import json
from typing import List

from langchain_chroma import Chroma
from langchain_core.documents import Document
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_groq import ChatGroq
from dotenv import load_dotenv

load_dotenv()

QA_MODEL    = "meta-llama/llama-4-scout-17b-16e-instruct"
TOP_K       = 4          # number of chunks to retrieve



# SYSTEM PROMPT 

SYSTEM_PROMPT = """You are a clinical medical assistant that answers questions 
STRICTLY based on the content of the medical PDF documents provided to you.

RULES YOU MUST FOLLOW:
1. Answer ONLY using information found in the retrieved document excerpts below.
2. If the documents do not contain enough information to answer the question,
   respond with: "The uploaded medical documents do not contain sufficient 
   information to answer this question."
3. NEVER use outside knowledge, assumptions, or general medical training 
   beyond what is explicitly stated in the documents.
4. For clinical data (dosages, statistics, p-values, patient counts), 
   reproduce numbers exactly as they appear in the source.
5. Do not speculate, infer, or extrapolate beyond what the documents state.
6. If a question is outside the scope of the uploaded documents, say so clearly.

Answer (in 3–5 clear sentences):
"""



# RETRIEVE

def retrieve_chunks(vectorstore: Chroma, query: str, k: int = TOP_K) -> List[Document]:
    """Retrieve the top-k most relevant chunks for a query."""
    retriever = vectorstore.as_retriever(search_kwargs={"k": k})
    return retriever.invoke(query)



# BUILD CONTEXT STRING

def build_context(chunks: List[Document]) -> tuple[str, List[str]]:
    """
    Build a plain-text context block and collect all base64 images
    from the retrieved chunks.

    Returns
    -------
    context_text : str   — text + table content for the prompt
    all_images   : list  — list of base64 image strings
    """
    context_text = ""
    all_images: List[str] = []

    for i, chunk in enumerate(chunks):
        context_text += f"=== Document Excerpt {i + 1} ===\n"

        if "original_content" in chunk.metadata:
            original_data = json.loads(chunk.metadata["original_content"])

            raw_text = original_data.get("raw_text", "")
            if raw_text:
                context_text += f"TEXT:\n{raw_text}\n\n"

            tables_html = original_data.get("tables_html", [])
            if tables_html:
                context_text += "TABLES:\n"
                for j, table in enumerate(tables_html):
                    context_text += f"Table {j + 1}:\n{table}\n\n"

            images_base64 = original_data.get("images_base64", [])
            all_images.extend(images_base64)
        else:
            context_text += f"{chunk.page_content}\n\n"

        context_text += "\n"

    return context_text, all_images



# GENERATE ANSWER

def generate_answer(
    vectorstore: Chroma,
    query: str,
    k: int = TOP_K,
) -> dict:
    """
    Full RAG answer generation pipeline.

    Returns
    -------
    dict with keys:
        answer      : str            — the model's answer
        source_docs : List[Document] — retrieved chunks used
    """
    try:
        llm = ChatGroq(model=QA_MODEL, temperature=0)

        # Retrieve relevant chunks
        chunks = retrieve_chunks(vectorstore, query, k)

        if not chunks:
            return {
                "answer": "No relevant content found in the uploaded documents.",
                "source_docs": [],
            }

        # Build context
        context_text, images = build_context(chunks)

        # Build user prompt
        user_prompt = (
            f"RETRIEVED DOCUMENT CONTENT:\n\n"
            f"{context_text}\n"
            f"─────────────────────────────────────────\n"
            f"QUESTION: {query}\n\n"
            f"Remember: Answer ONLY from the document content above. "
            f"If the answer is not present, say so explicitly.\n\n"
            f"ANSWER:"
        )

        # Build multimodal message (text + any retrieved images)
        message_content: list = [{"type": "text", "text": user_prompt}]

        for image_base64 in images:
            message_content.append({
                "type": "image_url",
                "image_url": {"url": f"data:image/jpeg;base64,{image_base64}"},
            })

        response = llm.invoke([
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(content=message_content),
        ])

        return {
            "answer":      response.content,
            "source_docs": chunks,
        }

    except Exception as e:
        return {
            "answer":      f"❌ Answer generation failed: {e}",
            "source_docs": [],
        }
