# Biomedical RAG Assistant

A RAG-powered document Q&A system for biomedical research. Upload PubMed clinical trial PDFs and ask questions — answers are grounded strictly from the uploaded documents.


## How It Works

1. Upload a medical PDF → parsed and chunked by section
2. Chunks are embedded using a local HuggingFace model → stored in ChromaDB
3. You ask a question → top relevant chunks are retrieved
4. LLaMA 4 Scout (via Groq) generates a grounded answer with source citations


## Project Structure

```
├── app.py            # Streamlit UI
├── embed_store.py    # PDF parsing, chunking, embedding, ChromaDB
├── qa_chain.py       # Retrieval and answer generation
├── .env              # API keys (create this yourself)
├── chroma_db/        # Auto-created vector store
└── README.md
```


## Setup


###  Install dependencies

```bash
pip install streamlit langchain langchain-groq langchain-chroma langchain-huggingface \
            sentence-transformers chromadb unstructured[pdf] python-dotenv
```

> **Note:** `unstructured[pdf]` also requires system dependencies for hi-res PDF parsing:
> ```bash
> pip install "unstructured[all-docs]"
> ```

### Get a Groq API key

Sign up at [console.groq.com](https://console.groq.com).

### Create a `.env` file

```
GROQ_API_KEY=your_api_key_here
```

---

## Run the App

```bash
streamlit run app.py
```

Open [http://localhost:8501](http://localhost:8501) in your browser.

---

## Usage

1. **Upload a PDF** — use the sidebar file uploader
2. **Click "Add to Index"** — waits while the document is processed (takes 1–3 min for large PDFs)
3. **Ask a question** — type in the chat box at the bottom
4. **View sources** — expand the "View source excerpts" section under each answer

> To replace the current document entirely, use **"Reindex"** instead of "Add to Index".

---

## Configuration

Key settings in `embed_store.py`:

| Variable | Default | Description |
|---|---|---|
| `PERSIST_DIRECTORY` | `chroma_db` | Where ChromaDB is saved |
| `EMBEDDING_MODEL` | `all-MiniLM-L6-v2` | HuggingFace embedding model |
| `SUMMARY_MODEL` | `llama-4-scout-17b` | Groq model for chunk summarisation |
| `max_characters` | `3000` | Max chunk size |

Key setting in `qa_chain.py`:

| Variable | Default | Description |
|---|---|---|
| `QA_MODEL` | `llama-4-scout-17b` | Groq model for answer generation |
| `TOP_K` | `4` | Number of chunks retrieved per query |

---

## Notes

- The vector index persists to disk — you don't need to re-upload PDFs on every restart
- The LLM will explicitly say when a question cannot be answered from the uploaded documents
