import json
import os
from typing import List

from unstructured.partition.pdf import partition_pdf
from unstructured.chunking.title import chunk_by_title
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_groq import ChatGroq
from langchain_core.documents import Document
from langchain_chroma import Chroma
from langchain_core.messages import HumanMessage, SystemMessage
from dotenv import load_dotenv

load_dotenv()

PERSIST_DIRECTORY = "chroma_db"
EMBEDDING_MODEL   = "sentence-transformers/all-MiniLM-L6-v2"
SUMMARY_MODEL     = "meta-llama/llama-4-scout-17b-16e-instruct"



# PARTITION

def partition_document(file_path: str):
    """Extract elements from PDF using unstructured hi-res strategy."""
    print(f"📄 Partitioning document: {file_path}")

    elements = partition_pdf(
        filename=file_path,
        strategy="hi_res",
        infer_table_structure=True,
        extract_image_block_types=["Image"],
        extract_image_block_to_payload=True,
    )

    print(f"✅ Extracted {len(elements)} elements")
    return elements



# CHUNK

def create_chunks_by_title(elements):
    """Chunk elements by section title with sensible size limits."""
    print("🔨 Creating smart chunks...")

    chunks = chunk_by_title(
        elements,
        max_characters=3000,
        new_after_n_chars=2400,
        combine_text_under_n_chars=500,
    )

    print(f"✅ Created {len(chunks)} chunks")
    return chunks



# SEPARATE CONTENT TYPES

def separate_content_types(chunk) -> dict:
    """Split a chunk into text, tables, and images."""
    content_data = {
        "text": chunk.text,
        "tables": [],
        "images": [],
        "types": ["text"],
    }

    if hasattr(chunk, "metadata") and hasattr(chunk.metadata, "orig_elements"):
        for element in chunk.metadata.orig_elements:
            element_type = type(element).__name__

            if element_type == "Table":
                content_data["types"].append("table")
                table_html = getattr(element.metadata, "text_as_html", element.text)
                content_data["tables"].append(table_html)

            elif element_type == "Image":
                if hasattr(element, "metadata") and hasattr(element.metadata, "image_base64"):
                    content_data["types"].append("image")
                    content_data["images"].append(element.metadata.image_base64)

    content_data["types"] = list(set(content_data["types"]))
    return content_data



# AI-ENHANCED SUMMARY

def create_ai_enhanced_summary(text: str, tables: List[str], images: List[str]) -> str:
    """
    Generate a retrieval-optimised summary for chunks that contain
    tables or images, using a vision-capable Groq model.
    """
    try:
        llm = ChatGroq(model=SUMMARY_MODEL, temperature=0)

        system_prompt = (
            "You are a medical document analyst. "
            "Your job is to create detailed, searchable summaries of medical content "
            "extracted from clinical PDFs. Be factual and precise."
        )

        # Build user prompt
        user_prompt = (
            "Create a comprehensive, searchable description of the following "
            "medical document content for use in a retrieval system.\n\n"
            "TEXT CONTENT:\n"
            f"{text}\n\n"
        )

        if tables:
            user_prompt += "TABLES:\n"
            for i, table in enumerate(tables):
                user_prompt += f"Table {i + 1}:\n{table}\n\n"

        user_prompt += (
            "YOUR TASK:\n"
            "Generate a comprehensive description that covers:\n"
            "1. Key medical facts, statistics, dosages, and clinical findings\n"
            "2. Diseases, conditions, treatments, and drugs mentioned\n"
            "3. Study design details (if applicable)\n"
            "4. Numerical data from tables (patient counts, percentages, p-values)\n"
            "5. Visual content analysis (if images are present)\n"
            "6. Synonyms and alternative medical terms a clinician might search for\n\n"
            "Prioritise findability and clinical accuracy over brevity.\n\n"
            "SEARCHABLE DESCRIPTION:"
        )

        # Build multimodal message 
        message_content: List[dict] = [{"type": "text", "text": user_prompt}]

        for image_base64 in images:
            message_content.append({
                "type": "image_url",
                "image_url": {"url": f"data:image/jpeg;base64,{image_base64}"},
            })

        response = llm.invoke([
            SystemMessage(content=system_prompt),
            HumanMessage(content=message_content),
        ])

        return response.content

    except Exception as e:
        print(f"     ❌ AI summary failed: {e}")
        fallback = f"{text[:300]}..."
        if tables:
            fallback += f" [Contains {len(tables)} table(s)]"
        if images:
            fallback += f" [Contains {len(images)} image(s)]"
        return fallback



# SUMMARISE ALL CHUNKS

def summarise_chunks(chunks) -> List[Document]:
    """Process every chunk, enriching mixed-content chunks with AI summaries."""
    print("🧠 Processing chunks with AI summaries...")

    langchain_documents = []
    total = len(chunks)

    for i, chunk in enumerate(chunks):
        print(f"   Processing chunk {i + 1}/{total}")

        content_data = separate_content_types(chunk)
        print(f"     Types: {content_data['types']} | "
              f"Tables: {len(content_data['tables'])} | "
              f"Images: {len(content_data['images'])}")

        if content_data["tables"] or content_data["images"]:
            print("     → Creating AI summary for mixed content...")
            enhanced_content = create_ai_enhanced_summary(
                content_data["text"],
                content_data["tables"],
                content_data["images"],
            )
            print(f"     → Preview: {enhanced_content[:150]}...")
        else:
            print("     → Using raw text (no tables/images)")
            enhanced_content = content_data["text"]

        doc = Document(
            page_content=enhanced_content,
            metadata={
                "original_content": json.dumps({
                    "raw_text":       content_data["text"],
                    "tables_html":    content_data["tables"],
                    "images_base64":  content_data["images"],
                })
            },
        )
        langchain_documents.append(doc)

    print(f"✅ Processed {len(langchain_documents)} chunks")
    return langchain_documents



# VECTOR STORE

def create_vector_store(
    documents: List[Document],
    persist_directory: str = PERSIST_DIRECTORY,
) -> Chroma:
    """Embed documents and persist to ChromaDB."""
    print("🔮 Creating embeddings and storing in ChromaDB...")

    embedding_model = HuggingFaceEmbeddings(model_name=EMBEDDING_MODEL)

    vectorstore = Chroma.from_documents(
        documents=documents,
        embedding=embedding_model,
        persist_directory=persist_directory,
        collection_metadata={"hnsw:space": "cosine"},
    )

    print(f"✅ Vector store saved to '{persist_directory}'")
    return vectorstore


def load_vector_store(persist_directory: str = PERSIST_DIRECTORY) -> Chroma:
    """Load an existing ChromaDB vector store from disk."""
    embedding_model = HuggingFaceEmbeddings(model_name=EMBEDDING_MODEL)

    vectorstore = Chroma(
        persist_directory=persist_directory,
        embedding_function=embedding_model,
        collection_metadata={"hnsw:space": "cosine"},
    )
    return vectorstore



# FULL PIPELINE 

def build_index(file_path: str, persist_directory: str = PERSIST_DIRECTORY) -> Chroma:
    """
    End-to-end pipeline: PDF → elements → chunks → summaries → vector store.
    Returns the Chroma vectorstore.
    """
    elements        = partition_document(file_path)
    chunks          = create_chunks_by_title(elements)
    processed_docs  = summarise_chunks(chunks)
    vectorstore     = create_vector_store(processed_docs, persist_directory)
    return vectorstore
