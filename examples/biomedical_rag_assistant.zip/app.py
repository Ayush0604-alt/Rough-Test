import os
import shutil
import tempfile
import streamlit as st
from dotenv import load_dotenv

from embed_store import build_index, load_vector_store, PERSIST_DIRECTORY
from qa_chain import generate_answer

load_dotenv()

st.set_page_config(page_title="Biomedical RAG Assistant", page_icon="🩺", layout="wide")


# SESSION STATE

if "vectorstore"   not in st.session_state: st.session_state.vectorstore   = None
if "chat_history"  not in st.session_state: st.session_state.chat_history  = []
if "indexed_files" not in st.session_state: st.session_state.indexed_files = []



# HELPERS

def try_load_existing_index():
    if os.path.isdir(PERSIST_DIRECTORY) and os.listdir(PERSIST_DIRECTORY):
        try:
            st.session_state.vectorstore = load_vector_store(PERSIST_DIRECTORY)
            return True
        except Exception:
            return False
    return False


def index_pdf(uploaded_file, reindex: bool = False) -> bool:
    with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
        tmp.write(uploaded_file.read())
        tmp_path = tmp.name

    try:
        if reindex and os.path.isdir(PERSIST_DIRECTORY):
            shutil.rmtree(PERSIST_DIRECTORY)
            st.session_state.indexed_files = []

        with st.spinner(f"Indexing {uploaded_file.name} — this may take a few minutes..."):
            st.session_state.vectorstore = build_index(tmp_path, PERSIST_DIRECTORY)

        if uploaded_file.name not in st.session_state.indexed_files:
            st.session_state.indexed_files.append(uploaded_file.name)

        return True

    except Exception as e:
        st.error(f"Indexing failed: {e}")
        return False

    finally:
        os.unlink(tmp_path)



# SIDEBAR

with st.sidebar:
    st.title("🩺 Biomedical PDF RAG")
    st.divider()

    # Auto-load existing index on first run
    if st.session_state.vectorstore is None:
        if try_load_existing_index():
            st.success("Existing index loaded from disk.")

    # Index status
    if st.session_state.vectorstore is not None:
        st.success("Index is ready.")
        if st.session_state.indexed_files:
            st.markdown("**Indexed files:**")
            for f in st.session_state.indexed_files:
                st.markdown(f"- {f}")
    else:
        st.warning("No index found. Upload a PDF to get started.")

    st.divider()

    # Upload
    st.subheader("📤 Upload PDF")
    uploaded_file = st.file_uploader("Choose a medical PDF", type=["pdf"])

    col1, col2 = st.columns(2)
    with col1:
        if st.button("Add to Index", disabled=uploaded_file is None, use_container_width=True):
            if index_pdf(uploaded_file, reindex=False):
                st.success("Done!")
                st.rerun()
    with col2:
        if st.button("Reindex", disabled=uploaded_file is None, use_container_width=True,
                     help="Wipes existing index and rebuilds from this file only"):
            if index_pdf(uploaded_file, reindex=True):
                st.session_state.chat_history = []
                st.success("Done!")
                st.rerun()

    st.divider()

    if st.button("🗑️ Clear Chat", use_container_width=True):
        st.session_state.chat_history = []
        st.rerun()



# MAIN AREA

st.title("🩺 Biomedical Document Q&A")
st.caption("Answers are grounded strictly from your uploaded PDFs.")
st.divider()

# Chat history
if not st.session_state.chat_history:
    st.info("Upload a medical PDF in the sidebar, then ask a question below.")
else:
    for turn in st.session_state.chat_history:
        with st.chat_message("user"):
            st.write(turn["question"])

        with st.chat_message("assistant"):
            st.write(turn["answer"])

            if turn.get("source_docs"):
                with st.expander(f"View {len(turn['source_docs'])} source excerpt(s)"):
                    for i, doc in enumerate(turn["source_docs"]):
                        st.markdown(f"**Excerpt {i + 1}**")
                        st.caption(doc.page_content[:400] + "…")
                        st.divider()

# Query input
st.divider()
query = st.chat_input("Ask a question about your medical documents...")

if query:
    if st.session_state.vectorstore is None:
        st.warning("Please upload and index a PDF before asking questions.")
    else:
        with st.chat_message("user"):
            st.write(query)

        with st.chat_message("assistant"):
            with st.spinner("Searching and generating answer..."):
                result = generate_answer(st.session_state.vectorstore, query)
            st.write(result["answer"])

            if result.get("source_docs"):
                with st.expander(f"View {len(result['source_docs'])} source excerpt(s)"):
                    for i, doc in enumerate(result["source_docs"]):
                        st.markdown(f"**Excerpt {i + 1}**")
                        st.caption(doc.page_content[:400] + "…")
                        st.divider()

        st.session_state.chat_history.append({
            "question":    query,
            "answer":      result["answer"],
            "source_docs": result.get("source_docs", []),
        })
