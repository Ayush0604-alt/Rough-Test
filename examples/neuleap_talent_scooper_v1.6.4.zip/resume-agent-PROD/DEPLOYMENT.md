# Deployment, Upgrades & Disaster Recovery

## Why upgrades are data-safe

Persistent state never lives in the app/frontend containers:

- **PostgreSQL** → named volume `pg_data`
- **MinIO** (raw + resume files) → named volume `minio_data`
- **Config / secrets / tokens** → host bind-mounts `./secrets` and `./.env`
- **Schema** → `app/db/schema.sql` runs on every boot with `CREATE TABLE/INDEX IF NOT EXISTS`
  and an additive-`ALTER` migration block, so **new columns/tables are created in place** —
  existing rows are untouched.

Therefore the correct upgrade **preserves all data**:

```bash
docker compose build && docker compose up -d       # ✅ keeps data + config
```

The **only** thing that destroys data is `docker compose down -v` (the `-v` deletes the
named volumes). Never use `-v` for an upgrade. There is no need for a "full cleanup and
recreation" — that was the source of the data loss.

## Seamless upgrade (with pre-backup + auto-rollback)

```bash
bash scripts/upgrade.sh
```

1. Takes a **full pre-upgrade DB dump** (`backups/preupgrade/…`).
2. Tags the current images as `:rollback`.
3. Rebuilds + `up -d` (volumes preserved; schema migrates additively).
4. Waits for health, runs a **consistency check**.
5. On any failure, auto-runs `scripts/rollback.sh` (restores the previous images + DB).

Manual rollback: `bash scripts/rollback.sh backups/preupgrade/preupgrade_<STAMP>`

> Windows: run these from **Git Bash** (`bash scripts/upgrade.sh`).

## Backup & Disaster Recovery

Configured in **Settings → Backup & Disaster Recovery** (System Admin only).

- **Full backup** = `pg_dump -Fc` of PostgreSQL **+** a snapshot of both MinIO buckets **+** the
  system configuration (`secrets/`), so a full set restores the whole system.
- **Incremental** = the DB dump only (small + frequent; files + config are captured by the weekly full).
- **Targets**: primary local dir (`$HOST_DATA_DIR/backups`) → copied to a **secondary**
  (`$HOST_DATA_DIR/backups-secondary`, repointable at a mounted/NAS share) and pushed to an optional
  **S3-compatible cloud** bucket, so there are always ≥2 full sets in different places.

> **Data lives outside the repo.** `backups`, `backups-secondary`, and `dist-bundle` are large,
> churny artifacts kept **outside the repo folder** and bind-mounted in via `HOST_DATA_DIR` (set in
> `.env` to the host path that holds them; defaults to the repo dir if unset). The app mounts them at
> `/app/backups` + `/app/backups-secondary`; the updater sidecar also mounts `$HOST_DATA_DIR/backups`
> at `/project/backups` so the upgrade handshake still reaches it. `scripts/make-bundle.sh` writes to
> `$DIST_OUT` (default `../dist-bundle`).
- **Retention**: keeps ≥2 full sets + N recent incrementals (configurable).
- **Schedule**: incremental every _N_ hours + a weekly full on a chosen day/hour.

### Enabling the secondary (NAS) path

Uncomment the secondary mount in `docker-compose.yml` (point the host side at your external
disk / NAS share) and set the **same container path** in Settings → Backup:

```yaml
# - /mnt/nas/neuleap-backups:/app/backups-secondary
```
then set `Secondary path = /app/backups-secondary` in Settings.

### Enabling cloud (S3-compatible)

In Settings → Backup → Cloud: enable, set the endpoint (blank = AWS S3), region, bucket,
prefix, and access/secret keys.

## How to test (separately, before QA)

**Backups**
1. Settings → Backup & Disaster Recovery → **Backup now (full)**.
2. Confirm a set appears under **Available backups** with a green status and file sizes.
3. On the host: `ls backups/full/` shows `full_<stamp>/` with `db.dump`,
   `minio_raw.tar.gz`, `minio_resume.tar.gz`, `manifest.json`.
4. Set an incremental interval + weekly full, Save, and confirm the schedule shows in Health.

**Upgrade + rollback**
1. Bump `APP_VERSION`, then `bash scripts/upgrade.sh` → confirm it backs up, rebuilds,
   health-checks, and reports success; data (candidates, banks, config) is intact.
2. To prove rollback: temporarily break the app build, run `scripts/upgrade.sh`, and confirm
   it auto-reverts to the previous images and restores the DB dump.

**Health**
- Settings → Backup & Disaster Recovery → **System Health**: DB ✓, Storage ✓ (object counts),
  disk free, last full/incremental times, secondary/cloud configured flags.

## In-app upgrade (Settings → System Upgrade)

One-click upgrade of a **running** deployment, driven by the `updater` sidecar (a
small container with the Docker socket + project mounted, started by
`docker compose up -d`).

The updater is **opt-in** (it holds the Docker socket). Start it before upgrading:

```bash
docker compose --profile updater up -d      # start the updater sidecar
```

Settings → System Upgrade warns + disables Upgrade if it isn't running.

### 1. Build a bundle (on the machine with the new images)

```bash
docker compose build app frontend           # build the new version
bash scripts/keygen.sh                       # ONCE: Ed25519 keypair (private + public)
SIGN_KEY=signing_private.pem bash scripts/make-bundle.sh v1.3.1 [features.txt]
# -> dist-bundle/bundle_v1.3.1.tar  (docker save of both images + manifest + signature)
```

Paste `signing_public.pem` into Settings → System Upgrade (once). Then only bundles signed
with the matching private key install; a tampered/unsigned bundle is rejected. Omit `SIGN_KEY`
for an unsigned bundle (allowed only when no public key is configured and "require signature"
is off). `features.txt` (optional): one line per feature, shown after the upgrade.

**Carrying `.env` + compose changes in the bundle.** Most releases are pure code (backend +
frontend images + `schema.sql`, which the app runs additively). When a release also needs a new
env var or compose topology, add them to the bundle:

```bash
printf 'NEW_FEATURE_FLAG=1\nSOME_TIMEOUT=30\n' > env.add          # new .env keys (with defaults)
# overlay.yml: a compose overlay adding a port/service/volume, e.g. a new published port
ENV_ADDITIONS=env.add COMPOSE_OVERLAY=overlay.yml \
  SIGN_KEY=signing_private.pem bash scripts/make-bundle.sh v1.4.0 features.txt
```

On upgrade the updater **appends only the missing `.env` keys** (never overwriting your values)
and installs the compose overlay as `docker-compose.bundle.yml`, wiring `COMPOSE_FILE` so every
future `docker compose up -d` includes it. Both are checksummed in the signed manifest, and both
are reverted on rollback. New env vars alone don't even need the overlay — the app loads the whole
`.env`, so a new key is picked up automatically on the recreate.

### 2. Upgrade (System Admin)

Settings → **System Upgrade** → upload `bundle_v1.3.1.tar` → the app validates the
manifest + image checksums and shows the version + feature list → **Upgrade now**.

Behind the button:
1. The app takes a **full pre-upgrade backup**.
2. The **updater** tags the current images `:rollback`, `docker load`s the new
   images, recreates `app` + `frontend` (**data volumes preserved**), waits for
   health, then runs **consistency** (DB row count) + **integrity** (`/health`)
   checks.
3. On success → status `success` with the new feature list (poll survives the
   brief restart — the result is read from a shared status file).
4. On **any** failure → the updater retags `:rollback` → `:latest`, recreates,
   and **restores the DB from the pre-upgrade backup**; status shows
   `rolled_back`.

> The app + this page restart during the swap. If the page disconnects, wait
> ~1–2 min and refresh — the final result shows in Settings → System Upgrade.

### Testing the in-app upgrade

- **Same-version dry run** (safe): build a bundle from the *current* images and
  upgrade to it — it reloads identical images, all checks pass, `success`, data
  intact. This exercises the whole path without a version change.
- **Rollback**: build a bundle whose app image fails its health/consistency
  check (e.g. a deliberately broken build) and upgrade — confirm it auto-reverts
  to the previous images and restores the DB, status `rolled_back`.

> Security note: the `updater` has Docker-socket access (required to swap the
> stack). It only acts on a request the app writes after a System-Admin upgrade.
