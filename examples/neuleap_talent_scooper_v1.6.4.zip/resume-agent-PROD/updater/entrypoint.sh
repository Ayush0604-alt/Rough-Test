#!/usr/bin/env bash
# NeuLeap updater sidecar. Watches a shared dir for an upgrade request written
# by the app, then performs a data-safe image swap with health + consistency
# checks and automatic rollback on any failure. It has the Docker socket + the
# project mounted so it can drive `docker compose` against the SAME stack.
#
# Protocol (all under $SHARED = ./backups/upgrade on the host):
#   request.json   {bundle_id, pre_backup_id}   — written by the app on "Upgrade"
#   incoming/<id>/ {app.tar, frontend.tar, manifest.json}  — the uploaded bundle
#   status.json    {state, phase, message, version, features, updated_at}  — us
set -uo pipefail

SHARED="${SHARED:-/project/backups/upgrade}"
PROJECT="${COMPOSE_PROJECT_NAME:-neuleap_app_v2}"
cd /project

# ── Resolve the REAL host project dir ──
# We drive `docker compose` from inside this container, but the Docker daemon
# runs on the host: any relative bind source ("./backups") would resolve to our
# own /project and the daemon would bind a phantom empty dir, silently detaching
# the app's .env/secrets/backups on every upgrade. So we self-inspect our own
# /project mount to learn the true host path and export it as HOST_PROJECT_DIR,
# which docker-compose.yml uses as the bind base (backslashes → forward slashes
# so Docker Desktop accepts the Windows path). Falls back to "." if inspection
# fails (e.g. a pure-Linux host where relative sources already resolve right).
resolve_host_project_dir() {
  local self src
  self=$(cat /etc/hostname 2>/dev/null)
  src=$(docker inspect "$self" \
        --format '{{range .Mounts}}{{if eq .Destination "/project"}}{{.Source}}{{end}}{{end}}' \
        2>/dev/null)
  [ -n "$src" ] || { echo "."; return; }
  printf '%s' "$src" | tr '\\' '/'   # C:\Users\… → C:/Users/… (valid for Docker Desktop)
}
export HOST_PROJECT_DIR="$(resolve_host_project_dir)"
echo "updater: HOST_PROJECT_DIR=$HOST_PROJECT_DIR"

# The compose command, auto-including the optional bundle overlay whenever it
# exists (so a bundle that adds a port/service/volume persists across restarts).
compose_cmd() {
  local c="docker compose -f docker-compose.yml"
  [ -f docker-compose.override.yml ] && c="$c -f docker-compose.override.yml"
  [ -f docker-compose.bundle.yml ]   && c="$c -f docker-compose.bundle.yml"
  echo "$c"
}

now() { date -u +%Y-%m-%dT%H:%M:%SZ; }

# Build a SIGNED revert bundle of the CURRENTLY-RUNNING images and drop it in the
# install drop folder BEFORE swapping to the new one. The :rollback image tags
# (below) only survive until the NEXT upgrade and auto-revert only on failure —
# this gives the operator a durable, reinstallable copy of the version they're
# leaving, so they can roll back later even after a "successful" upgrade turns out
# bad. Only the most recent revert bundle is kept. Best-effort: a failure here is
# logged and NEVER blocks the upgrade.
REVERT_KEY="/project/backups/tb/private.pem"
build_revert_bundle() {
  local dropdir="$SHARED/drop"
  mkdir -p "$dropdir" || return 1
  local cur_ver stage app_sha fe_sha files out
  cur_ver=$(cat "$SHARED/current_version" 2>/dev/null || true)
  [ -n "$cur_ver" ] || cur_ver="pre-$(date -u +%Y%m%d.%H%M)"
  stage=$(mktemp -d) || return 1
  docker save "${PROJECT}-app:latest"      -o "$stage/app.tar"      || { rm -rf "$stage"; return 1; }
  docker save "${PROJECT}-frontend:latest" -o "$stage/frontend.tar" || { rm -rf "$stage"; return 1; }
  app_sha=$(sha256sum "$stage/app.tar" | cut -d' ' -f1)
  fe_sha=$(sha256sum "$stage/frontend.tar" | cut -d' ' -f1)
  jq -n --arg ver "$cur_ver" --arg ts "$(now)" --arg proj "$PROJECT" --arg a "$app_sha" --arg f "$fe_sha" \
    '{version:$ver, created_at:$ts, project:$proj, revert:true,
      images:[{service:"app",tarfile:"app.tar",image:($proj+"-app:latest"),sha256:$a},
              {service:"frontend",tarfile:"frontend.tar",image:($proj+"-frontend:latest"),sha256:$f}],
      env_sha256:"", overlay_sha256:"", features:[("Revert to " + $ver)]}' \
    > "$stage/manifest.json" || { rm -rf "$stage"; return 1; }
  files="app.tar frontend.tar manifest.json"
  if [ -f "$REVERT_KEY" ] && command -v python3 >/dev/null 2>&1 && [ -f /project/scripts/sign_bundle.py ]; then
    if python3 /project/scripts/sign_bundle.py "$REVERT_KEY" "$stage/manifest.json" "$stage/manifest.sig" >/dev/null 2>&1; then
      files="$files manifest.sig"
    else
      echo "updater: revert-bundle signing failed (leaving unsigned — install will refuse it if a signing key is configured)"
    fi
  else
    echo "updater: no signing key at $REVERT_KEY — revert bundle left unsigned"
  fi
  out="$dropdir/bundle_revert_${cur_ver}.tar"
  rm -f "$dropdir"/bundle_revert_*.tar   # keep only the latest revert copy
  tar -C "$stage" -cf "$out" $files && echo "updater: wrote revert bundle -> $out"
  rm -rf "$stage"
}

# Append only the .env keys a bundle introduces that aren't already set — new
# feature defaults ride along, operator-set values are never overwritten.
apply_env_additions() {
  local src="$1" envf="/project/.env"
  [ -f "$src" ] || return 0
  touch "$envf"
  while IFS= read -r line || [ -n "$line" ]; do
    case "$line" in ''|\#*) continue;; esac
    local key="${line%%=*}"
    grep -qE "^[[:space:]]*${key}[[:space:]]*=" "$envf" || printf '%s\n' "$line" >> "$envf"
  done < "$src"
  echo "applied .env additions from bundle"
}

# Install the bundle's compose overlay so future `docker compose up -d` includes
# it too — via COMPOSE_FILE + a pinned separator (robust across Linux/Windows).
apply_compose_overlay() {
  local src="$1" envf="/project/.env"
  [ -f "$src" ] || return 0
  cp "$src" /project/docker-compose.bundle.yml
  grep -q '^COMPOSE_PATH_SEPARATOR=' "$envf" 2>/dev/null || echo 'COMPOSE_PATH_SEPARATOR=:' >> "$envf"
  if ! grep -q '^COMPOSE_FILE=' "$envf" 2>/dev/null; then
    local files="docker-compose.yml"
    [ -f /project/docker-compose.override.yml ] && files="$files:docker-compose.override.yml"
    files="$files:docker-compose.bundle.yml"
    echo "COMPOSE_FILE=$files" >> "$envf"
  elif ! grep -q 'docker-compose.bundle.yml' "$envf"; then
    sed -i 's#^COMPOSE_FILE=.*#&:docker-compose.bundle.yml#' "$envf"
  fi
  echo "applied compose overlay from bundle"
}

# Version + features for the current upgrade, injected into every status write.
# Features are kept in a FILE and read via jq --slurpfile so no JSON ever passes
# through shell-arg quoting (which was silently corrupting it).
UPG_VERSION=""
UPG_FEATURES_FILE="/tmp/upg_features.json"
echo '[]' > "$UPG_FEATURES_FILE"

status() {  # state phase message   (version/features come from the globals)
  mkdir -p "$SHARED"
  if jq -n --arg state "$1" --arg phase "$2" --arg msg "$3" --arg ts "$(now)" \
        --arg version "$UPG_VERSION" --slurpfile feats "$UPG_FEATURES_FILE" \
        '{state:$state, phase:$phase, message:$msg, updated_at:$ts, version:$version, features:($feats[0] // [])}' \
        > "$SHARED/status.json.tmp" 2>/dev/null; then
    mv "$SHARED/status.json.tmp" "$SHARED/status.json"
  else
    printf '{"state":"%s","phase":"%s","message":"%s","updated_at":"%s"}\n' \
      "$1" "$2" "$3" "$(now)" > "$SHARED/status.json"
  fi
  echo "[$(now)] $1/$2: $3"
}

do_upgrade() {
  local req="$1"
  local bundle_id pre_backup_id inc
  bundle_id=$(jq -r '.bundle_id' "$req")
  pre_backup_id=$(jq -r '.pre_backup_id // ""' "$req")
  inc="$SHARED/incoming/$bundle_id"
  if [ ! -f "$inc/manifest.json" ]; then
    status failed done "Bundle $bundle_id not found"
    return 1
  fi
  UPG_VERSION=$(jq -r '.version // ""' "$inc/manifest.json" 2>/dev/null || echo "")
  jq -c '.features // []' "$inc/manifest.json" > "$UPG_FEATURES_FILE" 2>/dev/null || echo '[]' > "$UPG_FEATURES_FILE"

  status running snapshot "Tagging current images for rollback"
  local app_cur fe_cur
  app_cur=$(docker inspect --format='{{.Image}}' "$($(compose_cmd) ps -q app 2>/dev/null)" 2>/dev/null || echo "")
  fe_cur=$(docker inspect --format='{{.Image}}' "$($(compose_cmd) ps -q frontend 2>/dev/null)" 2>/dev/null || echo "")
  [ -n "$app_cur" ] && docker tag "$app_cur" "${PROJECT}-app:rollback"
  [ -n "$fe_cur" ]  && docker tag "$fe_cur"  "${PROJECT}-frontend:rollback"

  # Durable, reinstallable revert copy of the version we're about to replace.
  status running revert-bundle "Saving a revert bundle of the current version"
  build_revert_bundle || echo "updater: revert bundle build skipped (non-fatal)"

  status running load "Loading new images"
  docker load -i "$inc/app.tar"       || { status failed load "docker load app failed"; return 1; }
  docker load -i "$inc/frontend.tar"  || { status failed load "docker load frontend failed"; return 1; }

  # Back up .env + any existing overlay so a rollback can restore them, then
  # apply the bundle's .env additions + compose overlay (both optional).
  cp /project/.env "/project/.env.preupgrade.bak" 2>/dev/null || true
  if [ -f /project/docker-compose.bundle.yml ]; then
    cp /project/docker-compose.bundle.yml /project/.bundle.preupgrade.bak
  else
    rm -f /project/.bundle.preupgrade.bak
  fi
  status running config "Applying .env + compose changes from the bundle"
  apply_env_additions "$inc/env.additions"
  apply_compose_overlay "$inc/overlay.compose.yml"

  status running recreate "Recreating app + frontend (data volumes preserved)"
  $(compose_cmd) up -d --no-build --force-recreate app frontend

  status running health "Waiting for the app to become healthy"
  local ok=0 i
  for i in $(seq 1 40); do
    if $(compose_cmd) ps app --format '{{.Status}}' | grep -q healthy; then ok=1; break; fi
    sleep 3
  done

  if [ "$ok" = "1" ]; then
    status running verify "Data consistency + integrity checks"
    if $(compose_cmd) exec -T postgres psql -U resume_user -d resume_db \
         -c "SELECT count(*) FROM candidate_master;" >/dev/null 2>&1 \
       && $(compose_cmd) exec -T app curl -fsS http://localhost:8000/health >/dev/null 2>&1; then
      # Remember the now-installed version so the NEXT upgrade's revert bundle is
      # labelled with the version it actually reverts to.
      [ -n "$UPG_VERSION" ] && printf '%s' "$UPG_VERSION" > "$SHARED/current_version" 2>/dev/null || true
      status success done "Upgrade complete and verified"
      return 0
    fi
  fi

  # ── rollback ──
  status running rollback "Upgrade failed — reverting to the previous version"
  # Revert .env + compose overlay to their pre-upgrade state first.
  cp "/project/.env.preupgrade.bak" /project/.env 2>/dev/null || true
  if [ -f /project/.bundle.preupgrade.bak ]; then
    cp /project/.bundle.preupgrade.bak /project/docker-compose.bundle.yml
  else
    rm -f /project/docker-compose.bundle.yml   # overlay was newly added this upgrade
  fi
  docker tag "${PROJECT}-app:rollback"      "${PROJECT}-app:latest"      2>/dev/null || true
  docker tag "${PROJECT}-frontend:rollback" "${PROJECT}-frontend:latest" 2>/dev/null || true
  $(compose_cmd) up -d --no-build --force-recreate app frontend
  if [ -n "$pre_backup_id" ] && [ -f "/project/backups/full/$pre_backup_id/db.dump" ]; then
    for i in $(seq 1 20); do
      $(compose_cmd) exec -T postgres pg_isready -U resume_user -d resume_db >/dev/null 2>&1 && break
      sleep 2
    done
    $(compose_cmd) exec -T postgres pg_restore -U resume_user -d resume_db \
       --clean --if-exists --no-owner --no-privileges < "/project/backups/full/$pre_backup_id/db.dump" || true
  fi
  status rolled_back done "Upgrade failed and was reverted to the previous version"
  return 1
}

echo "NeuLeap updater watching $SHARED (project=$PROJECT)"
mkdir -p "$SHARED"
while true; do
  now > "$SHARED/updater.alive"   # heartbeat so the app can show the updater is running
  if [ -f "$SHARED/request.json" ]; then
    req="$SHARED/request.processing.json"
    if mv "$SHARED/request.json" "$req" 2>/dev/null; then
      do_upgrade "$req" || true
      mkdir -p "$SHARED/history"
      cp "$SHARED/status.json" "$SHARED/history/status_$(date -u +%Y%m%dT%H%M%SZ).json" 2>/dev/null || true
      rm -f "$req"
    fi
  fi
  sleep 3
done
