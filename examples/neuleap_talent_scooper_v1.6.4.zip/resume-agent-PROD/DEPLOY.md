# Deploying to a new environment

The app keeps state in **two places**, and neither is reset by `docker compose
build`. If a new environment shows the previous one's data (leaked source tags,
a slot-picker stuck on *"Your interview is booked"*, old candidates), one of
these carried over:

| State | Lives in | Carries over when… |
| --- | --- | --- |
| Source tags, email templates, scheduling, scoring, LLM/mailbox keys, `jwt_secret.key` | **`secrets/`** — file config, bind-mounted (`./secrets:/app/secrets`) | you **copy the project folder** (a fresh `git clone` does NOT, since `secrets/*` is gitignored) |
| Candidates, rounds, slot invites + **bookings**, pools, audit log | **`pg_data`** Docker volume (Postgres) | you **reuse the volume** (`up` without `down -v`, or the same compose project name) |
| Uploaded resumes / raw files | **`minio_data`** Docker volume (MinIO) | same as above |

## Start a genuinely clean environment

From the project root, run the reset helper, then bring it up:

```powershell
# Windows (PowerShell)
powershell -ExecutionPolicy Bypass -File scripts\fresh-env.ps1
docker compose up -d --build
```

```bash
# Linux / macOS deploy host
bash scripts/fresh-env.sh
docker compose up -d --build
```

`fresh-env` empties `secrets/` (keeping only `.gitkeep`) and runs `docker
compose down -v` to drop the `pg_data` + `minio_data` volumes. It never touches
your source code. Flags: `--keep-secrets` (only reset the DB/volumes),
`--yes`/`-Yes` (skip the confirmation prompt).

On first start the app recreates safe defaults: **empty** source tags, a freshly
generated `secrets/jwt_secret.key`, the schema from `app/db/schema.sql`, and the
seeded default users (which are forced to change their password at first login).

## Set the environment before going live

`.env` carries `APP_ENV` and the provider secrets. Copy `.env.example` and set
real values on the new host — do **not** copy dev's `.env`.

- `APP_ENV=qa` (or `dev`) — candidate emails are redirected to the QA test
  inbox, and **System Cleanup** (Mailbox → gear drawer → Batch Archive) is
  available to wipe candidate/interview data + source tags without dropping the
  volumes. It is **disabled** for `production`/`prod`/`prd`.
- `APP_ENV=production` — real candidate emails send; no in-app wipe.

## Notes

- The app image never bakes `secrets/` in (the Dockerfile only `COPY app ./app`),
  and `.dockerignore` excludes `secrets/`, `.env`, `node_modules`, and build
  output as defense-in-depth.
- **System Cleanup** (QA only) clears every candidate/interview data table —
  including slot invites/bookings, pools, and session/OTP tables — plus the
  file-based source tags. It deliberately keeps login accounts and settings
  files (templates, LLM/mailbox keys).
