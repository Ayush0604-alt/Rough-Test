import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";
import {
  Clock,
  CheckCircle2,
  AlertTriangle,
  ExternalLink,
  UploadCloud,
  Inbox,
  X,
  ArrowLeft,
  ChevronRight,
  Loader2,
  FileX,
  ShieldAlert,
  Tag,
  Search,
  ArrowUp,
  ArrowDown,
  ArrowUpDown,
  Settings as SettingsGear,
  ChevronDown,
} from "lucide-react";
import { emailsService } from "@/services/emails";
import { reviewQueueService } from "@/services/reviewQueue";
import { graphService } from "@/services/graph";
import { pipelineService } from "@/services/pipeline";
import { sourceTagsService } from "@/services/sourceTags";
import { cn } from "@/lib/utils";
import type { EmailMaster, AgingBucket } from "@/types/email";
import { AGING_LABEL, AGING_PILL_CLS, AGING_RANGE, formatAge } from "@/lib/aging";
import UploadResumeModal from "@/components/intake/UploadResumeModal";
import RegisterSourceTagModal from "@/components/intake/RegisterSourceTagModal";
import UploadQueuePanel from "@/components/intake/UploadQueuePanel";
import BatchArchivePanel from "@/components/intake/BatchArchivePanel";
import InterviewerPoolsPanel from "@/components/intake/InterviewerPoolsPanel";
import EmailTemplatesPanel from "@/components/intake/EmailTemplatesPanel";
import MailboxAccountCard from "@/components/settings/MailboxAccountCard";
import OutlookIntakePanel from "@/components/intake/OutlookIntakePanel";
import { PipelineStatusBar, PipelineLastRun, usePipelineStatus } from "@/components/pipeline/PipelinePanel";
import ReviewQueue from "@/components/review/ReviewQueue";
import PageHeader from "@/components/layout/PageHeader";
import PageContainer from "@/components/layout/PageContainer";
import Pagination from "@/components/common/Pagination";
import { usePagination } from "@/hooks/usePagination";
import { useAuth } from "@/context/AuthContext";

type Tab = "All" | "Processed" | "Needs Review" | "Resolved";

// Which column the Emails table is sorted by — a subset that has an obvious
// total order (ID/Source/Received/Aging/Status); Sender/Subject/Type aren't
// offered as sort keys since free text rarely needs it and it'd clutter the
// header.
type SortKey = "id" | "source" | "received" | "aging" | "status";

// The table shows only three outcomes: Success, Failed, or an in-flight
// Queued/Processing. (Duplicate, Not a Resume, Exhausted, … all
// roll up into Failed — see displayStatus.)
const FINAL_STATUS_CLS: Record<string, string> = {
  Success: "text-emerald-600 bg-emerald-500/10 border-emerald-500/30",
  Queued: "text-blue-600 bg-blue-500/10 border-blue-500/30",
  Processing: "text-blue-600 bg-blue-500/10 border-blue-500/30",
  Failed: "text-rose-600 bg-rose-500/10 border-rose-500/30",
};

const MONTHS = [
  "Jan", "Feb", "Mar", "Apr", "May", "Jun",
  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
];

function finalOf(e: EmailMaster): string {
  return (e.final_status as string) || e.process_status;
}

// The single status shown in the table — collapsed to just three outcomes:
//   • a clean pass with nothing left to review        → "Success"
//   • still in-flight (a batch hasn't finished it yet) → "Queued" (shows "Processing"
//                                                          with a spinner while running)
//   • anything else — Duplicate, Not a Resume, Failed, Exhausted, … → "Failed"
// The specific cause is never lost: it rides along in the badge tooltip (failReason)
// and is spelled out, row by row, in the Activity log the "Audit" link opens.
function displayStatus(e: EmailMaster): "Success" | "Queued" | "Failed" {
  const fs = finalOf(e);
  if (fs === "Queued") return "Queued";
  if (fs === "Processed" && (e.open_reviews ?? 0) === 0) return "Success";
  return "Failed";
}

// One plain-English line explaining WHY a mail is marked Failed — surfaced in the
// badge tooltip so the table stays terse while the reason is a hover (or one Audit
// click) away.
function failReason(e: EmailMaster): string {
  if ((e.open_reviews ?? 0) > 0) {
    return `Needs review — ${e.open_reviews} item(s) from this email still need review`;
  }
  const fs = finalOf(e);
  const cause = fs && fs !== "Failed" && fs !== "Processed" ? fs : "Processing failed";
  return e.final_detail ? `${cause} — ${e.final_detail}` : cause;
}

// Which tab a mail belongs to. The live signal is open_reviews:
//   • open items still waiting on a human → Needs Review;
//   • once those are resolved/discarded (open_reviews → 0) it MOVES OUT — a clean
//     pass lands in Processed, anything else terminal (Duplicate, Not a Resume,
//     Failed, etc.) lands in Resolved. Queued/in-flight mail sits only under All.
function emailBucket(e: EmailMaster): "needs-review" | "processed" | "resolved" | null {
  if ((e.open_reviews ?? 0) > 0) return "needs-review";
  const fs = finalOf(e);
  if (fs === "Processed") return "processed";
  if (fs === "Queued") return null; // in-flight — not yet resolved
  return "resolved";
}

// Stored received_date arrives two ways — a plain calendar date ("2026-06-17") or a
// full UTC ISO timestamp ("2026-06-17T10:48:46Z"). Render both consistently: a clean
// "17 Jun 2026" date, with the wall-clock time (in IST) when one is available.
function formatReceived(raw?: string): { date: string; time?: string } {
  if (!raw) return { date: "—" };
  if (!raw.includes("T")) {
    const m = raw.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (!m) return { date: raw };
    return { date: `${m[3]} ${MONTHS[+m[2] - 1]} ${m[1]}` };
  }
  const d = new Date(raw);
  if (Number.isNaN(d.getTime())) return { date: raw };
  return {
    date: d.toLocaleDateString("en-IN", {
      day: "2-digit", month: "short", year: "numeric", timeZone: "Asia/Kolkata",
    }),
    time: d.toLocaleTimeString("en-IN", {
      hour: "2-digit", minute: "2-digit", hour12: false, timeZone: "Asia/Kolkata",
    }),
  };
}

// Per-file accounting for a mail that carries multiple resumes (a ZIP/Mixed/
// batch upload) — the collapsed 3-state badge (displayStatus) would otherwise
// show one "Failed" for the whole mail even when e.g. 20 of 23 files actually
// passed, hiding exactly how many succeeded/failed/still need review.
function fileAccounting(e: EmailMaster): { passed: number; failed: number; review: number; total: number } {
  const passed = e.candidate_count ?? 0;
  const failed = e.failed_files ?? 0;
  const review = e.open_reviews ?? 0;
  const attached = (e.attachment_names ?? "").split(",").map((s) => s.trim()).filter(Boolean).length;
  return { passed, failed, review, total: Math.max(attached, passed + failed) };
}

// True when a plain single-outcome badge (FinalStatusBadge) would hide real
// information — more than one file attempted AND outcomes actually differ
// (some passed while others failed/need review).
function needsAccountingBreakdown(e: EmailMaster): boolean {
  const { total, failed, review } = fileAccounting(e);
  return total > 1 && (failed > 0 || review > 0);
}

function FileAccountingBadge({ email }: { email: EmailMaster }) {
  const { passed, failed, review } = fileAccounting(email);
  return (
    <div className="space-y-1">
      <div className="flex flex-wrap items-center gap-1">
        {passed > 0 && (
          <span className="inline-flex items-center gap-1 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-1.5 py-0.5 text-[10px] font-medium text-emerald-600">
            <CheckCircle2 className="h-2.5 w-2.5" /> {passed} passed
          </span>
        )}
        {failed > 0 && (
          <span
            title={email.failed_reason ?? "Processing failed"}
            className="inline-flex items-center gap-1 rounded-full border border-rose-500/30 bg-rose-500/10 px-1.5 py-0.5 text-[10px] font-medium text-rose-600"
          >
            <AlertTriangle className="h-2.5 w-2.5" /> {failed} failed
          </span>
        )}
        {review > 0 && (
          <span className="inline-flex items-center gap-1 rounded-full border border-amber-500/30 bg-amber-500/10 px-1.5 py-0.5 text-[10px] font-medium text-amber-600">
            <Clock className="h-2.5 w-2.5" /> {review} review
          </span>
        )}
      </div>
      {failed > 0 && email.failed_reason && (
        <p className="max-w-[190px] truncate text-[10px] text-ink-mute" title={email.failed_reason}>
          {email.failed_reason}
        </p>
      )}
    </div>
  );
}

function guessType(email: EmailMaster): string {
  const names = (email.attachment_names ?? "").toLowerCase();
  if (names.includes(".xlsx") || names.includes(".xls")) return "Excel";
  if (names.includes(".zip")) return "ZIP";
  if (names.includes(".pdf") && names.includes(".docx")) return "Mixed";
  if (names.includes(".pdf")) return names.split(",").length > 1 ? `PDF ×${names.split(",").length}` : "PDF";
  if (names.includes(".docx")) return "DOCX";
  if (!names || names.trim() === "") return "None";
  return "PDF";
}

function FinalStatusBadge({
  status,
  detail,
  running,
}: {
  status: string;
  detail?: string;
  running?: boolean;
}) {
  // A "Queued" mail is in-flight: show "Processing" (with a live spinner) while a
  // batch is actually running, otherwise "Queued". Terminal outcomes resolve to
  // "Success" or "Failed".
  const isProcessing = status === "Queued" && running;
  const label = isProcessing ? "Processing" : status;
  const Icon =
    status === "Success"
      ? CheckCircle2
      : status === "Queued"
        ? isProcessing
          ? Loader2
          : Clock
        : AlertTriangle;
  return (
    <span
      title={detail}
      className={cn(
        "inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium border",
        FINAL_STATUS_CLS[label] ?? "text-slate-500 bg-slate-500/10 border-slate-500/30"
      )}
    >
      <Icon className={cn("h-3 w-3", isProcessing && "animate-spin")} /> {label}
    </span>
  );
}

const AGING_BUCKETS: AgingBucket[] = ["fresh", "aging", "stale", "critical"];
const isAgingBucket = (v: string | null): v is AgingBucket =>
  v != null && (AGING_BUCKETS as string[]).includes(v);

function AgingBadge({ email }: { email: EmailMaster }) {
  const bucket = email.aging_bucket;
  if (!bucket || email.age_hours == null) {
    return <span className="text-xs text-ink-mute">—</span>;
  }
  const verb = email.is_pending ? "waiting" : "old";
  return (
    <span
      title={`Received ~${formatAge(email.age_hours)} ago (${AGING_LABEL[bucket]} · ${AGING_RANGE[bucket]}) — ${verb}`}
      className={cn(
        "inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium border tnum",
        AGING_PILL_CLS[bucket]
      )}
    >
      <Clock className="h-3 w-3" /> {formatAge(email.age_hours)}
    </span>
  );
}

// The four processing outcomes surfaced in the overview strip. Each carries its
// own accent so the cards and the donut share one color language.
const SUMMARY_META = [
  { key: "processing", label: "Processing", icon: Loader2, color: "#0284c7" },
  { key: "processed", label: "Processed", icon: CheckCircle2, color: "#10b981" },
  { key: "failed", label: "Failed", icon: AlertTriangle, color: "#e11d48" },
  { key: "nonResume", label: "Not a Resume", icon: FileX, color: "#d97706" },
] as const;

type SummaryKey = (typeof SUMMARY_META)[number]["key"];

// Which of the four outcome buckets a mail contributes to — the EMAIL-level
// mirror of localSummary's per-resume tally, so the drill-down a card opens
// shows exactly the mails that produced that card's number. Reads the SAME
// finalOf/fileAccounting signals localSummary counts, so the card total and
// the rows it reveals can never drift apart. A multi-resume mail can match
// both Processed and Failed (some files passed, others didn't) — that's
// correct, it legitimately contributed to both cards.
function emailMatchesOutcome(e: EmailMaster, key: SummaryKey): boolean {
  const fs = finalOf(e);
  if (fs === "Queued") return key === "processing";
  if (fs === "Not a Resume") return key === "nonResume";
  const { passed, failed } = fileAccounting(e);
  if (passed === 0 && failed === 0) {
    return fs === "Processed" ? key === "processed" : key === "failed";
  }
  if (key === "processed") return passed > 0;
  if (key === "failed") return failed > 0;
  return false;
}

function SummaryCard({
  label,
  value,
  icon: Icon,
  color,
  selected = false,
  onClick,
}: {
  label: string;
  value: number;
  icon: typeof Loader2;
  color: string;
  selected?: boolean;
  onClick?: () => void;
}) {
  const interactive = !!onClick;
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={!interactive}
      aria-pressed={interactive ? selected : undefined}
      title={interactive ? `Show the ${label.toLowerCase()} resumes in the table below` : undefined}
      style={selected ? { borderColor: color, boxShadow: `0 0 0 1px ${color}` } : undefined}
      className={cn(
        "group flex items-center gap-3 rounded-xl border border-border bg-card px-4 py-3 text-left transition-colors",
        interactive && "cursor-pointer hover:border-primary/40 hover:bg-secondary/40",
        !interactive && "cursor-default",
      )}
    >
      <div
        className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl"
        style={{ backgroundColor: `${color}1a`, color }}
      >
        <Icon className="h-5 w-5" />
      </div>
      <div className="min-w-0 flex-1">
        <div className="text-xl font-bold leading-tight text-ink tnum">{value}</div>
        <div className="truncate text-[11px] font-medium uppercase tracking-wide text-ink-mute">
          {label}
        </div>
      </div>
      {interactive && (
        <ChevronRight
          className={cn(
            "h-4 w-4 shrink-0 transition-opacity",
            selected ? "opacity-90" : "opacity-0 group-hover:opacity-60",
          )}
          style={selected ? { color } : undefined}
        />
      )}
    </button>
  );
}

export default function IntakeMailMaster() {
  const { canAccessBackoffice } = useAuth();
  const [tab, setTab] = useState<Tab>("All");
  const [uploadOpen, setUploadOpen] = useState(false);
  const [sourceTagOpen, setSourceTagOpen] = useState(false);
  // Campaign-tools drawer (Interviewer Timeslot Pools + Batch Archive) —
  // closed by default; open/seen state sticks across visits so a recruiter
  // who works in it daily isn't re-hiding it every load, and the first-time
  // hint pulse stops once they've found it.
  const [toolsOpen, setToolsOpen] = useState(() => localStorage.getItem("intake-tools-open") === "1");
  const [toolsHintSeen, setToolsHintSeen] = useState(
    () => localStorage.getItem("intake-tools-seen") === "1",
  );
  const toggleTools = () => {
    setToolsOpen((v) => {
      const next = !v;
      localStorage.setItem("intake-tools-open", next ? "1" : "0");
      return next;
    });
    if (!toolsHintSeen) {
      localStorage.setItem("intake-tools-seen", "1");
      setToolsHintSeen(true);
    }
  };
  // Processing stats (filters + donut + outcome tiles) — collapsed by default
  // into a mini donut on the pipeline status bar; clicking it expands the full
  // section. Sticky like the drawer, so a recruiter who keeps it open stays so.
  const [statsOpen, setStatsOpen] = useState(() => localStorage.getItem("intake-stats-open") === "1");
  const toggleStats = () =>
    setStatsOpen((v) => {
      const next = !v;
      localStorage.setItem("intake-stats-open", next ? "1" : "0");
      return next;
    });
  // Needs Review is a subpage opened from a button (keeps the Mailbox short).
  const [showReview, setShowReview] = useState(false);
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  // Deep-link from the Dashboard aging report: ?aging=critical filters the table
  // to one bucket (over pending mail only — that's what the report counts).
  const [searchParams, setSearchParams] = useSearchParams();
  const agingFilter = searchParams.get("aging");
  const activeAging = isAgingBucket(agingFilter) ? agingFilter : null;
  const clearAging = () => {
    const next = new URLSearchParams(searchParams);
    next.delete("aging");
    setSearchParams(next, { replace: true });
  };

  const { data: emails = [], isLoading } = useQuery({
    queryKey: ["emails"],
    queryFn: async () => (await emailsService.list()).data,
  });

  // Registered "social post" source tags — the active one is what's currently
  // auto-stamped onto new Graph-mail resumes (see RegisterSourceTagModal).
  const { data: sourceTagsData } = useQuery({
    queryKey: ["source-tags"],
    queryFn: async () => (await sourceTagsService.list()).data,
  });
  const sourceTags = sourceTagsData?.tags ?? [];
  const activeSourceTagId = sourceTagsData?.active_id ?? null;
  const activeSourceTag = sourceTags.find((t) => t.id === activeSourceTagId) ?? null;

  // Shared with PipelinePanel (same query key) — tells us when a batch is actively
  // running so queued mail can render as "Processing" instead of "Queued".
  const { data: pipelineStatus } = useQuery({
    queryKey: ["pipeline-status"],
    queryFn: async () => (await pipelineService.status()).data,
  });
  const pipelineRunning = pipelineStatus?.running ?? false;

  // Backs both PipelineStatusBar (sticky, under the hero) and PipelineLastRun
  // (scrolls with the rest of the page) — split from one shared hook so they
  // stay in sync without duplicating any of the querying/mutation logic.
  const pipeline = usePipelineStatus();

  // Count of open review items — drives the "Needs Review" button badge (cached
  // with the ReviewQueue subpage's own query).
  const { data: reviewItems = [] } = useQuery({
    queryKey: ["review-queue"],
    queryFn: async () => (await reviewQueueService.list()).data,
  });
  const reviewCount = reviewItems.length;

  // Outlook folder counts (totalItemCount per folder) from Microsoft Graph. This call
  // is relatively slow (~1s), so it refreshes on page load and tab-focus (the query
  // defaults) rather than on a constant timer.
  const { data: folderCounts } = useQuery({
    queryKey: ["graph", "folder-counts"],
    queryFn: async () => (await graphService.folderCounts()).data,
  });

  // Source-tag / origin filters for the overview strip above — independent from the
  // Emails table's own filters below, since this card summarizes the whole mailbox.
  // The source filter DEFAULTS to the currently-active source tag once it loads
  // (so the mini donut/stats reflect the campaign being run right now) — but any
  // explicit pick by the user, including "All sources", wins from then on.
  const [statsSource, setStatsSource] = useState("");
  const [statsSourceTouched, setStatsSourceTouched] = useState(false);
  useEffect(() => {
    if (!statsSourceTouched && activeSourceTag?.label) setStatsSource(activeSourceTag.label);
  }, [activeSourceTag?.label, statsSourceTouched]);
  const [statsOrigin, setStatsOrigin] = useState<"all" | "mail" | "manual">("all");
  const statsFilterActive = !!statsSource || statsOrigin !== "all";

  // Drill-down: clicking an outcome card (or donut slice) filters the Emails
  // table below to exactly the mails that card counted, mirroring the stats
  // strip's own source/origin scope onto the table (`originFilter`). `null` =
  // no outcome drill active. `tableRef` lets a click scroll the table into view.
  const [outcomeFilter, setOutcomeFilter] = useState<SummaryKey | null>(null);
  const [originFilter, setOriginFilter] = useState<"all" | "mail" | "manual">("all");
  const tableRef = useRef<HTMLDivElement | null>(null);

  // Processing-outcome breakdown — derived from the app's own email history as a
  // FALLBACK for when Graph isn't configured. Counted at the RESUME level (via
  // fileAccounting — the same passed/failed split the table's per-row badge
  // uses), not one bucket per email: a single ZIP/batch upload can carry 25
  // resumes with a mix of outcomes, and counting it as "1 email" would make
  // a 98-resume batch look like it only ever processed a handful of items.
  // Also doubles as the filtered view when a source/origin filter is active, since
  // Graph's live folder counts are mailbox-wide and can't be sliced this way.
  const localSummary = useMemo<Record<SummaryKey, number>>(() => {
    const acc: Record<SummaryKey, number> = {
      processing: 0,
      processed: 0,
      failed: 0,
      nonResume: 0,
    };
    for (const e of emails) {
      if (statsSource && (e.source ?? "") !== statsSource) continue;
      if (statsOrigin !== "all") {
        const isManual = (e.sender_mail_id ?? "").trim().toLowerCase() === "direct";
        if (statsOrigin === "manual" && !isManual) continue;
        if (statsOrigin === "mail" && isManual) continue;
      }
      const fs = finalOf(e);
      if (fs === "Queued") {
        // Not extracted yet at all — every attachment is still "processing".
        acc.processing += fileAccounting(e).total || 1;
        continue;
      }
      if (fs === "Not a Resume") {
        acc.nonResume += 1;
        continue;
      }
      const { passed, failed } = fileAccounting(e);
      if (passed === 0 && failed === 0) {
        // A single-resume mail with no per-file breakdown recorded — fall
        // back to the mail's own overall verdict.
        if (fs === "Processed") acc.processed += 1;
        else acc.failed += 1;
      } else {
        acc.processed += passed;
        acc.failed += failed;
      }
    }
    return acc;
  }, [emails, statsSource, statsOrigin]);

  // Mirror the Outlook sidebar EXACTLY. Those per-folder badges are the UNREAD item
  // counts (`counts`), so the card reads them straight through — Processed/Non-Resume/
  // Failed match the mailbox number-for-number. We consult the full item counts
  // (`totals`) ONLY to decide whether Graph actually resolved the folders: that way,
  // when every mail has been read (all unread → 0, exactly like Outlook) we keep
  // showing 0 instead of wrongly falling back to the local history breakdown.
  const graphSummary: Record<SummaryKey, number> = {
    processing: folderCounts?.counts?.processing ?? 0,
    processed: folderCounts?.counts?.processed ?? 0,
    failed: folderCounts?.counts?.failed ?? 0,
    nonResume: folderCounts?.counts?.non_resume ?? 0,
  };
  const t = folderCounts?.totals;
  const graphResolvedTotal =
    (t?.processing ?? 0) + (t?.processed ?? 0) + (t?.failed ?? 0) + (t?.non_resume ?? 0);
  const fromGraph =
    !!folderCounts?.configured && !folderCounts.error && graphResolvedTotal > 0 && !statsFilterActive;
  const summary: Record<SummaryKey, number> = fromGraph ? graphSummary : localSummary;

  const summaryTotal = SUMMARY_META.reduce((n, m) => n + summary[m.key], 0);

  const donutData = SUMMARY_META.map((m) => ({
    name: m.label,
    value: summary[m.key],
    color: m.color,
  })).filter((d) => d.value > 0);

  // Distinct sources seen across every email, for the Source filter dropdown.
  const sourceOptions = useMemo(() => {
    const set = new Set<string>();
    emails.forEach((e) => { if (e.source) set.add(e.source); });
    return [...set].sort((a, b) => a.localeCompare(b));
  }, [emails]);

  const [search, setSearch] = useState("");
  const [sourceFilter, setSourceFilter] = useState("");
  const [sortKey, setSortKey] = useState<SortKey>("received");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("desc");
  const toggleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortKey(key);
      setSortDir(key === "received" || key === "aging" ? "desc" : "asc");
    }
  };

  const filtered = emails.filter((e) => {
    // Aging deep-link narrows to pending mail in the selected bucket.
    if (activeAging && !(e.is_pending && e.aging_bucket === activeAging)) return false;
    if (tab === "Processed" && emailBucket(e) !== "processed") return false;
    if (tab === "Needs Review" && emailBucket(e) !== "needs-review") return false;
    if (tab === "Resolved" && emailBucket(e) !== "resolved") return false;
    if (sourceFilter && (e.source ?? "") !== sourceFilter) return false;
    // Outcome drill-down (from clicking a processing-stat card/donut slice).
    if (outcomeFilter && !emailMatchesOutcome(e, outcomeFilter)) return false;
    if (originFilter !== "all") {
      const isManual = (e.sender_mail_id ?? "").trim().toLowerCase() === "direct";
      if (originFilter === "manual" && !isManual) return false;
      if (originFilter === "mail" && isManual) return false;
    }
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      const haystack = [e.E_id, e.sender_mail_id, e.subject, e.source]
        .filter(Boolean)
        .join(" ")
        .toLowerCase();
      if (!haystack.includes(q)) return false;
    }
    return true;
  });

  const sorted = useMemo(() => {
    const dir = sortDir === "asc" ? 1 : -1;
    return [...filtered].sort((a, b) => {
      switch (sortKey) {
        case "id": {
          const na = parseInt(a.E_id.replace(/\D/g, ""), 10) || 0;
          const nb = parseInt(b.E_id.replace(/\D/g, ""), 10) || 0;
          return (na - nb) * dir;
        }
        case "source":
          return (a.source ?? "").localeCompare(b.source ?? "") * dir;
        case "received": {
          const ta = a.received_date ? new Date(a.received_date).getTime() : 0;
          const tb = b.received_date ? new Date(b.received_date).getTime() : 0;
          return (ta - tb) * dir;
        }
        case "aging":
          return ((a.age_hours ?? 0) - (b.age_hours ?? 0)) * dir;
        case "status":
          return displayStatus(a).localeCompare(displayStatus(b)) * dir;
        default:
          return 0;
      }
    });
  }, [filtered, sortKey, sortDir]);

  const pg = usePagination(sorted, 20);

  const count = (pred: (e: EmailMaster) => boolean) => emails.filter(pred).length;
  // "Needs Review" sits before "Resolved": items live there until handled, then
  // move to Resolved once their open review items are resolved/discarded.
  const tabs: Tab[] = ["All", "Processed", "Needs Review", "Resolved"];
  const tabCounts: Record<Tab, number> = {
    All: emails.length,
    Processed: count((e) => emailBucket(e) === "processed"),
    "Needs Review": count((e) => emailBucket(e) === "needs-review"),
    Resolved: count((e) => emailBucket(e) === "resolved"),
  };

  // Click an outcome card/donut slice → drill the Emails table into just those
  // mails. Re-clicking the active card clears it (toggle). Opening a drill
  // carries the stats strip's own source/origin scope onto the table (so the
  // rows match the number just clicked) and resets the tab to All (the outcome
  // is orthogonal to the All/Processed/Review/Resolved tabs), then scrolls the
  // table into view. A zero-count card isn't clickable — nothing to show.
  const drillIntoOutcome = (key: SummaryKey) => {
    if (outcomeFilter === key) {
      setOutcomeFilter(null);
      return;
    }
    setOutcomeFilter(key);
    setSourceFilter(statsSource);
    setOriginFilter(statsOrigin);
    setTab("All");
    requestAnimationFrame(() =>
      tableRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }),
    );
  };
  const clearDrill = () => {
    setOutcomeFilter(null);
    setOriginFilter("all");
  };

  // Recruiter has no Mailbox access at all (server-side enforced too — every
  // /intake, /graph, /pipeline, /review-queue call 403s for that role). This
  // guard keeps the page from rendering a UI whose every call would fail, for
  // a Recruiter who lands here via a direct URL (the nav entry is already
  // hidden from the sidebar).
  if (!canAccessBackoffice) {
    return (
      <PageContainer>
        <PageHeader title="Mailbox" subtitle="Intake queue · pipeline runs · review" />
        <div className="flex flex-col items-center justify-center gap-3 rounded-2xl glass p-12 text-center">
          <ShieldAlert className="h-8 w-8 text-muted-foreground" />
          <p className="text-sm font-semibold text-foreground">Mailbox is restricted</p>
          <p className="max-w-sm text-xs text-muted-foreground">
            This section is only available to Admin and System Admin accounts.
          </p>
        </div>
      </PageContainer>
    );
  }

  // Needs Review subpage — opened from the button on the main Mailbox view.
  if (showReview) {
    return (
      <PageContainer>
        <button
          onClick={() => setShowReview(false)}
          className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="h-3.5 w-3.5" /> Back to Mailbox
        </button>
        <ReviewQueue />
      </PageContainer>
    );
  }

  // Mini donut on the pipeline status bar — the collapsed face of the stats
  // section below it. Click to expand/collapse the full filters + tiles view.
  const statsMiniDonut = (
    <button
      type="button"
      onClick={toggleStats}
      title={`Resume processing${statsSource ? ` — ${statsSource}` : ""} — ${summaryTotal} total. Click to ${statsOpen ? "collapse" : "expand"} the stats.`}
      aria-expanded={statsOpen}
      className="flex items-center gap-1 rounded-lg border border-border/60 bg-card/70 px-1.5 py-1 transition-colors hover:bg-secondary/60"
    >
      <div className="pointer-events-none h-8 w-8">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={donutData.length > 0 ? donutData : [{ name: "none", value: 1, color: "#e5e7eb" }]}
              dataKey="value"
              nameKey="name"
              innerRadius={9}
              outerRadius={15}
              paddingAngle={1}
              stroke="none"
              isAnimationActive={false}
            >
              {(donutData.length > 0 ? donutData : [{ name: "none", value: 1, color: "#e5e7eb" }]).map((d) => (
                <Cell key={d.name} fill={d.color} />
              ))}
            </Pie>
          </PieChart>
        </ResponsiveContainer>
      </div>
      <span className="tnum text-xs font-bold text-foreground">{summaryTotal}</span>
      <ChevronDown
        className={cn("h-3.5 w-3.5 text-muted-foreground transition-transform", !statsOpen && "-rotate-90")}
      />
    </button>
  );

  return (
    // A real split pane, not a sticky element riding along a page-wide scroll —
    // sticky was fine at rest but visibly "jerked" on first load as the queries
    // resolved and reflowed the page under it. The header below is simply
    // OUTSIDE the scrolling region now, so it never moves; only the dedicated
    // body pane (below) scrolls, in its own bounded area.
    <div className="flex h-full flex-col overflow-hidden">
      <div className="mx-auto w-full shrink-0 space-y-3 px-4 pt-4 sm:px-6">
        <PageHeader
          title="Mailbox"
          actions={
            <div className="flex items-center gap-2">
              {/* Archives & Interview Slots — a gear on the hero bar; the panel
                  expands out from under the hero when clicked (below). The
                  first-time pulse hints where these tools went for new users. */}
              <button
                type="button"
                onClick={toggleTools}
                title="Interview Time-slot Pools / Source tagged Archive-Restore-Prune-Clean / Base Email Templates / Mailbox Account — click to pull them out from under this bar."
                aria-expanded={toolsOpen}
                className={cn(
                  "relative inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border transition-colors",
                  toolsOpen
                    ? "border-primary/40 bg-primary/10 text-primary"
                    : "border-border bg-card text-muted-foreground hover:bg-secondary hover:text-foreground"
                )}
              >
                <SettingsGear className="h-4 w-4" />
                {!toolsHintSeen && (
                  <span className="absolute -right-0.5 -top-0.5 h-2 w-2 animate-pulse rounded-full bg-primary" />
                )}
              </button>
              <button
                onClick={() => setSourceTagOpen(true)}
                title={
                  activeSourceTag
                    ? `New email resumes are being tagged with "${activeSourceTag.label}" — click to manage`
                    : "No source tag is active — new email resumes won't be auto-tagged. Click to manage."
                }
                className={cn(
                  "inline-flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-semibold transition-colors",
                  activeSourceTag
                    ? "border-primary/30 bg-primary/5 text-primary hover:bg-primary/10"
                    : "border-border bg-secondary/40 text-muted-foreground hover:bg-secondary"
                )}
              >
                <Tag className="h-3.5 w-3.5" />
                <span className="max-w-[160px] truncate">
                  {activeSourceTag ? activeSourceTag.label : "No Source tagged"}
                </span>
              </button>
              <button
                onClick={() => setSourceTagOpen(true)}
                className="inline-flex shrink-0 items-center gap-1.5 rounded-lg border border-border bg-card px-3 py-2 text-xs font-semibold text-foreground transition-colors hover:border-primary/40 hover:bg-secondary"
              >
                <Tag className="h-3.5 w-3.5" />
                Register recent social post as a source tag
              </button>
              <button onClick={() => setUploadOpen(true)} className="btn-brand shrink-0">
                <UploadCloud className="h-4 w-4" />
                Upload resume(s)
              </button>
            </div>
          }
        />

        {/* Archives & Interview Slots — hidden entirely until the gear on the
            hero bar is clicked, then expands out from under the hero here. The
            header pane doesn't scroll, so the content gets its own bounded
            scroll and can never push the page controls off-screen. */}
        {toolsOpen && (
          <div className="surface overflow-hidden">
            <div className="flex items-center justify-between gap-2 border-b border-border/60 px-3 py-1.5">
              <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-foreground">
                <SettingsGear className="h-3.5 w-3.5 text-muted-foreground" />
                Interview Time-slot Pools / Source tagged Archive-Restore-Prune-Clean / Base Email
                Templates / Mailbox Account
              </span>
              <button
                type="button"
                onClick={toggleTools}
                title="Tuck back under the hero bar"
                className="rounded-lg p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
                aria-label="Close"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
            <div className="max-h-[55vh] space-y-3 overflow-y-auto p-3">
              {/* Proactively block interview placeholder slots on rostered interviewers'
                  calendars, sized to candidate volume per campaign source + round. */}
              <InterviewerPoolsPanel />

              {/* Archive/restore/prune resumes by source tag, and (Admin only) wipe the
                  database for a fresh QA reload. */}
              <BatchArchivePanel />

              {/* The base subject/body each generated email draft starts from —
                  per next-action type, editable (Admin), revert-able. */}
              <EmailTemplatesPanel />

              {/* Intake mailbox credentials (encrypted) + per-outcome folder
                  routing — warning-gated, SysAdmin re-auth to save. */}
              <MailboxAccountCard />
            </div>
          </div>
        )}

      {/* 1 — Resume Processing: pipeline run controls + live status merged with
          the outcome overview (donut + counts). One card, one set of numbers —
          the status row carries only Needs Review/Resolved (plus the Run
          button); Processing/Processed/Failed/Not-a-Resume live in the grid. */}
      <div className="surface overflow-hidden">
        <PipelineStatusBar
          pipeline={pipeline}
          needsReviewCount={reviewCount}
          statsToggle={statsMiniDonut}
          onNeedsReviewClick={() => setShowReview(true)}
          onResolvedClick={() => {
            setTab("Resolved");
            requestAnimationFrame(() =>
              tableRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }),
            );
          }}
        />
        {statsOpen && (
        <div className="border-t border-border p-4">
        <div className="mb-3 flex flex-wrap items-center gap-2">
          {fromGraph ? (
            // Live feed — highlight the heading itself rather than a muted side note.
            <h2 className="inline-flex items-center gap-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2.5 py-1 text-xs font-semibold text-emerald-600">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
              Live from Outlook
            </h2>
          ) : (
            <div>
              <h2 className="text-sm font-medium text-ink">Resume Processing</h2>
              <p className="text-[10px] text-ink-mute">From emails &amp; uploads</p>
            </div>
          )}
          <div className="ml-auto flex flex-wrap items-center gap-1.5">
            <select
              value={statsSource}
              onChange={(e) => {
                setStatsSourceTouched(true);
                setStatsSource(e.target.value);
              }}
              title="Filter by source tag"
              className="rounded-lg border border-border bg-background px-2 py-1 text-[11px] text-ink outline-none focus:border-primary/50"
            >
              <option value="">All sources</option>
              {/* Keep the active tag pickable/renderable even before any email
                  carries it — it's the default selection. */}
              {(statsSource && !sourceOptions.includes(statsSource)
                ? [statsSource, ...sourceOptions]
                : sourceOptions
              ).map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
            <div className="flex items-center rounded-lg border border-border bg-background p-0.5 text-[11px]">
              {(
                [
                  { key: "all", label: "Both" },
                  { key: "mail", label: "Email" },
                  { key: "manual", label: "Uploads" },
                ] as const
              ).map((o) => (
                <button
                  key={o.key}
                  type="button"
                  onClick={() => setStatsOrigin(o.key)}
                  className={cn(
                    "rounded-md px-2 py-0.5 font-medium transition-colors",
                    statsOrigin === o.key ? "bg-primary text-primary-foreground" : "text-ink-mute hover:text-ink"
                  )}
                >
                  {o.label}
                </button>
              ))}
            </div>
            {statsFilterActive && (
              <button
                type="button"
                onClick={() => { setStatsSourceTouched(true); setStatsSource(""); setStatsOrigin("all"); }}
                title="Clear filter"
                className="inline-flex items-center gap-1 rounded-lg px-1.5 py-1 text-ink-mute transition-colors hover:text-ink"
              >
                <X className="h-3 w-3" />
              </button>
            )}
            <span className="text-[11px] tnum text-ink-mute whitespace-nowrap">
              {summaryTotal} {fromGraph ? "total" : "resumes"}
            </span>
          </div>
        </div>
        <div className="grid gap-4 lg:grid-cols-[160px_1fr] lg:items-center">
          {/* Donut */}
          <div className="relative mx-auto h-[140px] w-[140px]">
            {donutData.length > 0 ? (
              <>
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={donutData}
                      dataKey="value"
                      nameKey="name"
                      innerRadius={46}
                      outerRadius={66}
                      paddingAngle={2}
                      stroke="none"
                      className="cursor-pointer outline-none"
                      onClick={(d: { name?: string; payload?: { name?: string } }) => {
                        const name = d?.name ?? d?.payload?.name;
                        const meta = SUMMARY_META.find((m) => m.label === name);
                        if (meta) drillIntoOutcome(meta.key);
                      }}
                    >
                      {donutData.map((d) => (
                        <Cell
                          key={d.name}
                          fill={d.color}
                          className="transition-opacity hover:opacity-80"
                        />
                      ))}
                    </Pie>
                    <Tooltip
                      // Pin the tooltip above the donut so it never sits on top of
                      // the centred total/"Emails" label (which clipped the text).
                      cursor={false}
                      position={{ y: -8 }}
                      allowEscapeViewBox={{ x: true, y: true }}
                      offset={0}
                      wrapperStyle={{ zIndex: 20, whiteSpace: "nowrap" }}
                      formatter={(value: number, name: string) => [`${value}`, name]}
                      contentStyle={{
                        borderRadius: 8,
                        border: "1px solid hsl(var(--border))",
                        background: "hsl(var(--background))",
                        color: "hsl(var(--foreground))",
                        fontSize: 12,
                        padding: "4px 8px",
                        whiteSpace: "nowrap",
                      }}
                      itemStyle={{ color: "hsl(var(--foreground))" }}
                      labelStyle={{ color: "hsl(var(--foreground))" }}
                    />
                  </PieChart>
                </ResponsiveContainer>
                <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-2xl font-bold text-ink tnum">{summaryTotal}</span>
                  <span className="text-[10px] uppercase tracking-wide text-ink-mute">
                    {fromGraph ? "Emails" : "Resumes"}
                  </span>
                </div>
              </>
            ) : (
              <div className="flex h-full items-center justify-center text-xs text-ink-mute">
                {isLoading ? "Loading…" : "No emails yet"}
              </div>
            )}
          </div>
          {/* Count cards */}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {SUMMARY_META.map((m) => (
              <SummaryCard
                key={m.key}
                label={m.label}
                value={summary[m.key]}
                icon={m.icon}
                color={m.color}
                selected={outcomeFilter === m.key}
                onClick={summary[m.key] > 0 ? () => drillIntoOutcome(m.key) : undefined}
              />
            ))}
          </div>
        </div>
        </div>
        )}
      </div>

      </div>

      <UploadResumeModal
        open={uploadOpen}
        onClose={() => setUploadOpen(false)}
        onUploaded={() => {
          queryClient.invalidateQueries({ queryKey: ["emails"] });
          queryClient.invalidateQueries({ queryKey: ["run-summary"] });
          queryClient.invalidateQueries({ queryKey: ["intake-pending"] });
        }}
      />

      <RegisterSourceTagModal
        open={sourceTagOpen}
        tags={sourceTags}
        activeId={activeSourceTagId}
        onClose={() => setSourceTagOpen(false)}
        onChanged={() => queryClient.invalidateQueries({ queryKey: ["source-tags"] })}
      />

      <div className="min-h-0 flex-1 overflow-y-auto">
      <div className="mx-auto w-full space-y-3 px-4 pb-4 pt-4 sm:px-6">

      {/* Last run result — scrolls with the rest of the page. */}
      <PipelineLastRun pipeline={pipeline} />

      {/* Manually uploaded files staged for the next run — review/discard before running. */}
      <UploadQueuePanel />

      {/* 2 — Needs Review: opens the actionable queue as a subpage */}
      <button
        onClick={() => setShowReview(true)}
        className={cn(
          "flex w-full items-center gap-3 rounded-xl border px-4 py-3 text-left transition-colors",
          reviewCount > 0
            ? "border-amber-500/30 bg-amber-400/5 hover:bg-amber-400/10"
            : "border-border bg-card hover:bg-secondary/50"
        )}
      >
        <div
          className={cn(
            "flex h-9 w-9 shrink-0 items-center justify-center rounded-xl",
            reviewCount > 0 ? "bg-amber-500/15 text-amber-500" : "bg-emerald-500/15 text-emerald-500"
          )}
        >
          {reviewCount > 0 ? <AlertTriangle className="h-5 w-5" /> : <CheckCircle2 className="h-5 w-5" />}
        </div>
        <div className="min-w-0 flex-1">
          <div className="text-sm font-semibold text-foreground">Needs Review</div>
          <div className="text-xs text-muted-foreground">
            {reviewCount > 0
              ? `${reviewCount} item${reviewCount === 1 ? "" : "s"} waiting — files & rows the pipeline couldn't auto-process`
              : "All clear — nothing waiting for review"}
          </div>
        </div>
        {reviewCount > 0 && (
          <span className="shrink-0 rounded-full border border-amber-500/30 bg-amber-400/10 px-2.5 py-0.5 text-xs font-bold text-amber-500">
            {reviewCount}
          </span>
        )}
        <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
      </button>

      {/* 3 — Incoming Email Queue (renders only when Outlook intake is configured) */}
      <OutlookIntakePanel />

      {/* 4 — Email history table */}
      <div ref={tableRef} className="surface overflow-hidden scroll-mt-4">
        <div className="flex flex-wrap items-center gap-x-3 gap-y-2 border-b border-border px-5 py-1.5">
          <h2 className="text-sm font-medium text-ink">Emails/Uploads</h2>
          <div className="flex items-center gap-1">
            {tabs.map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={cn(
                  "relative px-3 py-3 text-xs font-medium transition-colors",
                  tab === t ? "text-ink" : "text-ink-mute hover:text-ink"
                )}
              >
                {t}
                {tabCounts[t] > 0 && (
                  <span className="ml-1.5 rounded-full px-1.5 py-0.5 text-[10px] font-semibold bg-secondary text-ink-mute tnum">
                    {tabCounts[t]}
                  </span>
                )}
                {tab === t && (
                  <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary rounded-full" />
                )}
              </button>
            ))}
          </div>
          {activeAging && (
            <button
              onClick={clearAging}
              title="Clear aging filter"
              className={cn(
                "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium",
                AGING_PILL_CLS[activeAging]
              )}
            >
              {AGING_LABEL[activeAging]} pending mail ({AGING_RANGE[activeAging]})
              <X className="h-3 w-3" />
            </button>
          )}
          {outcomeFilter && (() => {
            const meta = SUMMARY_META.find((m) => m.key === outcomeFilter);
            if (!meta) return null;
            const originLabel =
              originFilter === "manual" ? " · Uploads" : originFilter === "mail" ? " · Email" : "";
            return (
              <button
                onClick={clearDrill}
                title="Clear outcome filter"
                style={{ color: meta.color, borderColor: `${meta.color}55`, backgroundColor: `${meta.color}14` }}
                className="inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium"
              >
                {meta.label} resumes{originLabel}
                <X className="h-3 w-3" />
              </button>
            );
          })()}
          {/* Search / source filter / count — share the tabs row (the space to
              its right was empty) instead of stacking inside the column-header
              row, which stretched it two rows tall. */}
          <div className="ml-auto flex flex-wrap items-center justify-end gap-2">
            <div className="relative w-[200px] max-w-full">
              <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-ink-mute" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search ID, sender, subject, source…"
                className="w-full rounded-lg border border-border bg-background py-1.5 pl-8 pr-2.5 text-xs text-ink outline-none focus:border-primary/50"
              />
            </div>
            <select
              value={sourceFilter}
              onChange={(e) => setSourceFilter(e.target.value)}
              className="rounded-lg border border-border bg-background px-2.5 py-1.5 text-xs text-ink outline-none focus:border-primary/50"
            >
              <option value="">All sources</option>
              {sourceOptions.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
            {(search || sourceFilter || outcomeFilter || originFilter !== "all") && (
              <button
                type="button"
                onClick={() => { setSearch(""); setSourceFilter(""); clearDrill(); }}
                className="inline-flex items-center gap-1 rounded-lg px-2 py-1.5 text-xs text-ink-mute transition-colors hover:text-ink"
              >
                <X className="h-3 w-3" /> Clear
              </button>
            )}
            <span className="text-[11px] tnum text-ink-mute whitespace-nowrap">
              {filtered.length} of {emails.length} email{emails.length === 1 ? "" : "s"}
            </span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-secondary">
                {(
                  [
                    { label: "ID", key: "id" },
                    { label: "Sender" },
                    { label: "Subject" },
                    { label: "Source", key: "source" },
                    { label: "Received", key: "received" },
                    { label: "Aging", key: "aging" },
                    { label: "Type" },
                    { label: "Status", key: "status" },
                  ] as { label: string; key?: SortKey }[]
                ).map((col) => (
                  <th
                    key={col.label || "actions"}
                    className="px-2.5 py-2 text-left text-[11px] font-medium uppercase tracking-wide text-ink-mute"
                  >
                    {col.key ? (
                      <button
                        type="button"
                        onClick={() => toggleSort(col.key!)}
                        className="inline-flex items-center gap-1 transition-colors hover:text-ink"
                      >
                        {col.label}
                        {sortKey === col.key ? (
                          sortDir === "asc" ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />
                        ) : (
                          <ArrowUpDown className="h-3 w-3 opacity-30" />
                        )}
                      </button>
                    ) : (
                      col.label
                    )}
                  </th>
                ))}
                <th className="px-2.5 py-2 text-left" />{/* actions column */}
              </tr>
            </thead>
            <tbody>
              {pg.pageItems.map((email) => {
                const received = formatReceived(email.received_date);
                return (
                  <tr
                    key={email.E_id}
                    className="border-b border-border hover:bg-secondary transition-colors"
                  >
                    <td className="px-2.5 py-2 text-xs font-mono text-primary tnum">{email.E_id}</td>
                    <td className="px-2.5 py-2 text-xs text-ink-mute max-w-[110px] truncate">
                      {email.sender_mail_id}
                    </td>
                    <td className="px-2.5 py-2 text-xs text-ink max-w-[180px]">
                      <span className="truncate block">{email.subject}</span>
                    </td>
                    <td className="px-2.5 py-2 text-xs text-ink-mute max-w-[110px] truncate" title={email.source ?? undefined}>
                      {email.source || "—"}
                    </td>
                    <td className="px-2.5 py-2 whitespace-nowrap">
                      <div className="text-xs text-ink tnum">{received.date}</div>
                      {received.time && (
                        <div className="text-[11px] text-ink-mute tnum">{received.time}</div>
                      )}
                    </td>
                    <td className="px-2.5 py-2">
                      <AgingBadge email={email} />
                    </td>
                    <td className="px-2.5 py-2">
                      <span className="text-xs text-ink-mute">{guessType(email)}</span>
                    </td>
                    <td className="px-2.5 py-2 max-w-[200px]">
                      {needsAccountingBreakdown(email) ? (
                        <FileAccountingBadge email={email} />
                      ) : (
                        <FinalStatusBadge
                          status={displayStatus(email)}
                          detail={
                            displayStatus(email) === "Failed"
                              ? failReason(email)
                              : email.final_detail
                          }
                          running={pipelineRunning}
                        />
                      )}
                    </td>
                    <td className="px-2.5 py-2">
                      {/* Any mail with something to inspect — a straight Failed
                          verdict, or a multi-file mail with failed/needs-review
                          items even though it also has files that passed. The
                          Audit link jumps straight to this mail's reason rows
                          in the Activity log either way. */}
                      {(displayStatus(email) === "Failed" || needsAccountingBreakdown(email)) && (
                        <button
                          onClick={() => navigate(`/audit-logs?email=${encodeURIComponent(email.E_id)}`)}
                          className="text-xs text-ink-mute hover:text-primary flex items-center gap-1 whitespace-nowrap transition-colors"
                        >
                          <ExternalLink className="h-3 w-3" /> Audit
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={9} className="px-4 py-12 text-center">
                    <Inbox className="h-6 w-6 text-ink-mute/50 mx-auto mb-2" />
                    <div className="text-sm text-ink-mute">
                      {isLoading ? "Loading…" : "No emails match this filter."}
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="px-5 py-3 border-t border-border">
          {isLoading ? (
            <span className="text-xs text-ink-mute">Loading…</span>
          ) : (
            <Pagination
              page={pg.page}
              pageCount={pg.pageCount}
              total={pg.total}
              pageSize={pg.pageSize}
              startIndex={pg.startIndex}
              onPage={pg.setPage}
              itemLabel="emails"
            />
          )}
        </div>
      </div>

      </div>
      </div>
    </div>
  );
}
