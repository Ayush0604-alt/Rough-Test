import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { isAxiosError } from "axios";
import { Eye, EyeOff, Loader2, Lock, Mail } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { cn } from "@/lib/utils";
import logo from "@/logo/neuleap_logo.png";

interface LocationState {
  from?: { pathname: string };
}

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  // Only a deep-link redirect (ProtectedRoute bounced them here from a specific
  // page) overrides the role default below — a plain visit to /login has no
  // `from`, so falls through to /dashboard (or /settings for System Admin, who
  // has no Dashboard access — see canAccessRecruiting).
  const from = (location.state as LocationState)?.from?.pathname;

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const nextUser = await login(email, password);
      navigate(from ?? (nextUser.role === "sysadmin" ? "/settings" : "/dashboard"), { replace: true });
    } catch (err) {
      if (isAxiosError(err)) {
        setError(
          err.response?.data?.detail ??
            (err.response
              ? "Invalid email or password."
              : "Can't reach the server. Try again.")
        );
      } else {
        setError("Unable to sign in.");
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-background px-4">
      {/* Signature ambient mesh wash behind the card. */}
      <div className="gradient-mesh pointer-events-none absolute inset-0 opacity-70" />

      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
        className="surface-float relative w-full max-w-sm p-8"
      >
        <div className="flex flex-col items-center text-center">
          <img
            src={logo}
            alt="Talents Scooper"
            className="h-12 w-12 rounded-xl object-cover"
          />
          <h1 className="mt-4 text-[22px] font-semibold tracking-[-0.02em] text-ink">
            Talents Scooper
          </h1>
          <p className="text-[11px] font-semibold uppercase tracking-[0.08em] text-primary">
            @NeuLeap.Ai
          </p>
          {/* Slogan — the emotional hook; the plain-English "what this does"
              lives in the footer tagline below the form instead, so the two
              never compete for the same line. */}
          <p className="mt-3 max-w-[260px] text-sm italic leading-snug text-ink-mute">
            "Send a post and watch the gates…"
          </p>
          <p className="mt-2 text-sm text-ink-mute">Sign in to continue</p>
        </div>

        <form onSubmit={onSubmit} className="mt-7 space-y-4">
          <div className="space-y-1.5">
            <label
              htmlFor="email"
              className="text-xs font-medium text-ink-mute"
            >
              Email
            </label>
            <div className="relative">
              <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-mute" />
              <input
                id="email"
                type="email"
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@company.com"
                className="w-full rounded-xl border border-border bg-secondary/40 py-2.5 pl-9 pr-3 text-sm text-ink outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/30"
                required
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label
              htmlFor="password"
              className="text-xs font-medium text-ink-mute"
            >
              Password
            </label>
            <div className="relative">
              <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-mute" />
              <input
                id="password"
                type={showPassword ? "text" : "password"}
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full rounded-xl border border-border bg-secondary/40 py-2.5 pl-9 pr-10 text-sm text-ink outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/30"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword((v) => !v)}
                aria-label={showPassword ? "Hide password" : "Show password"}
                className="absolute right-2 top-1/2 inline-flex h-7 w-7 -translate-y-1/2 items-center justify-center rounded-lg text-ink-mute transition-colors hover:bg-secondary hover:text-ink"
              >
                {showPassword ? (
                  <EyeOff className="h-4 w-4" />
                ) : (
                  <Eye className="h-4 w-4" />
                )}
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between text-xs">
            <label className="flex cursor-pointer items-center gap-2 text-ink-mute">
              <input
                type="checkbox"
                className="h-3.5 w-3.5 rounded border-border accent-primary"
              />
              Remember me
            </label>
            <button
              type="button"
              onClick={() => navigate("/forgot-password")}
              className="font-medium text-primary transition-colors hover:text-primary-deep"
            >
              Forgot password?
            </button>
          </div>

          {error && (
            <p className="rounded-lg bg-red-500/10 px-3 py-2 text-xs font-medium text-red-600 dark:text-red-400">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={submitting}
            className={cn("btn-brand w-full", submitting && "cursor-not-allowed")}
          >
            {submitting ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Signing in…
              </>
            ) : (
              "Sign in"
            )}
          </button>
        </form>

        <p className="mt-6 text-center text-xs leading-relaxed text-ink-mute">
          The Agentic AI solution to your professional talent hunt problem.
        </p>
      </motion.div>
    </div>
  );
}
