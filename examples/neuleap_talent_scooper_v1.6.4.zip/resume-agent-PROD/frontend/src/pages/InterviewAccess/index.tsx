import { useEffect, useMemo, useRef, useState } from "react";
import { RemarkBadge, StickyRemarkCard } from "@/components/candidate/CandidateNote";
import { useParams } from "react-router-dom";
import { motion } from "framer-motion";
import {
  AlertTriangle,
  Award,
  Briefcase,
  Check,
  CheckCircle2,
  ChevronDown,
  FileText,
  Gauge,
  GraduationCap,
  Info,
  KeyRound,
  Loader2,
  Mail,
  Quote,
  ShieldCheck,
  Sparkles,
  Copy,
  Library,
  Wand2,
  Lock,
  Lightbulb,
  X,
  XCircle,
} from "lucide-react";
import { cn, formatExperience, formatScore } from "@/lib/utils";
import { outcomeLabel } from "@/lib/badges";
import { parseCertificates, type CandidateMaster } from "@/types";
import AnalysisReportBody, { hasAnalysisReport } from "@/components/candidate/AnalysisReport";
import ScoreBreakdown, {
  NlrsBreakdown,
  ScorePopoverModal,
  hasNlrsBreakdown,
  hasScoreBreakdown,
} from "@/components/candidate/ScoreBreakdown";
import InterviewQuestionsPanel from "@/components/candidate/InterviewQuestionsPanel";
import { useConfirm } from "@/components/common/ConfirmProvider";
import RoundHistory from "@/components/candidate/detail/RoundHistory";
import type { Round as RoundType } from "@/types/rounds";
import ThemeToggle from "@/components/layout/ThemeToggle";
import { INTERVIEW_MODE_OPTIONS, type InterviewMode, type InterviewOptions } from "@/services/interview";
import logo from "@/logo/neuleap_logo.png";
import {
  InterviewerApiError,
  interviewerService,
  interviewerSession,
  type InterviewerCandidate,
  type InterviewerContextResponse,
  type InterviewerQuestion,
  type InterviewerRound,
  type QuestionAnswer,
  type SubmitFeedbackBody,
  type VerdictOption,
  type VerdictOptionsResponse,
  type AllocatedQuestionBank,
  type QBGatedBucket,
} from "@/services/interviewer";

type Screen = "loading" | "email" | "code" | "ready" | "invalid";

const toList = (v: string[] | string | null | undefined): string[] => {
  if (Array.isArray(v)) return v.filter((x): x is string => typeof x === "string" && !!x);
  if (typeof v === "string" && v.trim()) return v.split(/[·,]/).map((s) => s.trim()).filter(Boolean);
  return [];
};

// job_roles arrives as either structured {role, company, months}[] or a flat
// string[]/joined string (legacy) — normalize to a display-ready label list.
const jobRoleLabels = (v: CandidateMaster["job_roles"]): string[] => {
  if (Array.isArray(v)) {
    return v
      .map((r) =>
        typeof r === "string"
          ? r
          : [r.role, r.company].filter(Boolean).join(" · ")
      )
      .filter(Boolean);
  }
  return toList(v as string | string[] | null | undefined);
};

function AuthShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-background px-4">
      <div className="gradient-mesh pointer-events-none absolute inset-0 opacity-70" />
      <div className="absolute right-4 top-4 z-10">
        <ThemeToggle />
      </div>
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
        className="surface-float relative w-full max-w-sm p-8"
      >
        <div className="mb-6 flex flex-col items-center text-center">
          <img src={logo} alt="Talents Scooper" className="h-11 w-11 rounded-xl object-cover" />
          <h1 className="mt-3 text-lg font-semibold tracking-[-0.02em] text-ink">Interviewer Access</h1>
          <p className="text-[11px] font-semibold uppercase tracking-[0.08em] text-primary">@NeuLeap.Ai</p>
        </div>
        {children}
      </motion.div>
    </div>
  );
}

export default function InterviewAccess() {
  const { token } = useParams<{ token: string }>();
  const [screen, setScreen] = useState<Screen>("loading");
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const [email, setEmail] = useState("");
  const [codeRaw, setCodeRaw] = useState("");
  const [remember, setRemember] = useState(false);
  const [busy, setBusy] = useState(false);

  const [sessionToken, setSessionToken] = useState<string | null>(null);
  const [candidate, setCandidate] = useState<InterviewerCandidate | null>(null);
  const [roundId, setRoundId] = useState<number | null>(null);
  const [rounds, setRounds] = useState<InterviewerRound[]>([]);

  const codeDisplay = codeRaw.length > 3 ? `${codeRaw.slice(0, 3)}-${codeRaw.slice(3)}` : codeRaw;

  // On mount: if a session for this link is already remembered, try it before
  // showing the challenge at all.
  useEffect(() => {
    if (!token) return;
    const existing = interviewerSession.get(token);
    if (!existing) {
      setScreen("email");
      return;
    }
    interviewerService
      .getContext(token, existing)
      .then((ctx) => {
        setSessionToken(existing);
        applyContext(ctx);
        setScreen("ready");
      })
      .catch((e) => {
        interviewerSession.clear(token);
        if (e instanceof InterviewerApiError && e.status === 404) {
          setErrorMsg(e.message);
          setScreen("invalid");
        } else {
          setScreen("email");
        }
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token]);

  function applyContext(ctx: InterviewerContextResponse | { candidate: InterviewerCandidate; round_id: number | null; rounds: InterviewerRound[] }) {
    setCandidate(ctx.candidate);
    setRoundId(ctx.round_id);
    setRounds(ctx.rounds);
  }

  const requestCode = async () => {
    if (!token || !email.trim()) return;
    setBusy(true);
    setErrorMsg(null);
    try {
      await interviewerService.requestCode(token, email.trim());
      setScreen("code");
    } catch (e) {
      setErrorMsg(e instanceof InterviewerApiError ? e.message : "Couldn't send the code. Try again.");
    } finally {
      setBusy(false);
    }
  };

  const verifyCode = async () => {
    if (!token || codeRaw.length < 6) return;
    setBusy(true);
    setErrorMsg(null);
    try {
      const res = await interviewerService.verifyCode(token, email.trim(), codeDisplay, remember);
      if (res.session_token) {
        setSessionToken(res.session_token);
        if (remember) interviewerSession.set(token, res.session_token);
      }
      applyContext(res);
      setScreen("ready");
    } catch (e) {
      setErrorMsg(e instanceof InterviewerApiError ? e.message : "Verification failed.");
    } finally {
      setBusy(false);
    }
  };

  if (screen === "loading") {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (screen === "invalid") {
    return (
      <AuthShell>
        <div className="flex flex-col items-center gap-2 text-center">
          <AlertTriangle className="h-8 w-8 text-amber-500" />
          <p className="text-sm font-semibold text-ink">This link isn't valid</p>
          <p className="text-xs text-ink-mute">{errorMsg ?? "It may have been revoked or malformed."}</p>
        </div>
      </AuthShell>
    );
  }

  if (screen === "email") {
    return (
      <AuthShell>
        <p className="mb-4 text-center text-xs text-ink-mute">
          Enter your work email to request an access code for this interview.
        </p>
        <div className="space-y-3">
          <div className="relative">
            <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-mute" />
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && requestCode()}
              placeholder="you@neuleap.ai"
              className="w-full rounded-xl border border-border bg-secondary/40 py-2.5 pl-9 pr-3 text-sm text-ink outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/30"
            />
          </div>
          {errorMsg && <p className="rounded-lg bg-red-500/10 px-3 py-2 text-xs font-medium text-red-500">{errorMsg}</p>}
          <button
            onClick={requestCode}
            disabled={busy || !email.trim()}
            className="btn-brand w-full disabled:cursor-not-allowed disabled:opacity-60"
          >
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Request code"}
          </button>
        </div>
      </AuthShell>
    );
  }

  if (screen === "code") {
    return (
      <AuthShell>
        <p className="mb-4 text-center text-xs text-ink-mute">
          We sent a 6-character code to <span className="font-medium text-ink">{email}</span>. It expires in 10 minutes.
        </p>
        <div className="space-y-3">
          <div className="relative">
            <KeyRound className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-mute" />
            <input
              value={codeDisplay}
              onChange={(e) => setCodeRaw(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 6))}
              onKeyDown={(e) => e.key === "Enter" && verifyCode()}
              placeholder="XXX-XXX"
              maxLength={7}
              className="w-full rounded-xl border border-border bg-secondary/40 py-2.5 pl-9 pr-3 text-center text-sm font-semibold tracking-[0.2em] text-ink outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/30"
            />
          </div>
          <label className="flex cursor-pointer items-center gap-2 text-xs text-ink-mute">
            <input
              type="checkbox"
              checked={remember}
              onChange={(e) => setRemember(e.target.checked)}
              className="h-3.5 w-3.5 rounded border-border accent-primary"
            />
            Remember this device
          </label>
          {errorMsg && <p className="rounded-lg bg-red-500/10 px-3 py-2 text-xs font-medium text-red-500">{errorMsg}</p>}
          <button
            onClick={verifyCode}
            disabled={busy || codeRaw.length < 6}
            className="btn-brand w-full disabled:cursor-not-allowed disabled:opacity-60"
          >
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Verify"}
          </button>
          <button
            onClick={() => { setScreen("email"); setCodeRaw(""); setErrorMsg(null); }}
            className="w-full text-center text-[11px] text-muted-foreground hover:text-foreground"
          >
            Use a different email
          </button>
        </div>
      </AuthShell>
    );
  }

  if (!token || !candidate) return null;

  return (
    <CandidateView
      token={token}
      sessionToken={sessionToken!}
      candidate={candidate}
      roundId={roundId}
      rounds={rounds}
      onRoundUpdated={(updated) =>
        setRounds((prev) => prev.map((r) => (r.round_id === updated.round_id ? { ...r, ...updated } : r)))
      }
    />
  );
}

// ── The read-only candidate view + the one round's feedback/verdict form ────

function Field({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div>
      <div className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className="text-sm text-foreground">{value ?? "—"}</div>
    </div>
  );
}

function Section({ icon: Icon, title, children }: { icon: React.ElementType; title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <div className="mb-4 flex items-center gap-2">
        <Icon className="h-4 w-4 text-muted-foreground" />
        <h2 className="text-sm font-semibold text-foreground">{title}</h2>
      </div>
      {children}
    </div>
  );
}

// Round 1+ verdict picker's per-option button — "advance" (Move to X / Hire on
// Final) reads as a positive/forward action, "reject" as a stop, and the two
// Admin-only bypasses get a stronger, more deliberate-looking treatment since
// they skip whatever rounds remain.
function VerdictButton({
  option,
  selected,
  onSelect,
  className,
}: {
  option: VerdictOption;
  selected: VerdictOption | null;
  onSelect: (o: VerdictOption) => void;
  className?: string;
}) {
  const isSelected = selected?.key === option.key && selected?.target === option.target;
  const tone =
    option.key === "advance"
      ? "emerald"
      : option.key === "hire" || option.key === "direct_hire"
        ? "blue"
        : "rose";
  const toneCls: Record<string, string> = {
    emerald: "border-emerald-500/50 bg-emerald-500/10 text-emerald-600",
    blue: "border-blue-500/50 bg-blue-500/10 text-blue-600",
    rose: "border-rose-500/50 bg-rose-500/10 text-rose-600",
  };
  const Icon = option.key === "advance" || option.key === "hire" ? Check : XCircle;
  return (
    <button
      onClick={() => onSelect(option)}
      className={cn(
        "flex items-center justify-center gap-1.5 rounded-lg border py-2 text-xs font-semibold transition-colors",
        isSelected ? toneCls[tone] : "border-border text-muted-foreground hover:text-foreground",
        className
      )}
    >
      <Icon className="h-3.5 w-3.5" /> {option.label}
    </button>
  );
}

function CandidateView({
  token,
  sessionToken,
  candidate: c,
  roundId,
  rounds,
  onRoundUpdated,
}: {
  token: string;
  sessionToken: string;
  candidate: InterviewerCandidate;
  roundId: number | null;
  rounds: InterviewerRound[];
  onRoundUpdated: (round: InterviewerRound) => void;
}) {
  const activeRound = useMemo(() => rounds.find((r) => r.round_id === roundId) ?? null, [rounds, roundId]);
  const alreadyDecided = !!activeRound && !!activeRound.outcome && activeRound.outcome !== "Pending";

  // The presentational score-breakdown/analysis-report components are shared
  // with the recruiter pages and typed against the full CandidateMaster shape,
  // but each only reads the handful of fields also present on the interviewer's
  // narrower payload (verified against _INTERVIEWER_FIELDS in app/api/interviewer.py)
  // — reusing them here avoids re-implementing the same bars/numbered-list UI.
  const cm = c as unknown as CandidateMaster;

  const [resumeUrl, setResumeUrl] = useState<string | null>(null);
  const [resumeLoading, setResumeLoading] = useState(false);
  const [atsOpen, setAtsOpen] = useState(false);
  const [nlrsOpen, setNlrsOpen] = useState(false);
  const [questionsOpen, setQuestionsOpen] = useState(false);
  // When a question bank is ALLOCATED for this candidate's round, the interviewer
  // marks THOSE questions (in the feedback sheet) — the free-form "Generate
  // Interview Questions" generator is hidden so they don't produce a different set.
  const [hasAllocatedQB, setHasAllocatedQB] = useState(false);
  useEffect(() => {
    interviewerService
      .getQuestionBank(token, sessionToken)
      .then((r) => setHasAllocatedQB(!!r.allocation))
      .catch(() => setHasAllocatedQB(false));
  }, [token, sessionToken]);
  // Questions the interviewer explicitly pulled in from the rich generator via
  // "Add to feedback sheet" — appended (never replacing) the feedback form's
  // own auto-fetched baseline, so the candidate's actual response can be
  // recorded against the exact question that was asked.
  const [extraFeedbackQuestions, setExtraFeedbackQuestions] = useState<{ bucket: string; question: string }[]>([]);
  // Extra aptitude modes layered onto "Generate Interview Questions" — same
  // dropdown as the recruiter's Candidate page, picked before the panel opens.
  const [interviewModes, setInterviewModes] = useState<Set<string>>(new Set());
  const [modesOpen, setModesOpen] = useState(false);
  const modesRef = useRef<HTMLDivElement>(null);
  // Config-driven modes (incl. custom types) — same source the recruiter view
  // uses, so the dropdown matches. Falls back to the built-in list until loaded.
  const [modeOptions, setModeOptions] = useState<{ key: string; label: string }[]>(INTERVIEW_MODE_OPTIONS);
  useEffect(() => {
    interviewerService
      .getInterviewModes()
      .then((ms) => {
        if (ms.length) setModeOptions(ms.map((m) => ({ key: m.key, label: m.label })));
      })
      .catch(() => {});
  }, []);
  useEffect(() => {
    if (!modesOpen) return;
    const onDown = (e: MouseEvent) => {
      if (modesRef.current && !modesRef.current.contains(e.target as Node)) setModesOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [modesOpen]);

  const openResume = () => {
    // Open the tab SYNCHRONOUSLY, inside the click handler's own gesture —
    // fetching the blob first and calling window.open() only after the
    // `await` resolves loses that gesture context and gets silently blocked
    // by the browser's popup blocker. Deliberately no "noopener" here: when
    // set, window.open() always returns null (that's the point of noopener —
    // no reference back), which left the tab permanently blank because there
    // was no handle left to navigate once the fetch resolved. Safe to omit —
    // this tab is only ever pointed at a blob: URL we create ourselves, never
    // an external/attacker-controlled address.
    const win = window.open("", "_blank");
    if (resumeUrl) {
      if (win) win.location.href = resumeUrl;
      return;
    }
    setResumeLoading(true);
    interviewerService
      .fetchResumeBlobUrl(token, sessionToken)
      .then((url) => {
        setResumeUrl(url);
        if (win) win.location.href = url;
        else window.open(url, "_blank"); // window.open was blocked outright — last-ditch retry
      })
      .catch(() => {
        if (win) win.close();
      })
      .finally(() => setResumeLoading(false));
  };

  const certificates = parseCertificates(cm.certificates);
  const jobRoles = jobRoleLabels(cm.job_roles);

  return (
    <div className="min-h-screen bg-background px-4 py-8">
      <div className="mx-auto flex max-w-3xl flex-col gap-4">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <img src={logo} alt="Talents Scooper" className="h-8 w-8 rounded-lg object-cover" />
            <div>
              <p className="text-[10px] font-semibold uppercase tracking-[0.08em] text-primary">Interviewer Access</p>
              <h1 className="flex items-center gap-1.5 text-lg font-semibold text-foreground">
                {c.name ?? c.candidate_id}
                <RemarkBadge remark={c.latest_remark} />
              </h1>
            </div>
          </div>
          <div className="flex shrink-0 items-center gap-1.5">
          <ThemeToggle />
          {/* No questions to prepare once this round's verdict is submitted, and
              hidden entirely when a question bank is allocated (mark those instead). */}
          {!alreadyDecided && !hasAllocatedQB && (
          <div ref={modesRef} className="relative flex shrink-0">
            <button
              onClick={() => setQuestionsOpen(true)}
              className="flex items-center gap-1.5 rounded-l-lg border border-r-0 border-primary/30 bg-primary/10 px-2.5 py-1.5 text-xs font-semibold text-primary transition-colors hover:bg-primary/20"
            >
              <Sparkles className="h-3.5 w-3.5" />
              Generate Interview Questions
              {interviewModes.size > 0 && (
                <span className="rounded-full bg-primary/20 px-1.5 text-[10px] font-bold leading-4">
                  +{interviewModes.size}
                </span>
              )}
            </button>
            <button
              type="button"
              onClick={() => setModesOpen((o) => !o)}
              title="Add aptitude question modes"
              className="flex items-center justify-center rounded-r-lg border border-primary/30 bg-primary/10 px-2 text-primary transition-colors hover:bg-primary/20"
            >
              <ChevronDown className={cn("h-3.5 w-3.5 transition-transform", modesOpen && "rotate-180")} />
            </button>
            {modesOpen && (
              <div className="absolute right-0 top-full z-40 mt-1.5 w-80 rounded-xl border border-border bg-card p-1.5 shadow-lg">
                <div className="px-2 py-1 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                  Combine with question modes
                </div>
                {modeOptions.map((opt) => {
                  const active = interviewModes.has(opt.key);
                  return (
                    <button
                      key={opt.key}
                      type="button"
                      onClick={() =>
                        setInterviewModes((prev) => {
                          const next = new Set(prev);
                          if (next.has(opt.key)) next.delete(opt.key);
                          else next.add(opt.key);
                          return next;
                        })
                      }
                      className="flex w-full items-start gap-2 rounded-lg px-2 py-1.5 text-left text-xs text-foreground hover:bg-secondary"
                    >
                      <span
                        className={cn(
                          "mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded border transition-colors",
                          active ? "border-primary bg-primary text-white" : "border-border"
                        )}
                      >
                        {active && <Check className="h-3 w-3" />}
                      </span>
                      {opt.label}
                    </button>
                  );
                })}
                {interviewModes.size > 0 && (
                  <button
                    type="button"
                    onClick={() => setInterviewModes(new Set())}
                    className="mt-1 flex w-full items-center justify-between rounded-lg px-2 py-1 text-left text-[11px] font-medium text-muted-foreground hover:bg-secondary hover:text-foreground"
                  >
                    Clear selection
                    <X className="h-3 w-3" />
                  </button>
                )}
              </div>
            )}
          </div>
          )}
          </div>
        </div>

        {c.latest_remark?.text && (
          <div className="flex justify-start">
            <StickyRemarkCard remark={c.latest_remark} readOnly />
          </div>
        )}

        <Section icon={Briefcase} title="Candidate summary">
          <div className="grid grid-cols-2 gap-x-4 gap-y-3 sm:grid-cols-3">
            <Field label="Stream" value={c.stream} />
            <Field label="Domain" value={c.domain} />
            <Field
              label="Experience"
              value={c.fresher_or_lateral === "Fresher" ? "Fresher" : c.yearofexp != null ? formatExperience(c.yearofexp) : null}
            />
            <Field label="Current company" value={c.currentcompany} />
            <Field label="Location" value={c.currentlocation} />
            <div>
              <div className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">ATS score</div>
              {hasScoreBreakdown(cm) ? (
                <button
                  type="button"
                  onClick={() => setAtsOpen(true)}
                  title="Show ATS score breakdown"
                  className="text-sm font-semibold text-foreground underline decoration-dotted underline-offset-2 transition-colors hover:text-primary"
                >
                  {formatScore(c.atsscore)}
                </button>
              ) : (
                <div className="text-sm text-foreground">{formatScore(c.atsscore)}</div>
              )}
            </div>
            <div>
              <div className="flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                <Gauge className="h-3 w-3" /> NLRS
              </div>
              {hasNlrsBreakdown(cm) ? (
                <button
                  type="button"
                  onClick={() => setNlrsOpen(true)}
                  title="Show NLRS score breakdown"
                  className="text-sm font-semibold text-foreground underline decoration-dotted underline-offset-2 transition-colors hover:text-primary"
                >
                  {formatScore(cm.nlrs?.score)}
                </button>
              ) : (
                <div className="text-sm text-foreground">{formatScore(cm.nlrs?.score)}</div>
              )}
            </div>
          </div>
          {c.has_resume && (
            <button
              onClick={openResume}
              disabled={resumeLoading}
              className="mt-4 inline-flex items-center gap-1.5 rounded-lg border border-border px-2.5 py-1.5 text-xs font-medium text-muted-foreground transition-colors hover:border-primary/40 hover:text-foreground disabled:opacity-50"
            >
              {resumeLoading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <FileText className="h-3.5 w-3.5" />}
              View resume
            </button>
          )}
        </Section>

        {c.role_context && (
          <Section icon={Quote} title="One-Line Summary">
            <p className="break-words text-sm leading-relaxed text-foreground">{c.role_context}</p>
          </Section>
        )}

        <Section icon={GraduationCap} title="Experience & Education">
          <div className="grid grid-cols-2 gap-x-4 gap-y-3 sm:grid-cols-3">
            <Field label="College" value={c.clg} />
            <Field
              label="Highest degree"
              value={c.highest_coursecompleted ? `${c.highest_coursecompleted}${c.education_status ? ` (${c.education_status})` : ""}` : null}
            />
            <Field label={c.education_status === "pursuing" ? "Expected passout" : "Passout year"} value={c.passoutyr} />
            <Field label="CGPA" value={c.cgpa != null ? c.cgpa.toFixed(1) : null} />
          </div>
          {jobRoles.length > 0 && (
            <div className="mt-3">
              <div className="mb-1.5 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Company history</div>
              <div className="space-y-1">
                {jobRoles.map((role, i) => (
                  <div key={i} className="flex items-center gap-2 text-sm text-foreground">
                    <Briefcase className="h-3 w-3 shrink-0 text-muted-foreground" />
                    {role}
                  </div>
                ))}
              </div>
            </div>
          )}
        </Section>

        {toList(c.primary_skills).length > 0 && (
          <Section icon={Award} title="Skills">
            <div className="flex flex-wrap gap-1.5">
              {toList(c.primary_skills).map((s) => (
                <span key={s} className="rounded-full border border-border bg-secondary px-2 py-0.5 text-[11px] text-foreground">{s}</span>
              ))}
            </div>
          </Section>
        )}

        {certificates.length > 0 && (
          <Section icon={Award} title="Certificates">
            <div className="space-y-1.5">
              {certificates.map((cert, i) => (
                <div key={i} className="flex flex-wrap items-baseline gap-x-1.5 text-sm">
                  <span className="font-medium text-foreground">{cert.name}</span>
                  {cert.issuer && <span className="text-xs text-muted-foreground">· {cert.issuer}</span>}
                  {cert.year && <span className="text-xs text-muted-foreground">· {cert.year}</span>}
                </div>
              ))}
            </div>
          </Section>
        )}

        {toList(c.projects).length > 0 && (
          <Section icon={Briefcase} title="Projects">
            <ul className="list-inside list-disc space-y-1 text-sm text-foreground">
              {toList(c.projects).map((s) => <li key={s}>{s}</li>)}
            </ul>
          </Section>
        )}

        {hasAnalysisReport(cm) && (
          <Section icon={FileText} title="Analysis Report">
            <AnalysisReportBody c={cm} />
          </Section>
        )}

        <Section icon={ShieldCheck} title="Round history">
          {/* The SAME card layout the internal candidate page shows (shared
              RoundHistory component) — including merged "Fast-tracked" cards
              with the recorded promotion reason wherever rounds were skipped.
              Compensation fields simply aren't in the interviewer payload, so
              those rows don't render here. */}
          <RoundHistory
            rounds={rounds.map((r) => ({
              round_id: r.round_id,
              candidate_id: c.candidate_id,
              round_name: r.round_name as RoundType["round_name"],
              domain: r.domain ?? "",
              interviewer: r.interviewer ?? "",
              current_ctc: null,
              expected_ctc: null,
              notice_period: null,
              relocation: null,
              scheduled_on: r.scheduled_on,
              feedback: r.feedback,
              score: r.score,
              outcome: (r.outcome as RoundType["outcome"]) ?? null,
            }))}
            role={c.stream}
            activeRoundId={roundId}
          />
        </Section>

        {roundId != null && activeRound && (
          alreadyDecided ? (
            <Section icon={CheckCircle2} title={`${activeRound.round_name} — verdict recorded`}>
              <p className="text-xs text-muted-foreground">
                A verdict was already submitted for this round (
                <span className="font-semibold text-foreground">{outcomeLabel(activeRound.outcome)}</span>
                ) — no further action is needed.
              </p>
            </Section>
          ) : (
            <FeedbackForm
              token={token}
              sessionToken={sessionToken}
              round={activeRound}
              extraQuestions={extraFeedbackQuestions}
              onSubmitted={onRoundUpdated}
            />
          )
        )}

        <p className="pb-4 text-center text-[11px] text-muted-foreground">
          This view is read-only except for the interview feedback below. It refreshes each visit.
        </p>
      </div>

      {atsOpen && (
        <ScorePopoverModal candidate={cm} subtitle="Why this ATS score" onClose={() => setAtsOpen(false)}>
          <ScoreBreakdown c={cm} />
        </ScorePopoverModal>
      )}
      {nlrsOpen && (
        <ScorePopoverModal candidate={cm} subtitle="Why this NLRS score" onClose={() => setNlrsOpen(false)}>
          <NlrsBreakdown c={cm} />
        </ScorePopoverModal>
      )}
      <InterviewQuestionsPanel
        open={questionsOpen}
        candidateId={c.candidate_id}
        onClose={() => setQuestionsOpen(false)}
        initialOptions={{ modes: [...interviewModes] as InterviewMode[] }}
        fetchFn={(opts: InterviewOptions) => interviewerService.generateQuestions(token, sessionToken, opts)}
        onUseQuestions={(qs) => setExtraFeedbackQuestions((prev) => [...prev, ...qs])}
      />
    </div>
  );
}

// The 0→10 score scale as faces — one emoji per point, worst to best. Clicking
// the selected one again clears the (optional) score.
const SCORE_EMOJIS = ["😵", "😫", "😞", "😕", "😐", "🙂", "😊", "😃", "😁", "🤩", "🏆"];

type QbCellT = { response: string; observation: string; ai_mark: number | null; final_mark: number | null; rationale: string; awarded: number[] };

// The interviewer's answering surface when a question bank is allocated to this
// round — used INSTEAD of generating a kit. Each question is copiable (paste to
// the candidate over Teams), with a response, an optional observation, and a
// mark; "Suggest marks (AI)" pre-fills a score per response that can be overridden.
function QuestionBankAnswerBlock({
  bankName,
  buckets,
  resp,
  setField,
  togglePoint,
  onCopy,
  copiedIdx,
  marking,
  onAiMark,
  locking,
  onLockAnswer,
  onLockMark,
}: {
  bankName: string;
  buckets: QBGatedBucket[];
  resp: Record<number, QbCellT>;
  setField: (i: number, patch: Partial<QbCellT>) => void;
  togglePoint: (i: number, pointIdx: number, points: { point: string; marks: number }[]) => void;
  onCopy: (i: number, text: string) => void;
  copiedIdx: number | null;
  marking: boolean;
  onAiMark: () => void;
  locking: { index: number; kind: "answer" | "mark" } | null;
  onLockAnswer: (index: number) => void;
  onLockMark: (index: number) => void;
}) {
  // Per-question "Show hint" toggles — hints are available BEFORE locking (a
  // probing aid); the model answer + rubric still stay hidden until the lock.
  const [hintsShown, setHintsShown] = useState<Set<number>>(new Set());
  const toggleHint = (i: number) =>
    setHintsShown((prev) => {
      const next = new Set(prev);
      if (next.has(i)) next.delete(i);
      else next.add(i);
      return next;
    });
  const flat = buckets.flatMap((b) => b.questions);
  // Marks arrive from Postgres NUMERIC columns — coerce defensively so a stray
  // string (Decimal serialized as text) can never break the arithmetic below.
  const outOf = flat.reduce((s, q) => s + (Number(q.max_mark) || 10), 0);
  const total = flat.reduce(
    (s, q) => s + (q.mark_locked ? Number(resp[q.index]?.final_mark ?? 0) || 0 : 0),
    0,
  );
  const fmtTotal = total % 1 === 0 ? total : total.toFixed(1);
  const anyMarking = flat.some((q) => q.answer_locked && !q.mark_locked);
  const anyResponses = flat.some((q) => (resp[q.index]?.response ?? "").trim());
  const allDone = flat.length > 0 && flat.every((q) => q.mark_locked);
  return (
    <div className="mb-4 space-y-2.5">
      <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-emerald-500/30 bg-emerald-500/5 px-3 py-2">
        <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-700 dark:text-emerald-400">
          <Library className="h-3.5 w-3.5" /> Question bank: {bankName}
          <span className="font-normal text-muted-foreground">· {flat.length} questions</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1 text-[11px] font-semibold tabular-nums text-foreground">
            {allDone && <ShieldCheck className="h-3.5 w-3.5 text-emerald-600" />}
            Total {fmtTotal}/{outOf}
          </span>
          {anyMarking && (
            <button
              type="button"
              onClick={onAiMark}
              disabled={marking || !anyResponses}
              title="Suggest a mark per answered question — override by ticking rubric points"
              className="inline-flex items-center gap-1 rounded-lg border border-primary/40 bg-primary/5 px-2 py-1 text-[11px] font-semibold text-primary hover:bg-primary/10 disabled:opacity-40"
            >
              {marking ? <Loader2 className="h-3 w-3 animate-spin" /> : <Wand2 className="h-3 w-3" />}
              Suggest marks (AI)
            </button>
          )}
        </div>
      </div>
      <p className="flex items-start gap-1.5 text-[11px] text-muted-foreground">
        <Info className="mt-0.5 h-3 w-3 shrink-0 text-primary" />
        Per question: paste the candidate's answer, then <b>Lock response</b> to reveal that question's
        model answer + rubric (hidden until you do, so you record what they actually said). Tick the
        rubric, then <b>Lock mark</b> to reveal its explanation. Each question is independent.
      </p>
      {buckets.map((b) => (
        <div key={b.name}>
          <div className="mb-1 mt-2 text-[10px] font-bold uppercase tracking-wider text-muted-foreground">{b.name}</div>
          {b.questions.map((q, n) => {
            const cell = resp[q.index];
            const points = q.answer_points ?? [];
            const awarded = cell?.awarded ?? [];
            const answerLocked = !!q.answer_locked;
            const markLocked = !!q.mark_locked;
            const lockingThis = locking?.index === q.index ? locking.kind : null;
            return (
              <div key={q.index} className="mb-2 rounded-lg border border-border bg-card p-2.5">
                <div className="flex items-start gap-2">
                  <span className="mt-0.5 text-[10px] font-semibold tabular-nums text-muted-foreground">{n + 1}.</span>
                  <p className="min-w-0 flex-1 text-xs font-medium text-foreground">{q.question}</p>
                  {markLocked && (
                    <span className="shrink-0 rounded bg-emerald-500/15 px-1.5 text-[10px] font-bold text-emerald-600">
                      {cell?.final_mark ?? 0}/{q.max_mark}
                    </span>
                  )}
                  <button
                    type="button"
                    onClick={() => onCopy(q.index, q.question)}
                    title="Copy question to send to the candidate"
                    className="shrink-0 rounded-md p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
                  >
                    {copiedIdx === q.index ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
                  </button>
                </div>

                {!answerLocked ? (
                  <textarea
                    value={cell?.response ?? ""}
                    onChange={(e) => setField(q.index, { response: e.target.value })}
                    rows={2}
                    placeholder="Candidate's response…"
                    className="mt-1.5 w-full rounded-lg border border-border bg-secondary/30 px-2.5 py-1.5 text-xs text-foreground outline-none focus:border-primary/50"
                  />
                ) : (
                  <div className="mt-1.5 whitespace-pre-wrap rounded-lg border border-border/60 bg-secondary/20 px-2.5 py-1.5 text-xs text-foreground/90">
                    {cell?.response?.trim() ? cell.response : <span className="italic text-muted-foreground">No response recorded</span>}
                  </div>
                )}

                {!answerLocked && q.hints && q.hints.length > 0 && hintsShown.has(q.index) && (
                  <div className="mt-1.5 flex flex-wrap gap-1.5">
                    {q.hints.map((h, i) => (
                      <span
                        key={i}
                        className="inline-flex items-center gap-1 rounded-full border border-amber-500/30 bg-amber-500/10 px-2 py-0.5 text-[10px] text-amber-700 dark:text-amber-400"
                      >
                        <Lightbulb className="h-2.5 w-2.5" /> {h}
                      </span>
                    ))}
                  </div>
                )}
                {!answerLocked && (
                  <div className="mt-1.5 flex items-center justify-end gap-2">
                    {q.hints && q.hints.length > 0 && (
                      <button
                        type="button"
                        onClick={() => toggleHint(q.index)}
                        className="inline-flex items-center gap-1 rounded-lg border border-amber-500/40 bg-amber-500/5 px-2 py-1 text-[11px] font-semibold text-amber-600 hover:bg-amber-500/10 dark:text-amber-400"
                      >
                        <Lightbulb className="h-3 w-3" />
                        {hintsShown.has(q.index) ? "Hide hint" : "Show hint"}
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => onLockAnswer(q.index)}
                      disabled={locking !== null}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-2.5 py-1 text-[11px] font-semibold text-white hover:bg-primary/90 disabled:opacity-40"
                    >
                      {lockingThis === "answer" ? <Loader2 className="h-3 w-3 animate-spin" /> : <Lock className="h-3 w-3" />}
                      Lock response &amp; reveal model answer
                    </button>
                  </div>
                )}

                {answerLocked && (
                  <div className="mt-2 space-y-2 border-t border-border/60 pt-2">
                    {q.strong_answer && (
                      <div>
                        <div className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Model answer</div>
                        <p className="mt-0.5 text-xs text-foreground/90">{q.strong_answer}</p>
                      </div>
                    )}
                    {q.hints && q.hints.length > 0 && (
                      <div className="flex flex-wrap gap-1.5">
                        {q.hints.map((h, i) => (
                          <span
                            key={i}
                            className="inline-flex items-center gap-1 rounded-full border border-amber-500/30 bg-amber-500/10 px-2 py-0.5 text-[10px] text-amber-700 dark:text-amber-400"
                          >
                            <Lightbulb className="h-2.5 w-2.5" /> {h}
                          </span>
                        ))}
                      </div>
                    )}
                    {points.length > 0 && (
                      <div>
                        <div className="flex items-center justify-between">
                          <div className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                            Rubric — tick what they covered
                          </div>
                          <span className="text-[10px] font-semibold text-muted-foreground">out of {q.max_mark}</span>
                        </div>
                        <ul className="mt-1 space-y-1">
                          {points.map((p, pi) => {
                            const ticked = awarded.includes(pi);
                            return (
                              <li key={pi}>
                                <button
                                  type="button"
                                  disabled={markLocked}
                                  onClick={() => togglePoint(q.index, pi, points)}
                                  className="flex w-full items-start gap-2 rounded-lg px-1.5 py-1 text-left text-xs hover:bg-secondary/50 disabled:cursor-default disabled:hover:bg-transparent"
                                >
                                  <span
                                    className={cn(
                                      "mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded border transition-colors",
                                      ticked ? "border-emerald-500 bg-emerald-500 text-white" : "border-border"
                                    )}
                                  >
                                    {ticked && <Check className="h-3 w-3" />}
                                  </span>
                                  <span className="min-w-0 flex-1 text-foreground/90">{p.point}</span>
                                  <span
                                    className={cn(
                                      "shrink-0 rounded px-1.5 text-[10px] font-bold",
                                      ticked ? "bg-emerald-500/15 text-emerald-600" : "bg-secondary text-muted-foreground"
                                    )}
                                  >
                                    +{p.marks}
                                  </span>
                                </button>
                              </li>
                            );
                          })}
                        </ul>
                      </div>
                    )}
                    <div className="flex flex-wrap items-center gap-2">
                      <input
                        value={cell?.observation ?? ""}
                        disabled={markLocked}
                        onChange={(e) => setField(q.index, { observation: e.target.value })}
                        placeholder="Observation (optional)"
                        className="min-w-0 flex-1 rounded-lg border border-border bg-secondary/30 px-2 py-1 text-[11px] text-foreground outline-none focus:border-primary/50 disabled:opacity-70"
                      />
                      <div className="flex items-center gap-1">
                        <span className="text-[10px] text-muted-foreground">Mark</span>
                        <input
                          type="number"
                          min={0}
                          max={q.max_mark}
                          disabled={markLocked}
                          value={cell?.final_mark ?? ""}
                          onChange={(e) =>
                            setField(q.index, {
                              final_mark: e.target.value === "" ? null : Math.max(0, Math.min(q.max_mark, Number(e.target.value))),
                            })
                          }
                          className="w-14 rounded-lg border border-border bg-background px-1.5 py-1 text-right text-xs text-foreground outline-none focus:border-primary/50 disabled:opacity-70"
                        />
                        <span className="text-[10px] text-muted-foreground">/{q.max_mark}</span>
                      </div>
                    </div>
                    {cell?.ai_mark != null && !markLocked && (
                      <div className="flex items-start gap-1 text-[10px] text-primary">
                        <Wand2 className="mt-0.5 h-2.5 w-2.5 shrink-0" />
                        <span>
                          AI suggested {cell.ai_mark}/{q.max_mark}
                          {cell.rationale ? ` — ${cell.rationale}` : ""}
                          {cell.final_mark !== cell.ai_mark && (
                            <button
                              type="button"
                              onClick={() => setField(q.index, { final_mark: cell.ai_mark })}
                              className="ml-1 underline hover:text-primary/80"
                            >
                              use
                            </button>
                          )}
                        </span>
                      </div>
                    )}
                    {!markLocked && (
                      <div className="flex justify-end">
                        <button
                          type="button"
                          onClick={() => onLockMark(q.index)}
                          disabled={locking !== null}
                          className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-2.5 py-1 text-[11px] font-semibold text-white hover:bg-primary/90 disabled:opacity-40"
                        >
                          {lockingThis === "mark" ? <Loader2 className="h-3 w-3 animate-spin" /> : <Lock className="h-3 w-3" />}
                          Lock mark &amp; reveal explanation
                        </button>
                      </div>
                    )}
                    {markLocked && q.explanation && (
                      <div>
                        <div className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Explanation</div>
                        <p className="mt-0.5 text-xs text-foreground/90">{q.explanation}</p>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
}

function FeedbackForm({
  token,
  sessionToken,
  round,
  extraQuestions,
  onSubmitted,
}: {
  token: string;
  sessionToken: string;
  round: InterviewerRound;
  // Questions explicitly pulled in from the rich "Generate Interview Questions"
  // panel (via its "Add to feedback sheet" action) — appended, always optional,
  // after the auto-fetched mandatory/optional baseline below.
  extraQuestions: { bucket: string; question: string }[];
  onSubmitted: (round: InterviewerRound) => void;
}) {
  const confirm = useConfirm();
  const [baseQuestions, setBaseQuestions] = useState<InterviewerQuestion[] | null>(null);
  const [questionsError, setQuestionsError] = useState<string | null>(null);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [overallFeedback, setOverallFeedback] = useState("");
  const [score, setScore] = useState("");
  // Legacy Screening-only picker.
  const [outcome, setOutcome] = useState<"Pass" | "Fail" | null>(null);
  // Round 1+ picker — Move to X / Reject / (Admin) Directly Hire/Reject.
  const [verdictOptions, setVerdictOptions] = useState<VerdictOptionsResponse | null>(null);
  const [verdictOptionsError, setVerdictOptionsError] = useState<string | null>(null);
  const [selectedOption, setSelectedOption] = useState<VerdictOption | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState<InterviewerRound | null>(null);
  // Promoting past the natural next stage (e.g. Round 1 → Final, or "Can be
  // Hired" mid-flow) requires a written justification — captured in this
  // popup and folded into the recorded feedback.
  const [promoteAsk, setPromoteAsk] = useState(false);
  const [promoteReason, setPromoteReason] = useState("");

  // Allocated question bank (if any) — when present, the interviewer answers
  // THESE questions with a per-question mark instead of generating a kit.
  const [qb, setQb] = useState<AllocatedQuestionBank | null>(null);
  type QbCell = { response: string; observation: string; ai_mark: number | null; final_mark: number | null; rationale: string; awarded: number[] };
  const [qbResp, setQbResp] = useState<Record<number, QbCell>>({});
  const [marking, setMarking] = useState(false);
  const [copiedIdx, setCopiedIdx] = useState<number | null>(null);

  useEffect(() => {
    interviewerService
      .getQuestions(token, sessionToken)
      .then((res) => setBaseQuestions(res.questions))
      .catch((e) => setQuestionsError(e instanceof InterviewerApiError ? e.message : "Couldn't load interview questions."));
    interviewerService
      .getVerdictOptions(token, sessionToken)
      .then(setVerdictOptions)
      .catch((e) => setVerdictOptionsError(e instanceof InterviewerApiError ? e.message : "Couldn't load verdict options."));
    interviewerService.getQuestionBank(token, sessionToken).then(setQb).catch(() => setQb(null));
    setOutcome(null);
    setSelectedOption(null);
    setQbResp({});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token, sessionToken, round.round_id]);

  // Hydrate the per-question cells from saved responses (resume, and after each
  // lock the endpoints return the persisted rows). Skips when nothing is saved
  // yet, so in-progress capture edits are never wiped.
  useEffect(() => {
    const rows = qb?.responses;
    if (!rows || rows.length === 0) return;
    const next: Record<number, QbCell> = {};
    rows.forEach((r) => {
      next[r.question_index] = {
        response: r.response_text ?? "",
        observation: r.observation ?? "",
        ai_mark: r.ai_mark,
        final_mark: r.final_mark,
        rationale: r.ai_rationale ?? "",
        awarded: r.awarded_points ?? [],
      };
    });
    setQbResp(next);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [qb]);

  const qbMode = !!qb?.allocation;
  const qbAlloc = qb?.allocation ?? null;
  // Per-question locking — which question + which stage is in flight.
  const [locking, setLocking] = useState<{ index: number; kind: "answer" | "mark" } | null>(null);

  // Flattened gated questions — powers the AI-mark items + the lock payloads.
  const qbFlat = useMemo(() => {
    const out: { index: number; bucket: string; question: string; ideal: string }[] = [];
    (qb?.buckets ?? []).forEach((b) =>
      b.questions.forEach((q) =>
        out.push({ index: q.index, bucket: q.bucket || b.name, question: q.question, ideal: q.strong_answer ?? "" })
      )
    );
    return out;
  }, [qb]);

  const setQbField = (i: number, patch: Partial<QbCell>) =>
    setQbResp((prev) => {
      const base: QbCell = prev[i] ?? { response: "", observation: "", ai_mark: null, final_mark: null, rationale: "", awarded: [] };
      return { ...prev, [i]: { ...base, ...patch } };
    });

  // Tick/untick a rubric point → the mark becomes the sum of the ticked points.
  const togglePoint = (i: number, pointIdx: number, points: { point: string; marks: number }[]) =>
    setQbResp((prev) => {
      const base: QbCell = prev[i] ?? { response: "", observation: "", ai_mark: null, final_mark: null, rationale: "", awarded: [] };
      const set = new Set(base.awarded);
      if (set.has(pointIdx)) set.delete(pointIdx);
      else set.add(pointIdx);
      const awarded = [...set].sort((a, b) => a - b);
      const sum = awarded.reduce((s, idx) => s + (points[idx]?.marks ?? 0), 0);
      return { ...prev, [i]: { ...base, awarded, final_mark: sum } };
    });

  const copyQuestion = async (i: number, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedIdx(i);
      setTimeout(() => setCopiedIdx(null), 1200);
    } catch {
      // clipboard blocked — the interviewer can still select the text manually
    }
  };

  const lockAnswer = async (index: number) => {
    if (!qbAlloc) return;
    const q = qbFlat.find((x) => x.index === index);
    const r = qbResp[index];
    const empty = !(r?.response ?? "").trim();
    const ok = await confirm({
      title: empty ? "Lock with no response recorded?" : "Lock this response?",
      message: empty
        ? "No candidate response is entered for this question. Locking reveals the model answer + rubric, and the response can't be edited afterwards. Lock anyway?"
        : "Locking freezes this response and reveals the model answer + rubric — you won't be able to edit the response afterwards. Continue?",
      confirmLabel: "Lock response",
      danger: empty,
    });
    if (!ok) return;
    setLocking({ index, kind: "answer" });
    setError(null);
    try {
      const res = await interviewerService.lockQBAnswer(token, sessionToken, qbAlloc.allocation_id, {
        index,
        bucket: q?.bucket ?? "",
        question: q?.question ?? "",
        response_text: r?.response ?? "",
        observation: r?.observation ?? "",
      });
      setQb((prev) => (prev && prev.allocation ? { ...prev, buckets: res.buckets, responses: res.responses } : prev));
    } catch (e) {
      setError(e instanceof InterviewerApiError ? e.message : "Couldn't lock this response.");
    } finally {
      setLocking(null);
    }
  };

  const lockMark = async (index: number) => {
    if (!qbAlloc) return;
    const r = qbResp[index];
    setLocking({ index, kind: "mark" });
    setError(null);
    try {
      const res = await interviewerService.lockQBMark(token, sessionToken, qbAlloc.allocation_id, {
        index,
        final_mark: r?.final_mark ?? null,
        awarded_points: r?.awarded ?? [],
        ai_mark: r?.ai_mark ?? null,
        ai_rationale: r?.rationale ?? "",
      });
      setQb((prev) => (prev && prev.allocation ? { ...prev, buckets: res.buckets, responses: res.responses } : prev));
    } catch (e) {
      setError(e instanceof InterviewerApiError ? e.message : "Couldn't lock this mark.");
    } finally {
      setLocking(null);
    }
  };

  const runAiMarks = async () => {
    setMarking(true);
    try {
      const items = qbFlat.map((q) => ({
        index: q.index,
        bucket: q.bucket,
        question: q.question,
        ideal_answer: q.ideal,
        response: qbResp[q.index]?.response ?? "",
      }));
      const { marks } = await interviewerService.markQuestionBank(token, sessionToken, items);
      setQbResp((prev) => {
        const next = { ...prev };
        marks.forEach((m) => {
          const cur = next[m.index] ?? { response: "", observation: "", ai_mark: null, final_mark: null, rationale: "", awarded: [] };
          next[m.index] = { ...cur, ai_mark: m.mark, rationale: m.rationale, final_mark: cur.final_mark ?? m.mark };
        });
        return next;
      });
    } catch {
      // AI marking is best-effort — the interviewer can still mark manually
    } finally {
      setMarking(false);
    }
  };

  // Merge in whatever's been sent from the question generator — always appended
  // (never reordering baseQuestions, so existing `answers` indices stay valid),
  // deduped by question text, always non-mandatory.
  const questions = useMemo<InterviewerQuestion[] | null>(() => {
    if (!baseQuestions) return null;
    const seen = new Set(baseQuestions.map((q) => q.question));
    const extras = extraQuestions
      .filter((q) => !seen.has(q.question) && seen.add(q.question))
      .map((q) => ({ bucket: q.bucket, question: q.question, mandatory: false }));
    return [...baseQuestions, ...extras];
  }, [baseQuestions, extraQuestions]);

  const missingMandatory = qbMode
    ? false
    : (questions ?? []).some((q, i) => q.mandatory && !(answers[i] ?? "").trim());
  const scoreNum = score.trim() === "" ? null : Number(score);
  const scoreInvalid = scoreNum !== null && (Number.isNaN(scoreNum) || scoreNum < 0 || scoreNum > 10);
  // Screening keeps the plain Pass/Fail picker; every later round gets the
  // round-aware options instead. Defaults to legacy while still loading so
  // there's never a flash of the wrong picker for Screening (the common case).
  const legacyMode = !verdictOptions || verdictOptions.legacy_pass_fail;
  const verdictChosen = legacyMode ? !!outcome : !!selectedOption;
  const canSubmit = (qbMode || !!questions) && !!verdictOptions && !missingMandatory && verdictChosen && !scoreInvalid && !submitting;

  // Maps a chosen round-aware option to the outcome/advance_to/direct_status
  // combination app/api/interviewer.py's submit_feedback expects.
  const bodyForOption = (opt: VerdictOption): Pick<SubmitFeedbackBody, "outcome" | "advance_to" | "direct_status"> => {
    if (opt.key === "reject") return { outcome: "Fail" };
    if (opt.key === "hire") return { outcome: "Pass", advance_to: "Hire" };
    if (opt.key === "direct_hire") return { outcome: "Pass", direct_status: "Hired" };
    if (opt.key === "direct_reject") return { outcome: "Fail", direct_status: "Rejected" };
    return { outcome: "Pass", advance_to: opt.target };
  };

  // Leapfrog detection — the FIRST "advance" option is always the round's
  // natural next stage, so any other advance target (or "Can be Hired" from a
  // non-Final round) is a promotion PAST the normal flow and needs an explicit
  // written justification before it's recorded.
  const firstAdvanceTarget = verdictOptions?.options.find((o) => o.key === "advance")?.target ?? null;
  const needsPromotionReason =
    !legacyMode &&
    !!selectedOption &&
    ((selectedOption.key === "advance" && !!selectedOption.target && selectedOption.target !== firstAdvanceTarget) ||
      selectedOption.key === "hire");

  const doSubmit = async (feedbackText: string) => {
    if (!qbMode && !questions) return;
    setError(null);
    setSubmitting(true);
    try {
      const answersPayload: QuestionAnswer[] = qbMode
        ? []
        : (questions ?? []).map((q, i) => ({ ...q, answer: answers[i] ?? "" }));
      // Question-bank marks are persisted separately via the lock-answers /
      // lock-marks steps, so the verdict submit only carries the allocation id
      // (to bind the round) — not the per-question responses.
      const res = await interviewerService.submitFeedback(token, sessionToken, {
        answers: answersPayload,
        overall_feedback: feedbackText,
        score: scoreNum,
        ...(qbMode ? { qb_allocation_id: qb!.allocation!.allocation_id } : {}),
        ...(legacyMode ? { outcome: outcome! } : bodyForOption(selectedOption!)),
      });
      setDone(res.round);
      onSubmitted(res.round);
    } catch (e) {
      setError(e instanceof InterviewerApiError ? e.message : "Couldn't submit feedback.");
    } finally {
      setSubmitting(false);
    }
  };

  const submit = async () => {
    if (!qbMode && !questions) return;
    if (legacyMode ? !outcome : !selectedOption) return;
    if (needsPromotionReason) {
      setPromoteAsk(true);
      return;
    }
    await doSubmit(overallFeedback);
  };

  const confirmPromotion = () => {
    const reason = promoteReason.trim();
    if (!reason || !selectedOption) return;
    setPromoteAsk(false);
    const merged = [
      overallFeedback.trim(),
      `[Promotion justification — ${selectedOption.label}]: ${reason}`,
    ]
      .filter(Boolean)
      .join("\n\n");
    void doSubmit(merged);
  };

  if (done) {
    return (
      <Section icon={CheckCircle2} title="Feedback recorded">
        <p className="text-xs text-muted-foreground">
          Thank you — the verdict (
          <span className="font-semibold text-foreground">{outcomeLabel(done.outcome)}</span>
          ) has been recorded for {done.round_name}. The candidate's process will move forward accordingly.
        </p>
      </Section>
    );
  }

  return (
    <Section icon={FileText} title={`${round.round_name} — feedback & verdict`}>
      {qbMode ? (
        <QuestionBankAnswerBlock
          bankName={qb!.allocation!.bank_name}
          buckets={qb!.buckets}
          resp={qbResp}
          setField={setQbField}
          togglePoint={togglePoint}
          onCopy={copyQuestion}
          copiedIdx={copiedIdx}
          marking={marking}
          onAiMark={runAiMarks}
          locking={locking}
          onLockAnswer={lockAnswer}
          onLockMark={lockMark}
        />
      ) : questionsError ? (
        <p className="mb-3 text-xs text-red-500">{questionsError}</p>
      ) : !questions ? (
        <div className="mb-3 flex items-center gap-2 text-xs text-muted-foreground">
          <Loader2 className="h-3.5 w-3.5 animate-spin" /> Generating interview questions…
        </div>
      ) : (
        <div className="mb-4 space-y-3">
          {questions.map((q, i) => (
            <div key={i}>
              <label className="mb-1 flex items-start justify-between gap-3 text-xs font-medium text-foreground">
                <span className="min-w-0 flex-1">
                  {q.question}
                  {q.mandatory && <span className="ml-1 text-destructive">*</span>}
                </span>
                <span className="max-w-[38%] shrink-0 text-right text-[10px] font-normal uppercase tracking-wide text-muted-foreground">
                  {q.bucket}{!q.mandatory && " · optional"}
                </span>
              </label>
              <textarea
                value={answers[i] ?? ""}
                onChange={(e) => setAnswers((prev) => ({ ...prev, [i]: e.target.value }))}
                rows={2}
                placeholder={q.mandatory ? "Required" : "Optional"}
                className={cn(
                  "w-full rounded-lg border bg-secondary/30 px-2.5 py-1.5 text-xs text-foreground outline-none focus:border-primary/50",
                  q.mandatory && !(answers[i] ?? "").trim() ? "border-border" : "border-border"
                )}
              />
            </div>
          ))}
        </div>
      )}

      <div className="mb-3 space-y-1.5">
        <label className="text-xs font-medium text-foreground">Overall comments</label>
        <textarea
          value={overallFeedback}
          onChange={(e) => setOverallFeedback(e.target.value)}
          rows={3}
          placeholder="Any additional observations…"
          className="w-full rounded-lg border border-border bg-secondary/30 px-2.5 py-1.5 text-xs text-foreground outline-none focus:border-primary/50"
        />
      </div>

      <div className="mb-4 space-y-1.5">
        <label className="text-xs font-medium text-foreground">
          Score (0–10, optional)
          {score !== "" && (
            <span className="ml-2 font-semibold text-primary">
              {SCORE_EMOJIS[Number(score)]} {score}/10
            </span>
          )}
        </label>
        <div className="flex flex-wrap items-center gap-1">
          {SCORE_EMOJIS.map((emoji, n) => {
            const active = score === String(n);
            return (
              <button
                key={n}
                type="button"
                onClick={() => setScore(active ? "" : String(n))}
                title={`${n}/10${active ? " — click again to clear" : ""}`}
                aria-pressed={active}
                className={cn(
                  "flex flex-col items-center rounded-lg border px-1.5 py-1 transition-all",
                  active
                    ? "scale-110 border-primary/60 bg-primary/10"
                    : "border-border bg-secondary/30 opacity-60 hover:opacity-100 hover:bg-secondary/60"
                )}
              >
                <span className="text-base leading-none">{emoji}</span>
                <span className={cn("mt-0.5 text-[9px] font-semibold tnum", active ? "text-primary" : "text-muted-foreground")}>
                  {n}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {!qbMode && (
        <div className="mb-3 flex items-start gap-2 rounded-lg border border-primary/20 bg-primary/5 px-3 py-2">
          <Info className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
          <p className="text-[11px] leading-relaxed text-muted-foreground">
            Tip: use <span className="font-medium text-foreground">Generate Interview Questions</span> above
            (optional) to generate or refresh a few picked questions for this round. Recording the
            candidate's responses and your observations against them here helps trace the final
            verdict back to specific evidence during an audit.
          </p>
        </div>
      )}

      <div className="mb-4 space-y-1.5">
        <label className="text-xs font-medium text-foreground">Verdict</label>
        {legacyMode ? (
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => setOutcome("Pass")}
              className={cn(
                "flex items-center justify-center gap-1.5 rounded-lg border py-2 text-xs font-semibold transition-colors",
                outcome === "Pass" ? "border-emerald-500/50 bg-emerald-500/10 text-emerald-600" : "border-border text-muted-foreground hover:text-foreground"
              )}
            >
              <Check className="h-3.5 w-3.5" /> Pass
            </button>
            <button
              onClick={() => setOutcome("Fail")}
              className={cn(
                "flex items-center justify-center gap-1.5 rounded-lg border py-2 text-xs font-semibold transition-colors",
                outcome === "Fail" ? "border-rose-500/50 bg-rose-500/10 text-rose-600" : "border-border text-muted-foreground hover:text-foreground"
              )}
            >
              <XCircle className="h-3.5 w-3.5" /> Fail
            </button>
          </div>
        ) : verdictOptionsError ? (
          <p className="text-xs text-red-500">{verdictOptionsError}</p>
        ) : !verdictOptions ? (
          <div className="flex items-center gap-2 py-1 text-xs text-muted-foreground">
            <Loader2 className="h-3.5 w-3.5 animate-spin" /> Loading verdict options…
          </div>
        ) : (
          <div className="space-y-1.5">
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              {verdictOptions.options
                .filter((o) => o.key === "advance" || o.key === "hire" || o.key === "reject")
                .map((o) => (
                  <VerdictButton
                    key={`${o.key}-${o.target ?? ""}`}
                    option={o}
                    selected={selectedOption}
                    onSelect={setSelectedOption}
                    // Reject always sits in the right column — the stop action
                    // never leads a row the forward actions flow through.
                    className={o.key === "reject" ? "sm:col-start-2" : undefined}
                  />
                ))}
            </div>
            {verdictOptions.is_admin && (
              <div className="space-y-1">
                <p className="text-[10px] font-medium uppercase tracking-wide text-muted-foreground">Admin bypass</p>
                <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                  {verdictOptions.options
                    .filter((o) => o.key === "direct_hire" || o.key === "direct_reject")
                    .map((o) => (
                      <VerdictButton key={o.key} option={o} selected={selectedOption} onSelect={setSelectedOption} />
                    ))}
                </div>
              </div>
            )}
          </div>
        )}
        {missingMandatory && (
          <p className="text-[10px] text-muted-foreground">Answer every required question above to continue.</p>
        )}
      </div>

      {error && <p className="mb-3 rounded-lg bg-red-500/10 px-3 py-2 text-xs font-medium text-red-500">{error}</p>}

      <button
        onClick={submit}
        disabled={!canSubmit}
        className="btn-brand w-full disabled:cursor-not-allowed disabled:opacity-50"
      >
        {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : "Submit verdict"}
      </button>

      {promoteAsk && selectedOption && (
        <div
          className="fixed inset-0 z-[60] flex items-center justify-center bg-foreground/50 p-4 backdrop-blur-sm"
          onClick={() => setPromoteAsk(false)}
        >
          <div
            className="w-full max-w-sm rounded-2xl border border-border bg-card p-5 shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-sm font-bold text-foreground">
              Why "{selectedOption.label}"?
            </h3>
            <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
              This verdict moves the candidate past the normal next stage
              {firstAdvanceTarget ? ` (${firstAdvanceTarget})` : ""} — please note what in this
              interview justifies the jump. Your reason is recorded with the feedback.
            </p>
            <textarea
              value={promoteReason}
              onChange={(e) => setPromoteReason(e.target.value)}
              rows={3}
              autoFocus
              placeholder="e.g. Cleared the system-design bar expected at the later round; depth well beyond this stage…"
              className="mt-3 w-full resize-none rounded-lg border border-border bg-background px-2.5 py-1.5 text-xs text-foreground outline-none focus:border-primary/50"
            />
            <div className="mt-4 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setPromoteAsk(false)}
                className="rounded-lg border border-border px-3.5 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-secondary"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmPromotion}
                disabled={!promoteReason.trim()}
                className="rounded-lg bg-primary px-3.5 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-primary/90 disabled:opacity-40"
              >
                Record reason &amp; submit
              </button>
            </div>
          </div>
        </div>
      )}
    </Section>
  );
}
