import { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import {
  ChevronRight,
  Mail,
  RotateCw,
  CheckCircle2,
  XCircle,
  Clock3,
  Sparkles,
  SearchCheck,
  UserCheck,
  Users,
  Trophy,
  PauseCircle,
  Rocket,
  FileSearch,
  Send,
  MessageCircle,
  CalendarClock,
  LogIn,
  CalendarCheck,
  ListChecks,
  PartyPopper,
  Tag,
  type LucideIcon,
} from "lucide-react";
import { candidatesService } from "@/services/candidates";
import { analyticsService, agingTier } from "@/services/analytics";
import { cn } from "@/lib/utils";
import { ALL_SOURCES, sourceOf, useGlobalSource, useSampleDataFilter } from "@/lib/source";
import FilterDropdown from "@/components/common/FilterDropdown";
import {
  bucketOf,
  bucketAges,
  agingDaysFor,
  BUCKET_COLOR,
  type RoundBucket,
} from "@/lib/rounds";
import {
  ONBOARDING_STAGE_ORDER,
  ONBOARDING_STAGE_LABELS,
  ONBOARDING_STAGE_COLOR,
  onboardingStageOf,
} from "@/lib/onboarding";
import type { CandidateMaster, OnboardingStage } from "@/types/candidate";
import PageHeader from "@/components/layout/PageHeader";
import PageContainer from "@/components/layout/PageContainer";

const BUBBLE = 84; // px — every stage shape is this exact height, so connectors line up precisely.
// ONE harmonized size across all three rows (recruitment, hiring,
// onboarding) — same height, same type scale, same icon size; rows wrap on
// narrower screens rather than shrinking their shapes out of proportion.
const ONBOARDING_BUBBLE = BUBBLE;

// Main pipeline, left → right, with Hired/Rejected/Undecided as the three
// terminal branches. Colors come from BUCKET_COLOR (lib/rounds) — the SAME
// per-bucket palette the Dashboard tiles and every stage chip use, so a
// stage reads as the same color everywhere in the app.
// The flow reads New » Screening » Round 1..n » Final » Hire/Rejected/
// Undecided — the round stages carry the REAL stage name ("Screening"; the
// slots-shared story lives in the sub-step chips below each stage now).
// Stable states (New + the terminals) render as PILLS; the in-flight round
// stages keep the forward-slanting parallelogram.
const PIPELINE_STAGES: { bucket: RoundBucket; label: string; color: string; icon: LucideIcon; shape: "pill" | "flow" }[] = [
  { bucket: "New", label: "New", color: BUCKET_COLOR.New, icon: Sparkles, shape: "pill" },
  { bucket: "Screening", label: "Screening", color: BUCKET_COLOR.Screening, icon: SearchCheck, shape: "flow" },
  { bucket: "Round 1", label: "Round 1", color: BUCKET_COLOR["Round 1"], icon: UserCheck, shape: "flow" },
  { bucket: "Round 2", label: "Round 2", color: BUCKET_COLOR["Round 2"], icon: Users, shape: "flow" },
  { bucket: "Final", label: "Final", color: BUCKET_COLOR.Final, icon: Trophy, shape: "flow" },
];
const TERMINAL_STAGES: { bucket: RoundBucket; label: string; color: string; icon: LucideIcon }[] = [
  { bucket: "Hired", label: "Hire", color: BUCKET_COLOR.Hired, icon: CheckCircle2 },
  { bucket: "Reject", label: "Rejected", color: BUCKET_COLOR.Reject, icon: XCircle },
  { bucket: "Undecided", label: "Undecided", color: BUCKET_COLOR.Undecided, icon: PauseCircle },
];

const ONBOARDING_ICON: Record<OnboardingStage, LucideIcon> = {
  ready_to_hire: Rocket,
  offer_review: FileSearch,
  offer_sent: Send,
  candidate_responded: MessageCircle,
  expected_join_date: CalendarClock,
  joined: LogIn,
  onboarding_date_set: CalendarCheck,
  allocation_checklist: ListChecks,
  onboarding_complete: PartyPopper,
};

// Round types that carry the invite/reminder/acceptance/outcome sub-steps —
// every round type (Screening/Round 1/Round 2/Final) per the same scope.
const ROUND_STEP_BUCKETS: RoundBucket[] = ["Screening", "Round 1", "Round 2", "Final"];

// The post-hire progression's two real phases: the HIRING PROCEDURE (Ready to
// Hire through the candidate's offer response) and the ONBOARDING PROCESS
// (everything after acceptance) — rendered as two separate flow rows.
const HIRING_STAGES = ONBOARDING_STAGE_ORDER.slice(0, 4);
const ONBOARDING_PHASE_STAGES = ONBOARDING_STAGE_ORDER.slice(4);

// The slot-invite lifecycle for candidates CURRENTLY sitting in this stage.
// Deliberately NOT "outcome recorded": a candidate whose interview verdict is
// in has already LEFT the bucket (Pass → next stage, Fail → Rejected), so the
// old "Interview done m/n" chip was really counting Holds/stale mirrors. What
// IS true of candidates still in the stage: invited or not → awaiting their
// slot pick (some nudged by reminders) → booked (upcoming, or already past
// the slot time and awaiting the interviewer's verdict) — plus the explicit
// declined / on-hold exceptions.
// Interview-round sequence + which slice of it each pipeline bucket covers
// (the "Round 2" bucket also holds the optional Round 3) — used to compute
// "passed this stage" (reached anything later, including Hired and those who
// fell at a LATER stage) and "rejected AT this stage" (their round stopped
// here) from each candidate's current round position.
const STAGE_SEQ = ["Screening", "Round 1", "Round 2", "Round 3", "Final"];
const BUCKET_STAGE_RANGE: Partial<Record<RoundBucket, [number, number]>> = {
  Screening: [0, 0],
  "Round 1": [1, 1],
  "Round 2": [2, 3],
  Final: [4, 4],
};
function reachedIdx(c: CandidateMaster): number {
  if (c.status === "Hired") return STAGE_SEQ.length; // beyond Final
  return STAGE_SEQ.indexOf((c.roundname ?? "").trim()); // -1 = New / no round
}

function stepCountsFor(
  candidates: CandidateMaster[],
  bucket: RoundBucket,
  scheduledMap: Record<string, string | null>
) {
  const inBucket = candidates.filter((c) => bucketOf(c) === bucket);
  const now = Date.now();
  const booked = inBucket.filter((c) => c.candidate_accepted_slot === true);
  const isPast = (c: CandidateMaster) => {
    const raw = scheduledMap[c.candidate_id];
    if (!raw) return false;
    const t = new Date(raw).getTime();
    return !Number.isNaN(t) && t < now;
  };
  const awaitingPickList = inBucket.filter(
    (c) => c.invite_sent_at && c.candidate_accepted_slot == null
  );
  const [firstIdx, lastIdx] = BUCKET_STAGE_RANGE[bucket] ?? [-2, -2];
  const passed = candidates.filter((c) => reachedIdx(c) > lastIdx).length;
  const rejectedHere = candidates.filter((c) => {
    if (bucketOf(c) !== "Reject") return false;
    const i = STAGE_SEQ.indexOf((c.roundname ?? "").trim());
    return i >= firstIdx && i <= lastIdx;
  }).length;
  return {
    total: inBucket.length,
    invited: inBucket.filter((c) => c.invite_sent_at).length,
    passed,
    rejectedHere,
    awaitingPick: awaitingPickList.length,
    reminded: awaitingPickList.filter((c) => (c.reminder_count ?? 0) > 0).length,
    upcoming: booked.filter((c) => !isPast(c)).length,
    awaitingVerdict: booked.filter(isPast).length,
    declined: inBucket.filter((c) => c.candidate_accepted_slot === false).length,
    onHold: inBucket.filter((c) => c.round_status === "Hold").length,
  };
}

// Aging badge color — grey (watch, >15d) to black (stalled, >30d), matching the
// Dashboard's own tiers (AGING_WATCH / AGING_ALERT).
function agingCountFor(
  candidates: CandidateMaster[],
  bucket: RoundBucket,
  agingByCandidate: Map<string, number>
): { watch: number; stalled: number } {
  let watch = 0;
  let stalled = 0;
  candidates.forEach((c) => {
    if (bucketOf(c) !== bucket || !bucketAges(bucket)) return;
    const days = agingDaysFor(c, agingByCandidate);
    if (days == null) return;
    const tier = agingTier(days);
    if (tier === "stalled") stalled += 1;
    else if (tier === "watch") watch += 1;
  });
  return { watch, stalled };
}

function AgingBadge({ watch, stalled }: { watch: number; stalled: number }) {
  if (watch === 0 && stalled === 0) return null;
  return (
    <div className="mt-1.5 flex items-center justify-center gap-1">
      {watch > 0 && (
        <span
          title={`${watch} aging 15–30 days`}
          className="inline-flex items-center gap-0.5 rounded-full border border-amber-500/30 bg-amber-500/10 px-1.5 py-0.5 text-[9px] font-bold text-amber-600"
        >
          <Clock3 className="h-2.5 w-2.5" /> {watch}
        </span>
      )}
      {stalled > 0 && (
        <span
          title={`${stalled} stalled >30 days`}
          className="inline-flex items-center gap-0.5 rounded-full border border-rose-500/30 bg-rose-500/10 px-1.5 py-0.5 text-[9px] font-bold text-rose-600"
        >
          <Clock3 className="h-2.5 w-2.5" /> {stalled}
        </span>
      )}
    </div>
  );
}

// "#rrggbb" + alpha → rgba() — every glassy fill/border derives from the ONE
// stage color at different opacities, so light and dark themes both tint
// their own background through the same translucent surface.
function hexA(hex: string, alpha: number): string {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 0xff}, ${(n >> 8) & 0xff}, ${n & 0xff}, ${alpha})`;
}

function StageBubble({
  label,
  count,
  color,
  icon: Icon,
  onClick,
  size = BUBBLE,
  shape = "flow",
}: {
  label: string;
  count: number;
  color: string;
  icon: LucideIcon;
  onClick: () => void;
  // Smaller for rows with more stages (e.g. onboarding's 9) so everything
  // still fits without a horizontal scrollbar.
  size?: number;
  // "flow" = forward-slanting rounded parallelogram (in-flight process
  // stages); "pill" = plain capsule (stable states: New, Hire, Rejected,
  // Undecided).
  shape?: "pill" | "flow";
}) {
  const compact = size < BUBBLE;
  // A stage with nobody in it (for the selected source tag) recedes — the
  // populated stages are where the data is, and they should pop instead of
  // every bubble shouting equally.
  const empty = count === 0;
  return (
    <button
      type="button"
      onClick={onClick}
      title={`${count} candidate${count === 1 ? "" : "s"} — view in Candidates`}
      className={cn(
        // py + gap give the icon (and label) an elegant breathing gap from the
        // shape's top/bottom edges instead of the content touching the skin.
        "group relative flex shrink-0 flex-col items-center justify-center gap-1 px-5 py-2.5 text-center transition-all duration-200 hover:-translate-y-1",
        compact && "px-4 py-1.5 gap-0.5",
        empty && "opacity-65 hover:opacity-100",
      )}
      style={{
        // Fixed height keeps every stage's vertical center identical (so
        // connectors line up); width is a MIN only — a long label or a
        // multi-digit count grows the shape sideways instead of wrapping.
        height: size,
        minWidth: Math.round(size * 1.35),
      }}
    >
      {/* The glassy skin is a separate, skewed layer — a rounded parallelogram
          leaning FORWARD (the direction the flow travels) — so the content on
          top stays perfectly upright and readable. */}
      <span
        aria-hidden
        className={cn(
          "absolute inset-0 border backdrop-blur-md transition-shadow",
          shape === "pill" ? "rounded-full" : compact ? "rounded-[18px]" : "rounded-[24px]",
          empty ? "shadow-none" : "shadow-sm group-hover:shadow-lg",
        )}
        style={{
          backgroundImage: `linear-gradient(155deg, ${hexA(color, 0.34)}, ${hexA(color, 0.12)})`,
          borderColor: hexA(color, 0.55),
          transform: shape === "flow" ? "skewX(-8deg)" : undefined,
        }}
      />
      <span
        className={cn(
          "relative flex shrink-0 items-center justify-center rounded-full transition-transform group-hover:scale-110",
          compact ? "h-5 w-5" : "h-7 w-7",
        )}
        style={{ backgroundColor: hexA(color, 0.22), color }}
      >
        <Icon className={compact ? "h-3 w-3" : "h-4 w-4"} />
      </span>
      <span className={cn("relative whitespace-nowrap font-extrabold leading-none tabular-nums text-ink", compact ? "text-base" : "text-xl")}>
        {count}
      </span>
      <span
        className={cn(
          "relative whitespace-nowrap px-1 font-semibold leading-tight",
          empty ? "text-ink-mute" : "text-ink",
          compact ? "text-[9px]" : "text-[11px] px-1.5",
        )}
      >
        {label}
      </span>
    </button>
  );
}

// A short connecting segment between two bubbles — height-matched to `h` so the
// chevron sits exactly on the bubbles' vertical center, regardless of whatever
// variable-height content (aging badge, step chips) hangs below them.
function Connector({ h = BUBBLE, w = 28 }: { h?: number; w?: number }) {
  return (
    <div className="flex shrink-0 items-center justify-center" style={{ height: h, width: w }}>
      <div className="flex items-center">
        <div className="h-px w-2 bg-border" />
        <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground/50" />
        <div className="h-px w-2 bg-border" />
      </div>
    </div>
  );
}

// Small chip column of the slot-invite lifecycle for one stage — in funnel
// order (invited → awaiting pick → scheduled → awaiting verdict), each chip
// only when it actually has data, so the column IS the stage's live story.
function StepChips({ counts }: { counts: ReturnType<typeof stepCountsFor> }) {
  if (counts.total === 0) return null;
  return (
    <div className="mt-2.5 flex flex-col items-center gap-1">
      {/* Sub-stage story, in flow order: slots sent → reminders → scheduled →
          interview done (Pass) / Rejected at this stage. */}
      <span
        title={`${counts.invited} of ${counts.total} in this stage have been sent a slot-picker invite`}
        className="inline-flex w-max items-center gap-1 rounded-full border border-border bg-card px-2 py-0.5 text-[9px] font-semibold text-foreground"
      >
        <Mail className="h-2.5 w-2.5 text-sky-500" /> Slots sent {counts.invited}/{counts.total}
      </span>
      {counts.awaitingPick > 0 && (
        <span
          title={`${counts.awaitingPick} invited but haven't picked a slot yet${counts.reminded > 0 ? ` — ${counts.reminded} already reminded (reminders repeat until the response window closes)` : ""}`}
          className="inline-flex w-max items-center gap-1 rounded-full border border-amber-500/30 bg-amber-500/10 px-2 py-0.5 text-[9px] font-semibold text-amber-600"
        >
          <RotateCw className="h-2.5 w-2.5" /> Reminder {counts.reminded}/{counts.awaitingPick} pending
        </span>
      )}
      {(counts.upcoming > 0 || counts.awaitingVerdict > 0) && (
        <span
          title={`${counts.upcoming} interview(s) upcoming${counts.awaitingVerdict > 0 ? ` · ${counts.awaitingVerdict} past their slot time, verdict pending` : ""}`}
          className="inline-flex w-max items-center gap-1 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2 py-0.5 text-[9px] font-semibold text-emerald-600"
        >
          <CalendarClock className="h-2.5 w-2.5" /> Scheduled {counts.upcoming}
          {counts.awaitingVerdict > 0 && ` · verdict due ${counts.awaitingVerdict}`}
        </span>
      )}
      {(counts.passed > 0 || counts.rejectedHere > 0) && (
        <span
          title={`${counts.passed} passed this stage (moved ahead — includes anyone now at a later stage or hired) · ${counts.rejectedHere} rejected at this stage`}
          className="inline-flex w-max items-center gap-1 rounded-full border border-border bg-card px-2 py-0.5 text-[9px] font-semibold text-foreground"
        >
          <CheckCircle2 className="h-2.5 w-2.5 text-emerald-500" /> Done {counts.passed}
          {counts.rejectedHere > 0 && (
            <>
              <XCircle className="ml-1 h-2.5 w-2.5 text-rose-500" /> {counts.rejectedHere}
            </>
          )}
        </span>
      )}
      {counts.declined > 0 && (
        <span
          title={`${counts.declined} declined their slot invite`}
          className="inline-flex w-max items-center gap-1 rounded-full border border-rose-500/30 bg-rose-500/10 px-2 py-0.5 text-[9px] font-semibold text-rose-600"
        >
          <XCircle className="h-2.5 w-2.5" /> Declined {counts.declined}
        </span>
      )}
      {counts.onHold > 0 && (
        <span
          title={`${counts.onHold} on hold at this stage`}
          className="inline-flex w-max items-center gap-1 rounded-full border border-border bg-card px-2 py-0.5 text-[9px] font-semibold text-muted-foreground"
        >
          <PauseCircle className="h-2.5 w-2.5" /> On hold {counts.onHold}
        </span>
      )}
    </div>
  );
}

export default function ProcessFlow() {
  const navigate = useNavigate();

  const { data: allCandidates = [] } = useQuery({
    queryKey: ["candidates"],
    queryFn: async () => (await candidatesService.list()).data,
  });

  // Source-tag filter — GLOBAL (shared with Dashboard/Screening, sticky
  // across visits), so switching campaigns here scopes the whole flow the
  // same way it scopes every other page. Options are the distinct sources
  // actually present, most recently active first.
  const [source, setSource] = useGlobalSource();
  const sampleDataFilter = useSampleDataFilter();
  const sources = useMemo(() => {
    const latest = new Map<string, string>();
    allCandidates.forEach((c) => {
      const s = sourceOf(c);
      if (!s) return;
      if (s === sampleDataFilter.label && !sampleDataFilter.visible) return;
      const d = c.mail_send_date || c.created_at || "";
      if (d > (latest.get(s) ?? "")) latest.set(s, d);
    });
    return Array.from(latest.keys()).sort((a, b) => (latest.get(b) ?? "").localeCompare(latest.get(a) ?? ""));
  }, [allCandidates, sampleDataFilter.label, sampleDataFilter.visible]);

  const candidates = useMemo(
    () => allCandidates.filter((c) => source === ALL_SOURCES || sourceOf(c) === source),
    [allCandidates, source]
  );

  const { data: analytics } = useQuery({
    queryKey: ["analytics", "rounds"],
    queryFn: async () => (await analyticsService.rounds()).data,
  });

  const agingByCandidate = useMemo(() => {
    const m = new Map<string, number>();
    (analytics?.candidates ?? []).forEach((c) => m.set(c.candidate_id, c.aging_days));
    return m;
  }, [analytics]);

  const counts = useMemo(() => {
    const m: Partial<Record<RoundBucket, number>> = {};
    candidates.forEach((c) => {
      const b = bucketOf(c);
      if (b) m[b] = (m[b] ?? 0) + 1;
    });
    return m;
  }, [candidates]);

  // The optional Round 3 folds into the "Round 2" bucket (lib/rounds) — when
  // anyone in the current source's data is actually sitting in Round 3, say
  // so on the bubble instead of silently mislabeling them "Round 2".
  const hasRound3 = useMemo(
    () => candidates.some((c) => (c.roundname ?? "").trim() === "Round 3"),
    [candidates]
  );

  const hired = useMemo(() => candidates.filter((c) => c.status === "Hired"), [candidates]);
  const onboardingCounts = useMemo(() => {
    const m: Record<string, number> = Object.fromEntries(ONBOARDING_STAGE_ORDER.map((s) => [s, 0]));
    hired.forEach((c) => {
      const stage = onboardingStageOf(c.onboarding_stage);
      m[stage] = (m[stage] ?? 0) + 1;
    });
    return m;
  }, [hired]);

  // Recruitment pipeline stages land on the DASHBOARD (the recruiter's
  // working view of those buckets); the bucket rides along as a query param
  // for a later improvement to auto-focus the matching panel. The hiring/
  // onboarding pills keep going to the Candidates page filtered to exactly
  // that stage — the Dashboard has no equivalent view for those yet.
  const goToBucket = (bucket: string) =>
    navigate(`/dashboard?bucket=${encodeURIComponent(bucket)}`);
  const goToOnboarding = (stage: string) =>
    navigate(`/rounds?bucket=Hired&onboarding=${encodeURIComponent(stage)}`);

  // Terminal stack height (3 bubbles + 2 gaps) — the connector into it is
  // height-matched the same way as every other connector.
  const TERMINAL_GAP = 14;
  const terminalStackHeight = TERMINAL_STAGES.length * BUBBLE + (TERMINAL_STAGES.length - 1) * TERMINAL_GAP;

  return (
    <PageContainer className="flex h-full flex-col">
      <PageHeader
        title="Recruitment Process Flow — Live"
        actions={
          <FilterDropdown
            label={source === ALL_SOURCES ? "All sources" : source}
            icon={<Tag className="h-3.5 w-3.5" />}
            options={["All sources", ...sources]}
            selected={source === ALL_SOURCES ? new Set<string>() : new Set([source])}
            onToggle={(v: string) => setSource(v === "All sources" ? ALL_SOURCES : v)}
            onClear={() => setSource(ALL_SOURCES)}
            width="w-48"
            single
            allowClear={false}
            searchable
            searchPlaceholder="Search sources…"
            searchLimit={12}
            align="right"
          />
        }
      />

      <div className="flex-1 space-y-10 overflow-auto rounded-2xl glass p-6 sm:p-8">
        {/* ── Main pipeline: New → Screening → Round 1 → Round 2 → Final ── */}
        <div>
          <h2 className="mb-5 text-xs font-bold uppercase tracking-wide text-muted-foreground">
            Recruitment — Interview Pipeline
          </h2>
          {/* One canvas, no scrollbar: the row WRAPS on narrower screens (the
              same way the hiring/onboarding rows do) instead of overflowing
              sideways — every pill stays visible at any width. */}
          <div className="flex flex-wrap items-start justify-center gap-y-4 pb-2">
            {PIPELINE_STAGES.map((stage) => {
              const aging = agingCountFor(candidates, stage.bucket, agingByCandidate);
              const showSteps = ROUND_STEP_BUCKETS.includes(stage.bucket);
              return (
                <div key={stage.bucket} className="flex items-start">
                  <div className="flex flex-col items-center">
                    <StageBubble
                      label={stage.bucket === "Round 2" && hasRound3 ? "Round 2 / 3" : stage.label}
                      count={counts[stage.bucket] ?? 0}
                      color={stage.color}
                      icon={stage.icon}
                      shape={stage.shape}
                      onClick={() => goToBucket(stage.bucket)}
                    />
                    <AgingBadge watch={aging.watch} stalled={aging.stalled} />
                    {showSteps && (
                      <StepChips
                        counts={stepCountsFor(candidates, stage.bucket, analytics?.scheduled ?? {})}
                      />
                    )}
                  </div>
                  <Connector />
                </div>
              );
            })}
            {/* Terminal branches: Hired / Rejected / Undecided */}
            <div className="flex items-center">
              <Connector h={terminalStackHeight} />
              <div className="flex flex-col" style={{ gap: TERMINAL_GAP }}>
                {TERMINAL_STAGES.map((stage) => (
                  <StageBubble
                    key={stage.bucket}
                    label={stage.label}
                    count={counts[stage.bucket] ?? 0}
                    color={stage.color}
                    icon={stage.icon}
                    shape="pill"
                    onClick={() => goToBucket(stage.bucket)}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* ── Post-hire progression, split into its two real phases: the
            HIRING PROCEDURE (Ready to Hire → offer prep → offer sent → the
            candidate's response) and then the ONBOARDING PROCESS (join date
            → joined → onboarding scheduling → checklist → complete). Both
            apply only to Hired candidates, continuing from the Recruitment
            pipeline above. ── */}
        <div>
          <h2 className="mb-1 text-xs font-bold uppercase tracking-wide text-muted-foreground">
            Hiring Procedure
          </h2>
          <p className="mb-5 text-[11px] text-muted-foreground">
            From Ready to Hire — offer preparation, sending, and the candidate's response.
          </p>
          <div className="flex flex-wrap items-start justify-center gap-y-3 pb-2">
            {HIRING_STAGES.map((stage, i) => (
              <div key={stage} className="flex items-start">
                <StageBubble
                  label={ONBOARDING_STAGE_LABELS[stage]}
                  count={onboardingCounts[stage] ?? 0}
                  color={ONBOARDING_STAGE_COLOR[stage]}
                  icon={ONBOARDING_ICON[stage]}
                  onClick={() => goToOnboarding(stage)}
                  size={ONBOARDING_BUBBLE}
                />
                {i < HIRING_STAGES.length - 1 && <Connector h={ONBOARDING_BUBBLE} w={14} />}
              </div>
            ))}
          </div>
        </div>

        <div>
          <h2 className="mb-1 text-xs font-bold uppercase tracking-wide text-muted-foreground">
            Onboarding Process
          </h2>
          <p className="mb-5 text-[11px] text-muted-foreground">
            After the offer is accepted — joining, onboarding scheduling, and allocation.
          </p>
          <div className="flex flex-wrap items-start justify-center gap-y-3 pb-2">
            {ONBOARDING_PHASE_STAGES.map((stage, i) => (
              <div key={stage} className="flex items-start">
                <StageBubble
                  label={ONBOARDING_STAGE_LABELS[stage]}
                  count={onboardingCounts[stage] ?? 0}
                  color={ONBOARDING_STAGE_COLOR[stage]}
                  icon={ONBOARDING_ICON[stage]}
                  onClick={() => goToOnboarding(stage)}
                  size={ONBOARDING_BUBBLE}
                />
                {i < ONBOARDING_PHASE_STAGES.length - 1 && (
                  <Connector h={ONBOARDING_BUBBLE} w={14} />
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </PageContainer>
  );
}
