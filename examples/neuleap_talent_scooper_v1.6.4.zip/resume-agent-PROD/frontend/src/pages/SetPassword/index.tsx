import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { motion } from "framer-motion";
import { isAxiosError } from "axios";
import { CheckCircle2, Eye, EyeOff, Loader2, Lock, XCircle } from "lucide-react";
import { authService } from "@/services/auth";
import { cn } from "@/lib/utils";
import logo from "@/logo/neuleap_logo.png";

// Shared by the forgot-password reset AND the new-account invite — the token's
// `purpose` (from validation) only changes the wording.
export default function SetPassword() {
  const { token = "" } = useParams();
  const navigate = useNavigate();

  const [checking, setChecking] = useState(true);
  const [valid, setValid] = useState(false);
  const [purpose, setPurpose] = useState<string | null>(null);

  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    authService
      .checkResetToken(token)
      .then((res) => {
        if (!alive) return;
        setValid(res.valid);
        setPurpose(res.purpose);
      })
      .catch(() => alive && setValid(false))
      .finally(() => alive && setChecking(false));
    return () => {
      alive = false;
    };
  }, [token]);

  const isInvite = purpose === "invite";

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (password.length < 6) {
      setError("Password must be at least 6 characters.");
      return;
    }
    if (password !== confirm) {
      setError("Passwords don't match.");
      return;
    }
    setSubmitting(true);
    try {
      await authService.resetPassword(token, password);
      setDone(true);
    } catch (err) {
      setError(
        isAxiosError(err)
          ? err.response?.data?.detail ?? "Couldn't set your password. Try again."
          : "Couldn't set your password. Try again."
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-background px-4">
      <div className="gradient-mesh pointer-events-none absolute inset-0 opacity-70" />
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
        className="surface-float relative w-full max-w-sm p-8"
      >
        <div className="flex flex-col items-center text-center">
          <img src={logo} alt="Talents Scooper" className="h-12 w-12 rounded-xl object-cover" />
          <h1 className="mt-4 text-[22px] font-semibold tracking-[-0.02em] text-ink">
            {isInvite ? "Set up your account" : "Set a new password"}
          </h1>
        </div>

        {checking ? (
          <div className="mt-8 flex items-center justify-center gap-2 text-sm text-ink-mute">
            <Loader2 className="h-4 w-4 animate-spin" /> Checking your link…
          </div>
        ) : !valid ? (
          <div className="mt-7 flex flex-col items-center gap-3 text-center">
            <XCircle className="h-10 w-10 text-red-500" />
            <p className="text-sm text-ink">
              This link is invalid or has expired. Please request a new one.
            </p>
            <button onClick={() => navigate("/forgot-password")} className="btn-brand mt-2 w-full">
              Request a new link
            </button>
          </div>
        ) : done ? (
          <div className="mt-7 flex flex-col items-center gap-3 text-center">
            <CheckCircle2 className="h-10 w-10 text-emerald-500" />
            <p className="text-sm text-ink">
              Your password is set. You can now sign in{isInvite ? " to your new account" : ""}.
            </p>
            <button onClick={() => navigate("/login")} className="btn-brand mt-2 w-full">
              Go to sign in
            </button>
          </div>
        ) : (
          <form onSubmit={onSubmit} className="mt-7 space-y-4">
            <p className="text-center text-sm text-ink-mute">
              {isInvite
                ? "Choose a password to activate your account."
                : "Choose a new password for your account."}
            </p>
            <div className="space-y-1.5">
              <label htmlFor="password" className="text-xs font-medium text-ink-mute">
                New password
              </label>
              <div className="relative">
                <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-mute" />
                <input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  autoComplete="new-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="At least 6 characters"
                  className="w-full rounded-xl border border-border bg-secondary/40 py-2.5 pl-9 pr-10 text-sm text-ink outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/30"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  aria-label={showPassword ? "Hide password" : "Show password"}
                  className="absolute right-2 top-1/2 inline-flex h-7 w-7 -translate-y-1/2 items-center justify-center rounded-lg text-ink-mute transition-colors hover:bg-secondary hover:text-ink"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>
            <div className="space-y-1.5">
              <label htmlFor="confirm" className="text-xs font-medium text-ink-mute">
                Confirm password
              </label>
              <div className="relative">
                <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-mute" />
                <input
                  id="confirm"
                  type={showPassword ? "text" : "password"}
                  autoComplete="new-password"
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                  placeholder="Re-enter password"
                  className="w-full rounded-xl border border-border bg-secondary/40 py-2.5 pl-9 pr-3 text-sm text-ink outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/30"
                  required
                />
              </div>
            </div>

            {error && (
              <p className="rounded-lg bg-red-500/10 px-3 py-2 text-xs font-medium text-red-600 dark:text-red-400">
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={submitting}
              className={cn("btn-brand w-full", submitting && "cursor-not-allowed")}
            >
              {submitting ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" /> Saving…
                </>
              ) : isInvite ? (
                "Activate account"
              ) : (
                "Set new password"
              )}
            </button>
          </form>
        )}
      </motion.div>
    </div>
  );
}
