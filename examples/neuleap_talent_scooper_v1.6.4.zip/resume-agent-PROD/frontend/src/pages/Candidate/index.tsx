import { useEffect, useRef, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  ArrowLeft,
  Mail,
  Phone,
  MapPin,
  Building2,
  GraduationCap,
  Briefcase,
  FileText,
  ChevronRight,
  CalendarDays,
  GitBranch,
  Clock,
  TrendingUp,
  Loader2,
  Sparkles,
  Award,
  Route as RouteIcon,
  FolderGit2,
  History,
  Settings2,
  Quote,
  Brain,
  CheckCircle2,
  CircleDashed,
  XCircle,
  ClipboardList,
  Zap,
  ChevronDown,
  Check,
  X,
  ShieldAlert,
  StickyNote,
  Paperclip,
} from "lucide-react";
import AnalysisReportBody, { parseAnalysisReport } from "@/components/candidate/AnalysisReport";
import AnalysisReportModal from "@/components/candidate/AnalysisReportModal";
import { useRecruiterApplyPermission } from "@/hooks/useCanApplyPredictedNba";
import NbaCommentDialog from "@/components/candidate/NbaCommentDialog";
import { AddNoteDialog, EditRemarkDialog, NoteBadge, ReferralBadge, RemarkBadge, StickyNoteCard, StickyRemarkCard } from "@/components/candidate/CandidateNote";
import InviteBlockBadge from "@/components/candidate/InviteBlockBadge";
import ConfirmDialog from "@/components/common/ConfirmDialog";
import {
  NbaModal,
  suggestedNba,
  nbaLabel,
  type NbaOverride,
} from "@/components/candidate/NextActionOverride";
import { EmailDraftBadge, EmailDraftReviewModal } from "@/components/candidate/EmailDraftReview";
import { candidatesService } from "@/services/candidates";
import { roundsService } from "@/services/rounds";
import { settingsService, type CandidateSectionsSettings } from "@/services/settings";
import { INTERVIEW_MODE_OPTIONS, interviewService, type InterviewMode } from "@/services/interview";
import { useAuth } from "@/context/AuthContext";
import type { CandidateMaster } from "@/types";
import { motion } from "framer-motion";
import { cn, titleCase, initialsOf, formatExperience } from "@/lib/utils";
import { statusBadge, streamBadge } from "@/lib/badges";
import { effectiveStatus, roundLabel, agingDaysFor } from "@/lib/rounds";
import ResumeViewerModal from "@/components/candidate/ResumeViewerModal";
import InterviewQuestionsPanel from "@/components/candidate/InterviewQuestionsPanel";
import BentoGrid from "@/components/bento/BentoGrid";
import BentoCard from "@/components/bento/BentoCard";
import BentoStat from "@/components/bento/BentoStat";
import CareerTimeline from "@/components/candidate/detail/CareerTimeline";
import CertificationCard from "@/components/candidate/detail/CertificationCard";
import SkillCloud from "@/components/candidate/detail/SkillCloud";
import RoundHistory from "@/components/candidate/detail/RoundHistory";
import ActionsAuditLog from "@/components/candidate/detail/ActionsAuditLog";
import StageTransitionNotes from "@/components/candidate/detail/StageTransitionNotes";
import EntryResolution from "@/components/candidate/detail/EntryResolution";
import OnboardingPanel from "@/components/candidate/detail/OnboardingPanel";
import PageContainer from "@/components/layout/PageContainer";
import PageHeader from "@/components/layout/PageHeader";
import ScoreBreakdown, { hasScoreBreakdown } from "@/components/candidate/ScoreBreakdown";
import NlrsScoreBreakdown, { hasNlrsBreakdown } from "@/components/candidate/NlrsScoreBreakdown";

// Mirrors the backend default (app.services.candidate_sections_config) so the
// page never flashes the wrong state before the Settings query resolves.
const DEFAULT_SECTIONS: CandidateSectionsSettings = {
  quick_signals: false,
  thinking_summary: false,
  ats_breakdown: false,
  nlrs_breakdown: true,
  skills: false,
  certificates: true,
  career_timeline: false,
  round_history: true,
};

// Evidence quotes are all tucked behind the "Read more" toggle — the Candidate
// Summary shows only the narrative paragraph until the recruiter expands it.
const EVIDENCE_PREVIEW = 0;

// Priority chip styling, keyed by next_action.priority_tone (Model B triage).
const PRIORITY_CHIP: Record<string, string> = {
  urgent: "border-rose-500/30 bg-rose-400/10 text-rose-500",
  high: "border-orange-500/30 bg-orange-400/10 text-orange-500",
  medium: "border-amber-500/30 bg-amber-400/10 text-amber-500",
  low: "border-slate-400/30 bg-slate-400/10 text-slate-500",
  muted: "border-border bg-secondary text-ink-mute",
};

function Pill({ label, className }: { label: string; className: string }) {
  return (
    <span className={cn("inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold", className)}>
      {label}
    </span>
  );
}

function InfoRow({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ElementType;
  label: string;
  value: string | number | null;
}) {
  if (!value && value !== 0) return null;
  return (
    <div className="flex items-start gap-2.5">
      <Icon className="mt-0.5 h-3.5 w-3.5 shrink-0 text-ink-mute" />
      <div>
        <span className="text-[10px] uppercase tracking-wide text-ink-mute">{label}</span>
        <div className="text-xs font-medium text-ink">{value}</div>
      </div>
    </div>
  );
}

// JSONB list columns arrive as arrays or legacy " · "-joined strings.
function toList(v: string[] | string | null | undefined): string[] {
  if (Array.isArray(v)) return v.map(String).filter(Boolean);
  if (typeof v === "string" && v.trim()) return v.split(" · ").filter(Boolean);
  return [];
}

// job_roles is structured [{role, company, months}] (legacy: plain strings).
function formatRoles(v: CandidateMaster["job_roles"]): string[] {
  if (!Array.isArray(v)) return toList(v as string | null | undefined);
  return v
    .map((r) => {
      if (typeof r === "string") return r;
      if (r && typeof r === "object") {
        const role = (r.role ?? "").toString().trim();
        const company = (r.company ?? "").toString().trim();
        const m = typeof r.months === "number" ? r.months : null;
        const d = m ? ` (${m >= 12 ? `${(m / 12).toFixed(1)}y` : `${m}mo`})` : "";
        const head = [role, company].filter(Boolean).join(" @ ");
        return head ? head + d : "";
      }
      return "";
    })
    .filter(Boolean);
}

// Switches = number of job changes = (count of roles in the work history) − 1, ≥ 0.
// Derived from the same job_roles the Career Timeline shows so the page stays
// self-consistent. The stored total_companieswitched (LLM-reported) is unreliable,
// so we recompute whenever roles are present and fall back only when they aren't.
function countSwitches(
  jobRoles: CandidateMaster["job_roles"],
  stored: number | null | undefined
): number {
  if (Array.isArray(jobRoles)) {
    const roles = jobRoles.filter((r) =>
      typeof r === "string"
        ? r.trim() !== ""
        : !!r && ((r.role ?? "").toString().trim() !== "" || (r.company ?? "").toString().trim() !== "")
    );
    if (roles.length > 0) return Math.max(0, roles.length - 1);
  }
  return stored ?? 0;
}

export default function Candidate() {
  const { candidateId } = useParams<{ candidateId: string }>();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { isAdmin, canAccessRecruiting } = useAuth();
  const { canApplyFor } = useRecruiterApplyPermission();
  const [resumeOpen, setResumeOpen] = useState(false);
  const [resumeWhich, setResumeWhich] = useState<"current" | "pending">("current");
  const [interviewOpen, setInterviewOpen] = useState(false);
  // Extra aptitude modes layered onto "Generate Interview Questions" — picked via
  // its dropdown, combined into the kit alongside the standard questions.
  const [interviewModes, setInterviewModes] = useState<Set<string>>(new Set());
  // Generate generic, cohort-uniform questions (a placement-drive set) rather
  // than ones grounded in this candidate's own profile — the basis for a
  // reusable question bank.
  const [avoidPersonalization, setAvoidPersonalization] = useState(false);
  const [modesOpen, setModesOpen] = useState(false);
  const modesRef = useRef<HTMLDivElement>(null);
  // Question-mode list is config-driven (Settings → Interview Question
  // Generation); fall back to the built-in defaults until it loads.
  const { data: modeOptions = INTERVIEW_MODE_OPTIONS } = useQuery({
    queryKey: ["interview-modes"],
    queryFn: async () => (await interviewService.getModes()).data.map((m) => ({ key: m.key, label: m.label })),
    staleTime: 60_000,
  });
  useEffect(() => {
    if (!modesOpen) return;
    const onDown = (e: MouseEvent) => {
      if (modesRef.current && !modesRef.current.contains(e.target as Node)) setModesOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [modesOpen]);
  const [uploadNote, setUploadNote] = useState<string | null>(null);
  const [showAllEvidence, setShowAllEvidence] = useState(false);
  // Recruiter override of the "Proposed Next Best Action" box — opened via the box's
  // "Update" button; persists on candidate_master (see NextActionOverride.tsx).
  const [nbaModalOpen, setNbaModalOpen] = useState(false);
  // The email draft "ready for review" badge next to that box opens this.
  const [draftReviewOpen, setDraftReviewOpen] = useState(false);
  // "Report" hero button opens the same Analysis Report popover the Dashboard uses.
  const [reportOpen, setReportOpen] = useState(false);

  const { data: c, isLoading, isError } = useQuery({
    queryKey: ["candidate", candidateId],
    queryFn: async () => (await candidatesService.get(candidateId!)).data,
    enabled: !!candidateId,
  });

  // Which optional sections are enabled — shared across every user (Settings
  // → Candidate Page Sections), not a per-candidate or per-recruiter setting.
  const { data: sections = DEFAULT_SECTIONS } = useQuery({
    queryKey: ["candidate-sections-config"],
    queryFn: async () => (await settingsService.getCandidateSections()).data,
    staleTime: 5 * 60 * 1000,
  });

  // TEMP — Settings → Legacy Features (Admin only). Defaults to hidden; see
  // app/services/legacy_features_config.py.
  const { data: legacyFeatures } = useQuery({
    queryKey: ["legacy-features-config"],
    queryFn: async () => (await settingsService.getLegacyFeatures()).data,
    staleTime: 5 * 60 * 1000,
  });

  const { data: rounds = [] } = useQuery({
    queryKey: ["rounds", candidateId],
    queryFn: async () => (await roundsService.listForCandidate(candidateId!)).data,
    enabled: !!candidateId,
  });

  // Full processing + recruiter-action audit trail — L1 (mail intake) through L4
  // (recruiter actions). Rendered as the collapsed "Actions Audit Log" below Round
  // History, one flat reverse-chronological list.
  const { data: auditLog = [] } = useQuery({
    queryKey: ["audit-log", candidateId],
    queryFn: async () => (await candidatesService.auditLog(candidateId!)).data,
    enabled: !!candidateId,
  });

  // Every email draft this candidate has ever had — the audit log's "view email"
  // button opens the EXACT draft a given entry refers to (via its draft_id),
  // not just whichever one is currently pending.
  const { data: emailDrafts = [] } = useQuery({
    queryKey: ["email-drafts", candidateId],
    queryFn: async () => (await candidatesService.emailDrafts(candidateId!)).data,
    enabled: !!candidateId,
  });
  const [viewDraftId, setViewDraftId] = useState<number | null>(null);

  const invalidateCandidate = () => {
    queryClient.invalidateQueries({ queryKey: ["candidate", candidateId] });
    queryClient.invalidateQueries({ queryKey: ["candidates"] });
    // Every recruiter action on this page (resume upload, reapplication, NBA
    // override) writes an audit_log row — keep the Actions Audit Log in sync.
    queryClient.invalidateQueries({ queryKey: ["audit-log", candidateId] });
    queryClient.invalidateQueries({ queryKey: ["email-drafts", candidateId] });
  };

  const attachResume = useMutation({
    mutationFn: (file: File) => candidatesService.attachResume(candidateId!, file),
    onSuccess: (res) => {
      invalidateCandidate();
      setUploadNote(
        res.data?.extraction_ok === false
          ? "Resume saved — extraction didn't complete; it'll retry on the next run."
          : null,
      );
    },
  });

  const resolveReapplication = useMutation({
    mutationFn: (action: "accept" | "ignore") =>
      candidatesService.resolveReapplication(candidateId!, action),
    onSuccess: invalidateCandidate,
  });

  const updateNba = useMutation({
    mutationFn: ({ ov, comment }: { ov: NbaOverride; comment?: string }) =>
      candidatesService.updateNextAction(candidateId!, { key: ov.key, text: ov.text, comment }),
    onSuccess: invalidateCandidate,
  });
  // NBA apply/change routed through the comment popup (reason -> Action Log).
  const [pendingNba, setPendingNba] = useState<
    { kind: "apply" } | { kind: "override"; ov: NbaOverride } | null
  >(null);
  // Sticky note — add-anytime popup; latest note renders in the hero.
  const [noteDialogOpen, setNoteDialogOpen] = useState(false);
  const [confirmDeleteNote, setConfirmDeleteNote] = useState(false);
  const addNote = useMutation({
    mutationFn: (text: string) => candidatesService.addNote(candidateId!, text),
    onSuccess: () => {
      invalidateCandidate();
      setNoteDialogOpen(false);
    },
  });
  const deleteNote = useMutation({
    mutationFn: () => candidatesService.deleteNote(candidateId!),
    onSuccess: () => {
      invalidateCandidate();
      setConfirmDeleteNote(false);
    },
  });
  const [remarkDialogOpen, setRemarkDialogOpen] = useState(false);
  const setRemark = useMutation({
    mutationFn: (text: string) => candidatesService.setRemark(candidateId!, text),
    onSuccess: () => {
      invalidateCandidate();
      setRemarkDialogOpen(false);
    },
  });

  // Predicted (NLRS-based) NBA — same "Apply" action as the Dashboard popover,
  // available to every role. Only meaningful while the candidate is still New.
  const applyPredicted = useMutation({
    mutationFn: (comment?: string) => candidatesService.applyPredictedNba(candidateId!, comment),
    onSuccess: invalidateCandidate,
  });

  const updateOnboarding = useMutation({
    mutationFn: (body: Parameters<typeof candidatesService.updateOnboarding>[1]) =>
      candidatesService.updateOnboarding(candidateId!, body),
    onSuccess: invalidateCandidate,
  });

  // System Admin has no recruiting-workflow access (a pure back-office role —
  // see AuthContext.canAccessRecruiting). Frontend-only scoping.
  if (!canAccessRecruiting) {
    return (
      <PageContainer>
        <PageHeader title="Candidate" />
        <div className="flex flex-col items-center justify-center gap-3 rounded-2xl glass p-12 text-center">
          <ShieldAlert className="h-8 w-8 text-muted-foreground" />
          <p className="text-sm font-semibold text-foreground">Candidate profile is restricted</p>
          <p className="max-w-sm text-xs text-muted-foreground">
            This section is only available to Admin and Recruitment Manager accounts.
          </p>
        </div>
      </PageContainer>
    );
  }

  if (isLoading) {
    return (
      <div className="flex items-center gap-2 p-6 text-sm text-ink-mute">
        <Loader2 className="h-4 w-4 animate-spin" /> Loading candidate…
      </div>
    );
  }
  if (isError || !c) {
    return (
      <div className="p-6 text-sm text-red-400">
        Could not load candidate {candidateId}.{" "}
        <button onClick={() => navigate(-1)} className="underline">Go back</button>
      </div>
    );
  }

  const initials = c.name ? initialsOf(c.name) : "?";

  const projects = toList(c.projects);
  const analysisReport = parseAnalysisReport(c.analysis_report);
  const jobRoles = formatRoles(c.job_roles);
  const skills = toList(c.primary_skills);
  const switches = countSwitches(c.job_roles, c.total_companieswitched);
  const evidence = toList(c.evidence_snippets);
  const nextAction = c.next_action ?? null;
  // Display-only relabel of "Screening" → "Call" so the next-action sentence matches
  // the rest of the app (Round History, board). Stored stage stays "Screening".
  const nextActionLabel = nextAction
    ? nextAction.label.replace(/Screening/g, roundLabel("Screening"))
    : "";
  // Thinking & Evidence shows ONLY the LLM narrative. The deterministic ATS score
  // breakdown (appended by ats_scoring.merge_explanation, always starting with
  // "ATS NN/100 (deterministic)." and trailed by the timeline reconcile text) is
  // dropped here — it's already surfaced structurally in the Score Card. Splitting at
  // the marker covers every candidate without needing a re-extraction.
  const analysisText = (c.analysis ?? "")
    .split(/\n*\s*ATS\s+\d+\/100\s*\((?:deterministic|scored)\)/i)[0]
    .trim();
  // Visual treatment for the "Proposed Next Best Action" box, keyed off the
  // server-computed action verb (schedule/advance/await/none).
  const nextActionView =
    nextAction?.action === "await"
      ? { Icon: CircleDashed, cls: "text-amber-400" }
      : nextAction?.action === "none"
        ? nextAction.label.toLowerCase().includes("hired")
          ? { Icon: CheckCircle2, cls: "text-emerald-400" }
          : { Icon: XCircle, cls: "text-rose-400" }
        : { Icon: CheckCircle2, cls: "text-primary" };
  const openResume = (which: "current" | "pending") => {
    setResumeWhich(which);
    setResumeOpen(true);
  };

  const showEntryResolution =
    c.previously_seen || c.status === "Pending Resume";

  return (
    <PageContainer>
      <ResumeViewerModal
        open={resumeOpen}
        candidateId={c.candidate_id}
        fileName={resumeWhich === "pending" ? c.pending_review_file : c.s3_file_path}
        which={resumeWhich}
        onClose={() => setResumeOpen(false)}
      />
      <InterviewQuestionsPanel
        open={interviewOpen}
        candidateId={c.candidate_id}
        onClose={() => setInterviewOpen(false)}
        initialOptions={{
          modes: [...interviewModes] as InterviewMode[],
          avoid_personalization: avoidPersonalization,
        }}
      />
      <NbaCommentDialog
        open={!!pendingNba}
        title={pendingNba?.kind === "apply" ? "Apply predicted Next Best Action?" : "Change the Next Best Action?"}
        message={
          pendingNba?.kind === "apply"
            ? "Moves this candidate forward with their predicted action, right away."
            : "Updates the next action and runs its automation (stage move / email draft) right away."
        }
        pending={applyPredicted.isPending || updateNba.isPending}
        onCancel={() => setPendingNba(null)}
        onApply={(comment) => {
          if (pendingNba?.kind === "apply") applyPredicted.mutate(comment);
          else if (pendingNba?.kind === "override") updateNba.mutate({ ov: pendingNba.ov, comment });
          setPendingNba(null);
        }}
      />
      <ConfirmDialog
        open={confirmDeleteNote}
        tone="destructive"
        title="Delete this note?"
        message={
          <>
            The sticky note and the badge next to the name disappear everywhere. The note itself
            stays in the <span className="font-semibold text-foreground">Actions Audit Log</span>,
            along with a record of this deletion.
          </>
        }
        confirmLabel="Delete note"
        pending={deleteNote.isPending}
        onCancel={() => setConfirmDeleteNote(false)}
        onConfirm={() => deleteNote.mutate()}
      />
      <EditRemarkDialog
        open={remarkDialogOpen}
        candidateName={c.name ? titleCase(c.name) : c.candidate_id}
        current={c.latest_remark}
        pending={setRemark.isPending}
        onCancel={() => setRemarkDialogOpen(false)}
        onSave={(text) => setRemark.mutate(text)}
      />
      <AddNoteDialog
        open={noteDialogOpen}
        candidateName={c.name ? titleCase(c.name) : c.candidate_id}
        pending={addNote.isPending}
        onCancel={() => setNoteDialogOpen(false)}
        onSave={(text) => addNote.mutate(text)}
      />
      {nbaModalOpen && (
        <NbaModal
          candidate={c}
          current={c.next_action_override ?? undefined}
          suggested={suggestedNba(c)}
          onClose={() => setNbaModalOpen(false)}
          onSave={(ov) => {
            setPendingNba({ kind: "override", ov });
            setNbaModalOpen(false);
          }}
        />
      )}
      {draftReviewOpen && c.pending_email_draft && (
        <EmailDraftReviewModal
          draft={c.pending_email_draft}
          candidate={c}
          onClose={() => setDraftReviewOpen(false)}
          onUpdated={invalidateCandidate}
        />
      )}
      {viewDraftId != null && emailDrafts.find((d) => d.draft_id === viewDraftId) && (
        <EmailDraftReviewModal
          draft={emailDrafts.find((d) => d.draft_id === viewDraftId)!}
          candidate={c}
          onClose={() => setViewDraftId(null)}
          onUpdated={invalidateCandidate}
        />
      )}
      {reportOpen && (
        <AnalysisReportModal
          candidate={c}
          agingDays={agingDaysFor(c, new Map())}
          isAdmin={isAdmin}
          canApplyPredicted={canApplyFor(c.source)}
          onClose={() => setReportOpen(false)}
          onViewResume={() => {
            setReportOpen(false);
            openResume("current");
          }}
          onApplyPredicted={() => {
            setPendingNba({ kind: "apply" });
            setReportOpen(false);
          }}
          applyPending={applyPredicted.isPending}
          onOverrideSave={(ov) => {
            setPendingNba({ kind: "override", ov });
            setReportOpen(false);
          }}
          onReviewDraft={() => {
            setReportOpen(false);
            setDraftReviewOpen(true);
          }}
        />
      )}

      {/* Back nav */}
      <button
        onClick={() => navigate(-1)}
        className="flex items-center gap-1.5 text-xs text-ink-mute transition-colors hover:text-ink"
      >
        <ArrowLeft className="h-3.5 w-3.5" />
        Back
      </button>

      <BentoGrid>
        {/* ── HERO: identity + actions (span 12) ──────────────────────────── */}
        <BentoCard span={{ sm: 6, lg: 12 }}>
          {/* Referral clip — shown at the very top when the resume's sender is
              on the Settings → Referrals allow-list. Message (when set) plus
              "Referred by <sender>", or just "Referred by <sender>". */}
          {c.referral?.referred_by && (
            <div className="mb-3 flex items-start gap-2 rounded-lg border border-emerald-500/40 bg-emerald-500/10 px-3 py-2">
              <Paperclip className="mt-0.5 h-3.5 w-3.5 shrink-0 -rotate-45 text-emerald-600" />
              <div className="min-w-0 text-xs leading-relaxed text-emerald-800 dark:text-emerald-300">
                {c.referral.message && (
                  <span className="mr-1 font-medium text-emerald-900 dark:text-emerald-200">
                    {c.referral.message}
                  </span>
                )}
                <span className="whitespace-nowrap font-semibold">
                  Referred by: {c.referral.referred_by}
                </span>
              </div>
            </div>
          )}
          {/* Two independent rows — identity, then actions — instead of one flex
              row where a wide actions cluster used to fight identity for space on
              desktop (squeezing the name/badges/contact column and leaving the
              rest of the card blank). Each row now gets the card's full width. */}
          <div className="flex flex-col gap-4">
            <div className="flex flex-wrap items-start gap-4">
              <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl bg-primary/15 text-xl font-bold text-primary">
                {initials}
              </div>
              <div className="order-last ml-auto flex flex-wrap items-start justify-end gap-3">
                {c.latest_remark?.text && (
                  <StickyRemarkCard remark={c.latest_remark} onEdit={() => setRemarkDialogOpen(true)} />
                )}
                {c.latest_note?.text ? (
                  <StickyNoteCard
                    note={c.latest_note}
                    onAdd={() => setNoteDialogOpen(true)}
                    onDelete={() => setConfirmDeleteNote(true)}
                  />
                ) : (
                  <button
                    onClick={() => setNoteDialogOpen(true)}
                    title="Stick a note on this candidate — recorded in the Actions Audit Log"
                    className="inline-flex items-center gap-1 self-start rounded-md px-1.5 py-1 text-[10px] font-medium text-ink-mute/70 transition-colors hover:bg-amber-100/60 hover:text-amber-700 dark:hover:bg-amber-400/10"
                  >
                    <StickyNote className="h-3 w-3" />
                    Add note
                  </button>
                )}
              </div>
              <div className="min-w-0 flex-1">
                <div className="mb-1.5 flex flex-wrap items-center gap-2">
                  <h1 className="text-lg font-bold text-ink">{c.name ? titleCase(c.name) : "Unnamed Candidate"}</h1>
                  <ReferralBadge referral={c.referral} />
                  <InviteBlockBadge reason={c.invite_block_reason} />
                  <NoteBadge note={c.latest_note} />
                  <RemarkBadge remark={c.latest_remark} />
                  <span className="font-mono text-xs text-ink-mute">{c.candidate_id}</span>
                </div>
                <div className="mb-3 flex flex-wrap items-center gap-1.5">
                  <Pill label={effectiveStatus(c)} className={statusBadge(effectiveStatus(c))} />
                  {c.stream && <Pill label={c.stream} className={streamBadge(c.stream)} />}
                  {c.fresher_or_lateral && (
                    <Pill
                      label={c.fresher_or_lateral === "Fresher" ? "Fresher" : `Lateral · ${formatExperience(c.yearofexp)}`}
                      className="border-slate-500/30 bg-slate-400/10 text-slate-400"
                    />
                  )}
                </div>
                <div className="flex flex-wrap items-center gap-4">
                  {c.email && (
                    <span className="flex items-center gap-1.5 text-xs text-ink-mute">
                      <Mail className="h-3 w-3" /> {c.email}
                    </span>
                  )}
                  {c.phno && (
                    <span className="flex items-center gap-1.5 text-xs text-ink-mute">
                      <Phone className="h-3 w-3" /> {c.phno}
                    </span>
                  )}
                  {c.currentlocation && (
                    <span className="flex items-center gap-1.5 text-xs text-ink-mute">
                      <MapPin className="h-3 w-3" /> {c.currentlocation}
                    </span>
                  )}
                </div>
              </div>
            </div>
            <div className="flex w-full flex-col gap-2 border-t border-border pt-4 sm:flex-row sm:flex-wrap sm:items-stretch sm:border-t-0 sm:pt-0">
              <div className="flex w-full flex-col gap-2 sm:w-auto sm:flex-row">
                <button
                  onClick={() => openResume("current")}
                  disabled={!c.s3_file_path}
                  className="flex w-full items-center justify-center gap-1.5 rounded-xl border border-border px-3 py-2 text-xs font-medium text-ink transition-colors hover:border-primary/40 hover:bg-secondary disabled:cursor-not-allowed disabled:opacity-40 sm:w-auto"
                  title={c.s3_file_path ? "Open resume viewer" : "No resume on file"}
                >
                  <FileText className="h-3.5 w-3.5" />
                  View Resume
                </button>
                <button
                  onClick={() => setReportOpen(true)}
                  className="flex w-full items-center justify-center gap-1.5 rounded-xl border border-border px-3 py-2 text-xs font-medium text-ink transition-colors hover:border-primary/40 hover:bg-secondary sm:w-auto"
                  title="Open the Analysis Report"
                >
                  <ClipboardList className="h-3.5 w-3.5" />
                  Report
                </button>
                <button
                  onClick={() => setRemarkDialogOpen(true)}
                  className="flex w-full items-center justify-center gap-1.5 rounded-xl border border-sky-400/50 bg-sky-100/40 px-3 py-2 text-xs font-medium text-sky-700 transition-colors hover:bg-sky-200/50 dark:bg-sky-400/10 dark:hover:bg-sky-400/20 sm:w-auto"
                  title="Add/edit a remark — visible to the interviewer too"
                >
                  <StickyNote className="h-3.5 w-3.5" />
                  {c.latest_remark?.text ? "Edit Remark" : "Remark"}
                </button>
                {/* Hidden once the interview journey is decided — the current
                    round's verdict is in (Cleared/Rejected/Hired) or the
                    candidate reached a terminal status. No interview left to
                    prepare questions for. */}
                {!(
                  c.status === "Hired" ||
                  c.status === "Rejected" ||
                  ["Cleared", "Rejected", "Hired"].includes(c.round_status ?? "")
                ) && (
                <div ref={modesRef} className="relative flex w-full sm:w-auto">
                  <button
                    onClick={() => setInterviewOpen(true)}
                    className="flex flex-1 items-center justify-center gap-1.5 rounded-l-xl border border-r-0 border-primary/40 bg-primary/5 px-3 py-2 text-xs font-semibold text-primary transition-colors hover:bg-primary/10 sm:flex-none"
                  >
                    <Sparkles className="h-3.5 w-3.5" />
                    Generate Interview Questions
                    {interviewModes.size > 0 && (
                      <span className="rounded-full bg-primary/20 px-1.5 text-[10px] font-bold leading-4">
                        +{interviewModes.size}
                      </span>
                    )}
                    {avoidPersonalization && (
                      <span
                        title="Generic cohort questions (avoid personalization)"
                        className="rounded-full bg-emerald-500/20 px-1.5 text-[10px] font-bold leading-4 text-emerald-600"
                      >
                        generic
                      </span>
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={() => setModesOpen((o) => !o)}
                    title="Add aptitude question modes"
                    className="flex items-center justify-center rounded-r-xl border border-primary/40 bg-primary/5 px-2 text-primary transition-colors hover:bg-primary/10"
                  >
                    <ChevronDown className={cn("h-3.5 w-3.5 transition-transform", modesOpen && "rotate-180")} />
                  </button>
                  {modesOpen && (
                    <div className="absolute left-0 top-full z-40 mt-1.5 w-80 rounded-xl border border-border bg-card p-1.5 shadow-lg">
                      <div className="px-2 py-1 text-[10px] font-semibold uppercase tracking-wide text-ink-mute">
                        Combine with question modes
                      </div>
                      {modeOptions.map((opt) => {
                        const active = interviewModes.has(opt.key);
                        return (
                          <button
                            key={opt.key}
                            type="button"
                            onClick={() =>
                              setInterviewModes((prev) => {
                                const next = new Set(prev);
                                if (next.has(opt.key)) next.delete(opt.key);
                                else next.add(opt.key);
                                return next;
                              })
                            }
                            className="flex w-full items-start gap-2 rounded-lg px-2 py-1.5 text-left text-xs text-ink hover:bg-secondary"
                          >
                            <span
                              className={cn(
                                "mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded border transition-colors",
                                active ? "border-primary bg-primary text-white" : "border-border"
                              )}
                            >
                              {active && <Check className="h-3 w-3" />}
                            </span>
                            {opt.label}
                          </button>
                        );
                      })}
                      {interviewModes.size > 0 && (
                        <button
                          type="button"
                          onClick={() => setInterviewModes(new Set())}
                          className="mt-1 flex w-full items-center justify-between rounded-lg px-2 py-1 text-left text-[11px] font-medium text-ink-mute hover:bg-secondary hover:text-ink"
                        >
                          Clear selection
                          <X className="h-3 w-3" />
                        </button>
                      )}

                      {/* Generation flag — generic (cohort) vs personalized. */}
                      <div className="mt-1.5 border-t border-border/60 pt-1.5">
                        <button
                          type="button"
                          onClick={() => setAvoidPersonalization((v) => !v)}
                          className="flex w-full items-start gap-2 rounded-lg px-2 py-1.5 text-left text-xs text-ink hover:bg-secondary"
                        >
                          <span
                            className={cn(
                              "mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded border transition-colors",
                              avoidPersonalization ? "border-emerald-500 bg-emerald-500 text-white" : "border-border"
                            )}
                          >
                            {avoidPersonalization && <Check className="h-3 w-3" />}
                          </span>
                          <span className="min-w-0">
                            <span className="font-medium">Avoid personalization</span>
                            <span className="mt-0.5 block text-[10px] leading-snug text-ink-mute">
                              Generic questions for a whole cohort (placement drive) — not tied to this
                              candidate. Lets you save the set as a reusable question bank.
                            </span>
                          </span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
                )}
              </div>
              {nextAction && (
                <div className="flex w-full flex-col justify-center gap-1 rounded-xl border border-border px-3.5 py-2 text-left sm:w-auto sm:flex-1 sm:min-w-[240px]">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5">
                      <span className="text-[9px] font-semibold uppercase tracking-wider text-ink-mute">
                        Proposed Next Best Action
                      </span>
                      {!c.next_action_override && nextAction.priority_tier !== "none" && (
                        <span
                          className={cn(
                            "inline-flex items-center rounded-full border px-1.5 py-px text-[9px] font-bold uppercase tracking-wide",
                            PRIORITY_CHIP[nextAction.priority_tone] ?? PRIORITY_CHIP.muted,
                          )}
                        >
                          {nextAction.priority_label}
                        </span>
                      )}
                    </div>
                    <div className="flex shrink-0 items-center gap-1.5">
                      <EmailDraftBadge
                        draft={c.pending_email_draft}
                        onClick={() => setDraftReviewOpen(true)}
                      />
                      {isAdmin && (
                      <button
                        type="button"
                        onClick={() => setNbaModalOpen(true)}
                        title="Update Next Action"
                        className="flex items-center gap-1 rounded-md px-1.5 py-0.5 text-[9px] font-semibold text-primary transition-colors hover:bg-primary/10"
                      >
                        <Zap className="h-3 w-3" />
                        Update
                      </button>
                      )}
                    </div>
                  </div>
                  <span className="flex items-center gap-1.5 text-xs font-semibold text-ink">
                    {c.next_action_override ? (
                      <>
                        <Zap className="h-3.5 w-3.5 shrink-0 text-primary" />
                        {nbaLabel(c, c.next_action_override)}
                      </>
                    ) : (
                      <>
                        <nextActionView.Icon className={cn("h-3.5 w-3.5 shrink-0", nextActionView.cls)} />
                        {nextActionLabel}
                      </>
                    )}
                  </span>
                </div>
              )}
              {legacyFeatures?.interview_round_button && (
                <button
                  onClick={() => navigate(`/rounds/${c.candidate_id}`)}
                  className="btn-brand w-full shrink-0 justify-center px-3 py-2 text-xs sm:w-auto"
                >
                  Interview Round
                  <ChevronRight className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
          </div>
        </BentoCard>

        {/* ── Post-hire onboarding pipeline (Live Workflow) — only once Hired ── */}
        {c.status === "Hired" && (
          <BentoCard span={{ sm: 6, lg: 12 }} title="Onboarding" tone="success" icon={ClipboardList}>
            <OnboardingPanel
              c={c}
              onSetStage={(stage) => updateOnboarding.mutate({ stage })}
              onSetDate={(field, value) => updateOnboarding.mutate({ [field]: value })}
              onToggleChecklistItem={(key) => updateOnboarding.mutate({ checklist_item: key })}
            />
          </BentoCard>
        )}

        {/* ── Stage transition notes + full Actions Audit Log (full width) —
             both read the same audit trail; transition notes surface just the
             comments, the log below is the full flat reverse-chronological
             history, with a "view email" button on drafted/edited/sent rows. ── */}
        <StageTransitionNotes entries={auditLog} />
        <ActionsAuditLog entries={auditLog} onViewEmail={(draftId) => setViewDraftId(draftId)} />

        {/* ── Entry resolution (accent, full width) — only when applicable ── */}
        {showEntryResolution && (
          <BentoCard span={{ sm: 6, lg: 12 }} title="Entry Resolution" tone="warn" icon={Settings2}>
            <EntryResolution
              c={c}
              onViewResume={openResume}
              onAcceptReapplication={() => resolveReapplication.mutate("accept")}
              onIgnoreReapplication={() => resolveReapplication.mutate("ignore")}
              onUpload={(f) => attachResume.mutate(f)}
              reapplicationPending={resolveReapplication.isPending}
              uploadPending={attachResume.isPending}
              uploadError={attachResume.isError ? (attachResume.error as Error)?.message ?? "Upload failed" : null}
              uploadNote={uploadNote}
            />
          </BentoCard>
        )}

        {/* ── One-Line Summary + Round History share a row (same level) ──────── */}
        {c.role_context && (
          <BentoCard span={{ sm: 6, lg: 6 }} title="One-Line Summary" icon={Quote}>
            <p className="text-sm leading-relaxed text-ink break-words">{c.role_context}</p>
          </BentoCard>
        )}

        {sections.round_history && (
          <BentoCard span={{ sm: 6, lg: 6 }} title="Round History" icon={History}>
            <RoundHistory rounds={rounds} role={c.stream} />
          </BentoCard>
        )}

        {/* ── Detail columns: LEFT and RIGHT each stack independently (masonry).
             A "Read more" expansion grows only its own column — the other never
             stretches and cards flow up instead of leaving a row gap. Each column is
             one grid cell; cards inside flow with flex. ──────────────────────────── */}
        <motion.div className="flex flex-col gap-3 sm:col-span-6 lg:col-span-6">
          {/* LEFT: analysis report (same row as Certifications on the right),
              Thinking Summary, breakdowns, timeline, skills, file details. */}
          {analysisReport.length > 0 && (
            <BentoCard title="Analysis Report" icon={ClipboardList}>
              <div className="rounded-xl border border-border bg-secondary/20 p-3.5">
                <AnalysisReportBody c={c} />
              </div>
            </BentoCard>
          )}

          {sections.thinking_summary && (analysisText || evidence.length > 0) && (
            <BentoCard title="Thinking Summary" icon={Brain}>
              {analysisText && (
                <p className="text-xs leading-relaxed text-ink-mute">{analysisText}</p>
              )}
              {evidence.length > 0 && (
                <>
                  {(showAllEvidence ? evidence : evidence.slice(0, EVIDENCE_PREVIEW)).length > 0 && (
                    <ul className={cn("space-y-1.5", analysisText && "mt-3 border-t border-border/60 pt-3")}>
                      {(showAllEvidence ? evidence : evidence.slice(0, EVIDENCE_PREVIEW)).map((e, i) => (
                        <li key={i} className="flex items-start gap-2 text-xs leading-relaxed text-ink-mute">
                          <Quote className="mt-0.5 h-3 w-3 shrink-0 text-ink-mute/60" />
                          <span>&ldquo;{e}&rdquo;</span>
                        </li>
                      ))}
                    </ul>
                  )}
                  {evidence.length > EVIDENCE_PREVIEW && (
                    <button
                      onClick={() => setShowAllEvidence((v) => !v)}
                      className="mt-2 text-[11px] font-semibold text-primary transition-colors hover:text-primary/80"
                    >
                      {showAllEvidence
                        ? "Show less"
                        : `Read more — ${evidence.length - EVIDENCE_PREVIEW} supporting ${
                            evidence.length - EVIDENCE_PREVIEW === 1 ? "quote" : "quotes"
                          }`}
                    </button>
                  )}
                </>
              )}
            </BentoCard>
          )}

          {sections.ats_breakdown && hasScoreBreakdown(c) && (
            <BentoCard title="ATS Score Breakdown" icon={TrendingUp}>
              <ScoreBreakdown c={c} />
            </BentoCard>
          )}

          {sections.nlrs_breakdown && hasNlrsBreakdown(c) && (
            <BentoCard title="NLRS Score Breakdown" icon={TrendingUp}>
              <NlrsScoreBreakdown c={c} />
            </BentoCard>
          )}

          {sections.career_timeline && (
            <BentoCard title="Career Timeline" icon={RouteIcon}>
              <CareerTimeline c={c} />
            </BentoCard>
          )}

          {sections.skills && (
            <BentoCard title="Skills" icon={Sparkles}>
              <SkillCloud skills={skills} />
            </BentoCard>
          )}

          <BentoCard title="File" icon={FileText}>
            <div className="break-all font-mono text-[10px] text-ink-mute">
              {c.s3_file_path || "No file attached"}
            </div>
            <div className="mt-1 text-[10px] text-ink-mute">Source email: {c.E_id}</div>
            {c.source_mail_id && (
              <div className="mt-0.5 break-all text-[10px] text-ink-mute">
                From: <span className="font-mono">{c.source_mail_id}</span>
              </div>
            )}
          </BentoCard>
        </motion.div>

        <motion.div className="flex flex-col gap-3 sm:col-span-6 lg:col-span-6">
          {/* RIGHT: Certifications leads (same row as Analysis Report on the
              left), then Quick Signals, Experience & Education, Projects. */}
          {sections.certificates && (
          <BentoCard
            title="Certifications"
            icon={Award}
            actions={
              <span className="tnum rounded-full bg-amber-400/10 px-2 py-0.5 text-[10px] font-bold text-amber-400">
                {Array.isArray(c.certificates) ? c.certificates.length : 0}
              </span>
            }
          >
            <CertificationCard c={c} />
          </BentoCard>
          )}

          {sections.quick_signals && (
          <BentoCard title="Quick Signals" icon={TrendingUp}>
            <div className="grid grid-cols-2 gap-3">
              <BentoStat
                icon={Briefcase}
                label="Experience"
                value={c.fresher_or_lateral === "Fresher" ? "Fresher" : formatExperience(c.yearofexp ?? 0)}
              />
              <BentoStat
                icon={Clock}
                label="Career Gap"
                tone={(c.gap_count ?? 0) > 0 ? "warn" : "good"}
                value={
                  c.gap_months
                    ? c.gap_months >= 12
                      ? +(c.gap_months / 12).toFixed(1)
                      : c.gap_months
                    : 0
                }
                unit={
                  c.gap_months
                    ? c.gap_months >= 12
                      ? `yrs${(c.gap_count ?? 0) > 1 ? ` · ${c.gap_count} gaps` : ""}`
                      : `mo${(c.gap_count ?? 0) > 1 ? ` · ${c.gap_count} gaps` : ""}`
                    : "none"
                }
              />
              <BentoStat
                icon={GitBranch}
                label="Switches"
                value={switches}
                tone={switches >= 3 ? "warn" : "default"}
              />
              <BentoStat
                icon={Building2}
                label="Current Co."
                value={c.currentcompany ?? (c.fresher_or_lateral === "Fresher" ? "—" : "—")}
              />
            </div>
          </BentoCard>
          )}

          <BentoCard title="Experience & Education" icon={GraduationCap}>
            <div className="space-y-3">
              <InfoRow icon={GraduationCap} label="College" value={c.clg} />
              <InfoRow
                icon={GraduationCap}
                label="Highest Degree"
                value={
                  c.highest_coursecompleted
                    ? `${c.highest_coursecompleted}${c.education_status ? ` (${c.education_status})` : ""}`
                    : null
                }
              />
              <InfoRow
                icon={CalendarDays}
                label={c.education_status === "pursuing" ? "Expected Passout" : "Passout Year"}
                value={c.passoutyr}
              />
              <InfoRow
                icon={GraduationCap}
                label="CGPA"
                value={c.cgpa != null ? c.cgpa.toFixed(1) : null}
              />
              <InfoRow icon={GitBranch} label="Domain" value={c.domain} />
              {jobRoles.length > 0 && (
                <div>
                  <span className="text-[10px] uppercase tracking-wide text-ink-mute">Company History</span>
                  <div className="mt-1.5 space-y-1">
                    {jobRoles.map((role, i) => (
                      <div key={i} className="flex items-center gap-2 text-xs text-ink">
                        <Briefcase className="h-3 w-3 shrink-0 text-ink-mute" />
                        {role}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </BentoCard>

          {projects.length > 0 && (
            <BentoCard title="Projects" icon={FolderGit2}>
              <div className="grid grid-cols-1 gap-2">
                {projects.map((p, i) => (
                  <div key={i} className="rounded-xl bg-secondary/40 px-3 py-2">
                    <div className="text-xs font-medium leading-relaxed text-ink">{p.trim()}</div>
                    {c.stream && (
                      <span className={cn("mt-1 inline-block rounded-full border px-1.5 py-0.5 text-[9px] font-semibold", streamBadge(c.stream))}>
                        {c.stream}
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </BentoCard>
          )}
        </motion.div>
      </BentoGrid>
    </PageContainer>
  );
}
