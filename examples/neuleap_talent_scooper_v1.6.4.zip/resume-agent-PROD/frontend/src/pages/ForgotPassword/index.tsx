import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { isAxiosError } from "axios";
import { ArrowLeft, CheckCircle2, Loader2, Mail } from "lucide-react";
import { authService } from "@/services/auth";
import { cn } from "@/lib/utils";
import logo from "@/logo/neuleap_logo.png";

export default function ForgotPassword() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      await authService.forgotPassword(email);
      // The endpoint always returns 200 (never reveals whether the email
      // exists), so a success screen is safe regardless.
      setSent(true);
    } catch (err) {
      setError(
        isAxiosError(err) && !err.response
          ? "Can't reach the server. Try again."
          : "Something went wrong. Try again."
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-background px-4">
      <div className="gradient-mesh pointer-events-none absolute inset-0 opacity-70" />
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
        className="surface-float relative w-full max-w-sm p-8"
      >
        <div className="flex flex-col items-center text-center">
          <img src={logo} alt="Talents Scooper" className="h-12 w-12 rounded-xl object-cover" />
          <h1 className="mt-4 text-[22px] font-semibold tracking-[-0.02em] text-ink">
            Reset your password
          </h1>
          <p className="mt-2 max-w-[280px] text-sm text-ink-mute">
            Enter your account email and we'll send you a link to set a new password.
          </p>
        </div>

        {sent ? (
          <div className="mt-7 flex flex-col items-center gap-3 text-center">
            <CheckCircle2 className="h-10 w-10 text-emerald-500" />
            <p className="text-sm text-ink">
              If <span className="font-semibold">{email}</span> is a registered account, a
              reset link is on its way. Check your inbox (and spam).
            </p>
            <p className="text-xs text-ink-mute">The link expires in 1 hour.</p>
            <button onClick={() => navigate("/login")} className="btn-brand mt-2 w-full">
              Back to sign in
            </button>
          </div>
        ) : (
          <form onSubmit={onSubmit} className="mt-7 space-y-4">
            <div className="space-y-1.5">
              <label htmlFor="email" className="text-xs font-medium text-ink-mute">
                Email
              </label>
              <div className="relative">
                <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-mute" />
                <input
                  id="email"
                  type="email"
                  autoComplete="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@company.com"
                  className="w-full rounded-xl border border-border bg-secondary/40 py-2.5 pl-9 pr-3 text-sm text-ink outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/30"
                  required
                />
              </div>
            </div>

            {error && (
              <p className="rounded-lg bg-red-500/10 px-3 py-2 text-xs font-medium text-red-600 dark:text-red-400">
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={submitting}
              className={cn("btn-brand w-full", submitting && "cursor-not-allowed")}
            >
              {submitting ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" /> Sending…
                </>
              ) : (
                "Send reset link"
              )}
            </button>

            <button
              type="button"
              onClick={() => navigate("/login")}
              className="flex w-full items-center justify-center gap-1.5 text-xs font-medium text-ink-mute transition-colors hover:text-ink"
            >
              <ArrowLeft className="h-3.5 w-3.5" /> Back to sign in
            </button>
          </form>
        )}
      </motion.div>
    </div>
  );
}
