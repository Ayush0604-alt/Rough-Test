import { useState, useMemo, useEffect } from "react";
import { useParams, useNavigate, useSearchParams } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  ArrowLeft,
  Plus,
  Calendar,
  CalendarDays,
  Tag,
  ChevronRight,
  CheckCircle2,
  Loader2,
  AlertTriangle,
  Search,
  X,
  ExternalLink,
  ClipboardCheck,
  ChevronDown,
  Lock,
  Clock,
  SlidersHorizontal,
  Award,
  ArrowUpDown,
  ChevronUp,
  ListChecks,
  Filter,
  BarChart2,
  ClipboardList,
  Check,
  Download,
  ShieldAlert,
  Sparkles,
  Share2,
  Copy,
  CalendarClock,
  StickyNote,
} from "lucide-react";
import AnalysisReportBody, { hasAnalysisReport } from "@/components/candidate/AnalysisReport";
import {
  NBA_OPTIONS,
  NbaOptionsList,
  nbaStatus,
  suggestedNba,
  type NbaOverride,
} from "@/components/candidate/NextActionOverride";
import { EmailDraftReviewModal } from "@/components/candidate/EmailDraftReview";
import AnalysisReportModal from "@/components/candidate/AnalysisReportModal";
import { useRecruiterApplyPermission } from "@/hooks/useCanApplyPredictedNba";
import ResumeViewerModal from "@/components/candidate/ResumeViewerModal";
import { candidatesService } from "@/services/candidates";
import { roundsService } from "@/services/rounds";
import { interviewerService } from "@/services/interviewer";
import { candidateSlotsService } from "@/services/candidateSlots";
import { settingsService } from "@/services/settings";
import { analyticsService, agingTier } from "@/services/analytics";
import { sourceTagsService } from "@/services/sourceTags";
import { roundStageBucket, daysSince, certMatches, ROUND_FILTER_BUCKETS, roundLabel } from "@/lib/rounds";
import { onboardingStageOf } from "@/lib/onboarding";
import { allowedAdvance, showCtc } from "@/lib/interviewPlan";
import { ROUND_PRESETS } from "@/constants";
import type { CandidateMaster, Round } from "@/types";
import { parseCertificates } from "@/types/candidate";
import {
  resumeColumnFor,
  toStrList,
  jobRoleTitles,
  thinkingSummaryText,
  nextBestActionLabel,
  type ResumeColumn,
} from "@/config/screeningColumns";
import ColumnConfigModal from "@/components/candidate/ColumnConfigModal";
import ScoreBreakdown, {
  hasScoreBreakdown,
  NlrsBreakdown,
  hasNlrsBreakdown,
  ScorePopoverModal,
} from "@/components/candidate/ScoreBreakdown";
import JdMatchModal from "@/components/candidate/JdMatchModal";
import JdExplainModal from "@/components/candidate/JdExplainModal";
import NbaCommentDialog from "@/components/candidate/NbaCommentDialog";
import { NoteBadge, ReferralBadge, RemarkBadge } from "@/components/candidate/CandidateNote";
import InviteBlockBadge from "@/components/candidate/InviteBlockBadge";
import BulkNoteDialog from "@/components/candidate/BulkNoteDialog";
import HelpRequestBadge from "@/components/candidate/HelpRequestBadge";
import { type JdMatchResult } from "@/services/jdMatch";
import BulkFilterModal, {
  EMPTY_BULK_FILTERS,
  bulkFilterMatches,
  activeBulkColumnKeys,
  bulkActiveCount,
  loadBulkFilters,
  saveBulkFilters,
  normalizeLocation,
  candidateRoleLabels,
  type BulkFilters,
} from "@/components/candidate/BulkFilterModal";
import { cn, titleCase, initialsOf, formatExperience, formatScore } from "@/lib/utils";
import PageHeader from "@/components/layout/PageHeader";
import PageContainer from "@/components/layout/PageContainer";
import { useAuth } from "@/context/AuthContext";
import Pagination from "@/components/common/Pagination";
import FilterDropdown from "@/components/common/FilterDropdown";
import { ALL_YEARS, yearOf, pickerYears, useGlobalYear } from "@/lib/year";
import { ALL_SOURCES, sourceOf, useGlobalSource, useSampleDataFilter } from "@/lib/source";
import { ALL_MONTHS, MONTH_NAMES, monthOf, useGlobalMonth } from "@/lib/month";
import { usePagination } from "@/hooks/usePagination";

// Rows-per-page for the Candidates table — defaults to 25, adjustable via the
// picker next to Pagination, and remembered across visits the same way other
// per-user table prefs (column config, panel focus, …) are.
const PAGE_SIZE_OPTIONS = [25, 50, 100, 200] as const;
const PAGE_SIZE_KEY = "screening-page-size";

function loadPageSize(): number {
  try {
    const raw = Number(localStorage.getItem(PAGE_SIZE_KEY));
    if ((PAGE_SIZE_OPTIONS as readonly number[]).includes(raw)) return raw;
  } catch {
    /* localStorage unavailable — fall through to default */
  }
  return 25;
}

const OUTCOME_COLORS: Record<string, string> = {
  Pass: "text-emerald-400 bg-emerald-400/10 border-emerald-500/30",
  Fail: "text-red-400 bg-red-400/10 border-red-500/30",
  Hold: "text-yellow-400 bg-yellow-400/10 border-yellow-500/30",
  Pending: "text-sky-400 bg-sky-400/10 border-sky-500/30",
};

// The outcome value "Fail" is stored as-is (a DB trigger maps it to round_status
// 'Rejected'), but it's shown to recruiters as "Rejected". One mapping, used everywhere
// an outcome is rendered. "Hold" is retired from the UI (kept here for legacy rows).
const OUTCOME_LABELS: Record<string, string> = { Fail: "Rejected" };
const outcomeLabel = (o: string): string => OUTCOME_LABELS[o] ?? o;
// The three outcomes a recruiter can set on any round (Hold removed).
const OUTCOME_CHOICES = ["Pending", "Pass", "Fail"] as const;

function Label({ children }: { children: React.ReactNode }) {
  return <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">{children}</label>;
}

function ReadOnlyStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="min-w-0">
      <div className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide truncate">{label}</div>
      <div className="text-sm font-semibold text-foreground truncate">{value}</div>
    </div>
  );
}

function TextInput({
  value,
  onChange,
  placeholder,
  type = "text",
  className,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: string;
  className?: string;
}) {
  return (
    <input
      type={type}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className={cn(
        "w-full px-3 py-2 text-xs rounded-lg border border-border bg-secondary text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50",
        className,
      )}
    />
  );
}

// A pill-styled dropdown with checkbox options that can be multi-selected. Closes
// on outside-click / Escape. `footer` lets a caller append extra controls (e.g. the
// cert free-text keyword) inside the popover.
export default function Screening() {
  const { candidateId } = useParams<{ candidateId: string }>();
  const { canAccessRecruiting } = useAuth();

  // System Admin has no recruiting-workflow access (a pure back-office role —
  // see AuthContext.canAccessRecruiting). Frontend-only scoping: covers both
  // /rounds and /rounds/:candidateId since they're the same dispatcher.
  if (!canAccessRecruiting) {
    return (
      <PageContainer>
        <PageHeader title="Candidates" />
        <div className="flex flex-col items-center justify-center gap-3 rounded-2xl glass p-12 text-center">
          <ShieldAlert className="h-8 w-8 text-muted-foreground" />
          <p className="text-sm font-semibold text-foreground">Candidates is restricted</p>
          <p className="max-w-sm text-xs text-muted-foreground">
            This section is only available to Admin and Recruitment Manager accounts.
          </p>
        </div>
      </PageContainer>
    );
  }

  // No candidate in the URL → list candidates to screen. The needs-review worklist
  // is one click away. The per-candidate rounds view renders when an id is set.
  if (!candidateId) return <ScreeningList />;

  return <ScreeningDetail candidateId={candidateId} />;
}

// How long the candidate has sat in their current stage (in a round, or New).
// Tier colors: 🟢 ≤15 neutral · 🟡 >15 watch · 🔴 >30 stalled.
function DaysBadge({ days, label }: { days: number; label?: string }) {
  const tier = agingTier(days);
  const cls =
    tier === "stalled"
      ? "text-rose-600 bg-rose-500/10 border-rose-500/30"
      : tier === "watch"
        ? "text-amber-600 bg-amber-500/10 border-amber-500/30"
        : "text-slate-500 bg-slate-500/10 border-slate-500/30";
  return (
    <span
      title={label ?? "Days in current stage"}
      className={cn(
        "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-semibold",
        cls
      )}
    >
      <Clock className="h-2.5 w-2.5" />
      {days}d{tier === "stalled" ? " 🔴" : tier === "watch" ? " 🟡" : ""}
    </span>
  );
}

// The candidate's current round/stage, collapsing terminal statuses to a single
// label: Screening → Round 1/2/3 → Final → Hired/Rejected/Closed (New if no round).
function stageLabel(c: CandidateMaster): string {
  if (c.status === "Hired") return "Hired";
  if (c.status === "Rejected") return "Rejected";
  if (c.status === "Closed") return "Closed";
  if (c.status === "Undecided") return "Undecided";
  // A Fail round rejects the candidate while their lifecycle status stays "Active"
  // (the DB trigger flips round_status to 'Rejected', not status) — show Rejected,
  // not the round they were rejected at, so it matches the Reject filter bucket.
  if (c.round_status === "Rejected") return "Rejected";
  return c.roundname?.trim() || "New";
}

function stageCls(stage: string): string {
  if (stage === "Hired") return "text-blue-600 bg-blue-500/10 border-blue-500/30";
  if (stage === "Rejected") return "text-rose-600 bg-rose-500/10 border-rose-500/30";
  if (stage === "Closed") return "text-slate-500 bg-slate-500/10 border-slate-500/30";
  if (stage === "Undecided") return "text-yellow-600 bg-yellow-500/10 border-yellow-500/30";
  if (stage === "Final") return "text-amber-600 bg-amber-500/10 border-amber-500/30";
  if (stage === "Screening") return "text-sky-600 bg-sky-500/10 border-sky-500/30";
  if (stage.startsWith("Round")) return "text-violet-600 bg-violet-500/10 border-violet-500/30";
  return "text-slate-500 bg-slate-500/10 border-slate-500/30"; // New
}

const fmtReceived = (s: string | null) =>
  s
    ? new Date(s).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" })
    : "—";

// Sortable columns on the Rounds list. "received" (the default) orders by the date
// the résumé arrived. The header keys (name/stream/scheduled/round_status + the
// resume-field keys) are clickable sort columns; their per-row value comes from
// `sortKeyValue` in the component.
type SortKey =
  | "aging"
  | "ats"
  | "experience"
  | "received"
  | "name"
  | "stream"
  | "scheduled"
  | "round_status"
  | "highest_degree"
  | "passout_year"
  | "cgpa"
  | "fresher_or_lateral"
  | "career_gap"
  | "nlrs"
  | "email"
  | "phone"
  | "location"
  | "source"
  | "college"
  | "domain"
  | "current_company"
  | "projects"
  | "certificates"
  | "job_role"
  | "primary_skills"
  | "next_best_action"
  | "one_line_summary"
  | "thinking_summary"
  | "analysis_report"
  | "jd_match";

// Degree level → ordinal, so "Highest Degree" sorts by qualification, not alphabetically.
const DEGREE_RANK: Record<string, number> = { Diploma: 0, Bachelor: 1, Master: 2, PhD: 3 };

// Interview stage → progression ordinal, so "Round Status" sorts New → Call → Round 1…N →
// Final → Hired → Rejected → Closed instead of alphabetically.
function stageRank(stage: string): number {
  const order: Record<string, number> = {
    New: 0, Screening: 1, Final: 5, Hired: 6, Rejected: 7, Closed: 8, Undecided: 9,
  };
  if (stage in order) return order[stage];
  const m = /^Round\s*(\d+)/i.exec(stage);
  if (m) return 1 + Number(m[1]); // Round 1 → 2, Round 2 → 3, …
  return 99;
}

// A clickable table header that sorts by `sortKey`, toggling direction on repeat
// click and showing the active direction (↑/↓) — neutral ⇅ otherwise.
function SortTh({
  label,
  sortKey,
  sort,
  onSort,
  align = "left",
}: {
  label: string;
  sortKey: SortKey;
  sort: { key: SortKey; dir: "asc" | "desc" };
  onSort: (k: SortKey) => void;
  align?: "left" | "right";
}) {
  const active = sort.key === sortKey;
  const Icon = !active ? ArrowUpDown : sort.dir === "asc" ? ChevronUp : ChevronDown;
  return (
    <th className={cn("px-4 py-1.5", align === "right" && "text-right")}>
      <button
        onClick={() => onSort(sortKey)}
        title={`Sort by ${label}`}
        className={cn(
          "inline-flex items-center gap-1 font-semibold uppercase tracking-wide transition-colors hover:text-foreground",
          align === "right" && "flex-row-reverse",
          active && "text-primary"
        )}
      >
        {label}
        <Icon className="h-3 w-3" />
      </button>
    </th>
  );
}

function ScreeningList() {
  const navigate = useNavigate();
  const { isAdmin } = useAuth();
  const { canApplyFor } = useRecruiterApplyPermission();
  // Keep the search filter in the URL (?q=…) so back-navigation from a candidate's
  // Screening view (navigate(-1)) lands on the same filtered list, not a reset one.
  const [searchParams, setSearchParams] = useSearchParams();
  const search = searchParams.get("q") ?? "";
  // Merge updates so the search box never wipes an active deep-link filter
  // (?stage / ?arrived / ?aging) and vice-versa.
  const setSearch = (v: string) => {
    const next = new URLSearchParams(searchParams);
    if (v) next.set("q", v);
    else next.delete("q");
    setSearchParams(next, { replace: true });
  };
  const clearParam = (key: string) => {
    const next = new URLSearchParams(searchParams);
    next.delete(key);
    setSearchParams(next, { replace: true });
  };
  // Analytics deep-links: ?stage=Round 1 · ?arrived=today · ?aging=gt15|gt30.
  const stageFilter = searchParams.get("stage");
  const arrivedFilter = searchParams.get("arrived");
  const agingParam = searchParams.get("aging");
  const agingThreshold =
    agingParam && agingParam.startsWith("gt") ? Number(agingParam.slice(2)) : null;
  // Tier deep-links from the Candidate Analysis blocks: stalled | watch | ontrack.
  const tierParam = searchParams.get("tier");
  // Post-hire onboarding stage deep-link from the Workflow page's Offer→Onboarding
  // bubbles (?onboarding=ready_to_hire|offer_review|…). null onboarding_stage on a
  // Hired candidate reads as the first stage ("ready_to_hire").
  const onboardingParam = searchParams.get("onboarding");
  // Round filter — the single source of truth for round/bucket filtering, backed by
  // the ?bucket URL param (comma-separated for multi-select). Dashboard tiles/chart
  // deep-link here (?bucket=Round 1), so arriving from a tile pre-selects the dropdown
  // instead of fighting a hidden second filter. Buckets: New | Round 1 | Round 2 |
  // Final | Hired | Reject (Screening + no-round fold into New; Round 3 into Round 2).
  const selectedRounds = useMemo(
    () => new Set((searchParams.get("bucket") ?? "").split(",").filter(Boolean)),
    [searchParams]
  );
  const setRounds = (next: Set<string>) => {
    const params = new URLSearchParams(searchParams);
    if (next.size) params.set("bucket", [...next].join(","));
    else params.delete("bucket");
    setSearchParams(params, { replace: true });
  };
  // Multi-select: toggle a round in/out of the checked set (checklist style).
  const toggleRound = (r: string) => {
    const next = new Set(selectedRounds);
    next.has(r) ? next.delete(r) : next.add(r);
    setRounds(next);
  };
  // Certificate filter (local — not deep-linked). Checked cert tags are ANDed,
  // with the free-text keyword ANDed on top.
  // Experience is a multi-select checklist — checked values are ORed (empty
  // set = no filter for that facet).
  // Experience bands — single-select (radio). Each option is a [min, max) year
  // range (max = null means "and above"); a candidate passes if their experience
  // falls inside the chosen range. Ranges are half-open so they don't overlap.
  const EXPERIENCE_BANDS: Record<string, [number, number | null]> = {
    "0-2 years": [0, 2],
    "2-4 years": [2, 4],
    "4-6 years": [4, 6],
    "Above 6 years": [6, null],
  };
  const [expFilter, setExpFilter] = useState<Set<string>>(new Set());
  const matchExperience = (c: CandidateMaster): boolean => {
    if (expFilter.size === 0) return true;
    if (c.yearofexp == null) return false;
    const [min, max] = EXPERIENCE_BANDS[[...expFilter][0]];
    return c.yearofexp >= min && (max == null || c.yearofexp < max);
  };

  // Column sorting: received date (newest first) by default; a sortable header
  // switches to that metric (Aging / ATS / Experience), each toggling desc → asc
  // on repeat click.
  const [sort, setSort] = useState<{ key: SortKey; dir: "asc" | "desc" }>({
    key: "received",
    dir: "desc", // newest résumés first
  });
  const toggleSort = (key: SortKey) =>
    setSort((prev) =>
      prev.key === key
        ? { key, dir: prev.dir === "desc" ? "asc" : "desc" }
        : { key, dir: "desc" }
    );
  // Year / Month / Source — GLOBAL filters shared with the Dashboard (same
  // localStorage-backed hooks), surfaced here as a compact picker row next to
  // Pagination at the bottom rather than the top toolbar.
  const [year, setYear] = useGlobalYear();
  const [month, setMonth] = useGlobalMonth();
  const [source, setSource] = useGlobalSource();
  const [selectedTags, setSelectedTags] = useState<Set<string>>(new Set());
  const [certKeyword, setCertKeyword] = useState("");
  const toggleTag = (tag: string) =>
    setSelectedTags((prev) => {
      const next = new Set(prev);
      next.has(tag) ? next.delete(tag) : next.add(tag);
      return next;
    });
  const matchCert = (c: CandidateMaster): boolean => {
    const terms = [...selectedTags];
    const kw = certKeyword.trim();
    if (kw) terms.push(kw);
    return terms.every((term) => certMatches(c, term));
  };
  const certFilterActive = selectedTags.size > 0 || certKeyword.trim() !== "";

  const { data: candidates = [], isLoading, isError } = useQuery({
    queryKey: ["candidates"],
    queryFn: async () => (await candidatesService.list()).data,
  });

  // Per-candidate aging_days — drives both the ?aging filter and the days badge
  // shown on every card, so it's fetched for the list view (cached with Analytics).
  const { data: analytics } = useQuery({
    queryKey: ["analytics", "rounds"],
    queryFn: async () => (await analyticsService.rounds()).data,
  });

  // Admin-editable certificate tags (Settings page); empty until loaded.
  const { data: certTags = [] } = useQuery({
    queryKey: ["scoring", "cert_tags"],
    queryFn: async () => (await settingsService.getScoring()).data.cert_tags ?? [],
  });

  // Per-stream skill keyword lists (Settings → stream_keywords) — the common-skill chips
  // on the bulk filter's Primary Skills tab.
  const { data: skillGroups = {} } = useQuery({
    queryKey: ["scoring", "stream_keywords"],
    queryFn: async () => (await settingsService.getScoring()).data.stream_keywords ?? {},
  });

  // Source facets — each email carries its sender + the candidate_ids it produced. A
  // sender of "direct" is a manual file upload; anything else arrived by mail. Powers the
  // bulk Source filter without a per-row fetch.
  const { data: facets } = useQuery({
    queryKey: ["candidates", "facets"],
    queryFn: async () => (await candidatesService.facets()).data,
  });
  const sourceById = useMemo(() => {
    const m = new Map<string, "mail" | "manual">();
    facets?.emails.forEach((e) => {
      const src = (e.sender_mail_id ?? "").trim().toLowerCase() === "direct" ? "manual" : "mail";
      e.candidate_ids.forEach((id) => m.set(id, src));
    });
    return m;
  }, [facets]);

  // Distinct domain values across all candidates — the chip options on the bulk filter's
  // Domain tab (so recruiters can check known domains instead of guessing the spelling).
  const domainOptions = useMemo(() => {
    const set = new Set<string>();
    candidates.forEach((c) => {
      const d = c.domain?.trim();
      if (d) set.add(d);
    });
    return [...set].sort((a, b) => a.localeCompare(b));
  }, [candidates]);

  // Distinct locations — chips on the bulk filter's Location tab, normalized to "City, State"
  // (sub-locality / pincode / country dropped) so variants of the same place collapse.
  const locationOptions = useMemo(() => {
    const set = new Set<string>();
    candidates.forEach((c) => {
      const l = normalizeLocation(c.currentlocation);
      if (l) set.add(l);
    });
    return [...set].sort((a, b) => a.localeCompare(b));
  }, [candidates]);

  // Standard job-role buckets present in the data (raw titles classified to ≤2-word labels)
  // — the chips on the Job Role tab.
  const jobRoleOptions = useMemo(() => {
    const set = new Set<string>();
    candidates.forEach((c) => candidateRoleLabels(c.job_roles).forEach((l) => set.add(l)));
    return [...set].sort((a, b) => a.localeCompare(b));
  }, [candidates]);

  // Registered social-post source tags — the bulk filter's Source tab options.
  // Every REGISTERED tag (not just ones already stamped on a candidate), since a
  // recruiter may filter for a tag right after registering it, before any
  // candidate has arrived under it yet.
  const { data: sourceTagsData } = useQuery({
    queryKey: ["source-tags"],
    queryFn: async () => (await sourceTagsService.list()).data,
  });
  const sourceTagLabels = useMemo(
    () => (sourceTagsData?.tags ?? []).map((t) => t.label),
    [sourceTagsData],
  );

  // Recruiter-editable column config, saved to the backend (/settings/columns) via the
  // "Columns" button → shared by all users. The modal invalidates this query on save, so
  // the table updates immediately.
  const { data: columnConfig } = useQuery({
    queryKey: ["column-config"],
    queryFn: async () => (await settingsService.getColumns()).data,
  });
  // TEMP — Settings → Legacy Features (Admin only). Defaults to hidden; see
  // app/services/legacy_features_config.py.
  const { data: legacyFeatures } = useQuery({
    queryKey: ["legacy-features-config"],
    queryFn: async () => (await settingsService.getLegacyFeatures()).data,
    staleTime: 5 * 60 * 1000,
  });
  // Bulk filter — a single AND-ed filter object set in the "Filters" modal. Active
  // numeric/categorical facets ALSO force their column visible (see below), so the
  // table shows what was filtered on. Seeded from localStorage so it survives a reload.
  const [bulkFilters, setBulkFilters] = useState<BulkFilters>(loadBulkFilters);
  const [bulkModalOpen, setBulkModalOpen] = useState(false);
  const bulkCount = bulkActiveCount(bulkFilters);
  // Candidate whose ATS score-breakdown popover is open (clicked from the ATS column).
  const [atsBreakdown, setAtsBreakdown] = useState<CandidateMaster | null>(null);
  const [nlrsBreakdown, setNlrsBreakdown] = useState<CandidateMaster | null>(null);
  // Candidate whose Analysis Report popover is open (clicked from the candidate cell).
  const [analysisFor, setAnalysisFor] = useState<CandidateMaster | null>(null);
  // Email-draft "ready for review" badge (shown in the Analysis Report popover)
  // opens this — reviews/approves the draft generated by the last NBA selection.
  const [draftReviewOpen, setDraftReviewOpen] = useState(false);
  // "View Resume" inside the Analysis Report popover opens this on top of it.
  const [resumeFor, setResumeFor] = useState<CandidateMaster | null>(null);
  // Persist on every change (cleared from storage when no facet is active).
  useEffect(() => saveBulkFilters(bulkFilters), [bulkFilters]);

  // Next Best Action override — same "Update Next Action" control embedded at the
  // bottom of the Analysis Report popover on the Dashboard (NextActionOverride.tsx).
  // Persists on candidate_master (PATCH /next-action); the table's Next Best Action
  // column re-reads it off the refetched candidate row.
  const queryClient = useQueryClient();
  const updateNba = useMutation({
    mutationFn: ({ candidateId, ov, comment }: { candidateId: string; ov: NbaOverride; comment?: string }) =>
      candidatesService.updateNextAction(candidateId, { key: ov.key, text: ov.text, comment }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["candidates"] });
    },
  });

  // Predicted (NLRS-based) NBA — the key is always computed server-side, this
  // just accepts it. Available to both Admin and Recruiter, unlike the manual
  // override above. Only valid while the candidate is still in the New stage —
  // nothing about the candidate moves forward until this is called.
  const applyPredicted = useMutation({
    mutationFn: ({ candidateId, comment }: { candidateId: string; comment?: string }) =>
      candidatesService.applyPredictedNba(candidateId, comment),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["candidates"] }),
  });
  const [bulkNoteKind, setBulkNoteKind] = useState<null | "note" | "remark">(null);
  const bulkNote = useMutation({
    mutationFn: ({ ids, text, kind }: { ids: string[]; text: string; kind: "note" | "remark" }) =>
      candidatesService.bulkNote(ids, text, kind),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["candidates"] });
      setBulkNoteKind(null);
      setSelectedIds(new Set());
    },
  });
  const applyPredictedBulk = useMutation({
    mutationFn: ({ ids, comment }: { ids: string[]; comment?: string }) =>
      candidatesService.applyPredictedNbaBulk(ids, comment),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["candidates"] });
      setSelectedIds(new Set());
    },
  });

  // Bulk multiselect — checkbox column, header select-all-visible, and the
  // "Apply predicted NBA" bulk action bar. Only New-stage rows are selectable
  // (predicted_nba != null) since that's the only bulk action available today.
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const toggleSelected = (id: string) =>
    setSelectedIds((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });

  // Both the per-row "Apply" and the bulk-toolbar "Apply predicted NBA to N"
  // move candidates forward immediately with no undo — gate each behind a
  // confirmation instead of firing straight from the click.
  const [confirmApplyFor, setConfirmApplyFor] = useState<CandidateMaster | null>(null);
  // NBA change routed through the comment popup (Analysis Report override picker).
  const [pendingOverride, setPendingOverride] = useState<{ candidateId: string; name: string; ov: NbaOverride } | null>(null);
  const [confirmBulkOpen, setConfirmBulkOpen] = useState(false);
  // Every selected candidate's own source must allow it — a Recruiter can't
  // bulk-apply across a mixed selection that includes even one still-pending
  // source (matches the single-candidate "Admin review pending…" gate).
  const selectedCanApply = useMemo(
    () =>
      [...selectedIds].every((id) => canApplyFor(candidates.find((c) => c.candidate_id === id)?.source)),
    [selectedIds, candidates, canApplyFor]
  );

  const columnList = columnConfig?.columns ?? [];
  // Candidate keeps its special pinned-left rendering (avatar + name + profile link), so
  // it's gated here rather than via the registry. Defaults to shown until explicitly off.
  const showCandidate = columnList.find((c) => c.key === "candidate_name")?.visible ?? true;
  const showCol = (key: string) => columnList.find((c) => c.key === key)?.visible ?? true;

  // JD (Job Description) matching — on-demand, session-only. Results are keyed
  // by candidate_id; re-running "Match JD" against a different/edited JD
  // replaces the whole map (a candidate absent from the newest run reads as
  // "not scored" rather than showing a stale score from an earlier JD).
  const [jdMatchOpen, setJdMatchOpen] = useState(false);
  const [jdMatchResults, setJdMatchResults] = useState<Map<string, JdMatchResult>>(new Map());
  // The JD text the current scores were computed against + which candidate's
  // "why this score?" popup is open (null = closed).
  const [jdText, setJdText] = useState("");
  const [jdExplainFor, setJdExplainFor] = useState<{ id: string; name: string } | null>(null);

  // Operational columns honour the saved toggle, but a matching active bulk filter forces
  // its column on ("dynamic columns") even if toggled off — same promise as the registry ones.
  const showStream = showCol("stream") || bulkFilters.streams.length > 0;
  const showReceived = showCol("received") || !!bulkFilters.dateFrom || !!bulkFilters.dateTo;
  const showScheduled = showCol("scheduled");
  const showAging =
    showCol("aging") || bulkFilters.aging.min != null || bulkFilters.aging.max != null;
  const showAts = showCol("ats") || bulkFilters.ats.min != null || bulkFilters.ats.max != null;
  const showAnalysisReport = showCol("analysis_report");
  const showRoundStatus = showCol("round_status") || bulkFilters.roundStatus.length > 0;
  const showInterview = showCol("interview") && !!legacyFeatures?.interview_round_button;
  // Both pinned at the end (after Interview), like it — not part of the
  // draggable middle-column set. Predicted NBA was previously unconditional;
  // JD Match is force-shown once a JD has actually been matched this session,
  // even if the recruiter hasn't toggled the column on, so the result of what
  // they just did isn't hidden by default.
  const showPredictedNba = showCol("predicted_nba");
  const showJdMatch = showCol("jd_match") || jdMatchResults.size > 0;

  // ONE ordered list of the "middle" columns (everything between the pinned Candidate
  // column and the pinned Interview action), in the recruiter's SAVED drag-order — both
  // the operational columns (Stream/Received/…/ATS/Analysis Report/Round Status) and the
  // resume-registry columns interleaved together. This is what makes drag-reorder move
  // EVERY column, not just the registry ones. A bulk-filtered attribute is force-shown.
  const orderedMiddleColumns = useMemo(() => {
    const opVisible: Record<string, boolean> = {
      stream: showStream,
      received: showReceived,
      scheduled: showScheduled,
      aging: showAging,
      ats: showAts,
      analysis_report: showAnalysisReport,
      round_status: showRoundStatus,
    };
    const forced = activeBulkColumnKeys(bulkFilters);
    const out: ({ kind: "op"; key: string } | { kind: "reg"; col: ResumeColumn })[] = [];
    const seen = new Set<string>();
    const consider = (key: string, visible: boolean) => {
      if (seen.has(key) || key === "candidate_name" || key === "interview") return;
      seen.add(key);
      if (key in opVisible) {
        if (opVisible[key]) out.push({ kind: "op", key });
        return;
      }
      const col = resumeColumnFor(key);
      if (col && (visible || forced.includes(key))) out.push({ kind: "reg", col });
    };
    columnList.forEach((entry) => consider(entry.key, entry.visible));
    // A bulk-forced registry column missing from the saved list still appears (at the end).
    forced.forEach((k) => consider(k, true));
    return out;
  }, [
    columnList,
    bulkFilters,
    showStream,
    showReceived,
    showScheduled,
    showAging,
    showAts,
    showAnalysisReport,
    showRoundStatus,
  ]);
  const [columnsModalOpen, setColumnsModalOpen] = useState(false);

  // Header cell for an operational column (bespoke header markup / sort control).
  const opHeader = (key: string) => {
    switch (key) {
      case "stream": return <SortTh key={key} label="Stream" sortKey="stream" sort={sort} onSort={toggleSort} />;
      case "received": return <SortTh key={key} label="Received" sortKey="received" sort={sort} onSort={toggleSort} />;
      case "scheduled": return <SortTh key={key} label="Scheduled" sortKey="scheduled" sort={sort} onSort={toggleSort} />;
      case "aging": return <SortTh key={key} label="Aging" sortKey="aging" sort={sort} onSort={toggleSort} />;
      case "ats": return <SortTh key={key} label="ATS" sortKey="ats" sort={sort} onSort={toggleSort} />;
      case "round_status": return <SortTh key={key} label="Round Status" sortKey="round_status" sort={sort} onSort={toggleSort} />;
      case "analysis_report":
        return <SortTh key={key} label="Analysis Report" sortKey="analysis_report" sort={sort} onSort={toggleSort} />;
      default: return null;
    }
  };

  // candidate_id → the current round's scheduled date. Sourced from analytics.scheduled,
  // which covers Active AND Hired candidates — so a hired candidate's Final-round date
  // shows in the SCHEDULED column instead of "Not scheduled".
  const scheduledByCandidate = useMemo(() => {
    const m = new Map<string, string>();
    Object.entries(analytics?.scheduled ?? {}).forEach(([id, date]) => {
      if (date) m.set(id, date);
    });
    return m;
  }, [analytics]);

  // Aging counts from the current round's SCHEDULED date when one exists, else from
  // the received date (mail_send_date). Future-dated rounds clamp to 0 (not yet aged).
  const agingFor = (c: CandidateMaster): number | null => {
    const sched = scheduledByCandidate.get(c.candidate_id);
    if (sched) return Math.max(0, daysSince(sched) ?? 0);
    return daysSince(c.mail_send_date);
  };

  // Set of candidate_ids matching the aging filter (null = filter inactive).
  // ?tier picks an exact band (stalled / watch / ontrack); ?aging=gtN is a threshold.
  const agingIds = useMemo(() => {
    if (!analytics) return null;
    if (tierParam) {
      const want = tierParam === "ontrack" ? "ok" : tierParam; // agingTier → ok|watch|stalled
      return new Set(
        analytics.candidates
          .filter((c) => agingTier(c.aging_days) === want)
          .map((c) => c.candidate_id)
      );
    }
    if (agingThreshold != null) {
      // In-round candidates age from the round; "New" candidates (Active, no round)
      // age from when the pipeline last processed them.
      const ids = new Set(
        analytics.candidates
          .filter((c) => c.aging_days > agingThreshold)
          .map((c) => c.candidate_id)
      );
      candidates.forEach((c) => {
        if (c.status === "Active" && c.roundid == null) {
          const d = daysSince(
            c.pipeline_processed_at ?? c.parsed_at ?? c.created_at ?? c.mail_send_date
          );
          if (d != null && d > agingThreshold) ids.add(c.candidate_id);
        }
      });
      return ids;
    }
    return null;
  }, [analytics, agingThreshold, tierParam, candidates]);

  // Year dropdown options: the current year and the one before it only — never
  // future years (see pickerYears). Newest first.
  const yearOptions = useMemo(() => pickerYears(year), [year]);
  // Distinct intake sources actually present, most-recent-first — mirrors the
  // Dashboard's own Source filter (same recency ordering + "latest 11" cap).
  const sampleDataFilter = useSampleDataFilter();
  const sourceOptions = useMemo(() => {
    const latest = new Map<string, string>();
    candidates.forEach((c) => {
      const s = sourceOf(c);
      if (!s) return;
      if (s === sampleDataFilter.label && !sampleDataFilter.visible) return;
      const d = c.mail_send_date || c.created_at || "";
      if (d > (latest.get(s) ?? "")) latest.set(s, d);
    });
    return Array.from(latest.keys()).sort((a, b) => (latest.get(b) ?? "").localeCompare(latest.get(a) ?? ""));
  }, [candidates, sampleDataFilter.label, sampleDataFilter.visible]);

  const q = search.trim().toLowerCase();
  const todayStr = new Date().toLocaleDateString("en-CA"); // YYYY-MM-DD, local
  // Per-row sort value for the active column. Returns a number (metrics/dates/ordinals),
  // a string (names/categories, compared case-insensitively), or null (missing → sorts
  // last). NLRS has no data yet, so it always returns null (a clickable no-op for now).
  const sortKeyValue = (c: CandidateMaster): number | string | null => {
    switch (sort.key) {
      case "name": return (c.name ?? "").trim().toLowerCase() || null;
      case "stream": return (c.stream ?? "").trim().toLowerCase() || null;
      case "scheduled": {
        const s = scheduledByCandidate.get(c.candidate_id);
        return s ? new Date(s).getTime() : null;
      }
      case "round_status": return stageRank(stageLabel(c));
      case "highest_degree":
        return c.highest_coursecompleted ? DEGREE_RANK[c.highest_coursecompleted] ?? null : null;
      case "passout_year": return c.passoutyr ?? null;
      case "cgpa": return c.cgpa ?? null;
      case "fresher_or_lateral": return c.fresher_or_lateral ?? null;
      case "career_gap": return c.gap_months ?? null;
      case "ats": return c.atsscore ?? null;
      case "experience": return c.yearofexp ?? null;
      case "email": return (c.email ?? "").trim().toLowerCase() || null;
      case "phone": return (c.phno ?? "").trim().toLowerCase() || null;
      case "location": return (c.currentlocation ?? "").trim().toLowerCase() || null;
      case "source": return (c.source ?? "").trim().toLowerCase() || null;
      case "college": return (c.clg ?? "").trim().toLowerCase() || null;
      case "domain": return (c.domain ?? "").trim().toLowerCase() || null;
      case "current_company": return (c.currentcompany ?? "").trim().toLowerCase() || null;
      case "one_line_summary": return (c.role_context ?? "").trim().toLowerCase() || null;
      case "thinking_summary": return thinkingSummaryText(c.analysis).toLowerCase() || null;
      case "next_best_action": return (nextBestActionLabel(c) ?? "").trim().toLowerCase() || null;
      // List columns sort by item COUNT — a candidate with more projects/certs/roles/
      // skills ranks higher. Zero items reads as "no data" (sorts last, like every
      // other missing field) rather than a legitimate low value.
      case "projects": return toStrList(c.projects).length || null;
      case "certificates": return parseCertificates(c.certificates).length || null;
      case "job_role": return jobRoleTitles(c.job_roles).length || null;
      case "primary_skills": return toStrList(c.primary_skills).length || null;
      // Presence-only signal (the cell is just a "Report" button) — always sortable,
      // groups candidates with an Analysis Report apart from those without.
      case "analysis_report": return hasAnalysisReport(c) ? 1 : 0;
      case "received": {
        const t = c.mail_send_date ? new Date(c.mail_send_date).getTime() : NaN;
        return Number.isNaN(t) ? null : t;
      }
      case "aging": return agingFor(c);
      case "nlrs": return c.nlrs?.score ?? null;
      case "jd_match": return jdMatchResults.get(c.candidate_id)?.score ?? null;
      default: return null;
    }
  };

  // Show every candidate — including not-yet-extracted ones with no name yet. Each
  // appears bucketed by their actual round STAGE (Call / Round 1 / … / Hired /
  // Reject), never by a lifecycle status. roundStageBucket does that classification.
  const list = candidates
    .filter(
      (c) =>
        !q ||
        (c.name ?? "").toLowerCase().includes(q) ||
        c.candidate_id.toLowerCase().includes(q) ||
        (c.stream ?? "").toLowerCase().includes(q) ||
        (c.latest_note?.text ?? "").toLowerCase().includes(q) ||
        (c.latest_remark?.text ?? "").toLowerCase().includes(q) ||
        // Referral: the "referred by" name/email, the referral message, and the
        // "referral(s)" keyword itself (returns every referral candidate).
        (c.referral?.referred_by ?? "").toLowerCase().includes(q) ||
        (c.referral?.message ?? "").toLowerCase().includes(q) ||
        (!!c.referral && q.length >= 3 && "referrals".startsWith(q))
    )
    .filter((c) => !stageFilter || c.roundname === stageFilter)
    .filter((c) => selectedRounds.size === 0 || selectedRounds.has(roundStageBucket(c) ?? ""))
    .filter((c) => !onboardingParam || onboardingStageOf(c.onboarding_stage) === onboardingParam)
    .filter((c) => year === ALL_YEARS || yearOf(c) === year)
    .filter((c) => month === ALL_MONTHS || monthOf(c) === month)
    .filter((c) => source === ALL_SOURCES || sourceOf(c) === source)
    .filter((c) => matchExperience(c))
    .filter((c) => matchCert(c))
    .filter(
      (c) => arrivedFilter !== "today" || (c.mail_send_date ?? "").slice(0, 10) === todayStr
    )
    .filter((c) => agingIds == null || agingIds.has(c.candidate_id))
    .filter((c) =>
      bulkFilterMatches(c, bulkFilters, {
        aging: agingFor(c),
        source: sourceById.get(c.candidate_id) ?? null,
      }),
    )
    .sort((a, b) => {
      // All other columns: missing values sort last regardless of direction; strings
      // compare case-insensitively, numbers/ordinals/dates numerically.
      const mul = sort.dir === "asc" ? 1 : -1;
      const va = sortKeyValue(a);
      const vb = sortKeyValue(b);
      if (va == null && vb == null) return 0;
      if (va == null) return 1;
      if (vb == null) return -1;
      if (typeof va === "string" || typeof vb === "string")
        return String(va).localeCompare(String(vb)) * mul;
      return (va - vb) * mul;
    });

  // Downloads the currently filtered/sorted candidates as a CSV — all the fields
  // shown across the table's columns (identity, stage/status, scores, contact,
  // and the key resume facts), not just whatever's toggled on right now, so the
  // export is a complete, stable snapshot regardless of the Columns config.
  const exportCsv = (rows: CandidateMaster[]) => {
    const headers = [
      "Candidate ID", "Name", "Email", "Phone", "Status", "Stage", "Stream", "Source",
      "Fresher/Lateral", "Experience (yrs)", "College", "Highest Degree",
      "Passout Year", "CGPA", "Current Company", "Current Location", "Domain",
      "ATS", "NLRS", "JD Match Score", "Predicted NBA", "Next Best Action", "Career Gap",
      "Primary Skills", "Certificates", "Projects", "Job Roles",
      "Received Date", "Scheduled Date", "Aging (days)",
    ];
    const csvCell = (v: unknown): string => {
      const s = v == null ? "" : String(v);
      return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    };
    const lines = [headers.map(csvCell).join(",")];
    rows.forEach((c) => {
      const scheduledOn = scheduledByCandidate.get(c.candidate_id) ?? null;
      lines.push(
        [
          c.candidate_id, titleCase(c.name), c.email, c.phno, c.status, stageLabel(c), c.stream, c.source,
          c.fresher_or_lateral, c.yearofexp != null ? formatExperience(c.yearofexp) : "", c.clg, c.highest_coursecompleted,
          c.passoutyr, c.cgpa, c.currentcompany, c.currentlocation, c.domain,
          c.atsscore != null ? formatScore(c.atsscore) : "", c.nlrs?.score != null ? formatScore(c.nlrs.score) : "",
          jdMatchResults.get(c.candidate_id)?.score != null ? formatScore(jdMatchResults.get(c.candidate_id)!.score!) : "",
          c.predicted_nba ? NBA_OPTIONS.find((o) => o.key === c.predicted_nba)?.label ?? c.predicted_nba : "",
          nextBestActionLabel(c), c.careergap,
          toStrList(c.primary_skills).join("; "),
          parseCertificates(c.certificates).map((x) => x.name).join("; "),
          toStrList(c.projects).join("; "),
          jobRoleTitles(c.job_roles).join("; "),
          fmtReceived(c.mail_send_date), scheduledOn ? fmtReceived(scheduledOn) : "",
          agingFor(c),
        ]
          .map(csvCell)
          .join(",")
      );
    });
    const blob = new Blob([lines.join("\n")], { type: "text/csv;charset=utf-8;" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `candidates-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(a.href);
  };

  const chips: { key: string; label: string }[] = [];
  if (stageFilter) chips.push({ key: "stage", label: `Round: ${roundLabel(stageFilter)}` });
  if (arrivedFilter === "today") chips.push({ key: "arrived", label: "Arrived today" });
  if (agingThreshold != null)
    chips.push({ key: "aging", label: `Needs attention (>${agingThreshold} days)` });
  if (tierParam)
    chips.push({
      key: "tier",
      label:
        tierParam === "stalled"
          ? "Stalled >30d"
          : tierParam === "watch"
            ? "Watch 16–30d"
            : "On track ≤15d",
    });

  // Hooks must run on every render — keep this above the early return below.
  // Rows per page — defaults to 25, adjustable via the picker down by
  // Pagination; persisted across visits like the app's other table prefs.
  const [pageSize, setPageSizeState] = useState(loadPageSize);
  const setPageSize = (n: number) => {
    setPageSizeState(n);
    try {
      localStorage.setItem(PAGE_SIZE_KEY, String(n));
    } catch {
      /* non-fatal */
    }
  };
  const pg = usePagination(list, pageSize);

  return (
    <PageContainer className="flex h-full flex-col">
      <PageHeader
        title="Candidates"
        actions={
          <div className="flex flex-wrap items-center gap-2">
            {/* Admin-only: JD matching sends every filtered candidate to the
                LLM in one call — a deliberate, metered spend (also enforced
                server-side via require_admin on /jd-match). */}
            {isAdmin && (
            <button
              onClick={() => setJdMatchOpen(true)}
              className={cn(
                "inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-[11px] font-semibold transition-colors",
                jdMatchResults.size > 0
                  ? "border-primary/40 bg-primary/10 text-primary hover:bg-primary/20"
                  : "border-border bg-card text-foreground hover:border-primary/40 hover:bg-secondary",
              )}
              title="Score the currently filtered candidates against a job description (Admin only — token-intensive)"
            >
              <Sparkles className="h-3.5 w-3.5" />
              Match JD
              {jdMatchResults.size > 0 && (
                <span className="inline-flex h-4 min-w-4 items-center justify-center rounded-full bg-primary px-1 text-[10px] font-bold text-white tnum">
                  {jdMatchResults.size}
                </span>
              )}
            </button>
            )}
            <button
              onClick={() => setBulkModalOpen(true)}
              className={cn(
                "inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-[11px] font-semibold transition-colors",
                bulkCount > 0
                  ? "border-primary/40 bg-primary/10 text-primary hover:bg-primary/20"
                  : "border-border bg-card text-foreground hover:border-primary/40 hover:bg-secondary",
              )}
              title="Bulk filter by ATS, experience, CGPA, certificates and more"
            >
              <Filter className="h-3.5 w-3.5" />
              Filters
              {bulkCount > 0 && (
                <span className="inline-flex h-4 min-w-4 items-center justify-center rounded-full bg-primary px-1 text-[10px] font-bold text-white tnum">
                  {bulkCount}
                </span>
              )}
            </button>
            <button
              onClick={() => setColumnsModalOpen(true)}
              className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1 text-[11px] font-semibold text-foreground transition-colors hover:border-primary/40 hover:bg-secondary"
              title="Configure which columns appear on the table"
            >
              <SlidersHorizontal className="h-3.5 w-3.5" />
              Columns
            </button>
            <button
              onClick={() => exportCsv(list)}
              className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1 text-[11px] font-semibold text-foreground transition-colors hover:border-primary/40 hover:bg-secondary"
              title="Download the currently filtered candidates as a CSV (opens in Excel)"
            >
              <Download className="h-3.5 w-3.5" />
              Export CSV
            </button>
          </div>
        }
      />

      {/* Filters — search, date range, and all facets share a single wrapping row. */}
      <div className="flex flex-wrap items-center gap-x-2 gap-y-2">

        {/* Experience — single-select (radio) over year-range bands. */}
        <FilterDropdown
          label={expFilter.size ? [...expFilter][0] : "All experience"}
          icon={<Clock className="h-3.5 w-3.5" />}
          options={Object.keys(EXPERIENCE_BANDS)}
          selected={expFilter}
          onToggle={(v) => setExpFilter(expFilter.has(v) ? new Set() : new Set([v]))}
          onClear={() => setExpFilter(new Set())}
          width="w-44"
          single
        />

        {/* Round filter — multi-select checklist over the pipeline buckets. "Manual
            Review" is a candidate lifecycle status, not a round, so it's excluded here.
            "Screening" is shown as "Call" (display only — the stored value is unchanged). */}
        <FilterDropdown
          label="All rounds"
          icon={<ListChecks className="h-3.5 w-3.5" />}
          options={[...ROUND_FILTER_BUCKETS]}
          selected={selectedRounds}
          onToggle={toggleRound}
          onClear={() => setRounds(new Set())}
          optionLabel={(b) => roundLabel(b)}
          width="w-44"
        />

        {certTags.length > 0 && (
          <FilterDropdown
            label="All certs"
            icon={<Award className="h-3.5 w-3.5 text-amber-400" />}
            options={certTags}
            selected={selectedTags}
            onToggle={toggleTag}
            onClear={() => setSelectedTags(new Set())}
            footer={
              <input
                type="text"
                value={certKeyword}
                onChange={(e) => setCertKeyword(e.target.value)}
                placeholder="+ keyword…"
                title="Match any cert name or issuer (ANDed with checked tags)"
                className="w-full rounded-lg border border-border bg-secondary px-2 py-1.5 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50"
              />
            }
          />
        )}

        {/* Search — grows to fill leftover space; other filters are fixed-width. */}
        <div className="relative min-w-36 flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search name, id, stream…"
            className="field-input h-8 w-full !pl-9 pr-7"
          />
          {search && (
            <button
              onClick={() => setSearch("")}
              title="Clear search"
              className="absolute right-2 top-1/2 -translate-y-1/2 rounded-md p-0.5 text-muted-foreground hover:bg-secondary hover:text-foreground"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          )}
        </div>

        {/* Result count — plain range + a highlighted filtered total. */}
        <span className="ml-auto flex flex-wrap items-center gap-2">
          <span className="text-xs text-muted-foreground tnum">
            Showing {list.length === 0 ? 0 : pg.startIndex + 1}–
            {Math.min(pg.startIndex + pg.pageSize, list.length)}
          </span>
          <span className="inline-flex items-center rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-xs font-semibold text-primary tnum">
            Total : {list.length}
          </span>
        </span>

        {(expFilter.size > 0 ||
          certFilterActive ||
          selectedRounds.size > 0 ||
          bulkCount > 0 ||
          chips.length > 0) && (
          <button
            onClick={() => {
              // Reset local facet state.
              setExpFilter(new Set());
              setSelectedTags(new Set());
              setCertKeyword("");
              setBulkFilters(EMPTY_BULK_FILTERS);
              // Strip every URL-backed filter in ONE update — calling setSearchParams
              // several times each reads the same stale params and clobbers the rest,
              // which left rounds/date filters behind.
              const next = new URLSearchParams(searchParams);
              ["bucket", "stage", "arrived", "aging", "tier", "onboarding"].forEach(
                (k) => next.delete(k)
              );
              setSearchParams(next, { replace: true });
            }}
            className="rounded-full border border-primary/40 bg-primary/10 px-2.5 py-1 text-[11px] font-semibold text-primary transition-colors hover:bg-primary/20"
          >
            Clear all
          </button>
        )}
      </div>

      {chips.length > 0 && (
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="text-[11px] text-muted-foreground">Filtered by</span>
          {chips.map((chip) => (
            <button
              key={chip.key}
              onClick={() => clearParam(chip.key)}
              className="inline-flex items-center gap-1 rounded-full border border-primary/30 bg-primary/10 px-2.5 py-0.5 text-[11px] font-semibold text-primary hover:bg-primary/20"
            >
              {chip.label}
              <X className="h-3 w-3" />
            </button>
          ))}
        </div>
      )}

      <ColumnConfigModal
        open={columnsModalOpen}
        columns={columnList}
        onClose={() => setColumnsModalOpen(false)}
      />

      <BulkFilterModal
        open={bulkModalOpen}
        applied={bulkFilters}
        certTags={certTags}
        skillGroups={skillGroups}
        domainOptions={domainOptions}
        locationOptions={locationOptions}
        jobRoleOptions={jobRoleOptions}
        sourceTagOptions={sourceTagLabels}
        onApply={setBulkFilters}
        onClose={() => setBulkModalOpen(false)}
      />

      {jdMatchOpen && (
        <JdMatchModal
          candidateIds={list.map((c) => c.candidate_id)}
          onClose={() => setJdMatchOpen(false)}
          onResults={(results, text) => {
            setJdMatchResults(new Map(results.map((r) => [r.candidate_id, r])));
            setJdText(text);
          }}
        />
      )}

      {/* JD-match "why this score?" breakdown — opened by clicking a score. */}
      {jdExplainFor && (
        <JdExplainModal
          candidateId={jdExplainFor.id}
          candidateName={jdExplainFor.name}
          result={jdMatchResults.get(jdExplainFor.id) ?? null}
          jdText={jdText}
          onClose={() => setJdExplainFor(null)}
        />
      )}

      {/* ATS score-breakdown popover — opened by clicking a candidate's ATS value. */}
      {atsBreakdown && (
        <ScorePopoverModal candidate={atsBreakdown} subtitle="Why this ATS score" onClose={() => setAtsBreakdown(null)}>
          <ScoreBreakdown c={atsBreakdown} />
        </ScorePopoverModal>
      )}

      {/* NLRS score-breakdown popover — opened by clicking a candidate's NLRS value. */}
      {nlrsBreakdown && (
        <ScorePopoverModal candidate={nlrsBreakdown} subtitle="Why this NLRS score" onClose={() => setNlrsBreakdown(null)}>
          <NlrsBreakdown c={nlrsBreakdown} />
        </ScorePopoverModal>
      )}

      {/* Analysis Report popover — same shared modal as the Dashboard's, opened by
          the Report button on a candidate row. */}
      {analysisFor && (
        <AnalysisReportModal
          candidate={analysisFor}
          agingDays={agingFor(analysisFor)}
          isAdmin={isAdmin}
          canApplyPredicted={canApplyFor(analysisFor.source)}
          onClose={() => setAnalysisFor(null)}
          onViewResume={() => setResumeFor(analysisFor)}
          onApplyPredicted={() => {
            setConfirmApplyFor(analysisFor);
            setAnalysisFor(null);
          }}
          applyPending={applyPredicted.isPending}
          onOverrideSave={(ov) => {
            setPendingOverride({
              candidateId: analysisFor.candidate_id,
              name: analysisFor.name ? titleCase(analysisFor.name) : analysisFor.candidate_id,
              ov,
            });
            setAnalysisFor(null);
          }}
          onReviewDraft={() => setDraftReviewOpen(true)}
        />
      )}

      {resumeFor && (
        <ResumeViewerModal
          open={!!resumeFor}
          candidateId={resumeFor.candidate_id}
          which="current"
          fileName={resumeFor.s3_file_path}
          onClose={() => setResumeFor(null)}
        />
      )}

      <NbaCommentDialog
        open={!!confirmApplyFor}
        title="Apply predicted Next Best Action?"
        message={
          confirmApplyFor && (
            <>
              This moves{" "}
              <span className="font-semibold text-foreground">
                {confirmApplyFor.name ? titleCase(confirmApplyFor.name) : confirmApplyFor.candidate_id}
              </span>{" "}
              forward as{" "}
              <span className="font-semibold text-foreground">
                {NBA_OPTIONS.find((o) => o.key === confirmApplyFor.predicted_nba)?.label ??
                  confirmApplyFor.predicted_nba}
              </span>{" "}
              right away.
            </>
          )
        }
        pending={applyPredicted.isPending}
        onCancel={() => setConfirmApplyFor(null)}
        onApply={(comment) => {
          if (confirmApplyFor) applyPredicted.mutate({ candidateId: confirmApplyFor.candidate_id, comment });
          setConfirmApplyFor(null);
        }}
      />

      <NbaCommentDialog
        open={confirmBulkOpen}
        title="Apply predicted Next Best Action?"
        message={
          <>
            This moves{" "}
            <span className="font-semibold text-foreground">
              {selectedIds.size} candidate{selectedIds.size === 1 ? "" : "s"}
            </span>{" "}
            forward with their predicted action, right away.
          </>
        }
        bulkCount={selectedIds.size}
        pending={applyPredictedBulk.isPending}
        onCancel={() => setConfirmBulkOpen(false)}
        onApply={(comment) => {
          applyPredictedBulk.mutate({ ids: [...selectedIds], comment });
          setConfirmBulkOpen(false);
        }}
      />

      <NbaCommentDialog
        open={!!pendingOverride}
        title="Change the Next Best Action?"
        message={
          pendingOverride && (
            <>
              Updates the next action for{" "}
              <span className="font-semibold text-foreground">{pendingOverride.name}</span> and runs
              its automation (stage move / email draft) right away.
            </>
          )
        }
        pending={updateNba.isPending}
        onCancel={() => setPendingOverride(null)}
        onApply={(comment) => {
          if (pendingOverride)
            updateNba.mutate({ candidateId: pendingOverride.candidateId, ov: pendingOverride.ov, comment });
          setPendingOverride(null);
        }}
      />

      <BulkNoteDialog
        open={bulkNoteKind != null}
        kind={bulkNoteKind ?? "note"}
        count={selectedIds.size}
        pending={bulkNote.isPending}
        onCancel={() => setBulkNoteKind(null)}
        onApply={(text) =>
          bulkNote.mutate({ ids: [...selectedIds], text, kind: bulkNoteKind ?? "note" })
        }
      />

      {draftReviewOpen && analysisFor?.pending_email_draft && (
        <EmailDraftReviewModal
          draft={analysisFor.pending_email_draft}
          candidate={analysisFor}
          onClose={() => setDraftReviewOpen(false)}
          onUpdated={() => queryClient.invalidateQueries({ queryKey: ["candidates"] })}
        />
      )}

      {/* Analysis Report popover — opened by the report button on a candidate row. */}
      {analysisFor && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/40 p-4 backdrop-blur-sm"
          onClick={() => setAnalysisFor(null)}
        >
          <div
            className="max-h-[85vh] w-full max-w-lg overflow-hidden rounded-2xl border border-border bg-card shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-3 border-b border-border px-5 py-3.5">
              <div className="min-w-0">
                <h2 className="truncate text-sm font-bold text-foreground">
                  {analysisFor.name ?? analysisFor.candidate_id}
                </h2>
                <p className="text-[11px] text-muted-foreground">
                  Analysis Report · {analysisFor.candidate_id}
                </p>
              </div>
              <button
                onClick={() => setAnalysisFor(null)}
                className="rounded-lg p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
                aria-label="Close"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="max-h-[calc(85vh-3.5rem)] overflow-auto px-5 py-4">
              <AnalysisReportBody c={analysisFor} />

              <div className="mt-5 border-t border-border pt-4">
                <h3 className="mb-2.5 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                  Update Next Action
                </h3>
                <NbaOptionsList
                  current={analysisFor.next_action_override ?? undefined}
                  suggested={suggestedNba(analysisFor)}
                  onSave={(ov) => {
                    updateNba.mutate({ candidateId: analysisFor.candidate_id, ov });
                    setAnalysisFor(null);
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {isLoading ? (
        <div className="surface px-5 py-10 flex items-center gap-2 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading candidates…
        </div>
      ) : isError ? (
        <div className="surface px-5 py-12 text-center">
          <AlertTriangle className="h-6 w-6 text-rose-500 mx-auto mb-2" />
          <p className="text-sm font-semibold text-foreground">Couldn't load candidates</p>
          <p className="text-xs text-muted-foreground mt-1">
            The candidate service didn't respond. Check the backend and try again.
          </p>
        </div>
      ) : list.length === 0 ? (
        <div className="surface px-5 py-12 text-center">
          <p className="text-sm font-semibold text-foreground">No candidates to screen yet</p>
          <p className="text-xs text-muted-foreground mt-1">
            Upload resumes in Intake and run the pipeline — processed candidates show up here.
          </p>
        </div>
      ) : (
        <>
          {selectedIds.size > 0 && (
            <div className="flex flex-col gap-2 rounded-2xl border border-primary/30 bg-primary/5 px-4 py-2 sm:flex-row sm:items-center sm:justify-between">
              <span className="text-xs font-semibold text-foreground">
                {selectedIds.size} candidate{selectedIds.size === 1 ? "" : "s"} selected
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setSelectedIds(new Set())}
                  className="rounded-full px-2.5 py-1 text-[11px] font-medium text-muted-foreground hover:bg-secondary"
                >
                  Clear
                </button>
                <button
                  onClick={() => setBulkNoteKind("note")}
                  className="inline-flex items-center gap-1.5 rounded-full border border-amber-400/50 bg-amber-100/40 px-3 py-1.5 text-[11px] font-semibold text-amber-700 transition-colors hover:bg-amber-200/50 dark:bg-amber-400/10"
                >
                  <StickyNote className="h-3 w-3" /> Note
                </button>
                <button
                  onClick={() => setBulkNoteKind("remark")}
                  className="inline-flex items-center gap-1.5 rounded-full border border-sky-400/50 bg-sky-100/40 px-3 py-1.5 text-[11px] font-semibold text-sky-700 transition-colors hover:bg-sky-200/50 dark:bg-sky-400/10"
                >
                  <StickyNote className="h-3 w-3" /> Remark
                </button>
                {selectedCanApply ? (
                  <button
                    onClick={() => setConfirmBulkOpen(true)}
                    disabled={applyPredictedBulk.isPending}
                    className="inline-flex items-center gap-1.5 rounded-full bg-emerald-600 px-3 py-1.5 text-[11px] font-semibold text-white transition-colors hover:bg-emerald-700 disabled:opacity-50"
                  >
                    <Check className="h-3 w-3" />
                    {applyPredictedBulk.isPending ? "Applying…" : `Apply predicted NBA to ${selectedIds.size}`}
                  </button>
                ) : (
                  <span className="rounded-full border border-border bg-secondary px-3 py-1.5 text-[11px] font-medium text-muted-foreground">
                    Admin review pending…
                  </span>
                )}
              </div>
            </div>
          )}
          <div className="surface min-h-0 flex-1 overflow-auto">
            <table className="w-full min-w-[920px] text-left text-sm">
              <thead className="[&>tr>th]:sticky [&>tr>th]:top-0 [&>tr>th]:z-10 [&>tr>th]:bg-card">
                <tr className="border-b border-border text-[9px] font-semibold uppercase tracking-wide text-muted-foreground">
                  <th className="w-9 px-3 py-1.5">
                    <input
                      type="checkbox"
                      title="Select all New-stage candidates on this page"
                      checked={
                        pg.pageItems.some((c) => c.predicted_nba) &&
                        pg.pageItems.filter((c) => c.predicted_nba).every((c) => selectedIds.has(c.candidate_id))
                      }
                      onChange={(e) => {
                        const eligible = pg.pageItems.filter((c) => c.predicted_nba).map((c) => c.candidate_id);
                        setSelectedIds((prev) => {
                          const next = new Set(prev);
                          eligible.forEach((id) => (e.target.checked ? next.add(id) : next.delete(id)));
                          return next;
                        });
                      }}
                      className="h-3.5 w-3.5 cursor-pointer rounded border-border accent-primary"
                    />
                  </th>
                  {showCandidate && (
                    <SortTh label="Candidate" sortKey="name" sort={sort} onSort={toggleSort} />
                  )}
                  {/* Operational + configurable columns interleaved in the recruiter's saved
                      drag-order (so reordering moves every column, not just the registry ones). */}
                  {orderedMiddleColumns.map((mc) =>
                    mc.kind === "op" ? (
                      opHeader(mc.key)
                    ) : mc.col.sortKey ? (
                      <SortTh
                        key={mc.col.key}
                        label={mc.col.header}
                        sortKey={mc.col.sortKey as SortKey}
                        sort={sort}
                        onSort={toggleSort}
                      />
                    ) : (
                      <th key={mc.col.key} className="px-4 py-1.5 font-semibold whitespace-nowrap">
                        {mc.col.header}
                      </th>
                    ),
                  )}
                  {showInterview && <th className="px-4 py-1.5 text-right font-semibold">Interview</th>}
                  {showJdMatch && (
                    <SortTh label="JD Match" sortKey="jd_match" sort={sort} onSort={toggleSort} />
                  )}
                  {showPredictedNba && (
                    <th className="px-4 py-1.5 text-left font-semibold">Predicted NBA</th>
                  )}
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {pg.pageItems.map((c) => {
                  // Current round's scheduled date (in-round candidates only) → drives
                  // both the Scheduled column and the aging basis.
                  const scheduledOn = scheduledByCandidate.get(c.candidate_id) ?? null;
                  const agingDays = agingFor(c);
                  const stage = stageLabel(c);
                  // Terminal candidates (Rejected / Hired / Closed) are out of the
                  // active pipeline — they no longer age and have no pending interview
                  // to schedule, so those columns read "—" instead of "0d" / "Not
                  // scheduled" (which wrongly imply an action is still due).
                  const terminal =
                    stage === "Rejected" || stage === "Hired" || stage === "Closed";
                  // Body cell for an operational column — closes over this row's computed
                  // context (scheduledOn / agingDays / stage / terminal).
                  const opCell = (key: string) => {
                    switch (key) {
                      case "stream":
                        return (
                          <td key={key} className="px-4 py-1.5 text-xs text-muted-foreground whitespace-nowrap">
                            {c.stream ?? "—"}
                          </td>
                        );
                      case "received":
                        return (
                          <td key={key} className="px-4 py-1.5 text-xs text-muted-foreground whitespace-nowrap">
                            {fmtReceived(c.mail_send_date)}
                          </td>
                        );
                      case "scheduled":
                        return (
                          <td key={key} className="px-4 py-1.5 whitespace-nowrap">
                            {scheduledOn ? (
                              <span className="text-xs text-foreground">{fmtReceived(scheduledOn)}</span>
                            ) : terminal ? (
                              <span className="text-xs text-muted-foreground">—</span>
                            ) : (
                              <span className="text-xs text-muted-foreground">Not scheduled</span>
                            )}
                          </td>
                        );
                      case "aging":
                        return (
                          <td key={key} className="px-4 py-1.5">
                            {!terminal && agingDays != null ? (
                              <DaysBadge
                                days={agingDays}
                                label={scheduledOn ? "Days since scheduled date" : "Days since received"}
                              />
                            ) : (
                              <span className="text-xs text-muted-foreground">—</span>
                            )}
                          </td>
                        );
                      case "ats":
                        return (
                          <td key={key} className="px-4 py-1.5">
                            {c.atsscore == null ? (
                              <span className="stat-value text-sm font-bold text-muted-foreground">—</span>
                            ) : hasScoreBreakdown(c) ? (
                              <button
                                onClick={() => setAtsBreakdown(c)}
                                title="Show ATS score breakdown"
                                className="stat-value inline-flex items-center gap-1 text-sm font-bold text-foreground underline decoration-dotted underline-offset-2 transition-colors hover:text-primary"
                              >
                                {formatScore(c.atsscore)}
                                <BarChart2 className="h-3 w-3 opacity-60" />
                              </button>
                            ) : (
                              <span className="stat-value text-sm font-bold text-foreground">
                                {formatScore(c.atsscore)}
                              </span>
                            )}
                          </td>
                        );
                      case "analysis_report":
                        return (
                          <td key={key} className="px-4 py-1.5">
                            <button
                              onClick={() => setAnalysisFor(c)}
                              title="View Analysis Report"
                              className={cn(
                                "inline-flex items-center gap-1.5 rounded-lg border px-2 py-1 text-[11px] font-semibold transition-colors",
                                hasAnalysisReport(c)
                                  ? "border-primary/30 bg-primary/5 text-primary hover:bg-primary/10"
                                  : "border-border bg-card text-muted-foreground hover:border-primary/40 hover:text-foreground",
                              )}
                            >
                              <ClipboardList className="h-3.5 w-3.5" />
                              Report
                            </button>
                          </td>
                        );
                      case "round_status":
                        // ROUND STATUS = the candidate's interview ROUND/STAGE only (Call /
                        // Round 1 / 2 / Final / Hired / Rejected / New). Never a lifecycle status.
                        return (
                          <td key={key} className="px-4 py-1.5">
                            <span className="inline-flex items-center gap-1.5">
                              <span className={cn("inline-block rounded-full border px-2.5 py-0.5 text-[10px] font-semibold", stageCls(stage))}>
                                {roundLabel(stage)}
                              </span>
                              <HelpRequestBadge candidate={c} />
                            </span>
                          </td>
                        );
                      default:
                        return null;
                    }
                  };
                  return (
                    <tr key={c.candidate_id} className="group hover:bg-secondary/50 transition-colors">
                      <td className="px-3 py-1.5">
                        {c.predicted_nba && (
                          <input
                            type="checkbox"
                            checked={selectedIds.has(c.candidate_id)}
                            onChange={() => toggleSelected(c.candidate_id)}
                            title="Select for bulk apply"
                            className="h-3.5 w-3.5 cursor-pointer rounded border-border accent-primary"
                          />
                        )}
                      </td>
                      {showCandidate && (
                        <td className="px-4 py-1.5">
                          <button
                            onClick={() => navigate(`/candidates/${c.candidate_id}`)}
                            className="block text-left"
                            title="Open candidate profile"
                          >
                            <div className="min-w-0">
                              <div className="truncate text-sm font-semibold text-foreground group-hover:text-primary transition-colors">
                                {c.name ? titleCase(c.name) : <span className="italic text-muted-foreground">Unnamed candidate</span>}
                                <ReferralBadge referral={c.referral} className="ml-1 align-middle" />
                                <InviteBlockBadge reason={c.invite_block_reason} className="ml-1 align-middle" />
                                <NoteBadge note={c.latest_note} className="ml-1 align-middle" />
                                <RemarkBadge remark={c.latest_remark} className="ml-0.5 align-middle" />
                              </div>
                              <div className="truncate text-[11px] text-muted-foreground">
                                {c.candidate_id}
                              </div>
                            </div>
                          </button>
                        </td>
                      )}
                      {/* Operational + configurable columns, in the saved drag-order. */}
                      {orderedMiddleColumns.map((mc) =>
                        mc.kind === "op" ? (
                          opCell(mc.key)
                        ) : mc.col.key === "nlrs" ? (
                          <td key={mc.col.key} className="px-4 py-1.5 align-middle">
                            {c.nlrs == null ? (
                              <span className="stat-value text-sm font-bold text-muted-foreground">—</span>
                            ) : hasNlrsBreakdown(c) ? (
                              <button
                                onClick={() => setNlrsBreakdown(c)}
                                title="Show NLRS score breakdown"
                                className={cn(
                                  "stat-value inline-flex items-center gap-1 text-sm font-bold underline decoration-dotted underline-offset-2 transition-colors hover:text-primary",
                                  c.nlrs.score >= 70
                                    ? "text-emerald-500"
                                    : c.nlrs.score >= 45
                                      ? "text-amber-500"
                                      : "text-rose-500",
                                )}
                              >
                                {formatScore(c.nlrs.score)}
                                <BarChart2 className="h-3 w-3 opacity-60" />
                              </button>
                            ) : (
                              <span className="stat-value text-sm font-bold text-foreground">
                                {formatScore(c.nlrs.score)}
                              </span>
                            )}
                          </td>
                        ) : (
                          <td key={mc.col.key} className="px-4 py-1.5 align-middle">
                            {mc.col.render(c)}
                          </td>
                        ),
                      )}
                      {showInterview && (
                        <td className="px-4 py-1.5 text-right">
                          <button
                            onClick={() => navigate(`/rounds/${c.candidate_id}`)}
                            className="inline-flex items-center gap-1 rounded-lg border border-border bg-secondary px-2.5 py-1.5 text-[11px] font-semibold text-foreground hover:bg-accent transition-colors"
                            title="Manage interview rounds"
                          >
                            <ClipboardCheck className="h-3 w-3" /> Interview Round
                          </button>
                        </td>
                      )}
                      {showJdMatch && (() => {
                        const m = jdMatchResults.get(c.candidate_id);
                        return (
                          <td className="px-4 py-1.5">
                            {m?.score == null ? (
                              <span className="text-xs text-muted-foreground">—</span>
                            ) : (
                              <button
                                type="button"
                                onClick={() => setJdExplainFor({ id: c.candidate_id, name: c.name || c.candidate_id })}
                                title={`${m.note ? `${m.note} — ` : ""}Click for the detailed breakdown of why this score`}
                                className={cn(
                                  "stat-value cursor-pointer text-sm font-bold underline decoration-dotted underline-offset-4 transition-transform hover:scale-110",
                                  m.score >= 70
                                    ? "text-emerald-500"
                                    : m.score >= 45
                                      ? "text-amber-500"
                                      : "text-rose-500",
                                )}
                              >
                                {formatScore(m.score)}
                              </button>
                            )}
                          </td>
                        );
                      })()}
                      {showPredictedNba && (
                        <td className="px-4 py-1.5">
                          {c.predicted_nba ? (
                            <div className="flex items-center gap-1.5">
                              <span className="text-[11px] text-muted-foreground">
                                {NBA_OPTIONS.find((o) => o.key === c.predicted_nba)?.label ?? c.predicted_nba}
                              </span>
                              <button
                                onClick={() => setConfirmApplyFor(c)}
                                disabled={applyPredicted.isPending}
                                title="Apply the predicted Next Best Action — moves the candidate forward"
                                className="inline-flex shrink-0 items-center gap-1 rounded-full border border-emerald-500/40 bg-emerald-500/10 px-2 py-0.5 text-[10px] font-semibold text-emerald-600 transition-colors hover:bg-emerald-500/20 disabled:opacity-40"
                              >
                                <Check className="h-3 w-3" /> Apply
                              </button>
                            </div>
                          ) : (() => {
                            // predicted_nba goes null the instant it's Applied or
                            // Overridden — fall back to that status instead of a
                            // bare "—" so an already-actioned New-stage row doesn't
                            // misleadingly look untouched.
                            const status = nbaStatus(c);
                            return status ? (
                              <span
                                className={cn(
                                  "text-[11px] font-medium",
                                  status.tag === "Applied"
                                    ? "text-emerald-600"
                                    : status.tag === "Overridden"
                                      ? "text-amber-600"
                                      : "text-muted-foreground",
                                )}
                              >
                                {status.tag}: {status.label}
                              </span>
                            ) : (
                              <span className="text-xs text-muted-foreground">—</span>
                            );
                          })()}
                        </td>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <Pagination
              page={pg.page}
              pageCount={pg.pageCount}
              total={pg.total}
              pageSize={pg.pageSize}
              startIndex={pg.startIndex}
              onPage={pg.setPage}
              itemLabel="candidates"
              showCount={false}
              pageSizeControl={
                <FilterDropdown
                  label={`${pageSize} / page`}
                  options={PAGE_SIZE_OPTIONS.map(String)}
                  selected={new Set([String(pageSize)])}
                  onToggle={(v) => setPageSize(Number(v))}
                  onClear={() => setPageSize(25)}
                  width="w-28"
                  single
                  allowClear={false}
                  align="right"
                  openUp
                />
              }
            />
            {/* Source / Year / Month — same global filters as the Dashboard, placed
                here (bottom-right, by pagination) rather than the top toolbar.
                flex-wrap so a narrow phone drops these onto their own row
                instead of clipping them against the pagination control. */}
            <div className="flex flex-wrap items-center gap-2 sm:ml-auto">
              <FilterDropdown
                label={source === ALL_SOURCES ? "All sources" : source}
                icon={<Tag className="h-3.5 w-3.5" />}
                options={["All sources", ...sourceOptions]}
                selected={source === ALL_SOURCES ? new Set() : new Set([source])}
                onToggle={(v) => setSource(v === "All sources" ? ALL_SOURCES : v)}
                onClear={() => setSource(ALL_SOURCES)}
                width="w-48"
                single
                allowClear={false}
                align="right"
                openUp
                searchable
                searchPlaceholder="Search sources…"
                searchLimit={12}
              />
              <FilterDropdown
                label={year === ALL_YEARS ? "All years" : String(year)}
                icon={<Calendar className="h-3.5 w-3.5" />}
                options={["All years", ...yearOptions.map(String)]}
                selected={year === ALL_YEARS ? new Set() : new Set([String(year)])}
                onToggle={(v) => setYear(v === "All years" ? ALL_YEARS : Number(v))}
                onClear={() => setYear(ALL_YEARS)}
                width="w-40"
                single
                allowClear={false}
                align="right"
                openUp
              />
              <FilterDropdown
                label={month === ALL_MONTHS ? "All months" : MONTH_NAMES[month - 1]}
                icon={<CalendarDays className="h-3.5 w-3.5" />}
                options={["All months", ...MONTH_NAMES]}
                selected={month === ALL_MONTHS ? new Set() : new Set([MONTH_NAMES[month - 1]])}
                onToggle={(v) =>
                  setMonth(v === "All months" ? ALL_MONTHS : MONTH_NAMES.indexOf(v as (typeof MONTH_NAMES)[number]) + 1)
                }
                onClear={() => setMonth(ALL_MONTHS)}
                width="w-40"
                single
                allowClear={false}
                align="right"
                openUp
              />
            </div>
          </div>
        </>
      )}
    </PageContainer>
  );
}

function ScreeningDetail({ candidateId }: { candidateId: string }) {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const {
    data: c,
    isLoading,
    isError,
  } = useQuery({
    queryKey: ["candidate", candidateId],
    queryFn: async () => (await candidatesService.get(candidateId!)).data,
    enabled: !!candidateId,
  });

  const { data: rounds = [] } = useQuery({
    queryKey: ["rounds", candidateId],
    queryFn: async () => (await roundsService.listForCandidate(candidateId!)).data,
    enabled: !!candidateId,
  });

  if (isLoading) {
    return (
      <div className="p-6 flex items-center gap-2 text-sm text-muted-foreground">
        <Loader2 className="h-4 w-4 animate-spin" /> Loading candidate…
      </div>
    );
  }
  if (isError || !c) {
    return (
      <div className="p-6 text-sm text-red-400">
        Could not load candidate {candidateId}.{" "}
        <button onClick={() => navigate(-1)} className="underline">Go back</button>
      </div>
    );
  }

  return (
    <ScreeningForm
      c={c}
      rounds={rounds}
      candidateId={candidateId!}
      queryClient={queryClient}
      navigate={navigate}
    />
  );
}

function roundStatus(r: Round): { label: string; cls: string } {
  if (r.outcome && r.outcome !== "Pending")
    return { label: outcomeLabel(r.outcome), cls: OUTCOME_COLORS[r.outcome] ?? OUTCOME_COLORS.Pending };
  // A scheduled-but-not-recorded round whose date has passed falls back to Pending
  // (the interview was due and no outcome was entered).
  if (r.scheduled_on) {
    const past = new Date(r.scheduled_on) < new Date(new Date().toDateString());
    if (past) return { label: "Pending", cls: OUTCOME_COLORS.Pending };
    return { label: "Scheduled", cls: "text-blue-600 bg-blue-500/10 border-blue-500/30" };
  }
  return { label: "To schedule", cls: "text-slate-500 bg-slate-500/10 border-slate-500/30" };
}

function ScreeningForm({
  c,
  rounds,
  candidateId,
  queryClient,
  navigate,
}: {
  c: CandidateMaster;
  rounds: Round[];
  candidateId: string;
  queryClient: ReturnType<typeof useQueryClient>;
  navigate: ReturnType<typeof useNavigate>;
}) {
  const [showNew, setShowNew] = useState(false);
  const [openRound, setOpenRound] = useState<Round | null>(null);

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["rounds", candidateId] });
    queryClient.invalidateQueries({ queryKey: ["candidate", candidateId] });
    queryClient.invalidateQueries({ queryKey: ["candidates"] });
  };

  // SINGLE SOURCE OF TRUTH: the current stage comes from candidate_master
  // (c.roundname / c.roundid), the exact field the Rounds board reads — never
  // inferred from the rounds-history tail, which could lag behind. The matching
  // round (pointed to by c.roundid) only supplies the outcome/scheduled label.
  const currentStage = c.status === "Hired" ? "Hired" : (c.roundname?.trim() || "New");
  const currentRound =
    rounds.find((r) => r.round_id === c.roundid) ?? rounds[rounds.length - 1];

  return (
    <PageContainer size="focused">
      <div className="flex items-center justify-between gap-2">
        <button
          onClick={() => navigate("/rounds")}
          className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          Back to Rounds
        </button>
        <button
          onClick={() => navigate(`/candidates/${candidateId}`)}
          className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-secondary px-3 py-1.5 text-xs font-semibold text-foreground hover:bg-accent transition-colors"
        >
          <ExternalLink className="h-3.5 w-3.5" />
          View Profile
        </button>
      </div>

      <div className="flex items-center gap-3">
        <div className="w-11 h-11 rounded-xl gradient-brand flex items-center justify-center text-sm font-bold text-white shrink-0">
          {c.name ? initialsOf(c.name) : "?"}
        </div>
        <div>
          <h1 className="text-xl font-bold text-foreground">{c.name ? titleCase(c.name) : c.candidate_id}</h1>
          <ReferralBadge referral={c.referral} />
          <InviteBlockBadge reason={c.invite_block_reason} />
          <NoteBadge note={c.latest_note} />
          <p className="text-xs text-muted-foreground">
            {c.candidate_id} · {c.stream ?? "Role TBD"}
          </p>
        </div>
        <span
          className={cn(
            "ml-auto rounded-full border px-3 py-1 text-xs font-semibold",
            currentRound ? roundStatus(currentRound).cls : "text-slate-500 bg-slate-500/10 border-slate-500/30"
          )}
        >
          {roundLabel(currentStage)}
          {currentRound ? ` · ${roundStatus(currentRound).label}` : ""}
        </span>
      </div>

      <div className="surface overflow-hidden">
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-border">
          <h2 className="text-sm font-semibold text-foreground">Interview Rounds</h2>
        </div>

        {rounds.length === 0 ? (
          <div className="px-5 py-12 flex flex-col items-center text-center gap-2">
            <div className="w-10 h-10 rounded-2xl bg-secondary flex items-center justify-center">
              <Calendar className="h-5 w-5 text-muted-foreground" />
            </div>
            <p className="text-sm font-semibold text-foreground">No rounds scheduled yet</p>
            <p className="text-xs text-muted-foreground max-w-xs">
              Add the first round to start tracking this candidate through your interview process.
            </p>
            <button onClick={() => setShowNew(true)} className="btn-brand text-xs mt-1">
              <Plus className="h-3.5 w-3.5" /> Schedule a round
            </button>
          </div>
        ) : (
          <div className="divide-y divide-border">
            {rounds.map((r) => {
              const st = roundStatus(r);
              return (
                <button
                  key={r.round_id}
                  onClick={() => setOpenRound(r)}
                  className="w-full flex items-center gap-3 px-5 py-3.5 text-left hover:bg-secondary/50 transition-colors"
                >
                  <div className="w-8 h-8 rounded-lg bg-secondary flex items-center justify-center shrink-0">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="min-w-0 flex-1">
                    {/* Real round name — the "Interview slots shared" relabel is for stage chips only. */}
                    <div className="text-sm font-medium text-foreground">{r.round_name}</div>
                    {r.scheduled_on && (
                      <div className="text-[11px] text-muted-foreground">
                        {new Date(r.scheduled_on).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" })}
                      </div>
                    )}
                  </div>
                  <span className={cn("rounded-full border px-2.5 py-0.5 text-[11px] font-semibold", st.cls)}>
                    {st.label}
                  </span>
                  <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0" />
                </button>
              );
            })}
          </div>
        )}
      </div>

      {showNew && (
        <ScheduleRoundModal
          candidateId={candidateId}
          candidate={c}
          rounds={rounds}
          onClose={() => setShowNew(false)}
          onCreated={(round) => {
            invalidate();
            setShowNew(false);
            // Keep the candidate in context and open the just-created round so it
            // can be modified right away — no re-selecting the candidate.
            setOpenRound(round);
          }}
        />
      )}
      {openRound && (
        <RoundDetailDrawer round={openRound} candidate={c} rounds={rounds} onClose={() => setOpenRound(null)} onSaved={invalidate} />
      )}
    </PageContainer>
  );
}

function ScheduleRoundModal({
  candidateId,
  candidate,
  rounds,
  onClose,
  onCreated,
}: {
  candidateId: string;
  candidate: CandidateMaster;
  rounds: Round[];
  onClose: () => void;
  onCreated: (round: Round) => void;
}) {
  const [error, setError] = useState<string | null>(null);

  // Interview rounds run in a fixed order — no custom rounds. Round 3 only takes
  // part when the candidate's plan includes it (set once on the Screening round).
  const sequence = ROUND_PRESETS.filter((s) => s !== "Round 3" || candidate.include_round3);
  const existing = new Set(rounds.map((r) => r.round_name as string));
  // The only round that can be added is the first stage not yet created: everything
  // before it is done (locked), everything after it is not unlocked yet.
  const nextStage = sequence.find((s) => !existing.has(s)) ?? null;

  const create = useMutation({
    mutationFn: (rn: string) =>
      roundsService.create({
        candidate_id: candidateId,
        round_name: rn as Round["round_name"],
        domain: candidate.domain ?? "",
        interviewer: "",
        current_ctc: null,
        expected_ctc: null,
        notice_period: null,
        relocation: null,
        scheduled_on: null,
        feedback: null,
        score: null,
        outcome: "Pending",
      }),
    // Hand the created round back so the caller can keep the candidate in context
    // and open it for editing immediately — no reselecting the candidate to modify.
    onSuccess: (res) => onCreated(res.data),
    onError: (e: unknown) => setError(e instanceof Error ? e.message : "Could not create round"),
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/60 p-4">
      <div className="w-full max-w-sm rounded-2xl border border-border bg-card p-5 shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-sm font-bold text-foreground">New round</h2>
          <button onClick={onClose} className="rounded-lg p-1 text-muted-foreground hover:bg-secondary">
            <X className="h-4 w-4" />
          </button>
        </div>

        <label className="text-xs font-medium text-muted-foreground">Round name</label>
        <div className="mt-2 flex flex-wrap items-center gap-1.5">
          {sequence.map((p, i) => {
            const done = existing.has(p);
            const isNext = p === nextStage;
            return (
              <span key={p} className="inline-flex items-center gap-1.5">
                {i > 0 && <ChevronRight className="h-3 w-3 text-muted-foreground/50" />}
                <span
                  className={cn(
                    "inline-flex items-center gap-1 rounded-lg border px-2.5 py-1 text-xs font-medium",
                    done
                      ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-600"
                      : isNext
                        ? "border-primary/50 bg-primary/10 text-primary"
                        : "border-border bg-secondary/40 text-muted-foreground/60"
                  )}
                  title={
                    done
                      ? "Already added"
                      : isNext
                        ? "Next round to add"
                        : "Unlocks once the previous round is added"
                  }
                >
                  {done ? (
                    <CheckCircle2 className="h-3 w-3" />
                  ) : !isNext ? (
                    <Lock className="h-3 w-3" />
                  ) : null}
                  {p}
                </span>
              </span>
            );
          })}
        </div>

        <p className="mt-3 text-[11px] text-muted-foreground">
          {nextStage ? (
            <>
              Next round to add: <span className="font-semibold text-foreground">{nextStage}</span>.
              Rounds follow a fixed sequence — finished rounds are locked.
            </>
          ) : (
            "All rounds in the sequence have been added for this candidate."
          )}
        </p>

        {error && <p className="text-[11px] text-destructive mt-2">{error}</p>}

        <div className="flex justify-end gap-2 mt-5">
          <button onClick={onClose} className="rounded-lg border border-border px-3 py-2 text-xs font-medium text-muted-foreground hover:bg-secondary">
            Cancel
          </button>
          <button
            onClick={() => nextStage && create.mutate(nextStage)}
            disabled={!nextStage || create.isPending}
            className="btn-brand text-xs"
          >
            {create.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Plus className="h-3.5 w-3.5" />}
            {nextStage ? `Add ${nextStage}` : "Add round"}
          </button>
        </div>
      </div>
    </div>
  );
}

function RoundDetailDrawer({
  round,
  candidate,
  rounds,
  onClose,
  onSaved,
}: {
  round: Round;
  candidate: CandidateMaster;
  rounds: Round[];
  onClose: () => void;
  onSaved: () => void;
}) {
  // CTC & notice period are captured ONLY on the Screening round. Every later
  // round (Round 1/2, Final) shows those figures read-only, mirrored from the
  // candidate (candidate_master mirrors the Screening round — see schema.sql).
  const isScreening = round.round_name === "Screening";

  // The next round can't be scheduled BEFORE the previous round, but it CAN be on the
  // same day (multiple rounds can happen back-to-back in one day). Find the round
  // immediately before this one in the candidate's ordered history.
  const idx = rounds.findIndex((r) => r.round_id === round.round_id);
  const prevScheduled = idx > 0 ? rounds[idx - 1].scheduled_on : null;
  // No round may be scheduled in the past.
  const todayStr = new Date().toLocaleDateString("en-CA");
  const prevDay = prevScheduled ? new Date(prevScheduled).toLocaleDateString("en-CA") : null;
  // Earliest allowed date = today, but never before the previous round (same-day is allowed).
  const minScheduled = prevDay && prevDay > todayStr ? prevDay : todayStr;

  const [scheduledOn, setScheduledOn] = useState(round.scheduled_on ? round.scheduled_on.slice(0, 10) : "");
  const [interviewer, setInterviewer] = useState(round.interviewer ?? "");
  const [currentCtc, setCurrentCtc] = useState(round.current_ctc?.toString() ?? "");
  const [expectedCtc, setExpectedCtc] = useState(round.expected_ctc?.toString() ?? "");
  const [noticePeriod, setNoticePeriod] = useState(round.notice_period?.toString() ?? "");
  const [score, setScore] = useState(round.score?.toString() ?? "");
  const [outcome, setOutcome] = useState<string>(round.outcome ?? "");
  const [feedback, setFeedback] = useState(round.feedback ?? "");
  const [advanceTo, setAdvanceTo] = useState<string>("");
  const [error, setError] = useState<string | null>(null);
  // Live Workflow email/acceptance sub-steps for this round.
  const [inviteSent, setInviteSent] = useState(!!round.invite_sent_at);
  const [acceptedSlot, setAcceptedSlot] = useState<boolean | null>(round.candidate_accepted_slot ?? null);
  const [reminderCount, setReminderCount] = useState(round.reminder_count ?? 0);

  // Where a Pass on this round may advance to (skip the optional Round 3 at Round 2).
  const effInclude = candidate.include_round3 ?? false;
  const advanceTargets = allowedAdvance(round.round_name, effInclude);
  const effectiveAdvance =
    advanceTo && advanceTargets.includes(advanceTo) ? advanceTo : advanceTargets[0] ?? null;

  // Score rule: 0–10 when provided.
  const scoreNum = score.trim() === "" ? null : Number(score);
  const scoreInvalid = scoreNum !== null && (Number.isNaN(scoreNum) || scoreNum < 0 || scoreNum > 10);
  // A scheduled date is mandatory — a round can't be saved without one.
  const scheduleMissing = scheduledOn.trim() === "";
  // An interviewer name is mandatory too — every round must name who runs it.
  const interviewerMissing = interviewer.trim() === "";
  // A Pass/Fail outcome is a stage transition — the comment explaining it is
  // mandatory (mirrors the server-side check in PATCH /rounds/{id}).
  const isTransitionOutcome = outcome === "Pass" || outcome === "Fail";
  const feedbackMissing = isTransitionOutcome && feedback.trim() === "";
  // The outcome can only be recorded once the round has actually been SCHEDULED
  // (a date persisted on the round). While you're still scheduling it for the first
  // time, the outcome buttons stay disabled — you enter the result after the interview.
  const roundScheduled = !!round.scheduled_on;
  // …and it can't be in the past or before the previous round. minScheduled already
  // folds both floors (today / previous round); scheduleInPast distinguishes the message.
  const scheduleTooEarly = scheduledOn.trim() !== "" && scheduledOn < minScheduled;
  const scheduleInPast = scheduledOn.trim() !== "" && scheduledOn < todayStr;
  // CTC / notice are only relevant for laterals — freshers have no current CTC.
  const isLateral = showCtc(candidate.fresher_or_lateral);

  // Values shown read-only on non-Screening rounds: prefer the candidate mirror,
  // fall back to this round's own figures.
  const dispCurrentCtc = candidate.current_ctc ?? round.current_ctc;
  const dispExpectedCtc = candidate.expected_ctc ?? round.expected_ctc;
  const dispNoticePeriod = candidate.notice_period ?? round.notice_period;

  const save = useMutation({
    mutationFn: () =>
      roundsService.update(round.round_id, {
        scheduled_on: scheduledOn || null,
        // Interviewer is typed in manually per round.
        interviewer: interviewer.trim(),
        // Only the Screening round owns these fields; never write them from a later round.
        ...(isScreening && {
          current_ctc: currentCtc === "" ? null : Number(currentCtc),
          expected_ctc: expectedCtc === "" ? null : Number(expectedCtc),
          notice_period: noticePeriod === "" ? null : Number(noticePeriod),
        }),
        score: score === "" ? null : Number(score),
        outcome: (outcome || "Pending") as Round["outcome"],
        feedback: feedback || null,
        // On a Pass, the chosen advance target (e.g. Round 2 → skip Round 3 → Final).
        // "Hired" is auto (passing Final), not an advance target, so never sent.
        ...(outcome === "Pass" && effectiveAdvance && effectiveAdvance !== "Hired"
          ? { advance_to: effectiveAdvance }
          : {}),
        // Live Workflow email/acceptance sub-steps.
        invite_sent_at: inviteSent ? round.invite_sent_at ?? new Date().toISOString() : null,
        candidate_accepted_slot: acceptedSlot,
      }),
    onSuccess: () => {
      setError(null);
      onSaved();
      onClose();
    },
    onError: (e: unknown) => setError(e instanceof Error ? e.message : "Save failed"),
  });

  // Reminder emails are logged immediately (not bundled with Save) — capped at 2.
  const sendReminder = useMutation({
    mutationFn: () => roundsService.sendReminder(round.round_id),
    onSuccess: (res) => {
      setReminderCount(res.data.reminder_count ?? 0);
      onSaved();
    },
  });

  // "Share with Interviewer" — mints a signed, candidate+round-scoped link an
  // external interviewer can open without any app login (see app.api.interviewer).
  const [shareUrl, setShareUrl] = useState<string | null>(null);
  const [shareCopied, setShareCopied] = useState(false);
  const shareLink = useMutation({
    mutationFn: () => interviewerService.createLink(candidate.candidate_id, round.round_id),
    onSuccess: ({ data }) => setShareUrl(`${window.location.origin}${data.url_path}`),
  });
  const copyShareLink = async () => {
    if (!shareUrl) return;
    await navigator.clipboard.writeText(shareUrl);
    setShareCopied(true);
    setTimeout(() => setShareCopied(false), 2000);
  };

  // "Send slot invite" — mints/re-sends the candidate-facing slot-selection
  // link for THIS round (see app.api.candidate_slots) and emails it right
  // away, regardless of the Settings → Interview Scheduling "Auto-send
  // invites" toggle (this is an explicit recruiter action, not the automatic
  // stage-advance hook).
  const [slotInviteUrl, setSlotInviteUrl] = useState<string | null>(null);
  const [slotInviteCopied, setSlotInviteCopied] = useState(false);
  const sendSlotInvite = useMutation({
    mutationFn: () => candidateSlotsService.createInvite(candidate.candidate_id, round.round_id),
    onSuccess: ({ data }) => setSlotInviteUrl(`${window.location.origin}${data.url_path}`),
  });
  const copySlotInviteLink = async () => {
    if (!slotInviteUrl) return;
    await navigator.clipboard.writeText(slotInviteUrl);
    setSlotInviteCopied(true);
    setTimeout(() => setSlotInviteCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/40 p-4 backdrop-blur-sm">
      <div className="flex max-h-[90vh] w-full max-w-md flex-col overflow-hidden rounded-2xl bg-card shadow-2xl">
        <div className="flex items-center justify-between border-b border-border px-5 py-4">
          <div>
            <h2 className="text-sm font-bold text-foreground">{round.round_name}</h2>
            <p className="text-[11px] text-muted-foreground">Round details</p>
          </div>
          <button onClick={onClose} className="rounded-lg p-1.5 text-muted-foreground hover:bg-secondary hover:text-foreground">
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="border-b border-border bg-secondary/20 px-5 py-2.5">
          {shareUrl ? (
            <div className="flex items-center gap-1.5">
              <input
                readOnly
                value={shareUrl}
                onFocus={(e) => e.target.select()}
                className="flex-1 truncate rounded-lg border border-border bg-secondary px-2 py-1 text-[11px] text-foreground"
              />
              <button
                onClick={copyShareLink}
                className="flex shrink-0 items-center gap-1 rounded-lg border border-border px-2 py-1 text-[10px] font-semibold text-muted-foreground hover:text-foreground"
              >
                <Copy className="h-3 w-3" /> {shareCopied ? "Copied" : "Copy"}
              </button>
            </div>
          ) : (
            <button
              onClick={() => shareLink.mutate()}
              disabled={shareLink.isPending}
              className="flex items-center gap-1.5 text-[11px] font-semibold text-muted-foreground hover:text-foreground disabled:opacity-50"
            >
              {shareLink.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Share2 className="h-3.5 w-3.5" />}
              Share with Interviewer
            </button>
          )}
          {shareLink.isError && (
            <p className="mt-1 text-[10px] text-destructive">Couldn't create the link. Try again.</p>
          )}
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
          <fieldset className="m-0 space-y-4 border-0 p-0">
          <div className="space-y-1.5">
            <Label>Interviewer <span className="text-destructive">*</span></Label>
            <TextInput
              value={interviewer}
              onChange={setInterviewer}
              placeholder="Interviewer name"
              className={cn(interviewerMissing && "border-destructive/60")}
            />
            {interviewerMissing && (
              <p className="text-[10px] text-muted-foreground">An interviewer name is required to save this round.</p>
            )}
          </div>
          <div className="space-y-1.5">
            <Label>Scheduled date <span className="text-destructive">*</span></Label>
            <input
              type="date"
              value={scheduledOn}
              min={minScheduled}
              onChange={(e) => setScheduledOn(e.target.value)}
              className={cn("field-input", (scheduleMissing || scheduleTooEarly) && "border-destructive/60")}
            />
            {scheduleMissing ? (
              <p className="text-[10px] text-muted-foreground">A scheduled date is required to save this round.</p>
            ) : scheduleInPast ? (
              <p className="text-[10px] text-destructive">Scheduled date can't be in the past.</p>
            ) : scheduleTooEarly ? (
              <p className="text-[10px] text-destructive">
                Can't be before the previous round ({fmtReceived(prevScheduled)}).
              </p>
            ) : prevScheduled ? (
              <p className="text-[10px] text-muted-foreground">
                Previous round was on {fmtReceived(prevScheduled)} — same day or later is fine.
              </p>
            ) : null}
          </div>

          <div className="space-y-1.5">
            <Label>Invite &amp; slot acceptance</Label>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => setInviteSent((v) => !v)}
                className={cn(
                  "flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-xs font-medium transition-colors",
                  inviteSent
                    ? "border-sky-500/40 bg-sky-500/10 text-sky-600"
                    : "border-border text-muted-foreground hover:text-foreground"
                )}
              >
                <span
                  className={cn(
                    "flex h-3.5 w-3.5 items-center justify-center rounded border",
                    inviteSent ? "border-sky-500 bg-sky-500 text-white" : "border-border"
                  )}
                >
                  {inviteSent && <Check className="h-2.5 w-2.5" />}
                </span>
                Invite sent
              </button>
              <button
                type="button"
                disabled={reminderCount >= 2 || sendReminder.isPending}
                onClick={() => sendReminder.mutate()}
                className="flex items-center gap-1.5 rounded-lg border border-amber-500/30 bg-amber-500/10 px-2.5 py-1.5 text-xs font-medium text-amber-600 transition-colors hover:bg-amber-500/20 disabled:cursor-not-allowed disabled:opacity-40"
              >
                Send reminder ({reminderCount}/2)
              </button>
              <button
                type="button"
                disabled={sendSlotInvite.isPending}
                onClick={() => sendSlotInvite.mutate()}
                title="Email the candidate a link to pick their own interview slot"
                className="flex items-center gap-1.5 rounded-lg border border-primary/30 bg-primary/5 px-2.5 py-1.5 text-xs font-medium text-primary transition-colors hover:bg-primary/10 disabled:cursor-not-allowed disabled:opacity-40"
              >
                {sendSlotInvite.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <CalendarClock className="h-3.5 w-3.5" />}
                Send slot invite
              </button>
            </div>
            {slotInviteUrl && (
              <div className="flex items-center gap-1.5">
                <input
                  readOnly
                  value={slotInviteUrl}
                  onFocus={(e) => e.target.select()}
                  className="flex-1 truncate rounded-lg border border-border bg-secondary px-2 py-1 text-[11px] text-foreground"
                />
                <button
                  onClick={copySlotInviteLink}
                  className="flex shrink-0 items-center gap-1 rounded-lg border border-border px-2 py-1 text-[10px] font-semibold text-muted-foreground hover:text-foreground"
                >
                  <Copy className="h-3 w-3" /> {slotInviteCopied ? "Copied" : "Copy"}
                </button>
              </div>
            )}
            {sendSlotInvite.isError && (
              <p className="text-[10px] text-destructive">Couldn't send the slot invite. Try again.</p>
            )}
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] text-muted-foreground">Accepted slot?</span>
              {[
                { v: true, label: "Yes" },
                { v: false, label: "No" },
                { v: null, label: "Pending" },
              ].map((opt) => (
                <button
                  key={String(opt.v)}
                  type="button"
                  onClick={() => setAcceptedSlot(opt.v)}
                  className={cn(
                    "rounded-lg border px-2 py-1 text-[11px] font-semibold transition-colors",
                    acceptedSlot === opt.v
                      ? opt.v === true
                        ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-600"
                        : opt.v === false
                          ? "border-rose-500/40 bg-rose-500/10 text-rose-600"
                          : "border-border bg-secondary text-foreground"
                      : "border-border text-muted-foreground hover:text-foreground"
                  )}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {isLateral && (isScreening ? (
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Current CTC (LPA)</Label>
                <TextInput value={currentCtc} onChange={setCurrentCtc} placeholder="e.g. 8.5" type="number" />
              </div>
              <div className="space-y-1.5">
                <Label>Expected CTC (LPA)</Label>
                <TextInput value={expectedCtc} onChange={setExpectedCtc} placeholder="e.g. 12.0" type="number" />
              </div>
              <div className="space-y-1.5 col-span-2">
                <Label>Notice Period (days)</Label>
                <TextInput value={noticePeriod} onChange={setNoticePeriod} placeholder="e.g. 30" type="number" />
              </div>
            </div>
          ) : (
            <div className="space-y-1.5">
              <Label>Compensation &amp; notice</Label>
              <div className="grid grid-cols-3 gap-3 rounded-lg border border-border bg-secondary/40 p-3">
                <ReadOnlyStat label="Current CTC" value={dispCurrentCtc != null ? `${dispCurrentCtc} LPA` : "—"} />
                <ReadOnlyStat label="Expected CTC" value={dispExpectedCtc != null ? `${dispExpectedCtc} LPA` : "—"} />
                <ReadOnlyStat label="Notice" value={dispNoticePeriod != null ? `${dispNoticePeriod} days` : "—"} />
              </div>
              <p className="text-[11px] text-muted-foreground">Captured on the Call round.</p>
            </div>
          ))}
          <div className="space-y-1.5">
            <Label>Outcome</Label>
            <div className="grid grid-cols-3 gap-1.5">
              {OUTCOME_CHOICES.map((o) => (
                <button
                  key={o}
                  disabled={!roundScheduled}
                  onClick={() => setOutcome(o)}
                  className={cn(
                    "py-1.5 rounded-lg border text-xs font-semibold transition-colors",
                    !roundScheduled
                      ? "cursor-not-allowed border-border text-muted-foreground/50 opacity-60"
                      : outcome === o ? (OUTCOME_COLORS[o] ?? "") + " ring-1 ring-current/30" : "border-border text-muted-foreground hover:text-foreground"
                  )}
                >
                  {outcomeLabel(o)}
                </button>
              ))}
            </div>
            <p className="text-[10px] text-muted-foreground">
              {roundScheduled
                ? "Pending auto-flips once the scheduled date passes without an outcome."
                : "Schedule this round first — you can record the outcome once it's scheduled."}
            </p>
          </div>
          {/* Round 2 can either run the optional Round 3 or skip straight to Final. */}
          {outcome === "Pass" && advanceTargets.length > 1 && (
            <div className="space-y-1.5">
              <Label>Advance to</Label>
              <select
                value={effectiveAdvance ?? ""}
                onChange={(e) => setAdvanceTo(e.target.value)}
                className="field-input cursor-pointer"
              >
                {advanceTargets.map((s) => (
                  <option key={s} value={s}>
                    {s} {s === "Final" ? "· skip Round 3" : ""}
                  </option>
                ))}
              </select>
              <p className="text-[11px] text-muted-foreground">
                Round 3 is optional — pick it or skip straight to Final.
              </p>
            </div>
          )}
          <div className="space-y-1.5">
            <Label>Score (0-10)</Label>
            <input
              type="number"
              min={0}
              max={10}
              step={0.1}
              value={score}
              onChange={(e) => setScore(e.target.value)}
              placeholder="e.g. 7.5"
              className={cn("field-input", scoreInvalid && "border-destructive focus:border-destructive")}
            />
            {scoreInvalid && <p className="text-[11px] text-destructive">Score must be between 0 and 10.</p>}
          </div>
          <div className="space-y-1.5">
            <Label>
              Notes {isTransitionOutcome && <span className="text-destructive">*</span>}
            </Label>
            <textarea
              value={feedback}
              onChange={(e) => setFeedback(e.target.value)}
              rows={4}
              placeholder="Interview notes…"
              className={cn("field-input resize-y", feedbackMissing && "border-destructive/60")}
            />
            {feedbackMissing && (
              <p className="text-[10px] text-muted-foreground">
                Notes are required when recording a Pass/Fail outcome.
              </p>
            )}
          </div>
          {error && <p className="text-[11px] text-destructive">{error}</p>}
          </fieldset>
        </div>

        <div className="border-t border-border px-5 py-3 flex justify-end gap-2">
          <button onClick={onClose} className="rounded-lg border border-border px-3 py-2 text-xs font-medium text-muted-foreground hover:bg-secondary">
            Close
          </button>
          <button
            onClick={() => {
              if (interviewerMissing) {
                setError("Please enter an interviewer name before saving.");
                return;
              }
              if (scheduleMissing) {
                setError("Please set a scheduled date before saving.");
                return;
              }
              if (scheduleInPast) {
                setError("Scheduled date can't be in the past.");
                return;
              }
              if (scheduleTooEarly) {
                setError(`Scheduled date can't be before the previous round (${fmtReceived(prevScheduled)}).`);
                return;
              }
              if (feedbackMissing) {
                setError("Please add notes before recording a Pass/Fail outcome.");
                return;
              }
              save.mutate();
            }}
            disabled={
              save.isPending ||
              scoreInvalid ||
              interviewerMissing ||
              scheduleMissing ||
              scheduleTooEarly ||
              feedbackMissing
            }
            className="btn-brand text-xs"
          >
            {save.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <CheckCircle2 className="h-3.5 w-3.5" />}
            Save
          </button>
        </div>
      </div>
    </div>
  );
}
