import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  AlertTriangle,
  Calendar,
  Clock,
  KeyRound,
  Loader2,
  Mail,
  User2,
  X,
} from "lucide-react";
import ThemeToggle from "@/components/layout/ThemeToggle";
import logo from "@/logo/neuleap_logo.png";
import {
  PoolInterviewerApiError,
  poolInterviewerService,
  poolInterviewerSession,
  type PoolInterviewerMe,
} from "@/services/poolInterviewer";
import type { PoolSlot } from "@/services/interviewPools";

type Screen = "loading" | "email" | "code" | "slots";

function AuthShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-background px-4">
      <div className="gradient-mesh pointer-events-none absolute inset-0 opacity-70" />
      <div className="absolute right-4 top-4 z-10">
        <ThemeToggle />
      </div>
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
        className="surface-float relative w-full max-w-sm p-8"
      >
        <div className="mb-6 flex flex-col items-center text-center">
          <img src={logo} alt="Talents Scooper" className="h-11 w-11 rounded-xl object-cover" />
          <h1 className="mt-3 text-lg font-semibold tracking-[-0.02em] text-ink">Interviewer Portal</h1>
          <p className="text-[11px] font-semibold uppercase tracking-[0.08em] text-primary">@NeuLeap.Ai</p>
        </div>
        {children}
      </motion.div>
    </div>
  );
}

const fmtDay = (iso: string) =>
  new Date(iso).toLocaleDateString(undefined, { weekday: "short", day: "2-digit", month: "short" });
const fmtTime = (iso: string) => new Date(iso).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" });

export default function InterviewerPoolPortal() {
  const [screen, setScreen] = useState<Screen>("loading");
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [email, setEmail] = useState("");
  const [codeRaw, setCodeRaw] = useState("");
  const [remember, setRemember] = useState(false);
  const [busy, setBusy] = useState(false);
  const [sessionToken, setSessionToken] = useState<string | null>(null);
  const [me, setMe] = useState<PoolInterviewerMe | null>(null);

  useEffect(() => {
    const existing = poolInterviewerSession.get();
    if (!existing) {
      setScreen("email");
      return;
    }
    poolInterviewerService
      .me(existing)
      .then((res) => {
        setSessionToken(existing);
        setMe(res);
        setScreen("slots");
      })
      .catch(() => {
        poolInterviewerSession.clear();
        setScreen("email");
      });
  }, []);

  const requestCode = async () => {
    if (!email.trim()) return;
    setBusy(true);
    setErrorMsg(null);
    try {
      await poolInterviewerService.requestCode(email.trim());
      setScreen("code");
    } catch (e) {
      setErrorMsg(e instanceof PoolInterviewerApiError ? e.message : "Couldn't send the code. Try again.");
    } finally {
      setBusy(false);
    }
  };

  const verifyCode = async () => {
    if (codeRaw.length < 6) return;
    setBusy(true);
    setErrorMsg(null);
    try {
      const res = await poolInterviewerService.verifyCode(email.trim(), codeRaw, remember);
      setSessionToken(res.session_token);
      if (remember) poolInterviewerSession.set(res.session_token);
      setMe({ email: email.trim(), name: res.name, round_names: res.round_names });
      setScreen("slots");
    } catch (e) {
      setErrorMsg(e instanceof PoolInterviewerApiError ? e.message : "Verification failed.");
    } finally {
      setBusy(false);
    }
  };

  if (screen === "loading") {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (screen === "email") {
    return (
      <AuthShell>
        <p className="mb-4 text-center text-xs text-ink-mute">
          Enter your work email to manage the interview slots reserved for you.
        </p>
        <div className="space-y-3">
          <div className="relative">
            <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-mute" />
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && requestCode()}
              placeholder="you@company.com"
              className="w-full rounded-xl border border-border bg-secondary/40 py-2.5 pl-9 pr-3 text-sm text-ink outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/30"
            />
          </div>
          {errorMsg && <p className="rounded-lg bg-red-500/10 px-3 py-2 text-xs font-medium text-red-500">{errorMsg}</p>}
          <button
            onClick={requestCode}
            disabled={busy || !email.trim()}
            className="btn-brand w-full disabled:cursor-not-allowed disabled:opacity-60"
          >
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Send me a code"}
          </button>
        </div>
      </AuthShell>
    );
  }

  if (screen === "code") {
    return (
      <AuthShell>
        <p className="mb-4 text-center text-xs text-ink-mute">
          We sent a code to <span className="font-medium text-ink">{email}</span>. It expires in 10 minutes.
        </p>
        <div className="space-y-3">
          <div className="relative">
            <KeyRound className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-mute" />
            <input
              value={codeRaw}
              onChange={(e) => setCodeRaw(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 6))}
              onKeyDown={(e) => e.key === "Enter" && verifyCode()}
              placeholder="XXXXXX"
              maxLength={6}
              className="w-full rounded-xl border border-border bg-secondary/40 py-2.5 pl-9 pr-3 text-center text-sm font-semibold tracking-[0.2em] text-ink outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/30"
            />
          </div>
          <label className="flex cursor-pointer items-center gap-2 text-xs text-ink-mute">
            <input
              type="checkbox"
              checked={remember}
              onChange={(e) => setRemember(e.target.checked)}
              className="h-3.5 w-3.5 rounded border-border accent-primary"
            />
            Remember this device
          </label>
          {errorMsg && <p className="rounded-lg bg-red-500/10 px-3 py-2 text-xs font-medium text-red-500">{errorMsg}</p>}
          <button
            onClick={verifyCode}
            disabled={busy || codeRaw.length < 6}
            className="btn-brand w-full disabled:cursor-not-allowed disabled:opacity-60"
          >
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Verify"}
          </button>
          <button
            onClick={() => { setScreen("email"); setCodeRaw(""); setErrorMsg(null); }}
            className="w-full text-center text-[11px] text-muted-foreground hover:text-foreground"
          >
            Use a different email
          </button>
        </div>
      </AuthShell>
    );
  }

  if (!sessionToken || !me) return null;
  return <SlotsView sessionToken={sessionToken} me={me} />;
}

function SlotsView({ sessionToken, me }: { sessionToken: string; me: PoolInterviewerMe }) {
  const [slots, setSlots] = useState<PoolSlot[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [proposing, setProposing] = useState<number | null>(null);
  const [proposeStart, setProposeStart] = useState("");
  const [proposeEnd, setProposeEnd] = useState("");
  const [busyId, setBusyId] = useState<number | null>(null);

  const load = () => {
    poolInterviewerService
      .mySlots(sessionToken)
      .then(setSlots)
      .catch((e) => setError(e instanceof PoolInterviewerApiError ? e.message : "Couldn't load your slots."));
  };

  useEffect(load, [sessionToken]);

  const remove = async (slotId: number) => {
    setBusyId(slotId);
    setError(null);
    try {
      await poolInterviewerService.removeSlot(sessionToken, slotId);
      load();
    } catch (e) {
      setError(e instanceof PoolInterviewerApiError ? e.message : "Couldn't remove that slot.");
    } finally {
      setBusyId(null);
    }
  };

  const submitPropose = async (slotId: number) => {
    if (!proposeStart || !proposeEnd) return;
    setBusyId(slotId);
    setError(null);
    try {
      await poolInterviewerService.proposeTime(sessionToken, slotId, proposeStart, proposeEnd);
      setProposing(null);
      load();
    } catch (e) {
      setError(e instanceof PoolInterviewerApiError ? e.message : "That time didn't work — try another.");
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div className="min-h-screen bg-background px-4 py-8">
      <div className="mx-auto flex max-w-2xl flex-col gap-4">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <img src={logo} alt="Talents Scooper" className="h-8 w-8 rounded-lg object-cover" />
            <div>
              <p className="text-[10px] font-semibold uppercase tracking-[0.08em] text-primary">Interviewer Portal</p>
              <h1 className="text-lg font-semibold text-foreground">Hi {me.name?.split(" ")[0] ?? "there"}</h1>
            </div>
          </div>
          <ThemeToggle />
        </div>

        <div className="flex items-center gap-2 rounded-xl border border-border bg-card px-4 py-3 text-xs text-muted-foreground">
          <User2 className="h-3.5 w-3.5 shrink-0" />
          Rostered for: {me.round_names.length > 0 ? me.round_names.join(", ") : "no rounds yet"}
        </div>

        {error && <p className="rounded-lg bg-red-500/10 px-3 py-2 text-xs font-medium text-red-500">{error}</p>}

        <div className="rounded-xl border border-border bg-card p-5">
          <div className="mb-4 flex items-center gap-2">
            <Calendar className="h-4 w-4 text-muted-foreground" />
            <h2 className="text-sm font-semibold text-foreground">Your reserved interview slots</h2>
          </div>

          {!slots ? (
            <div className="flex items-center gap-2 py-6 text-xs text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" /> Loading…
            </div>
          ) : slots.length === 0 ? (
            <p className="py-6 text-center text-xs text-muted-foreground">No placeholder slots reserved for you right now.</p>
          ) : (
            <div className="space-y-2">
              {slots.map((s) => (
                <div key={s.id} className="rounded-lg border border-border/60 bg-secondary/20 p-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="text-xs">
                      <span className="rounded-full bg-primary/10 px-1.5 py-0.5 text-[10px] font-semibold text-primary">
                        {s.round_name}
                      </span>{" "}
                      <span className="font-semibold text-foreground">{fmtDay(s.slot_start)}</span>{" "}
                      <span className="text-muted-foreground">
                        <Clock className="mr-1 inline h-3 w-3" />
                        {fmtTime(s.slot_start)}–{fmtTime(s.slot_end)}
                      </span>
                      {s.status === "booked" && (
                        <span className="ml-2 rounded-full bg-emerald-500/10 px-2 py-0.5 text-[10px] font-semibold text-emerald-600">
                          Booked by a candidate
                        </span>
                      )}
                    </div>
                    {s.status === "open" && (
                      <div className="flex shrink-0 items-center gap-1.5">
                        <button
                          onClick={() => { setProposing(s.id); setProposeStart(""); setProposeEnd(""); }}
                          className="rounded-lg border border-border px-2 py-1 text-[11px] font-medium text-muted-foreground hover:text-foreground"
                        >
                          Adjust
                        </button>
                        <button
                          onClick={() => remove(s.id)}
                          disabled={busyId === s.id}
                          className="flex items-center gap-1 rounded-lg border border-red-500/30 bg-red-500/5 px-2 py-1 text-[11px] font-medium text-red-500 hover:bg-red-500/10 disabled:opacity-50"
                        >
                          {busyId === s.id ? <Loader2 className="h-3 w-3 animate-spin" /> : <X className="h-3 w-3" />}
                          Remove
                        </button>
                      </div>
                    )}
                  </div>
                  {proposing === s.id && (
                    <div className="mt-2 flex flex-wrap items-center gap-2">
                      <input
                        type="datetime-local"
                        value={proposeStart}
                        onChange={(e) => setProposeStart(e.target.value)}
                        className="rounded-lg border border-border bg-secondary px-2 py-1 text-xs text-foreground"
                      />
                      <input
                        type="datetime-local"
                        value={proposeEnd}
                        onChange={(e) => setProposeEnd(e.target.value)}
                        className="rounded-lg border border-border bg-secondary px-2 py-1 text-xs text-foreground"
                      />
                      <button
                        onClick={() => submitPropose(s.id)}
                        disabled={busyId === s.id || !proposeStart || !proposeEnd}
                        className="rounded-lg bg-primary px-2.5 py-1 text-[11px] font-semibold text-primary-foreground disabled:opacity-50"
                      >
                        Save new time
                      </button>
                      <button onClick={() => setProposing(null)} className="text-[11px] text-muted-foreground hover:text-foreground">
                        Cancel
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        <p className="flex items-center gap-1.5 pb-4 text-center text-[11px] text-muted-foreground">
          <AlertTriangle className="h-3 w-3 shrink-0" />
          You can also remove or move these events directly on your own calendar — changes sync back here within the hour.
        </p>
      </div>
    </div>
  );
}
