import { useEffect, useRef, useState } from "react";
import { useMutation } from "@tanstack/react-query";
import {
  ArrowUp,
  Loader2,
  Database,
  Sparkles,
  ChevronDown,
  AlertCircle,
  Plus,
  X,
  Mic,
  Maximize2,
  Minimize2,
} from "lucide-react";
import { chatbotService, type ChatResult, type ChatTurn } from "@/services/chatbot";
import { cn, titleCase, formatExperience, formatScore } from "@/lib/utils";
import { useSpeechRecognition } from "@/hooks/useSpeechRecognition";

const SAMPLES = [
  "Show data engineer candidates with experience",
  "Top GenAI candidates this week",
  "Passed Round 1 but no Round 2 scheduled",
  "Pending Resume list",
  "Archived candidates with atsscore > 60",
  "Lateral candidates willing to relocate",
];

interface Entry {
  question: string;
  result?: ChatResult;
  error?: string;
  pending?: boolean;
}

// Persist the conversation for the lifetime of the browser tab (chat session), so a
// reload or navigating away and back doesn't wipe the thread. Cleared when the tab closes.
const HISTORY_KEY = "chatbot:history";

function loadHistory(): Entry[] {
  try {
    const raw = sessionStorage.getItem(HISTORY_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as Entry[];
    if (!Array.isArray(parsed)) return [];
    // Drop a turn that was still in-flight when the tab was last closed/reloaded —
    // otherwise it would be stuck on "Thinking…" forever.
    return parsed
      .filter((e) => e && typeof e.question === "string" && !e.pending)
      .map(({ pending: _pending, ...e }) => e);
  } catch {
    return [];
  }
}

function saveHistory(history: Entry[]) {
  try {
    // Never persist a pending turn — it can't be resumed after a reload.
    const stable = history.filter((e) => !e.pending);
    if (stable.length === 0) sessionStorage.removeItem(HISTORY_KEY);
    else sessionStorage.setItem(HISTORY_KEY, JSON.stringify(stable));
  } catch {
    /* sessionStorage unavailable (private mode / quota) — non-fatal. */
  }
}

// The chatbot's SQL is LLM-generated against arbitrary tables/columns, so
// there's no fixed schema to format against — these are name-pattern
// heuristics applied to whatever column names come back, not a lookup
// against a known column list.
const YEAR_COLUMN_RE = /(year|yoe|experience)/i;
const NAME_COLUMN_RE = /(^|_)name$/i;

// A column is "fractional" if ANY row shows a non-integer value for it —
// treated as a measurement/score column (2 decimals, or 1 for years) and
// every cell in it is reformatted to the same precision so the column reads
// as one consistent number, not a mix of "5" and "74.897770749767". A column
// where every row happens to be a whole number (row counts, day counts, IDs)
// is left as a plain integer — EXCEPT a year/experience column, which is
// conceptually always a fractional quantity even when a given result is a
// round number, so it forces 1 decimal regardless.
function columnIsFractional(rows: Record<string, unknown>[], col: string): boolean {
  return rows.some((r) => {
    const v = r[col];
    return typeof v === "number" && !Number.isInteger(v);
  });
}

function formatCell(col: string, value: unknown, fractional: boolean): string {
  if (value == null) return "—";
  if (typeof value === "number") {
    if (YEAR_COLUMN_RE.test(col)) return formatExperience(value);
    if (fractional) return formatScore(value);
    return String(value);
  }
  if (typeof value === "string" && NAME_COLUMN_RE.test(col)) {
    return titleCase(value);
  }
  return String(value);
}

function ResultTable({ rows }: { rows: Record<string, unknown>[] }) {
  if (rows.length === 0) return null;
  const cols = Object.keys(rows[0]);
  const fractionalCols = new Set(cols.filter((c) => columnIsFractional(rows, c)));
  return (
    <div className="overflow-x-auto rounded-lg border border-border">
      <table className="w-full text-xs">
        <thead>
          <tr className="border-b border-border bg-secondary">
            {cols.map((c) => (
              <th
                key={c}
                className="px-3 py-2 text-left text-[11px] font-medium uppercase tracking-wide text-ink-mute whitespace-nowrap"
              >
                {c}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i} className="border-b border-border last:border-0 hover:bg-secondary">
              {cols.map((c) => (
                <td key={c} className="px-3 py-2 text-ink whitespace-nowrap tnum">
                  {formatCell(c, r[c], fractionalCols.has(c))}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function SqlDisclosure({ sql }: { sql: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div>
      <button
        onClick={() => setOpen((o) => !o)}
        className="inline-flex items-center gap-1 text-[11px] text-ink-mute hover:text-primary transition-colors"
      >
        <Database className="h-3 w-3" />
        {open ? "Hide" : "Show"} SQL
        <ChevronDown className={cn("h-3 w-3 transition-transform", open && "rotate-180")} />
      </button>
      {open && (
        <code className="mt-1.5 block text-[11px] text-ink-secondary bg-secondary rounded-md px-3 py-2 font-mono break-all">
          {sql}
        </code>
      )}
    </div>
  );
}

const BOT_NAME = "Talents Scooper";

function BotAvatar() {
  return (
    <div className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-primary to-brand-deep shadow-[0_2px_8px_hsla(248,98%,61%,0.35)]">
      <Sparkles className="h-4 w-4 text-white" />
    </div>
  );
}

function TypingDots() {
  return (
    <span className="inline-flex items-center gap-1">
      {[0, 1, 2].map((i) => (
        <span
          key={i}
          className="h-1.5 w-1.5 rounded-full bg-primary/60 animate-bounce"
          style={{ animationDelay: `${i * 0.15}s` }}
        />
      ))}
    </span>
  );
}

function AssistantBubble({ entry }: { entry: Entry }) {
  return (
    <div className="flex gap-3">
      <BotAvatar />
      <div className="min-w-0 flex-1 space-y-2.5">
        <div className="flex items-center gap-2 text-[13px] font-semibold text-ink">
          {BOT_NAME}
          {entry.result?.retried && <span className="pill-tag-soft">refined</span>}
        </div>
        {entry.pending ? (
          <div className="flex items-center gap-2 text-sm text-ink-mute">
            <TypingDots /> <span>{BOT_NAME} is thinking…</span>
          </div>
        ) : entry.error ? (
          <div className="flex items-start gap-2 rounded-lg border border-rose-500/30 bg-rose-500/5 px-3 py-2 text-sm text-rose-600">
            <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
            <span>{entry.error}</span>
          </div>
        ) : entry.result ? (
          entry.result.type === "info" ? (
            <div className="text-sm leading-relaxed text-ink">
              {entry.result.answer}
            </div>
          ) : (
          <>
            <div className="text-sm leading-relaxed text-ink">
              {entry.result.answer ?? `Found ${entry.result.row_count} record(s).`}
            </div>
            <ResultTable rows={entry.result.rows} />
            {entry.result.total_count != null &&
              entry.result.total_count > entry.result.row_count && (
                <p className="text-[11px] text-ink-mute">
                  Showing top {entry.result.row_count} of {entry.result.total_count} matches
                </p>
              )}
            {entry.result.sql && <SqlDisclosure sql={entry.result.sql} />}
          </>
          )
        ) : null}
      </div>
    </div>
  );
}

export default function Chatbot({
  onClose,
  pageContext,
  maximized,
  onToggleMaximize,
}: {
  onClose?: () => void;
  // Short description of whatever page/candidate the recruiter is currently
  // on (see @/lib/pageContext) — read fresh by the caller on every render,
  // so a follow-up question reflects wherever they've navigated to since the
  // chat was opened, not wherever they were when it first opened.
  pageContext?: string;
  maximized?: boolean;
  onToggleMaximize?: () => void;
} = {}) {
  const [question, setQuestion] = useState("");
  const [history, setHistory] = useState<Entry[]>(loadHistory);
  const scrollRef = useRef<HTMLDivElement>(null);
  const taRef = useRef<HTMLTextAreaElement>(null);
  // Snapshot of whatever text was already in the box the moment voice input
  // started — dictated speech APPENDS to it rather than clobbering it, so a
  // recruiter can type part of a question and dictate the rest.
  const voiceBaseTextRef = useRef("");

  const {
    supported: speechSupported,
    listening,
    error: speechError,
    start: startListening,
    stop: stopListening,
  } = useSpeechRecognition({
    onResult: (transcript) => {
      const next = (voiceBaseTextRef.current ? voiceBaseTextRef.current + " " : "") + transcript;
      setQuestion(next);
      requestAnimationFrame(() => {
        if (taRef.current) autoGrow(taRef.current);
      });
    },
  });

  const toggleListening = () => {
    if (listening) {
      stopListening();
    } else {
      voiceBaseTextRef.current = question.trim();
      startListening();
    }
  };

  const ask = useMutation({
    mutationFn: ({
      question,
      history,
    }: {
      question: string;
      history: ChatTurn[];
    }) => chatbotService.query(question, history, pageContext),
    onSuccess: (res) =>
      setHistory((h) => {
        const next = [...h];
        next[next.length - 1] = { ...next[next.length - 1], result: res.data, pending: false };
        return next;
      }),
    onError: (e: unknown) =>
      setHistory((h) => {
        const next = [...h];
        next[next.length - 1] = {
          ...next[next.length - 1],
          error: e instanceof Error ? e.message : "Query failed",
          pending: false,
        };
        return next;
      }),
  });

  // Keep the viewport pinned to the newest message (ChatGPT-style).
  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [history]);

  // Persist the thread to the chat session so it survives reloads within the tab.
  useEffect(() => {
    saveHistory(history);
  }, [history]);

  const submit = (q: string) => {
    const trimmed = q.trim();
    if (!trimmed || ask.isPending) return;
    if (listening) stopListening();
    setQuestion("");
    if (taRef.current) taRef.current.style.height = "auto";

    // Replay completed prior turns so a short follow-up keeps its context. For a SQL
    // answer we include the SQL too, so the model knows what it already answered.
    const priorTurns: ChatTurn[] = history.flatMap((e) => {
      const turns: ChatTurn[] = [{ role: "user", content: e.question }];
      if (e.result) {
        const content =
          e.result.type === "sql" && e.result.sql
            ? `${e.result.answer ?? ""}\nSQL: ${e.result.sql}`.trim()
            : e.result.answer ?? "";
        if (content) turns.push({ role: "assistant", content });
      }
      return turns;
    });

    setHistory((h) => [...h, { question: trimmed, pending: true }]);
    ask.mutate({ question: trimmed, history: priorTurns });
  };

  const newChat = () => {
    if (ask.isPending) return;
    if (listening) stopListening();
    setHistory([]);
    setQuestion("");
    try {
      sessionStorage.removeItem(HISTORY_KEY);
    } catch {
      /* non-fatal */
    }
    taRef.current?.focus();
  };

  const onKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      submit(question);
    }
  };

  const autoGrow = (el: HTMLTextAreaElement) => {
    el.style.height = "auto";
    el.style.height = `${Math.min(el.scrollHeight, 180)}px`;
  };

  const isEmpty = history.length === 0;

  return (
    <div className="flex h-full flex-col">
      {/* Slim header — a chat surface shouldn't spend a tall hero band on its title. */}
      <div className="shrink-0 border-b border-border/60 px-4 py-2.5 sm:px-6">
        <div className="mx-auto flex max-w-[820px] items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-brand-deep shadow-[0_2px_8px_hsla(248,98%,61%,0.30)]">
              <Sparkles className="h-4 w-4 text-white" />
            </div>
            <div className="min-w-0">
              <div className="text-sm font-semibold leading-tight text-ink">{BOT_NAME}</div>
              <div className="truncate text-[11px] text-ink-mute">
                Recruiting copilot · plain-English over your data
              </div>
            </div>
          </div>
          <div className="flex shrink-0 items-center gap-1.5">
            {!isEmpty && (
              <button
                onClick={newChat}
                disabled={ask.isPending}
                className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1.5 text-xs font-medium text-ink-secondary transition-colors hover:border-primary/40 hover:text-ink disabled:opacity-40"
              >
                <Plus className="h-3.5 w-3.5" />
                New chat
              </button>
            )}
            {onToggleMaximize && (
              <button
                onClick={onToggleMaximize}
                aria-label={maximized ? "Restore chat size" : "Maximize chat"}
                title={maximized ? "Restore" : "Maximize"}
                className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-ink-mute transition-colors hover:bg-secondary hover:text-ink"
              >
                {maximized ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
              </button>
            )}
            {onClose && (
              <button
                onClick={onClose}
                aria-label="Close chat"
                className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-ink-mute transition-colors hover:bg-secondary hover:text-ink"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Conversation */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto px-4">
        <div className={cn("mx-auto max-w-[820px]", isEmpty && "flex h-full items-center justify-center")}>
          {isEmpty ? (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-brand-deep shadow-[0_8px_24px_hsla(248,98%,61%,0.35)]">
                <Sparkles className="h-7 w-7 text-white" />
              </div>
              <h2 className="text-[24px] font-light tracking-[-0.01em] text-ink">
                Hi, I'm {BOT_NAME} 👋
              </h2>
              <p className="mt-1.5 max-w-[420px] text-sm text-ink-mute">
                Ask me anything about your candidates in plain English — I'll pull it
                live from your data and remember the conversation.
              </p>
              <p className="mt-7 text-[11px] font-medium uppercase tracking-wide text-ink-mute">
                Try asking
              </p>
              <div className="mt-3 flex max-w-[640px] flex-wrap justify-center gap-2">
                {SAMPLES.map((s) => (
                  <button
                    key={s}
                    onClick={() => submit(s)}
                    className="rounded-full border border-border bg-card px-3.5 py-1.5 text-xs text-ink-secondary transition-all hover:-translate-y-0.5 hover:border-primary/40 hover:text-ink hover:shadow-sm"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="space-y-8 py-6">
              {history.map((entry, i) => (
                <div key={i} className="space-y-5">
                  {/* User message — right aligned bubble */}
                  <div className="flex justify-end">
                    <div className="max-w-[80%] rounded-2xl rounded-br-md bg-primary px-4 py-2.5 text-sm text-white">
                      {entry.question}
                    </div>
                  </div>
                  {/* Assistant response */}
                  <AssistantBubble entry={entry} />
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Composer — pinned to the bottom, ChatGPT-style */}
      <div className="px-4 pb-5 pt-2">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            submit(question);
          }}
          className="mx-auto max-w-[820px]"
        >
          <div className="flex items-end gap-2 rounded-3xl border border-input bg-card p-2 pl-4 shadow-[0_1px_3px_hsla(207,100%,22%,0.08)] focus-within:border-primary focus-within:shadow-[0_0_0_3px_hsla(248,98%,61%,0.12)] transition-all">
            <textarea
              ref={taRef}
              value={question}
              rows={1}
              onChange={(e) => {
                setQuestion(e.target.value);
                autoGrow(e.target);
              }}
              onKeyDown={onKeyDown}
              placeholder={listening ? "Listening…" : `Message ${BOT_NAME}…`}
              className="max-h-[180px] flex-1 resize-none bg-transparent py-2 text-sm text-ink placeholder:text-ink-mute focus:outline-none"
            />
            {/* Voice input — browser-native SpeechRecognition (Web Speech API),
                hidden entirely where it isn't supported (notably Firefox)
                rather than shown disabled. Mirrors Claude/Gemini's mic
                affordance: a plain mic glyph at rest, a small pulsing
                "equalizer" while actively listening. */}
            {speechSupported && (
              <button
                type="button"
                onClick={toggleListening}
                disabled={ask.isPending}
                aria-label={listening ? "Stop voice input" : "Start voice input"}
                title={listening ? "Stop voice input" : "Voice input"}
                className={cn(
                  "relative flex h-9 w-9 shrink-0 items-center justify-center rounded-full transition-colors disabled:opacity-40",
                  listening
                    ? "bg-rose-500/15 text-rose-600"
                    : "text-ink-mute hover:bg-secondary hover:text-ink",
                )}
              >
                {listening && (
                  <span className="absolute inset-0 rounded-full bg-rose-500/20 animate-ping" />
                )}
                {listening ? (
                  <span className="relative flex items-center gap-0.5">
                    {[0, 1, 2].map((i) => (
                      <span
                        key={i}
                        className="animate-voice-bar rounded-full bg-rose-600"
                        style={{ animationDelay: `${i * 0.15}s` }}
                      />
                    ))}
                  </span>
                ) : (
                  <Mic className="h-4 w-4" />
                )}
              </button>
            )}
            <button
              type="submit"
              disabled={ask.isPending || !question.trim()}
              aria-label="Send"
              className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary text-white transition-colors hover:bg-brand-deep disabled:opacity-40"
            >
              {ask.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <ArrowUp className="h-4 w-4" />
              )}
            </button>
          </div>
          <p
            className={cn(
              "mt-2 text-center text-[11px]",
              listening || speechError ? "text-rose-600" : "text-ink-mute",
            )}
          >
            {listening
              ? "Listening… tap the mic to stop."
              : speechError
                ? speechError
                : "Read-only · AI-generated answers — each question spends AI tokens (metered in Token Usage). Keep questions specific. Enter to send, Shift+Enter for a new line."}
          </p>
        </form>
      </div>
    </div>
  );
}
