import { useEffect, useMemo, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/context/AuthContext";
import {
  Sparkles,
  Users,
  CheckCircle2,
  XCircle,
  Loader2,
  Calendar,
  CalendarDays,
  Tag,
  ClipboardList,
  ArrowUp,
  ArrowDown,
  ArrowUpDown,
  ChevronDown,
  PauseCircle,
  ShieldAlert,
  ChevronLeft,
  ChevronRight,
  X,
  BarChart2,
  Search,
} from "lucide-react";
import { candidatesService } from "@/services/candidates";
import { settingsService } from "@/services/settings";
import { analyticsService, type AnalyticsCandidate } from "@/services/analytics";
import {
  ROUND_FILTER_BUCKETS,
  BUCKET_COLOR,
  bucketOf,
  agingDaysFor,
  roundLabel,
  type RoundBucket,
} from "@/lib/rounds";
import type { CandidateMaster } from "@/types/candidate";
import { parseCertificates } from "@/types/candidate";
import { cn, titleCase, initialsOf, formatExperience, formatScore } from "@/lib/utils";
import { hasAnalysisReport } from "@/components/candidate/AnalysisReport";
import ScoreBreakdown, {
  hasScoreBreakdown,
  NlrsBreakdown,
  hasNlrsBreakdown,
  ScorePopoverModal,
} from "@/components/candidate/ScoreBreakdown";
import AnalysisReportModal from "@/components/candidate/AnalysisReportModal";
import { useRecruiterApplyPermission } from "@/hooks/useCanApplyPredictedNba";
import ResumeViewerModal from "@/components/candidate/ResumeViewerModal";
import { nbaStatus, type NbaOverride } from "@/components/candidate/NextActionOverride";
import { EmailDraftReviewModal } from "@/components/candidate/EmailDraftReview";
import StatCard from "@/components/common/StatCard";
import PageHeader from "@/components/layout/PageHeader";
import PageContainer from "@/components/layout/PageContainer";
import FilterDropdown from "@/components/common/FilterDropdown";
import HelpRequestBadge from "@/components/candidate/HelpRequestBadge";
import NbaCommentDialog from "@/components/candidate/NbaCommentDialog";
import { NoteBadge, ReferralBadge } from "@/components/candidate/CandidateNote";
import InviteBlockBadge from "@/components/candidate/InviteBlockBadge";
import { ALL_YEARS, yearOf, pickerYears, useGlobalYear } from "@/lib/year";
import { ALL_SOURCES, sourceOf, useGlobalSource, useSampleDataFilter } from "@/lib/source";
import { ALL_MONTHS, MONTH_NAMES, monthOf, useGlobalMonth } from "@/lib/month";
import { useMediaQuery } from "@/hooks/useMediaQuery";

// Aging threshold (days) for the "Aging" tile + the Screening filter it opens.
const AGING_DAYS = 15;

// Rows per page in each of the three shortlist panels (New / Processing /
// Outcomes) — Prev/Next paged rather than an unbounded scroll of everything.
const PAGE_SIZE = 50;

// Prev/Next pager shown under a panel's table once it has more than one page.
function ListPagination({
  page,
  total,
  onPageChange,
}: {
  page: number;
  total: number;
  onPageChange: (page: number) => void;
}) {
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  if (totalPages <= 1) return null;
  // Clamp for display too — the underlying page state may momentarily exceed
  // totalPages right after the list shrinks (a candidate leaving between
  // refetches), before the next Prev/Next click settles it back down.
  const shown = Math.min(page, totalPages);
  const start = (shown - 1) * PAGE_SIZE + 1;
  const end = Math.min(shown * PAGE_SIZE, total);
  return (
    <div className="mt-2 flex shrink-0 items-center justify-between gap-2 border-t border-border/60 pt-2 text-[11px] text-muted-foreground">
      <span className="tabular-nums">
        {start}-{end} of {total}
      </span>
      <div className="flex items-center gap-1">
        <button
          type="button"
          onClick={() => onPageChange(shown - 1)}
          disabled={shown <= 1}
          title="Previous page"
          className="rounded-lg p-1 transition-colors hover:bg-secondary hover:text-ink disabled:opacity-30 disabled:hover:bg-transparent"
        >
          <ChevronLeft className="h-3.5 w-3.5" />
        </button>
        <span className="tabular-nums">
          Page {shown} of {totalPages}
        </span>
        <button
          type="button"
          onClick={() => onPageChange(shown + 1)}
          disabled={shown >= totalPages}
          title="Next page"
          className="rounded-lg p-1 transition-colors hover:bg-secondary hover:text-ink disabled:opacity-30 disabled:hover:bg-transparent"
        >
          <ChevronRight className="h-3.5 w-3.5" />
        </button>
      </div>
    </div>
  );
}

// Sort-direction glyph for a clickable column header. `dir` is null when the
// column isn't the active sort key (shows the neutral up/down chevrons).
type SortDir = "asc" | "desc";
function SortIcon({ dir }: { dir: SortDir | null }) {
  if (dir === "asc") return <ArrowUp className="h-3 w-3" />;
  if (dir === "desc") return <ArrowDown className="h-3 w-3" />;
  return <ArrowUpDown className="h-3 w-3 opacity-40" />;
}

// Scheduled-date format used in the "Action Date" column, e.g. "25 Jul 2026".
const fmtScheduled = (s: string) =>
  new Date(s).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });

// Oldest age (days) among candidates currently in one of `buckets` — null when
// none of them age (see bucketAges) or there's simply nobody in that set yet.
function oldestAgeIn(
  candidates: CandidateMaster[],
  buckets: RoundBucket[],
  agingByCandidate: Map<string, number>,
): number | null {
  let oldest: number | null = null;
  candidates.forEach((c) => {
    const b = bucketOf(c);
    if (!b || !buckets.includes(b)) return;
    const days = agingDaysFor(c, agingByCandidate);
    if (days != null && (oldest == null || days > oldest)) oldest = days;
  });
  return oldest;
}

// Small "Oldest Nd" chip appended to a stage pill — red once past AGING_DAYS,
// matching every other aging indicator in the app.
function OldestAgeBadge({ days }: { days: number | null }) {
  if (days == null) return null;
  return (
    <span
      className={cn(
        "whitespace-nowrap rounded-full px-1 py-0.5 text-[8px] font-bold tabular-nums sm:px-1.5 sm:text-[9px]",
        days > AGING_DAYS ? "bg-rose-500/15 text-rose-600" : "bg-secondary text-muted-foreground",
      )}
    >
      Oldest {days}d
    </span>
  );
}

// The buckets rolled into the "Candidates being Processed" tile.
const PROCESSING_BUCKETS: RoundBucket[] = ["Screening", "Round 1", "Round 2", "Final"];
// The buckets rolled into the "Hired / Rejected / Undecided" outcomes panel.
const OUTCOME_BUCKETS: RoundBucket[] = ["Hired", "Reject", "Undecided"];
// Display label for the "Candidates being Processed" panel's active sub-filter
// chip — keyed the same as the processingFilter state below. Rows follow the
// slot-invite lifecycle (slots shared → reminders → drafts awaiting review →
// booked/scheduled), plus the Final stage — matching how candidates actually
// move now (any round's invite is a slot-share; booking is what "Scheduled"
// means, regardless of which round it's for).
type ProcessingFilter =
  | "slots_shared"
  | "reminders"
  | "reminder_drafts"
  | "scheduled"
  | "final"
  // Exact-stage slices — reached via the Process Flow page's stage bubbles
  // (?bucket=...), not the rollup's own lifecycle rows.
  | "stage_screening"
  | "stage_round1"
  | "stage_round2";
const PROCESSING_FILTER_LABEL: Record<ProcessingFilter, string> = {
  slots_shared: roundLabel("Screening"), // "Interview slots shared"
  reminders: "Reminders Sent",
  reminder_drafts: "Reminder drafts to review",
  scheduled: "Interview Scheduled",
  final: "Final",
  stage_screening: "Screening",
  stage_round1: "Round 1",
  stage_round2: "Round 2 / 3",
};

// ── Candidate-shortlist split panels — collapse state ───────────────────────
// Three panels now (New / Candidates being Processed / Hired·Rejected·
// Undecided). Exactly ONE is ever expanded full-width — the other two are
// always collapsed to narrow icon strips. There's no "all three equal" state:
// New is expanded by default, and clicking a tile/strip switches which one is
// expanded (collapsing whichever was expanded before). Desktop/lg (and tall
// enough — see canRow) only: below that, all three always stack full-width
// regardless of this state, since collapsing sideways on a phone-width
// screen doesn't make sense.
type PanelFocus = "new" | "processing" | "outcomes";
const PANEL_COLLAPSE_KEY = "dashboard-panel-collapse";

function loadPanelFocus(): PanelFocus {
  try {
    const raw = localStorage.getItem(PANEL_COLLAPSE_KEY);
    if (raw === "new" || raw === "processing" || raw === "outcomes") return raw;
    // Migrate old values (before "New expanded by default, always exactly one
    // expanded" became the model): "none" (3-way split) and the old 2-panel
    // "left"/"right" all collapse down to the current default, New.
    if (raw === "left") return "processing"; // old: Processing expanded, New collapsed
  } catch {
    /* localStorage unavailable — fall through to default */
  }
  // Default: New Potential Candidates fully expanded, the other two collapsed.
  return "new";
}

// The narrow icon-strip a panel collapses to — expand chevron, the panel's
// own icon, and a live count so some info-scent survives even collapsed.
function CollapsedPanelStrip({
  icon: Icon,
  iconClassName,
  label,
  count,
  chevron: Chevron,
  onExpand,
}: {
  icon: React.ElementType;
  iconClassName: string;
  label: string;
  count: number;
  chevron: React.ElementType;
  onExpand: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onExpand}
      title={`Expand "${label}"`}
      className="flex h-full w-full flex-col items-center justify-center gap-3 rounded-xl text-ink-mute transition-colors hover:bg-secondary hover:text-ink"
    >
      <Chevron className="h-4 w-4 shrink-0" />
      <Icon className={cn("h-4 w-4 shrink-0", iconClassName)} />
      <span className="rounded-full bg-secondary px-1.5 py-0.5 text-[10px] font-bold tabular-nums text-foreground">
        {count}
      </span>
    </button>
  );
}

// ── Year filter ──────────────────────────────────────────────────────────────
// The dashboard is scoped to ONE intake year at a time (the year a resume's mail
// arrived — candidate.mail_send_date). The choice is GLOBAL (see @/lib/year): it
// persists across visits and applies to every candidate list in the app.



// The Report column's cell, shared verbatim by all three dashboard tables
// (ProcessingTable / OutcomesTable / CandidateTable) — they render an identical
// cell, so it lives here once rather than being kept in sync three times.
//
// Layout: the Report + Undecided buttons sit side by side, with the NBA status
// line (see nbaStatus: still-Predicted, Applied as-is, or manually Overridden)
// stacked underneath. That status line is opt-in — Settings → Legacy Features →
// "Predicted NBA status line", default OFF, since the prediction is already
// visible and appliable inside the Report popover.
//
// Undecided is the one NBA action promoted to the row itself: it's where most
// freshers/interns land, so parking a candidate is the highest-volume triage
// call and shouldn't cost a popover round-trip. It routes through the same
// confirm/comment dialog as every other override (reason → Action Log), so the
// action stays audit-logged.
function ReportCell({
  c,
  onReport,
  onUndecided,
}: {
  c: CandidateMaster;
  onReport: (c: CandidateMaster) => void;
  onUndecided: (c: CandidateMaster) => void;
}) {
  // Shared cache key with the Settings card + the ATS/NLRS column gating, so a
  // toggle saved there lands here without a refetch storm (one query, cached).
  const { data: legacy } = useQuery({
    queryKey: ["legacy-features-config"],
    queryFn: async () => (await settingsService.getLegacyFeatures()).data,
  });
  const status = nbaStatus(c);
  // Already parked → the button would be a no-op, so it's not offered.
  const alreadyUndecided = c.next_action_override?.key === "undecided";

  return (
    <div className="flex flex-col items-start gap-1">
      <div className="flex items-center gap-1">
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onReport(c);
          }}
          title="Analysis Report"
          className={cn(
            "inline-flex items-center gap-1 rounded-lg border px-2 py-1 text-[10px] font-semibold transition-colors",
            hasAnalysisReport(c)
              ? "border-primary/30 bg-primary/5 text-primary hover:bg-primary/10"
              : "border-border bg-card text-muted-foreground hover:border-primary/40 hover:text-foreground",
          )}
        >
          <ClipboardList className="h-3 w-3" />
          Report
        </button>
        {!alreadyUndecided && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onUndecided(c);
            }}
            title="Park as Undecided for now — sends the ack-email and moves the candidate to the Undecided bucket"
            className="inline-flex items-center gap-1 rounded-lg border border-border bg-card px-2 py-1 text-[10px] font-semibold text-muted-foreground transition-colors hover:border-amber-500/40 hover:text-amber-600"
          >
            <PauseCircle className="h-3 w-3" />
            Undecided
          </button>
        )}
      </div>
      {legacy?.predicted_nba_status && status && (
        <span
          className={cn(
            "whitespace-nowrap text-[10px] font-medium",
            status.tag === "Applied"
              ? "text-emerald-600"
              : status.tag === "Overridden"
                ? "text-amber-600"
                : "text-muted-foreground",
          )}
        >
          {status.tag}: {status.label}
        </span>
      )}
    </div>
  );
}

// "Being processed" table (right panel). Same column set + sort/Report
// features as "New Potential Candidates Added" (CandidateTable below), plus
// this list's own extras: Stream, Stage, and Action Date (the current round's
// scheduled date) — those don't apply to CandidateTable's still-"New" rows.
// Rows deep-link to the profile; the Report button opens the popover in place.
type ProcessingSortKey = "received" | "experience" | "aging" | "action" | "ats" | "nlrs";

function ProcessingTable({
  rows,
  onRowClick,
  onReport,
  onUndecided,
  onAtsBreakdown,
  onNlrsBreakdown,
  agingByCandidate,
  scheduledByCandidate,
}: {
  rows: CandidateMaster[];
  onRowClick: (id: string) => void;
  onReport: (c: CandidateMaster) => void;
  onUndecided: (c: CandidateMaster) => void;
  onAtsBreakdown: (c: CandidateMaster) => void;
  onNlrsBreakdown: (c: CandidateMaster) => void;
  // candidate_id → whole days in the current state.
  agingByCandidate: Map<string, number>;
  // candidate_id → current round's scheduled date (ISO), or null/absent.
  scheduledByCandidate: Record<string, string | null>;
}) {
  // Click-to-sort on any column below. null = keep the incoming (default,
  // Aging-desc) order from the parent's useMemo. Clicking toggles desc → asc → desc.
  const [sort, setSort] = useState<{ key: ProcessingSortKey; dir: SortDir } | null>(null);
  const toggle = (key: ProcessingSortKey) =>
    setSort((s) => (s?.key === key ? { key, dir: s.dir === "desc" ? "asc" : "desc" } : { key, dir: "desc" }));

  const displayRows = useMemo(() => {
    if (!sort) return rows;
    const arr = [...rows];
    arr.sort((a, b) => {
      if (sort.key === "action") {
        // Action Date — unscheduled rows always sink to the bottom.
        const ad = scheduledByCandidate[a.candidate_id];
        const bd = scheduledByCandidate[b.candidate_id];
        if (!ad && !bd) return 0;
        if (!ad) return 1;
        if (!bd) return -1;
        const av = new Date(ad).getTime();
        const bv = new Date(bd).getTime();
        return sort.dir === "asc" ? av - bv : bv - av;
      }
      let av: number;
      let bv: number;
      switch (sort.key) {
        case "aging":
          av = agingDaysFor(a, agingByCandidate) ?? -Infinity;
          bv = agingDaysFor(b, agingByCandidate) ?? -Infinity;
          break;
        case "received":
          av = new Date(a.mail_send_date).getTime();
          bv = new Date(b.mail_send_date).getTime();
          break;
        case "experience":
          av = a.yearofexp ?? -Infinity;
          bv = b.yearofexp ?? -Infinity;
          break;
        case "ats":
          av = a.atsscore ?? -Infinity;
          bv = b.atsscore ?? -Infinity;
          break;
        case "nlrs":
        default:
          av = a.nlrs?.score ?? -Infinity;
          bv = b.nlrs?.score ?? -Infinity;
          break;
      }
      return sort.dir === "asc" ? av - bv : bv - av;
    });
    return arr;
  }, [rows, sort, agingByCandidate, scheduledByCandidate]);

  // Reusable sortable column header (same pattern as CandidateTable's).
  const SortableTh = ({ label, sortKey }: { label: string; sortKey: ProcessingSortKey }) => (
    <th className="whitespace-nowrap px-2 py-1.5 text-right">
      <button
        type="button"
        onClick={() => toggle(sortKey)}
        className="ml-auto inline-flex items-center gap-1 uppercase tracking-wide transition-colors hover:text-foreground"
      >
        {label}
        <SortIcon dir={sort?.key === sortKey ? sort.dir : null} />
      </button>
    </th>
  );

  return (
    // Natural (non-fixed) column widths + nowrap cells so no title or value ever
    // clips — the table grows past the card's width and this scrolls horizontally
    // instead of truncating (same treatment as the CandidateTable above).
    // h-full so a short row count still stretches this wrapper to the card's
    // full height — pins the horizontal scrollbar to the card's bottom edge
    // instead of bunching it right under the last row.
    <div className="h-full overflow-x-auto">
      <table className="w-full min-w-max border-collapse text-left">
        <thead>
          <tr className="sticky top-0 z-10 border-b border-border bg-card text-[9px] font-semibold uppercase tracking-wide text-muted-foreground">
            <th className="whitespace-nowrap py-1.5 pr-2">Name</th>
            <th className="whitespace-nowrap px-2 py-1.5" title="Analysis Report + Predicted NBA / Applied / Overridden status">
              Report
            </th>
            <th className="whitespace-nowrap px-2 py-1.5">Stream</th>
            <th className="whitespace-nowrap px-2 py-1.5">Stage</th>
            <SortableTh label="Received" sortKey="received" />
            <SortableTh label="Experience" sortKey="experience" />
            <SortableTh label="Aging" sortKey="aging" />
            <th className="whitespace-nowrap px-2 py-1.5">
              <button
                type="button"
                onClick={() => toggle("action")}
                className="inline-flex items-center gap-1 uppercase tracking-wide transition-colors hover:text-foreground"
              >
                Action Date
                <SortIcon dir={sort?.key === "action" ? sort.dir : null} />
              </button>
            </th>
            <SortableTh label="ATS" sortKey="ats" />
            <SortableTh label="NLRS" sortKey="nlrs" />
          </tr>
        </thead>
        <tbody>
          {displayRows.map((c) => {
            const b = bucketOf(c);
            const agingDays = agingDaysFor(c, agingByCandidate);
            const scheduledOn = scheduledByCandidate[c.candidate_id] ?? null;
            return (
              <tr
                key={c.candidate_id}
                onClick={() => onRowClick(c.candidate_id)}
                className="cursor-pointer border-b border-border/50 transition-colors last:border-b-0 hover:bg-secondary/60"
              >
                <td className="py-1.5 pr-2">
                  <div className="flex items-center gap-2">
                    <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg gradient-brand text-[9px] font-bold text-white">
                      {c.name ? initialsOf(c.name) : "?"}
                    </div>
                    <span className="whitespace-nowrap text-xs font-semibold text-foreground">
                      {c.name ? titleCase(c.name) : c.candidate_id}
                    </span>
                    <ReferralBadge referral={c.referral} />
                    <InviteBlockBadge reason={c.invite_block_reason} />
                    <NoteBadge note={c.latest_note} />
                  </div>
                </td>
                <td className="px-2 py-1.5">
                  <ReportCell c={c} onReport={onReport} onUndecided={onUndecided} />
                </td>
                <td className="whitespace-nowrap px-2 py-1.5 text-[11px] text-muted-foreground">
                  {c.stream ?? "—"}
                </td>
                <td className="whitespace-nowrap px-2 py-1.5">
                  {b ? (
                    <span className="inline-flex items-center gap-1 whitespace-nowrap text-[11px] font-medium text-foreground">
                      <span
                        className="h-1.5 w-1.5 rounded-full"
                        style={{ backgroundColor: BUCKET_COLOR[b] }}
                      />
                      {roundLabel(b)}
                      <HelpRequestBadge candidate={c} />
                    </span>
                  ) : (
                    "—"
                  )}
                </td>
                <td className="whitespace-nowrap px-2 py-1.5 text-right text-[11px] text-muted-foreground">
                  {fmtScheduled(c.mail_send_date)}
                </td>
                <td className="whitespace-nowrap px-2 py-1.5 text-right text-[11px] text-muted-foreground">
                  {c.fresher_or_lateral === "Fresher"
                    ? "Fresher"
                    : formatExperience(c.yearofexp)}
                </td>
                <td className="whitespace-nowrap px-2 py-1.5 text-right text-[11px] tabular-nums">
                  {agingDays == null ? (
                    <span className="text-muted-foreground">—</span>
                  ) : (
                    <span
                      title={`${agingDays}d in ${b ? roundLabel(b) : "current stage"} · received ${fmtScheduled(c.mail_send_date)}`}
                      className={
                        agingDays > AGING_DAYS
                          ? "font-semibold text-rose-500"
                          : "text-muted-foreground"
                      }
                    >
                      {agingDays}d
                    </span>
                  )}
                </td>
                <td className="whitespace-nowrap px-2 py-1.5 text-[11px] text-muted-foreground">
                  {scheduledOn ? fmtScheduled(scheduledOn) : "Not scheduled"}
                </td>
                <td className="px-2 py-1.5 text-right text-xs font-bold">
                  {c.atsscore == null ? (
                    <span className="text-muted-foreground">—</span>
                  ) : hasScoreBreakdown(c) ? (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onAtsBreakdown(c);
                      }}
                      title="Show ATS score breakdown"
                      className="inline-flex items-center gap-1 text-foreground underline decoration-dotted underline-offset-2 transition-colors hover:text-primary"
                    >
                      {formatScore(c.atsscore)}
                      <BarChart2 className="h-3 w-3 opacity-60" />
                    </button>
                  ) : (
                    <span className="text-foreground">{formatScore(c.atsscore)}</span>
                  )}
                </td>
                <td className="px-2 py-1.5 text-right text-xs font-bold">
                  {c.nlrs == null ? (
                    <span className="text-muted-foreground">—</span>
                  ) : hasNlrsBreakdown(c) ? (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onNlrsBreakdown(c);
                      }}
                      title="Show NLRS score breakdown"
                      className="inline-flex items-center gap-1 text-foreground underline decoration-dotted underline-offset-2 transition-colors hover:text-primary"
                    >
                      {formatScore(c.nlrs.score)}
                      <BarChart2 className="h-3 w-3 opacity-60" />
                    </button>
                  ) : (
                    <span className="text-foreground">{formatScore(c.nlrs.score)}</span>
                  )}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

// "Hired / Rejected / Undecided" table (3rd panel). Same column set as the
// other two lists (Report/Received/Experience/Aging/ATS/NLRS), plus a Stage
// badge since this list mixes three different outcomes in one place. Aging
// here isn't a "stalled in the pipeline" signal (these are terminal/parked,
// not actively progressing) — it just reads as "days since the decision" /
// "days parked as Undecided", same underlying agingDaysFor fallback as
// everywhere else.
type OutcomeSortKey = "received" | "experience" | "aging" | "ats" | "nlrs";

function OutcomesTable({
  rows,
  onRowClick,
  onReport,
  onUndecided,
  onAtsBreakdown,
  onNlrsBreakdown,
  agingByCandidate,
}: {
  rows: CandidateMaster[];
  onRowClick: (id: string) => void;
  onReport: (c: CandidateMaster) => void;
  onUndecided: (c: CandidateMaster) => void;
  onAtsBreakdown: (c: CandidateMaster) => void;
  onNlrsBreakdown: (c: CandidateMaster) => void;
  agingByCandidate: Map<string, number>;
}) {
  const [sort, setSort] = useState<{ key: OutcomeSortKey; dir: SortDir } | null>(null);
  const toggle = (key: OutcomeSortKey) =>
    setSort((s) => (s?.key === key ? { key, dir: s.dir === "desc" ? "asc" : "desc" } : { key, dir: "desc" }));

  const displayRows = useMemo(() => {
    if (!sort) return rows;
    const arr = [...rows];
    arr.sort((a, b) => {
      let av: number;
      let bv: number;
      switch (sort.key) {
        case "aging":
          av = agingDaysFor(a, agingByCandidate) ?? -Infinity;
          bv = agingDaysFor(b, agingByCandidate) ?? -Infinity;
          break;
        case "received":
          av = new Date(a.mail_send_date).getTime();
          bv = new Date(b.mail_send_date).getTime();
          break;
        case "experience":
          av = a.yearofexp ?? -Infinity;
          bv = b.yearofexp ?? -Infinity;
          break;
        case "ats":
          av = a.atsscore ?? -Infinity;
          bv = b.atsscore ?? -Infinity;
          break;
        case "nlrs":
        default:
          av = a.nlrs?.score ?? -Infinity;
          bv = b.nlrs?.score ?? -Infinity;
          break;
      }
      return sort.dir === "asc" ? av - bv : bv - av;
    });
    return arr;
  }, [rows, sort, agingByCandidate]);

  const SortableTh = ({ label, sortKey }: { label: string; sortKey: OutcomeSortKey }) => (
    <th className="whitespace-nowrap px-2 py-1.5 text-right">
      <button
        type="button"
        onClick={() => toggle(sortKey)}
        className="ml-auto inline-flex items-center gap-1 uppercase tracking-wide transition-colors hover:text-foreground"
      >
        {label}
        <SortIcon dir={sort?.key === sortKey ? sort.dir : null} />
      </button>
    </th>
  );

  return (
    <div className="h-full overflow-x-auto">
      <table className="w-full min-w-max border-collapse text-left">
        <thead>
          <tr className="sticky top-0 z-10 border-b border-border bg-card text-[9px] font-semibold uppercase tracking-wide text-muted-foreground">
            <th className="whitespace-nowrap py-1.5 pr-2">Name</th>
            <th className="whitespace-nowrap px-2 py-1.5" title="Analysis Report + Predicted NBA / Applied / Overridden status">
              Report
            </th>
            <th className="whitespace-nowrap px-2 py-1.5">Stage</th>
            <SortableTh label="Received" sortKey="received" />
            <SortableTh label="Experience" sortKey="experience" />
            <SortableTh label="Aging" sortKey="aging" />
            <SortableTh label="ATS" sortKey="ats" />
            <SortableTh label="NLRS" sortKey="nlrs" />
          </tr>
        </thead>
        <tbody>
          {displayRows.map((c) => {
            const b = bucketOf(c);
            const agingDays = agingDaysFor(c, agingByCandidate);
            return (
              <tr
                key={c.candidate_id}
                onClick={() => onRowClick(c.candidate_id)}
                className="cursor-pointer border-b border-border/50 transition-colors last:border-b-0 hover:bg-secondary/60"
              >
                <td className="py-1.5 pr-2">
                  <div className="flex items-center gap-2">
                    <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg gradient-brand text-[9px] font-bold text-white">
                      {c.name ? initialsOf(c.name) : "?"}
                    </div>
                    <span className="whitespace-nowrap text-xs font-semibold text-foreground">
                      {c.name ? titleCase(c.name) : c.candidate_id}
                    </span>
                    <ReferralBadge referral={c.referral} />
                    <InviteBlockBadge reason={c.invite_block_reason} />
                    <NoteBadge note={c.latest_note} />
                  </div>
                </td>
                <td className="px-2 py-1.5">
                  <ReportCell c={c} onReport={onReport} onUndecided={onUndecided} />
                </td>
                <td className="whitespace-nowrap px-2 py-1.5">
                  {b ? (
                    <span className="inline-flex items-center gap-1 whitespace-nowrap text-[11px] font-medium text-foreground">
                      <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: BUCKET_COLOR[b] }} />
                      {roundLabel(b)}
                      <HelpRequestBadge candidate={c} />
                    </span>
                  ) : (
                    "—"
                  )}
                </td>
                <td className="whitespace-nowrap px-2 py-1.5 text-right text-[11px] text-muted-foreground">
                  {fmtScheduled(c.mail_send_date)}
                </td>
                <td className="whitespace-nowrap px-2 py-1.5 text-right text-[11px] text-muted-foreground">
                  {c.fresher_or_lateral === "Fresher" ? "Fresher" : formatExperience(c.yearofexp)}
                </td>
                <td className="whitespace-nowrap px-2 py-1.5 text-right text-[11px] tabular-nums">
                  {agingDays == null ? (
                    <span className="text-muted-foreground">—</span>
                  ) : (
                    <span
                      title={`${agingDays}d since ${b ? roundLabel(b) : "last update"}`}
                      className={agingDays > AGING_DAYS ? "font-semibold text-rose-500" : "text-muted-foreground"}
                    >
                      {agingDays}d
                    </span>
                  )}
                </td>
                <td className="px-2 py-1.5 text-right text-xs font-bold">
                  {c.atsscore == null ? (
                    <span className="text-muted-foreground">—</span>
                  ) : hasScoreBreakdown(c) ? (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onAtsBreakdown(c);
                      }}
                      title="Show ATS score breakdown"
                      className="inline-flex items-center gap-1 text-foreground underline decoration-dotted underline-offset-2 transition-colors hover:text-primary"
                    >
                      {formatScore(c.atsscore)}
                      <BarChart2 className="h-3 w-3 opacity-60" />
                    </button>
                  ) : (
                    <span className="text-foreground">{formatScore(c.atsscore)}</span>
                  )}
                </td>
                <td className="px-2 py-1.5 text-right text-xs font-bold">
                  {c.nlrs == null ? (
                    <span className="text-muted-foreground">—</span>
                  ) : hasNlrsBreakdown(c) ? (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onNlrsBreakdown(c);
                      }}
                      title="Show NLRS score breakdown"
                      className="inline-flex items-center gap-1 text-foreground underline decoration-dotted underline-offset-2 transition-colors hover:text-primary"
                    >
                      {formatScore(c.nlrs.score)}
                      <BarChart2 className="h-3 w-3 opacity-60" />
                    </button>
                  ) : (
                    <span className="text-foreground">{formatScore(c.nlrs.score)}</span>
                  )}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

// "New Potential Candidates Added" table — Name, Report, Aging, Received,
// Experience, ATS, NLRS. Everything else (CGPA/College/Certificates/manual
// override) lives in the Report popover instead. Rows deep-link to the
// profile; the Report button opens the popover in place.
type CandidateSortKey =
  | "aging"
  | "received"
  | "experience"
  | "passout"
  | "cgpa"
  | "certs"
  | "ats"
  | "nlrs"
  | "college";

function CandidateTable({
  rows,
  onRowClick,
  onReport,
  onUndecided,
  onAtsBreakdown,
  onNlrsBreakdown,
  agingByCandidate,
}: {
  rows: CandidateMaster[];
  onRowClick: (id: string) => void;
  onReport: (c: CandidateMaster) => void;
  onUndecided: (c: CandidateMaster) => void;
  onAtsBreakdown: (c: CandidateMaster) => void;
  onNlrsBreakdown: (c: CandidateMaster) => void;
  // candidate_id → whole days in the current state (same map ProcessingTable uses).
  agingByCandidate: Map<string, number>;
}) {
  // Click-to-sort on any column below. Defaults to NLRS desc on every mount
  // (i.e. every page load/navigation) — clicking another column overrides it
  // for the rest of this visit, same toggle desc → asc → desc as elsewhere.
  const [sort, setSort] = useState<{ key: CandidateSortKey; dir: SortDir }>({
    key: "nlrs",
    dir: "desc",
  });
  // First click on a numeric column opens at desc (highest first — the useful
  // end of a score/count), but a text column opens at asc, since A→Z is what
  // "sort by college" is expected to mean. Toggling from there is unchanged.
  const firstDirFor = (key: CandidateSortKey): SortDir => (key === "college" ? "asc" : "desc");
  const toggle = (key: CandidateSortKey) =>
    setSort((s) =>
      s.key === key
        ? { key, dir: s.dir === "desc" ? "asc" : "desc" }
        : { key, dir: firstDirFor(key) },
    );

  // ATS / NLRS score columns are opt-in (Settings → Legacy Features, default
  // off). Hiding them does NOT change the ranking — rows still sort highest-
  // NLRS-first (the default sort key), the score columns just aren't shown.
  const { data: legacy } = useQuery({
    queryKey: ["legacy-features-config"],
    queryFn: async () => (await settingsService.getLegacyFeatures()).data,
  });
  const showAts = !!legacy?.ats_column;
  const showNlrs = !!legacy?.nlrs_column;

  const displayRows = useMemo(() => {
    const arr = [...rows];
    arr.sort((a, b) => {
      // College is the one non-numeric sort, so it returns early rather than
      // going through the numeric av/bv path below. Blank colleges always sink
      // to the bottom (same treatment as unscheduled rows in ProcessingTable) —
      // flipping the direction reorders the named ones without floating a block
      // of "—" to the top. localeCompare keeps accented names in sensible order.
      if (sort.key === "college") {
        const as = a.clg?.trim() ?? "";
        const bs = b.clg?.trim() ?? "";
        if (!as && !bs) return 0;
        if (!as) return 1;
        if (!bs) return -1;
        const cmp = as.localeCompare(bs, undefined, { sensitivity: "base" });
        return sort.dir === "asc" ? cmp : -cmp;
      }
      let av: number;
      let bv: number;
      switch (sort.key) {
        case "aging":
          av = agingDaysFor(a, agingByCandidate) ?? -Infinity;
          bv = agingDaysFor(b, agingByCandidate) ?? -Infinity;
          break;
        case "received":
          av = new Date(a.mail_send_date).getTime();
          bv = new Date(b.mail_send_date).getTime();
          break;
        case "experience":
          av = a.yearofexp ?? -Infinity;
          bv = b.yearofexp ?? -Infinity;
          break;
        case "passout":
          av = a.passoutyr ?? -Infinity;
          bv = b.passoutyr ?? -Infinity;
          break;
        case "cgpa":
          av = a.cgpa ?? -Infinity;
          bv = b.cgpa ?? -Infinity;
          break;
        case "certs":
          av = parseCertificates(a.certificates).length;
          bv = parseCertificates(b.certificates).length;
          break;
        case "ats":
          av = a.atsscore ?? -Infinity;
          bv = b.atsscore ?? -Infinity;
          break;
        case "nlrs":
        default:
          av = a.nlrs?.score ?? -Infinity;
          bv = b.nlrs?.score ?? -Infinity;
          break;
      }
      return sort.dir === "asc" ? av - bv : bv - av;
    });
    return arr;
  }, [rows, sort, agingByCandidate]);

  // Reusable sortable column header. Right-aligned by default (every numeric
  // column); `align="left"` for the text columns, so the header sits over the
  // start of the value rather than trailing off away from it.
  const SortableTh = ({
    label,
    sortKey,
    align = "right",
  }: {
    label: string;
    sortKey: CandidateSortKey;
    align?: "left" | "right";
  }) => (
    <th className={cn("whitespace-nowrap px-2 py-1.5", align === "right" ? "text-right" : "text-left")}>
      <button
        type="button"
        onClick={() => toggle(sortKey)}
        className={cn(
          "inline-flex items-center gap-1 uppercase tracking-wide transition-colors hover:text-foreground",
          align === "right" && "ml-auto",
        )}
      >
        {label}
        <SortIcon dir={sort.key === sortKey ? sort.dir : null} />
      </button>
    </th>
  );

  return (
    // Natural (non-fixed) column widths + nowrap cells so no title or value ever
    // clips — the table grows past the card's width and this scrolls horizontally
    // instead of truncating.
    // h-full so a short row count still stretches this wrapper to the card's
    // full height — pins the horizontal scrollbar to the card's bottom edge
    // instead of bunching it right under the last row.
    <div className="h-full overflow-x-auto">
      <table className="w-full min-w-max border-collapse text-left">
        <thead>
          <tr className="sticky top-0 z-10 border-b border-border bg-card text-[9px] font-semibold uppercase tracking-wide text-muted-foreground">
            <th className="whitespace-nowrap py-1.5 pr-2">Name</th>
            <th className="whitespace-nowrap px-2 py-1.5" title="Analysis Report + Predicted NBA / Applied / Overridden status">
              Report
            </th>
            <SortableTh label="Aging" sortKey="aging" />
            <SortableTh label="Received" sortKey="received" />
            <SortableTh label="Experience" sortKey="experience" />
            {/* Leads the education block (College · Certificates · CGPA · Passout).
                Sorts alphabetically — see the early-return branch in displayRows. */}
            <SortableTh label="College" sortKey="college" align="left" />
            <SortableTh label="Certificates" sortKey="certs" />
            <SortableTh label="CGPA" sortKey="cgpa" />
            <SortableTh label="Passout Year" sortKey="passout" />
            {showAts && <SortableTh label="ATS" sortKey="ats" />}
            {showNlrs && <SortableTh label="NLRS" sortKey="nlrs" />}
          </tr>
        </thead>
        <tbody>
          {displayRows.map((c) => (
            <tr
              key={c.candidate_id}
              onClick={() => onRowClick(c.candidate_id)}
              className="cursor-pointer border-b border-border/50 transition-colors last:border-b-0 hover:bg-secondary/60"
            >
              <td className="py-1.5 pr-2">
                <div className="flex items-center gap-2">
                  <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg gradient-brand text-[9px] font-bold text-white">
                    {c.name ? initialsOf(c.name) : "?"}
                  </div>
                  <span className="whitespace-nowrap text-xs font-semibold text-foreground">
                    {c.name ? titleCase(c.name) : c.candidate_id}
                  </span>
                  <ReferralBadge referral={c.referral} />
                  <InviteBlockBadge reason={c.invite_block_reason} />
                  <NoteBadge note={c.latest_note} />
                </div>
              </td>
              <td className="px-2 py-1.5">
                <ReportCell c={c} onReport={onReport} onUndecided={onUndecided} />
              </td>
              {(() => {
                const agingDays = agingDaysFor(c, agingByCandidate);
                return (
                  <td className="whitespace-nowrap px-2 py-1.5 text-right text-[11px] tabular-nums">
                    {agingDays == null ? (
                      <span className="text-muted-foreground">—</span>
                    ) : (
                      <span
                        className={
                          agingDays > AGING_DAYS
                            ? "font-semibold text-rose-500"
                            : "text-muted-foreground"
                        }
                      >
                        {agingDays}d
                      </span>
                    )}
                  </td>
                );
              })()}
              <td className="whitespace-nowrap px-2 py-1.5 text-right text-[11px] text-muted-foreground">
                {fmtScheduled(c.mail_send_date)}
              </td>
              <td className="whitespace-nowrap px-2 py-1.5 text-right text-[11px] text-muted-foreground">
                {c.fresher_or_lateral === "Fresher" ? "Fresher" : formatExperience(c.yearofexp)}
              </td>
              {/* Capped + truncated rather than nowrap-grown: college names run
                  long enough to push the score columns off-screen otherwise. The
                  full value stays available on hover. */}
              <td className="px-2 py-1.5 text-[11px] text-muted-foreground">
                {c.clg ? (
                  <span className="block max-w-[14rem] truncate" title={c.clg}>
                    {titleCase(c.clg)}
                  </span>
                ) : (
                  "—"
                )}
              </td>
              {(() => {
                const certCount = parseCertificates(c.certificates).length;
                return (
                  <td className="whitespace-nowrap px-2 py-1.5 text-right text-[11px] text-muted-foreground">
                    {certCount > 0 ? certCount : "—"}
                  </td>
                );
              })()}
              <td className="whitespace-nowrap px-2 py-1.5 text-right text-[11px] text-muted-foreground">
                {c.cgpa != null ? c.cgpa.toFixed(1) : "—"}
              </td>
              <td className="whitespace-nowrap px-2 py-1.5 text-right text-[11px] text-muted-foreground">
                {c.passoutyr ?? "—"}
              </td>
              {showAts && (
              <td className="px-2 py-1.5 text-right text-xs font-bold">
                {c.atsscore == null ? (
                  <span className="text-muted-foreground">—</span>
                ) : hasScoreBreakdown(c) ? (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onAtsBreakdown(c);
                    }}
                    title="Show ATS score breakdown"
                    className="inline-flex items-center gap-1 text-foreground underline decoration-dotted underline-offset-2 transition-colors hover:text-primary"
                  >
                    {formatScore(c.atsscore)}
                    <BarChart2 className="h-3 w-3 opacity-60" />
                  </button>
                ) : (
                  <span className="text-foreground">{formatScore(c.atsscore)}</span>
                )}
              </td>
              )}
              {showNlrs && (
              <td className="px-2 py-1.5 text-right text-xs font-bold">
                {c.nlrs == null ? (
                  <span className="text-muted-foreground">—</span>
                ) : hasNlrsBreakdown(c) ? (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onNlrsBreakdown(c);
                    }}
                    title="Show NLRS score breakdown"
                    className="inline-flex items-center gap-1 text-foreground underline decoration-dotted underline-offset-2 transition-colors hover:text-primary"
                  >
                    {formatScore(c.nlrs.score)}
                    <BarChart2 className="h-3 w-3 opacity-60" />
                  </button>
                ) : (
                  <span className="text-foreground">{formatScore(c.nlrs.score)}</span>
                )}
              </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function Dashboard() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  // Manual NBA override ("change NBA") is Admin-only — the backend 403s a
  // Recruiter's attempt too, this just keeps the control from appearing.
  const { isAdmin, canAccessRecruiting } = useAuth();
  const { canApplyFor } = useRecruiterApplyPermission();

  // Candidate whose Analysis Report popover is open (null = closed).
  const [analysisFor, setAnalysisFor] = useState<CandidateMaster | null>(null);
  // Candidate whose ATS/NLRS score-breakdown popover is open — same click-to-
  // explain pattern as the Screening table's ATS/NLRS columns.
  const [atsBreakdownFor, setAtsBreakdownFor] = useState<CandidateMaster | null>(null);
  const [nlrsBreakdownFor, setNlrsBreakdownFor] = useState<CandidateMaster | null>(null);
  // Email-draft "ready for review" badge next to Predicted NBA opens this.
  const [draftReviewFor, setDraftReviewFor] = useState<CandidateMaster | null>(null);
  // "View Resume" inside the Analysis Report popover opens this on top of it.
  const [resumeFor, setResumeFor] = useState<CandidateMaster | null>(null);

  // Split-panel focus — see PanelFocus above. Persisted so a recruiter's
  // chosen layout survives reloads/revisits, same pattern as the sidebar's
  // own collapsed state (AppLayout's "sidebar-collapsed" key).
  const [panelFocus, setPanelFocusState] = useState<PanelFocus>(loadPanelFocus);
  const setPanelFocus = (next: PanelFocus) => {
    setPanelFocusState(next);
    try {
      localStorage.setItem(PANEL_COLLAPSE_KEY, next);
    } catch {
      /* non-fatal */
    }
  };

  // Which slice of the "Candidates being Processed" rollup is showing in that
  // panel — set by clicking one of the rollup's breakdown rows. null = every
  // Screening/Round 1/Round 2/Final candidate (the rollup's full total).
  const [processingFilter, setProcessingFilter] = useState<ProcessingFilter | null>(null);
  // Same idea for the Hired/Rejected/Undecided panel — set by clicking Hired,
  // the Rejected dropdown row, or Undecided. null = all three outcomes.
  const [outcomesFilter, setOutcomesFilter] = useState<"Hired" | "Reject" | "Undecided" | null>(null);

  // Deep link from the Process Flow page (?bucket=<stage>): open the panel
  // that actually holds that stage's candidates and pre-filter it to exactly
  // them. Applied once on arrival, then stripped from the URL so refreshes /
  // later panel clicks aren't re-forced back to the linked stage.
  const [searchParams, setSearchParams] = useSearchParams();
  useEffect(() => {
    const bucket = searchParams.get("bucket");
    if (!bucket) return;
    if (bucket === "New") {
      setPanelFocus("new");
    } else if (["Screening", "Round 1", "Round 2", "Final"].includes(bucket)) {
      setProcessingFilter(
        bucket === "Final"
          ? "final"
          : bucket === "Screening"
            ? "stage_screening"
            : bucket === "Round 1"
              ? "stage_round1"
              : "stage_round2"
      );
      setPanelFocus("processing");
    } else if (["Hired", "Reject", "Undecided"].includes(bucket)) {
      setOutcomesFilter(bucket as "Hired" | "Reject" | "Undecided");
      setPanelFocus("outcomes");
    }
    searchParams.delete("bucket");
    setSearchParams(searchParams, { replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Whether there's room for the 3 shortlist panels side-by-side. Plain width
  // (Tailwind's lg:) isn't enough on its own — a tablet rotated to landscape
  // can cross 1024px wide too, and 3 panels crammed into a touch-sized screen
  // is worse than stacking. A min-height cutoff was tried here first, but it
  // backfired: plenty of ordinary laptop screens (e.g. 1366x768) are shorter
  // than any reasonable cutoff, so they got excluded too and the whole
  // single-focus collapse feature silently never activated for them. What
  // actually distinguishes "landscape tablet" from "real laptop/desktop" is
  // the input method, not the viewport's height — hover:hover + pointer:fine
  // is mouse/trackpad hardware (laptops, desktops), while touch-only tablets
  // report hover:none/pointer:coarse even at a wide landscape viewport.
  const canRow = useMediaQuery("(min-width: 1024px) and (hover: hover) and (pointer: fine)");

  // Manual NBA override — persists on candidate_master (PATCH /next-action), read
  // straight off each candidate row (c.next_action_override). Admin-only (see the
  // "Options to Override NBA" section of the popover below).
  const updateNba = useMutation({
    mutationFn: ({ candidateId, ov, comment }: { candidateId: string; ov: NbaOverride; comment?: string }) =>
      candidatesService.updateNextAction(candidateId, { key: ov.key, text: ov.text, comment }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["candidates"] });
    },
  });

  // Predicted (NLRS-based) NBA — the key is always computed server-side, this just
  // accepts it. Available to every role. Only valid while the candidate is still
  // in the New stage — nothing about the candidate moves forward until Apply is clicked.
  const applyPredicted = useMutation({
    mutationFn: ({ candidateId, comment }: { candidateId: string; comment?: string }) =>
      candidatesService.applyPredictedNba(candidateId, comment),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["candidates"] }),
  });
  // Reminder cadence (max reminders + auto-reject window) — drives the
  // per-reminder rollup rows; harmless fallback (2 reminders) until loaded.
  const { data: cadence } = useQuery({
    queryKey: ["scheduling-cadence"],
    queryFn: async () => (await settingsService.getSchedulingCadence()).data,
    staleTime: 60_000,
  });
  // NBA apply/change routed through the comment popup (reason -> Action Log).
  const [pendingNba, setPendingNba] = useState<
    | { kind: "apply"; candidateId: string; name: string }
    | { kind: "override"; candidateId: string; name: string; ov: NbaOverride }
    | null
  >(null);

  // The per-row "Undecided" button (see ReportCell). Deliberately an "override"
  // — not "apply" — because it parks the candidate on the recruiter's call
  // regardless of what the system predicted, and so it lands in the same
  // confirm/comment dialog every other manual NBA change goes through.
  const askUndecided = (c: CandidateMaster) =>
    setPendingNba({
      kind: "override",
      candidateId: c.candidate_id,
      name: c.name ?? c.candidate_id,
      ov: { key: "undecided" },
    });

  const { data: allCandidates = [], isLoading } = useQuery({
    queryKey: ["candidates"],
    queryFn: async () => (await candidatesService.list()).data,
  });

  // Selected intake year — GLOBAL (shared with every candidate list, sticky across
  // visits; defaults to the current year).
  const [year, setYear] = useGlobalYear();

  // Dropdown options: the current year and the one before it only — never future
  // years (see pickerYears). Newest first.
  const years = useMemo(() => pickerYears(year), [year]);

  // Selected intake source — GLOBAL, same persistence/sync pattern as year.
  // Options are whatever distinct sources are actually present (not a fixed
  // list, since it's free text typed at upload time), ordered most-recent-first
  // (by the newest candidate carrying each source) so the picker's "latest 11"
  // cap (see sourceFilterProps below) surfaces the tags actually in play right
  // now — the type-ahead search still reaches every source beyond that cap.
  const [source, setSource] = useGlobalSource();
  const sampleDataFilter = useSampleDataFilter();
  const sources = useMemo(() => {
    const latest = new Map<string, string>();
    allCandidates.forEach((c) => {
      const s = sourceOf(c);
      if (!s) return;
      if (s === sampleDataFilter.label && !sampleDataFilter.visible) return;
      const d = c.mail_send_date || c.created_at || "";
      if (d > (latest.get(s) ?? "")) latest.set(s, d);
    });
    return Array.from(latest.keys()).sort((a, b) => (latest.get(b) ?? "").localeCompare(latest.get(a) ?? ""));
  }, [allCandidates, sampleDataFilter.label, sampleDataFilter.visible]);

  // Selected intake month — GLOBAL, same pattern again. Independent of (AND-ed
  // with, not nested inside) year — "All years" + "January" spans every year.
  const [month, setMonth] = useGlobalMonth();

  // Hero-bar candidate search — name or candidate_id, ANDed with the
  // source/year/month filters above so it narrows every panel below
  // (counts, Potential/Processing/Outcomes tables) consistently, the same
  // way changing a filter dropdown does.
  const [nameQuery, setNameQuery] = useState("");

  // Everything below is computed over THIS year's + month's + source's + search candidates only.
  const candidates = useMemo(() => {
    const q = nameQuery.trim().toLowerCase();
    return allCandidates
      .filter((c) => year === ALL_YEARS || yearOf(c) === year)
      .filter((c) => month === ALL_MONTHS || monthOf(c) === month)
      .filter((c) => source === ALL_SOURCES || sourceOf(c) === source)
      .filter(
        (c) =>
          !q ||
          (c.name ?? "").toLowerCase().includes(q) ||
          c.candidate_id.toLowerCase().includes(q) ||
          (c.latest_note?.text ?? "").toLowerCase().includes(q) ||
          (c.latest_remark?.text ?? "").toLowerCase().includes(q) ||
          // Referral: the "referred by" name/email, the referral message, and
          // the "referral(s)" keyword itself (returns every referral candidate).
          (c.referral?.referred_by ?? "").toLowerCase().includes(q) ||
          (c.referral?.message ?? "").toLowerCase().includes(q) ||
          (!!c.referral && q.length >= 3 && "referrals".startsWith(q))
      );
  }, [allCandidates, year, month, source, nameQuery]);

  // Round aging (days in the active round) per candidate — only active-in-round
  // candidates have one; "New" candidates age from pipeline_processed_at instead.
  const { data: analytics } = useQuery({
    queryKey: ["analytics", "rounds"],
    queryFn: async () => (await analyticsService.rounds()).data,
  });

  const agingByCandidate = useMemo(() => {
    const m = new Map<string, number>();
    (analytics?.candidates ?? ([] as AnalyticsCandidate[])).forEach((c) =>
      m.set(c.candidate_id, c.aging_days)
    );
    return m;
  }, [analytics]);

  // candidate_ids that already have an interview scheduled — excluded from the
  // "Potential Candidates" shortlist (that panel is for fresh, unscheduled New
  // candidates only).
  const scheduledIds = useMemo(() => {
    const s = new Set<string>();
    Object.entries(analytics?.scheduled ?? {}).forEach(([id, date]) => {
      if (date) s.add(id);
    });
    return s;
  }, [analytics]);

  // Count per bucket.
  const counts = useMemo(() => {
    const m = Object.fromEntries(ROUND_FILTER_BUCKETS.map((b) => [b, 0])) as Record<RoundBucket, number>;
    candidates.forEach((c) => {
      const b = bucketOf(c);
      if (b) m[b] += 1;
    });
    return m;
  }, [candidates]);

  // Slot-invite lifecycle states across the "Candidates being Processed"
  // buckets — cross-cutting sub-metrics (any round), one per rollup breakdown
  // row: awaiting a slot pick ("slots shared"), reminded at least once,
  // a reminder draft still sitting unsent for recruiter review (Email Send
  // Controls → draft review), and actually booked ("Interview Scheduled").
  const processingStates = useMemo(() => {
    const inProc = candidates.filter((c) => {
      const b = bucketOf(c);
      return b != null && PROCESSING_BUCKETS.includes(b);
    });
    const mk = (arr: CandidateMaster[]) => ({
      count: arr.length,
      oldest: oldestAgeIn(arr, PROCESSING_BUCKETS, agingByCandidate),
    });
    const maxReminders = Math.max(1, cadence?.max_reminders ?? 2);
    // One row per configured reminder: "Reminder k of N sent" counts the
    // candidates still awaiting a pick whose LAST nudge was #k. The final
    // bucket carries the auto-reject warning (its clock is now running).
    const reminderBuckets = Array.from({ length: maxReminders }, (_, i) => {
      const k = i + 1;
      return {
        k,
        stat: mk(
          inProc.filter(
            (c) => (c.reminder_count ?? 0) === k && !scheduledIds.has(c.candidate_id)
          )
        ),
      };
    });
    return {
      slotsShared: mk(inProc.filter((c) => !scheduledIds.has(c.candidate_id))),
      reminded: mk(inProc.filter((c) => (c.reminder_count ?? 0) > 0)),
      reminderBuckets,
      maxReminders,
      reminderDrafts: mk(inProc.filter((c) => c.pending_email_draft?.nba_key === "slot_reminder")),
      scheduled: mk(inProc.filter((c) => scheduledIds.has(c.candidate_id))),
    };
  }, [candidates, agingByCandidate, scheduledIds, cadence]);

  // "Candidates being Processed" rollup — collapsed by default; expand to see
  // its 4 components (Interview slots shared / Reminders Sent / Interview
  // Scheduled / Final) individually.
  const [rollupExpanded, setRollupExpanded] = useState(false);
  // "Rejected" tucked behind a dropdown off "Hired" — same collapsed-by-default
  // breakdown pattern as the processing rollup above.
  const [rejectedExpanded, setRejectedExpanded] = useState(false);

  // Potential candidates — fresh "New" candidates only (not yet moved into any
  // interview round) that don't already have an interview scheduled. Ranked by
  // NLRS so the strongest surface first — matches the table's default sort below.
  const potential = useMemo(
    () =>
      candidates
        .filter((c) => bucketOf(c) === "New" && !scheduledIds.has(c.candidate_id))
        .sort((a, b) => (b.nlrs?.score ?? -1) - (a.nlrs?.score ?? -1)),
    [candidates, scheduledIds]
  );

  // Candidates in Final or Reject — ordered by Aging descending (longest in their
  // current state first), then oldest Action Date on top (earliest scheduled date
  // first; unscheduled sink to the bottom), tie-broken by ATS desc. The card scrolls
  // when rows overflow.
  const processing = useMemo(() => {
    const scheduledMap = analytics?.scheduled ?? {};
    let rows = candidates
      .map((c) => ({ c, b: bucketOf(c) }))
      .filter((x): x is { c: CandidateMaster; b: RoundBucket } => x.b != null && PROCESSING_BUCKETS.includes(x.b));

    // The rollup's own breakdown rows narrow this same list down instead of
    // navigating away — all lifecycle rows are cross-cutting (any round):
    // slots shared = invite out, nothing booked yet; scheduled = actually
    // booked; reminders/drafts track the nudge cycle. Final stays a stage.
    if (processingFilter === "slots_shared") rows = rows.filter((x) => !scheduledIds.has(x.c.candidate_id));
    else if (processingFilter === "scheduled") rows = rows.filter((x) => scheduledIds.has(x.c.candidate_id));
    else if (processingFilter === "final") rows = rows.filter((x) => x.b === "Final");
    else if (processingFilter === "reminders") rows = rows.filter((x) => (x.c.reminder_count ?? 0) > 0);
    else if (processingFilter === "reminder_drafts")
      rows = rows.filter((x) => x.c.pending_email_draft?.nba_key === "slot_reminder");
    else if (processingFilter === "stage_screening") rows = rows.filter((x) => x.b === "Screening");
    else if (processingFilter === "stage_round1") rows = rows.filter((x) => x.b === "Round 1");
    else if (processingFilter === "stage_round2") rows = rows.filter((x) => x.b === "Round 2");

    return rows
      .sort((x, y) => {
        const ax = agingDaysFor(x.c, agingByCandidate) ?? -1;
        const ay = agingDaysFor(y.c, agingByCandidate) ?? -1;
        if (ax !== ay) return ay - ax;
        // Oldest Action Date on top — unscheduled (no date) sorts last.
        const dx = scheduledMap[x.c.candidate_id] ? new Date(scheduledMap[x.c.candidate_id]!).getTime() : Infinity;
        const dy = scheduledMap[y.c.candidate_id] ? new Date(scheduledMap[y.c.candidate_id]!).getTime() : Infinity;
        if (dx !== dy) return dx - dy;
        return (y.c.atsscore ?? -1) - (x.c.atsscore ?? -1);
      })
      .map((x) => x.c);
  }, [candidates, agingByCandidate, analytics, processingFilter, scheduledIds]);

  // Hired / Rejected / Undecided — the 3rd panel. Ranked by NLRS like the
  // "New" list; narrowed to one bucket when a specific tile/dropdown row is clicked.
  const outcomes = useMemo(() => {
    return candidates
      .filter((c) => {
        const b = bucketOf(c);
        return b != null && OUTCOME_BUCKETS.includes(b) && (outcomesFilter == null || b === outcomesFilter);
      })
      .sort((a, b) => (b.nlrs?.score ?? -1) - (a.nlrs?.score ?? -1));
  }, [candidates, outcomesFilter]);

  // Page (1-based) each panel is showing — PAGE_SIZE rows per page, Prev/Next
  // paged rather than an unbounded scroll of every matching candidate.
  const [potentialPage, setPotentialPage] = useState(1);
  const [processingPage, setProcessingPage] = useState(1);
  const [outcomesPage, setOutcomesPage] = useState(1);

  // Jump back to page 1 when an explicit filter changes the list's meaning —
  // a background refetch of the same filter shouldn't bounce the user off
  // the page they're on, so this only watches the filter controls themselves,
  // not the (re-fetchable) candidate arrays. Out-of-range pages (e.g. a
  // candidate leaving the list between refetches) are clamped below instead.
  useEffect(() => setPotentialPage(1), [year, month, source]);
  useEffect(() => setProcessingPage(1), [year, month, source, processingFilter]);
  useEffect(() => setOutcomesPage(1), [year, month, source, outcomesFilter]);

  const potentialRows = useMemo(() => {
    const totalPages = Math.max(1, Math.ceil(potential.length / PAGE_SIZE));
    const page = Math.min(potentialPage, totalPages);
    return potential.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);
  }, [potential, potentialPage]);
  const processingRows = useMemo(() => {
    const totalPages = Math.max(1, Math.ceil(processing.length / PAGE_SIZE));
    const page = Math.min(processingPage, totalPages);
    return processing.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);
  }, [processing, processingPage]);
  const outcomesRows = useMemo(() => {
    const totalPages = Math.max(1, Math.ceil(outcomes.length / PAGE_SIZE));
    const page = Math.min(outcomesPage, totalPages);
    return outcomes.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);
  }, [outcomes, outcomesPage]);

  // System Admin has no recruiting-workflow access (a pure back-office role —
  // see AuthContext.canAccessRecruiting). Frontend-only scoping: nothing about
  // /candidates is actually blocked server-side (Process Flow still needs it),
  // this just keeps System Admin out of the Dashboard UI itself.
  if (!canAccessRecruiting) {
    return (
      <PageContainer>
        <PageHeader title="Dashboard" />
        <div className="flex flex-col items-center justify-center gap-3 rounded-2xl glass p-12 text-center">
          <ShieldAlert className="h-8 w-8 text-muted-foreground" />
          <p className="text-sm font-semibold text-foreground">Dashboard is restricted</p>
          <p className="max-w-sm text-xs text-muted-foreground">
            This section is only available to Admin and Recruitment Manager accounts.
          </p>
        </div>
      </PageContainer>
    );
  }

  if (isLoading) {
    return (
      <div className="p-6 flex items-center gap-2 text-sm text-gray-500">
        <Loader2 className="h-4 w-4 animate-spin" /> Loading dashboard…
      </div>
    );
  }

  // Rendered twice below (mobile: on the "Dashboard" title's own row, pushed
  // to its right edge; desktop: back in the actions row with Year/Month),
  // toggled by breakpoint via the wrapping "sm:hidden" / "hidden sm:block"
  // containers so only one is ever visible at a time. Keeps the mobile
  // actions row down to Year + Month (2 items), which is what actually fits
  // without overflow; desktop has room for all three together as before.
  // Two separate instances (not one shared element) purely so each can carry
  // its own key — both actually want align="right": the title row is
  // `justify-between` (mobile) so this lands at its right edge, and it's the
  // right-most/first item in a right-aligned actions row (desktop). Either
  // way the trigger sits at the right edge of its row, so the panel must
  // open right-aligned to stay on screen.
  const sourceFilterProps = {
    label: source === ALL_SOURCES ? "All sources" : source,
    icon: <Tag className="h-3.5 w-3.5" />,
    options: ["All sources", ...sources],
    selected: source === ALL_SOURCES ? new Set<string>() : new Set([source]),
    onToggle: (v: string) => setSource(v === "All sources" ? ALL_SOURCES : v),
    onClear: () => setSource(ALL_SOURCES),
    width: "w-48",
    single: true,
    allowClear: false,
    searchable: true,
    searchPlaceholder: "Search sources…",
    // "All sources" is pinned first, so 12 = it + the latest 11 real sources.
    searchLimit: 12,
  };

  return (
    <PageContainer className="flex flex-col lg:h-full">
      <PageHeader
        title="Dashboard"
        titleAdornment={
          <div className="sm:hidden">
            <FilterDropdown {...sourceFilterProps} align="right" />
          </div>
        }
        actions={
          // w-full + flex-wrap on mobile so this whole group (search + filter
          // chips) wraps predictably within its own row instead of being
          // shoved around by the fixed-size Refresh button sharing the line —
          // that's what left the odd stray gap around Refresh on narrow phones.
          <div className="flex w-full flex-wrap items-center gap-2 sm:w-auto sm:flex-nowrap">
            <div className="relative">
              <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
              <input
                value={nameQuery}
                onChange={(e) => setNameQuery(e.target.value)}
                placeholder="Search candidates…"
                className="w-32 rounded-lg border border-border bg-card/70 py-1.5 pl-8 pr-7 text-xs text-foreground placeholder:text-muted-foreground outline-none transition-all focus:w-52 focus:border-primary/50 focus:ring-2 focus:ring-primary/20"
              />
              {nameQuery && (
                <button
                  onClick={() => setNameQuery("")}
                  title="Clear search"
                  className="absolute right-1.5 top-1/2 -translate-y-1/2 rounded-md p-0.5 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
            <div className="hidden sm:block">
              <FilterDropdown {...sourceFilterProps} align="right" />
            </div>
            <FilterDropdown
              label={year === ALL_YEARS ? "All years" : String(year)}
              icon={<Calendar className="h-3.5 w-3.5" />}
              options={["All years", ...years.map(String)]}
              selected={year === ALL_YEARS ? new Set() : new Set([String(year)])}
              onToggle={(v) => setYear(v === "All years" ? ALL_YEARS : Number(v))}
              onClear={() => setYear(ALL_YEARS)}
              width="w-40"
              single
              allowClear={false}
              align="right"
            />
            <FilterDropdown
              label={month === ALL_MONTHS ? "All months" : MONTH_NAMES[month - 1]}
              icon={<CalendarDays className="h-3.5 w-3.5" />}
              options={["All months", ...MONTH_NAMES]}
              selected={month === ALL_MONTHS ? new Set() : new Set([MONTH_NAMES[month - 1]])}
              onToggle={(v) =>
                setMonth(v === "All months" ? ALL_MONTHS : MONTH_NAMES.indexOf(v as (typeof MONTH_NAMES)[number]) + 1)
              }
              onClear={() => setMonth(ALL_MONTHS)}
              width="w-40"
              single
              allowClear={false}
              align="right"
            />
          </div>
        }
      />

      {/* Stage tiles, regrouped: New | Candidates being Processed (rolled up) |
          Hired/Rejected | Undecided. New and the rollup control THIS page's own
          panels below (click = expand/collapse, no navigation) since those two
          panels already ARE this page's view of those candidates. Hired/Rejected
          and Undecided have no panel here, so they still deep-link to the
          Candidates page. Age-of-oldest replaces the old standalone Aging tile,
          shown per-stage instead (only where bucketAges applies).
          Wraps rather than horizontally scrolling — an overflow-x-auto row
          forces overflow-y to clip too (a real CSS overflow-pairing quirk),
          which was cutting off the rollup/Rejected dropdown bubbles that pop
          out below their pill. Wrap + the responsive sm:/lg: pill sizing above
          is what makes this row adapt to available space instead. */}
      <div className="flex flex-wrap items-center justify-center gap-1.5 sm:gap-2 lg:gap-2.5">
        <StatCard
          compact
          variant="pill"
          icon={Sparkles}
          label="New"
          value={counts.New}
          accent="sky"
          sub={<OldestAgeBadge days={oldestAgeIn(candidates, ["New"], agingByCandidate)} />}
          onClick={() => setPanelFocus("new")}
        />

        <div className="relative inline-flex shrink-0 items-center gap-1">
          <StatCard
            compact
            variant="pill"
            icon={Users}
            label="Candidates being Processed"
            value={PROCESSING_BUCKETS.reduce((sum, b) => sum + counts[b], 0)}
            accent="violet"
            sub={<OldestAgeBadge days={oldestAgeIn(candidates, PROCESSING_BUCKETS, agingByCandidate)} />}
            onClick={() => {
              setProcessingFilter(null);
              setPanelFocus("processing");
            }}
          />
          <button
            type="button"
            onClick={() => setRollupExpanded((v) => !v)}
            title={rollupExpanded ? "Hide breakdown" : "Show breakdown"}
            className="surface flex h-6 w-6 shrink-0 items-center justify-center !rounded-full text-ink-mute transition-colors hover:bg-secondary hover:text-ink sm:h-7 sm:w-7 lg:h-8 lg:w-8"
          >
            <ChevronDown className={cn("h-3 w-3 transition-transform sm:h-3.5 sm:w-3.5", rollupExpanded && "rotate-180")} />
          </button>

          {rollupExpanded && (
            <div className="absolute left-0 top-full z-40 mt-1.5 w-72 rounded-xl border border-border bg-card p-1.5 shadow-lg">
              {(
                [
                  // Slot-invite lifecycle order: invite out → nudges → drafts
                  // waiting on the recruiter → booked → the Final stage.
                  { key: "slots_shared", label: PROCESSING_FILTER_LABEL.slots_shared, stat: processingStates.slotsShared },
                  // One row per configured reminder — the final one carries
                  // the auto-reject warning (the candidate was told the same
                  // in that reminder's email).
                  ...processingStates.reminderBuckets.map(({ k, stat }) => ({
                    key: "reminders" as ProcessingFilter,
                    label:
                      k === processingStates.maxReminders
                        ? `Reminder ${k} of ${processingStates.maxReminders} (final) — auto-rejects after ${cadence ? `${cadence.auto_reject_after} ${cadence.auto_reject_after_unit}` : "the response window"}`
                        : `Reminder ${k} of ${processingStates.maxReminders} sent`,
                    stat,
                  })),
                  { key: "reminder_drafts", label: PROCESSING_FILTER_LABEL.reminder_drafts, stat: processingStates.reminderDrafts },
                  { key: "scheduled", label: PROCESSING_FILTER_LABEL.scheduled, stat: processingStates.scheduled },
                  {
                    key: "final",
                    label: PROCESSING_FILTER_LABEL.final,
                    stat: { count: counts.Final, oldest: oldestAgeIn(candidates, ["Final"], agingByCandidate) },
                  },
                ] as { key: ProcessingFilter; label: string; stat: { count: number; oldest: number | null } }[]
              ).map(({ key, label, stat }) => (
                <button
                  key={label}
                  type="button"
                  onClick={() => {
                    setProcessingFilter(key);
                    setPanelFocus("processing");
                    setRollupExpanded(false);
                  }}
                  className="flex w-full items-center justify-between gap-2 rounded-lg px-2.5 py-1.5 text-left text-xs text-ink transition-colors hover:bg-secondary"
                >
                  <span>{label}</span>
                  <span className="flex items-center gap-1.5">
                    <span className="tnum font-bold text-ink">{stat.count}</span>
                    <OldestAgeBadge days={stat.oldest} />
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Hired — primary control into the Hired/Rejected/Undecided panel.
            Rejected drops from it via a small chevron bubble, same
            collapsed-by-default pattern as the processing rollup. */}
        <div className="relative inline-flex shrink-0 items-center gap-1">
          <button
            type="button"
            onClick={() => {
              setOutcomesFilter("Hired");
              setPanelFocus("outcomes");
            }}
            title="Can be Offered"
            className="surface inline-flex shrink-0 items-center gap-1 !rounded-full px-2 py-1 transition-all duration-200 active:scale-95 sm:gap-1.5 sm:px-2.5 sm:py-1.5 lg:gap-2 lg:px-3"
          >
            <span className="flex h-4 w-4 items-center justify-center rounded-full bg-blue-500/10 sm:h-5 sm:w-5 lg:h-6 lg:w-6">
              <CheckCircle2 className="h-2.5 w-2.5 text-blue-600 sm:h-3 sm:w-3 lg:h-3.5 lg:w-3.5" />
            </span>
            <span className="stat-value text-xs font-semibold leading-none text-ink sm:text-sm lg:text-base">{counts.Hired}</span>
            <span className="whitespace-nowrap text-[9px] font-medium text-ink-mute sm:text-[10px] lg:text-xs">Hire</span>
          </button>
          <button
            type="button"
            onClick={() => setRejectedExpanded((v) => !v)}
            title={rejectedExpanded ? "Hide Rejected" : "Show Rejected"}
            className="surface flex h-6 w-6 shrink-0 items-center justify-center !rounded-full text-ink-mute transition-colors hover:bg-secondary hover:text-ink sm:h-7 sm:w-7 lg:h-8 lg:w-8"
          >
            <ChevronDown className={cn("h-3 w-3 transition-transform sm:h-3.5 sm:w-3.5", rejectedExpanded && "rotate-180")} />
          </button>

          {rejectedExpanded && (
            <div className="absolute left-0 top-full z-40 mt-1.5 w-44 rounded-xl border border-border bg-card p-1.5 shadow-lg">
              <button
                type="button"
                onClick={() => {
                  setOutcomesFilter("Reject");
                  setPanelFocus("outcomes");
                  setRejectedExpanded(false);
                }}
                className="flex w-full items-center justify-between gap-2 rounded-lg px-2.5 py-1.5 text-left text-xs text-ink transition-colors hover:bg-secondary"
              >
                <span className="flex items-center gap-1.5">
                  <XCircle className="h-3 w-3 text-rose-600" />
                  Rejected
                </span>
                <span className="tnum font-bold text-ink">{counts.Reject}</span>
              </button>
            </div>
          )}
        </div>

        <StatCard
          compact
          variant="pill"
          icon={PauseCircle}
          label="Undecided"
          value={counts.Undecided}
          accent="orange"
          sub={<OldestAgeBadge days={oldestAgeIn(candidates, ["Undecided"], agingByCandidate)} />}
          onClick={() => {
            setOutcomesFilter("Undecided");
            setPanelFocus("outcomes");
          }}
        />
      </div>

      {/* Candidate shortlists — New / being processed / outcomes, all three
          filterable in place from the tiles above instead of navigating to the
          Candidates page. Grows to fill the remaining viewport height; each
          list scrolls independently when its rows overflow the card. Wide
          AND tall enough (`canRow` — see above) only: exactly ONE panel is
          ever expanded full-width, the other two are always collapsed to
          narrow icon strips (see PanelFocus above — New by default); below
          that (or too short), all three always stack full-width, so EVERY
          panel's full content AND its collapsed strip stay in the DOM and
          it's `canRow` (not a JS `collapsed ? <Strip/> : <Content/>` swap)
          choosing which shows — a swap would've hidden the content in the
          stacked layout too whenever a focus state happened to be set from a
          previous, wider session. */}
      <div className={cn("flex flex-col gap-4", canRow && "min-h-0 flex-1 flex-row")}>
        {/* New — not yet being processed (still "New"), strongest by NLRS.
            Expanded by default; no in-header collapse button here since New
            IS the resting state everything else falls back to. */}
        <div
          className={cn(
            "flex min-h-[360px] flex-col rounded-2xl glass p-5",
            canRow && "min-h-0",
            canRow && (panelFocus !== "new" ? "w-16 shrink-0 p-2" : "min-w-0 flex-1"),
          )}
        >
          <div className={cn("hidden flex-1", canRow && panelFocus !== "new" && "flex")}>
            <CollapsedPanelStrip
              icon={Sparkles}
              iconClassName="text-sky-500"
              label="New Potential Candidates Added"
              count={potential.length}
              chevron={ChevronRight}
              onExpand={() => setPanelFocus("new")}
            />
          </div>
          <div
            className={cn(
              "min-h-0 flex-1 flex-col",
              canRow && panelFocus !== "new" ? "hidden" : "flex",
            )}
          >
            <div className="mb-3 flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-sky-500" />
              <h2 className="min-w-0 flex-1 text-sm font-medium text-ink">
                New Potential Candidates Added
              </h2>
            </div>
            <div className="min-h-0 flex-1 overflow-y-auto">
              {potential.length === 0 ? (
                <p className="py-8 text-center text-xs text-muted-foreground">
                  No candidates waiting to be processed.
                </p>
              ) : (
                <CandidateTable
                  rows={potentialRows}
                  onRowClick={(id) => navigate(`/candidates/${id}`)}
                  onReport={setAnalysisFor}
                  onUndecided={askUndecided}
                  onAtsBreakdown={setAtsBreakdownFor}
                  onNlrsBreakdown={setNlrsBreakdownFor}
                  agingByCandidate={agingByCandidate}
                />
              )}
            </div>
            <ListPagination page={potentialPage} total={potential.length} onPageChange={setPotentialPage} />
          </div>
        </div>

        {/* Candidates being Processed — Screening/Round 1/Round 2/Final, optionally
            narrowed to one of the rollup's breakdown rows (processingFilter). */}
        <div
          className={cn(
            "flex min-h-[360px] flex-col rounded-2xl glass p-5",
            canRow && "min-h-0",
            canRow && (panelFocus !== "processing" ? "w-16 shrink-0 p-2" : "min-w-0 flex-1"),
          )}
        >
          <div className={cn("hidden flex-1", canRow && panelFocus !== "processing" && "flex")}>
            <CollapsedPanelStrip
              icon={Users}
              iconClassName="text-violet-500"
              label="Candidates being Processed"
              count={processing.length}
              chevron={ChevronLeft}
              onExpand={() => setPanelFocus("processing")}
            />
          </div>
          <div
            className={cn(
              "min-h-0 flex-1 flex-col",
              canRow && panelFocus !== "processing" ? "hidden" : "flex",
            )}
          >
            <div className="mb-3 flex items-center gap-2">
              <Users className="h-4 w-4 text-violet-500" />
              <h2 className="min-w-0 flex-1 text-sm font-medium text-ink">
                Candidates being Processed
              </h2>
              {processingFilter && (
                <button
                  type="button"
                  onClick={() => setProcessingFilter(null)}
                  title="Clear filter"
                  className="inline-flex shrink-0 items-center gap-1 rounded-full bg-violet-500/10 px-2 py-0.5 text-[10px] font-semibold text-violet-600 transition-colors hover:bg-violet-500/20"
                >
                  {PROCESSING_FILTER_LABEL[processingFilter]}
                  <X className="h-2.5 w-2.5" />
                </button>
              )}
              <button
                type="button"
                onClick={() => setPanelFocus("new")}
                title="Collapse this panel"
                className={cn(
                  "shrink-0 rounded-lg p-1 text-ink-mute transition-colors hover:bg-secondary hover:text-ink",
                  canRow ? "inline-flex" : "hidden",
                )}
              >
                <ChevronRight className="h-3.5 w-3.5" />
              </button>
            </div>
            <div className="min-h-0 flex-1 overflow-y-auto">
              {processing.length === 0 ? (
                <p className="py-8 text-center text-xs text-muted-foreground">
                  {processingFilter ? "No candidates match this filter." : "No candidates being processed yet."}
                </p>
              ) : (
                <ProcessingTable
                  rows={processingRows}
                  onRowClick={(id) => navigate(`/candidates/${id}`)}
                  onReport={setAnalysisFor}
                  onUndecided={askUndecided}
                  onAtsBreakdown={setAtsBreakdownFor}
                  onNlrsBreakdown={setNlrsBreakdownFor}
                  agingByCandidate={agingByCandidate}
                  scheduledByCandidate={analytics?.scheduled ?? {}}
                />
              )}
            </div>
            <ListPagination page={processingPage} total={processing.length} onPageChange={setProcessingPage} />
          </div>
        </div>

        {/* Hired / Rejected / Undecided — optionally narrowed to one outcome
            (outcomesFilter) by the Hired/Rejected/Undecided tiles above. */}
        <div
          className={cn(
            "flex min-h-[360px] flex-col rounded-2xl glass p-5",
            canRow && "min-h-0",
            canRow && (panelFocus !== "outcomes" ? "w-16 shrink-0 p-2" : "min-w-0 flex-1"),
          )}
        >
          <div className={cn("hidden flex-1", canRow && panelFocus !== "outcomes" && "flex")}>
            <CollapsedPanelStrip
              icon={CheckCircle2}
              iconClassName="text-blue-500"
              label="Hired / Rejected / Undecided"
              count={outcomes.length}
              chevron={ChevronLeft}
              onExpand={() => setPanelFocus("outcomes")}
            />
          </div>
          <div
            className={cn(
              "min-h-0 flex-1 flex-col",
              canRow && panelFocus !== "outcomes" ? "hidden" : "flex",
            )}
          >
            <div className="mb-3 flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-blue-500" />
              <h2 className="min-w-0 flex-1 text-sm font-medium text-ink">
                Hired / Rejected / Undecided
              </h2>
              {outcomesFilter && (
                <button
                  type="button"
                  onClick={() => setOutcomesFilter(null)}
                  title="Clear filter"
                  className="inline-flex shrink-0 items-center gap-1 rounded-full bg-blue-500/10 px-2 py-0.5 text-[10px] font-semibold text-blue-600 transition-colors hover:bg-blue-500/20"
                >
                  {roundLabel(outcomesFilter)}
                  <X className="h-2.5 w-2.5" />
                </button>
              )}
              <button
                type="button"
                onClick={() => setPanelFocus("new")}
                title="Collapse this panel"
                className={cn(
                  "shrink-0 rounded-lg p-1 text-ink-mute transition-colors hover:bg-secondary hover:text-ink",
                  canRow ? "inline-flex" : "hidden",
                )}
              >
                <ChevronRight className="h-3.5 w-3.5" />
              </button>
            </div>
            <div className="min-h-0 flex-1 overflow-y-auto">
              {outcomes.length === 0 ? (
                <p className="py-8 text-center text-xs text-muted-foreground">
                  {outcomesFilter ? "No candidates match this filter." : "No hired, rejected, or undecided candidates yet."}
                </p>
              ) : (
                <OutcomesTable
                  rows={outcomesRows}
                  onRowClick={(id) => navigate(`/candidates/${id}`)}
                  onReport={setAnalysisFor}
                  onUndecided={askUndecided}
                  onAtsBreakdown={setAtsBreakdownFor}
                  onNlrsBreakdown={setNlrsBreakdownFor}
                  agingByCandidate={agingByCandidate}
                />
              )}
            </div>
            <ListPagination page={outcomesPage} total={outcomes.length} onPageChange={setOutcomesPage} />
          </div>
        </div>
      </div>

      <NbaCommentDialog
        open={!!pendingNba}
        title={pendingNba?.kind === "apply" ? "Apply predicted Next Best Action?" : "Change the Next Best Action?"}
        message={
          pendingNba && (
            <>
              {pendingNba.kind === "apply" ? "Moves " : "Updates the next action for "}
              <span className="font-semibold text-foreground">{pendingNba.name}</span>
              {pendingNba.kind === "apply"
                ? " forward with their predicted action, right away."
                : " and runs its automation (stage move / email draft) right away."}
            </>
          )
        }
        pending={applyPredicted.isPending || updateNba.isPending}
        onCancel={() => setPendingNba(null)}
        onApply={(comment) => {
          if (pendingNba?.kind === "apply")
            applyPredicted.mutate({ candidateId: pendingNba.candidateId, comment });
          else if (pendingNba?.kind === "override")
            updateNba.mutate({ candidateId: pendingNba.candidateId, ov: pendingNba.ov, comment });
          setPendingNba(null);
        }}
      />

      {/* Analysis Report popover — opened by the Report button on a potential-candidate row. */}
      {analysisFor && (
        <AnalysisReportModal
          candidate={analysisFor}
          agingDays={agingDaysFor(analysisFor, agingByCandidate)}
          isAdmin={isAdmin}
          canApplyPredicted={canApplyFor(analysisFor.source)}
          onClose={() => setAnalysisFor(null)}
          onViewResume={() => setResumeFor(analysisFor)}
          onApplyPredicted={() => {
            setPendingNba({
              kind: "apply",
              candidateId: analysisFor.candidate_id,
              name: analysisFor.name ?? analysisFor.candidate_id,
            });
            setAnalysisFor(null);
          }}
          applyPending={applyPredicted.isPending}
          onOverrideSave={(ov) => {
            setPendingNba({
              kind: "override",
              candidateId: analysisFor.candidate_id,
              name: analysisFor.name ?? analysisFor.candidate_id,
              ov,
            });
            setAnalysisFor(null);
          }}
          onReviewDraft={() => setDraftReviewFor(analysisFor)}
        />
      )}

      {/* ATS/NLRS score-breakdown popovers — opened by clicking a candidate's
          ATS/NLRS value in any of the three lists above. */}
      {atsBreakdownFor && (
        <ScorePopoverModal
          candidate={atsBreakdownFor}
          subtitle="Why this ATS score"
          onClose={() => setAtsBreakdownFor(null)}
        >
          <ScoreBreakdown c={atsBreakdownFor} />
        </ScorePopoverModal>
      )}
      {nlrsBreakdownFor && (
        <ScorePopoverModal
          candidate={nlrsBreakdownFor}
          subtitle="Why this NLRS score"
          onClose={() => setNlrsBreakdownFor(null)}
        >
          <NlrsBreakdown c={nlrsBreakdownFor} />
        </ScorePopoverModal>
      )}

      {resumeFor && (
        <ResumeViewerModal
          open={!!resumeFor}
          candidateId={resumeFor.candidate_id}
          which="current"
          fileName={resumeFor.s3_file_path}
          onClose={() => setResumeFor(null)}
        />
      )}

      {draftReviewFor?.pending_email_draft && (
        <EmailDraftReviewModal
          draft={draftReviewFor.pending_email_draft}
          candidate={draftReviewFor}
          onClose={() => setDraftReviewFor(null)}
          onUpdated={() => queryClient.invalidateQueries({ queryKey: ["candidates"] })}
        />
      )}
    </PageContainer>
  );
}
