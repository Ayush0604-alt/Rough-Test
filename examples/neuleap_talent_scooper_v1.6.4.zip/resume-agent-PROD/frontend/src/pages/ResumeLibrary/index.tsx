import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { Search, FileText, Eye, SlidersHorizontal, Loader2, Calendar, ArrowUpDown, Award } from "lucide-react";
import { candidatesService } from "@/services/candidates";
import { settingsService } from "@/services/settings";
import { cn, titleCase, formatExperience, formatScore } from "@/lib/utils";
import type { CandidateMaster, CandidateStream } from "@/types/candidate";
import { NoteBadge, ReferralBadge } from "@/components/candidate/CandidateNote";
import { parseCertificates } from "@/types/candidate";
import { effectiveStatus } from "@/lib/rounds";
import ResumeViewerModal from "@/components/candidate/ResumeViewerModal";
import PageHeader from "@/components/layout/PageHeader";
import PageContainer from "@/components/layout/PageContainer";

const STREAM_COLORS: Record<string, string> = {
  GenAI: "text-violet-400 bg-violet-400/10 border-violet-500/30",
  "Data Eng": "text-teal-400 bg-teal-400/10 border-teal-500/30",
  "Not Relevant": "text-slate-400 bg-slate-400/10 border-slate-500/30",
};

const STATUS_COLORS: Record<string, string> = {
  Active: "text-emerald-400 bg-emerald-400/10 border-emerald-500/30",
  Hired: "text-blue-400 bg-blue-400/10 border-blue-500/30",
  Rejected: "text-rose-400 bg-rose-400/10 border-rose-500/30",
};

// Sort key: prefer the full timestamp (created_at → parsed_at) so resumes added on
// the same day still order by time; fall back to the date-only mail_send_date.
function sortTs(c: CandidateMaster): number {
  const s = c.created_at ?? c.parsed_at ?? c.mail_send_date;
  const t = s ? new Date(s).getTime() : 0;
  return Number.isNaN(t) ? 0 : t;
}

// True when the candidate has at least one certificate whose name or issuer contains
// `term` (case-insensitive). Used by the AND cert filter and the keyword search.
function certMatches(c: CandidateMaster, term: string): boolean {
  const t = term.trim().toLowerCase();
  if (!t) return true;
  return parseCertificates(c.certificates).some(
    (cert) =>
      cert.name.toLowerCase().includes(t) ||
      (cert.issuer ?? "").toLowerCase().includes(t)
  );
}

function fileExt(path: string): "PDF" | "DOCX" | "IMAGE" {
  const p = (path ?? "").toLowerCase();
  if (p.endsWith(".pdf")) return "PDF";
  if (p.endsWith(".docx")) return "DOCX";
  return "IMAGE";
}

function AtsBar({ score }: { score: number }) {
  const pct = Math.max(0, Math.min(100, score));
  const color =
    score >= 85 ? "bg-emerald-500" :
    score >= 70 ? "bg-blue-500" :
    score >= 55 ? "bg-yellow-500" : "bg-red-500";
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-1.5 bg-secondary rounded-full">
        <div className={cn("h-full rounded-full", color)} style={{ width: `${pct}%` }} />
      </div>
      <span className="text-xs font-bold text-foreground w-10 text-right">{formatScore(score)}</span>
    </div>
  );
}

function ResumeCard({ c, onClick, onView }: { c: CandidateMaster; onClick: () => void; onView: () => void }) {
  const ext = fileExt(c.s3_file_path);
  const certCount = parseCertificates(c.certificates).length;
  return (
    <div
      onClick={onClick}
      className="rounded-xl border border-border bg-card p-4 flex flex-col gap-3 h-full cursor-pointer hover:border-primary/40 hover:bg-accent/30 transition-all group"
    >
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-2">
          <div className={cn(
            "w-8 h-8 rounded-lg flex items-center justify-center text-[10px] font-bold",
            ext === "PDF" ? "bg-red-500/15 text-red-400" :
            ext === "DOCX" ? "bg-blue-500/15 text-blue-400" :
            "bg-green-500/15 text-green-400"
          )}>
            {ext}
          </div>
          <div>
            <div className="flex items-center gap-1 text-xs font-bold text-foreground">
              {titleCase(c.name)}
              <ReferralBadge referral={c.referral} />
              <NoteBadge note={c.latest_note} />
            </div>
            <div className="text-[10px] text-muted-foreground font-mono">{c.candidate_id}</div>
          </div>
        </div>
        <button
          onClick={(e) => {
            e.stopPropagation();
            onView();
          }}
          title="View resume"
          className="opacity-0 group-hover:opacity-100 transition-opacity p-1.5 rounded-md hover:bg-secondary"
        >
          <Eye className="h-3.5 w-3.5 text-muted-foreground" />
        </button>
      </div>

      <div className="flex items-center gap-1.5 flex-wrap">
        {STATUS_COLORS[effectiveStatus(c)] && (
          <span className={cn("text-[10px] font-semibold border rounded-full px-1.5 py-0.5", STATUS_COLORS[effectiveStatus(c)])}>
            {effectiveStatus(c)}
          </span>
        )}
        {c.stream && (
          <span className={cn("text-[10px] font-semibold border rounded-full px-1.5 py-0.5", STREAM_COLORS[c.stream])}>
            {c.stream}
          </span>
        )}
        {c.fresher_or_lateral && (
          <span className="text-[10px] text-muted-foreground border border-border rounded-full px-1.5 py-0.5">
            {c.fresher_or_lateral}
          </span>
        )}
        {certCount > 0 && (
          <span
            title={`${certCount} certificate${certCount !== 1 ? "s" : ""}`}
            className="inline-flex items-center gap-0.5 text-[10px] text-amber-400 border border-amber-500/30 bg-amber-400/10 rounded-full px-1.5 py-0.5 font-medium"
          >
            <Award className="h-3 w-3" />
            {certCount}
          </span>
        )}
      </div>

      <div className="space-y-1">
        <div className="text-[10px] text-muted-foreground">{c.clg ?? "—"}</div>
        <div className="text-[10px] text-muted-foreground">
          {c.passoutyr ? `Passout ${c.passoutyr}` : ""}
          {c.yearofexp ? ` · ${formatExperience(c.yearofexp)} exp` : ""}
          {c.currentcompany ? ` · ${c.currentcompany}` : ""}
        </div>
      </div>

      {/* Pinned to the bottom so the bar + date line up across every card in a row,
          regardless of how many lines the college name wraps to. */}
      <div className="mt-auto space-y-3 pt-1">
        {c.atsscore != null ? (
          <AtsBar score={c.atsscore} />
        ) : (
          <div className="text-[10px] text-muted-foreground">ATS score pending</div>
        )}

        <div className="text-[10px] text-muted-foreground border-t border-border/50 pt-2">
          Added {c.mail_send_date}
        </div>
      </div>
    </div>
  );
}

export default function ResumeLibrary() {
  const navigate = useNavigate();
  const [search, setSearch] = useState("");
  const [streamFilter, setStreamFilter] = useState<CandidateStream | "All">("All");
  const [statusFilter, setStatusFilter] = useState<"All" | "Hired" | "Rejected">("All");
  const [dateFilter, setDateFilter] = useState<"All" | "Today" | "Month">("All");
  const [sortOrder, setSortOrder] = useState<"newest" | "oldest">("newest");
  const [viewing, setViewing] = useState<CandidateMaster | null>(null);
  // Certificate filter: checked tags are ANDed; the keyword is ANDed on top.
  const [selectedTags, setSelectedTags] = useState<Set<string>>(new Set());
  const [certKeyword, setCertKeyword] = useState("");

  const { data: candidates = [], isLoading } = useQuery({
    queryKey: ["candidates"],
    queryFn: async () => (await candidatesService.list()).data,
  });

  // Admin-editable certificate tags (Settings page); fall back to none until loaded.
  const { data: certTags = [] } = useQuery({
    queryKey: ["scoring", "cert_tags"],
    queryFn: async () => (await settingsService.getScoring()).data.cert_tags ?? [],
  });

  const toggleTag = (tag: string) =>
    setSelectedTags((prev) => {
      const next = new Set(prev);
      next.has(tag) ? next.delete(tag) : next.add(tag);
      return next;
    });

  // AND predicate: every checked tag (and the keyword, if any) must be satisfied by
  // at least one of the candidate's certificates.
  const matchCert = (c: CandidateMaster): boolean => {
    const terms = [...selectedTags];
    const kw = certKeyword.trim();
    if (kw) terms.push(kw);
    if (terms.length === 0) return true;
    return terms.every((term) => certMatches(c, term));
  };

  const certFilterActive = selectedTags.size > 0 || certKeyword.trim() !== "";

  const withFile = candidates.filter((c) => c.s3_file_path && c.name);

  const today = new Date().toISOString().slice(0, 10);
  const month = today.slice(0, 7); // YYYY-MM

  const filtered = withFile
    .filter((c) => {
      const q = search.toLowerCase();
      const matchSearch = !q || (c.name?.toLowerCase().includes(q) || c.clg?.toLowerCase().includes(q));
      const matchStream = streamFilter === "All" || c.stream === streamFilter;
      const matchStatus = statusFilter === "All" || effectiveStatus(c) === statusFilter;
      const matchDate =
        dateFilter === "All" ||
        (dateFilter === "Today" && c.mail_send_date === today) ||
        (dateFilter === "Month" && (c.mail_send_date ?? "").startsWith(month));
      return matchSearch && matchStream && matchStatus && matchDate && matchCert(c);
    })
    // Sort by date/time: newest or oldest first.
    .sort((a, b) => (sortOrder === "newest" ? sortTs(b) - sortTs(a) : sortTs(a) - sortTs(b)));

  const addedToday = withFile.filter((c) => c.mail_send_date === today).length;

  return (
    <PageContainer>
      {viewing && (
        <ResumeViewerModal
          open={!!viewing}
          candidateId={viewing.candidate_id}
          fileName={viewing.s3_file_path}
          onClose={() => setViewing(null)}
        />
      )}

      {/* Header */}
      <PageHeader
        eyebrow="Library"
        title="Resume Library"
        subtitle="All validated resumes, with duplicates removed"
      />

      {/* Summary bar */}
      <div className="flex flex-wrap items-center gap-x-4 gap-y-2 rounded-xl border border-border bg-card px-4 py-3 sm:px-5">
        <div className="flex items-center gap-2">
          <FileText className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm font-bold text-foreground">{withFile.length}</span>
          <span className="text-xs text-muted-foreground">Total resumes</span>
        </div>
        <div className="w-px h-4 bg-border" />
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">Added today</span>
          <span className="text-sm font-bold text-foreground">{addedToday}</span>
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3 flex-wrap">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search name or college…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-8 pr-4 py-2 text-xs rounded-lg border border-border bg-secondary text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50 w-52"
          />
        </div>

        <div className="flex flex-wrap items-center gap-1">
          <SlidersHorizontal className="h-3.5 w-3.5 text-muted-foreground" />
          <span className="text-xs text-muted-foreground">Stream:</span>
          {(["All", "GenAI", "Data Eng", "Not Relevant"] as const).map((s) => (
            <button
              key={s}
              onClick={() => setStreamFilter(s as any)}
              className={cn(
                "px-2.5 py-1 text-xs rounded-full border font-medium transition-colors",
                streamFilter === s
                  ? "border-primary bg-primary/10 text-primary"
                  : "border-border text-muted-foreground hover:text-foreground hover:border-border/80"
              )}
            >
              {s}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-1">
          <span className="text-xs text-muted-foreground">Status:</span>
          {(["All", "Hired", "Rejected"] as const).map((s) => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={cn(
                "px-2.5 py-1 text-xs rounded-full border font-medium transition-colors",
                statusFilter === s
                  ? "border-primary bg-primary/10 text-primary"
                  : "border-border text-muted-foreground hover:text-foreground"
              )}
            >
              {s}
            </button>
          ))}
        </div>

        {certTags.length > 0 && (
          <div className="flex flex-wrap items-center gap-1">
            <Award className="h-3.5 w-3.5 text-amber-400" />
            <span className="text-xs text-muted-foreground">Certs:</span>
            {certTags.map((tag) => {
              const active = selectedTags.has(tag);
              return (
                <button
                  key={tag}
                  onClick={() => toggleTag(tag)}
                  className={cn(
                    "px-2.5 py-1 text-xs rounded-full border font-medium transition-colors",
                    active
                      ? "border-amber-500/50 bg-amber-400/10 text-amber-400"
                      : "border-border text-muted-foreground hover:text-foreground hover:border-border/80"
                  )}
                >
                  {active ? "✓ " : ""}{tag}
                </button>
              );
            })}
            <input
              type="text"
              value={certKeyword}
              onChange={(e) => setCertKeyword(e.target.value)}
              placeholder="+ keyword…"
              title="Match any cert name or issuer (ANDed with checked tags)"
              className="w-28 px-2 py-1 text-xs rounded-full border border-border bg-secondary text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50"
            />
          </div>
        )}

        <div className="flex items-center gap-1">
          <Calendar className="h-3.5 w-3.5 text-muted-foreground" />
          {([["All", "All"], ["Today", "Today"], ["Month", "This month"]] as const).map(([val, label]) => (
            <button
              key={val}
              onClick={() => setDateFilter(val)}
              className={cn(
                "px-2.5 py-1 text-xs rounded-full border font-medium transition-colors",
                dateFilter === val
                  ? "border-primary bg-primary/10 text-primary"
                  : "border-border text-muted-foreground hover:text-foreground"
              )}
            >
              {label}
            </button>
          ))}
        </div>

        <button
          onClick={() => setSortOrder((o) => (o === "newest" ? "oldest" : "newest"))}
          title="Toggle sort order by date & time"
          className="flex items-center gap-1 px-2.5 py-1 text-xs rounded-full border border-border font-medium text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowUpDown className="h-3.5 w-3.5" />
          {sortOrder === "newest" ? "Newest first" : "Oldest first"}
        </button>

        {(search || streamFilter !== "All" || statusFilter !== "All" || dateFilter !== "All" || certFilterActive) && (
          <button
            onClick={() => {
              setSearch(""); setStreamFilter("All");
              setStatusFilter("All"); setDateFilter("All");
              setSelectedTags(new Set()); setCertKeyword("");
            }}
            className="text-xs text-muted-foreground hover:text-foreground underline"
          >
            Clear filters
          </button>
        )}

        <span className="ml-auto text-xs text-muted-foreground">{filtered.length} resumes</span>
      </div>

      {/* Card grid */}
      {isLoading ? (
        <div className="py-16 flex items-center justify-center gap-2 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading resumes…
        </div>
      ) : filtered.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border py-16 flex flex-col items-center gap-2 text-muted-foreground">
          <FileText className="h-8 w-8 opacity-30" />
          <p className="text-sm">No resumes match your filters.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {filtered.map((c) => (
            <ResumeCard
              key={c.candidate_id}
              c={c}
              onClick={() => navigate(`/candidates/${c.candidate_id}`)}
              onView={() => setViewing(c)}
            />
          ))}
        </div>
      )}
    </PageContainer>
  );
}
