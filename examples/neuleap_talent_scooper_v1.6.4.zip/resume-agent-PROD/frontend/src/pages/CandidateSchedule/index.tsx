import { useCallback, useEffect, useMemo, useState } from "react";
import { useParams, useSearchParams } from "react-router-dom";
import { motion } from "framer-motion";
import {
  AlertTriangle,
  Bell,
  Calendar,
  CheckCircle2,
  Clock,
  KeyRound,
  Loader2,
  Mail,
  XCircle,
} from "lucide-react";
import { cn } from "@/lib/utils";
import ThemeToggle from "@/components/layout/ThemeToggle";
import logo from "@/logo/neuleap_logo.png";
import {
  CandidateSlotApiError,
  candidateSlotsService,
  candidateSlotSession,
  type AvailableSlot,
  type SlotStatus,
} from "@/services/candidateSlots";

type Screen = "loading" | "email" | "code" | "staff" | "picker" | "invalid";

function AuthShell({ children, title }: { children: React.ReactNode; title: string }) {
  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-background px-4">
      <div className="gradient-mesh pointer-events-none absolute inset-0 opacity-70" />
      <div className="absolute right-4 top-4 z-10">
        <ThemeToggle />
      </div>
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
        className="surface-float relative w-full max-w-sm p-8"
      >
        <div className="mb-6 flex flex-col items-center text-center">
          <img src={logo} alt="Talents Scooper" className="h-11 w-11 rounded-xl object-cover" />
          <h1 className="mt-3 text-lg font-semibold tracking-[-0.02em] text-ink">{title}</h1>
          <p className="text-[11px] font-semibold uppercase tracking-[0.08em] text-primary">@NeuLeap.Ai</p>
        </div>
        {children}
      </motion.div>
    </div>
  );
}

const fmtDay = (iso: string) =>
  new Date(iso).toLocaleDateString(undefined, { weekday: "short", day: "2-digit", month: "short" });
const fmtTime = (iso: string) =>
  new Date(iso).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" });
// A pool-scoped round can roster several interviewers, so multiple distinct
// slots (different slot_id) can share the same start time — keying/comparing
// by start alone would make two same-time buttons highlight together.
const slotKey = (s: AvailableSlot) => (s.slot_id != null ? `id:${s.slot_id}` : `t:${s.start}`);

export default function CandidateSchedule() {
  const { token } = useParams<{ token: string }>();
  // The staff-credential option only shows when the link was opened FROM the
  // app (the pool table's "Open" appends ?staff=1) — candidates' emailed
  // links never carry it, so they only ever see the plain code challenge.
  // (The backend endpoint itself is credential+role gated either way.)
  const [searchParams] = useSearchParams();
  const staffHint = searchParams.get("staff") === "1";
  const [screen, setScreen] = useState<Screen>("loading");
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const [email, setEmail] = useState("");
  const [codeRaw, setCodeRaw] = useState("");
  const [remember, setRemember] = useState(false);
  const [busy, setBusy] = useState(false);

  const [sessionToken, setSessionToken] = useState<string | null>(null);
  const [status, setStatus] = useState<SlotStatus | null>(null);

  useEffect(() => {
    if (!token) return;
    const existing = candidateSlotSession.get(token);
    if (!existing) {
      setScreen("email");
      return;
    }
    candidateSlotsService
      .getStatus(token, existing)
      .then((s) => {
        setSessionToken(existing);
        setStatus(s);
        setScreen("picker");
      })
      .catch((e) => {
        candidateSlotSession.clear(token);
        if (e instanceof CandidateSlotApiError && e.status === 404) {
          setErrorMsg(e.message);
          setScreen("invalid");
        } else {
          setScreen("email");
        }
      });
  }, [token]);

  const requestCode = async () => {
    if (!token || !email.trim()) return;
    setBusy(true);
    setErrorMsg(null);
    try {
      await candidateSlotsService.requestCode(token, email.trim());
      setScreen("code");
    } catch (e) {
      setErrorMsg(e instanceof CandidateSlotApiError ? e.message : "Couldn't send the code. Try again.");
    } finally {
      setBusy(false);
    }
  };

  const verifyCode = async () => {
    if (!token || codeRaw.length < 5) return;
    setBusy(true);
    setErrorMsg(null);
    try {
      const res = await candidateSlotsService.verifyCode(token, email.trim(), codeRaw, remember);
      if (res.session_token) {
        setSessionToken(res.session_token);
        if (remember) candidateSlotSession.set(token, res.session_token);
      }
      setStatus(res.status);
      setScreen("picker");
    } catch (e) {
      setErrorMsg(e instanceof CandidateSlotApiError ? e.message : "Verification failed.");
    } finally {
      setBusy(false);
    }
  };

  // Staff (Admin/SysAdmin) path — verify with app credentials instead of the
  // emailed code, so a picker link can be CHECKED without the candidate inbox.
  const [staffUser, setStaffUser] = useState("");
  const [staffPass, setStaffPass] = useState("");
  const staffVerify = async () => {
    if (!token || !staffUser.trim() || !staffPass) return;
    setBusy(true);
    setErrorMsg(null);
    try {
      const res = await candidateSlotsService.staffAccess(token, staffUser.trim(), staffPass);
      if (res.session_token) setSessionToken(res.session_token);
      setStatus(res.status);
      setStaffPass("");
      setScreen("picker");
    } catch (e) {
      setErrorMsg(e instanceof CandidateSlotApiError ? e.message : "Verification failed.");
    } finally {
      setBusy(false);
    }
  };

  if (screen === "loading") {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (screen === "invalid") {
    return (
      <AuthShell title="Interview Scheduling">
        <div className="flex flex-col items-center gap-2 text-center">
          <AlertTriangle className="h-8 w-8 text-amber-500" />
          <p className="text-sm font-semibold text-ink">This link isn't valid</p>
          <p className="text-xs text-ink-mute">{errorMsg ?? "It may have expired or been mistyped."}</p>
        </div>
      </AuthShell>
    );
  }

  if (screen === "email") {
    return (
      <AuthShell title="Pick your interview slot">
        <p className="mb-4 text-center text-xs text-ink-mute">
          Enter the email this invite was sent to, and we'll send you a one-time code.
        </p>
        <div className="space-y-3">
          <div className="relative">
            <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-mute" />
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && requestCode()}
              placeholder="you@example.com"
              className="w-full rounded-xl border border-border bg-secondary/40 py-2.5 pl-9 pr-3 text-sm text-ink outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/30"
            />
          </div>
          {errorMsg && <p className="rounded-lg bg-red-500/10 px-3 py-2 text-xs font-medium text-red-500">{errorMsg}</p>}
          <button
            onClick={requestCode}
            disabled={busy || !email.trim()}
            className="btn-brand w-full disabled:cursor-not-allowed disabled:opacity-60"
          >
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Send me a code"}
          </button>
          {staffHint && (
            <button
              onClick={() => { setScreen("staff"); setErrorMsg(null); }}
              className="w-full text-center text-[11px] text-muted-foreground underline decoration-dotted underline-offset-2 hover:text-foreground"
            >
              Checking this link as staff? Verify with Admin / SysAdmin credentials
            </button>
          )}
        </div>
      </AuthShell>
    );
  }

  if (screen === "staff") {
    return (
      <AuthShell title="Staff access">
        <p className="mb-4 text-center text-xs text-ink-mute">
          Verify with your <span className="font-medium text-ink">Admin / SysAdmin</span> app
          credentials to open this slot-picker link without the candidate's emailed code. The
          visit is recorded in the Actions Audit Log.
        </p>
        <div className="space-y-3">
          <div className="relative">
            <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-mute" />
            <input
              type="email"
              value={staffUser}
              onChange={(e) => setStaffUser(e.target.value)}
              placeholder="you@neuleap.ai"
              className="w-full rounded-xl border border-border bg-secondary/40 py-2.5 pl-9 pr-3 text-sm text-ink outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/30"
            />
          </div>
          <div className="relative">
            <KeyRound className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-mute" />
            <input
              type="password"
              value={staffPass}
              onChange={(e) => setStaffPass(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && staffVerify()}
              placeholder="App password"
              className="w-full rounded-xl border border-border bg-secondary/40 py-2.5 pl-9 pr-3 text-sm text-ink outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/30"
            />
          </div>
          {errorMsg && <p className="rounded-lg bg-red-500/10 px-3 py-2 text-xs font-medium text-red-500">{errorMsg}</p>}
          <button
            onClick={staffVerify}
            disabled={busy || !staffUser.trim() || !staffPass}
            className="btn-brand w-full disabled:cursor-not-allowed disabled:opacity-60"
          >
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Verify & open"}
          </button>
          <button
            onClick={() => { setScreen("email"); setStaffPass(""); setErrorMsg(null); }}
            className="w-full text-center text-[11px] text-muted-foreground hover:text-foreground"
          >
            Back — I'm the candidate, send me a code instead
          </button>
        </div>
      </AuthShell>
    );
  }

  if (screen === "code") {
    return (
      <AuthShell title="Pick your interview slot">
        <p className="mb-4 text-center text-xs text-ink-mute">
          We sent a code to <span className="font-medium text-ink">{email}</span>. It expires in 10 minutes.
        </p>
        <div className="space-y-3">
          <div className="relative">
            <KeyRound className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-mute" />
            <input
              value={codeRaw}
              onChange={(e) => setCodeRaw(e.target.value.toUpperCase().replace(/[^A-Z0-9-]/g, "").slice(0, 9))}
              onKeyDown={(e) => e.key === "Enter" && verifyCode()}
              placeholder="NLi-XXXXX"
              maxLength={9}
              className="w-full rounded-xl border border-border bg-secondary/40 py-2.5 pl-9 pr-3 text-center text-sm font-semibold tracking-[0.2em] text-ink outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/30"
            />
          </div>
          <label className="flex cursor-pointer items-center gap-2 text-xs text-ink-mute">
            <input
              type="checkbox"
              checked={remember}
              onChange={(e) => setRemember(e.target.checked)}
              className="h-3.5 w-3.5 rounded border-border accent-primary"
            />
            Remember this device
          </label>
          {errorMsg && <p className="rounded-lg bg-red-500/10 px-3 py-2 text-xs font-medium text-red-500">{errorMsg}</p>}
          <button
            onClick={verifyCode}
            disabled={busy || codeRaw.replace(/[^0-9]/g, "").length < 5}
            className="btn-brand w-full disabled:cursor-not-allowed disabled:opacity-60"
          >
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Verify"}
          </button>
          <button
            onClick={() => { setScreen("email"); setCodeRaw(""); setErrorMsg(null); }}
            className="w-full text-center text-[11px] text-muted-foreground hover:text-foreground"
          >
            Use a different email
          </button>
        </div>
      </AuthShell>
    );
  }

  if (!token || !status) return null;

  return (
    <SlotPicker
      token={token}
      sessionToken={sessionToken!}
      status={status}
      onStatusChange={setStatus}
    />
  );
}

function SlotPicker({
  token,
  sessionToken,
  status,
  onStatusChange,
}: {
  token: string;
  sessionToken: string;
  status: SlotStatus;
  onStatusChange: (s: SlotStatus) => void;
}) {
  const [slots, setSlots] = useState<AvailableSlot[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<AvailableSlot | null>(null);
  const [booking, setBooking] = useState(false);
  const [remindMeAgain, setRemindMeAgain] = useState(status.remind_me_again);

  const loadSlots = useCallback(() => {
    return candidateSlotsService
      .getSlots(token, sessionToken)
      .then((res) => setSlots(res.slots))
      .catch((e) =>
        setError(e instanceof CandidateSlotApiError ? e.message : "Couldn't load available slots."),
      );
  }, [token, sessionToken]);

  useEffect(() => {
    if (status.booked || status.rejected) return;
    loadSlots();
  }, [loadSlots, status.booked, status.rejected]);

  const grouped = useMemo(() => {
    const byDay = new Map<string, AvailableSlot[]>();
    for (const s of slots ?? []) {
      const key = fmtDay(s.start);
      const arr = byDay.get(key);
      if (arr) arr.push(s);
      else byDay.set(key, [s]);
    }
    return [...byDay.entries()];
  }, [slots]);

  const book = async () => {
    if (!selected) return;
    setBooking(true);
    setError(null);
    try {
      const updated = await candidateSlotsService.bookSlot(
        token, sessionToken, selected.start, selected.end, selected.slot_id
      );
      onStatusChange(updated);
    } catch (e) {
      setError(e instanceof CandidateSlotApiError ? e.message : "Couldn't book that slot — try another.");
      // The chosen time may now have fewer (or zero) parallel placeholders —
      // refresh so the counts/times reflect what's actually still open.
      setSelected(null);
      loadSlots();
    } finally {
      setBooking(false);
    }
  };

  const toggleRemind = async (value: boolean) => {
    setRemindMeAgain(value);
    try {
      await candidateSlotsService.setRemindMeAgain(token, sessionToken, value);
    } catch {
      // non-critical — leave the checkbox as the user set it
    }
  };

  return (
    <div className="min-h-screen bg-background px-4 py-8">
      <div className="mx-auto flex max-w-2xl flex-col gap-4">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <img src={logo} alt="Talents Scooper" className="h-8 w-8 rounded-lg object-cover" />
            <div>
              <p className="text-[10px] font-semibold uppercase tracking-[0.08em] text-primary">
                {status.round_name} — Interview Scheduling
              </p>
              <h1 className="text-lg font-semibold text-foreground">
                {status.is_sample
                  ? "Slot picker preview"
                  : status.candidate_name
                    ? `Hi ${status.candidate_name.split(" ")[0]}`
                    : "Pick your slot"}
              </h1>
              {status.is_sample && (
                <span className="mt-0.5 inline-flex items-center rounded-full border border-amber-500/40 bg-amber-400/10 px-2 py-0.5 text-[10px] font-bold text-amber-600">
                  Test invite — sample candidate, not a real applicant
                </span>
              )}
            </div>
          </div>
          <ThemeToggle />
        </div>

        {status.booked ? (
          <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/5 p-6 text-center">
            <CheckCircle2 className="mx-auto mb-2 h-8 w-8 text-emerald-500" />
            <p className="text-sm font-semibold text-foreground">Your interview is booked</p>
            {status.slot_start && status.slot_end && (
              <p className="mt-1 text-xs text-muted-foreground">
                {fmtDay(status.slot_start)} · {fmtTime(status.slot_start)}–{fmtTime(status.slot_end)}
              </p>
            )}
            <p className="mt-3 text-[11px] text-muted-foreground">
              Please check your inbox/calendar for the invite and meeting joining details. There will
              be no reminder call — please join be on time!
            </p>
          </div>
        ) : status.rejected ? (
          <div className="rounded-xl border border-border bg-card p-6 text-center">
            <XCircle className="mx-auto mb-2 h-8 w-8 text-muted-foreground" />
            <p className="text-sm font-semibold text-foreground">This invite has expired</p>
            <p className="mt-1 text-xs text-muted-foreground">
              No slot was selected within the response window. Reach out to the hiring team if you'd
              still like to be considered.
            </p>
          </div>
        ) : (
          <div className="rounded-xl border border-border bg-card p-5">
            <div className="mb-4 flex items-center gap-2">
              <Calendar className="h-4 w-4 text-muted-foreground" />
              <h2 className="text-sm font-semibold text-foreground">Available Interview slots left ..</h2>
            </div>

            {error && <p className="mb-3 rounded-lg bg-red-500/10 px-3 py-2 text-xs font-medium text-red-500">{error}</p>}

            {!slots ? (
              <div className="flex items-center gap-2 py-6 text-xs text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" /> Loading available slots…
              </div>
            ) : grouped.length === 0 ? (
              <p className="py-6 text-center text-xs text-muted-foreground">
                No open slots right now — check back soon, or use "Remind me again" below.
              </p>
            ) : (
              <div className="max-h-96 space-y-4 overflow-y-auto pr-1">
                {grouped.map(([day, daySlots]) => (
                  <div key={day}>
                    <div className="mb-1.5 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                      {day}
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {daySlots.map((s) => (
                        <button
                          key={slotKey(s)}
                          onClick={() => setSelected(s)}
                          className={cn(
                            "flex items-center gap-1 rounded-lg border px-2.5 py-1.5 text-xs font-medium transition-colors",
                            selected && slotKey(selected) === slotKey(s)
                              ? "border-primary bg-primary/10 text-primary"
                              : "border-border text-foreground hover:border-primary/40 hover:bg-secondary"
                          )}
                        >
                          <Clock className="h-3 w-3" /> {fmtTime(s.start)}
                          {(s.remaining ?? 1) > 1 && (
                            <span
                              className="ml-0.5 rounded-full bg-emerald-500/15 px-1.5 py-px text-[10px] font-semibold tabular-nums text-emerald-600 dark:text-emerald-400"
                              title={`${s.remaining} interviewers open at this time`}
                            >
                              {s.remaining} left
                            </span>
                          )}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}

            <div className="mt-4 flex items-center justify-between gap-3 border-t border-border/60 pt-4">
              <label className="flex cursor-pointer items-center gap-2 text-xs text-muted-foreground">
                <input
                  type="checkbox"
                  checked={remindMeAgain}
                  onChange={(e) => toggleRemind(e.target.checked)}
                  className="h-3.5 w-3.5 rounded border-border accent-primary"
                />
                <Bell className="h-3.5 w-3.5" /> Remind me again
              </label>
              <button
                onClick={book}
                disabled={!selected || booking}
                className="btn-brand disabled:cursor-not-allowed disabled:opacity-50"
              >
                {booking ? <Loader2 className="h-4 w-4 animate-spin" /> : "Confirm the earliest you can make up"}
              </button>
            </div>
            <NeedHelp token={token} sessionToken={sessionToken} />
          </div>
        )}
        {(status.booked || status.rejected) && <NeedHelp token={token} sessionToken={sessionToken} centered />}
      </div>
    </div>
  );
}

/**
 * Deliberately low-key "Need help?" affordance near the main action — opens a
 * tiny message box; the message lands on the candidate's row in the team's
 * status tracking (a red "!") so a recruiter can read it and act.
 */
function NeedHelp({
  token,
  sessionToken,
  centered = false,
}: {
  token: string;
  sessionToken: string;
  centered?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const send = async () => {
    if (message.trim().length < 3) return;
    setBusy(true);
    setErr(null);
    try {
      await candidateSlotsService.sendHelp(token, sessionToken, message.trim());
      setSent(true);
      setOpen(false);
    } catch (e) {
      setErr(e instanceof CandidateSlotApiError ? e.message : "Couldn't send — please try again.");
    } finally {
      setBusy(false);
    }
  };

  if (sent) {
    // Stays available for follow-ups — a booked candidate may need to reach
    // the team more than once (reschedule, joining details, running late…).
    return (
      <div className={cn("mt-3", centered && "text-center")}>
        <p className={cn("text-[11px] text-emerald-600", centered && "text-center")}>
          Message sent — the hiring team has been flagged and will get back to you.
        </p>
        <button
          type="button"
          onClick={() => {
            setSent(false);
            setMessage("");
            setOpen(true);
          }}
          className="mt-1 text-[11px] text-muted-foreground underline decoration-dotted underline-offset-2 transition-colors hover:text-foreground"
        >
          Send another message
        </button>
      </div>
    );
  }
  if (!open) {
    // On the booked/expired views (centered) this is the candidate's ONLY
    // remaining action — a real button, not the low-key dotted link the
    // picker uses next to its primary Confirm button.
    return centered ? (
      <div className="mt-3 text-center">
        <button
          type="button"
          onClick={() => setOpen(true)}
          className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-card px-3.5 py-2 text-xs font-semibold text-foreground transition-colors hover:border-primary/40 hover:bg-secondary"
        >
          Need help? Message the hiring team
        </button>
      </div>
    ) : (
      <div className="mt-3 text-right">
        <button
          type="button"
          onClick={() => setOpen(true)}
          className="text-[11px] text-muted-foreground underline decoration-dotted underline-offset-2 transition-colors hover:text-foreground"
        >
          Need help?
        </button>
      </div>
    );
  }
  return (
    <div className="mt-3 rounded-lg border border-border bg-secondary/30 p-3">
      <p className="mb-1.5 text-[11px] text-muted-foreground">
        Tell us what's blocking you (timing, the slots offered, anything else) — the hiring team
        will see it against your application and follow up.
      </p>
      <textarea
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        rows={3}
        autoFocus
        placeholder="Type your message…"
        className="w-full resize-none rounded-lg border border-border bg-background px-2.5 py-1.5 text-xs text-foreground outline-none focus:border-primary/50"
      />
      {err && <p className="mt-1 text-[11px] text-red-500">{err}</p>}
      <div className="mt-2 flex justify-end gap-2">
        <button
          type="button"
          onClick={() => setOpen(false)}
          disabled={busy}
          className="rounded-lg border border-border px-2.5 py-1.5 text-[11px] font-semibold text-foreground transition-colors hover:bg-secondary disabled:opacity-40"
        >
          Cancel
        </button>
        <button
          type="button"
          onClick={send}
          disabled={busy || message.trim().length < 3}
          className="rounded-lg bg-primary px-2.5 py-1.5 text-[11px] font-semibold text-white transition-colors hover:bg-primary/90 disabled:opacity-40"
        >
          {busy ? <Loader2 className="h-3 w-3 animate-spin" /> : "Send message"}
        </button>
      </div>
    </div>
  );
}
