import { useEffect, useMemo, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  Settings2,
  Bell,
  Tag,
  Clock,
  RefreshCw,
  Archive,
  Mail,
  Award,
  Save,
  Users2,
  UserPlus,
  Trash2,
  ShieldCheck,
  ShieldAlert,
  Loader2,
  MessageSquare,
  Link2,
  LayoutGrid,
  Globe,
  RotateCcw,
  Search,
  ExternalLink,
  Copy,
  Check,
  KeyRound,
  Plus,
  X,
  CalendarClock,
  Send,
} from "lucide-react";
import { cn, apiErrorMessage } from "@/lib/utils";
import {
  settingsService,
  type InterviewerDomainEntry,
  type SampleInterviewLinks as SampleInterviewLinksType,
  type RoundTypeEntry,
  type InterviewSchedulingSettings as InterviewSchedulingSettingsType,
  type EmailSendSettings,
} from "@/services/settings";
import { authService, type ManagedUser, type UserRole } from "@/services/auth";
import { useAuth } from "@/context/AuthContext";
import PageHeader from "@/components/layout/PageHeader";
import PageContainer from "@/components/layout/PageContainer";
import ConfirmDialog from "@/components/common/ConfirmDialog";
import { useConfirm } from "@/components/common/ConfirmProvider";
import ExtractionAnalysisCard from "@/components/settings/ExtractionAnalysisCard";
import LegacyFeaturesCard from "@/components/settings/LegacyFeaturesCard";
import FeedbackReportsCard from "@/components/settings/FeedbackReportsCard";
import CollapsibleSection from "@/components/settings/CollapsibleSection";
import LlmKeysCard from "@/components/settings/LlmKeysCard";
import GraphApiCard from "@/components/settings/GraphApiCard";
import BackupCard from "@/components/settings/BackupCard";
import UpgradeCard from "@/components/settings/UpgradeCard";
import ReferralConfigCard from "@/components/settings/ReferralConfigCard";
import InterviewQuestionGenerationCard from "@/components/settings/InterviewQuestionGenerationCard";
import { findBestSectionMatch, findSectionMatches, focusSection } from "@/components/settings/sectionRegistry";

export function SectionHeader({ icon: Icon, title, desc }: { icon: React.ElementType; title: string; desc: string }) {
  return (
    <div className="flex items-start gap-3 mb-4">
      <div className="w-8 h-8 rounded-lg bg-secondary flex items-center justify-center shrink-0">
        <Icon className="h-4 w-4 text-muted-foreground" />
      </div>
      <div>
        <div className="text-sm font-semibold text-foreground">{title}</div>
        <div className="text-xs text-muted-foreground">{desc}</div>
      </div>
    </div>
  );
}

export function SettingRow({
  label,
  description,
  children,
}: {
  label: string;
  description?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between gap-4 py-3 border-b border-border/50 last:border-0">
      <div className="flex-1 min-w-0">
        <div className="text-xs font-medium text-foreground">{label}</div>
        {description && <div className="text-[10px] text-muted-foreground mt-0.5">{description}</div>}
      </div>
      {children}
    </div>
  );
}

export function Toggle({ value, onChange }: { value: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!value)}
      className={cn(
        "relative inline-flex h-5 w-9 items-center rounded-full transition-colors shrink-0",
        value ? "bg-primary" : "bg-secondary"
      )}
    >
      <span
        className={cn(
          "inline-block h-3.5 w-3.5 transform rounded-full bg-white shadow transition-transform",
          value ? "translate-x-4" : "translate-x-1"
        )}
      />
    </button>
  );
}

export function NumericInput({ value, onChange, min, max, step = 1 }: {
  value: number;
  onChange: (v: number) => void;
  min?: number;
  max?: number;
  step?: number;
}) {
  // Clamp to [min, max] on blur so a typed-in out-of-range value is corrected — the
  // HTML min/max attributes only validate, they don't stop the user typing 0 or 999.
  const clamp = (n: number) => {
    if (Number.isNaN(n)) return min ?? 0;
    if (min != null && n < min) return min;
    if (max != null && n > max) return max;
    return n;
  };
  return (
    <input
      type="number"
      value={value}
      onChange={(e) => onChange(Number(e.target.value))}
      onBlur={(e) => onChange(clamp(Number(e.target.value)))}
      min={min}
      max={max}
      step={step}
      className="w-20 px-2 py-1.5 text-xs rounded-lg border border-border bg-secondary text-foreground focus:outline-none focus:border-primary/50 text-right"
    />
  );
}

const STREAM_KEYWORDS: Record<string, string[]> = {
  GenAI: ["LLM", "GPT", "RAG", "LangChain", "fine-tune", "prompt", "generative", "agentic", "AutoGen", "machine learning", "deep learning", "PyTorch", "TensorFlow", "scikit-learn", "neural network", "classification", "computer vision", "NLP", "data science"],
  "Data Eng": ["Spark", "Kafka", "Airflow", "dbt", "ETL", "pipeline", "Snowflake", "Redshift", "BigQuery"],
  "Not Relevant": [],
};

// Fallback cert-filter tags until /settings/scoring loads (mirrors the backend default).
const CERT_TAGS: string[] = ["AWS", "Google", "Microsoft", "Databricks", "Snowflake", "Coursera"];

// ── Certificate tag input restrictions ───────────────────────────────────────
// Tags are kept exactly as typed (casing is cosmetic — filtering is case-insensitive),
// but must be clean: bounded length/words, single spaces, and a safe character set
// that still covers real names (C++, .NET, AI/ML, R&D).
const CERT_TAG_MAX_LEN = 24;
const CERT_TAG_MIN_LEN = 2;
const CERT_TAG_MAX_WORDS = 4;
const CERT_TAG_ALLOWED = /^[A-Za-z0-9 +#.&/-]+$/;

type TagResult = { ok: true; value: string } | { ok: false; error: string };

function validateCertTag(raw: string, existing: string[]): TagResult {
  // Spacing limit: trim ends + collapse any run of whitespace to a single space.
  const value = raw.trim().replace(/\s+/g, " ");
  if (!value) return { ok: false, error: "Enter a tag." };
  if (value.length < CERT_TAG_MIN_LEN)
    return { ok: false, error: `At least ${CERT_TAG_MIN_LEN} characters.` };
  if (value.length > CERT_TAG_MAX_LEN)
    return { ok: false, error: `Max ${CERT_TAG_MAX_LEN} characters.` };
  if (value.split(" ").length > CERT_TAG_MAX_WORDS)
    return { ok: false, error: `Max ${CERT_TAG_MAX_WORDS} words.` };
  if (!CERT_TAG_ALLOWED.test(value))
    return { ok: false, error: "Only letters, numbers, spaces and + # . & / -" };
  if (existing.some((t) => t.toLowerCase() === value.toLowerCase()))
    return { ok: false, error: "Tag already added." };
  return { ok: true, value };
}

// ── User Management (Admin / System Admin only) ──────────────────────────────
// Add/remove SPA login accounts. The "recruiter" role is the Recruitment Manager:
// full access EXCEPT the manual Next Best Action override (Admin only, enforced
// server-side) and Settings (Admin/System Admin only, also server-side). Rendered
// only when canAccessBackoffice; the API 403s a Recruiter regardless.
const ROLE_LABEL: Record<UserRole, string> = {
  admin: "Admin",
  recruiter: "Recruitment Manager",
  sysadmin: "System Admin",
};

function UserManagementCard() {
  const confirm = useConfirm();
  const { isAdmin } = useAuth();
  const [users, setUsers] = useState<ManagedUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [email, setEmail] = useState("");
  const [role, setRole] = useState<UserRole>("recruiter");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  // Fallback shown when the invite email couldn't be delivered (no mail config)
  // but a link could still be built — the admin relays it manually.
  const [inviteLink, setInviteLink] = useState<{ email: string; link: string } | null>(null);
  // Inline-validation display gates (don't flag an empty form the user hasn't
  // touched yet) + the confirm-before-add popup.
  const [emailTouched, setEmailTouched] = useState(false);
  const [confirmAddOpen, setConfirmAddOpen] = useState(false);
  // Admin password reset — the generated password is shown exactly once,
  // right in the card, with a copy button (it's never retrievable again).
  const [resetBusyId, setResetBusyId] = useState<number | null>(null);
  const [resetResult, setResetResult] = useState<{ email: string; password: string } | null>(null);
  const [resetCopied, setResetCopied] = useState(false);

  const load = () => {
    setLoading(true);
    authService
      .listUsers()
      .then(setUsers)
      .catch(() => setError("Couldn't load users."))
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  // ── Live, in-page validation — the fields validate as you type (once
  // touched), the Add button stays disabled until everything passes, and a
  // valid entry is then confirmed in a popup before the account is created.
  const emailTrimmed = email.trim();
  const emailValid = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(emailTrimmed);
  const emailTaken = users.some(
    (u) => u.email.trim().toLowerCase() === emailTrimmed.toLowerCase()
  );
  // New accounts are created by EMAIL INVITE — the member gets a link to set
  // their own initial password, which guarantees a valid, reachable email. No
  // admin-typed password, so only the email needs to be valid.
  const emailIssue = !emailTrimmed
    ? "Email is required."
    : !emailValid
      ? "That doesn't look like a valid email address."
      : emailTaken
        ? "A user with this email already exists."
        : null;
  const formValid = !emailIssue;

  const confirmAdd = async () => {
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const created = await authService.createUser(emailTrimmed, role);
      setConfirmAddOpen(false);
      setEmail("");
      setRole("recruiter");
      setEmailTouched(false);
      if (created.invite_sent) {
        setNotice(`Invited ${emailTrimmed} — an email with a link to set their password is on the way.`);
      } else if (created.invite_link) {
        // Email delivery isn't configured — hand the admin the link to relay.
        setInviteLink({ email: emailTrimmed, link: created.invite_link });
        setNotice(null);
      } else {
        setNotice(`Created ${emailTrimmed}, but the invite email couldn't be sent and no public URL is configured — use "Reset password" to hand over a credential.`);
      }
      load();
    } catch (e: unknown) {
      setConfirmAddOpen(false);
      setError(apiErrorMessage(e, "Couldn't create the user."));
    } finally {
      setBusy(false);
      setTimeout(() => setNotice(null), 6000);
    }
  };

  const requestAdd = () => {
    setEmailTouched(true);
    if (!formValid) return;
    setError(null);
    setConfirmAddOpen(true);
  };

  // The system must never lose its last Admin — the backend refuses it too
  // (400), but the UI blocks it up front so the delete control on that row
  // reads as unavailable instead of failing after a confirm.
  const activeAdminCount = users.filter((u) => u.role === "admin" && u.is_active).length;
  const isLastAdmin = (u: ManagedUser) =>
    u.role === "admin" && u.is_active && activeAdminCount <= 1;

  const removeUser = async (u: ManagedUser) => {
    if (isLastAdmin(u)) {
      setError(
        "The system must always keep at least one Admin — add another Admin account before removing this one."
      );
      return;
    }
    if (!(await confirm({ title: "Remove user?", message: `Remove ${u.email}? They will no longer be able to sign in.`, confirmLabel: "Remove", danger: true }))) return;
    setError(null);
    try {
      await authService.deleteUser(u.id);
      setUsers((prev) => prev.filter((x) => x.id !== u.id));
    } catch (e: unknown) {
      setError(apiErrorMessage(e, "Couldn't remove the user."));
    }
  };

  const resetPassword = async (u: ManagedUser) => {
    if (
      !(await confirm({
        title: "Reset password?",
        message:
          `Reset ${u.email}'s password? A new one is generated for you to hand over — ` +
          `they'll be required to change it on their next sign-in.`,
        confirmLabel: "Reset",
        danger: true,
      }))
    )
      return;
    setError(null);
    setResetResult(null);
    setResetCopied(false);
    setResetBusyId(u.id);
    try {
      setResetResult(await authService.resetUserPassword(u.id));
      load(); // must_change_password flag now shows on the row
    } catch (e: unknown) {
      setError(apiErrorMessage(e, "Couldn't reset the password."));
    } finally {
      setResetBusyId(null);
    }
  };

  const copyResetPassword = async () => {
    if (!resetResult) return;
    try {
      await navigator.clipboard.writeText(resetResult.password);
      setResetCopied(true);
      setTimeout(() => setResetCopied(false), 1500);
    } catch {
      /* clipboard denied — the value is still visible to copy by hand */
    }
  };

  return (
    <CollapsibleSection
      id="user-management"
      icon={Users2}
      title="User Management"
      desc="Add or remove login accounts and set each one's role"
      colSpan="lg:col-span-2"
    >
      {/* Add-user form — validates live as you type; Add stays disabled until
          both fields pass, then a confirmation popup gates the actual create. */}
      <div className="rounded-lg border border-border bg-secondary/30 p-3 mb-4">
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-[1fr_auto_auto] sm:items-start">
          <div>
            <input
              type="email"
              value={email}
              onChange={(e) => { setEmail(e.target.value); if (error) setError(null); }}
              onBlur={() => setEmailTouched(true)}
              onKeyDown={(e) => e.key === "Enter" && requestAdd()}
              placeholder="new.user@neuleap.ai"
              className={cn(
                "w-full px-2 py-1.5 text-xs rounded-lg border bg-secondary text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50",
                emailTouched && emailIssue
                  ? "border-destructive/60"
                  : emailTrimmed && !emailIssue
                    ? "border-emerald-500/50"
                    : "border-border"
              )}
            />
            {emailTouched && emailIssue && (
              <p className="mt-1 text-[10px] text-destructive">{emailIssue}</p>
            )}
          </div>
          <select
            value={role}
            onChange={(e) => setRole(e.target.value as UserRole)}
            className="px-2 py-1.5 text-xs rounded-lg border border-border bg-secondary text-foreground focus:outline-none focus:border-primary/50"
          >
            <option value="recruiter">Recruitment Manager</option>
            <option value="admin">Admin</option>
            <option value="sysadmin">System Admin</option>
          </select>
          <button
            onClick={requestAdd}
            disabled={busy || (emailTouched && !formValid)}
            title={formValid ? "Review & invite this user" : "Fix the highlighted field first"}
            className="inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-semibold hover:bg-primary/90 disabled:opacity-50 transition-colors"
          >
            <UserPlus className="h-3.5 w-3.5" />
            {busy ? "Inviting…" : "Invite user"}
          </button>
        </div>
        {error ? (
          <p className="mt-2 text-[10px] text-red-400">{error}</p>
        ) : notice ? (
          <p className="mt-2 text-[10px] text-emerald-500">{notice}</p>
        ) : (
          <p className="mt-2 text-[10px] text-muted-foreground">
            Recruitment Managers can do everything except the manual Next Best Action override.
            New users are emailed a link to set their own password — so the account is tied to a valid email.
          </p>
        )}
        {inviteLink && (
          <div className="mt-2 rounded-lg border border-amber-500/40 bg-amber-500/5 p-2">
            <p className="text-[10px] font-semibold text-amber-600 dark:text-amber-400">
              Invite email couldn't be sent — share this set-password link with {inviteLink.email}:
            </p>
            <div className="mt-1 flex items-center gap-2">
              <code className="min-w-0 flex-1 truncate rounded bg-secondary px-1.5 py-1 text-[10px] text-foreground">
                {inviteLink.link}
              </code>
              <button
                onClick={() => navigator.clipboard?.writeText(inviteLink.link)}
                className="shrink-0 rounded-lg border border-border px-2 py-1 text-[10px] font-medium text-muted-foreground hover:text-primary"
              >
                Copy
              </button>
              <button
                onClick={() => setInviteLink(null)}
                className="shrink-0 rounded-lg px-1.5 py-1 text-[10px] text-muted-foreground hover:text-foreground"
              >
                Dismiss
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Valid entry → explicit confirmation before the account is created. */}
      <ConfirmDialog
        open={confirmAddOpen}
        title="Invite this user?"
        message={
          <>
            <span className="font-semibold text-foreground">{emailTrimmed}</span> will be added as{" "}
            <span className="font-semibold text-foreground">{ROLE_LABEL[role]}</span> and emailed a
            link to set their own password. The account can't be signed into until they do.
          </>
        }
        confirmLabel="Invite user"
        pendingLabel="Inviting…"
        pending={busy}
        onCancel={() => setConfirmAddOpen(false)}
        onConfirm={confirmAdd}
      />

      {/* User list */}
      {loading ? (
        <div className="flex items-center gap-2 py-6 text-xs text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading users…
        </div>
      ) : (
        <div className="space-y-1.5">
          {users.map((u) => (
            <div
              key={u.id}
              className="flex items-center justify-between gap-3 rounded-lg border border-border/60 bg-secondary/20 px-3 py-2"
            >
              <div className="min-w-0">
                <div className="truncate text-xs font-medium text-foreground">{u.email}</div>
                <div className="text-[10px] text-muted-foreground">
                  {u.name}
                  {u.must_change_password && (
                    <span className="ml-1.5 rounded-full border border-amber-500/30 bg-amber-400/10 px-1.5 py-px text-[9px] font-semibold text-amber-600">
                      must change password
                    </span>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <span
                  className={cn(
                    "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-semibold",
                    u.role === "admin"
                      ? "bg-primary/10 text-primary border border-primary/20"
                      : u.role === "sysadmin"
                        ? "bg-violet-500/10 text-violet-600 border border-violet-500/20"
                        : "bg-secondary text-muted-foreground border border-border"
                  )}
                >
                  {(u.role === "admin" || u.role === "sysadmin") && <ShieldCheck className="h-3 w-3" />}
                  {ROLE_LABEL[u.role]}
                </span>
                {isAdmin && (
                  <button
                    onClick={() => resetPassword(u)}
                    disabled={resetBusyId !== null}
                    title="Reset password — generates a new one for you to hand over; they must change it on next sign-in"
                    className="rounded-lg p-1.5 text-muted-foreground hover:bg-amber-500/10 hover:text-amber-500 transition-colors disabled:opacity-40"
                  >
                    {resetBusyId === u.id ? (
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    ) : (
                      <KeyRound className="h-3.5 w-3.5" />
                    )}
                  </button>
                )}
                <button
                  onClick={() => removeUser(u)}
                  disabled={isLastAdmin(u)}
                  title={
                    isLastAdmin(u)
                      ? "The system must always keep at least one Admin — add another Admin before removing this one"
                      : "Remove user"
                  }
                  className="rounded-lg p-1.5 text-muted-foreground hover:bg-red-500/10 hover:text-red-400 transition-colors disabled:cursor-not-allowed disabled:opacity-30 disabled:hover:bg-transparent disabled:hover:text-muted-foreground"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          ))}
          {users.length === 0 && (
            <p className="py-4 text-center text-[11px] text-muted-foreground">No users yet.</p>
          )}
        </div>
      )}

      {/* Freshly reset password — shown exactly once; it's never retrievable
          again (only the hash is stored). */}
      {resetResult && (
        <div className="mt-3 rounded-lg border border-amber-500/30 bg-amber-400/10 p-3">
          <p className="text-[11px] text-foreground">
            New password for <span className="font-semibold">{resetResult.email}</span> — copy it
            now and hand it over; it can't be shown again. They'll be asked to change it on their
            next sign-in.
          </p>
          <div className="mt-2 flex items-center gap-2">
            <code className="selectable rounded-md border border-border bg-background px-2.5 py-1.5 text-xs font-semibold tracking-wide text-foreground">
              {resetResult.password}
            </code>
            <button
              type="button"
              onClick={copyResetPassword}
              className="inline-flex items-center gap-1 rounded-lg border border-border px-2 py-1.5 text-[11px] font-semibold text-foreground transition-colors hover:bg-secondary"
            >
              {resetCopied ? <Check className="h-3 w-3 text-emerald-500" /> : <Copy className="h-3 w-3" />}
              {resetCopied ? "Copied" : "Copy"}
            </button>
            <button
              type="button"
              onClick={() => setResetResult(null)}
              className="ml-auto rounded-lg px-2 py-1.5 text-[11px] text-muted-foreground transition-colors hover:text-foreground"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

    </CollapsibleSection>
  );
}

// "Recruiters can apply predicted NBA" moved to Mailbox → Batch Archive
// (per-source-tag, not a single global toggle) — see BatchArchivePanel.tsx.

// ── Interviewer Access (Admin / System Admin only) ───────────────────────────
// Email-domain allow-list + remember-me duration for the external, no-login
// interviewer surface (/interview/:token — see app.api.interviewer). Self-
// contained and instant-apply (like User Management above) rather than
// bundled into the page's big "Save changes" flow: every add/remove/toggle
// writes the full domain list straight back via PUT, and "Revoke sessions" is
// a one-off action with its own confirmation, not something you'd want
// silently queued behind an unrelated pipeline-settings edit.
// Auto-send + draft-review-required — governs whether email drafts (NBA
// ack-emails, pool-slot invites) go out with a recruiter's eyes on them
// first. Turning draft review OFF is the one setting on this whole page
// gated behind re-entering your own password — see the modal below.
// Actions on this card that require re-entering the acting System Admin's
// own password before they take effect — both flip a switch that lets real
// candidate emails start leaving the system with less (or no) human check.
type ReauthAction = "enable-auto-send" | "disable-draft-review";

const REAUTH_COPY: Record<ReauthAction, { title: string; body: string; confirmLabel: string }> = {
  "enable-auto-send": {
    title: "This lets candidate emails start sending",
    body:
      "Once on, marking a draft “ready to send” will prompt an immediate send-confirmation " +
      "instead of just saving it — recruiters can confirm a real send from right inside the draft " +
      "review modal. Confirm with your own System Admin password to proceed.",
    confirmLabel: "Turn on auto-send",
  },
  "disable-draft-review": {
    title: "This turns off every review step",
    body:
      "Candidate emails will go out the instant they're generated — nobody checks the subject, " +
      "body, or recipient first. The full detail still lands in the Actions Audit Log, but there's " +
      "no stopping a bad draft before it sends. Confirm with your own System Admin password to proceed.",
    confirmLabel: "Turn off draft review",
  },
};

function EmailSendControlsCard() {
  const { user } = useAuth();
  const [cfg, setCfg] = useState<EmailSendSettings | null>(null);
  const [schedulingCfg, setSchedulingCfg] = useState<InterviewSchedulingSettingsType | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [reauthAction, setReauthAction] = useState<ReauthAction | null>(null);
  const [password, setPassword] = useState("");
  const [reauthError, setReauthError] = useState<string | null>(null);
  const [reauthBusy, setReauthBusy] = useState(false);

  useEffect(() => {
    settingsService.getEmailSendConfig().then(({ data }) => setCfg(data)).catch(() => setError("Couldn't load email send settings."));
    settingsService.getInterviewScheduling().then(({ data }) => setSchedulingCfg(data)).catch(() => {});
  }, []);

  const persist = async (next: EmailSendSettings) => {
    setCfg(next);
    setSaving(true);
    setError(null);
    try {
      const { data } = await settingsService.saveEmailSendConfig(next);
      setCfg(data);
    } catch (e: unknown) {
      const detail = (e as { response?: { data?: { detail?: string } } })?.response?.data?.detail;
      setError(detail ?? "Couldn't save — try again.");
    } finally {
      setSaving(false);
    }
  };

  const persistScheduling = async (next: InterviewSchedulingSettingsType) => {
    setSchedulingCfg(next);
    setSaving(true);
    setError(null);
    try {
      const { data } = await settingsService.saveInterviewScheduling(next);
      setSchedulingCfg(data);
    } catch {
      setError("Couldn't save — try again.");
    } finally {
      setSaving(false);
    }
  };

  const closeReauth = () => { setReauthAction(null); setPassword(""); setReauthError(null); };

  const confirmReauth = async () => {
    if (!user || !reauthAction) return;
    setReauthBusy(true);
    setReauthError(null);
    try {
      const { data } =
        reauthAction === "enable-auto-send"
          ? await settingsService.enableAutoSend(user.email, password)
          : await settingsService.disableDraftReview(user.email, password);
      setCfg(data);
      closeReauth();
    } catch (e: unknown) {
      const detail = (e as { response?: { data?: { detail?: string } } })?.response?.data?.detail;
      setReauthError(detail ?? "Couldn't verify — try again.");
    } finally {
      setReauthBusy(false);
    }
  };

  if (!cfg) {
    return (
      <CollapsibleSection
        id="email-send-controls"
        icon={Send}
        title="Email Send Controls"
        desc="Auto-send + draft review for candidate emails"
        colSpan="lg:col-span-2"
      >
        <div className="flex items-center gap-2 py-4 text-xs text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading…
        </div>
      </CollapsibleSection>
    );
  }

  return (
    <CollapsibleSection
      id="email-send-controls"
      icon={Send}
      title="Email Send Controls"
      desc="Every automatic candidate email this app can send — round slot invites and NBA ack-email drafts — in one place"
      colSpan="lg:col-span-2"
    >
      <div className="mb-1 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
        Round slot invites
      </div>
      <SettingRow
        label="Auto-send round slot invites"
        description="OFF by default — until enabled, advancing a candidate to a new round never emails them a real slot invite"
      >
        {schedulingCfg ? (
          <Toggle
            value={schedulingCfg.auto_invite_enabled}
            onChange={(v) => void persistScheduling({ ...schedulingCfg, auto_invite_enabled: v })}
          />
        ) : (
          <Loader2 className="h-3.5 w-3.5 animate-spin text-muted-foreground" />
        )}
      </SettingRow>

      <div className="mb-1 mt-4 border-t border-border/60 pt-4 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
        Draft emails (NBA ack-emails, pool-slot invites)
      </div>
      <SettingRow
        label="Auto-send"
        description="Lets 'Mark ready to send' prompt an immediate send-confirmation instead of just saving the draft"
      >
        <Toggle
          value={cfg.auto_send_enabled}
          onChange={(v) => {
            if (!v) void persist({ ...cfg, auto_send_enabled: false });
            else setReauthAction("enable-auto-send");
          }}
        />
      </SettingRow>
      <SettingRow
        label="Draft review required"
        description={
          cfg.draft_review_required
            ? "Every draft is reviewed by a recruiter before it sends"
            : "OFF — drafts send the instant they're created, no recruiter ever sees them first"
        }
      >
        <Toggle
          value={cfg.draft_review_required}
          onChange={(v) => {
            if (v) void persist({ ...cfg, draft_review_required: true });
            else setReauthAction("disable-draft-review");
          }}
        />
      </SettingRow>
      {!cfg.auto_send_enabled && (
        <p className="mt-2 text-[10px] text-muted-foreground">Turn on Auto-send before draft review can be turned off.</p>
      )}
      {saving && <p className="mt-2 flex items-center gap-1.5 text-[10px] text-muted-foreground"><Loader2 className="h-3 w-3 animate-spin" /> Saving…</p>}
      {error && <p className="mt-2 text-[10px] text-red-400">{error}</p>}

      {reauthAction && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/40 p-4 backdrop-blur-sm"
          onClick={closeReauth}
        >
          <div className="w-full max-w-sm rounded-2xl border border-border bg-card p-5 shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-start gap-3">
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-rose-500/10 text-rose-600">
                <ShieldAlert className="h-4.5 w-4.5" />
              </span>
              <div className="min-w-0">
                <h3 className="text-sm font-bold text-foreground">{REAUTH_COPY[reauthAction].title}</h3>
                <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                  {REAUTH_COPY[reauthAction].body}
                </p>
              </div>
            </div>
            <div className="mt-3 space-y-2">
              <div className="rounded-lg border border-border bg-secondary px-2.5 py-1.5 text-xs text-muted-foreground">
                {user?.email}
              </div>
              <input
                type="password"
                autoFocus
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && password && confirmReauth()}
                placeholder="Your password"
                className="w-full rounded-lg border border-border bg-secondary px-2.5 py-1.5 text-xs text-foreground placeholder:text-muted-foreground focus:border-rose-500/50 focus:outline-none"
              />
            </div>
            {reauthError && <p className="mt-2 text-[11px] text-red-500">{reauthError}</p>}
            <div className="mt-5 flex justify-end gap-2">
              <button
                type="button"
                onClick={closeReauth}
                className="rounded-lg border border-border px-3.5 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-secondary"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmReauth}
                disabled={!password || reauthBusy}
                className="inline-flex items-center gap-1.5 rounded-lg bg-rose-600 px-3.5 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-rose-700 disabled:opacity-40"
              >
                {reauthBusy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <ShieldAlert className="h-3.5 w-3.5" />}
                {REAUTH_COPY[reauthAction].confirmLabel}
              </button>
            </div>
          </div>
        </div>
      )}
    </CollapsibleSection>
  );
}

function InterviewerAccessCard() {
  const confirm = useConfirm();
  const [domains, setDomains] = useState<InterviewerDomainEntry[]>([]);
  const [rememberDays, setRememberDays] = useState(11);
  const [newDomain, setNewDomain] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [revoking, setRevoking] = useState<string | null>(null);

  const load = () => {
    setLoading(true);
    settingsService
      .getInterviewerAccess()
      .then(({ data }) => {
        setDomains(data.domains);
        setRememberDays(data.remember_days);
      })
      .catch(() => setError("Couldn't load interviewer access settings."))
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  const persist = async (next: InterviewerDomainEntry[], days = rememberDays) => {
    setSaving(true);
    setError(null);
    try {
      const { data } = await settingsService.saveInterviewerAccess({ domains: next, remember_days: days });
      setDomains(data.domains);
      setRememberDays(data.remember_days);
    } catch {
      setError("Couldn't save — try again.");
    } finally {
      setSaving(false);
    }
  };

  const addDomain = () => {
    const value = newDomain.trim().toLowerCase().replace(/^@+/, "");
    if (!value) return;
    if (domains.some((d) => d.domain === value)) {
      setError("That domain is already listed.");
      return;
    }
    setNewDomain("");
    void persist([...domains, { domain: value, allowed: true }]);
  };

  const toggleDomain = (domain: string) => {
    void persist(domains.map((d) => (d.domain === domain ? { ...d, allowed: !d.allowed } : d)));
  };

  const removeDomain = (domain: string) => {
    void persist(domains.filter((d) => d.domain !== domain));
  };

  const revoke = async (domain: string) => {
    if (!(await confirm({ title: "Revoke sessions?", message: `Revoke every remembered session for @${domain}? Interviewers from this domain will need a new code to get back in.`, confirmLabel: "Revoke", danger: true }))) return;
    setRevoking(domain);
    setNotice(null);
    try {
      const { data } = await settingsService.revokeInterviewerDomain(domain);
      setNotice(`${data.sessions_revoked} session(s) revoked for @${domain}`);
    } catch {
      setError("Couldn't revoke sessions — try again.");
    } finally {
      setRevoking(null);
      setTimeout(() => setNotice(null), 4000);
    }
  };

  return (
    <CollapsibleSection
      id="interviewer-access"
      icon={Globe}
      title="Interviewer Access"
      desc="Which email domains external interviewers can verify with, and how long a device is remembered"
      colSpan="lg:col-span-2"
    >
      <div className="rounded-lg border border-border bg-secondary/30 p-3 mb-4">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
          <input
            value={newDomain}
            onChange={(e) => { setNewDomain(e.target.value); if (error) setError(null); }}
            onKeyDown={(e) => e.key === "Enter" && addDomain()}
            placeholder="neuleap.ai"
            className="flex-1 px-2 py-1.5 text-xs rounded-lg border border-border bg-secondary text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50"
          />
          <button
            onClick={addDomain}
            disabled={saving || !newDomain.trim()}
            className="inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-semibold hover:bg-primary/90 disabled:opacity-50 transition-colors shrink-0"
          >
            <Globe className="h-3.5 w-3.5" />
            Add domain
          </button>
        </div>
        {error ? (
          <p className="mt-2 text-[10px] text-red-400">{error}</p>
        ) : notice ? (
          <p className="mt-2 text-[10px] text-emerald-500">{notice}</p>
        ) : (
          <p className="mt-2 text-[10px] text-muted-foreground">
            Only interviewers with a work email on an allowed domain can request an access code.
          </p>
        )}
      </div>

      {loading ? (
        <div className="flex items-center gap-2 py-6 text-xs text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading…
        </div>
      ) : (
        <div className="space-y-1.5 mb-4">
          {domains.map((d) => (
            <div
              key={d.domain}
              className="flex items-center justify-between gap-3 rounded-lg border border-border/60 bg-secondary/20 px-3 py-2"
            >
              <div className="flex min-w-0 items-center gap-2">
                <span
                  className={cn(
                    "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-semibold border shrink-0",
                    d.allowed
                      ? "bg-emerald-500/10 text-emerald-600 border-emerald-500/20"
                      : "bg-secondary text-muted-foreground border-border"
                  )}
                >
                  {d.allowed ? "Allowed" : "Blocked"}
                </span>
                <span className="truncate text-xs font-medium text-foreground">@{d.domain}</span>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => revoke(d.domain)}
                  disabled={revoking === d.domain}
                  title="Revoke all remembered sessions for this domain"
                  className="flex items-center gap-1 rounded-lg px-2 py-1 text-[10px] font-semibold text-muted-foreground hover:bg-amber-500/10 hover:text-amber-600 transition-colors disabled:opacity-50"
                >
                  {revoking === d.domain ? <Loader2 className="h-3 w-3 animate-spin" /> : <RotateCcw className="h-3 w-3" />}
                  Revoke sessions
                </button>
                <Toggle value={d.allowed} onChange={() => toggleDomain(d.domain)} />
                <button
                  onClick={() => removeDomain(d.domain)}
                  title="Remove domain"
                  className="rounded-lg p-1.5 text-muted-foreground hover:bg-red-500/10 hover:text-red-400 transition-colors"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          ))}
          {domains.length === 0 && (
            <p className="py-4 text-center text-[11px] text-muted-foreground">
              No domains allowed yet — interviewer links can't be verified until one is added.
            </p>
          )}
        </div>
      )}

      <SettingRow
        label="Remember device for"
        description="How long a verified interviewer skips the code challenge on return visits (days)"
      >
        <div className="flex items-center gap-2">
          <NumericInput
            value={rememberDays}
            onChange={(v) => { setRememberDays(v); void persist(domains, v); }}
            min={1}
            max={90}
          />
          {saving && <Loader2 className="h-3.5 w-3.5 animate-spin text-muted-foreground" />}
        </div>
      </SettingRow>

      <SampleInterviewLinkRow />
    </CollapsibleSection>
  );
}

// Per-round-type interviewer roster (Screening/Round 1/Round 2/Final/HR/Joining
// FollowUp/Onboarding + any admin-added custom stages). This is what the
// candidate slot-selection flow reads to know whose calendar to check at each
// stage — for now every lookup is redirected to the QA stand-in mailbox
// configured below regardless of which interviewer is rostered here, but the
// roster is already stage-accurate so that redirect can be lifted later.
function RoundInterviewersCard() {
  const confirm = useConfirm();
  const [roundTypes, setRoundTypes] = useState<RoundTypeEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [newType, setNewType] = useState("");
  const [drafts, setDrafts] = useState<Record<string, { name: string; email: string }>>({});

  useEffect(() => {
    settingsService
      .getRoundInterviewers()
      .then(({ data }) => setRoundTypes(data.round_types))
      .catch(() => setError("Couldn't load round interviewer rosters."))
      .finally(() => setLoading(false));
  }, []);

  const persist = async (next: RoundTypeEntry[]) => {
    setSaving(true);
    setError(null);
    try {
      const { data } = await settingsService.saveRoundInterviewers({ round_types: next });
      setRoundTypes(data.round_types);
    } catch {
      setError("Couldn't save — try again.");
    } finally {
      setSaving(false);
    }
  };

  const draftFor = (key: string) => drafts[key] ?? { name: "", email: "" };
  const setDraft = (key: string, patch: Partial<{ name: string; email: string }>) =>
    setDrafts((prev) => ({ ...prev, [key]: { ...draftFor(key), ...patch } }));

  const addInterviewer = (key: string) => {
    const d = draftFor(key);
    if (!d.name.trim() || !d.email.trim() || !d.email.includes("@")) {
      setError("Enter a name and a valid email before adding.");
      return;
    }
    const next = roundTypes.map((rt) =>
      rt.key === key
        ? { ...rt, interviewers: [...rt.interviewers, { name: d.name.trim(), email: d.email.trim() }] }
        : rt
    );
    setDrafts((prev) => ({ ...prev, [key]: { name: "", email: "" } }));
    void persist(next);
  };

  const removeInterviewer = (key: string, idx: number) => {
    void persist(
      roundTypes.map((rt) =>
        rt.key === key ? { ...rt, interviewers: rt.interviewers.filter((_, i) => i !== idx) } : rt
      )
    );
  };

  const addRoundType = () => {
    const label = newType.trim();
    if (!label) return;
    if (roundTypes.some((rt) => rt.label.toLowerCase() === label.toLowerCase())) {
      setError("That round type already exists.");
      return;
    }
    setNewType("");
    void persist([...roundTypes, { key: "", label, custom: true, interviewers: [] }]);
  };

  const removeRoundType = async (key: string) => {
    if (!(await confirm({ title: "Remove this round type and its roster?", confirmLabel: "Remove", danger: true }))) return;
    void persist(roundTypes.filter((rt) => rt.key !== key));
  };

  return (
    <CollapsibleSection
      id="round-interviewers"
      icon={Users2}
      title="Round Interviewers"
      desc="Who's rostered on each interview stage — sourced for calendar availability when offering candidates a slot"
      colSpan="lg:col-span-2"
    >
      {loading ? (
        <div className="flex items-center gap-2 py-4 text-xs text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading…
        </div>
      ) : (
        <div className="space-y-3">
          {roundTypes.map((rt) => (
            <div key={rt.key} className="rounded-lg border border-border/60 bg-secondary/20 p-3">
              <div className="mb-2 flex items-center justify-between gap-2">
                <span className="text-xs font-semibold text-foreground">{rt.label}</span>
                {rt.custom && (
                  <button
                    onClick={() => removeRoundType(rt.key)}
                    title="Remove this custom round type"
                    className="rounded-lg p-1 text-muted-foreground hover:bg-red-500/10 hover:text-red-400 transition-colors"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                )}
              </div>
              <div className="space-y-1.5">
                {rt.interviewers.map((iv, idx) => (
                  <div
                    key={`${iv.email}-${idx}`}
                    className="flex items-center justify-between gap-2 rounded-lg bg-background/60 px-2.5 py-1.5"
                  >
                    <div className="min-w-0 text-xs">
                      <span className="font-medium text-foreground">{iv.name}</span>{" "}
                      <span className="text-muted-foreground">— {iv.email}</span>
                    </div>
                    <button
                      onClick={() => removeInterviewer(rt.key, idx)}
                      className="shrink-0 rounded-lg p-1 text-muted-foreground hover:bg-red-500/10 hover:text-red-400 transition-colors"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                ))}
                {rt.interviewers.length === 0 && (
                  <p className="px-1 py-1 text-[10px] text-muted-foreground">No interviewers rostered yet.</p>
                )}
              </div>
              <div className="mt-2 flex flex-col gap-1.5 sm:flex-row">
                <input
                  value={draftFor(rt.key).name}
                  onChange={(e) => setDraft(rt.key, { name: e.target.value })}
                  placeholder="Name"
                  className="flex-1 rounded-lg border border-border bg-secondary px-2 py-1.5 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50"
                />
                <input
                  value={draftFor(rt.key).email}
                  onChange={(e) => setDraft(rt.key, { email: e.target.value })}
                  onKeyDown={(e) => e.key === "Enter" && addInterviewer(rt.key)}
                  placeholder="email@company.com"
                  className="flex-1 rounded-lg border border-border bg-secondary px-2 py-1.5 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50"
                />
                <button
                  onClick={() => addInterviewer(rt.key)}
                  disabled={saving}
                  className="inline-flex shrink-0 items-center justify-center gap-1 rounded-lg bg-primary px-2.5 py-1.5 text-xs font-semibold text-primary-foreground hover:bg-primary/90 disabled:opacity-50 transition-colors"
                >
                  <UserPlus className="h-3.5 w-3.5" /> Add
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="mt-3 flex flex-col gap-2 sm:flex-row sm:items-center">
        <input
          value={newType}
          onChange={(e) => { setNewType(e.target.value); if (error) setError(null); }}
          onKeyDown={(e) => e.key === "Enter" && addRoundType()}
          placeholder="Additional round type (e.g. Culture Fit)"
          className="flex-1 rounded-lg border border-border bg-secondary px-2 py-1.5 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50"
        />
        <button
          onClick={addRoundType}
          disabled={saving || !newType.trim()}
          className="inline-flex shrink-0 items-center justify-center gap-1.5 rounded-lg border border-border bg-card px-3 py-1.5 text-xs font-semibold text-foreground hover:bg-secondary transition-colors disabled:opacity-50"
        >
          <Plus className="h-3.5 w-3.5" /> Add round type
        </button>
        {saving && <Loader2 className="h-3.5 w-3.5 animate-spin text-muted-foreground" />}
      </div>
      {error && <p className="mt-2 text-[10px] text-red-400">{error}</p>}
    </CollapsibleSection>
  );
}

// Native candidate interview slot-picker cadence — slot length, which
// calendar is checked (currently always the QA stand-in mailbox — see the
// module docstring in app/services/interview_scheduling_config.py), and the
// reminder/auto-reject schedule for candidates who don't book a slot.
function InterviewSchedulingCard() {
  const [cfg, setCfg] = useState<InterviewSchedulingSettingsType | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    settingsService
      .getInterviewScheduling()
      .then(({ data }) => setCfg(data))
      .catch(() => setError("Couldn't load interview scheduling settings."))
      .finally(() => setLoading(false));
  }, []);

  const persist = async (next: InterviewSchedulingSettingsType) => {
    setCfg(next);
    setSaving(true);
    setError(null);
    try {
      const { data } = await settingsService.saveInterviewScheduling(next);
      setCfg(data);
    } catch {
      setError("Couldn't save — check the values and try again.");
    } finally {
      setSaving(false);
    }
  };

  if (loading || !cfg) {
    return (
      <CollapsibleSection id="interview-scheduling" icon={CalendarClock} title="Interview Scheduling" desc="Candidate slot-picker cadence" colSpan="lg:col-span-2">
        <div className="flex items-center gap-2 py-4 text-xs text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading…
        </div>
      </CollapsibleSection>
    );
  }

  return (
    <CollapsibleSection
      id="interview-scheduling"
      icon={CalendarClock}
      title="Interview Scheduling"
      desc="Slot length, calendar lookup, and the reminder/auto-reject cadence for the candidate slot picker"
      colSpan="lg:col-span-2"
    >
      <SettingRow
        label="QA calendar email"
        description="Availability lookups check this mailbox's calendar. Outside production, this is also where every candidate-facing email (slot invites, booking confirmations, reminders, Teams meeting invites) is redirected instead of the candidate's real address"
      >
        <input
          value={cfg.qa_calendar_email}
          onChange={(e) => setCfg({ ...cfg, qa_calendar_email: e.target.value })}
          onBlur={() => void persist(cfg)}
          className="w-64 rounded-lg border border-border bg-secondary px-2 py-1.5 text-xs text-foreground text-right focus:outline-none focus:border-primary/50"
        />
      </SettingRow>
      <SettingRow label="Slot duration" description="Length of each offered interview slot">
        <div className="flex items-center gap-1.5">
          <NumericInput
            value={cfg.slot_duration_minutes}
            onChange={(v) => void persist({ ...cfg, slot_duration_minutes: v })}
            min={10}
            max={240}
            step={5}
          />
          <span className="text-[11px] text-muted-foreground">minutes</span>
        </div>
      </SettingRow>
      <SettingRow label="Reminders before auto-reject" description="How many reminder emails a candidate gets if they don't pick a slot">
        <div className="flex items-center gap-1.5">
          <NumericInput
            value={cfg.reminder_max_count}
            onChange={(v) => void persist({ ...cfg, reminder_max_count: v })}
            min={0}
            max={10}
          />
          <span className="text-[11px] text-muted-foreground">emails</span>
        </div>
      </SettingRow>
      <SettingRow
        label="Reminder interval"
        description={`Time between reminder emails${cfg.minutes_allowed ? " — minutes are available in this QA environment for fast cycle testing" : ""}`}
      >
        <div className="flex items-center gap-1.5">
          <NumericInput
            value={cfg.reminder_interval_hours}
            onChange={(v) => void persist({ ...cfg, reminder_interval_hours: v })}
            min={1}
            max={cfg.reminder_interval_unit === "minutes" ? 10080 : 24 * 30}
          />
          {cfg.minutes_allowed ? (
            <select
              value={cfg.reminder_interval_unit}
              onChange={(e) =>
                void persist({ ...cfg, reminder_interval_unit: e.target.value as "hours" | "minutes" })
              }
              className="rounded-lg border border-border bg-secondary px-1.5 py-1.5 text-xs text-foreground focus:border-primary/50 focus:outline-none"
            >
              <option value="hours">hours</option>
              <option value="minutes">minutes (QA)</option>
            </select>
          ) : (
            <span className="text-[11px] text-muted-foreground">hours</span>
          )}
        </div>
      </SettingRow>
      <SettingRow
        label="Auto-reject after"
        description={`How long with no slot booked before the candidate is automatically rejected${cfg.minutes_allowed ? " — minutes are available in this QA environment for fast cycle testing" : ""}`}
      >
        <div className="flex items-center gap-1.5">
          <NumericInput
            value={cfg.auto_reject_after_days}
            onChange={(v) => void persist({ ...cfg, auto_reject_after_days: v })}
            min={1}
            max={cfg.auto_reject_after_unit === "minutes" ? 43200 : 90}
          />
          {cfg.minutes_allowed ? (
            <select
              value={cfg.auto_reject_after_unit}
              onChange={(e) =>
                void persist({ ...cfg, auto_reject_after_unit: e.target.value as "days" | "minutes" })
              }
              className="rounded-lg border border-border bg-secondary px-1.5 py-1.5 text-xs text-foreground focus:border-primary/50 focus:outline-none"
            >
              <option value="days">days</option>
              <option value="minutes">minutes (QA)</option>
            </select>
          ) : (
            <span className="text-[11px] text-muted-foreground">days</span>
          )}
        </div>
      </SettingRow>
      <p className="mt-2 text-[10px] text-muted-foreground">
        Whether advancing a candidate auto-sends this invite is configured under Settings →
        Email Send Controls (below Interviewer Access).
      </p>
      {saving && (
        <div className="mt-2 flex items-center gap-1.5 text-[10px] text-muted-foreground">
          <Loader2 className="h-3 w-3 animate-spin" /> Saving…
        </div>
      )}
      {error && <p className="mt-2 text-[10px] text-red-400">{error}</p>}
    </CollapsibleSection>
  );
}

// A stable, always-clickable interview link against a fully-mocked demo
// candidate (mock resume, ATS/NLRS scores, Analysis Report, certs, etc.) — so
// you can check the interviewer experience anytime without touching real
// candidate data. "Reset" clears any verdict left over from a prior test.
// One row per verdict-picker scenario (order matches the interview plan flow).
const SAMPLE_SCENARIO_ORDER = ["Screening", "Round 1", "Round 2", "Final"];
const SAMPLE_SCENARIO_HINT: Record<string, string> = {
  Screening: "Legacy Pass/Fail picker",
  "Round 1": "Move to Round 2 / Reject (+ Admin bypass)",
  "Round 2": "Move to Final / Reject (+ Admin bypass)",
  Final: "Hire / Reject (+ Admin bypass)",
};

function SampleInterviewLinkRow() {
  const [links, setLinks] = useState<SampleInterviewLinksType | null>(null);
  const [loading, setLoading] = useState(true);
  const [resetting, setResetting] = useState<string | null>(null);
  const [copiedFor, setCopiedFor] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const load = () => {
    setLoading(true);
    settingsService
      .getSampleInterviewLinks()
      .then(({ data }) => setLinks(data))
      .catch(() => setNotice("Couldn't set up the sample links — try again."))
      .finally(() => setLoading(false));
  };
  useEffect(load, []);

  const copy = async (roundName: string, urlPath: string) => {
    try {
      await navigator.clipboard.writeText(`${window.location.origin}${urlPath}`);
      setCopiedFor(roundName);
      setTimeout(() => setCopiedFor(null), 2000);
    } catch {
      /* clipboard permission denied — the field is still selectable to copy manually */
    }
  };

  const reset = async (roundName: string) => {
    setResetting(roundName);
    setNotice(null);
    try {
      const { data } = await settingsService.resetSampleInterviewScenario(roundName);
      setLinks((prev) => (prev ? { ...prev, [roundName]: data } : prev));
      setNotice(`${roundName} reset — ready to test its verdict flow again.`);
    } catch {
      setNotice("Couldn't reset — try again.");
    } finally {
      setResetting(null);
      setTimeout(() => setNotice(null), 4000);
    }
  };

  return (
    <div className="mt-3 rounded-lg border border-border bg-secondary/30 p-3">
      <div className="mb-1.5 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
        Sample interviewer view
      </div>
      <p className="mb-2 text-[11px] text-muted-foreground">
        Stable links against a mocked demo candidate (with a mock resume) — one per verdict-picker
        scenario, so you can check every stage of the interviewer experience without touching real
        candidate data.
      </p>
      {loading || !links ? (
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Loader2 className="h-3.5 w-3.5 animate-spin" /> Setting up sample data…
        </div>
      ) : (
        <>
          <div className="space-y-2">
            {SAMPLE_SCENARIO_ORDER.filter((name) => links[name]).map((roundName) => {
              const link = links[roundName];
              return (
                <div key={roundName} className="rounded-lg border border-border/60 bg-card p-2">
                  <div className="mb-1.5 flex items-baseline gap-2">
                    <span className="text-xs font-semibold text-foreground">{roundName}</span>
                    <span className="text-[10px] text-muted-foreground">{SAMPLE_SCENARIO_HINT[roundName]}</span>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <input
                      readOnly
                      value={`${window.location.origin}${link.url_path}`}
                      onFocus={(e) => e.target.select()}
                      className="min-w-[14rem] flex-1 truncate rounded-lg border border-border bg-secondary px-2 py-1.5 text-xs text-foreground"
                    />
                    <a
                      href={link.url_path}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex shrink-0 items-center gap-1 rounded-lg border border-border px-2.5 py-1.5 text-[11px] font-semibold text-muted-foreground hover:bg-secondary hover:text-foreground"
                    >
                      <ExternalLink className="h-3 w-3" /> Open
                    </a>
                    <button
                      onClick={() => copy(roundName, link.url_path)}
                      className="inline-flex shrink-0 items-center gap-1 rounded-lg border border-border px-2.5 py-1.5 text-[11px] font-semibold text-muted-foreground hover:bg-secondary hover:text-foreground"
                    >
                      <Copy className="h-3 w-3" /> {copiedFor === roundName ? "Copied" : "Copy"}
                    </button>
                    <button
                      onClick={() => reset(roundName)}
                      disabled={resetting === roundName}
                      title="Clear any verdict/feedback left from a previous test"
                      className="inline-flex shrink-0 items-center gap-1 rounded-lg border border-border px-2.5 py-1.5 text-[11px] font-semibold text-muted-foreground hover:bg-secondary hover:text-foreground disabled:opacity-50"
                    >
                      {resetting === roundName ? <Loader2 className="h-3 w-3 animate-spin" /> : <RotateCcw className="h-3 w-3" />}
                      Reset
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
          {notice && <p className="mt-2 text-[11px] text-emerald-500">{notice}</p>}
        </>
      )}
    </div>
  );
}

// Groups the settings tiles below into contextually related clusters (Access
// & Accounts / Pipeline & Notifications / Candidate & Screening Experience /
// Classification & Scoring) — a plain full-width label + rule, not another
// collapsible level; the tiles underneath still collapse individually.
function GroupDivider({ label }: { label: string }) {
  return (
    <div className="col-span-full mb-1 mt-4 flex items-center gap-3 first:mt-0">
      <span className="whitespace-nowrap text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
        {label}
      </span>
      <div className="h-px flex-1 bg-border" />
    </div>
  );
}

export default function Settings() {
  const { canAccessBackoffice, isAdmin } = useAuth();
  // Every section below is collapsed by default (see CollapsibleSection) —
  // this jumps to and expands the best-matching one instead of making the
  // admin hunt through a dozen collapsed cards. Type-ahead: as the admin
  // types, a ranked dropdown of every plausible section appears (not just
  // the single best guess) — useful when a query is ambiguous (e.g. "qa
  // email" is relevant to both Interview Scheduling and Email Send Controls).
  const [sectionQuery, setSectionQuery] = useState("");
  const [searchFocused, setSearchFocused] = useState(false);
  const [highlightIdx, setHighlightIdx] = useState(0);
  const [noMatch, setNoMatch] = useState(false);
  const sectionMatches = useMemo(() => findSectionMatches(sectionQuery), [sectionQuery]);
  const showDropdown = searchFocused && sectionQuery.trim() !== "" && sectionMatches.length > 0;
  const pickSection = (id: string) => {
    focusSection(id);
    setSectionQuery("");
    setSearchFocused(false);
    setNoMatch(false);
  };
  const runSectionSearch = () => {
    if (sectionMatches.length > 0) {
      pickSection(sectionMatches[Math.min(highlightIdx, sectionMatches.length - 1)].id);
      return;
    }
    const match = findBestSectionMatch(sectionQuery);
    if (match) {
      pickSection(match.id);
    } else {
      setNoMatch(true);
      setTimeout(() => setNoMatch(false), 2500);
    }
  };
  // Invalidates FloatingChatbot's cached widget-config query on save, below —
  // that component stays mounted app-wide and never unmounts on navigation,
  // so without this it keeps showing/hiding based on stale cached data until
  // its 5-minute staleTime lapses (or a hard page refresh resets the cache).
  const queryClient = useQueryClient();
  // Pipeline config — persisted to env via /settings/pipeline (loaded on mount).
  const [runTime, setRunTime] = useState("00:00");
  const [maxRetries, setMaxRetries] = useState(3);
  const [archiveAfterDays, setArchiveAfterDays] = useState(30);
  const [archiveAtsThreshold, setArchiveAtsThreshold] = useState(30); // ATS scale 0–100
  const [dedupThreshold, setDedupThreshold] = useState(85);

  // Floating chat launcher ("Neuleap Buddy") — one shared on/off toggle for
  // every user, not a per-user preference (see FloatingChatbot.tsx, which
  // reads this same setting on every page load).
  const [chatWidgetVisible, setChatWidgetVisible] = useState(true);

  // Interview-slot-picker API — the "Get slot link" button on an email draft
  // (EmailDraftReview.tsx) calls this externally-configured endpoint with the
  // round + candidate name/email (param names below are that API's own
  // vocabulary, not ours). override_email is a QA escape hatch: when set, it's
  // sent instead of the candidate's real address on every call.
  const [slotApiUrl, setSlotApiUrl] = useState("");
  const [slotParamRound, setSlotParamRound] = useState("round");
  const [slotParamName, setSlotParamName] = useState("candidate_name");
  const [slotParamEmail, setSlotParamEmail] = useState("email");
  const [slotOverrideEmail, setSlotOverrideEmail] = useState("");

  // Candidate profile page — which optional sections render, for every user
  // (see Candidate/index.tsx, which reads this same setting on every load).
  // Defaults mirror the backend's (candidate_sections_config._DEFAULTS) so the
  // page never flashes the wrong state before this loads.
  const [secQuickSignals, setSecQuickSignals] = useState(false);
  const [secThinkingSummary, setSecThinkingSummary] = useState(false);
  const [secAtsBreakdown, setSecAtsBreakdown] = useState(false);
  const [secNlrsBreakdown, setSecNlrsBreakdown] = useState(true);
  const [secSkills, setSecSkills] = useState(false);
  const [secCertificates, setSecCertificates] = useState(true);
  const [secCareerTimeline, setSecCareerTimeline] = useState(false);
  const [secRoundHistory, setSecRoundHistory] = useState(true);

  const [notifEmail, setNotifEmail] = useState("");
  const [notifManualReview, setNotifManualReview] = useState(true);
  const [notifExhausted, setNotifExhausted] = useState(true);
  const [notifRunSummary, setNotifRunSummary] = useState(false);
  const [graphConfigured, setGraphConfigured] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saveMsg, setSaveMsg] = useState<string | null>(null);
  // Unsaved-changes tracking: any user edit flips `dirty`; a successful Save/Reload
  // clears it. The loader below sets state directly (not via `touch`), so loading
  // never marks the form dirty.
  const [dirty, setDirty] = useState(false);
  const [confirmChatbotEnable, setConfirmChatbotEnable] = useState(false);
  const touch =
    <T,>(fn: (v: T) => void) =>
    (v: T) => {
      fn(v);
      setDirty(true);
    };

  // Load persisted settings (env-file backed) on mount.
  useEffect(() => {
    settingsService
      .getChatbotWidget()
      .then(({ data }) => setChatWidgetVisible(data.visible))
      .catch(() => {});
    settingsService
      .getInterviewSlotSettings()
      .then(({ data }) => {
        setSlotApiUrl(data.api_url);
        setSlotParamRound(data.param_round);
        setSlotParamName(data.param_name);
        setSlotParamEmail(data.param_email);
        setSlotOverrideEmail(data.override_email);
      })
      .catch(() => {});
    settingsService
      .getCandidateSections()
      .then(({ data }) => {
        setSecQuickSignals(data.quick_signals);
        setSecThinkingSummary(data.thinking_summary);
        setSecAtsBreakdown(data.ats_breakdown);
        setSecNlrsBreakdown(data.nlrs_breakdown);
        setSecSkills(data.skills);
        setSecCertificates(data.certificates);
        setSecCareerTimeline(data.career_timeline);
        setSecRoundHistory(data.round_history);
      })
      .catch(() => {});
    settingsService
      .getNotifications()
      .then(({ data }) => {
        setNotifEmail(data.email ?? "");
        setNotifManualReview(data.manual_review);
        setNotifExhausted(data.exhausted);
        setNotifRunSummary(data.run_summary);
        setGraphConfigured(data.graph_configured ?? true);
      })
      .catch(() => {});
    settingsService
      .getPipeline()
      .then(({ data }) => {
        setRunTime(data.run_time ?? "00:00");
        setMaxRetries(data.max_retries);
        setArchiveAfterDays(data.archive_after_days);
        setArchiveAtsThreshold(data.archive_ats_threshold);
        setDedupThreshold(data.dedup_threshold);
      })
      .catch(() => {});
    settingsService
      .getScoring()
      .then(({ data }) => {
        if (data.ats_bands) setAtsBands(data.ats_bands);
        if (data.stream_keywords && Object.keys(data.stream_keywords).length)
          setStreams(data.stream_keywords);
        if (data.cert_tags && data.cert_tags.length) setCertTags(data.cert_tags);
      })
      .catch(() => {});
  }, []);

  const saveNotifications = async () => {
    setSaving(true);
    setSaveMsg(null);
    try {
      await Promise.all([
        settingsService.saveChatbotWidget(chatWidgetVisible),
        settingsService.saveInterviewSlotSettings({
          api_url: slotApiUrl.trim(),
          param_round: slotParamRound.trim() || "round",
          param_name: slotParamName.trim() || "candidate_name",
          param_email: slotParamEmail.trim() || "email",
          override_email: slotOverrideEmail.trim(),
        }),
        settingsService.saveCandidateSections({
          quick_signals: secQuickSignals,
          thinking_summary: secThinkingSummary,
          ats_breakdown: secAtsBreakdown,
          nlrs_breakdown: secNlrsBreakdown,
          skills: secSkills,
          certificates: secCertificates,
          career_timeline: secCareerTimeline,
          round_history: secRoundHistory,
        }),
        settingsService.saveNotifications({
          email: notifEmail.trim() || null,
          run_summary: notifRunSummary,
          manual_review: notifManualReview,
          exhausted: notifExhausted,
          new_p1: false,
        }),
        settingsService.savePipeline({
          run_time: runTime,
          max_retries: maxRetries,
          archive_after_days: archiveAfterDays,
          archive_ats_threshold: archiveAtsThreshold,
          dedup_threshold: dedupThreshold,
        }),
        settingsService.saveScoring({
          ats_bands: atsBands,
          stream_keywords: streams,
          cert_tags: certTags,
        }),
      ]);
      setSaveMsg("Saved");
      setDirty(false);
      queryClient.invalidateQueries({ queryKey: ["chatbot-widget-config"] });
      queryClient.invalidateQueries({ queryKey: ["candidate-sections-config"] });
    } catch {
      setSaveMsg("Save failed");
    } finally {
      setSaving(false);
      setTimeout(() => setSaveMsg(null), 3000);
    }
  };

  const reloadFromEnv = async () => {
    setSaving(true);
    setSaveMsg(null);
    try {
      const { data } = await settingsService.reloadFromEnv();
      setRunTime(data.pipeline.run_time ?? "00:00");
      setMaxRetries(data.pipeline.max_retries);
      setArchiveAfterDays(data.pipeline.archive_after_days);
      setArchiveAtsThreshold(data.pipeline.archive_ats_threshold);
      setDedupThreshold(data.pipeline.dedup_threshold);
      setNotifEmail(data.notifications.email ?? "");
      setNotifManualReview(data.notifications.manual_review);
      setNotifExhausted(data.notifications.exhausted);
      setNotifRunSummary(data.notifications.run_summary);
      setSaveMsg("Reloaded");
      setDirty(false);
    } catch {
      setSaveMsg("Reload failed");
    } finally {
      setSaving(false);
      setTimeout(() => setSaveMsg(null), 4000);
    }
  };

  const sendTest = async () => {
    setSaveMsg(null);
    try {
      const { data } = await settingsService.testNotification();
      setSaveMsg(data.sent ? "Test email sent" : `Test failed: ${data.error}`);
    } catch {
      setSaveMsg("Test failed");
    }
    setTimeout(() => setSaveMsg(null), 5000);
  };

  // ATS bands on the live 0–100 scale (matches atsscore + the backend). Loaded from
  // /settings/scoring on mount, saved back on "Save Settings".
  const [atsBands, setAtsBands] = useState({
    P1: 85,
    P2: 70,
    P3: 55,
  });

  const [streams, setStreams] = useState<Record<string, string[]>>(STREAM_KEYWORDS);
  const [newKeyword, setNewKeyword] = useState<Record<string, string>>({});

  const addKeyword = (stream: string) => {
    const kw = (newKeyword[stream] ?? "").trim();
    if (!kw) return;
    setStreams((prev) => ({ ...prev, [stream]: [...prev[stream], kw] }));
    setNewKeyword((prev) => ({ ...prev, [stream]: "" }));
    setDirty(true);
  };

  const removeKeyword = (stream: string, kw: string) => {
    setStreams((prev) => ({ ...prev, [stream]: prev[stream].filter((k) => k !== kw) }));
    setDirty(true);
  };

  // Certificate filter tags — the checkboxes shown in the Resume Library cert filter.
  // Loaded from /settings/scoring on mount, saved back on "Save Settings".
  const [certTags, setCertTags] = useState<string[]>(CERT_TAGS);
  const [newCertTag, setNewCertTag] = useState("");
  const [certTagError, setCertTagError] = useState<string | null>(null);

  const addCertTag = () => {
    const result = validateCertTag(newCertTag, certTags);
    if (!result.ok) {
      setCertTagError(result.error);
      return;
    }
    setCertTags((prev) => [...prev, result.value]);
    setNewCertTag("");
    setCertTagError(null);
    setDirty(true);
  };

  const removeCertTag = (tag: string) => {
    setCertTags((prev) => prev.filter((t) => t !== tag));
    setDirty(true);
  };

  // Auto-save: any edit (via `touch`) flips `dirty`, which (re)starts this
  // debounce — the effect re-runs on every watched field change, so the timer
  // always restarts with the LATEST values and only fires once edits pause.
  useEffect(() => {
    if (!dirty) return;
    const t = setTimeout(() => { void saveNotifications(); }, 1200);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    dirty,
    chatWidgetVisible,
    slotApiUrl, slotParamRound, slotParamName, slotParamEmail, slotOverrideEmail,
    secQuickSignals, secThinkingSummary, secAtsBreakdown, secNlrsBreakdown,
    secSkills, secCertificates, secCareerTimeline, secRoundHistory,
    notifEmail, notifRunSummary, notifManualReview, notifExhausted,
    runTime, maxRetries, archiveAfterDays, archiveAtsThreshold, dedupThreshold,
    atsBands, streams, certTags,
  ]);

  // Recruiter has no Settings access at all (server-side enforced too — every
  // /settings/* call 403s for that role). This guard just keeps the page from
  // rendering a form whose every save would fail, for a Recruiter who lands
  // here via a direct URL (the entry point is already hidden from the profile menu).
  if (!canAccessBackoffice) {
    return (
      <PageContainer>
        <PageHeader title="Settings" subtitle="Pipeline settings · stream definitions · notifications" />
        <div className="flex flex-col items-center justify-center gap-3 rounded-2xl glass p-12 text-center">
          <ShieldAlert className="h-8 w-8 text-muted-foreground" />
          <p className="text-sm font-semibold text-foreground">Settings is restricted</p>
          <p className="max-w-sm text-xs text-muted-foreground">
            This section is only available to Admin and System Admin accounts.
          </p>
        </div>
      </PageContainer>
    );
  }

  return (
    <PageContainer>
      <PageHeader
        title="Settings"
        subtitle="Pipeline settings · stream definitions · notifications"
        actions={
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
            <input
              value={sectionQuery}
              onChange={(e) => { setSectionQuery(e.target.value); setHighlightIdx(0); setNoMatch(false); }}
              onFocus={() => setSearchFocused(true)}
              onBlur={() => setTimeout(() => setSearchFocused(false), 150)}
              onKeyDown={(e) => {
                if (e.key === "Enter") { e.preventDefault(); runSectionSearch(); }
                else if (e.key === "ArrowDown") { e.preventDefault(); setHighlightIdx((i) => Math.min(i + 1, sectionMatches.length - 1)); }
                else if (e.key === "ArrowUp") { e.preventDefault(); setHighlightIdx((i) => Math.max(i - 1, 0)); }
                else if (e.key === "Escape") { setSearchFocused(false); }
              }}
              placeholder="Search settings…"
              className="w-36 rounded-lg border border-border bg-card/70 py-1.5 pl-8 pr-3 text-xs text-foreground placeholder:text-muted-foreground outline-none transition-all focus:w-56 focus:border-primary/50 focus:ring-2 focus:ring-primary/20"
            />
            {showDropdown && (
              <div className="absolute right-0 top-full z-10 mt-1.5 w-64 overflow-hidden rounded-lg border border-border bg-card shadow-lg">
                {sectionMatches.map((m, i) => (
                  <button
                    key={m.id}
                    type="button"
                    // onMouseDown (not onClick) fires before the input's onBlur closes the dropdown.
                    onMouseDown={() => pickSection(m.id)}
                    onMouseEnter={() => setHighlightIdx(i)}
                    className={cn(
                      "block w-full truncate px-3 py-1.5 text-left text-xs",
                      i === highlightIdx ? "bg-primary/10 text-primary" : "text-foreground hover:bg-secondary"
                    )}
                  >
                    {m.title}
                  </button>
                ))}
              </div>
            )}
            {noMatch && (
              <div className="absolute right-0 top-full z-10 mt-1.5 whitespace-nowrap rounded-lg border border-amber-500/30 bg-card px-2.5 py-1 text-[10px] font-medium text-amber-600 shadow-lg">
                No matching section
              </div>
            )}
          </div>
          <span
            title="Changes save automatically a moment after you stop editing"
            className={cn(
              "flex items-center gap-1.5 text-[11px] font-medium",
              saving ? "text-primary" : dirty ? "text-amber-500" : "text-muted-foreground"
            )}
          >
            <Save className="h-3 w-3" />
            {saveMsg ?? (saving ? "Saving…" : dirty ? "Auto-saving…" : "All changes saved")}
          </span>
          <button
            onClick={reloadFromEnv}
            disabled={saving}
            title="Reload the saved configuration"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border bg-card/70 text-xs font-semibold text-muted-foreground hover:text-foreground hover:border-primary/40 disabled:opacity-50 transition-colors shrink-0"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            Reload
          </button>
        </div>
        }
      />

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
      <GroupDivider label="Access & Accounts" />
      {/* User management — Admin only */}
      {/* canAccessBackoffice is guaranteed true here — the early guard above
          already returned for any role without Settings access. */}
      <UserManagementCard />
      <FeedbackReportsCard />

      <GroupDivider label="Interview Access & Scheduling" />
      <InterviewerAccessCard />
      <RoundInterviewersCard />
      <InterviewSchedulingCard />

      <GroupDivider label="Email Sending Controls" />
      <EmailSendControlsCard />

      <GroupDivider label="Pipeline & Notifications" />
      {/* Pipeline config */}
      <CollapsibleSection
        id="pipeline-config"
        icon={Settings2}
        title="Pipeline Configuration"
        desc="Controls how the automated pipeline runs each night"
      >
        <div>
          <SettingRow label="Daily run time" description="Time the pipeline starts collecting new emails each day">
            <div className="flex items-center gap-2">
              <Clock className="h-3.5 w-3.5 text-muted-foreground" />
              <input
                type="time"
                value={runTime}
                onChange={(e) => { setRunTime(e.target.value); setDirty(true); }}
                className="px-2 py-1.5 text-xs rounded-lg border border-border bg-secondary text-foreground focus:outline-none focus:border-primary/50"
              />
            </div>
          </SettingRow>
          <SettingRow label="Max retries per email" description="How many times to retry a failed email before sending it for manual review (1–5)">
            <div className="flex items-center gap-2">
              <RefreshCw className="h-3.5 w-3.5 text-muted-foreground" />
              <NumericInput value={maxRetries} onChange={touch(setMaxRetries)} min={1} max={5} />
            </div>
          </SettingRow>
          <SettingRow label="Archive after (closed) — days" description="Closed candidates are moved to the archive after this many days (5–30)">
            <div className="flex items-center gap-2">
              <Archive className="h-3.5 w-3.5 text-muted-foreground" />
              <NumericInput value={archiveAfterDays} onChange={touch(setArchiveAfterDays)} min={5} max={30} />
            </div>
          </SettingRow>
          <SettingRow label="Auto-archive ATS threshold" description="Candidates scoring below this (0–50) who were never screened are archived automatically">
            <NumericInput value={archiveAtsThreshold} onChange={touch(setArchiveAtsThreshold)} min={0} max={50} step={1} />
          </SettingRow>
        </div>
      </CollapsibleSection>

      {/* Notifications */}
      <CollapsibleSection
        id="notifications"
        icon={Bell}
        title="Notifications"
        desc="Email alerts for pipeline events"
      >
        <div>
          <SettingRow
            label="Notification email"
            description="Where alerts are sent after each run"
          >
            <div className="flex items-center gap-2">
              <Mail className="h-3.5 w-3.5 text-muted-foreground" />
              <input
                type="email"
                value={notifEmail}
                onChange={(e) => { setNotifEmail(e.target.value); setDirty(true); }}
                placeholder="hr@neuleap.ai"
                className="w-56 px-2 py-1.5 text-xs rounded-lg border border-border bg-secondary text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50"
              />
              <button
                onClick={sendTest}
                disabled={!notifEmail.trim()}
                className="px-2 py-1.5 text-[10px] font-semibold rounded-lg border border-border text-muted-foreground hover:text-foreground hover:border-primary/40 disabled:opacity-40 transition-colors"
              >
                Test
              </button>
            </div>
          </SettingRow>
          {!graphConfigured && (
            <p className="text-[10px] text-amber-500 -mt-1 mb-2">
              Email isn't set up yet — alerts won't be sent until it's configured.
            </p>
          )}
          <SettingRow
            label="Needs review alert"
            description="Notify when an email has items that need review"
          >
            <Toggle value={notifManualReview} onChange={touch(setNotifManualReview)} />
          </SettingRow>
          <SettingRow
            label="Exhausted email alert"
            description="Notify when an email fails too many times to process"
          >
            <Toggle value={notifExhausted} onChange={touch(setNotifExhausted)} />
          </SettingRow>
          <SettingRow
            label="Run summary email"
            description="Daily digest after each pipeline run with counts"
          >
            <Toggle value={notifRunSummary} onChange={touch(setNotifRunSummary)} />
          </SettingRow>
        </div>
      </CollapsibleSection>

      <GroupDivider label="Candidate & Screening Experience" />
      {/* Candidate profile page sections */}
      <CollapsibleSection
        id="candidate-sections"
        icon={LayoutGrid}
        title="Candidate Page Sections"
        desc="Which optional sections render on a candidate's profile page"
        colSpan="lg:col-span-2"
      >
        <div>
          <SettingRow label="Quick Signals" description="Experience / career gap / switches / current company tiles">
            <Toggle value={secQuickSignals} onChange={touch(setSecQuickSignals)} />
          </SettingRow>
          <SettingRow label="Thinking Summary" description="The LLM's narrative analysis + supporting evidence quotes">
            <Toggle value={secThinkingSummary} onChange={touch(setSecThinkingSummary)} />
          </SettingRow>
          <SettingRow label="ATS Score Breakdown" description="Per-dimension bars explaining the ATS score">
            <Toggle value={secAtsBreakdown} onChange={touch(setSecAtsBreakdown)} />
          </SettingRow>
          <SettingRow label="NLRS Score Breakdown" description="Per-dimension bars explaining the NLRS score">
            <Toggle value={secNlrsBreakdown} onChange={touch(setSecNlrsBreakdown)} />
          </SettingRow>
          <SettingRow label="Skills" description="The candidate's extracted primary-skills cloud">
            <Toggle value={secSkills} onChange={touch(setSecSkills)} />
          </SettingRow>
          <SettingRow label="Certificates" description="The candidate's certifications card">
            <Toggle value={secCertificates} onChange={touch(setSecCertificates)} />
          </SettingRow>
          <SettingRow label="Career Timeline" description="The candidate's job-history timeline">
            <Toggle value={secCareerTimeline} onChange={touch(setSecCareerTimeline)} />
          </SettingRow>
          <SettingRow label="Round History" description="Every interview round's interviewer, outcome, and feedback">
            <Toggle value={secRoundHistory} onChange={touch(setSecRoundHistory)} />
          </SettingRow>
        </div>
      </CollapsibleSection>

      {/* Floating chat launcher */}
      <CollapsibleSection
        id="chatbot"
        icon={MessageSquare}
        title="Chatbot"
        desc="The floating chat launcher shown on every page"
        colSpan="lg:col-span-2"
      >
        <div>
          <SettingRow
            label="Show floating chat icon"
            description="Turns the launcher (and its chat panel) off for every user when disabled"
          >
            <Toggle
              value={chatWidgetVisible}
              onChange={(v) => (v ? setConfirmChatbotEnable(true) : touch(setChatWidgetVisible)(false))}
            />
          </SettingRow>
          <p className="mt-2 rounded-lg border border-amber-500/30 bg-amber-400/10 px-3 py-2 text-[11px] leading-relaxed text-amber-700 dark:text-amber-400">
            <b>Token caution:</b> every question a user asks spends AI tokens twice (query building
            + answer narration), for EVERY user, on every page the launcher shows on. Spend is
            metered per module on the Token Usage page. Answers run read-only against candidate
            data and are AI-generated — users are reminded of both in the chat itself.
          </p>
        </div>
      </CollapsibleSection>

      <ConfirmDialog
        open={confirmChatbotEnable}
        title="Enable the chatbot for every user?"
        message={
          <>
            Each question spends AI tokens on <b>two</b> LLM calls (query building + narration),
            and the launcher appears for <b>all users on every page</b> — costs scale with team
            usage. Spend is metered under "Chatbot" on the Token Usage page. Answers are
            AI-generated from live candidate data (read-only). Enable?
          </>
        }
        confirmLabel="Enable chatbot"
        onCancel={() => setConfirmChatbotEnable(false)}
        onConfirm={() => {
          touch(setChatWidgetVisible)(true);
          setConfirmChatbotEnable(false);
        }}
      />

      {/* Interview slot picker */}
      <CollapsibleSection
        id="interview-slot-picker"
        icon={Link2}
        title="Interview Slot Picker (External)"
        desc={'The "Get slot link" button on an email draft calls this API for a scheduling link'}
        colSpan="lg:col-span-2"
      >
        <p className="mb-3 rounded-lg border border-sky-500/20 bg-sky-500/5 px-3 py-2 text-[11px] leading-relaxed text-muted-foreground">
          This calls a third-party scheduling API. For slots pre-reserved on your own interviewers'
          calendars instead, see Mailbox → <span className="font-medium text-foreground">Interviewer Timeslot Pools</span> and
          the "Get pool slot link" button on a draft — the two are independent, use whichever fits.
        </p>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <label className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
              API URL
            </label>
            <input
              type="url"
              value={slotApiUrl}
              onChange={(e) => { setSlotApiUrl(e.target.value); setDirty(true); }}
              placeholder="https://example.com/api/interview-slot-link"
              className="mt-1 w-full px-2 py-1.5 text-xs rounded-lg border border-border bg-secondary text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50"
            />
          </div>
          <div>
            <label className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
              Round param name
            </label>
            <input
              value={slotParamRound}
              onChange={(e) => { setSlotParamRound(e.target.value); setDirty(true); }}
              placeholder="round"
              className="mt-1 w-full px-2 py-1.5 text-xs rounded-lg border border-border bg-secondary text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50"
            />
          </div>
          <div>
            <label className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
              Candidate name param
            </label>
            <input
              value={slotParamName}
              onChange={(e) => { setSlotParamName(e.target.value); setDirty(true); }}
              placeholder="candidate_name"
              className="mt-1 w-full px-2 py-1.5 text-xs rounded-lg border border-border bg-secondary text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50"
            />
          </div>
          <div>
            <label className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
              Candidate email param
            </label>
            <input
              value={slotParamEmail}
              onChange={(e) => { setSlotParamEmail(e.target.value); setDirty(true); }}
              placeholder="email"
              className="mt-1 w-full px-2 py-1.5 text-xs rounded-lg border border-border bg-secondary text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50"
            />
          </div>
          <div>
            <label className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
              Override email (QA)
            </label>
            <input
              type="email"
              value={slotOverrideEmail}
              onChange={(e) => { setSlotOverrideEmail(e.target.value); setDirty(true); }}
              placeholder="qa@neuleap.ai"
              className="mt-1 w-full px-2 py-1.5 text-xs rounded-lg border border-border bg-secondary text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50"
            />
            <p className="mt-1 text-[10px] text-muted-foreground">
              When set, every slot-link call sends this address instead of the candidate's real email.
            </p>
          </div>
        </div>
      </CollapsibleSection>

      <GroupDivider label="Classification & Scoring" />
      {/* Stream definitions */}
      <CollapsibleSection
        id="stream-definitions"
        icon={Tag}
        title="Stream Definitions"
        desc="Keywords used to sort candidates into streams"
        colSpan="lg:col-span-2"
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {Object.entries(streams).map(([stream, keywords]) => (
            <div key={stream} className="rounded-lg border border-border bg-secondary/30 p-3">
              <div className="text-xs font-bold text-foreground mb-2">{stream}</div>
              <div className="flex flex-wrap gap-1.5 mb-2 min-h-[28px]">
                {keywords.map((kw) => (
                  <button
                    key={kw}
                    onClick={() => removeKeyword(stream, kw)}
                    className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-primary/10 border border-primary/20 text-primary hover:bg-red-500/10 hover:border-red-500/20 hover:text-red-400 transition-colors"
                    title="Click to remove"
                  >
                    {kw} ×
                  </button>
                ))}
                {keywords.length === 0 && (
                  <span className="text-[10px] text-muted-foreground italic">No keywords — matches everything else</span>
                )}
              </div>
              {stream !== "Not Relevant" && (
                <div className="flex gap-1.5">
                  <input
                    type="text"
                    value={newKeyword[stream] ?? ""}
                    onChange={(e) => setNewKeyword((prev) => ({ ...prev, [stream]: e.target.value }))}
                    onKeyDown={(e) => e.key === "Enter" && addKeyword(stream)}
                    placeholder="Add keyword…"
                    className="flex-1 px-2 py-1 text-[10px] rounded-md border border-border bg-secondary text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50"
                  />
                  <button
                    onClick={() => addKeyword(stream)}
                    className="px-2 py-1 rounded-md bg-primary/10 border border-primary/20 text-primary text-[10px] font-semibold hover:bg-primary/20 transition-colors"
                  >
                    Add
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      </CollapsibleSection>

      {/* Certificate filter tags */}
      <CollapsibleSection
        id="cert-tags"
        icon={Award}
        title="Certificate Filter Tags"
        desc="Tags shown as checkboxes in the Resume Library certificate filter"
        colSpan="lg:col-span-2"
      >
        <div className="rounded-lg border border-border bg-secondary/30 p-3">
          <div className="flex flex-wrap gap-1.5 mb-3 min-h-[28px]">
            {certTags.map((tag) => (
              <button
                key={tag}
                onClick={() => removeCertTag(tag)}
                className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-amber-400/10 border border-amber-500/30 text-amber-400 hover:bg-red-500/10 hover:border-red-500/20 hover:text-red-400 transition-colors"
                title="Click to remove"
              >
                {tag} ×
              </button>
            ))}
            {certTags.length === 0 && (
              <span className="text-[10px] text-muted-foreground italic">
                No tags — the cert filter shows only the "Has certs" option
              </span>
            )}
          </div>
          <div className="flex gap-1.5">
            <input
              type="text"
              value={newCertTag}
              maxLength={CERT_TAG_MAX_LEN}
              onChange={(e) => {
                setNewCertTag(e.target.value);
                if (certTagError) setCertTagError(null);
              }}
              onKeyDown={(e) => e.key === "Enter" && addCertTag()}
              placeholder="Add a tag (e.g. AWS, Snowflake, PMP)…"
              className={cn(
                "flex-1 px-2 py-1 text-[10px] rounded-md border bg-secondary text-foreground placeholder:text-muted-foreground focus:outline-none",
                certTagError ? "border-red-500/60 focus:border-red-500/60" : "border-border focus:border-primary/50"
              )}
            />
            <button
              onClick={addCertTag}
              className="px-2 py-1 rounded-md bg-primary/10 border border-primary/20 text-primary text-[10px] font-semibold hover:bg-primary/20 transition-colors"
            >
              Add
            </button>
          </div>
          {certTagError ? (
            <p className="mt-1.5 text-[10px] text-red-400">{certTagError}</p>
          ) : (
            <p className="mt-1.5 text-[10px] text-muted-foreground">
              Up to {CERT_TAG_MAX_WORDS} words · {CERT_TAG_MAX_LEN} chars · letters, numbers and + # . & / - · kept as typed
            </p>
          )}
        </div>
      </CollapsibleSection>

      {/* Extraction & Analysis — Admin ONLY (not System Admin): SKILL.md
          override, the Analysis Report prompt, and NLRS weights/rules all
          feed live extraction/scoring, a higher blast radius than the rest
          of Settings. Also enforced server-side (require_admin), not just
          hidden here. */}
      {/* LLM Model Keys — visible to Admin & SysAdmin; editing is SysAdmin-
          only with own-password reauth (enforced server-side too). */}
      <LlmKeysCard />
      <GraphApiCard />
      <BackupCard />
      <UpgradeCard />
      {isAdmin && <ReferralConfigCard />}
      {isAdmin && <InterviewQuestionGenerationCard />}
      {isAdmin && <ExtractionAnalysisCard />}
      {isAdmin && <LegacyFeaturesCard />}

      </div>

      {/* Footer hint — the Save button lives at the top (page header). */}
      <p className="text-xs text-muted-foreground">
        {dirty
          ? "You have unsaved changes — use Save changes at the top to apply them on the next run."
          : "Pipeline, scoring & notification settings persist to env and apply on the next run."}
      </p>
    </PageContainer>
  );
}
