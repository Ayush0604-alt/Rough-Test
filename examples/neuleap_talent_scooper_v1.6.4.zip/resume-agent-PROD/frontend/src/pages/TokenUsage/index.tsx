// Admin → Token Usage — tokenomics dashboard over the llm_token_usage ledger
// (one row per LLM call, recorded at every call site: extraction, analysis
// report, timeline, interview questions, JD match, chatbot). Hero bar carries
// the source-tag + time-range filters, same idiom as Dashboard/Process Flow;
// the body breaks utilization down by module, day, source tag and model.
import { useMemo, useState } from "react";
import { TrendingUp, Layers as LayersIcon, Lightbulb, Filter as FilterIcon, Route, Bot, Scissors, RefreshCw } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import {
  Coins,
  Tag,
  CalendarRange,
  Cpu,
  Layers,
  Loader2,
  ArrowDownToLine,
  ArrowUpFromLine,
  CircleDollarSign,
  Activity,
} from "lucide-react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ComposedChart,
  Area,
  Line,
  ReferenceLine,
} from "recharts";
import { tokenUsageService, type DayModuleUsage, type TokenUsageSummary } from "@/services/tokenUsage";
import { cn } from "@/lib/utils";
import PageHeader from "@/components/layout/PageHeader";
import PageContainer from "@/components/layout/PageContainer";
import FilterDropdown from "@/components/common/FilterDropdown";

const ALL = "All sources";

// Time-range presets → date_from (date_to = today). null = all time.
const RANGES = [
  { key: "7d", label: "Last 7 days", days: 7 },
  { key: "30d", label: "Last 30 days", days: 30 },
  { key: "90d", label: "Last 90 days", days: 90 },
  { key: "all", label: "All time", days: null },
] as const;
type RangeKey = (typeof RANGES)[number]["key"] | "custom";

// Human labels for the ledger's module keys — every LLM call site records
// under one of these.
const MODULE_LABEL: Record<string, string> = {
  extraction: "Resume extraction + ATS",
  analysis_report: "Analysis report",
  timeline: "Career timeline",
  interview_questions: "Interview questions",
  jd_match: "JD match (batch scoring)",
  jd_match_explain: "JD match — score explanations",
  chatbot_sql: "Chatbot — query building",
  chatbot_narration: "Chatbot — answer narration",
};
const MODULE_COLOR: Record<string, string> = {
  extraction: "#665efd",
  analysis_report: "#8b5cf6",
  timeline: "#0ea5e9",
  interview_questions: "#10b981",
  jd_match: "#f59e0b",
  jd_match_explain: "#f97316",
  chatbot_sql: "#14b8a6",
  chatbot_narration: "#06b6d4",
};

const fmtTokens = (n: number) =>
  n >= 1_000_000 ? `${(n / 1_000_000).toFixed(2)}M` : n >= 1_000 ? `${(n / 1_000).toFixed(1)}k` : String(n);
const fmtCost = (v: number) => (v >= 0.01 ? `$${v.toFixed(2)}` : v > 0 ? `$${v.toFixed(4)}` : "$0");
const isoDay = (d: Date) => d.toISOString().slice(0, 10);

const OVERALL_COLOR = "#d946ef"; // fuchsia — deliberately outside the module palette
const FORECAST_DAYS = 7;

// Least-squares fit over a daily series — the projection is a straight trend
// line, honest about being an estimate (dashed, clamped at 0).
function linReg(ys: number[]): { m: number; b: number } {
  const n = ys.length;
  if (n === 0) return { m: 0, b: 0 };
  if (n === 1) return { m: 0, b: ys[0] };
  let sx = 0, sy = 0, sxx = 0, sxy = 0;
  ys.forEach((y, x) => { sx += x; sy += y; sxx += x * x; sxy += x * y; });
  const denom = n * sxx - sx * sx;
  const m = denom === 0 ? 0 : (n * sxy - sx * sy) / denom;
  return { m, b: (sy - m * sx) / n };
}

// Daily consumption as a line-area TREND with a dashed linear forecast —
// overall plus per-module, with a module multiselect (empty = all modules).
function TrendForecastChart({ byModule }: { byModule: DayModuleUsage[] }) {
  const [picked, setPicked] = useState<Set<string>>(new Set());
  const modulesInData = useMemo(
    () => Array.from(new Set(byModule.map((r) => r.module))).sort(),
    [byModule],
  );
  const active = picked.size > 0 ? modulesInData.filter((m) => picked.has(m)) : modulesInData;

  const { rows, lastDay } = useMemo(() => {
    if (byModule.length === 0) return { rows: [] as Record<string, number | string | null>[], lastDay: "" };
    const days = Array.from(new Set(byModule.map((r) => r.day))).sort();
    // Continuous calendar between first and last actual day (gaps = 0).
    const all: string[] = [];
    const d0 = new Date(days[0] + "T00:00:00Z");
    const d1 = new Date(days[days.length - 1] + "T00:00:00Z");
    for (let d = new Date(d0); d <= d1; d.setUTCDate(d.getUTCDate() + 1)) {
      all.push(d.toISOString().slice(0, 10));
    }
    const value = new Map<string, number>(); // `${day}|${module}`
    byModule.forEach((r) => value.set(`${r.day}|${r.module}`, r.total_tokens));
    const series: Record<string, number[]> = { overall: [] };
    active.forEach((m) => (series[m] = []));
    const rows: Record<string, number | string | null>[] = all.map((day) => {
      const row: Record<string, number | string | null> = { day };
      let overall = 0;
      active.forEach((m) => {
        const v = value.get(`${day}|${m}`) ?? 0;
        row[m] = v;
        series[m].push(v);
        overall += v;
      });
      row.overall = overall;
      series.overall.push(overall);
      return row;
    });
    // Dashed forecast: fit on the trailing 14 actual days, project 7 ahead.
    const last = all[all.length - 1];
    const pivot = rows[rows.length - 1];
    ["overall", ...active].forEach((k) => (pivot[`fc_${k}`] = pivot[k] as number));
    const fits: Record<string, { m: number; b: number; n: number }> = {};
    ["overall", ...active].forEach((k) => {
      const tail = series[k].slice(-14);
      fits[k] = { ...linReg(tail), n: tail.length };
    });
    const start = new Date(last + "T00:00:00Z");
    for (let i = 1; i <= FORECAST_DAYS; i++) {
      const d = new Date(start);
      d.setUTCDate(d.getUTCDate() + i);
      const row: Record<string, number | string | null> = { day: d.toISOString().slice(0, 10) };
      ["overall", ...active].forEach((k) => {
        const f = fits[k];
        row[`fc_${k}`] = Math.max(0, Math.round(f.m * (f.n - 1 + i) + f.b));
      });
      rows.push(row);
    }
    return { rows, lastDay: last };
  }, [byModule, active]);

  if (byModule.length === 0) {
    return <p className="py-6 text-center text-xs text-muted-foreground">No activity in this range.</p>;
  }

  const label = (k: string) => MODULE_LABEL[k] ?? k;

  return (
    <>
      <div className="mb-2 flex items-center justify-between gap-2">
        <p className="text-[10px] text-muted-foreground">
          Solid = actual per day · dashed = straight-line projection for the next {FORECAST_DAYS} days
          (fitted on the trailing 14). Overall is the sum of the selected modules.
        </p>
        <FilterDropdown
          label={picked.size === 0 ? "All modules" : `${picked.size} module${picked.size === 1 ? "" : "s"}`}
          icon={<LayersIcon className="h-3.5 w-3.5" />}
          options={modulesInData}
          optionLabel={label}
          selected={picked}
          onToggle={(m: string) =>
            setPicked((prev) => {
              const next = new Set(prev);
              if (next.has(m)) next.delete(m);
              else next.add(m);
              return next;
            })
          }
          onClear={() => setPicked(new Set())}
          width="w-72"
          align="right"
        />
      </div>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={rows} margin={{ top: 4, right: 8, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id="overallFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={OVERALL_COLOR} stopOpacity={0.25} />
                <stop offset="100%" stopColor={OVERALL_COLOR} stopOpacity={0.02} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="currentColor" opacity={0.08} />
            <XAxis dataKey="day" tick={{ fontSize: 10 }} tickFormatter={(d: string) => d.slice(5)} stroke="currentColor" opacity={0.5} />
            <YAxis tick={{ fontSize: 10 }} tickFormatter={(v: number) => fmtTokens(v)} stroke="currentColor" opacity={0.5} width={44} />
            <Tooltip
              formatter={(v: number, name: string) => {
                const fc = name.startsWith("fc_");
                const key = fc ? name.slice(3) : name;
                return [v.toLocaleString(), `${key === "overall" ? "Overall" : label(key)}${fc ? " (forecast)" : ""}`];
              }}
              labelFormatter={(d) => `Day: ${d}`}
              contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 12, fontSize: 11 }}
            />
            {lastDay && (
              <ReferenceLine x={lastDay} stroke="currentColor" opacity={0.35} strokeDasharray="4 4"
                label={{ value: "forecast →", position: "insideTopRight", fontSize: 9, opacity: 0.6 }} />
            )}
            <Area type="monotone" dataKey="overall" stroke={OVERALL_COLOR} strokeWidth={2.5} fill="url(#overallFill)" dot={false} />
            <Line type="monotone" dataKey="fc_overall" stroke={OVERALL_COLOR} strokeWidth={2.5} strokeDasharray="6 4" dot={false} />
            {active.map((m) => (
              <Line key={m} type="monotone" dataKey={m} stroke={MODULE_COLOR[m] ?? "#64748b"} strokeWidth={1.5} dot={false} />
            ))}
            {active.map((m) => (
              <Line key={`fc_${m}`} type="monotone" dataKey={`fc_${m}`} stroke={MODULE_COLOR[m] ?? "#64748b"} strokeWidth={1.5} strokeDasharray="5 4" dot={false} />
            ))}
          </ComposedChart>
        </ResponsiveContainer>
      </div>
      <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1">
        <span className="flex items-center gap-1.5 text-[10px] font-semibold" style={{ color: OVERALL_COLOR }}>
          <span className="h-0.5 w-4 rounded-full" style={{ backgroundColor: OVERALL_COLOR }} /> Overall
        </span>
        {active.map((m) => (
          <span key={m} className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
            <span className="h-0.5 w-4 rounded-full" style={{ backgroundColor: MODULE_COLOR[m] ?? "#64748b" }} />
            {label(m)}
          </span>
        ))}
      </div>
    </>
  );
}

// Deployments the static price map considers "premium" — used only to decide
// whether the cheaper-model-routing hint applies.
function isPremiumModel(m: string): boolean {
  const x = m.toLowerCase();
  if (x.includes("mini") || x.includes("nano") || x.includes("35-turbo")) return false;
  return x.includes("gpt-4") || x.startsWith("gpt-5") || x.startsWith("o3") || x.startsWith("o4");
}

// Operational advice derived from the CURRENT breakdown — each hint only
// appears when the data says it applies, so the panel reads as a to-do list
// for this deployment, not a generic best-practices poster.
function OptimizationHints({ data }: { data: TokenUsageSummary }) {
  const hints = useMemo(() => {
    const total = data.totals.total_tokens || 1;
    const moduleTokens = (keys: string[]) =>
      data.by_module.filter((m) => keys.includes(m.module)).reduce((s, m) => s + m.total_tokens, 0);
    const pct = (n: number) => Math.round((n / total) * 100);
    const out: { icon: React.ReactNode; title: string; body: string }[] = [];

    // Data-volume awareness — the rules below need history to be meaningful,
    // so say so while the ledger is young instead of over-reading one day.
    const days = data.timeline.length;
    if (days > 0 && days < 7) {
      out.push({
        icon: <TrendingUp className="h-3.5 w-3.5" />,
        title: `Early days — ${days} day${days === 1 ? "" : "s"} of metering so far`,
        body:
          "These hints and the forecast recompute automatically as usage accrues; with under a week of history they lean on composition (which modules/models spend) rather than trends. Expect trend and per-source advice to appear here once 1-2 weeks of data exist.",
      });
    }

    // Trend awareness — fitted slope over the trailing 14 days.
    if (days >= 5) {
      const tail = data.timeline.slice(-14).map((d) => d.total_tokens);
      const { m } = linReg(tail);
      const mean = tail.reduce((a, b) => a + b, 0) / tail.length;
      if (mean > 0 && m / mean >= 0.15) {
        out.push({
          icon: <TrendingUp className="h-3.5 w-3.5" />,
          title: `Spend is trending up ~${Math.round((m / mean) * 100)}% per day — review before scaling further`,
          body:
            "The forecast line above extrapolates this growth. Before ramping intake or team usage, apply the module hints below (shortlisting, cheaper per-module deployments) so the trend rises with hiring volume, not with waste.",
        });
      }
    }

    // Source concentration — one campaign dominating the attributed spend.
    const attributed = data.by_source.filter((x) => x.source !== "No source");
    const attributedTotal = attributed.reduce((sum, x) => sum + x.total_tokens, 0);
    if (attributed.length >= 2 && attributedTotal > 0) {
      const top = attributed[0];
      if (top.total_tokens / attributedTotal >= 0.6) {
        out.push({
          icon: <Tag className="h-3.5 w-3.5" />,
          title: `"${top.source}" drives ${Math.round((top.total_tokens / attributedTotal) * 100)}% of attributed spend`,
          body:
            "Filter this page to that source tag and sanity-check its pipeline: duplicate resumes re-entering, over-eager re-extraction, or a JD re-matched repeatedly all show up as one campaign outspending the rest. Its tokens-per-candidate should look like every other source's.",
        });
      }
    }

    const jd = moduleTokens(["jd_match", "jd_match_explain"]);
    if (jd / total >= 0.25) {
      out.push({
        icon: <FilterIcon className="h-3.5 w-3.5" />,
        title: `JD matching is ${pct(jd)}% of this spend — shortlist before you match`,
        body:
          "Every run resends EVERY filtered candidate's profile plus the full JD. Filter to a stream/stage/date shortlist first, trim the JD to its real requirements, and avoid re-running the same JD — results are session-only, so a page refresh + re-run pays the whole bill again. Ask for score explanations only on borderline candidates.",
      });
    }

    const chat = moduleTokens(["chatbot_sql", "chatbot_narration"]);
    if (chat / total >= 0.15) {
      out.push({
        icon: <Bot className="h-3.5 w-3.5" />,
        title: `Chatbot is ${pct(chat)}% of this spend — two LLM calls per question, for every user`,
        body:
          "Specific questions (\"GenAI freshers above ATS 70 from this source\") resolve in one round-trip; vague ones trigger retries and follow-ups. For repeat lookups, saved filters on Dashboard/Candidates are free — the chatbot is best for questions the UI can't already answer. If a team isn't using it, disable the launcher in Settings → Chatbot.",
      });
    }

    const extract = moduleTokens(["extraction", "analysis_report", "timeline"]);
    if (extract / total >= 0.4) {
      out.push({
        icon: <RefreshCw className="h-3.5 w-3.5" />,
        title: `Extraction & analysis is ${pct(extract)}% — spend it once per resume, not twice`,
        body:
          "This spend is proportional to resumes processed, so duplicates are pure waste — keep the per-source dup-check scoping right on Register Source, and archive retired sources so stale mail can't re-enter the funnel. Run \"Re-extract batch\" only after a prompt/scoring change, never as a routine refresh, and regenerate a single analysis report instead of a batch when only one candidate changed.",
      });
    }

    const iq = moduleTokens(["interview_questions"]);
    if (iq / total >= 0.2) {
      out.push({
        icon: <RefreshCw className="h-3.5 w-3.5" />,
        title: `Interview questions are ${pct(iq)}% — regenerate deliberately`,
        body:
          "Each Regenerate rebuilds the whole kit from scratch. Pick difficulty/focus/effort BEFORE generating rather than iterating through variants, and reuse the saved feedback-sheet questions across a round's candidates where the profile overlap is high.",
      });
    }

    const premium = data.by_model
      .filter((m) => isPremiumModel(m.model))
      .reduce((s, m) => s + m.total_tokens, 0);
    if (premium / total >= 0.5 && data.by_model.length > 0) {
      out.push({
        icon: <Route className="h-3.5 w-3.5" />,
        title: `${pct(premium)}% runs on premium models — route light modules to a cheaper deployment`,
        body:
          "Settings → LLM Model Keys → per-module overrides: chatbot queries, timeline parsing and JD batch scoring hold up well on a mini/nano-class deployment (roughly 5–15× cheaper per token), while extraction and analysis stay on the strong model where quality actually pays. The Token Usage modules map 1:1 to those overrides, so you can verify the effect here within a day.",
      });
    }

    const promptShare = data.totals.prompt_tokens / Math.max(1, data.totals.prompt_tokens + data.totals.completion_tokens);
    if (promptShare >= 0.75) {
      out.push({
        icon: <Scissors className="h-3.5 w-3.5" />,
        title: `${Math.round(promptShare * 100)}% of tokens are INPUT — trim what you send, not what you get back`,
        body:
          "The bill is dominated by what's sent to the model: long JDs, big candidate batches, verbose prompts. Shorter pasted text and smaller batches cut cost linearly; answer length barely matters here.",
      });
    }

    // Always-on floor: the two habits that keep spend visible and bounded.
    out.push({
      icon: <Lightbulb className="h-3.5 w-3.5" />,
      title: "Make spend part of the campaign routine",
      body:
        "Check this page weekly filtered per source tag — tokens-per-hire is a real campaign cost. In QA, rehearse flows on a handful of resumes (small batches, one JD), never a full production-size batch; the flows behave identically and the rehearsal costs cents.",
    });
    return out;
  }, [data]);

  return (
    <div className="surface px-4 py-4">
      <h2 className="mb-3 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-muted-foreground">
        <Lightbulb className="h-3.5 w-3.5" /> Optimization hints — derived from this view's data
      </h2>
      <p className="mb-3 text-[10px] text-muted-foreground">
        Recomputed live from whatever the current source/time filters show — new hints (trends,
        source concentration, seasonality) appear on their own as more usage data is gathered.
      </p>
      <div className="space-y-2.5">
        {hints.map((h, i) => (
          <div key={i} className="flex items-start gap-2.5 rounded-xl border border-border/50 bg-card/40 px-3 py-2.5">
            <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full border border-amber-500/30 bg-amber-500/10 text-amber-600">
              {h.icon}
            </span>
            <div className="min-w-0">
              <p className="text-[11px] font-semibold text-foreground">{h.title}</p>
              <p className="mt-0.5 text-[11px] leading-relaxed text-muted-foreground">{h.body}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function StatCard({
  icon,
  label,
  value,
  hint,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  hint?: string;
}) {
  return (
    <div className="surface flex items-center gap-3 px-4 py-3">
      <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-primary/25 bg-primary/10 text-primary">
        {icon}
      </span>
      <div className="min-w-0">
        <div className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">{label}</div>
        <div className="stat-value truncate text-lg font-extrabold tabular-nums text-foreground" title={hint}>
          {value}
        </div>
        {hint && <div className="truncate text-[10px] text-muted-foreground">{hint}</div>}
      </div>
    </div>
  );
}

export default function TokenUsage() {
  const [source, setSource] = useState(ALL);
  const [range, setRange] = useState<RangeKey>("30d");
  const [customFrom, setCustomFrom] = useState("");
  const [customTo, setCustomTo] = useState("");

  const { dateFrom, dateTo } = useMemo(() => {
    if (range === "custom") return { dateFrom: customFrom || undefined, dateTo: customTo || undefined };
    const preset = RANGES.find((r) => r.key === range);
    if (!preset?.days) return { dateFrom: undefined, dateTo: undefined };
    const from = new Date();
    from.setDate(from.getDate() - (preset.days - 1));
    return { dateFrom: isoDay(from), dateTo: undefined };
  }, [range, customFrom, customTo]);

  const { data, isLoading, isFetching } = useQuery({
    queryKey: ["token-usage", dateFrom ?? "", dateTo ?? "", source],
    queryFn: async () =>
      (
        await tokenUsageService.summary({
          date_from: dateFrom,
          date_to: dateTo,
          source: source === ALL ? undefined : source,
        })
      ).data,
  });

  const maxModule = Math.max(1, ...(data?.by_module ?? []).map((m) => m.total_tokens));
  const maxSource = Math.max(1, ...(data?.by_source ?? []).map((s) => s.total_tokens));
  const rangeLabel =
    range === "custom"
      ? [customFrom || "…", customTo || "today"].join(" → ")
      : RANGES.find((r) => r.key === range)?.label ?? "Last 30 days";

  return (
    <PageContainer className="flex h-full flex-col">
      <PageHeader
        title="Token Usage"
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <FilterDropdown
              label={source}
              icon={<Tag className="h-3.5 w-3.5" />}
              options={[ALL, ...(data?.sources ?? []).filter((s) => s !== ALL)]}
              selected={source === ALL ? new Set<string>() : new Set([source])}
              onToggle={(v: string) => setSource(v)}
              onClear={() => setSource(ALL)}
              width="w-52"
              single
              allowClear={false}
              searchable
              searchPlaceholder="Search sources…"
              searchLimit={12}
              align="right"
            />
            <FilterDropdown
              label={rangeLabel}
              icon={<CalendarRange className="h-3.5 w-3.5" />}
              options={[...RANGES.map((r) => r.label), "Custom range"]}
              selected={new Set([range === "custom" ? "Custom range" : rangeLabel])}
              onToggle={(v: string) =>
                setRange(v === "Custom range" ? "custom" : (RANGES.find((r) => r.label === v)?.key ?? "30d"))
              }
              onClear={() => setRange("30d")}
              width="w-44"
              single
              allowClear={false}
              align="right"
            />
            {range === "custom" && (
              <span className="flex items-center gap-1.5">
                <input
                  type="date"
                  value={customFrom}
                  onChange={(e) => setCustomFrom(e.target.value)}
                  className="rounded-lg border border-border bg-background px-2 py-1.5 text-xs text-foreground outline-none focus:border-primary/50"
                />
                <span className="text-xs text-muted-foreground">→</span>
                <input
                  type="date"
                  value={customTo}
                  onChange={(e) => setCustomTo(e.target.value)}
                  className="rounded-lg border border-border bg-background px-2 py-1.5 text-xs text-foreground outline-none focus:border-primary/50"
                />
              </span>
            )}
          </div>
        }
      />

      <div className="flex-1 space-y-4 overflow-auto pb-4">
        {isLoading ? (
          <div className="flex items-center justify-center gap-2 py-16 text-xs text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" /> Loading token usage…
          </div>
        ) : !data || data.totals.calls === 0 ? (
          <div className="surface flex flex-col items-center gap-2 px-6 py-14 text-center">
            <Coins className="h-8 w-8 text-muted-foreground/50" />
            <p className="text-sm font-semibold text-foreground">No LLM usage recorded for this view</p>
            <p className="max-w-md text-xs text-muted-foreground">
              Every LLM call (resume extraction, analysis reports, interview questions, JD matching,
              chatbot) is metered from the moment this feature shipped — adjust the source or time
              range, or process some resumes and check back.
            </p>
          </div>
        ) : (
          <>
            {/* Headline stats */}
            <div className={cn("grid gap-3 sm:grid-cols-2 lg:grid-cols-5", isFetching && "opacity-70")}>
              <StatCard
                icon={<Coins className="h-4 w-4" />}
                label="Total tokens"
                value={fmtTokens(data.totals.total_tokens)}
                hint={`${data.totals.total_tokens.toLocaleString()} tokens`}
              />
              <StatCard
                icon={<Activity className="h-4 w-4" />}
                label="LLM calls"
                value={data.totals.calls.toLocaleString()}
              />
              <StatCard
                icon={<ArrowDownToLine className="h-4 w-4" />}
                label="Prompt (input)"
                value={fmtTokens(data.totals.prompt_tokens)}
              />
              <StatCard
                icon={<ArrowUpFromLine className="h-4 w-4" />}
                label="Completion (output)"
                value={fmtTokens(data.totals.completion_tokens)}
              />
              <StatCard
                icon={<CircleDollarSign className="h-4 w-4" />}
                label="Est. cost"
                value={fmtCost(data.totals.est_cost_usd)}
                hint="static price map — estimate only"
              />
            </div>

            {/* Trend + forecast — line/area, overall + per-module, module multiselect */}
            <div className="surface px-4 py-4">
              <h2 className="mb-1 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-muted-foreground">
                <TrendingUp className="h-3.5 w-3.5" /> Consumption trend &amp; {FORECAST_DAYS}-day forecast
              </h2>
              <TrendForecastChart byModule={data.timeline_by_module} />
            </div>

            {/* Timeline */}
            <div className="surface px-4 py-4">
              <h2 className="mb-3 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-muted-foreground">
                <CalendarRange className="h-3.5 w-3.5" /> Daily consumption — prompt vs completion
              </h2>
              {data.timeline.length === 0 ? (
                <p className="py-6 text-center text-xs text-muted-foreground">No activity in this range.</p>
              ) : (
                <div className="h-56">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={data.timeline} margin={{ top: 4, right: 8, left: 0, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="currentColor" opacity={0.08} />
                      <XAxis
                        dataKey="day"
                        tick={{ fontSize: 10 }}
                        tickFormatter={(d: string) => d.slice(5)}
                        stroke="currentColor"
                        opacity={0.5}
                      />
                      <YAxis tick={{ fontSize: 10 }} tickFormatter={(v: number) => fmtTokens(v)} stroke="currentColor" opacity={0.5} width={44} />
                      <Tooltip
                        formatter={(v: number, name: string) => [
                          v.toLocaleString(),
                          name === "prompt_tokens" ? "Prompt" : "Completion",
                        ]}
                        labelFormatter={(d) => `Day: ${d}`}
                        contentStyle={{
                          background: "hsl(var(--card))",
                          border: "1px solid hsl(var(--border))",
                          borderRadius: 12,
                          fontSize: 11,
                        }}
                      />
                      <Bar dataKey="prompt_tokens" stackId="t" fill="#665efd" radius={[0, 0, 0, 0]} />
                      <Bar dataKey="completion_tokens" stackId="t" fill="#10b981" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </div>

            <div className="grid gap-4 lg:grid-cols-2">
              {/* Module breakdown — where the utilization happens */}
              <div className="surface px-4 py-4">
                <h2 className="mb-3 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-muted-foreground">
                  <Layers className="h-3.5 w-3.5" /> By module — where tokens are spent
                </h2>
                <div className="space-y-2.5">
                  {data.by_module.map((m) => {
                    const color = MODULE_COLOR[m.module] ?? "#64748b";
                    return (
                      <div key={m.module}>
                        <div className="mb-1 flex items-baseline justify-between gap-2 text-[11px]">
                          <span className="truncate font-medium text-foreground">
                            {MODULE_LABEL[m.module] ?? m.module}
                          </span>
                          <span className="shrink-0 tabular-nums text-muted-foreground">
                            {fmtTokens(m.total_tokens)} · {m.calls.toLocaleString()} call{m.calls === 1 ? "" : "s"} ·{" "}
                            <span className="font-semibold text-foreground">{fmtCost(m.est_cost_usd)}</span>
                          </span>
                        </div>
                        <div
                          className="h-2 overflow-hidden rounded-full bg-secondary/70"
                          title={`prompt ${m.prompt_tokens.toLocaleString()} · completion ${m.completion_tokens.toLocaleString()}`}
                        >
                          <div
                            className="h-full rounded-full transition-all duration-500"
                            style={{
                              width: `${Math.max(2, (m.total_tokens / maxModule) * 100)}%`,
                              backgroundImage: `linear-gradient(90deg, ${color}cc, ${color})`,
                            }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Source-tag breakdown */}
              <div className="surface px-4 py-4">
                <h2 className="mb-3 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-muted-foreground">
                  <Tag className="h-3.5 w-3.5" /> By source tag
                </h2>
                {data.by_source.length === 0 ? (
                  <p className="py-6 text-center text-xs text-muted-foreground">No attributed usage yet.</p>
                ) : (
                  <div className="space-y-2.5">
                    {data.by_source.map((s) => (
                      <div key={s.source}>
                        <div className="mb-1 flex items-baseline justify-between gap-2 text-[11px]">
                          <span className={cn("truncate font-medium", s.source === "No source" ? "text-muted-foreground" : "text-foreground")}>
                            {s.source}
                          </span>
                          <span className="shrink-0 tabular-nums text-muted-foreground">
                            {fmtTokens(s.total_tokens)} · {s.calls.toLocaleString()} call{s.calls === 1 ? "" : "s"}
                          </span>
                        </div>
                        <div className="h-2 overflow-hidden rounded-full bg-secondary/70">
                          <div
                            className="h-full rounded-full bg-gradient-to-r from-primary/70 to-primary transition-all duration-500"
                            style={{ width: `${Math.max(2, (s.total_tokens / maxSource) * 100)}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                )}
                <p className="mt-3 text-[10px] leading-relaxed text-muted-foreground/80">
                  "No source" covers calls with no candidate attribution (chatbot, JD batch scoring)
                  and candidates without a source tag. Attribution follows the candidate's CURRENT
                  tag, so re-tagging re-attributes past usage too.
                </p>
              </div>
            </div>

            {/* Model breakdown */}
            <div className="surface px-4 py-4">
              <h2 className="mb-3 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-muted-foreground">
                <Cpu className="h-3.5 w-3.5" /> By model deployment
              </h2>
              <div className="flex flex-wrap gap-2">
                {data.by_model.map((m) => (
                  <span
                    key={m.model}
                    className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1.5 text-[11px]"
                    title={`${m.total_tokens.toLocaleString()} tokens across ${m.calls} calls`}
                  >
                    <span className="font-semibold text-foreground">{m.model}</span>
                    <span className="tabular-nums text-muted-foreground">
                      {fmtTokens(m.total_tokens)} · {fmtCost(m.est_cost_usd)}
                    </span>
                  </span>
                ))}
              </div>
              <p className="mt-3 text-[10px] text-muted-foreground/80">
                Costs are estimated from a static $/1M-token price map by deployment name — use them
                to compare modules and campaigns, not as a bill.
              </p>
            </div>

            {/* Operational advice — computed from this view's actual breakdown */}
            <OptimizationHints data={data} />
          </>
        )}
      </div>
    </PageContainer>
  );
}
