import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Library,
  Loader2,
  ChevronDown,
  Users,
  CalendarClock,
  Layers,
  Trophy,
  Sparkles,
  ListChecks,
  Download,
  UserPlus,
  Info,
  FileText,
  X,
  Check,
  Copy,
  Trash2,
  Loader2 as Spinner,
  Lightbulb,
  Search,
  Wand2,
  UserMinus,
} from "lucide-react";
import {
  interviewService,
  MODE_BUCKET_LABEL,
  type QuestionBank,
  type AllocationSummary,
  type Leaderboard,
  type LeaderboardRow,
  type AllocationScopeEntry,
  type BulkCandidate,
  type InterviewOptions,
  type InterviewMode,
  type InterviewKit,
} from "@/services/interview";
import Pagination from "@/components/common/Pagination";
import { sourceTagsService } from "@/services/sourceTags";
import { settingsService } from "@/services/settings";
import { useAuth } from "@/context/AuthContext";
import { Link } from "react-router-dom";
import { cn, apiErrorMessage } from "@/lib/utils";
import { useConfirm } from "@/components/common/ConfirmProvider";
import PageHeader from "@/components/layout/PageHeader";
import PageContainer from "@/components/layout/PageContainer";
import InterviewQuestionsPanel from "@/components/candidate/InterviewQuestionsPanel";
import { Plus, RotateCcw } from "lucide-react";
import { ROUND_NAMES } from "@/constants";

// Rounds a bank can be scoped to when assigning to a cohort — every
// screening/interview stage except the terminal "Hired" outcome.
const ASSIGNABLE_ROUNDS = ROUND_NAMES.filter((r) => r !== "Hired");

const DIFF_CLS: Record<string, string> = {
  Easy: "text-emerald-600 bg-emerald-500/10 border-emerald-500/30",
  Medium: "text-blue-600 bg-blue-500/10 border-blue-500/30",
  Hard: "text-amber-600 bg-amber-500/10 border-amber-500/30",
  "Very Hard": "text-rose-600 bg-rose-500/10 border-rose-500/30",
};

// Names are stored upper-cased at intake; present them Title Cased in the UI.
function titleCase(s: string): string {
  return (s || "").toLowerCase().replace(/\b\p{L}/gu, (c) => c.toUpperCase());
}

function fmtDate(iso: string | null): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString(undefined, { day: "2-digit", month: "short", year: "numeric" });
}

function fmtDateTime(iso: string | null): string {
  if (!iso) return "not scheduled";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleString(undefined, { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
}

/**
 * Question Banks — the reusable, generic question sets saved from the "Generate
 * Interview Questions" panel. Lists every saved bank, previews its questions,
 * bulk-assigns a bank to a cohort (a source tag), and shows the per-bank
 * leaderboard (ranked by marks) with Excel export.
 */
export default function QuestionBanks() {
  const queryClient = useQueryClient();
  const { data: banks, isLoading, isError } = useQuery({
    queryKey: ["question-banks"],
    queryFn: async () => (await interviewService.listBanks()).data,
  });
  const { data: summary } = useQuery({
    queryKey: ["qb-allocation-summary"],
    queryFn: async () => (await interviewService.allocationSummary()).data.summary,
  });

  const totalQuestions = (banks ?? []).reduce((n, b) => n + (b.question_count || 0), 0);

  // Search (hero bar) + pagination. The query matches the MODULES that make up a
  // bank (its bucket names + layered mode labels) FIRST, then falls back to the
  // bank name — so you can find a set by what's in it, not just what it's called.
  const PAGE_SIZE = 8;
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  useEffect(() => setPage(1), [search]);
  const modulesText = (b: QuestionBank) =>
    [
      ...(b.buckets ?? []).map((x) => x.name),
      ...(b.modes ?? []).map((m) => MODE_BUCKET_LABEL[m as InterviewMode] ?? String(m)),
    ]
      .join(" · ")
      .toLowerCase();
  const filtered = useMemo(() => {
    const all = banks ?? [];
    const q = search.trim().toLowerCase();
    if (!q) return all;
    const byModule = all.filter((b) => modulesText(b).includes(q));
    const byName = all.filter((b) => !modulesText(b).includes(q) && (b.name ?? "").toLowerCase().includes(q));
    return [...byModule, ...byName];
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [banks, search]);
  const pageCount = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const curPage = Math.min(page, pageCount);
  const paged = filtered.slice((curPage - 1) * PAGE_SIZE, curPage * PAGE_SIZE);

  // The "General" generator — opened blank (new bank) or seeded from a bank
  // (Customise). It's the candidate-less InterviewQuestionsPanel; saving from it
  // adds a bank right here.
  const [genOpen, setGenOpen] = useState(false);
  const [genOptions, setGenOptions] = useState<InterviewOptions>({});
  const [genBase, setGenBase] = useState<string | undefined>(undefined);
  // When set (via Customize), the panel opens on the bank's EXACT saved questions
  // instead of generating a fresh kit. Cleared for a brand-new bank.
  const [genKit, setGenKit] = useState<InterviewKit | null>(null);
  const [reseeding, setReseeding] = useState(false);

  // Aptitude question modes to layer into a NEW bank — picked in the dropdown on
  // the "New question bank" split button (mirrors the candidate page's "Generate
  // Interview Questions" dropdown). Config-driven from Settings → Interview
  // Question Generation.
  const [genModes, setGenModes] = useState<Set<string>>(new Set());
  const [modesOpen, setModesOpen] = useState(false);
  const modesRef = useRef<HTMLDivElement>(null);
  const { data: modeOptions = [] } = useQuery({
    queryKey: ["interview-modes"],
    queryFn: async () => (await interviewService.getModes()).data.map((m) => ({ key: m.key, label: m.label })),
    staleTime: 60_000,
  });
  useEffect(() => {
    if (!modesOpen) return;
    const onDown = (e: MouseEvent) => {
      if (modesRef.current && !modesRef.current.contains(e.target as Node)) setModesOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [modesOpen]);

  const openNew = () => {
    setGenBase(undefined);
    setGenKit(null); // fresh generation
    setGenOptions({
      avoid_personalization: true,
      difficulty: "Medium",
      modes: [...genModes] as InterviewMode[],
    });
    setModesOpen(false);
    setGenOpen(true);
  };
  const openCustomize = (bank: QuestionBank) => {
    setGenBase(bank.name);
    // Restore the EXACT options the bank was saved with (composition mix, total,
    // excludes, effort, focus, difficulty). Older banks (saved before `options`
    // existed) fall back to what we can infer from modes/difficulty/stream.
    const saved = (bank.options ?? {}) as InterviewOptions;
    setGenOptions({
      avoid_personalization: true,
      difficulty: bank.difficulty ?? "Medium",
      stream: bank.stream ?? undefined,
      ...saved,
      modes: ((saved.modes && saved.modes.length ? saved.modes : bank.modes) ?? []) as InterviewMode[],
    });
    // Load the bank's EXACT questions + config; saving makes a new versioned bank.
    setGenKit({
      summary: (bank.summary as InterviewKit["summary"]) ?? {
        name: bank.name,
        stream: bank.stream ?? "",
        difficulty: bank.difficulty ?? "",
      },
      buckets: bank.buckets,
      sources: bank.sources,
    });
    setGenOpen(true);
  };
  const refresh = () => {
    queryClient.invalidateQueries({ queryKey: ["question-banks"] });
    queryClient.invalidateQueries({ queryKey: ["qb-allocation-summary"] });
  };
  const restoreSamples = async () => {
    setReseeding(true);
    try {
      await interviewService.reseedBanks();
      refresh();
    } finally {
      setReseeding(false);
    }
  };

  return (
    <PageContainer>
      <PageHeader
        title="Question Banks"
        actions={
          <div className="flex flex-wrap items-center gap-2">
            {banks && banks.length > 0 && (
              <div className="relative">
                <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
                <input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search by module or name…"
                  className="w-52 rounded-lg border border-border bg-card py-1.5 pl-8 pr-2.5 text-xs text-foreground outline-none placeholder:text-muted-foreground focus:border-primary/50"
                />
              </div>
            )}
            {banks && banks.length > 0 && (
              <div className="mr-1 hidden items-center gap-3 text-xs text-muted-foreground sm:flex">
                <span className="inline-flex items-center gap-1.5">
                  <Library className="h-3.5 w-3.5" /> {banks.length}
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <ListChecks className="h-3.5 w-3.5" /> {totalQuestions}
                </span>
              </div>
            )}
            <button
              type="button"
              onClick={restoreSamples}
              disabled={reseeding}
              title="Re-create the built-in sample question banks (only the ones that are missing)"
              className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-card px-3 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-secondary disabled:opacity-40"
            >
              {reseeding ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RotateCcw className="h-3.5 w-3.5" />}
              Restore samples
            </button>
            <div ref={modesRef} className="relative flex">
              <button
                type="button"
                onClick={openNew}
                className="inline-flex items-center gap-1.5 rounded-l-lg bg-primary px-3 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-primary/90"
              >
                <Plus className="h-3.5 w-3.5" /> New question bank
                {genModes.size > 0 && (
                  <span className="rounded-full bg-white/25 px-1.5 text-[10px] font-bold leading-4">
                    +{genModes.size}
                  </span>
                )}
              </button>
              <button
                type="button"
                onClick={() => setModesOpen((o) => !o)}
                title="Include aptitude question modes"
                className="flex items-center justify-center rounded-r-lg border-l border-white/25 bg-primary px-2 text-white transition-colors hover:bg-primary/90"
              >
                <ChevronDown className={cn("h-3.5 w-3.5 transition-transform", modesOpen && "rotate-180")} />
              </button>
              {modesOpen && (
                <div className="absolute right-0 top-full z-40 mt-1.5 w-80 rounded-xl border border-border bg-card p-1.5 shadow-lg">
                  <div className="px-2 py-1 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                    Include question modes
                  </div>
                  {modeOptions.length === 0 ? (
                    <div className="px-2 py-1.5 text-[11px] text-muted-foreground">
                      No question modes configured (Settings → Interview Question Generation).
                    </div>
                  ) : (
                    modeOptions.map((opt) => {
                      const active = genModes.has(opt.key);
                      return (
                        <button
                          key={opt.key}
                          type="button"
                          onClick={() =>
                            setGenModes((prev) => {
                              const next = new Set(prev);
                              if (next.has(opt.key)) next.delete(opt.key);
                              else next.add(opt.key);
                              return next;
                            })
                          }
                          className="flex w-full items-start gap-2 rounded-lg px-2 py-1.5 text-left text-xs text-foreground hover:bg-secondary"
                        >
                          <span
                            className={cn(
                              "mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded border transition-colors",
                              active ? "border-primary bg-primary text-white" : "border-border"
                            )}
                          >
                            {active && <Check className="h-3 w-3" />}
                          </span>
                          {opt.label}
                        </button>
                      );
                    })
                  )}
                  {genModes.size > 0 && (
                    <button
                      type="button"
                      onClick={() => setGenModes(new Set())}
                      className="mt-1 flex w-full items-center justify-between rounded-lg px-2 py-1 text-left text-[11px] font-medium text-muted-foreground hover:bg-secondary hover:text-foreground"
                    >
                      Clear selection
                      <X className="h-3 w-3" />
                    </button>
                  )}
                  <div className="mt-1.5 border-t border-border/60 px-2 pb-1 pt-1.5 text-[10px] leading-snug text-muted-foreground">
                    Selected modes are layered into the generated set. Pick modes, then{" "}
                    <b className="text-foreground">New question bank</b>.
                  </div>
                </div>
              )}
            </div>
          </div>
        }
      />
      <InterviewQuestionsPanel
        open={genOpen}
        candidateId="general"
        onClose={() => setGenOpen(false)}
        initialOptions={genOptions}
        initialKit={genKit}
        fetchFn={(o) => interviewService.generateGeneral(o).then((r) => r.data)}
        bankNameBase={genBase}
        onSaved={refresh}
      />
      {isLoading ? (
        <div className="flex items-center gap-2 py-16 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading question banks…
        </div>
      ) : isError ? (
        <div className="rounded-xl border border-rose-500/30 bg-rose-500/5 p-6 text-sm text-rose-600">
          Couldn't load question banks. Try refreshing.
        </div>
      ) : !banks || banks.length === 0 ? (
        <EmptyState />
      ) : filtered.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border bg-card/50 p-8 text-center text-sm text-muted-foreground">
          No question banks match “{search}”. Try a module (e.g. “SQL”, “DSA”) or part of the name.
        </div>
      ) : (
        <>
          <div className="space-y-3">
            {paged.map((b) => (
              <BankCard
                key={b.qb_id}
                bank={b}
                summary={summary?.[String(b.qb_id)]}
                onCustomize={() => openCustomize(b)}
              />
            ))}
          </div>
          <Pagination
            page={curPage}
            pageCount={pageCount}
            total={filtered.length}
            pageSize={PAGE_SIZE}
            startIndex={(curPage - 1) * PAGE_SIZE}
            onPage={setPage}
            itemLabel="banks"
            className="mt-4"
          />
        </>
      )}
    </PageContainer>
  );
}

function EmptyState() {
  return (
    <div className="flex flex-col items-center justify-center gap-3 rounded-2xl border border-dashed border-border bg-card/50 px-6 py-16 text-center">
      <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-secondary">
        <Library className="h-6 w-6 text-muted-foreground" />
      </div>
      <div className="text-sm font-semibold text-foreground">No question banks yet</div>
      <p className="max-w-md text-xs leading-relaxed text-muted-foreground">
        Open a candidate, click <span className="font-medium text-foreground">Generate Interview
        Questions</span>, turn on <span className="font-medium text-foreground">Avoid
        personalization</span> in the dropdown, then use{" "}
        <span className="inline-flex items-center gap-1 font-medium text-emerald-600">
          <Library className="h-3 w-3" /> Add to question bank
        </span>{" "}
        to save a reusable set here.
      </p>
    </div>
  );
}

type StageSummary = AllocationSummary[string] | undefined;

function StageBadges({ s }: { s: StageSummary }) {
  if (!s || s.total === 0) return null;
  const items: [string, number, string][] = [
    ["assigned", s.assigned, "border-sky-500/30 bg-sky-500/10 text-sky-600"],
    ["answering", s.in_progress, "border-amber-500/30 bg-amber-500/10 text-amber-600"],
    ["scored", s.scored, "border-emerald-500/30 bg-emerald-500/10 text-emerald-600"],
  ];
  return (
    <div className="flex flex-wrap items-center gap-1">
      {items
        .filter(([, n]) => n > 0)
        .map(([label, n, cls]) => (
          <span key={label} className={cn("rounded-full border px-1.5 py-0.5 text-[9px] font-semibold", cls)}>
            {n} {label}
          </span>
        ))}
      {s.avg_score_pct != null && (
        <span
          title="Average score across scored candidates"
          className="rounded-full border border-violet-500/30 bg-violet-500/10 px-1.5 py-0.5 text-[9px] font-semibold text-violet-600"
        >
          Avg {Math.round(s.avg_score_pct)}%
        </span>
      )}
    </div>
  );
}

// Which cohorts/rounds this bank is currently assigned to (source tag +
// optional round), so that's visible without opening the leaderboard.
function ScopeChips({ s }: { s: StageSummary }) {
  if (!s || !s.scope || s.scope.length === 0) return null;
  const label = (e: AllocationScopeEntry) => {
    const tag = e.source_tag || "No source tag";
    return e.round_name ? `${tag} · ${e.round_name}` : tag;
  };
  return (
    <div className="mt-1 flex flex-wrap items-center gap-1">
      {s.scope.map((e, i) => (
        <span
          key={i}
          className="inline-flex items-center gap-1 rounded-full border border-border/70 bg-secondary/40 px-1.5 py-0.5 text-[9px] font-medium text-muted-foreground"
        >
          <Users className="h-2.5 w-2.5" /> {label(e)} ({e.n})
        </span>
      ))}
    </div>
  );
}

function BankCard({
  bank,
  summary,
  onCustomize,
}: {
  bank: QuestionBank;
  summary: StageSummary;
  onCustomize: () => void;
}) {
  const confirm = useConfirm();
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [bulkOpen, setBulkOpen] = useState(false);
  const [boardOpen, setBoardOpen] = useState(false);
  const [busy, setBusy] = useState<null | "dup" | "del" | "enrich">(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [securedDelOpen, setSecuredDelOpen] = useState(false);

  // Enrich is an opt-in legacy/maintenance control (Settings → Legacy Features),
  // hidden by default. Shares the cache key the rest of the app reads, so it's a
  // single request regardless of how many cards render.
  const { data: legacy } = useQuery({
    queryKey: ["legacy-features-config"],
    queryFn: async () => (await settingsService.getLegacyFeatures()).data,
  });
  const showEnrich = !!legacy?.qb_enrich_button;
  const showDuplicate = !!legacy?.qb_duplicate_button;
  // Candidates are assigned (the leaderboard is active) → deleting the bank would
  // wipe their assignments + recorded responses, so it's blocked.
  const hasCandidates = (summary?.total ?? 0) > 0;

  // A bank needs enriching if any question still lacks a rubric (older banks
  // generated before hints/rubric/explanation existed).
  const needsEnrich = (bank.buckets ?? []).some((b) =>
    (b.questions ?? []).some((q) => !(q.answer_points && q.answer_points.length > 0))
  );

  const refresh = () => {
    queryClient.invalidateQueries({ queryKey: ["question-banks"] });
    queryClient.invalidateQueries({ queryKey: ["qb-allocation-summary"] });
  };

  const enrich = async () => {
    setBusy("enrich");
    setNotice(null);
    try {
      const { data } = await interviewService.enrichBank(bank.qb_id);
      setNotice(
        data.enriched > 0
          ? `Added hints, rubric & explanation to ${data.enriched} question(s).`
          : "Every question already has a rubric."
      );
      refresh();
    } catch {
      setNotice("Couldn't enrich this bank.");
    } finally {
      setBusy(null);
    }
  };

  const duplicate = async () => {
    setBusy("dup");
    setNotice(null);
    try {
      const { data } = await interviewService.duplicateBank(bank.qb_id);
      setNotice(`Created “${data.name}” — customise and it keeps that versioned name.`);
      refresh();
    } catch {
      setNotice("Couldn't duplicate this bank.");
    } finally {
      setBusy(null);
    }
  };

  const remove = async () => {
    // A bank that ever had a leaderboard needs the heightened 2-password flow
    // (even after a discard) — a modal, not a plain confirm.
    if (bank.had_allocations) {
      setSecuredDelOpen(true);
      return;
    }
    if (!(await confirm({ title: "Delete question bank?", message: `Delete “${bank.name}”? This can't be undone.`, confirmLabel: "Delete", danger: true }))) return;
    setBusy("del");
    try {
      await interviewService.deleteBank(bank.qb_id);
      refresh();
    } catch {
      setNotice("Couldn't delete this bank.");
      setBusy(null);
    }
  };

  return (
    <div className="overflow-hidden rounded-xl border border-border bg-card">
      <div className="flex items-start gap-3 p-4">
        <button type="button" onClick={() => setOpen((v) => !v)} className="flex min-w-0 flex-1 items-start gap-3 text-left">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-emerald-500/10 text-emerald-600">
            <Sparkles className="h-4.5 w-4.5" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-sm font-bold text-foreground">{bank.name}</span>
              <span className="inline-flex items-center gap-1 rounded-full border border-border px-2 py-0.5 text-[10px] text-muted-foreground">
                <ListChecks className="h-2.5 w-2.5" /> {bank.question_count} questions
              </span>
              {bank.difficulty && (
                <span className={cn("rounded-full border px-2 py-0.5 text-[10px] font-semibold", DIFF_CLS[bank.difficulty] ?? DIFF_CLS.Medium)}>
                  {bank.difficulty}
                </span>
              )}
              {bank.stream && (
                <span className="rounded-full border border-border px-2 py-0.5 text-[10px] text-muted-foreground">{bank.stream}</span>
              )}
              <StageBadges s={summary} />
            </div>
            <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-muted-foreground">
              <span className="inline-flex items-center gap-1">
                <CalendarClock className="h-3 w-3" /> {fmtDate(bank.created_at)}
              </span>
              {bank.created_by && (
                <span className="inline-flex items-center gap-1">
                  <Users className="h-3 w-3" /> {bank.created_by}
                </span>
              )}
            </div>
            {/* Composition — the modules that make up this bank, so you can pick
                by what's inside at a glance. Deliberately light + small. */}
            {bank.buckets && bank.buckets.length > 0 && (
              <div className="mt-1 text-[10.5px] font-light leading-snug text-muted-foreground/80">
                {bank.buckets.map((bkt) => `${bkt.name} (${bkt.questions.length})`).join("  ·  ")}
              </div>
            )}
            <ScopeChips s={summary} />
          </div>
          <ChevronDown className={cn("mt-1 h-4 w-4 shrink-0 text-muted-foreground transition-transform", open && "rotate-180")} />
        </button>
      </div>

      {/* Actions */}
      <div className="flex flex-wrap gap-2 border-t border-border/60 px-4 py-2.5">
        <button
          type="button"
          onClick={() => setBulkOpen(true)}
          className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-500/40 bg-emerald-500/10 px-2.5 py-1 text-[11px] font-semibold text-emerald-600 transition-colors hover:bg-emerald-500/20"
        >
          <UserPlus className="h-3.5 w-3.5" /> Assign to a cohort
        </button>
        <button
          type="button"
          onClick={() => setBoardOpen(true)}
          disabled={!bank.had_allocations}
          title={!bank.had_allocations ? "No candidates assigned yet" : "See the ranking of assigned candidates (including any removed)"}
          className="inline-flex items-center gap-1.5 rounded-lg border border-amber-500/40 bg-amber-500/10 px-2.5 py-1 text-[11px] font-semibold text-amber-600 transition-colors hover:bg-amber-500/20 disabled:opacity-40"
        >
          <Trophy className="h-3.5 w-3.5" /> Leaderboard
        </button>
        <button
          type="button"
          onClick={onCustomize}
          title="Check Answers / Customize — open this bank's exact questions, model answers, rubric & settings to review or tweak, then save as a new version"
          className="inline-flex items-center gap-1.5 rounded-lg border border-primary/30 bg-primary/5 px-2.5 py-1 text-[11px] font-semibold text-primary transition-colors hover:bg-primary/10"
        >
          <Sparkles className="h-3.5 w-3.5" /> Customize
        </button>
        {showEnrich && (
          <button
            type="button"
            onClick={enrich}
            disabled={busy !== null}
            title={
              needsEnrich
                ? "AI-add hints, a scoring rubric, and an explanation to questions that lack them"
                : "Every question already has a rubric — re-run to refresh"
            }
            className={cn(
              "inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1 text-[11px] font-semibold transition-colors disabled:opacity-40",
              needsEnrich
                ? "border-violet-500/40 bg-violet-500/10 text-violet-600 hover:bg-violet-500/20"
                : "border-border text-muted-foreground hover:bg-secondary"
            )}
          >
            {busy === "enrich" ? <Spinner className="h-3.5 w-3.5 animate-spin" /> : <Wand2 className="h-3.5 w-3.5" />}
            Enrich
          </button>
        )}
        {showDuplicate && (
          <button
            type="button"
            onClick={duplicate}
            disabled={busy !== null}
            title="Make a copy as the next version (name + Roman numeral)"
            className="inline-flex items-center gap-1.5 rounded-lg border border-border px-2.5 py-1 text-[11px] font-semibold text-foreground transition-colors hover:bg-secondary disabled:opacity-40"
          >
            {busy === "dup" ? <Spinner className="h-3.5 w-3.5 animate-spin" /> : <Copy className="h-3.5 w-3.5" />} Duplicate
          </button>
        )}
        <button
          type="button"
          onClick={remove}
          disabled={busy !== null || hasCandidates}
          title={
            hasCandidates
              ? "Can't delete — candidates are assigned and the leaderboard is active. Their responses would be lost. Remove the assignments first."
              : "Delete this question bank"
          }
          className="ml-auto inline-flex items-center gap-1.5 rounded-lg border border-border px-2.5 py-1 text-[11px] font-semibold text-muted-foreground transition-colors hover:bg-rose-500/10 hover:text-rose-500 disabled:cursor-not-allowed disabled:opacity-40"
        >
          {busy === "del" ? <Spinner className="h-3.5 w-3.5 animate-spin" /> : <Trash2 className="h-3.5 w-3.5" />} Delete
        </button>
      </div>
      {notice && <p className="px-4 pb-2 text-[11px] font-medium text-emerald-600">{notice}</p>}

      {open && (
        <div className="border-t border-border bg-secondary/20 px-4 py-4">
          <div className="mx-auto max-w-4xl space-y-6">
            {bank.buckets.map((bkt) => (
              <div key={bkt.name}>
                <div className="mb-2.5 flex items-center gap-2">
                  <Layers className="h-3.5 w-3.5 text-primary" />
                  <h4 className="text-xs font-bold uppercase tracking-wider text-foreground">{bkt.name}</h4>
                  <span className="rounded-full bg-secondary px-1.5 py-0.5 text-[10px] font-semibold text-muted-foreground">
                    {bkt.questions.length}
                  </span>
                  <div className="h-px flex-1 bg-border/60" />
                </div>
                <ol className="space-y-2.5">
                  {bkt.questions.map((q, i) => (
                    <li key={i} className="rounded-xl border border-border bg-card p-3.5 shadow-sm">
                      <div className="flex items-start gap-3">
                        <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-secondary text-[11px] font-bold tabular-nums text-muted-foreground">
                          {i + 1}
                        </span>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-start justify-between gap-3">
                            <p className="text-sm font-medium leading-relaxed text-foreground">{q.question}</p>
                            <span
                              className={cn(
                                "mt-0.5 shrink-0 rounded-full border px-2 py-0.5 text-[10px] font-semibold",
                                DIFF_CLS[q.difficulty] ?? DIFF_CLS.Medium
                              )}
                            >
                              {q.difficulty}
                            </span>
                          </div>
                          {q.why && (
                            <p className="mt-1.5 flex items-start gap-1.5 text-xs leading-relaxed text-muted-foreground">
                              <Lightbulb className="mt-0.5 h-3 w-3 shrink-0 text-amber-500" />
                              <span>{q.why}</span>
                            </p>
                          )}
                        </div>
                      </div>
                    </li>
                  ))}
                </ol>
              </div>
            ))}
          </div>
        </div>
      )}

      {bulkOpen && <BulkAssignModal bank={bank} onClose={() => setBulkOpen(false)} />}
      {boardOpen && <LeaderboardModal bank={bank} onClose={() => setBoardOpen(false)} />}
      {securedDelOpen && (
        <SecuredDeleteModal bank={bank} onClose={() => setSecuredDelOpen(false)} onDeleted={() => { setSecuredDelOpen(false); refresh(); }} />
      )}
    </div>
  );
}

function BulkAssignModal({ bank, onClose }: { bank: QuestionBank; onClose: () => void }) {
  const queryClient = useQueryClient();
  const { data: tagsData } = useQuery({
    queryKey: ["source-tags"],
    queryFn: async () => (await sourceTagsService.list()).data,
  });
  const [tag, setTag] = useState<string>("");
  const [rounds, setRounds] = useState<Set<string>>(new Set());
  const [candidates, setCandidates] = useState<BulkCandidate[]>([]);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const toggleRound = (r: string) =>
    setRounds((prev) => {
      const next = new Set(prev);
      if (next.has(r)) next.delete(r);
      else next.add(r);
      return next;
    });

  const loadCandidates = async (t: string, roundList: string[]) => {
    setLoading(true);
    setError(null);
    try {
      const { data } = await interviewService.bankCandidates(bank.qb_id, t || null, roundList);
      setCandidates(data.candidates);
      // Default-select those not yet assigned to THIS bank.
      setSelected(new Set(data.candidates.filter((c) => !c.assigned_to_this).map((c) => c.candidate_id)));
    } catch (e) {
      setError(apiErrorMessage(e, "Couldn't load candidates for this tag."));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (tag) void loadCandidates(tag, [...rounds]);
    else {
      setCandidates([]);
      setSelected(new Set());
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tag, rounds]);

  const allSelected = candidates.length > 0 && selected.size === candidates.length;
  const toggleAll = () =>
    setSelected(allSelected ? new Set() : new Set(candidates.map((c) => c.candidate_id)));
  const toggle = (id: string) =>
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });

  const assign = async () => {
    if (selected.size === 0) return;
    setBusy(true);
    setError(null);
    try {
      const { data } = await interviewService.bulkAllocate(bank.qb_id, {
        source_tag: tag || null,
        candidate_ids: [...selected],
        round_names: rounds.size ? [...rounds] : undefined,
      });
      queryClient.invalidateQueries({ queryKey: ["qb-allocation-summary"] });
      setNotice(`Assigned “${bank.name}” to ${data.allocated} candidate${data.allocated === 1 ? "" : "s"}.`);
      await loadCandidates(tag, [...rounds]);
    } catch (e) {
      setError(apiErrorMessage(e, "Couldn't assign the question bank."));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal onClose={onClose} title={`Assign “${bank.name}” to a cohort`} icon={UserPlus}>
      <p className="text-[11px] text-muted-foreground">
        Pick a source tag to assign this bank to its candidates. It's reserved for each candidate's
        interviewer (not shown to the candidate). Bind happens when their interview slot invite is sent.
      </p>
      <div className="mt-3">
        <label className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Source tag</label>
        <select
          value={tag}
          onChange={(e) => setTag(e.target.value)}
          className="mt-1 w-full rounded-lg border border-border bg-background px-2.5 py-1.5 text-xs text-foreground outline-none focus:border-primary/50"
        >
          <option value="">Select a source tag…</option>
          {(tagsData?.tags ?? []).map((t) => (
            <option key={t.id} value={t.label}>
              {t.label} ({t.platform})
            </option>
          ))}
        </select>
      </div>

      <div className="mt-3">
        <label className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
          Round (optional)
        </label>
        <div className="mt-1 flex flex-wrap gap-1.5">
          {ASSIGNABLE_ROUNDS.map((r) => {
            const on = rounds.has(r);
            return (
              <button
                key={r}
                type="button"
                onClick={() => toggleRound(r)}
                className={cn(
                  "rounded-full border px-2.5 py-1 text-[11px] font-semibold transition-colors",
                  on
                    ? "border-primary bg-primary/10 text-primary"
                    : "border-border text-muted-foreground hover:bg-secondary"
                )}
              >
                {r}
              </button>
            );
          })}
        </div>
        <p className="mt-1 text-[10px] text-muted-foreground">
          {rounds.size === 0
            ? "Applies to all candidates under this tag."
            : `Only candidates currently in: ${[...rounds].join(", ")}.`}
        </p>
      </div>

      {loading ? (
        <div className="mt-3 flex items-center gap-2 py-4 text-xs text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading candidates…
        </div>
      ) : tag && candidates.length === 0 ? (
        <p className="mt-3 py-3 text-center text-[11px] text-muted-foreground">No candidates under this source tag.</p>
      ) : candidates.length > 0 ? (
        <div className="mt-3">
          <div className="mb-1.5 flex items-center justify-between">
            <button type="button" onClick={toggleAll} className="text-[11px] font-semibold text-primary hover:underline">
              {allSelected ? "Clear all" : "Select all"} ({selected.size}/{candidates.length})
            </button>
          </div>
          <div className="max-h-56 space-y-1 overflow-auto rounded-lg border border-border/60 p-1.5">
            {candidates.map((c) => {
              const on = selected.has(c.candidate_id);
              return (
                <button
                  key={c.candidate_id}
                  type="button"
                  onClick={() => toggle(c.candidate_id)}
                  className="flex w-full items-center gap-2 rounded-md px-2 py-1 text-left text-xs hover:bg-secondary"
                >
                  <span className={cn("flex h-4 w-4 shrink-0 items-center justify-center rounded border", on ? "border-primary bg-primary text-white" : "border-border")}>
                    {on && <Check className="h-3 w-3" />}
                  </span>
                  <span className="min-w-0 flex-1 truncate text-foreground">{c.name || c.candidate_id}</span>
                  {c.assigned_to_this ? (
                    <span className="shrink-0 text-[9px] font-semibold text-emerald-600">assigned</span>
                  ) : c.assigned_qb_id ? (
                    <span className="shrink-0 text-[9px] text-amber-600">other bank</span>
                  ) : null}
                </button>
              );
            })}
          </div>
        </div>
      ) : null}

      {error && <p className="mt-2 text-[11px] font-medium text-rose-500">{error}</p>}
      {notice && <p className="mt-2 text-[11px] font-medium text-emerald-600">{notice}</p>}

      <div className="mt-4 flex justify-end gap-2">
        <button type="button" onClick={onClose} className="rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-foreground hover:bg-secondary">
          Close
        </button>
        <button
          type="button"
          onClick={assign}
          disabled={busy || selected.size === 0}
          className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-emerald-700 disabled:opacity-40"
        >
          {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <UserPlus className="h-3.5 w-3.5" />}
          Assign {selected.size > 0 ? `(${selected.size})` : ""}
        </button>
      </div>
    </Modal>
  );
}

function LeaderboardModal({ bank, onClose }: { bank: QuestionBank; onClose: () => void }) {
  const queryClient = useQueryClient();
  const confirm = useConfirm();
  const { data, isLoading } = useQuery({
    queryKey: ["qb-leaderboard", bank.qb_id],
    queryFn: async () => (await interviewService.leaderboard(bank.qb_id)).data as Leaderboard,
  });
  const [exporting, setExporting] = useState(false);
  const [removingId, setRemovingId] = useState<number | null>(null);
  // Leaderboard drill-down — the (i) opens this candidate's full response sheet.
  const [sheetAlloc, setSheetAlloc] = useState<number | null>(null);
  // Clear & discard flow — irreversible, so it forces an Excel export first,
  // then the caller's password, then a confirm.
  const [discardOpen, setDiscardOpen] = useState(false);
  const [downloaded, setDownloaded] = useState(false);
  const [pw, setPw] = useState("");
  const [discarding, setDiscarding] = useState(false);
  const [discardErr, setDiscardErr] = useState<string | null>(null);

  const exportXlsx = async () => {
    setExporting(true);
    try {
      await interviewService.downloadLeaderboardXlsx(bank.qb_id, bank.name);
      setDownloaded(true);
    } finally {
      setExporting(false);
    }
  };

  const removeRow = async (row: LeaderboardRow) => {
    const ok = await confirm({
      title: "Remove this candidate?",
      message: `Remove ${titleCase(row.candidate_name)} from “${bank.name}”'s leaderboard? Their row is kept, marked as removed — any recorded responses/marks are not deleted.`,
      confirmLabel: "Remove",
      danger: true,
    });
    if (!ok) return;
    setRemovingId(row.allocation_id);
    try {
      await interviewService.removeAllocationRow(bank.qb_id, row.allocation_id);
      queryClient.invalidateQueries({ queryKey: ["qb-leaderboard", bank.qb_id] });
      queryClient.invalidateQueries({ queryKey: ["qb-allocation-summary"] });
    } finally {
      setRemovingId(null);
    }
  };

  const doDiscard = async () => {
    setDiscarding(true);
    setDiscardErr(null);
    try {
      await interviewService.discardLeaderboard(bank.qb_id, pw);
      queryClient.invalidateQueries({ queryKey: ["question-banks"] });
      queryClient.invalidateQueries({ queryKey: ["qb-allocation-summary"] });
      queryClient.invalidateQueries({ queryKey: ["qb-leaderboard", bank.qb_id] });
      onClose();
    } catch (e) {
      setDiscardErr(apiErrorMessage(e, "Couldn't discard the leaderboard."));
    } finally {
      setDiscarding(false);
    }
  };

  return (
    <Modal onClose={onClose} title={`Leaderboard — ${bank.name}`} icon={Trophy} wide>
      {discardOpen ? (
        <div className="space-y-3">
          <div className="rounded-lg border border-rose-500/30 bg-rose-500/5 p-3">
            <div className="flex items-center gap-1.5 text-xs font-bold text-rose-700 dark:text-rose-300">
              <Trash2 className="h-4 w-4" /> Clear &amp; discard this leaderboard
            </div>
            <p className="mt-1 text-[11px] leading-relaxed text-muted-foreground">
              This permanently deletes <b>all {data?.summary.total ?? ""} assignments and every recorded
              response &amp; mark</b> for “{bank.name}”. This is <b className="text-rose-600">NOT restorable</b> —
              download and keep the Excel first.
            </p>
          </div>
          <button
            type="button"
            onClick={exportXlsx}
            disabled={exporting}
            className={cn(
              "inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-semibold transition-colors disabled:opacity-40",
              downloaded ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-600" : "border-primary/40 bg-primary/5 text-primary hover:bg-primary/10"
            )}
          >
            {exporting ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : downloaded ? <Check className="h-3.5 w-3.5" /> : <Download className="h-3.5 w-3.5" />}
            {downloaded ? "Excel downloaded" : "Download Excel (required first)"}
          </button>
          <div>
            <label className="text-[11px] font-medium text-foreground">Confirm with your password</label>
            <input
              type="password"
              value={pw}
              onChange={(e) => setPw(e.target.value)}
              autoComplete="current-password"
              placeholder="Your account password"
              className="mt-1 w-full rounded-lg border border-border bg-background px-2.5 py-1.5 text-xs text-foreground outline-none focus:border-primary/50"
            />
          </div>
          {discardErr && <p className="text-[11px] font-medium text-rose-500">{discardErr}</p>}
          <div className="flex items-center justify-end gap-2 pt-1">
            <button
              type="button"
              onClick={() => { setDiscardOpen(false); setPw(""); setDiscardErr(null); }}
              className="rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-foreground hover:bg-secondary"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={doDiscard}
              disabled={!downloaded || !pw.trim() || discarding}
              title={!downloaded ? "Download the Excel first" : !pw.trim() ? "Enter your password" : undefined}
              className="inline-flex items-center gap-1.5 rounded-lg border border-rose-500 bg-rose-500 px-3 py-1.5 text-xs font-semibold text-white hover:bg-rose-600 disabled:opacity-40"
            >
              {discarding ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Trash2 className="h-3.5 w-3.5" />}
              Discard leaderboard
            </button>
          </div>
        </div>
      ) : isLoading ? (
        <div className="flex items-center gap-2 py-8 text-xs text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading leaderboard…
        </div>
      ) : !data || data.rows.length === 0 ? (
        <p className="py-6 text-center text-[11px] text-muted-foreground">No candidates assigned to this bank yet.</p>
      ) : (
        <>
          <div className="mb-2 flex items-center justify-between gap-2">
            <div className="text-[11px] text-muted-foreground">
              {data.summary.total} assigned · {data.summary.scored} scored · {data.summary.in_progress} answering
              {data.summary.removed > 0 && <> · {data.summary.removed} removed</>}
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={exportXlsx}
                disabled={exporting}
                className="inline-flex items-center gap-1.5 rounded-lg border border-border px-2.5 py-1 text-[11px] font-semibold text-foreground hover:bg-secondary disabled:opacity-40"
              >
                {exporting ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Download className="h-3.5 w-3.5" />}
                Export Excel
              </button>
              <button
                type="button"
                onClick={() => setDiscardOpen(true)}
                title="Permanently clear this leaderboard (assignments + responses)"
                className="inline-flex items-center gap-1.5 rounded-lg border border-rose-500/40 bg-rose-500/10 px-2.5 py-1 text-[11px] font-semibold text-rose-600 hover:bg-rose-500/20"
              >
                <Trash2 className="h-3.5 w-3.5" /> Clear &amp; Discard
              </button>
            </div>
          </div>
          <div className="max-h-[55vh] overflow-auto rounded-lg border border-border/60">
            <table className="w-full text-left text-xs">
              <thead className="sticky top-0 bg-secondary/60 text-[10px] uppercase tracking-wide text-muted-foreground">
                <tr>
                  <th className="px-2 py-1.5 font-semibold">#</th>
                  <th className="px-2 py-1.5 font-semibold">Candidate</th>
                  <th className="px-2 py-1.5 text-right font-semibold">Mark</th>
                  <th className="px-2 py-1.5 text-center font-semibold">Answered</th>
                  <th className="px-2 py-1.5 font-semibold">Status</th>
                  <th className="px-2 py-1.5 font-semibold" />
                </tr>
              </thead>
              <tbody>
                {data.rows.map((r) => {
                  const removed = r.status === "removed";
                  return (
                  <tr key={r.allocation_id} className={cn("border-t border-border/50", removed && "opacity-60")}>
                    <td className="px-2 py-1.5 font-semibold tabular-nums text-muted-foreground">
                      {r.rank ? (r.rank <= 3 ? ["🥇", "🥈", "🥉"][r.rank - 1] : r.rank) : "—"}
                    </td>
                    <td className="px-2 py-1.5">
                      <Link
                        to={`/candidates/${r.candidate_id}`}
                        title="Open candidate profile"
                        className={cn("font-medium text-primary hover:underline", removed && "line-through decoration-muted-foreground/50")}
                      >
                        {titleCase(r.candidate_name)}
                      </Link>
                      <span className="ml-1 text-[10px] text-muted-foreground">{r.candidate_id}</span>
                    </td>
                    <td className="px-2 py-1.5 text-right font-semibold tabular-nums text-foreground">
                      {r.scored ? `${r.total_mark}/${r.max_mark}` : "—"}
                    </td>
                    <td className="px-2 py-1.5 text-center tabular-nums text-muted-foreground">
                      {r.answered}/{r.questions_total}
                    </td>
                    <td className="px-2 py-1.5">
                      <span
                        title={removed ? `Removed${r.removed_by ? ` by ${r.removed_by}` : ""}${r.removed_at ? ` · ${fmtDateTime(r.removed_at)}` : ""}` : undefined}
                        className={cn(
                          "inline-flex items-center gap-1 rounded-full border px-1.5 py-0.5 text-[9px] font-semibold",
                          removed
                            ? "border-border bg-secondary text-muted-foreground"
                            : r.status === "scored"
                              ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-600"
                              : r.status === "in_progress"
                                ? "border-amber-500/30 bg-amber-500/10 text-amber-600"
                                : "border-sky-500/30 bg-sky-500/10 text-sky-600"
                        )}
                      >
                        {removed && <UserMinus className="h-2.5 w-2.5" />}
                        {removed ? "removed" : r.status === "in_progress" ? "answering" : r.status}
                      </span>
                    </td>
                    <td className="px-2 py-1.5">
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => setSheetAlloc(r.allocation_id)}
                          className="inline-flex rounded p-0.5 text-muted-foreground transition-colors hover:bg-secondary hover:text-primary"
                          title={`View full response — Interviewer: ${r.interviewer || "—"} · Round: ${r.round_name || "—"} · Slot: ${fmtDateTime(r.slot_start)}`}
                        >
                          <Info className="h-3.5 w-3.5" />
                        </button>
                        {!removed && (
                          <button
                            type="button"
                            onClick={() => void removeRow(r)}
                            disabled={removingId === r.allocation_id}
                            className="inline-flex rounded p-0.5 text-muted-foreground transition-colors hover:bg-rose-500/10 hover:text-rose-500 disabled:opacity-40"
                            title="Remove this candidate's assignment"
                          >
                            {removingId === r.allocation_id ? (
                              <Loader2 className="h-3.5 w-3.5 animate-spin" />
                            ) : (
                              <UserMinus className="h-3.5 w-3.5" />
                            )}
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </>
      )}
      {sheetAlloc != null && (
        <ResponseSheetModal
          qbId={bank.qb_id}
          allocationId={sheetAlloc}
          onClose={() => setSheetAlloc(null)}
        />
      )}
    </Modal>
  );
}

// Leaderboard drill-down: one candidate's FULL interview response sheet — every
// bank question with their answer + mark, the model answer, rubric and
// explanation. Works for a partial interview (blank/unanswered questions) as
// well as a completed one, and surfaces the interviewer + round + slot up top.
function ResponseSheetModal({
  qbId,
  allocationId,
  onClose,
}: {
  qbId: number;
  allocationId: number;
  onClose: () => void;
}) {
  const { data, isLoading } = useQuery({
    queryKey: ["qb-response-sheet", qbId, allocationId],
    queryFn: async () => (await interviewService.allocationResponses(qbId, allocationId)).data,
  });
  const statusLabel = (s: string) => (s === "in_progress" ? "answering" : s);
  return (
    <Modal
      onClose={onClose}
      title={data ? `Response — ${titleCase(data.candidate_name)}` : "Response"}
      icon={FileText}
      wide
    >
      {isLoading || !data ? (
        <div className="flex items-center gap-2 py-10 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading response…
        </div>
      ) : (
        <div className="space-y-3">
          {/* Interview meta — interviewer, round, slot, status, running total. */}
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 rounded-lg border border-border/60 bg-secondary/40 px-3 py-2 text-xs">
            <span className="text-muted-foreground">
              Interviewer:{" "}
              <span className="font-medium text-foreground">{data.interviewer || "—"}</span>
            </span>
            <span className="text-muted-foreground">
              Round: <span className="font-medium text-foreground">{data.round_name || "—"}</span>
            </span>
            <span className="text-muted-foreground">
              Slot: <span className="font-medium text-foreground">{fmtDateTime(data.slot_start)}</span>
            </span>
            <span className="text-muted-foreground">
              Status: <span className="font-medium text-foreground">{statusLabel(data.status)}</span>
            </span>
            <span className="ml-auto font-semibold tabular-nums text-foreground">
              {data.answered}/{data.questions_total} answered
              {data.status === "scored" && ` · ${data.total_mark}/${data.max_mark}`}
            </span>
          </div>

          <div className="max-h-[58vh] space-y-2.5 overflow-y-auto pr-1">
            {data.items.map((it) => (
              <div key={it.index} className="rounded-lg border border-border/60 p-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    {it.bucket && (
                      <span className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                        {it.bucket}
                      </span>
                    )}
                    <p className="text-sm font-medium text-foreground">
                      {it.index + 1}. {it.question}
                    </p>
                  </div>
                  <span className="shrink-0 rounded-full bg-secondary px-2 py-0.5 text-xs font-semibold tabular-nums">
                    {it.final_mark != null || it.mark_locked
                      ? `${Number(it.final_mark ?? 0)}/${Number(it.max_mark)}`
                      : `—/${Number(it.max_mark)}`}
                  </span>
                </div>

                {/* Candidate's answer — the heart of the drill-down. */}
                <div className="mt-2 rounded-md bg-secondary/50 px-2.5 py-2">
                  <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                    Candidate response
                  </p>
                  <p className="whitespace-pre-wrap text-xs text-foreground">
                    {it.response_text?.trim() || (
                      <span className="italic text-muted-foreground">Not answered</span>
                    )}
                  </p>
                  {it.observation?.trim() && (
                    <p className="mt-1.5 text-[11px] text-muted-foreground">
                      <span className="font-semibold">Observation:</span> {it.observation}
                    </p>
                  )}
                </div>

                {/* Model answer + rubric + explanation (recruiter-visible). */}
                {it.strong_answer?.trim() && (
                  <details className="mt-2 text-xs">
                    <summary className="cursor-pointer font-medium text-primary">Model answer & rubric</summary>
                    <p className="mt-1 whitespace-pre-wrap text-foreground">{it.strong_answer}</p>
                    {it.answer_points.length > 0 && (
                      <ul className="mt-1.5 space-y-0.5">
                        {it.answer_points.map((p, i) => (
                          <li key={i} className="flex items-start gap-1.5 text-muted-foreground">
                            <span className="tabular-nums font-semibold text-foreground">
                              {p.marks}
                            </span>
                            <span>{p.point}</span>
                          </li>
                        ))}
                      </ul>
                    )}
                    {it.explanation?.trim() && (
                      <p className="mt-1.5 text-[11px] text-muted-foreground">
                        <span className="font-semibold">Explanation:</span> {it.explanation}
                      </p>
                    )}
                  </details>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </Modal>
  );
}

// Heightened, non-restorable delete for a bank that once had an active leaderboard:
// a Sysadmin's credentials AND the logged-in user's own password, both verified
// server-side. The bank's leaderboard must already be discarded (enforced server-side).
function SecuredDeleteModal({
  bank,
  onClose,
  onDeleted,
}: {
  bank: QuestionBank;
  onClose: () => void;
  onDeleted: () => void;
}) {
  const { user } = useAuth();
  const [saEmail, setSaEmail] = useState("");
  const [saPw, setSaPw] = useState("");
  const [myPw, setMyPw] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const submit = async () => {
    setBusy(true);
    setErr(null);
    try {
      await interviewService.deleteBank(bank.qb_id, {
        sysadmin_email: saEmail.trim(),
        sysadmin_password: saPw,
        user_password: myPw,
      });
      onDeleted();
    } catch (e) {
      setErr(apiErrorMessage(e, "Couldn't delete this bank."));
    } finally {
      setBusy(false);
    }
  };

  const fieldCls =
    "mt-1 w-full rounded-lg border border-border bg-background px-2.5 py-1.5 text-xs text-foreground outline-none focus:border-primary/50";

  return (
    <Modal onClose={onClose} title={`Delete “${bank.name}”`} icon={Trash2}>
      <div className="space-y-3">
        <div className="rounded-lg border border-rose-500/30 bg-rose-500/5 p-3 text-[11px] leading-relaxed text-muted-foreground">
          This bank had an active leaderboard. Deleting it is{" "}
          <b className="text-rose-600">permanent and not restorable</b>. It needs a{" "}
          <b>Sysadmin</b>'s credentials <b>and</b> your own password.
        </div>
        <div>
          <label className="text-[11px] font-medium text-foreground">Sysadmin email</label>
          <input value={saEmail} onChange={(e) => setSaEmail(e.target.value)} placeholder="sysadmin@company.com" className={fieldCls} />
        </div>
        <div>
          <label className="text-[11px] font-medium text-foreground">Sysadmin password</label>
          <input type="password" value={saPw} onChange={(e) => setSaPw(e.target.value)} autoComplete="off" className={fieldCls} />
        </div>
        <div>
          <label className="text-[11px] font-medium text-foreground">Your password{user?.email ? ` (${user.email})` : ""}</label>
          <input type="password" value={myPw} onChange={(e) => setMyPw(e.target.value)} autoComplete="current-password" className={fieldCls} />
        </div>
        {err && <p className="text-[11px] font-medium text-rose-500">{err}</p>}
        <div className="flex items-center justify-end gap-2 pt-1">
          <button type="button" onClick={onClose} className="rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-foreground hover:bg-secondary">
            Cancel
          </button>
          <button
            type="button"
            onClick={submit}
            disabled={busy || !saEmail.trim() || !saPw || !myPw}
            className="inline-flex items-center gap-1.5 rounded-lg border border-rose-500 bg-rose-500 px-3 py-1.5 text-xs font-semibold text-white hover:bg-rose-600 disabled:opacity-40"
          >
            {busy ? <Spinner className="h-3.5 w-3.5 animate-spin" /> : <Trash2 className="h-3.5 w-3.5" />}
            Delete permanently
          </button>
        </div>
      </div>
    </Modal>
  );
}

function Modal({
  title,
  icon: Icon,
  onClose,
  wide,
  children,
}: {
  title: string;
  icon: React.ElementType;
  onClose: () => void;
  wide?: boolean;
  children: React.ReactNode;
}) {
  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-foreground/40 p-4 backdrop-blur-sm" onClick={onClose}>
      <div
        className={cn("w-full rounded-2xl border border-border bg-card p-5 shadow-2xl", wide ? "max-w-2xl" : "max-w-md")}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-3 flex items-start justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-secondary text-muted-foreground">
              <Icon className="h-4 w-4" />
            </span>
            <h3 className="text-sm font-bold text-foreground">{title}</h3>
          </div>
          <button type="button" onClick={onClose} className="rounded-lg p-1 text-muted-foreground hover:bg-secondary hover:text-foreground">
            <X className="h-4 w-4" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}
