import { useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import {
  AlertTriangle,
  CheckCircle2,
  RefreshCw,
  XCircle,
  Loader2,
  Download,
  ChevronDown,
  Calendar,
  X,
  ShieldAlert,
} from "lucide-react";
import { auditService } from "@/services/audit";
import { pipelineService } from "@/services/pipeline";
import { emailsService } from "@/services/emails";
import { candidatesService } from "@/services/candidates";
import { cn, titleCase } from "@/lib/utils";
import PageHeader from "@/components/layout/PageHeader";
import PageContainer from "@/components/layout/PageContainer";
import Pagination from "@/components/common/Pagination";
import { usePagination } from "@/hooks/usePagination";
import { useAuth } from "@/context/AuthContext";
import type { AuditLog, AuditStatus } from "@/types/audit";
import type { EmailMaster } from "@/types/email";

const STATUS_CONFIG: Record<AuditStatus, { color: string; icon: React.ElementType }> = {
  Success: { color: "text-emerald-500 bg-emerald-400/10 border-emerald-500/30", icon: CheckCircle2 },
  Failed: { color: "text-red-500 bg-red-400/10 border-red-500/30", icon: XCircle },
  Retry: { color: "text-amber-500 bg-amber-400/10 border-amber-500/30", icon: RefreshCw },
  Exhausted: { color: "text-orange-500 bg-orange-400/10 border-orange-500/30", icon: AlertTriangle },
};

const LAYER_ORDER: Record<string, number> = { L1: 1, L2: 2, L3: 3 };
// Worst-first when two entries share a timestamp.
const STATUS_PRIORITY: Record<AuditStatus, number> = { Exhausted: 3, Failed: 2, Retry: 1, Success: 0 };

const FALLBACK_BADGE = "text-gray-400 bg-gray-400/10 border-gray-500/30";

function StatusBadge({ status }: { status: AuditStatus }) {
  const cfg = STATUS_CONFIG[status];
  const Icon = cfg?.icon;
  return (
    <span className={cn("inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold border", cfg?.color ?? FALLBACK_BADGE)}>
      {Icon && <Icon className="h-3 w-3" />}
      {status}
    </span>
  );
}

function fmtTime(iso: string | null): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "—";
  return d.toLocaleString(undefined, { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
}

// Turn a raw pipeline failure string into one plain-English line. Inputs look like
// "Some_File.pdf: DUP: hash match — same resume re-sent" — we drop the filename
// prefix and the internal code, and map the cause to recruiter-friendly wording.
function humanizeReason(raw: string | null): { text: string; file?: string } {
  if (!raw) return { text: "—" };
  let file: string | undefined;
  let rest = raw.trim();
  // Strip a leading "filename.ext: " (allowing a doubled ".pdf.pdf" extension).
  const m = rest.match(/^(.*?\.(?:pdf|docx?|png|jpe?g|zip|xlsx?))(?:\.[a-z0-9]+)?:\s*(.*)$/i);
  if (m) {
    file = m[1];
    rest = m[2].trim();
  }
  const l = rest.toLowerCase();
  let text = rest || "Could not be processed";
  if (l.includes("dup_hired") || (l.includes("dup") && l.includes("hired"))) {
    text = "Duplicate — this candidate has already been hired";
  } else if (l.startsWith("dup") || l.includes("hash match") || l.includes("re-sent") || l.includes("duplicate")) {
    text = "Duplicate — the same resume was already received";
  } else if (l.includes("not_a_resume") || l.includes("not a resume")) {
    text = "Not a resume — no contact details or work-experience section found";
  } else if (l.includes("corrupt")) {
    text = "Corrupt file — the document couldn't be opened";
  } else if (l.includes("reapplication")) {
    text = "Reapplication — a known candidate sent a different resume";
  } else if (l.includes("password") || l.includes("encrypted")) {
    text = "Protected file — the document is password-encrypted";
  } else if (l.includes("timeout") || l.includes("timed out")) {
    text = "Timed out — extraction took too long and was stopped";
  }
  return { text, file };
}

// ONE row per mail (E_id): the entry that represents the mail's outcome in this batch
// — the LAST stage it reached. Within a batch, steps run L1 → L2 → L3 in time order, so
// the latest entry is where the mail ended up (its error stage, or its final Success).
function representative(entries: AuditLog[]): AuditLog {
  return [...entries].sort((a, b) => {
    const t = new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
    if (t !== 0) return t;
    const s = STATUS_PRIORITY[b.status] - STATUS_PRIORITY[a.status];
    if (s !== 0) return s;
    return (LAYER_ORDER[b.layer] ?? 0) - (LAYER_ORDER[a.layer] ?? 0);
  })[0];
}

interface MailRow {
  e_id: string;
  rep: AuditLog;
  // Per-mail figures mirrored from email_master (joined by E_id).
  extracted: number; // candidates/resumes this mail produced
  tokens: number; // LLM tokens spent on this mail
  // L2 cleared (Success) but no new candidate came out → a known candidate
  // re-applied with a different resume. Surfaced as a "Reapplication" note.
  isReapplication: boolean;
  // The status shown in THIS view (badge + batch counts). Normally the raw audit
  // status, but a reapplication is downgraded to "Failed" so the Activity Log agrees
  // with the Mailbox (which marks it Needs-Review/Failed): it cleared L2 but produced
  // no candidate and still needs a recruiter. The stored audit row stays "Success" —
  // only the display changes — so the retry-exhaustion gate is unaffected.
  displayStatus: AuditStatus;
  // Name of the candidate this row's audit entry is tied to (for the reapplication label).
  candidateName?: string;
}
interface BatchGroup {
  batch_id: string;
  time: string;
  mails: MailRow[];
  candidates: number; // total candidates extracted across the batch
  tokens: number; // total LLM tokens spent across the batch
  counts: Record<AuditStatus, number>;
}

export default function AuditLogs() {
  const { canAccessBackoffice } = useAuth();
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());
  // Calendar filter: when set (YYYY-MM-DD), show only runs from that day.
  const [dateFilter, setDateFilter] = useState("");
  // Deep-link from the Mailbox "Audit" link: ?email=E123 narrows the log to a single
  // mail's rows — the reason it was marked Failed, spelled out in the Details column.
  const [searchParams, setSearchParams] = useSearchParams();
  const emailFilter = searchParams.get("email");
  const clearEmailFilter = () => {
    const next = new URLSearchParams(searchParams);
    next.delete("email");
    setSearchParams(next, { replace: true });
  };

  const { data: logs = [], isLoading } = useQuery({
    queryKey: ["audit-logs"],
    queryFn: async () => (await auditService.list()).data,
  });

  // Token usage and candidate-extracted counts live on email_master, not the audit
  // ledger — join them in by E_id so each mail (and each batch) can show both.
  const { data: emails = [] } = useQuery({
    queryKey: ["emails"],
    queryFn: async () => (await emailsService.list()).data,
  });
  const emailMap = useMemo(() => {
    const m = new Map<string, EmailMaster>();
    emails.forEach((e) => m.set(e.E_id, e));
    return m;
  }, [emails]);

  // Candidate names, keyed by candidate_id — used to label a re-application with
  // WHO re-applied ("Reapplication: Jane Doe") instead of a bare note.
  const { data: candidates = [] } = useQuery({
    queryKey: ["candidates"],
    queryFn: async () => (await candidatesService.list()).data,
  });
  const nameByCid = useMemo(() => {
    const m = new Map<string, string>();
    candidates.forEach((c) => {
      if (c.name) m.set(c.candidate_id, titleCase(c.name));
    });
    return m;
  }, [candidates]);

  // Group every step by run (batch), then collapse to one row per mail within it.
  const groups = useMemo<BatchGroup[]>(() => {
    const byBatch = new Map<string, AuditLog[]>();
    // Keep only real mail-processing steps (L1/L2/L3) — batch-lifecycle markers
    // (e.g. layer "BATCH", status "Started") aren't a mail and shouldn't be a row.
    logs
      .filter((l) => LAYER_ORDER[l.layer] !== undefined)
      .forEach((l) => {
        const k = l.batch_id ?? "—";
        const arr = byBatch.get(k);
        if (arr) arr.push(l);
        else byBatch.set(k, [l]);
      });

    const out: BatchGroup[] = [];
    byBatch.forEach((entries, batch_id) => {
      const byMail = new Map<string, AuditLog[]>();
      entries.forEach((e) => {
        const arr = byMail.get(e.E_id);
        if (arr) arr.push(e);
        else byMail.set(e.E_id, [e]);
      });
      const mails: MailRow[] = [...byMail.entries()].map(([e_id, es]) => {
        const em = emailMap.get(e_id);
        const rep = representative(es);
        const extracted = em?.candidate_count ?? 0;
        const isReapplication = rep.layer === "L2" && rep.status === "Success" && extracted === 0;
        return {
          e_id,
          rep,
          extracted,
          tokens: em?.total_tokens ?? 0,
          isReapplication,
          displayStatus: isReapplication ? "Failed" : rep.status,
          candidateName: rep.candidate_id ? nameByCid.get(rep.candidate_id) : undefined,
        };
      });
      // Surface problem mails first, then by email id.
      mails.sort((a, b) => {
        const s = STATUS_PRIORITY[b.displayStatus] - STATUS_PRIORITY[a.displayStatus];
        return s !== 0 ? s : a.e_id.localeCompare(b.e_id);
      });
      const counts: Record<AuditStatus, number> = { Success: 0, Failed: 0, Retry: 0, Exhausted: 0 };
      mails.forEach((m) => (counts[m.displayStatus] += 1));
      // Total candidates extracted + tokens spent = the sum across the batch's mails.
      const candidates = mails.reduce((n, m) => n + m.extracted, 0);
      const tokens = mails.reduce((n, m) => n + m.tokens, 0);
      const time = entries.reduce((mx, e) => (e.created_at > mx ? e.created_at : mx), entries[0].created_at);
      out.push({ batch_id, time, mails, candidates, tokens, counts });
    });
    out.sort((a, b) => b.time.localeCompare(a.time));
    return out;
  }, [logs, emailMap, nameByCid]);

  // Restrict to the selected day (compared in local time, like the run header shows)
  // and, when deep-linked from a Mailbox "Audit" link, down to a single mail's rows.
  const filteredGroups = useMemo(() => {
    let gs = dateFilter
      ? groups.filter((g) => new Date(g.time).toLocaleDateString("en-CA") === dateFilter)
      : groups;
    if (emailFilter) {
      gs = gs
        .map((g) => ({ ...g, mails: g.mails.filter((m) => m.e_id === emailFilter) }))
        .filter((g) => g.mails.length > 0);
    }
    return gs;
  }, [groups, dateFilter, emailFilter]);

  const pg = usePagination(filteredGroups, 8);

  const toggle = (batch: string) =>
    setCollapsed((prev) => {
      const next = new Set(prev);
      next.has(batch) ? next.delete(batch) : next.add(batch);
      return next;
    });

  // Recruiter has no Activity Log access at all (server-side enforced too —
  // GET /audit-logs 403s for that role). This guard keeps the page from
  // rendering a UI whose every call would fail, for a Recruiter who lands
  // here via a direct URL (the nav entry is already hidden from the sidebar).
  if (!canAccessBackoffice) {
    return (
      <PageContainer>
        <PageHeader title="Activity Log" subtitle="Pipeline runs · per-mail processing history" />
        <div className="flex flex-col items-center justify-center gap-3 rounded-2xl glass p-12 text-center">
          <ShieldAlert className="h-8 w-8 text-muted-foreground" />
          <p className="text-sm font-semibold text-foreground">Activity Log is restricted</p>
          <p className="max-w-sm text-xs text-muted-foreground">
            This section is only available to Admin and System Admin accounts.
          </p>
        </div>
      </PageContainer>
    );
  }

  return (
    // A real split pane, not a sticky element riding along a page-wide scroll —
    // sticky was fine at rest but visibly "jerked" on first load as the query
    // results reflowed the page under it. The header below is simply OUTSIDE
    // the scrolling region now, so it can never move or judder; only the
    // dedicated body pane (below) scrolls, in its own bounded area.
    <div className="flex h-full flex-col overflow-hidden">
      <div className="mx-auto w-full shrink-0 px-4 pt-4 sm:px-6">
        <PageHeader
          title="Activity Log"
          actions={
            <>
              {/* Date filter — show only the runs from a chosen day. Folded into
                  the hero bar (rather than its own row below) to give the scroll
                  pane below more room. */}
              <div className="flex items-center gap-1.5 rounded-lg border border-border bg-secondary/60 px-2 py-1">
                <Calendar className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                <input
                  type="date"
                  value={dateFilter}
                  max={new Date().toISOString().split("T")[0]}
                  onChange={(e) => setDateFilter(e.target.value)}
                  title="Show only runs from this date"
                  className="h-6 w-[124px] cursor-pointer border-0 bg-transparent p-0 text-xs text-foreground outline-none"
                />
                {dateFilter && (
                  <button
                    onClick={() => setDateFilter("")}
                    title="Clear date filter"
                    className="shrink-0 text-muted-foreground hover:text-foreground"
                  >
                    <X className="h-3 w-3" />
                  </button>
                )}
              </div>
              {!isLoading && (
                <span className="whitespace-nowrap text-xs text-muted-foreground">
                  {filteredGroups.length} run{filteredGroups.length === 1 ? "" : "s"}
                </span>
              )}
              <a
                href={auditService.exportExcelUrl()}
                download
                title="Export the full activity log as Excel"
                className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-secondary px-3 py-2 text-xs font-semibold text-foreground hover:bg-accent transition-colors"
              >
                <Download className="h-3.5 w-3.5" /> Export Excel
              </a>
            </>
          }
        />
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto">
      <div className="mx-auto w-full space-y-4 px-4 pb-4 pt-4 sm:px-6">

      {/* Active email filter — set when arriving from a Mailbox "Audit" link. */}
      {emailFilter && (
        <div className="flex items-center gap-2 rounded-lg border border-primary/30 bg-primary/5 px-3 py-2 text-xs">
          <span className="text-muted-foreground">Showing the failure reason for mail</span>
          <span className="font-mono font-semibold text-primary">{emailFilter}</span>
          <button
            onClick={clearEmailFilter}
            className="ml-auto inline-flex items-center gap-1 font-medium text-muted-foreground hover:text-foreground"
          >
            <X className="h-3 w-3" /> Show all runs
          </button>
        </div>
      )}

      {isLoading ? (
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading activity…
        </div>
      ) : filteredGroups.length === 0 ? (
        <div className="rounded-xl border border-border bg-card px-5 py-12 text-center text-sm text-muted-foreground">
          {emailFilter
            ? `No activity recorded for mail ${emailFilter}.`
            : dateFilter
              ? "No pipeline runs on this date."
              : "No pipeline runs have been recorded yet."}
        </div>
      ) : (
        <>
          {pg.pageItems.map((g) => {
            const isOpen = !collapsed.has(g.batch_id);
            // Export carries both a "Candidates" and a "Discarded" sheet, so it's
            // offered for every real batch — even one with no extracted candidates
            // (the workbook still captures the run's discarded/failed mails).
            const hasExport = g.batch_id !== "—";
            return (
              <div key={g.batch_id} className="rounded-xl border border-border bg-card overflow-hidden">
                {/* Run header */}
                <div className="flex flex-wrap items-center gap-x-3 gap-y-2 border-b border-border bg-secondary/40 px-4 py-3">
                  <button
                    onClick={() => toggle(g.batch_id)}
                    className="flex min-w-0 flex-1 flex-wrap items-center gap-x-2 gap-y-1 text-left"
                  >
                    <ChevronDown
                      className={cn(
                        "h-4 w-4 shrink-0 text-muted-foreground transition-transform",
                        !isOpen && "-rotate-90"
                      )}
                    />
                    <span className="font-mono text-sm font-bold text-primary">{g.batch_id}</span>
                    <span className="hidden text-xs text-muted-foreground sm:inline">{fmtTime(g.time)}</span>
                    {/* Mail + candidate counts as separated, highlighted chips — the two
                        numbers recruiters scan for, no longer buried in a muted run-on. */}
                    <span className="inline-flex shrink-0 items-center gap-1 rounded-full border border-border bg-secondary px-2 py-0.5 text-[11px] font-semibold text-foreground">
                      {g.mails.length} mail{g.mails.length === 1 ? "" : "s"}
                    </span>
                    <span className="inline-flex shrink-0 items-center gap-1 rounded-full border border-blue-500/30 bg-blue-500/10 px-2 py-0.5 text-[11px] font-bold text-blue-600">
                      {g.candidates} candidate{g.candidates === 1 ? "" : "s"}
                    </span>
                  </button>

                  <div className="flex items-center gap-1.5">
                    {(["Success", "Retry", "Exhausted", "Failed"] as AuditStatus[]).map((s) =>
                      g.counts[s] > 0 ? (
                        <span
                          key={s}
                          className={cn(
                            "rounded-full border px-2 py-0.5 text-[11px] font-semibold",
                            STATUS_CONFIG[s].color
                          )}
                        >
                          {g.counts[s]} {s}
                        </span>
                      ) : null
                    )}
                    {hasExport && (
                      <a
                        href={pipelineService.batchExcelUrl(g.batch_id)}
                        download
                        title="Download this batch's candidates as Excel"
                        className="inline-flex items-center gap-1.5 rounded-lg border border-primary/40 bg-primary/5 px-2.5 py-1 text-[11px] font-semibold text-primary hover:bg-primary/10 transition-colors"
                      >
                        <Download className="h-3 w-3" /> Export
                      </a>
                    )}
                  </div>
                </div>

                {/* One row per mail */}
                {isOpen && (
                  <div className="overflow-x-auto">
                    <table className="w-full min-w-[680px] text-sm">
                      <thead>
                        <tr className="border-b border-border text-left text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                          <th className="px-4 py-2.5 w-10">#</th>
                          <th className="px-4 py-2.5">Email</th>
                          <th className="px-4 py-2.5">Details</th>
                          <th className="px-4 py-2.5 text-center">Candidates</th>
                          <th className="px-4 py-2.5">Status</th>
                          <th className="px-4 py-2.5">Time</th>
                        </tr>
                      </thead>
                      <tbody>
                        {g.mails.map((m, i) => (
                          <tr
                            key={m.e_id}
                            className={cn(
                              "border-b border-border/50 hover:bg-accent/40 transition-colors",
                              m.rep.status === "Exhausted" && "bg-orange-400/5"
                            )}
                          >
                            <td className="px-4 py-2.5 text-[11px] font-mono text-muted-foreground">{i + 1}</td>
                            <td className="px-4 py-2.5 text-xs font-mono text-blue-500 whitespace-nowrap">
                              {m.e_id}
                            </td>
                            <td className="px-4 py-2.5 max-w-[340px]">
                              {m.rep.fail_reason ? (
                                (() => {
                                  const r = humanizeReason(m.rep.fail_reason);
                                  return (
                                    <div title={m.rep.fail_reason ?? undefined}>
                                      <div className="text-xs text-foreground">{r.text}</div>
                                      {r.file && (
                                        <div className="truncate text-[10px] text-muted-foreground">{r.file}</div>
                                      )}
                                    </div>
                                  );
                                })()
                              ) : m.isReapplication ? (
                                // L2 cleared but produced no new candidate → a known
                                // candidate re-applied with a different resume. Plain text,
                                // styled like every other Details row (no highlight).
                                <div className="text-xs text-foreground">
                                  Reapplication{m.candidateName ? `: ${m.candidateName}` : ""}
                                </div>
                              ) : m.rep.status === "Success" && (m.candidateName || m.rep.candidate_id) ? (
                                <div className="text-xs text-foreground">Candidate extracted</div>
                              ) : (
                                <span className="text-[10px] text-muted-foreground">—</span>
                              )}
                            </td>
                            <td className="px-4 py-2.5 text-center text-xs tabular-nums text-foreground">
                              {m.extracted > 0 ? m.extracted : <span className="text-muted-foreground">—</span>}
                            </td>
                            <td className="px-4 py-2.5">
                              <StatusBadge status={m.displayStatus} />
                            </td>
                            <td className="px-4 py-2.5 text-[11px] text-muted-foreground whitespace-nowrap">
                              {fmtTime(m.rep.created_at)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            );
          })}

          <Pagination
            page={pg.page}
            pageCount={pg.pageCount}
            total={pg.total}
            pageSize={pg.pageSize}
            startIndex={pg.startIndex}
            onPage={pg.setPage}
            itemLabel="runs"
          />
        </>
      )}

      </div>
      </div>
    </div>
  );
}
