import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { MotionConfig } from "framer-motion";
import { AuthProvider } from "@/context/AuthContext";
import { ConfirmProvider } from "@/components/common/ConfirmProvider";
import ErrorBoundary from "@/components/common/ErrorBoundary";
import App from "./App";
import "./index.css";

// Data refreshes on demand rather than on a constant background timer: every query
// fetches on page load/reload and on navigation, refreshes when the tab regains focus
// or the network reconnects (only if the data is stale), and is re-pulled right after
// any mutation that invalidates it. There is NO global polling interval — that was
// re-firing every query (emails, status, review-queue, …) every 30s and flooding the
// network tab. The few views that genuinely need live updates set their own
// refetchInterval locally (e.g. PipelinePanel polls status only while a run is active).
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60,          // treat data as fresh for 60s (skips refetch on quick nav/focus)
      refetchInterval: false,        // no automatic background polling by default
      refetchOnWindowFocus: true,    // refresh when you return to the tab (if stale)
      refetchOnReconnect: true,
      retry: 1,
    },
  },
});

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        {/* reducedMotion="user" makes every Framer animation respect the OS setting. */}
        <MotionConfig reducedMotion="user">
          <AuthProvider>
            <ConfirmProvider>
              <ErrorBoundary>
                <App />
              </ErrorBoundary>
            </ConfirmProvider>
          </AuthProvider>
        </MotionConfig>
      </BrowserRouter>
    </QueryClientProvider>
  </StrictMode>
);
