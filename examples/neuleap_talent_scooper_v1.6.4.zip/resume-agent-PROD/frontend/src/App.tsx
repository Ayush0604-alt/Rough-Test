import { Routes, Route, Navigate } from "react-router-dom";
import AppLayout from "@/components/layout/AppLayout";
import ProtectedRoute from "@/components/auth/ProtectedRoute";
import Login from "@/pages/Login";
import ForgotPassword from "@/pages/ForgotPassword";
import SetPassword from "@/pages/SetPassword";
import InterviewAccess from "@/pages/InterviewAccess";
import CandidateSchedule from "@/pages/CandidateSchedule";
import InterviewerPoolPortal from "@/pages/InterviewerPoolPortal";
import Dashboard from "@/pages/Dashboard";
import IntakeMailMaster from "@/pages/IntakeMailMaster";
import ResumeLibrary from "@/pages/ResumeLibrary";
import Candidate from "@/pages/Candidate";
import Screening from "@/pages/Screening";
import QuestionBanks from "@/pages/QuestionBanks";
import ProcessFlow from "@/pages/ProcessFlow";
import Settings from "@/pages/Settings";
import AuditLogs from "@/pages/AuditLogs";
import Chatbot from "@/pages/Chatbot";
import TokenUsage from "@/pages/TokenUsage";
import { useAuth } from "@/context/AuthContext";
import { useTheme } from "@/hooks/useTheme";

// "/" lands on Dashboard for everyone EXCEPT System Admin, who has no
// recruiting-workflow access (see AuthContext.canAccessRecruiting) and lands
// on Settings instead — its actual back-office home.
function IndexRedirect() {
  const { user } = useAuth();
  return <Navigate to={user?.role === "sysadmin" ? "/settings" : "/dashboard"} replace />;
}

export default function App() {
  // Applies the persisted/OS theme to <html> on mount, REGARDLESS of route.
  // Without this, the `dark` class was only ever applied as a side effect of
  // ThemeToggle mounting inside AppLayout — so a route rendered outside it
  // (this file's own /login and /interview/:token, both reached on a fresh
  // tab with no prior AppLayout mount) stayed light-only, ignoring both the
  // visitor's OS preference and any stored choice.
  useTheme();

  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      {/* Public — no auth: forgot-password request + the emailed set/reset
          password link (also used for new-account invites — see app.api.auth). */}
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/set-password/:token" element={<SetPassword />} />
      {/* Public — no auth: external interviewers open this via a signed link,
          they never log into the SPA at all (see app.api.interviewer). */}
      <Route path="/interview/:token" element={<InterviewAccess />} />
      {/* Public — no auth: a candidate opens this via their round's slot-invite
          email and verifies with an emailed code, no SPA login involved (see
          app.api.candidate_slots). */}
      <Route path="/schedule/:token" element={<CandidateSchedule />} />
      {/* Public — no auth: any configured interviewer logs in with their own
          email + emailed code (see app.api.interview_pools.portal_router) to
          manage the placeholder slots reserved for them. */}
      <Route path="/interviewer-pool" element={<InterviewerPoolPortal />} />
      <Route element={<ProtectedRoute />}>
        <Route element={<AppLayout />}>
        <Route index element={<IndexRedirect />} />
        <Route path="/dashboard" element={<Dashboard />} />
        {/* Candidate Analysis removed */}
        <Route path="/analytics" element={<Navigate to="/dashboard" replace />} />
        <Route path="/intake" element={<IntakeMailMaster />} />
        <Route path="/resumes" element={<ResumeLibrary />} />
        <Route path="/candidates/:candidateId" element={<Candidate />} />
        <Route path="/rounds" element={<Screening />} />
        <Route path="/rounds/:candidateId" element={<Screening />} />
        <Route path="/question-banks" element={<QuestionBanks />} />
        <Route path="/process-flow" element={<ProcessFlow />} />
        <Route path="/workflow" element={<Navigate to="/process-flow" replace />} />
        {/* Legacy path — keep old /screening links/bookmarks working */}
        <Route path="/screening" element={<Navigate to="/rounds" replace />} />
        <Route path="/screening/:candidateId" element={<Navigate to="/rounds" replace />} />
        {/* Pipeline merged into Mailbox */}
        <Route path="/pipeline" element={<Navigate to="/intake" replace />} />
        <Route path="/chatbot" element={<Chatbot />} />
        <Route path="/token-usage" element={<TokenUsage />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="/audit-logs" element={<AuditLogs />} />
        </Route>
      </Route>
    </Routes>
  );
}
