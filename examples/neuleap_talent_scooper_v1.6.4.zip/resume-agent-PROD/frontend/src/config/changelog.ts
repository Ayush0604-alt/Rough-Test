// Per-build changelog shown from the Sidebar's version pill (QA env only).
// MAINTENANCE RULE: every time APP_VERSION (config/version.ts) is bumped, add
// a matching entry AT THE TOP here — newest first. `version` is the base
// semver part only (no _YYYYMMDD.HHMM build stamp); the popup pairs the top
// entry with the full APP_VERSION string.
export interface ChangelogEntry {
  version: string; // "v1.1.2" — base version, no build stamp
  date: string; // "2026-07-08"
  features: string[]; // new features
  fixes: string[]; // bug fixes
  watch: string[]; // changes to watch out for
}

export const CHANGELOG: ChangelogEntry[] = [
  {
    version: "v1.6.4",
    date: "2026-07-21",
    features: [
      "Dashboard candidate tables: an \"Undecided\" button now sits beside Report on every row. Most freshers/interns end up parked as Undecided, so the highest-volume triage call no longer costs a trip through the Report popover — one click, confirm, and the candidate is parked. It runs the same automation as picking Undecided in the popover (ack-email + move to the Undecided bucket) and the reason you type is recorded in the Action Log. The button hides itself on candidates already parked.",
      "Dashboard \"New Potential Candidates Added\": a College column, leading the education block (College · Certificates · CGPA · Passout Year). Click the header to sort alphabetically — first click is A→Z, candidates with no college on record always sit at the bottom, and long institution names are shortened with the full name on hover.",
      "Settings → Legacy Features: a new \"Predicted NBA status line\" toggle controls the \"Predicted / Applied / Overridden: …\" line under the Report button on the dashboard tables.",
    ],
    fixes: [
      "Fixed the frontend build. The v1.6.3 merge kept lines from both sides of a conflict, leaving a duplicate prop and an undefined one on the Dashboard's outcomes table and dropping three imports on the Screening page — the type-check failed and the frontend image could not be built at all.",
    ],
    watch: [
      "The predicted-NBA line under Report is now HIDDEN by default. It is not gone: Settings → Legacy Features → \"Predicted NBA status line\" turns it back on. Either way the prediction stays visible — and appliable — inside the Report popover, so nothing about how predictions work has changed.",
      "The row-level Undecided button performs the real action, not a local marker: it sends the ack-email and moves the candidate, exactly as the popover does. It is deliberately behind the same confirmation dialog for that reason.",
    ],
  },
  {
    version: "v1.6.3",
    date: "2026-07-21",
    features: [
      "Mobile navigation rebuilt: the hamburger menu and slide-in drawer are replaced by a persistent bottom tab bar (Dashboard · Rounds · Question Banks · Intake · Audit Logs, filtered to your role). Process Flow — and Token Usage for Admins — moved into the account dropdown, which now also carries \"Report a bug / request a feature\" and the version pill.",
      "Settings saves itself. The Save button is gone: changes are written automatically about a second after you stop editing, across the whole page (notifications, pipeline, scoring/ATS bands, chatbot widget, interview slots, candidate sections). A status line reads \"Auto-saving… → Saving… → Saved\", or \"Save failed\" if something goes wrong.",
      "Question Banks: remove a candidate from a bank's leaderboard. It is a soft removal behind a confirmation — the row stays, struck through with a \"removed\" chip showing who removed them and when, sorted to the bottom and unranked. Recorded responses and marks are never deleted, and the summary line reports the count separately.",
      "Question Banks: bulk assign can now be scoped to one or more rounds instead of a single one, and each candidate's allocation is stamped with the round they are actually in. Bank cards gained scope chips (which source tag and round a bank covers, with counts) and an average-score badge.",
      "Phone layout fixes: Refresh now sits on the title row instead of stranded among the actions, and the Dashboard and Screening filter rows wrap onto their own line rather than clipping against pagination.",
    ],
    fixes: [
      "The floating Neuleap Buddy mascot now stays clear of the new bottom tab bar on phones instead of sitting behind it.",
    ],
    watch: [
      "Settings has no Save button and no discard. An accidental edit is persisted about a second later — use Reload to pull the saved values back from disk.",
      "Database: two new optional columns on question_bank_allocations (removed_at, removed_by). They are added automatically on startup, additive and nullable, with no backfill and no downtime.",
      "API change for anything calling the app from outside: POST /question-banks/{id}/bulk-allocate now takes round_names (a list) instead of round_name (a single string). The app itself was updated, but external scripts must be too — the old field is silently ignored, so a stale caller loses its round without erroring.",
      "Removing a candidate from a leaderboard is available to any signed-in user who can open that leaderboard; it is not restricted to Admins.",
    ],
  },
  {
    version: "v1.6.2",
    date: "2026-07-21",
    features: [
      "Incoming Email Queue (Mailbox): discard one, several, or every queued email to exclude it from the next pipeline run — row checkboxes plus per-row and bulk Discard actions, each behind a confirmation. Discarded mail is never deleted: it moves into a \"Set aside\" panel (docked beside the queue, opened from a header toggle showing the live count) where any item can be Restored back into the queue for a later or on-demand run.",
      "Every discard and restore is recorded with who did it (Admin/System Admin) and when, so set-asides are part of the mail intake's audit trail, not a silent action.",
    ],
    fixes: [],
    watch: [
      "Discard/Restore move the underlying Outlook message between mail folders and need GRAPH_MOVE_MAIL enabled (the default). If a move fails or moving is disabled, the item stays put in its current list and an inline warning explains why — it never silently reports success.",
    ],
  },
  {
    version: "v1.6.1",
    date: "2026-07-15",
    features: [
      "Bug reports & feature requests now capture TWO dimensions: a P1–P5 priority (how urgent) AND a MoSCoW class — Must / Should / Could / Won't have (how essential). The MoSCoW badge shows on each report in Settings → Feedback and is included in the Excel export.",
    ],
    fixes: [
      "In-app User Manual (avatar → Help) updated across all roles to cover the MoSCoW field on the bug-report / feature-request form.",
    ],
    watch: [],
  },
  {
    version: "v1.6.0",
    date: "2026-07-15",
    features: [
      "Forgot password: a self-service 'Forgot password?' link on the sign-in page emails you a single-use reset link (valid 1 hour) — no admin needed. New accounts are now created by EMAIL INVITE too: enter an email + role and the member gets a link to set their own initial password, so every account is tied to a valid, reachable email.",
      "Report a bug / request a feature: a new sidebar button (every role) opens a form — pick Bug or Feature, add details, and set BOTH a P1–P5 priority (urgency) and a MoSCoW class (Must / Should / Could / Won't have). The reporter's name + email are attached automatically.",
      "Settings → Feedback (Admin / System Admin): review every reported bug + feature request, triage each one's status (Open / In progress / Resolved / Closed), delete, and export the whole list to Excel (including priority + MoSCoW).",
      "Upgrade safety net: applying an upgrade now auto-saves a SIGNED 'revert' bundle of the current version into the install drop folder BEFORE swapping — so you can always reinstall the version you left, even after a 'successful' upgrade turns out bad (durable beyond the in-place rollback tags).",
    ],
    fixes: [
      "The in-app User Manual (avatar → Help) was refreshed across all roles for everything added recently — invite/forgot-password, feedback reporting, the CGPA/Certificates columns + CGPA-in-NLRS, Excel source columns, the new interview-pool day windows + Final-round default, parallel slot capacity, and the fuller 'Why this prediction' explanation.",
    ],
    watch: [
      "New-user creation no longer takes an admin-typed password — it sends an invite email instead. This needs outbound email (Graph) configured; if it isn't, the set-password link is shown to the admin to relay manually, or use the per-user 'Reset password' action for a handover credential.",
      "Password reset + invite links are built from APP_PUBLIC_URL — make sure it points at the address users actually reach (the reset/invite emails are useless if it's blank or wrong).",
    ],
  },
  {
    version: "v1.5.0",
    date: "2026-07-15",
    features: [
      "Excel intake now captures EVERY column from the sheet onto the candidate, selectable on the Candidates page as '<column>__from-source-sheet' (opt-in via the Columns customizer, so 17 columns don't flood the table). If the sheet has a CGPA column it becomes the source of truth — the resume-extracted CGPA is kept alongside as 'CGPA__from-resume'.",
      "CGPA is now a major NLRS component — weighted 30%, second only to the Analysis Report (default split: Analysis 45 · CGPA 30 · Certs 12 · Experience 8 · ATS 5, all tunable in Settings → Extraction & Analysis → NLRS). A candidate with NO CGPA on record is not penalized: CGPA drops out and the other components rescale.",
      "Every page's hero bar now has a Refresh button — pulls the latest data in-app without a full browser reload (spins while fetching).",
      "Dashboard 'New Potential Candidates Added' card: added Certificates and CGPA columns (order is Experience · Certificates · CGPA · Passout Year). Candidates are always ranked highest-NLRS-first, resetting to that on every page load.",
      "Interview slot pools: new day-window options — Early morning (8–10), Late evening (18–21), and Full day extended (8–21) — plus a 'Reset to defaults' button on the Pool Calculation Controls. The Final round now defaults to Tue/Wed/Thu afternoons only, at most 20% of the day.",
      "The 'Why this prediction' explanation now shows the fuller format — a numbered list of reasons plus Strengths / Concerns — for EVERY prediction, not just fast-tracked ones. Fast-tracked candidates keep their distinct 'skip ahead' framing.",
    ],
    fixes: [
      "The ATS and NLRS score columns on the dashboard candidate tables are now controlled from Settings → Legacy Features (default OFF). Hiding them does not change the ranking — candidates still sort highest-NLRS-first, the raw score columns are just an opt-in detail view.",
    ],
    watch: [
      "Excel columns only populate on NEW intake. Candidates already imported before this build won't have them until their Excel source is re-processed — the columns are captured at intake time. New Excel intakes work automatically.",
      "Changed default pool calculation rules: weekly pattern (Mon none · Tue/Wed/Thu PM · Fri AM · Sat/Sun none), funnel cuts (Screening 50 · R1 30 · R2 15 · R3 0 · Final 55), and the Final-round override above. These are the shipped defaults + were applied to this environment's live config; use 'Reset to defaults' to re-apply the shipped set at any time.",
    ],
  },
  {
    version: "v1.4.0",
    date: "2026-07-13",
    features: [
      "Leaderboard drill-down: the (i) on each candidate now opens their FULL interview response sheet — every question with the candidate's answer, the mark, the model answer + rubric, and the explanation — and works whether the interview is partial or complete. The interviewer's name now shows too (resolved from the slot they were actually booked into), alongside the round and slot time.",
      "Interview slot pools now support PARALLEL capacity: when more than one interviewer is rostered for the same round at the same time, that time seats several candidates instead of just one. The candidate slot-picker shows how many are still open at each time ('N left') and it counts down as candidates book; booking claims whichever interviewer is still free at that time (concurrency-safe), so a second candidate no longer hits 'that slot was just taken' while capacity remains.",
      "After an interview verdict (through a question bank or a normal round), the candidate is automatically moved on with the right email teed up: a Pass / leapfrog advances to the next appropriate round and DRAFTS that round's slot-share email; a Fail / reject moves the candidate to Rejected and DRAFTS a polite decline email. Whether the draft is sent on your action or auto-sent stays governed by Settings → Email Send Controls — nothing sends on its own unless you've configured auto-send.",
    ],
    fixes: [
      "Fixed a crash ('m.toFixed is not a function' → 'Something went wrong') when opening the interviewer view for a candidate whose answers had been marked. Question-bank marks are stored as database NUMERIC values, which were being serialized to text and then broke the running-total math on the page; marks now come back as real numbers everywhere the response sheet is shown.",
      "Removing an interviewer from Settings → Round Interviewers now refreshes the pools immediately: their still-open placeholder slots are cancelled (and cleared off their calendar) so a de-rostered interviewer stops being offered to candidates. Already-booked meetings are left untouched.",
    ],
    watch: [
      "New behavior: a Fail/Reject verdict on an interview now drafts a candidate-facing decline email ('Update on your application'). It is a DRAFT only — it sends when you mark it ready/send, or automatically only if auto-send is turned on. The old resume-triage 'Straight Reject' still sends nothing. Review the decline wording (Settings → Email Templates) before enabling auto-send.",
    ],
  },
  {
    version: "v1.3.7",
    date: "2026-07-12",
    features: [],
    fixes: [
      "System Upgrade no longer auto-reloads the page just because you opened the card. The auto-reload now fires only when an upgrade you're actively watching finishes (active → success) — previously it also triggered on the last upgrade's saved 'success' result loaded on open, which caused an endless refresh loop while sitting on the System Upgrade section.",
    ],
    watch: [
      "Operational: backups, the secondary copy, and built upgrade bundles now live OUTSIDE the repo folder, bind-mounted in via HOST_DATA_DIR (set in .env; defaults to the repo dir). Existing data was migrated in place — no action needed. To relocate all of it (e.g. off OneDrive), move the folders and repoint HOST_DATA_DIR in one place.",
    ],
  },
  {
    version: "v1.3.6",
    date: "2026-07-12",
    features: [
      "Settings → Backup & Disaster Recovery and System Upgrade each now have an '(i) How it works' illustration — a compact diagram of the updater-sidecar upgrade flow (bundle → app → sidecar swap → health checks → success/auto-rollback, data volumes preserved) and the DR flow (scheduler → backup engine captures DB + files + config → copied to ≥2 locations → restore to an exact point-in-time).",
    ],
    fixes: [
      "Confirmation prompts across the app now use the app's own styled dialog instead of the raw browser popup, so 'are you sure?' steps match the rest of the UI (deleting a question bank, removing a user, restoring a backup, resetting settings, revoking sessions, reverting prompts/skills, starting an upgrade, and more).",
    ],
    watch: [],
  },
  {
    version: "v1.3.5",
    date: "2026-07-12",
    features: [
      "Backup & Disaster Recovery now snapshots the WHOLE system, not just data: a full backup captures the PostgreSQL dump + both MinIO buckets + all system CONFIGURATION (the secrets/ dir — every UI setting, key, and config file). Restore brings back data, files, AND configuration, then reloads the config live — so recovering to a point-in-time restores the exact system state you had.",
      "Backups now fan out to a second on-box location by default (backups-secondary/), so there are always ≥2 full sets in different places (point it at an external disk / NAS / SMB share for real off-site separation). Cloud (S3) can be added in Settings → Backup & Disaster Recovery.",
      "Settings → System Upgrade: install big bundles WITHOUT a browser upload. A bundle is a whole Docker image (~470MB), and Cloudflare/proxies cap request bodies (~100MB), so the upload button can't push it through the tunnel. Instead drop the .tar into backups/upgrade/drop/ on the host and click 'Load & validate' in the new 'Install from the server drop folder' panel — same signature + checksum validation as upload, no size limit.",
      "System Upgrade now auto-reloads the page when an upgrade finishes (countdown + 'Reload now' button), so the new version + UI appear without a manual refresh — the sidebar version is baked into the JS bundle, which only updates on a full reload.",
    ],
    fixes: [
      "Data-safe upgrade fix: the updater sidecar was silently detaching the app's host bind-mounts (.env, secrets, backups) on every in-app upgrade. It drives 'docker compose' from inside its own container, so relative bind sources ('./backups') resolved to a phantom /project dir and the daemon bound empty folders — the app's .env went 0-byte (DB + object storage were safe as named volumes). The updater now self-discovers the real host project path and pins every bind source to it (HOST_PROJECT_DIR); normal host-side 'docker compose' runs are unchanged.",
    ],
    watch: [
      "Bundles are ~470MB — install them via the drop folder or the Uploaded-bundles 'Install' button, never the browser 'Upload' button when behind Cloudflare or any proxy that limits request-body size.",
    ],
  },
  {
    version: "v1.3.4",
    date: "2026-07-12",
    features: [
      "Upgrade bundles can now also carry .env additions and a compose overlay. New env keys (with defaults) are appended to .env on upgrade WITHOUT overwriting any values you've set; a compose overlay (new port/service/volume) is installed and wired so every future 'docker compose up -d' includes it. Both are checksummed in the signed manifest (tamper-proof) and reverted on rollback. The bundle card shows '+ updates .env' / '+ updates compose' badges.",
    ],
    fixes: [],
    watch: [
      "New env vars alone don't need a compose overlay — the app loads the whole .env, so a new key is picked up on the recreate. Use ENV_ADDITIONS=… and COMPOSE_OVERLAY=… with scripts/make-bundle.sh (see DEPLOYMENT.md).",
    ],
  },
  {
    version: "v1.3.3",
    date: "2026-07-12",
    features: [
      "Settings → System Upgrade now lists previously-uploaded bundles with their version, size, and signature status (verified / signed / unsigned), and an Install button to run any of them without re-uploading.",
    ],
    fixes: [],
    watch: [],
  },
  {
    version: "v1.3.2",
    date: "2026-07-12",
    features: [
      "Upgrade safety hardening: the updater sidecar is now OPT-IN (a compose profile) so the Docker-socket container only runs when you enable it (docker compose --profile updater up -d). Settings → System Upgrade shows a clear warning and disables Upgrade when it isn't running.",
      "Signed upgrade bundles: generate an Ed25519 keypair (scripts/keygen.sh), paste the PUBLIC key in Settings → System Upgrade, and build signed bundles (SIGN_KEY=… scripts/make-bundle.sh). The server verifies the signature before installing and shows \"signature verified\"; a tampered or unsigned bundle (when a key is set, or when 'require signature' is on) is rejected.",
      "Backup failure emails: Settings → Backup & Disaster Recovery can email a chosen recipient list (or the Notifications recipient) whenever a backup fails.",
    ],
    fixes: [],
    watch: [
      "Keep signing_private.pem secret on the build machine — the server only ever holds the public key.",
    ],
  },
  {
    version: "v1.3.1",
    date: "2026-07-12",
    features: [
      "One-click in-app upgrade (Settings → System Upgrade, System Admin): upload a version bundle (built with scripts/make-bundle.sh), see its version + feature list, and click Upgrade. The app takes a full pre-upgrade backup, then an updater sidecar swaps the images (data volumes preserved), waits for health, and runs data-consistency + integrity checks — reporting success with the new feature list.",
      "Automatic rollback: if health or the checks fail, the updater reverts to the previous images AND restores the database from the pre-upgrade backup, and the UI shows \"reverted to previous version\". The upgrade is fully reversible.",
      "New updater sidecar service (Docker socket + project mounted) drives the swap against the same stack; it only acts on an upgrade a System Admin initiated.",
    ],
    fixes: [],
    watch: [
      "The app + Settings page briefly restart during the swap; the page reconnects and shows the final result from a shared status file.",
      "Build a bundle with: docker compose build app frontend && bash scripts/make-bundle.sh <version> [features.txt]. See DEPLOYMENT.md for the full flow + test steps (incl. a safe same-version dry run).",
    ],
  },
  {
    version: "v1.3.0",
    date: "2026-07-12",
    features: [
      "Backup & Disaster Recovery (Settings → Backup & Disaster Recovery, System Admin): scheduled backups — incremental (DB) every N hours + a weekly full (DB + both MinIO buckets) — written to a local primary plus an optional mounted/NAS secondary and an optional S3-compatible cloud target, so there are always ≥2 full sets in different places. Retention keeps ≥2 full sets. Includes System Health (database, object store, disk, last-backup times), \"Backup now\", the list of available backups, and one-click Restore.",
      "Data-safe upgrades: added scripts/upgrade.sh (auto pre-upgrade backup → rebuild → health + consistency check → auto-rollback on failure) and scripts/rollback.sh, plus DEPLOYMENT.md explaining why `docker compose build && up -d` preserves all data (named volumes + additive schema + bind-mounted config) and that only `down -v` destroys it.",
      "The app image now ships pg_dump/pg_restore for the backup engine.",
    ],
    fixes: [],
    watch: [
      "This is Phase 1 (backups/DR + health + safe upgrade scripts). Phase 2 — an in-app \"upload version bundle → one-click upgrade\" via a Docker-socket updater sidecar with pre-backup, checks and rollback — is next.",
      "To use the secondary/NAS copy, mount a host path to /app/backups-secondary (commented example in docker-compose.yml) and set it in Settings. Cloud copy needs an S3-compatible bucket + keys.",
    ],
  },
  {
    version: "v1.2.47",
    date: "2026-07-11",
    features: [
      "A question bank's expanded preview is now much more readable: larger question text with comfortable line-height, a coloured difficulty pill, a numbered chip per question, the rationale on its own line with a lightbulb, clearer section headers, and a constrained reading width so long questions don't stretch edge to edge.",
    ],
    fixes: [],
    watch: [],
  },
  {
    version: "v1.2.46",
    date: "2026-07-11",
    features: [
      "Question Banks page hero bar now has a \"New question bank\" button that opens the Questions Generator in General (candidate-less) mode — pick modes, set the mix, generate, and save a bank right from this page.",
      "Each bank has a \"Customize\" action that loads it into the General generator with its own modes/level, so you can tweak and regenerate; saving keeps the bank's name and bumps the Roman-numeral version (e.g. \"… II\").",
      "\"Restore samples\" button re-creates any of the built-in sample banks (Michael Jackson / Quentin Tarantino / Charlie Chaplin) that were deleted.",
      "Each bank's Delete and Duplicate actions are on the bank's action row (Assign · Leaderboard · Customize · Duplicate · Delete).",
    ],
    fixes: [],
    watch: [],
  },
  {
    version: "v1.2.45",
    date: "2026-07-11",
    features: [
      "New deployments come seeded with three sample question banks you can try or delete: \"Michael Jackson - Thriller\" (SQL + Analytical + Logical Reasoning), \"Quentin Tarantino - Pulp Fiction\" (DSA + Prompt Writing + Data Engineering) and \"Charlie Chaplin - The Kid\" (Python Libraries + Operations Research + Logical Reasoning). Seeded once per deployment — deleting them keeps them gone.",
      "Each bank now has Duplicate and Delete. Duplicate makes a copy as the NEXT Roman-numeral version — \"Michael Jackson - Thriller\" → \"Thriller II\" → \"III\" — so you can pick a bank, tweak it, and it keeps that versioned name instead of getting a fresh random one.",
    ],
    fixes: [],
    watch: [
      "Deleting a bank also removes its candidate assignments and any recorded responses.",
    ],
  },
  {
    version: "v1.2.44",
    date: "2026-07-11",
    features: [
      "Settings → Interview Question Generation: the web-search Topic is now REQUIRED for every question type (not optional), and each row/new type shows one-click Suggested search phrasings that fetch the best interview material for that section.",
    ],
    fixes: [
      "\"Search the web\" was returning no sources whenever a mode's topic was blank (which most were after edits). Every selected mode is now always searched — falling back to the section name and sharpening it into an interview-question query — so sources reliably show up.",
    ],
    watch: [],
  },
  {
    version: "v1.2.43",
    date: "2026-07-11",
    features: [
      "Favourite legends now span more than one complexity band: Michael Jackson albums come up on hard / very-hard banks as well as medium ones, and The Beatles come up on medium banks as well as hard ones (both still weighted ~3x). Quentin Tarantino stays on the harder banks.",
    ],
    fixes: [],
    watch: [],
  },
  {
    version: "v1.2.42",
    date: "2026-07-11",
    features: [
      "Question-bank naming now leans toward crowd favourites — Michael Jackson, Quentin Tarantino and The Beatles come up more often (weighted ~3x) within whatever complexity tier a bank matches (so Tarantino/Beatles surface on harder banks, Michael Jackson on medium ones).",
    ],
    fixes: [],
    watch: [],
  },
  {
    version: "v1.2.41",
    date: "2026-07-11",
    features: [
      "Question-bank codenames are now drawn purely from movies & music legends — filmmakers (Christopher Nolan, Quentin Tarantino, M. Night Shyamalan, Kubrick, Hitchcock, Scorsese, Kurosawa, Fincher…) and musicians/bands (Michael Jackson, The Beatles, Pink Floyd, Radiohead, Queen, Prince, Bowie…), each paired with one of their works (162 pairings across 34 legends).",
      "The match is now on the COMPLEXITY of the creativity: a hard / analytical bank gravitates to the cerebral names (Nolan - Inception, Radiohead - OK Computer, Kubrick - 2001), a medium bank to the crafted-but-accessible (Shyamalan, Spielberg, MJ, Queen), and an easy set to the feel-good (Elvis, Disney). Still varied within a tier so it stays a fun discovery.",
    ],
    fixes: [],
    watch: [],
  },
  {
    version: "v1.2.40",
    date: "2026-07-11",
    features: [
      "The suggested question-bank name now FITS the bank's character rather than being purely random: an analytical / operations-research / DSA set leans toward the scientists (Einstein, Newton), a prompt-writing set toward the writers (Shakespeare, Dylan, Tagore), a heavier bank toward a heavier legend, and a light behavioural set toward a lighter, creative name — with enough randomness that it still feels like a fresh discovery each time.",
    ],
    fixes: [],
    watch: [],
  },
  {
    version: "v1.2.39",
    date: "2026-07-11",
    features: [
      "Question bank auto-names now pair a legend with one of their creative works — e.g. \"Michael Jackson - Dangerous\", \"The Beatles - Magical Mystery Tour\", \"Charlie Chaplin - Making a Living\". That's 125 distinctive names across 29 legends, so the same legend can recur with a different work. Rename any suggestion when saving.",
    ],
    fixes: [],
    watch: [],
  },
  {
    version: "v1.2.38",
    date: "2026-07-11",
    features: [
      "Saved question banks are now auto-named after classic legends (Michael Jackson, Charlie Chaplin, Albert Einstein…) instead of Greek gods. Existing bank names are unchanged; you can still rename any suggestion when saving.",
    ],
    fixes: [],
    watch: [],
  },
  {
    version: "v1.2.37",
    date: "2026-07-11",
    features: [
      "Question Banks page — bulk-assign a bank to a whole cohort: pick a source tag, select all or a subset of its candidates, and assign the bank to them in one go (each candidate's interviewer gets it; candidates never see it).",
      "Each bank now shows live stage badges — how many candidates are assigned, answering, and scored.",
      "Per-bank leaderboard: ranks the assigned candidates by their total marks (medals for the top three), shows answered/total and stage, and an (i) icon per row reveals the interviewer, round and interview slot. Export the leaderboard to Excel.",
    ],
    fixes: [],
    watch: [
      "Bulk-assign creates a pre-assignment (bound to the round when the slot invite is sent). Re-assigning a candidate replaces any existing active assignment for that round.",
    ],
  },
  {
    version: "v1.2.36",
    date: "2026-07-11",
    features: [
      "Auto-send (draft review OFF) now enforces the interview slot-picker link: before a slot-invite email goes out automatically, the real slot link is minted from the matching interviewer timeslot pool and inserted in place of the placeholder. A pre-assigned question bank (optional) is bound to the round at the same time.",
      "If the slot link can't be inserted (no matching pool, or the public URL isn't configured), the auto-send is PAUSED — the email is not sent — and a blinking amber caution appears next to the candidate on the Dashboard, the Candidates list, and their profile. Hover it for the reason. Sending the draft manually (after fixing the pool/URL) clears the caution.",
    ],
    fixes: [
      "Previously an auto-sent slot-invite could go out with the literal \"[interview-slot-picker-link]\" placeholder instead of a real link. It now never ships without a working link.",
    ],
    watch: [
      "The slot-picker link is mandatory for slot-invite emails; the question bank remains optional (case-by-case).",
    ],
  },
  {
    version: "v1.2.35",
    date: "2026-07-11",
    features: [
      "Generate Interview Questions — the packaging control now lets you set the TOTAL number of questions with a −/+ stepper (3–40), and the generator produces roughly that many across the sections.",
      "You can now exclude a section from the mix: each section shows as a toggle chip under the mix bar — click to drop it (it leaves the bar and is omitted from the generated kit) or click again to bring it back. At least one section always stays.",
    ],
    fixes: [],
    watch: [],
  },
  {
    version: "v1.2.34",
    date: "2026-07-11",
    features: [],
    fixes: [
      "Interviewer timeslot pool sizing: a pool that covers only later rounds (e.g. Round 2 + Final) was showing every round Target as 0 and Screening-level need as 0. The funnel projection was only flowing candidates across the pool's OWN rounds, so candidates entering at Screening/Round 1 never carried over into the later rounds it provisions. It now flows the projected candidates down the full pipeline and reads off each pool round's reach — targets (and \"Make placeholders\") are correct again.",
    ],
    watch: [],
  },
  {
    version: "v1.2.33",
    date: "2026-07-11",
    features: [
      "Interviewers now run an assigned question bank: when a bank was allocated to a candidate's round, the interview link shows THAT bank's questions instead of the Generate panel. Each question has a copy button (paste to the candidate over Teams), a response/observation field and a 0–10 mark.",
      "AI-suggested marking: \"Suggest marks (AI)\" scores each recorded response against its ideal answer; the interviewer can override any mark. The running total and every response + mark are saved with the verdict (and shown in the round feedback).",
    ],
    fixes: [],
    watch: [
      "The verdict picker and score are unchanged — the question-bank marks are recorded in addition to the verdict. Per-question responses + marks persist to question_bank_responses; the allocation is marked scored on submit (feeds the upcoming leaderboard).",
    ],
  },
  {
    version: "v1.2.32",
    date: "2026-07-11",
    features: [
      "Question banks can now be ASSIGNED to a candidate's interview: the Email Draft review (the slot-invite email you review before sending) has a new \"Question bank for this interview\" picker. Assign a saved bank and it's reserved for the interviewer of that round — the questions are never shown to the candidate. Assignment is optional (case-by-case).",
      "If a bank was already pre-assigned to the candidate, the draft shows it as \"Pre-assigned & ready\" with its name and question count, and you can remove it.",
    ],
    fixes: [],
    watch: [
      "This is Phase 2A. Next: the interviewer opening this candidate's round sees the assigned bank (instead of Generate) and records a response + AI-suggested mark per question; and auto-send will enforce the slot-picker link before sending.",
    ],
  },
  {
    version: "v1.2.31",
    date: "2026-07-11",
    features: [
      "New Question Banks page in the left menu: it lists every saved (generic) question bank with its question count, difficulty, stream and creator, and expands to preview all the questions grouped by section. This is the home for the upcoming cohort allocation, leaderboard and Excel export.",
      "Settings → Interview Question Generation: the \"Add a question type\" fields now have concrete example placeholders and tooltips (label, section title, web-search seed, level/style guidance) so it's clear what to enter.",
    ],
    fixes: [],
    watch: [
      "The Question Banks page currently shows saved banks and their questions; allocating a bank to candidates (via the slot-invite email review) and the per-bank leaderboard/export land in the next phases.",
    ],
  },
  {
    version: "v1.2.30",
    date: "2026-07-11",
    features: [
      "Question packaging is now a single interactive \"mix\" bar covering EVERY section (the standard buckets plus any aptitude modes), not just the aptitude sections. Each section is a segment sized to its share of the questions — drag the dividers to shift how many questions come from each, with live approximate counts, then press Apply.",
      "The Generate Interview Questions panel's top controls are now collapsible: hit \"Hide controls\" to fold the summary, packaging, effort and buttons away and give the packaged questions the full panel height. A slim strip keeps Regenerate / Export / Add-to-bank reachable while collapsed.",
    ],
    fixes: [],
    watch: [],
  },
  {
    version: "v1.2.29",
    date: "2026-07-11",
    features: [
      "Question Banks (phase 1): the Generate Interview Questions dropdown has a new \"Avoid personalization\" option — it produces GENERIC questions that apply uniformly to a whole cohort (e.g. a placement drive) instead of being tied to one candidate's projects/evidence, so the same set can evaluate many candidates fairly.",
      "When a kit is generated with Avoid personalization on, an \"Add to question bank\" button appears next to Export. It opens a popup pre-filled with an auto-suggested codename (a Greek god) that you can keep or rename, and saves the set as a reusable question bank.",
    ],
    fixes: [],
    watch: [
      "This is phase 1 of the Question Bank feature. Allocating a saved bank to a candidate's interview (during the slot-invite email review) and the interviewer's answer/marking flow + the Question Bank Activity page with leaderboard land in the next phases.",
      "Saved banks are stored in a new question_banks table; bank names are unique.",
    ],
  },
  {
    version: "v1.2.28",
    date: "2026-07-11",
    features: [
      "Generate Interview Questions now offers three new aptitude modes: Prompt Writing, Operations Research, and Analytical Thinking & Logical Reasoning (estimation puzzles & brain-teasers — e.g. \"how many litres of paint for a narrow-body aircraft\", elevator control logic, jug/weighing puzzles). Multi-select combines any of them with the standard profile-grounded kit.",
      "Composition rider: when you pick multiple question modes you can now set a per-section weight (1-5) that controls roughly what share of the total questions comes from each section.",
      "Search web (opt-in): while generating, the selected modes can be grounded in a fresh web search of popular resources so the bank uses the latest and most challenging questions for the level. The kit footer lists the sources it drew on.",
      "New Settings → Interview Question Generation (Admin only): add / edit / delete the question-type modes that populate the Generate dropdown (label, bucket, web-search topic, level guidance), with reset-to-default. The built-in modes remain the default.",
      "The generation SKILL (the prompt logic — how web-search results are used, what \"challenging at a level\" means, composition rules) is now editable in that same Settings section, with reset-to-default, so question quality can be tuned without a code change.",
    ],
    fixes: [],
    watch: [
      "Web search uses a key-less endpoint and degrades gracefully — if it returns nothing, generation continues without sources.",
      "Custom question modes and the edited SKILL persist in the bind-mounted secrets/ dir; reset removes the override and returns to the built-in defaults.",
    ],
  },
  {
    version: "v1.2.27",
    date: "2026-07-10",
    features: [
      "Referral info is now searchable on the Dashboard and Candidates page: the search matches the referred-by name/email and the referral message, and typing \"referral\" / \"referrals\" (or a prefix like \"refer\") returns every referral candidate. Case-insensitive, alongside name, id, note and remark search.",
    ],
    fixes: [],
    watch: [],
  },
  {
    version: "v1.2.26",
    date: "2026-07-10",
    features: [],
    fixes: [
      "A referral entry's subject pattern is now a GATE: when set, emails from that sender/domain count as a referral ONLY if the subject matches the pattern (and the extracted name is the \"Referred by\"). Previously a configured pattern only affected the name — a non-matching subject still counted as a referral. Entries with no pattern are unchanged (every email from that sender is a referral). A gated email rule that fails still falls through to an ungated domain rule if one qualifies.",
    ],
    watch: [],
  },
  {
    version: "v1.2.25",
    date: "2026-07-10",
    features: [
      "Referrals can now extract the referrer NAME from the email subject. Each referral email/domain entry gets an optional subject pattern with a <Sender> placeholder (e.g. \"Referral by <Sender>\" or \"<Sender> referred this candidate\"); when the subject matches, the name in the <Sender> slot becomes the \"Referred by\" instead of the sending email address. Falls back to the sender when the subject doesn't match or no pattern is set.",
    ],
    fixes: [],
    watch: [
      "A subject pattern must contain a <Sender> placeholder (validated on save).",
    ],
  },
  {
    version: "v1.2.24",
    date: "2026-07-10",
    features: [
      "Referral candidates now show a green referral icon next to their name EVERYWHERE — all three Dashboard panels, the Candidates list + drawer, the Candidate page, Resume Library cards, and the Analysis Report header (like the note/remark badges). Hover it for the referred-by (and message). List enrichment is a single batched query and is skipped entirely when no referral emails/domains are configured.",
    ],
    fixes: [],
    watch: [],
  },
  {
    version: "v1.2.23",
    date: "2026-07-10",
    features: [
      "Settings → Graph API (next to LLM Model Keys) — manage the Microsoft Graph app-registration credentials (tenant id, client id, client secret) the mail-intake + calendar integration authenticates with, from the app. The client secret is stored encrypted at rest and never shown again; editing is SysAdmin-only with own-password confirmation, and every save is audit-logged. Resolution is Settings → environment variables, so nothing changes until you save.",
    ],
    fixes: [],
    watch: [
      "The mailbox address stays under Settings → Mailbox Account; Graph API here is only the OAuth app credentials. A wrong value stops mail intake and slot scheduling — the GRAPH_* environment variables remain the fallback; clear a stored secret with \"-\".",
    ],
  },
  {
    version: "v1.2.22",
    date: "2026-07-10",
    features: [],
    fixes: [
      "Referral clip messages are now PER entry — each referral email and each domain has its own message, instead of one shared message. The candidate clip shows the matched entry's message (an exact-email match wins over a domain match). Existing single-message configs migrate automatically (the old message is copied onto each entry).",
    ],
    watch: [],
  },
  {
    version: "v1.2.21",
    date: "2026-07-10",
    features: [
      "Referrals — a new Settings section (Admin) to list sender emails and domains that classify incoming candidates as referrals, plus an optional clip message. When a candidate's resume arrived from a matching sender, the candidate page shows a clip at the top: the message (if set) followed by \"Referred by: <sender>\", or just \"Referred by: <sender>\" when no message is configured. Classification is dynamic — adding a sender's domain later marks their past candidates as referrals too.",
    ],
    fixes: [],
    watch: [
      "Referral matching uses the resume email's sender address (email_master.sender_mail_id) — upload-channel candidates with no sender aren't classified.",
    ],
  },
  {
    version: "v1.2.20",
    date: "2026-07-10",
    features: [
      "Clean-environment guardrails so dev config/data never rides along: scripts/fresh-env.ps1 (Windows) and scripts/fresh-env.sh (Linux) reset a checkout to a clean slate (empty secrets/ + dropped Docker volumes), a .dockerignore keeps secrets/.env/node_modules out of image builds, and DEPLOY.md documents exactly what carries state and how to start fresh.",
    ],
    fixes: [],
    watch: [
      "For a new environment: run scripts/fresh-env before the first 'docker compose up -d --build' — or the copied secrets/ folder (source tags, config) and reused pg_data volume (candidates, bookings) will carry the previous deployment's state.",
    ],
  },
  {
    version: "v1.2.19",
    date: "2026-07-10",
    features: [],
    fixes: [
      "System Cleanup now clears ALL candidate/interview data: it was missing the slot-invite/booking, interview-pool, and session/OTP tables — so a wiped environment kept its slot bookings (the candidate slot-picker still showed \"Your interview is booked\"). It also now clears file-based source tags, so a cleanup gives a truly fresh campaign slate.",
    ],
    watch: [
      "System Cleanup remains QA-only and is unchanged for production. A new environment is only clean if it starts from an empty secrets/ folder AND a fresh database volume — copying the project folder carries over secrets/ (source tags, config) and reusing the pg_data Docker volume carries over the database (candidates, bookings).",
    ],
  },
  {
    version: "v1.2.18",
    date: "2026-07-09",
    features: [],
    fixes: [
      "Remark text is now searchable on the Dashboard and Candidates page (it was never included in either search filter, so remark-only matches returned nothing). Both note and remark search are case-insensitive.",
    ],
    watch: [],
  },
  {
    version: "v1.2.17",
    date: "2026-07-09",
    features: [],
    fixes: [
      "Notes and remarks are capped at 250 characters (live counter in the editor, enforced server-side too) and word-wrap strictly within the sticky card — long unbroken text no longer overflows the note/remark bounds.",
      "\"Default allocation rules\" renamed to \"Pool Calculation Controls\".",
    ],
    watch: [],
  },
  {
    version: "v1.2.16",
    date: "2026-07-09",
    features: [
      "Per-round allocation-rule overrides moved INTO the funnel: each round row now has a left-side toggle that expands its override editor (slot length, gap, day cap, day rules + Reset to default) right under that round — a small dot marks a round that overrides the defaults. The separate list section is gone.",
    ],
    fixes: [],
    watch: [],
  },
  {
    version: "v1.2.15",
    date: "2026-07-09",
    features: [
      "Per-round allocation-rule overrides — in Interviewer Timeslot Pools → Default allocation rules, each round now has a \"v\" expander showing the default config (slot length, gap, day cap, day rules) that can be overridden just for that round, with Reset to default. Placeholder generation resolves the effective rules per round (override → pool base → global default).",
      "The recruiter's remark now shows as a blue postit (like the yellow note postit) — on the Candidate page (editable) and on the interviewer's link view (read-only), not just as the name badge.",
    ],
    fixes: [],
    watch: [
      "A round with no override follows the defaults exactly as before; overrides only change the rounds you set them on.",
    ],
  },
  {
    version: "v1.2.14",
    date: "2026-07-09",
    features: [
      "Candidate remarks — like notes, but ALSO visible to the interviewer on their link view. Add/Edit Remark button alongside View Resume / Report; one remark stays, shown as a BLUE note icon by the name; editable and removable (save empty to clear). Every change is in the Actions Audit Log (step: candidate_remark).",
      "Bulk notes & remarks — on the Candidates page, select candidates and apply one Note (yellow, internal) or Remark (blue, interviewer-visible) to all of them at once; each is stamped as their latest and logged (bulk).",
    ],
    fixes: [
      "Excel-with-links intake now downloads the resumes: Google Forms response sheets store the file's Drive URL in the cell HYPERLINK while showing only the filename as the value — the parser read values only, so every link failed. It now reads the hyperlink target. Verified on a real 65-row sheet.",
      "Resume-link downloads retry transient failures (network blips, timeouts, HTTP 5xx and Google Drive rate-limiting on big batches) up to 3 times with backoff. Permanent failures aren't retried and are reported clearly — a file Google flagged as malware shows \"download · infected\" in manual review (the candidate must re-share a clean file; a retry can't fix it).",
    ],
    watch: [
      "The remark is shared with the interviewer by design; the yellow note stays internal-only. A file Google Drive marks infected cannot be pulled automatically — that row lands in manual review for a human to resolve.",
    ],
  },
  {
    version: "v1.2.13",
    date: "2026-07-09",
    features: [
      "Dashboard reminder tracking rebuilt: one row per CONFIGURED reminder (\"Reminder 1 of N sent\", \"Reminder 2 of N sent\" …), and the final row states plainly that the candidate auto-rejects after the configured window (e.g. \"Reminder 2 of 2 (final) — auto-rejects after 3 days\").",
      "Reminder emails carry a templatized {auto_reject_notice}: earlier reminders mention how many nudges to expect; the FINAL reminder warns the candidate that not booking within the configured window closes the application automatically. Editable in Email Base Templates like every other placeholder.",
      "Sticky-note text is searchable: the Dashboard name search and the Candidates page search both match against the latest note's content.",
    ],
    fixes: [
      "Reminders sent by the scheduler now actually show on the Dashboard — the job only stamped the invite's counter, never the round/candidate row the Dashboard reads, so \"Reminders Sent\" stayed 0 forever.",
    ],
    watch: [
      "The per-reminder rows count candidates still awaiting a pick; once they book, they move to Interview Scheduled regardless of how many nudges it took.",
    ],
  },
  {
    version: "v1.2.12",
    date: "2026-07-09",
    features: [
      "Help requests gained \"Reset this round\" alongside Mark handled: puts the candidate back at the INITIAL stage of their current round — the old picker link is disabled outright, invite/reminder/acceptance sub-steps reset, a fresh slot-invite email draft is generated for the normal review-and-send flow, and the help flag clears. Every step (round_reset, the regenerated draft, the resolution) lands in the Actions Audit Log.",
    ],
    fixes: [
      "Add note on the Candidate page is now a small, light affordance in the top-right of the hero (where the sticky itself lives once a note exists) instead of a full action button.",
    ],
    watch: [
      "Reset this round does NOT cancel an already-booked calendar meeting — cancel that from the calendar; the popup reminds you.",
    ],
  },
  {
    version: "v1.2.11",
    date: "2026-07-09",
    features: [
      "Sticky notes can be deleted: a trash icon on the sticky (with a confirmation) clears the note — the badge disappears everywhere the name shows — while the note text AND the deletion itself are recorded in the Actions Audit Log, keeping the full history traceable.",
    ],
    fixes: [],
    watch: [],
  },
  {
    version: "v1.2.10",
    date: "2026-07-09",
    features: [
      "The sticky-note badge now follows the candidate's name EVERYWHERE it appears: all three Dashboard panels (New Potential / Being Processed / Outcomes), the Candidates list and its drawer, the Candidate page, Resume Library cards, and the Analysis Report popover header. Hover the badge to read the latest note.",
    ],
    fixes: [],
    watch: [],
  },
  {
    version: "v1.2.9",
    date: "2026-07-09",
    features: [],
    fixes: [
      "Slot picker: \"Need help?\" stays clearly available AFTER a slot is booked (and on expired invites) — now a visible \"Need help? Message the hiring team\" button under the booking card instead of a faint dotted link, and candidates can send follow-up messages (\"Send another message\") instead of the option vanishing after the first one.",
    ],
    watch: [
      "Each new help message replaces the red \"!\" flag content on the candidate's row; every message stays in the Actions Audit Log.",
    ],
  },
  {
    version: "v1.2.8",
    date: "2026-07-09",
    features: [
      "Candidate sticky notes — add a note on any candidate at any time (Add Note button on their page). The latest note shows as a yellow sticky on the Candidate page and a small sticky-note badge next to the candidate's name in lists; a footnote points to the Actions Audit Log, where the FULL notes history is recorded (step: candidate_note).",
    ],
    fixes: [
      "Slot-picker personalization: real candidates always see their own name — verified across all live invites and drafts. What looked like a dummy name was the pool table's CHECK link, which is deliberately backed by the sample candidate; those pages now say \"Slot picker preview\" with a clear \"Test invite — sample candidate\" badge instead of greeting with the fixture's name.",
    ],
    watch: [
      "A new note replaces the previous one on the sticky (latest-only by design) — nothing is lost, every note stays in the Audit Log.",
    ],
  },
  {
    version: "v1.2.7",
    date: "2026-07-09",
    features: [],
    fixes: [
      "Re-entry from Reject/Undecided offers EVERY stage option in the Change-NBA picker (Screening onward) — previously the list was floored at the round where the candidate had stopped, hiding earlier stages. Candidates actively progressing still see only forward stages.",
    ],
    watch: [],
  },
  {
    version: "v1.2.6",
    date: "2026-07-09",
    features: [
      "NBA actions now gather a comment/reason: applying a predicted NBA (single or bulk) and changing the NBA (Admin) open a popup with a text box — Apply proceeds, Cancel abandons the action. The reason lands in the candidate's Actions Audit Log; bulk applies record the SAME comment on every affected candidate, marked (bulk-apply).",
      "Token Usage hints are now data-volume aware: an early-days notice while under a week of metering, an upward-trend warning (fitted on the trailing 14 days), and a source-concentration flag when one campaign drives 60%+ of attributed spend — new hint types appear on their own as data accrues.",
    ],
    fixes: [],
    watch: [
      "The comment is optional — an empty Apply still proceeds, the audit entry just carries no Reason suffix.",
    ],
  },
  {
    version: "v1.2.5",
    date: "2026-07-09",
    features: [
      "Token Usage → Optimization hints — a panel of operational advice DERIVED from the current view's data: each hint appears only when it applies (JD-match share high → shortlist first; premium-model share high → route light modules to cheaper deployments via LLM Model Keys; input-heavy ratio → trim what's sent; chatbot/extraction/questions shares → matching habits), plus the always-on weekly per-source review and QA small-batch rehearsal habits.",
    ],
    fixes: [],
    watch: [
      "Hints react to the source/time filters — narrowing the view re-derives the advice for that slice.",
    ],
  },
  {
    version: "v1.2.4",
    date: "2026-07-09",
    features: [
      "Help (avatar → Help — User Manual) refreshed for the latest changes: Match JD marked Admin-only with the shortlist-first token caution, the Token Usage trend & forecast chart, the chatbot enable/usage token cautions, plus new quick answers (\"Why can't I see Match JD?\" for recruiters, \"Does the chatbot cost anything?\").",
    ],
    fixes: [],
    watch: [],
  },
  {
    version: "v1.2.3",
    date: "2026-07-09",
    features: [
      "Match JD is now Admin-only (hidden for other roles and enforced server-side), with a token-cost caution in the modal: narrow filters to a shortlist first, results are session-only AI estimates, spend is metered in Token Usage.",
      "Chatbot cautions: enabling it in Settings now asks for confirmation (two LLM calls per question, for every user, on every page) and shows a standing token note; the chat itself reminds users each question spends metered AI tokens.",
    ],
    fixes: [
      "LLM Model Keys section restyled into the standard settings shell — consistent look, chevron and search-focus behaviour with every other section.",
    ],
    watch: [
      "Recruiters no longer see the Match JD button; existing JD scores in their session disappear on refresh. The /jd-match API returns 403 for non-Admins.",
    ],
  },
  {
    version: "v1.2.2",
    date: "2026-07-08",
    features: [
      "Token Usage: consumption trend & 7-day forecast — a line/area chart of daily tokens, overall (fuchsia area) plus per-module lines, with a dashed straight-line projection and a module multiselect filter (empty = all modules).",
      "In-app Help refreshed across all roles for everything recent: Token Usage, LLM Model Keys, JD-match explanations, source funnel health, staff link access, funnel sliders, changelog popup.",
    ],
    fixes: [
      "Token Usage source filter now lists every registered source tag (not just tags that already had metered usage).",
      "Settings: LLM Model Keys stretches full-width like the other sections and is findable via the type-ahead section search.",
    ],
    watch: [
      "Security hardening: one-time OTP codes and session tokens are now stored as SHA-256 digests (existing unexpired codes/sessions were invalidated once — just re-verify); the JWT signing secret auto-generates a strong value in secrets/jwt_secret.key when none is configured (everyone was logged out once); freshly-seeded default accounts must change their password at first sign-in. The stored mailbox credential was migrated to the new encryption key.",
      "The forecast is a least-squares straight line over the trailing 14 days — a planning aid, not a promise.",
    ],
  },
  {
    version: "v1.2.1",
    date: "2026-07-08",
    features: [
      "Settings → LLM Model Keys — input and maintain the AI provider connection (endpoint, API key, API version, default + fallback deployment) from the app. Keys are stored encrypted at rest, never shown again, and every save is audit-logged.",
      "Per-module LLM access keys — each module (extraction, analysis report, timeline, interview questions, JD match, chatbot) can carry its own deployment/endpoint/key override, e.g. run the chatbot on a cheaper model. Modules match the Token Usage page 1:1.",
    ],
    fixes: [],
    watch: [
      "Resolution order per LLM call: module override → Settings config → environment variables. With nothing saved in Settings, behaviour is exactly as before (env-driven).",
      "Editing is SysAdmin-only with own-password re-confirmation (Admins see it read-only). A wrong endpoint/key stops all AI features — the env values remain the safety net; clear a stored key with \"-\".",
    ],
  },
  {
    version: "v1.2.0",
    date: "2026-07-08",
    features: [
      "Token Usage page (Admin-only, left nav) — tokenomics dashboard over every LLM call in the app: totals with estimated cost, daily prompt-vs-completion timeline, and breakdowns by module (extraction, analysis report, timeline, interview questions, JD match, chatbot), source tag and model. Hero bar carries source-tag + time-range filters (presets or custom dates).",
      "JD Match \"why this score?\" — clicking a candidate's score in the JD Match column opens a detailed popup: verdict summary, five dimension scores (skills/experience/domain/education/role), what meets the JD and what's missing. Computed on demand, session-only.",
    ],
    fixes: [
      "\"Generate Interview Questions\" is hidden once the interview is complete and the verdict is submitted — on both the Candidate page and the interviewer's link view.",
    ],
    watch: [
      "Token metering starts with this build — usage before v1.2.0 was never recorded, so historical ranges will read empty. Costs come from a static price map: use them to compare modules/campaigns, not as a bill.",
      "Token-usage source attribution follows the candidate's CURRENT tag (re-tagging re-attributes past usage); chatbot and JD batch calls show under \"No source\".",
    ],
  },
  {
    version: "v1.1.3",
    date: "2026-07-08",
    features: [
      "Staff access to slot-picker check URLs — an Admin/SysAdmin opening a pool's \"Time-slot picker URL\" can verify with their own app credentials instead of needing the candidate's emailed one-time code. Every staff open is recorded in the Actions Audit Log.",
    ],
    fixes: [],
    watch: [
      "The staff-credential option only appears on links opened from the app (the pool table's Open appends ?staff=1) — candidates' emailed links never show it. The Copy button copies the clean candidate URL without the flag.",
      "The staff-access endpoint is role-gated server-side (admin/sysadmin only) — recruiter credentials or a hand-typed ?staff=1 get a 403.",
    ],
  },
  {
    version: "v1.1.2",
    date: "2026-07-08",
    features: [
      "Per-source process-health funnel — a funnel icon on every row of Register Source opens actual candidates processed through every stage till date, live in-flight counts, and the oldest candidate waiting at each stage (clean green banner for finished sources).",
      "Pool sizing simplified to funnel sliders — one slider per round with a live 100-candidate funnel preview; Calculate & save re-targets every pool.",
      "This changelog — click the version in the sidebar (QA only) to see what each build shipped.",
    ],
    fixes: [
      "Rounds passed via a leapfrog verdict (\"Move to Final\"), \"Can be Hired\", or an admin direct verdict no longer show \"Pending\" forever on the Candidate page and Interviewer view — the verdict is now stamped on the round after the NBA automation runs. Five previously-stuck rounds were backfilled to Pass.",
      "Funnel panels restyled glassmorphic with theme-token text so counts stay readable in dark and light modes.",
    ],
    watch: [
      "Interviewer verdicts that route through an NBA key record the round outcome ONLY after the NBA succeeds — if the automation fails, the round intentionally stays Pending so the verdict can be resubmitted.",
    ],
  },
  {
    version: "v1.1.1",
    date: "2026-07-08",
    features: [
      "Mailbox account configuration (inbox email/password, scan folder, per-outcome folders) — credentials encrypted at rest, gated behind a SysAdmin re-auth with a risk warning; lives in the Mailbox page's settings drawer.",
      "Email Base Templates: manage the base emails drafts build from, with per-template Reset to default; shipped defaults for Final round (in-office, with Pune office address) and Final round (online).",
      "Reminder templates carry \"Reminder X of Y\" and a {round_name} placeholder; auto-reject template included.",
      "One live pool per Source Tag enforced on pool creation; per-round \"Interview time-slot picker URL\" column on pools.",
    ],
    fixes: [
      "Resumes fed by the mail poller are stamped with the ACTIVE source tag (email-channel candidates no longer show \"—\").",
      "Batch archive schema drift fixed (live vs archive column sync) and archive errors now show inline in the confirm dialog.",
    ],
    watch: [
      "Mailbox credentials in the DB override the GRAPH_MAILBOX/GRAPH_FOLDER_* env values once saved — clear the DB config to fall back to env.",
    ],
  },
  {
    version: "v1.1.0",
    date: "2026-07-07",
    features: [
      "Interviewer verdicts can move a candidate to ANY later round (Round N+1 … Final) or \"Can be Hired\" — driving the NBA, email drafts and stage movement; promotions past the next round require a written justification.",
      "Interview score picked from 11 emoji (0–10); cherry-picked questions saved to the feedback sheet; Round history on the interviewer page matches the Candidate page (shared component, fast-tracked rounds shown as merged cards).",
      "Password management: first-time users must change their password; Change password in the profile menu; Admin can reset any user's password to a one-time generated value; the system always keeps at least one Admin.",
      "Slot-picker \"Need help?\" button — messages surface as a red \"!\" on the candidate row with Mark handled.",
      "Process Flow repainted: glassy theme-aware stages, source-tag filter, real per-stage sub-step stats, clicks deep-link into the Dashboard.",
      "Mailbox page: merged pipeline status bar + stats mini-donut (defaults to the active tag), settings drawer under the hero bar (pools / archive / templates / mailbox account).",
      "In-app Help — role-filtered User Manual for Admins, SysAdmins and Recruiters.",
      "Claymorphic environment badge; Admin click explains candidate-email risk and how to switch to PRD.",
    ],
    fixes: [
      "Blank white pages fixed twice over: stale cached index.html (nginx no-store) and FastAPI 422 detail objects rendered raw (global error boundary + readable messages).",
      "Add-user validation happens in the page with a proper confirmation popup; user deletion cannot remove the last Admin.",
    ],
    watch: [
      "Reminder/auto-reject intervals accept MINUTES in the QA env only — production only allows hours/days.",
      "A verdict of \"Can be Hired\" sets status Hired without creating further rounds; use the NBA picker to pull a candidate back if picked by mistake.",
    ],
  },
  {
    version: "v1.0.4",
    date: "2026-06-30",
    features: [
      "Filters for all 17 fields extracted from resumes on the upload/screening tables.",
      "Customizable table columns — pick which columns each table displays.",
      "Thinking summary (intuition) on candidate analysis; single-line highlighter on the candidate row.",
    ],
    fixes: [
      "Candidate profile showed Active even when Rejected; dashboard LHS/RHS table sorting; aging/action dates on resumes being processed.",
    ],
    watch: [],
  },
  {
    version: "v1.0.0",
    date: "2026-06-29",
    features: [
      "First alpha — resume intake by mail/upload, extraction pipeline, screening, dashboard, interview rounds, NBA predictions and email drafting.",
    ],
    fixes: [],
    watch: [],
  },
];
