// Single source of truth for the app version shown in the UI (Sidebar footer).
// Bump this on each release — it no longer comes from a build-time env var, so a
// version change is a tracked code change, not an environment/Docker tweak.
// MAINTENANCE RULE: every bump here needs a matching entry at the TOP of
// config/changelog.ts (features / fixes / watch-outs for the build).
export const APP_VERSION = "v1.6.4"; // format: v<MAJOR>.<MINOR>.<PATCH>_<YYYYMMDD>.<HHMM>