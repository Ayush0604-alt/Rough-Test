// Registry of the columns that can be toggled on the Candidates (Screening) table via the
// "Columns" button → Column Config. Each entry maps a column key → a header + a cell
// renderer reading from a CandidateMaster row. Visibility (and only visibility) is driven
// by the saved config (/settings/columns); the order here is the fixed left-to-right
// display order.
//
// To add a new configurable column: add a ResumeColumn here AND a matching entry in the
// backend column list (app/services/column_config.py _COLUMNS). "Candidate" (name) and
// "Experience" are gated separately in the Screening table; "Interview" (action) is pinned
// and not configurable.
import type { ReactNode } from "react";
import { Mail } from "lucide-react";
import type { CandidateMaster, JobRole } from "@/types";
import { parseCertificates } from "@/types/candidate";
import { nbaLabel } from "@/components/candidate/NextActionOverride";
import { formatExperience, formatScore } from "@/lib/utils";
import { nlrsBreakdownTitle } from "@/lib/score";

export interface ResumeColumn {
  key: string; // must match a key in the backend column list (column_config.py)
  header: string;
  render: (c: CandidateMaster) => ReactNode;
  // When set, the column header is a clickable sort control. The value must be one of the
  // Screening page's SortKey members (it owns the per-row comparison in sortKeyValue).
  sortKey?: string;
}

const DASH = <span className="text-muted-foreground">—</span>;

// JSONB list columns arrive as arrays or legacy " · "-joined strings.
// Exported: also used by the Screening page's click-to-sort (sort list columns by count).
export function toStrList(v: string[] | string | null | undefined): string[] {
  if (Array.isArray(v)) return v.map(String).filter(Boolean);
  if (typeof v === "string" && v.trim()) return v.split(" · ").filter(Boolean);
  return [];
}

export function jobRoleTitles(v: CandidateMaster["job_roles"]): string[] {
  if (Array.isArray(v)) {
    return v
      .map((r) =>
        typeof r === "string"
          ? r
          : [(r as JobRole).role, (r as JobRole).company].filter(Boolean).join(" @ "),
      )
      .filter(Boolean);
  }
  return toStrList(v as string | null | undefined);
}

// Compact cell for a list: first two items + "+N", full set in the tooltip.
function ListCell({ items }: { items: string[] }): ReactNode {
  if (items.length === 0) return DASH;
  const extra = items.length - 2;
  return (
    <span
      title={items.join(", ")}
      className="block max-w-[200px] truncate text-xs text-muted-foreground"
    >
      {items.slice(0, 2).join(", ")}
      {extra > 0 ? ` +${extra}` : ""}
    </span>
  );
}

function TextCell(value: string | number | null | undefined): ReactNode {
  if (value === null || value === undefined || value === "") return DASH;
  return (
    <span className="block max-w-[200px] truncate text-xs text-muted-foreground" title={String(value)}>
      {value}
    </span>
  );
}

// Wider single-line cell (truncated, full text in tooltip) for long prose columns like
// the one-line / thinking summaries.
function ProseCell(value: string | null | undefined): ReactNode {
  if (!value) return DASH;
  return (
    <span className="block max-w-[320px] truncate text-xs text-muted-foreground" title={value}>
      {value}
    </span>
  );
}

// "Thinking Summary" = the LLM analysis narrative ONLY — strip the appended ATS score
// trailer (mirrors the Candidate page split) so the column shows just the prose.
// Exported: also used by the Screening page's click-to-sort.
export function thinkingSummaryText(analysis: string | null | undefined): string {
  return (analysis ?? "")
    .split(/\n*\s*ATS\s+\d+\/100\s*\((?:deterministic|scored)\)/i)[0]
    .trim();
}

// "Next Best Action" cell value — a recruiter override (next_action_override) takes
// precedence over the computed next_action.label, same precedence as the Dashboard /
// candidate-profile boxes. Exported: also used by the Screening page's click-to-sort.
export function nextBestActionLabel(c: CandidateMaster): string | null | undefined {
  return c.next_action_override ? nbaLabel(c, c.next_action_override) : c.next_action?.label;
}

// Canonical order = display order (visibility is the only thing the YAML controls).
// Every column carries a sortKey — text/prose columns sort case-insensitively, list
// columns (Projects/Certificates/Job Role/Primary Skills) sort by item COUNT, and
// Next Best Action sorts on the same override-aware label it renders.
const ALL_RESUME_COLUMNS: ResumeColumn[] = [
  { key: "email", header: "Email", sortKey: "email", render: (c) => TextCell(c.email) },
  { key: "phone", header: "Phone", sortKey: "phone", render: (c) => TextCell(c.phno) },
  { key: "location", header: "Location", sortKey: "location", render: (c) => TextCell(c.currentlocation) },
  { key: "source", header: "Source", sortKey: "source", render: (c) => TextCell(c.source) },
  { key: "college", header: "College", sortKey: "college", render: (c) => TextCell(c.clg) },
  { key: "highest_degree", header: "Highest Degree", sortKey: "highest_degree", render: (c) => TextCell(c.highest_coursecompleted) },
  { key: "domain", header: "Domain", sortKey: "domain", render: (c) => TextCell(c.domain) },
  { key: "passout_year", header: "Passout Year", sortKey: "passout_year", render: (c) => TextCell(c.passoutyr) },
  { key: "cgpa", header: "CGPA", sortKey: "cgpa", render: (c) => TextCell(c.cgpa != null ? c.cgpa.toFixed(1) : null) },
  { key: "projects", header: "Projects", sortKey: "projects", render: (c) => <ListCell items={toStrList(c.projects)} /> },
  {
    key: "certificates",
    header: "Certificates",
    sortKey: "certificates",
    render: (c) => <ListCell items={parseCertificates(c.certificates).map((x) => x.name)} />,
  },
  { key: "fresher_or_lateral", header: "Fresher / Lateral", sortKey: "fresher_or_lateral", render: (c) => TextCell(c.fresher_or_lateral) },
  { key: "current_company", header: "Current Company", sortKey: "current_company", render: (c) => TextCell(c.currentcompany) },
  { key: "job_role", header: "Job Role", sortKey: "job_role", render: (c) => <ListCell items={jobRoleTitles(c.job_roles)} /> },
  {
    key: "experience",
    header: "Experience",
    sortKey: "experience",
    render: (c) =>
      TextCell(
        c.fresher_or_lateral === "Fresher"
          ? "Fresher"
          : c.yearofexp != null
            ? formatExperience(c.yearofexp)
            : null,
      ),
  },
  { key: "career_gap", header: "Career Gap", sortKey: "career_gap", render: (c) => TextCell(c.careergap) },
  { key: "primary_skills", header: "Primary Skills", sortKey: "primary_skills", render: (c) => <ListCell items={toStrList(c.primary_skills)} /> },
  // ATS / interview-plan columns (not raw resume fields, but configurable alongside them).
  // A recruiter override (next_action_override) takes precedence over the computed
  // next_action.label — same precedence as the Dashboard / candidate-profile boxes.
  {
    key: "next_best_action",
    header: "Next Best Action",
    sortKey: "next_best_action",
    render: (c) => (
      <span className="flex items-center gap-1">
        {ProseCell(nextBestActionLabel(c))}
        {c.pending_email_draft && (
          <span title="Email draft ready for review — open the Analysis Report to review it">
            <Mail className="h-3 w-3 shrink-0 text-amber-500" />
          </span>
        )}
      </span>
    ),
  },
  { key: "one_line_summary", header: "One-Line Summary", sortKey: "one_line_summary", render: (c) => ProseCell(c.role_context) },
  { key: "thinking_summary", header: "Thinking Summary", sortKey: "thinking_summary", render: (c) => ProseCell(thinkingSummaryText(c.analysis)) },
  // NLRS (Neuleap Resume Score) — 65% Analysis Report + 20% Certificates +
  // 10% Years of experience + 5% ATS, computed live (app.services.nlrs).
  {
    key: "nlrs",
    header: "NLRS",
    sortKey: "nlrs",
    render: (c) => {
      if (c.nlrs == null) return DASH;
      const s = c.nlrs.score;
      const tone = s >= 70 ? "text-emerald-500" : s >= 45 ? "text-amber-500" : "text-rose-500";
      return (
        <span
          title={nlrsBreakdownTitle(c.nlrs)}
          className={`text-xs font-bold tabular-nums ${tone}`}
        >
          {formatScore(s)}
        </span>
      );
    },
  },
];

// Lookup so the table can resolve a saved column key → its renderer.
const COLUMN_BY_KEY = new Map(ALL_RESUME_COLUMNS.map((col) => [col.key, col]));

// Excel-sourced dynamic columns (see app.services.column_config): keys like
// "College__from-source-sheet" / "CGPA__from-resume" aren't in the static
// registry — synthesize a renderer that reads candidate.source_columns[key].
const SHEET_SUFFIX = "__from-source-sheet";
const RESUME_SUFFIX = "__from-resume";

function isDynamicSourceKey(key: string): boolean {
  return key.endsWith(SHEET_SUFFIX) || key.endsWith(RESUME_SUFFIX);
}

function dynamicSourceColumn(key: string): ResumeColumn {
  const header = key.endsWith(SHEET_SUFFIX)
    ? `${key.slice(0, -SHEET_SUFFIX.length)} (sheet)`
    : key.endsWith(RESUME_SUFFIX)
      ? `${key.slice(0, -RESUME_SUFFIX.length)} (resume)`
      : key;
  return {
    key,
    header,
    render: (c) => TextCell(c.source_columns?.[key] ?? null),
  };
}

// Single registry column by key — lets the table interleave registry columns with the
// operational ones in ONE saved order (so drag-reorder moves every column, not just these).
export function resumeColumnFor(key: string): ResumeColumn | undefined {
  return COLUMN_BY_KEY.get(key) ?? (isDynamicSourceKey(key) ? dynamicSourceColumn(key) : undefined);
}

// The visible configurable columns, in the SAVED ORDER from the Column Config panel.
// `candidate_name` is pinned far-left and rendered separately by the table, so it's
// excluded here. Unknown static keys are skipped; dynamic Excel keys are synthesized.
export function orderedVisibleColumns(
  columns: { key: string; visible: boolean }[],
): ResumeColumn[] {
  return columns
    .filter((c) => c.visible && c.key !== "candidate_name")
    .map((c) => resumeColumnFor(c.key))
    .filter((c): c is ResumeColumn => c !== undefined);
}
