// ── Shared intake-year filter ────────────────────────────────────────────────
// The selected intake year (the year a resume's mail arrived — mail_send_date,
// falling back to created_at) is a GLOBAL filter: pick it once on the Dashboard
// and every candidate list across the app scopes to it by default. The choice is
// persisted in localStorage and synced live across pages/tabs via storage events.
import { useEffect, useState } from "react";

export const CURRENT_YEAR = new Date().getFullYear();
export const ALL_YEARS = "all" as const;
export type YearFilter = number | typeof ALL_YEARS;
export const YEAR_STORAGE_KEY = "dashboard.year";

// Year options for the picker: the current year and the single year before it —
// never future years. If the active selection is an older past year (e.g. a
// sticky value from before), it's included too, but a future year never is.
export function pickerYears(selected: YearFilter): number[] {
  const set = new Set<number>([CURRENT_YEAR, CURRENT_YEAR - 1]);
  if (selected !== ALL_YEARS && selected < CURRENT_YEAR) set.add(selected);
  return Array.from(set).sort((a, b) => b - a);
}

// Intake year of a candidate, parsed from mail_send_date (fallback: created_at).
export function yearOf(c: {
  mail_send_date?: string | null;
  created_at?: string | null;
}): number | null {
  const m = String(c.mail_send_date || c.created_at || "").match(/^(\d{4})/);
  return m ? Number(m[1]) : null;
}

// Read the persisted year (defaults to the current year on first use).
export function loadYear(): YearFilter {
  const saved = localStorage.getItem(YEAR_STORAGE_KEY);
  if (saved === ALL_YEARS) return ALL_YEARS;
  const n = saved ? Number(saved) : NaN;
  return Number.isFinite(n) ? n : CURRENT_YEAR;
}

// A custom event so same-tab listeners update too (the native `storage` event
// only fires in OTHER tabs/windows).
const YEAR_EVENT = "dashboard-year-change";

// Shared hook: returns the current global year and a setter that persists it and
// notifies every other consumer (this tab and others) so all lists stay in sync.
export function useGlobalYear(): [YearFilter, (y: YearFilter) => void] {
  const [year, setYearState] = useState<YearFilter>(loadYear);

  useEffect(() => {
    const sync = () => setYearState(loadYear());
    window.addEventListener("storage", sync);
    window.addEventListener(YEAR_EVENT, sync);
    return () => {
      window.removeEventListener("storage", sync);
      window.removeEventListener(YEAR_EVENT, sync);
    };
  }, []);

  const setYear = (y: YearFilter) => {
    localStorage.setItem(YEAR_STORAGE_KEY, String(y));
    setYearState(y);
    window.dispatchEvent(new Event(YEAR_EVENT));
  };

  return [year, setYear];
}
