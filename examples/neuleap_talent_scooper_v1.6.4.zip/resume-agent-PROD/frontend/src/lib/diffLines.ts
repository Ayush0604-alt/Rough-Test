// Minimal line-level diff (LCS-based) — used by Settings' SKILL.md upload
// comparison so an Admin can see exactly what changes before it's saved.
// No external dep: an LCS dynamic-programming table over LINES (not
// characters) keeps this fast enough for a several-hundred-line prompt file.
export type DiffLineType = "same" | "added" | "removed";
export interface DiffLine {
  type: DiffLineType;
  text: string;
}

// Above this many (oldLines * newLines) cells, skip the DP table — it would
// be slow/memory-heavy for a huge file. Callers should fall back to a plain
// side-by-side view in that case (see hasDiffSizeLimit).
const MAX_CELLS = 4_000_000; // e.g. ~2000 lines each

export function diffSizeExceeded(oldText: string, newText: string): boolean {
  const n = oldText.split("\n").length;
  const m = newText.split("\n").length;
  return n * m > MAX_CELLS;
}

export function diffLines(oldText: string, newText: string): DiffLine[] {
  const a = oldText.split("\n");
  const b = newText.split("\n");
  const n = a.length;
  const m = b.length;

  const dp: number[][] = Array.from({ length: n + 1 }, () => new Array(m + 1).fill(0));
  for (let i = n - 1; i >= 0; i--) {
    for (let j = m - 1; j >= 0; j--) {
      dp[i][j] = a[i] === b[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
    }
  }

  const result: DiffLine[] = [];
  let i = 0;
  let j = 0;
  while (i < n && j < m) {
    if (a[i] === b[j]) {
      result.push({ type: "same", text: a[i] });
      i++;
      j++;
    } else if (dp[i + 1][j] >= dp[i][j + 1]) {
      result.push({ type: "removed", text: a[i] });
      i++;
    } else {
      result.push({ type: "added", text: b[j] });
      j++;
    }
  }
  while (i < n) {
    result.push({ type: "removed", text: a[i] });
    i++;
  }
  while (j < m) {
    result.push({ type: "added", text: b[j] });
    j++;
  }
  return result;
}

// Collapses long unchanged runs to "... N unchanged lines ..." markers (kept
// as `context` lines of same-type padding around each change), so a mostly-
// identical file doesn't bury the actual edits in hundreds of same lines.
export interface DiffDisplayLine extends DiffLine {
  key: number;
}
export type DiffDisplayItem = DiffDisplayLine | { type: "collapsed"; count: number; key: number };

export function collapseUnchanged(lines: DiffLine[], context = 3): DiffDisplayItem[] {
  const out: DiffDisplayItem[] = [];
  let i = 0;
  let key = 0;
  while (i < lines.length) {
    if (lines[i].type !== "same") {
      out.push({ ...lines[i], key: key++ });
      i++;
      continue;
    }
    // Start of a same-run — find its extent.
    let j = i;
    while (j < lines.length && lines[j].type === "same") j++;
    const runLength = j - i;
    if (runLength <= context * 2) {
      for (let k = i; k < j; k++) out.push({ ...lines[k], key: key++ });
    } else {
      const showStart = i === 0 ? 0 : context; // no leading context at the very top
      const showEnd = j === lines.length ? 0 : context; // no trailing context at the very end
      for (let k = i; k < i + showStart; k++) out.push({ ...lines[k], key: key++ });
      const hiddenCount = runLength - showStart - showEnd;
      if (hiddenCount > 0) out.push({ type: "collapsed", count: hiddenCount, key: key++ });
      for (let k = j - showEnd; k < j; k++) out.push({ ...lines[k], key: key++ });
    }
    i = j;
  }
  return out;
}
