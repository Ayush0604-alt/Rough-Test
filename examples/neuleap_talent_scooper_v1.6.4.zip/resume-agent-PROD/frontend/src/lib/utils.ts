import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Title-case a name however it arrived from the resume (ALL CAPS, all
 * lowercase, mixed) — e.g. "KALYANI DHORDE" / "sadhna kumari" → "Kalyani
 * Dhorde" / "Sadhna Kumari". Lowercases everything then capitalizes the first
 * letter of each whitespace-separated word; short connector words (of/de/da)
 * are left as-is by design — simple and predictable beats "correct" for names.
 */
export function titleCase(raw: string | null | undefined): string {
  if (!raw) return "";
  return raw
    .toLowerCase()
    .split(" ")
    .map((word) => (word ? word[0].toUpperCase() + word.slice(1) : word))
    .join(" ");
}

/**
 * Up to 2 initials for an avatar badge, derived from the title-cased name so
 * an all-caps or all-lowercase source (e.g. "KALYANI DHORDE", "sadhna kumari")
 * never renders lowercase initials next to a title-cased name label.
 */
export function initialsOf(raw: string | null | undefined): string {
  const words = titleCase(raw).split(" ").filter(Boolean);
  return words.map((w) => w[0]).slice(0, 2).join("") || "?";
}

/**
 * Years of experience, formatted identically everywhere in the app: 1 decimal
 * place plus a literal "y" suffix (e.g. "3.3y", "0.0y").
 */
export function formatExperience(years: number | null | undefined): string {
  if (years == null) return "—";
  return `${years.toFixed(1)}y`;
}

/**
 * ATS/NLRS score, formatted identically everywhere in the app: exactly 2
 * decimal places (e.g. "74.90", "0.00").
 */
export function formatScore(score: number | null | undefined): string {
  if (score == null) return "—";
  return score.toFixed(2);
}

/**
 * A date-only stamp (e.g. mail_send_date, a scheduled round date) as
 * "3 Jul 2026" — the short format shared by every received/scheduled-date
 * column and tooltip across the app.
 */
export function formatDate(raw?: string | null): string {
  if (!raw) return "—";
  const d = new Date(raw);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });
}

/**
 * Render an ISO timestamp (e.g. the scheduler's "2026-06-19T00:00:00+05:30")
 * as a human-readable IST string like "19 Jun 2026, 12:00 AM IST".
 *
 * Non-date inputs (a friendly fallback such as "3:30 AM IST (daily)", "", null)
 * are returned as-is, with an em dash for empty values.
 */
export function formatDateTime(raw?: string | null): string {
  if (!raw) return "—";
  const d = new Date(raw);
  if (Number.isNaN(d.getTime())) return raw; // already human-readable / a fallback label
  return (
    d.toLocaleString("en-IN", {
      day: "numeric",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      hour12: true,
      timeZone: "Asia/Kolkata",
    }) + " IST"
  );
}

/**
 * Normalize an axios/FastAPI error into a plain, renderable string. FastAPI's
 * 422 validation errors put an ARRAY of {type, loc, msg, input, ctx} objects
 * in `detail` — rendering that raw as a React child crashes the whole app
 * (minified React error #31, a silent white page). Every catch block that
 * displays `detail` should route through this instead.
 */
export function apiErrorMessage(e: unknown, fallback: string): string {
  const detail = (e as { response?: { data?: { detail?: unknown } } })?.response?.data?.detail;
  if (typeof detail === "string" && detail.trim()) return detail;
  if (Array.isArray(detail)) {
    const msgs = detail
      .map((d) => {
        if (!d || typeof d !== "object") return null;
        const { msg, loc } = d as { msg?: unknown; loc?: unknown };
        if (typeof msg !== "string") return null;
        const field = Array.isArray(loc) && loc.length ? String(loc[loc.length - 1]) : null;
        return field && field !== "body" ? `${field}: ${msg}` : msg;
      })
      .filter(Boolean);
    if (msgs.length > 0) return msgs.join(" · ");
  }
  if (detail && typeof detail === "object" && typeof (detail as { msg?: unknown }).msg === "string") {
    return (detail as { msg: string }).msg;
  }
  return fallback;
}
