// Mail-aging presentation — bucket colors, labels, and age formatting shared by
// the Intake table pill and the Dashboard aging report so they never diverge.
// Bucket thresholds themselves live server-side (app/api/reads.py); the SPA only
// renders whatever bucket the API assigned.
import type { AgingBucket } from "@/types/email";

export const AGING_ORDER: AgingBucket[] = ["fresh", "aging", "stale", "critical"];

export const AGING_LABEL: Record<AgingBucket, string> = {
  fresh: "Fresh",
  aging: "Aging",
  stale: "Stale",
  critical: "Critical",
};

// Pill classes (text + bg + border) per bucket — same palette as final-status pills.
export const AGING_PILL_CLS: Record<AgingBucket, string> = {
  fresh: "text-emerald-600 bg-emerald-500/10 border-emerald-500/30",
  aging: "text-amber-600 bg-amber-500/10 border-amber-500/30",
  stale: "text-orange-600 bg-orange-500/10 border-orange-500/30",
  critical: "text-rose-600 bg-rose-500/10 border-rose-500/30",
};

// Solid bar fill per bucket — for the Dashboard report's horizontal bars.
export const AGING_BAR_CLS: Record<AgingBucket, string> = {
  fresh: "bg-emerald-500",
  aging: "bg-amber-500",
  stale: "bg-orange-500",
  critical: "bg-rose-500",
};

export const AGING_RANGE: Record<AgingBucket, string> = {
  fresh: "< 1 day",
  aging: "1–3 days",
  stale: "3–7 days",
  critical: "> 7 days",
};

// Compact age label: "5h" under a day, "3d" otherwise. null age ⇒ "—".
export function formatAge(hours?: number | null): string {
  if (hours == null) return "—";
  if (hours < 1) return "<1h";
  if (hours < 24) return `${Math.round(hours)}h`;
  return `${Math.round(hours / 24)}d`;
}
