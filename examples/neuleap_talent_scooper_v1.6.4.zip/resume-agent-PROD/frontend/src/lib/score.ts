import type { CandidateMaster, Nlrs } from "@/types";
import { formatExperience, formatScore } from "@/lib/utils";

/**
 * Hover text for an NLRS score: total + each component's weightage
 * (subscore × weight = contribution), one line per component. Shared by every
 * place that shows an NLRS number so the breakdown reads identically everywhere.
 */
export function nlrsBreakdownTitle(nlrs: Nlrs): string {
  const breakdown = nlrs.components
    .map((k) => `${k.label}: ${k.subscore.toFixed(0)} × ${Math.round(k.weight * 100)}% = ${k.weighted.toFixed(1)}`)
    .join("\n");
  return `NLRS ${formatScore(nlrs.score)}\n${breakdown}`;
}

export interface ScoreBand {
  /** Tailwind text color for the score figure + gauge stroke. */
  text: string;
  /** Tailwind bg color for solid bars. */
  bar: string;
  /** Raw stroke color for the SVG gauge (uses currentColor via text). */
  label: string;
}

/** ATS score → color band. Shared by ScoreCard and any list chip. */
export function scoreBand(score: number | null | undefined): ScoreBand {
  const s = score ?? 0;
  if (s >= 85) return { text: "text-emerald-400", bar: "bg-emerald-500", label: "Excellent" };
  if (s >= 70) return { text: "text-blue-400", bar: "bg-blue-500", label: "Strong" };
  if (s >= 55) return { text: "text-yellow-400", bar: "bg-yellow-500", label: "Moderate" };
  return { text: "text-red-400", bar: "bg-red-500", label: "Low" };
}

export interface ScoreFactor {
  label: string;
  /** 0..100 contribution strength for the breakdown bar. */
  value: number;
  /** Short human note. */
  note: string;
  positive: boolean;
}

const TIER1 = ["IIT", "BITS", "IIIT", "NIT"];

/**
 * Targets mirror the backend deterministic ATS formula (scoring_config DEFAULT_PARAMS /
 * app.services.ats_scoring). Keeping them in sync means each breakdown bar reflects how
 * the real atsscore is actually computed, instead of inventing arbitrary curves with
 * base offsets that pin every candidate near full.
 */
const ATS = {
  expTargetYears: 5, // exp_target_years — years that fully fill the Experience bar
  skillsTarget: 10, // skills that fully fill the Skills bar — max 10, so the bar never reads 100% below 10 skills
  certsTarget: 10, // certificates that fully fill the Certifications bar — max 10, same rule as skills
  gapThresholdMonths: 12, // gap_penalty_threshold_months — gap size at full impact
} as const;

/** Education ladder → 0..100 by highest course completed; Tier-1 institution lifts the band. */
const EDU_LEVEL: Record<string, number> = { PhD: 100, Master: 85, Bachelor: 65, Diploma: 45 };

const clamp = (n: number) => Math.max(0, Math.min(100, Math.round(n)));

/**
 * Experience bar strength (0..100).
 * Rule: a Fresher — or anyone with no recorded experience — sits at 0. Otherwise the
 * bar is years-of-experience as a fraction of the target (5y = full), capped at 100.
 */
function experienceValue(c: CandidateMaster): number {
  const exp = c.yearofexp ?? 0;
  if (c.fresher_or_lateral === "Fresher" || exp <= 0) return 0;
  return clamp((exp / ATS.expTargetYears) * 100);
}

/**
 * Education bar strength (0..100).
 * Rule: degree level sets the band (Diploma → PhD), a Tier-1 institution adds a lift,
 * and a still-pursuing qualification is discounted since it isn't completed yet.
 */
function educationValue(c: CandidateMaster): number {
  const base = EDU_LEVEL[c.highest_coursecompleted ?? ""] ?? 0;
  if (base === 0) return 0;
  const tier1 = TIER1.some((t) => (c.clg ?? "").toUpperCase().includes(t));
  const pursuing = c.education_status === "pursuing";
  return clamp((base + (tier1 ? 10 : 0)) * (pursuing ? 0.7 : 1));
}

/**
 * Skills bar strength (0..100).
 * Rule: number of extracted primary skills as a fraction of the target (10 = full).
 * Capped at 10, so a candidate with fewer than 10 skills never reads a full bar.
 */
function skillsValue(skills: number): number {
  return clamp((Math.min(skills, ATS.skillsTarget) / ATS.skillsTarget) * 100);
}

/**
 * Certifications bar strength (0..100).
 * Rule: number of certificates as a fraction of the target (10 = full). Capped at 10,
 * so 4 certs reads 40% rather than saturating the bar.
 */
function certificationsValue(certs: number): number {
  return clamp((Math.min(certs, ATS.certsTarget) / ATS.certsTarget) * 100);
}

/**
 * Career-gap bar strength (0..100) — a PENALTY meter, not a strength.
 * Rule: 0 with no gap; otherwise gap months as a fraction of the penalty threshold
 * (12mo = full impact), capped at 100.
 */
function gapValue(gapMonths: number): number {
  return gapMonths > 0 ? clamp((gapMonths / ATS.gapThresholdMonths) * 100) : 0;
}

/**
 * Derive a transparent ATS breakdown from existing candidate fields — no new data.
 * These are explanatory factors (experience, education, skills, certs bonus, gap impact)
 * computed from what L3 already extracted, so the score feels first-class without
 * inventing a backend contract.
 */
export function scoreFactors(c: CandidateMaster): ScoreFactor[] {
  const skills = Array.isArray(c.primary_skills) ? c.primary_skills.length : 0;
  const certs = Array.isArray(c.certificates) ? c.certificates.length : 0;
  const exp = c.yearofexp ?? 0;
  const gapMonths = c.gap_months ?? 0;
  const tier1 = TIER1.some((t) => (c.clg ?? "").toUpperCase().includes(t));

  return [
    {
      label: "Experience",
      value: experienceValue(c),
      note: c.fresher_or_lateral === "Fresher" ? "Fresher" : `${formatExperience(exp)} relevant`,
      positive: c.fresher_or_lateral !== "Fresher" && exp > 0,
    },
    {
      label: "Education",
      value: educationValue(c),
      note: c.highest_coursecompleted
        ? tier1
          ? `${c.highest_coursecompleted} · Tier-1`
          : c.highest_coursecompleted
        : "—",
      positive: Boolean(c.highest_coursecompleted),
    },
    {
      label: "Skills match",
      value: skillsValue(skills),
      note: `${Math.min(skills, ATS.skillsTarget)} / ${ATS.skillsTarget} skills`,
      positive: skills > 0,
    },
    {
      label: "Certifications",
      value: certificationsValue(certs),
      note: certs ? `${Math.min(certs, ATS.certsTarget)} / ${ATS.certsTarget} certs` : "None",
      positive: certs > 0,
    },
    {
      label: "Career gap",
      value: gapValue(gapMonths),
      note: gapMonths > 0 ? `${gapMonths}mo gap (impact)` : "No gaps",
      positive: gapMonths === 0,
    },
  ];
}
