import type { Variants } from "framer-motion";

// Subtle, fast enterprise motion. Durations <= 0.25s. Framer Motion automatically
// honors prefers-reduced-motion when MotionConfig reducedMotion="user" is set at the
// app root (see main.tsx), so these presets stay simple.

/** Card mount: fade + slight rise. */
export const fadeRise: Variants = {
  hidden: { opacity: 0, y: 8 },
  show: { opacity: 1, y: 0, transition: { duration: 0.22, ease: "easeOut" } },
};

/** Grid container: stagger children's fadeRise. */
export const stagger: Variants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.04 } },
};
