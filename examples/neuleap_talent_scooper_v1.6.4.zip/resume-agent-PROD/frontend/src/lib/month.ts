// ── Shared intake-month filter ───────────────────────────────────────────────
// Same GLOBAL-filter pattern as lib/year.ts and lib/source.ts: persisted in
// localStorage, synced live across pages/tabs. Independent of (AND-ed with,
// not nested inside) the year filter — e.g. "All years" + "January" shows
// every January across every year; "2026" + "January" narrows to just that month.
import { useEffect, useState } from "react";

export const ALL_MONTHS = "all" as const;
export type MonthFilter = number | typeof ALL_MONTHS; // 1-12 or "all"
export const MONTH_STORAGE_KEY = "dashboard.month";

export const MONTH_NAMES = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
] as const;

// Intake month (1-12) of a candidate, parsed from mail_send_date (fallback:
// created_at) — same source fields as yearOf, just the 2nd date component.
export function monthOf(c: {
  mail_send_date?: string | null;
  created_at?: string | null;
}): number | null {
  const m = String(c.mail_send_date || c.created_at || "").match(/^\d{4}-(\d{2})/);
  return m ? Number(m[1]) : null;
}

export function loadMonth(): MonthFilter {
  const saved = localStorage.getItem(MONTH_STORAGE_KEY);
  if (saved === ALL_MONTHS || saved === null) return ALL_MONTHS;
  const n = Number(saved);
  return Number.isInteger(n) && n >= 1 && n <= 12 ? n : ALL_MONTHS;
}

// A custom event so same-tab listeners update too (the native `storage` event
// only fires in OTHER tabs/windows) — same trick as lib/year.ts / lib/source.ts.
const MONTH_EVENT = "dashboard-month-change";

export function useGlobalMonth(): [MonthFilter, (m: MonthFilter) => void] {
  const [month, setMonthState] = useState<MonthFilter>(loadMonth);

  useEffect(() => {
    const sync = () => setMonthState(loadMonth());
    window.addEventListener("storage", sync);
    window.addEventListener(MONTH_EVENT, sync);
    return () => {
      window.removeEventListener("storage", sync);
      window.removeEventListener(MONTH_EVENT, sync);
    };
  }, []);

  const setMonth = (m: MonthFilter) => {
    localStorage.setItem(MONTH_STORAGE_KEY, String(m));
    setMonthState(m);
    window.dispatchEvent(new Event(MONTH_EVENT));
  };

  return [month, setMonth];
}
