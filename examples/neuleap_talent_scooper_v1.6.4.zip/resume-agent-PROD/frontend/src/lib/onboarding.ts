import type { OnboardingChecklistItem, OnboardingStage } from "@/types/candidate";

// Post-hire onboarding pipeline (Live Workflow) — mirrors app.stages.ONBOARDING_STAGE_ORDER.
// Tracked in PARALLEL to `status` ("Hired" never changes); only applies once a
// candidate is Hired. null/absent onboarding_stage is treated as the first stage.
export const ONBOARDING_STAGE_ORDER: OnboardingStage[] = [
  "ready_to_hire",
  "offer_review",
  "offer_sent",
  "candidate_responded",
  "expected_join_date",
  "joined",
  "onboarding_date_set",
  "allocation_checklist",
  "onboarding_complete",
];

export const ONBOARDING_STAGE_LABELS: Record<OnboardingStage, string> = {
  ready_to_hire: "Ready to Hire",
  offer_review: "Offer Review",
  offer_sent: "Offer Sent",
  candidate_responded: "Candidate Responded",
  expected_join_date: "Expected Join Date Set",
  joined: "Joined",
  onboarding_date_set: "Onboarding Date Set",
  allocation_checklist: "Allocation Checklist",
  onboarding_complete: "Onboarding Complete",
};

// Fixed standard allocation checklist — every Hired candidate gets this same set
// (mirrors app.stages.DEFAULT_ONBOARDING_CHECKLIST), used as the initial-state
// fallback until the candidate's own onboarding_checklist is populated server-side.
export const DEFAULT_ONBOARDING_CHECKLIST: OnboardingChecklistItem[] = [
  { key: "offer_letter_signed", label: "Offer letter signed", done: false },
  { key: "background_verification", label: "Background verification", done: false },
  { key: "it_asset_allocated", label: "IT asset allocated (laptop/ID/email)", done: false },
  { key: "buddy_assigned", label: "Buddy/mentor assigned", done: false },
  { key: "induction_scheduled", label: "Induction scheduled", done: false },
];

export function onboardingStageOf(stage: OnboardingStage | null | undefined): OnboardingStage {
  return stage ?? "ready_to_hire";
}

export function nextOnboardingStage(current: OnboardingStage | null | undefined): OnboardingStage | null {
  const i = ONBOARDING_STAGE_ORDER.indexOf(onboardingStageOf(current));
  return i < ONBOARDING_STAGE_ORDER.length - 1 ? ONBOARDING_STAGE_ORDER[i + 1] : null;
}

// Onboarding bubbles read as a post-hire "success" continuation of the flow —
// a cool blue → teal gradient distinct from the main pipeline's yellow/green/red/orange.
export const ONBOARDING_STAGE_COLOR: Record<OnboardingStage, string> = {
  ready_to_hire: "#2563eb",
  offer_review: "#1d6fd8",
  offer_sent: "#0891b2",
  candidate_responded: "#0e9488",
  expected_join_date: "#0d9467",
  joined: "#059669",
  onboarding_date_set: "#16a34a",
  allocation_checklist: "#4d9c1a",
  onboarding_complete: "#15803d",
};
