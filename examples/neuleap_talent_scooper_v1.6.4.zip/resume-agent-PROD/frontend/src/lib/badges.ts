// Single source of truth for status/stream/outcome badge colors.
// Color Consistency Lock: pages import from here, never inline color literals.
// The -400 text / /10 fill / /30 border pattern reads well on both light and dark.

const FALLBACK = "text-slate-400 bg-slate-400/10 border-slate-500/30";

export const STATUS_BADGE: Record<string, string> = {
  Active: "text-emerald-400 bg-emerald-400/10 border-emerald-500/30",
  "Pending Resume": "text-amber-400 bg-amber-400/10 border-amber-500/30",
  "Pending Extraction": "text-sky-400 bg-sky-400/10 border-sky-500/30",
  Hired: "text-blue-400 bg-blue-400/10 border-blue-500/30",
  Rejected: "text-red-400 bg-red-400/10 border-red-500/30",
  Closed: "text-slate-400 bg-slate-400/10 border-slate-500/30",
  Undecided: "text-yellow-400 bg-yellow-400/10 border-yellow-500/30",
};

export const STREAM_BADGE: Record<string, string> = {
  GenAI: "text-violet-400 bg-violet-400/10 border-violet-500/30",
  "Data Eng": "text-teal-400 bg-teal-400/10 border-teal-500/30",
  "Not Relevant": "text-slate-400 bg-slate-400/10 border-slate-500/30",
};

export const OUTCOME_BADGE: Record<string, string> = {
  Pass: "text-emerald-400 bg-emerald-400/10 border-emerald-500/30",
  Fail: "text-red-400 bg-red-400/10 border-red-500/30",
  Hold: "text-yellow-400 bg-yellow-400/10 border-yellow-500/30",
  Pending: "text-sky-400 bg-sky-400/10 border-sky-500/30",
};

export const statusBadge = (s?: string | null) => (s && STATUS_BADGE[s]) || FALLBACK;
export const streamBadge = (s?: string | null) => (s && STREAM_BADGE[s]) || "text-blue-400 bg-blue-400/10 border-blue-500/30";
export const outcomeBadge = (o?: string | null) => (o && OUTCOME_BADGE[o]) || FALLBACK;
// The round outcome "Fail" is stored as-is but shown to recruiters as "Rejected".
export const outcomeLabel = (o?: string | null) => (o === "Fail" ? "Rejected" : o ?? "");
