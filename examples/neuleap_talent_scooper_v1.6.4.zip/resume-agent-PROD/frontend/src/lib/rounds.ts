import type { CandidateMaster, CandidateStatus } from "@/types/candidate";
import { parseCertificates } from "@/types/candidate";

// The candidate's effective lifecycle status for display. A round marked Fail flips
// round_status to 'Rejected' (the DB trigger sync_candidate_current_round), but leaves
// candidate_master.status as 'Active' — so a candidate rejected at any round would
// otherwise still read "Active". Surface that rejection as the status. Hired is written
// straight to status by the repository, so it needs no override here.
export function effectiveStatus(c: CandidateMaster): CandidateStatus {
  if (c.status === "Active" && c.round_status === "Rejected") return "Rejected";
  return c.status;
}

// The recruiter-facing round breakdown shown on the Dashboard and used as the
// Screening ?bucket filter. Not-yet-in-a-round candidates fold into "New"; the
// "Screening" call is its own bucket; the optional "Round 3" folds into "Round 2".
// Terminal states map to Hired / Reject. "Undecided" is a paused/parked state (set
// via the "Undecided for now" NBA) — not a pipeline stage, but a recruiter can pull
// a candidate back out of it into any other stage later.
export const ROUND_BUCKETS = [
  "New",
  "Screening",
  "Round 1",
  "Round 2",
  "Final",
  "Hired",
  "Reject",
  "Undecided",
] as const;

// The buckets offered as filter options on the Screening list — same pipeline as
// the Dashboard.
export const ROUND_FILTER_BUCKETS = [...ROUND_BUCKETS] as const;

export type RoundBucket = (typeof ROUND_FILTER_BUCKETS)[number];

// Display label for a round/stage name. The "Screening" stage is shown to users
// as "Interview slots shared" and the "Reject" bucket as "Rejected" everywhere
// (display only — the stored values, DB triggers, and pipeline vocabulary all
// stay "Screening"/"Reject"). Every UI site that renders a round name routes
// through here so the relabel never drifts out of sync.
export function roundLabel(name: string | null | undefined): string {
  const n = (name ?? "").trim();
  if (n === "Screening") return "Interview slots shared";
  if (n === "Reject") return "Rejected";
  return name ?? "";
}

// Bar/tile color per bucket (hsl/hex), in canonical pipeline order.
export const BUCKET_COLOR: Record<RoundBucket, string> = {
  New: "#0284c7",
  Screening: "#10b981",
  "Round 1": "#665efd",
  "Round 2": "#533afd",
  Final: "#d97706",
  Hired: "#2563eb",
  Reject: "#e11d48",
  Undecided: "#ca8a04",
};

// Map a candidate onto exactly one ROUND bucket by their interview STAGE — never a
// lifecycle status. An Active candidate is bucketed by the round they're actually at
// (New / Screening / … / Hired / Reject). Returns null only when they're outside the
// round pipeline (Closed / Pending*).
export function roundStageBucket(c: CandidateMaster): RoundBucket | null {
  if (c.status === "Hired") return "Hired";
  if (c.status === "Rejected") return "Reject";
  if (c.status === "Undecided") return "Undecided";
  if (c.status === "Closed") return null;
  if (c.status === "Pending Extraction" || c.status === "Pending Resume") return null;
  // Active candidates bucket by round stage. A round marked Fail rejects the
  // candidate even when their lifecycle status is still "Active" (the DB trigger
  // flips round_status to 'Rejected', not status) — so a rejected-at-Screening
  // candidate lands in Reject.
  if (c.round_status === "Rejected") return "Reject";
  const r = (c.roundname ?? "").trim();
  if (r === "Screening") return "Screening";
  if (r === "Round 1") return "Round 1";
  if (r === "Round 2" || r === "Round 3") return "Round 2";
  if (r === "Final") return "Final";
  return "New"; // no round / "New"
}

// Dashboard breakdown bucket — the candidate's round stage.
export function bucketOf(c: CandidateMaster): RoundBucket | null {
  return roundStageBucket(c);
}

// Buckets that still age (a candidate sitting in this state can stall). Terminal
// Hired/Reject never age.
export function bucketAges(b: RoundBucket | null): boolean {
  return b === "New" || b === "Screening" || b === "Round 1" || b === "Round 2" || b === "Final";
}

// Whole days since `s` (clamped at 0); null when the date is absent/invalid.
export function daysSince(s: string | null | undefined): number | null {
  if (!s) return null;
  const d = new Date(s);
  if (isNaN(d.getTime())) return null;
  return Math.max(0, Math.floor((Date.now() - d.getTime()) / 86_400_000));
}

// Days a candidate has aged in their current state. In-round candidates use the
// round-aging map (today − round start) keyed by candidate_id; "New" candidates
// age from when the pipeline last processed them.
export function agingDaysFor(
  c: CandidateMaster,
  agingByCandidate: Map<string, number>
): number | null {
  if (agingByCandidate.has(c.candidate_id)) return agingByCandidate.get(c.candidate_id)!;
  return daysSince(c.pipeline_processed_at ?? c.parsed_at ?? c.created_at ?? c.mail_send_date);
}

// True when the candidate has at least one certificate whose name or issuer
// contains `term` (case-insensitive). Powers the Screening cert tag/keyword filter.
export function certMatches(c: CandidateMaster, term: string): boolean {
  const t = term.trim().toLowerCase();
  if (!t) return true;
  return parseCertificates(c.certificates).some(
    (cert) =>
      cert.name.toLowerCase().includes(t) || (cert.issuer ?? "").toLowerCase().includes(t)
  );
}
