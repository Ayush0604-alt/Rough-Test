// Hardcoded interview workflow — mirrors app/services/interview_plan.py.
//   Screening → Round 1 → Round 2 → [Round 3] → Final → Hired
// Interviewers are NOT pinned in code — every round's interviewer is entered
// manually per candidate, so no names appear anywhere in the app.

export const FLOW = ["Screening", "Round 1", "Round 2", "Round 3", "Final"] as const;

export function round1Options(_domain?: string | null): string[] {
  // No preset Round 1 interviewers — the recruiter types the name manually.
  return [];
}

// No interviewer is auto-assigned to any stage; all are entered manually.
export function fixedInterviewer(_stage: string): string | null {
  return null;
}

// CTC / Expected CTC / Notice apply to laterals only — freshers (and candidates
// whose type wasn't extracted) NEVER see these fields, on any form. Single source
// of truth so the rule can't drift across screens.
export function showCtc(fresherOrLateral?: string | null): boolean {
  return (fresherOrLateral ?? "").trim().toLowerCase() === "lateral";
}

// Next round in the candidate's plan, or null after Final. Skips Round 3 unless included.
export function nextPlannedStage(current: string | null | undefined, includeRound3: boolean): string | null {
  const name = (current ?? "New").trim();
  if (name === "New") return "Screening";
  const i = (FLOW as readonly string[]).indexOf(name);
  if (i < 0) return null;
  let nxt: string | null = i + 1 < FLOW.length ? FLOW[i + 1] : null;
  if (nxt === "Round 3" && !includeRound3) nxt = "Final";
  return nxt;
}

// Stages a Pass on `current` may advance to: the planned next, plus the Round 2 → Final
// skip of the optional Round 3 when it's included. Final → ["Hired"].
export function allowedAdvance(current: string | null | undefined, includeRound3: boolean): string[] {
  const name = (current ?? "New").trim();
  if (name === "Final") return ["Hired"];
  if (name === "Round 2" && includeRound3) return ["Round 3", "Final"];
  const nxt = nextPlannedStage(name, includeRound3);
  return nxt ? [nxt] : [];
}
