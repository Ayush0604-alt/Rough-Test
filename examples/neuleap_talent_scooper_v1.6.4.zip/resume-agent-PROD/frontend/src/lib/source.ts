// ── Shared intake-source filter ──────────────────────────────────────────────
// The recruiter-typed "source" (e.g. "LinkedIn", "Naukri", "Referral - Jane")
// attached to a candidate at upload time (see UploadResumeModal). Mirrors
// lib/year.ts's pattern: a GLOBAL filter selected on the Dashboard, persisted
// in localStorage, synced live across pages/tabs via storage events. Unlike
// year, the option list isn't a fixed range — it's whatever distinct source
// values are actually present on the current candidate list, computed by the
// caller (Dashboard) rather than here.
import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { api } from "@/services/api";

export const ALL_SOURCES = "all" as const;
export type SourceFilter = string | typeof ALL_SOURCES;
export const SOURCE_STORAGE_KEY = "dashboard.source";

// A candidate's source, trimmed; "" / null / undefined all read as "no source"
// (candidates created before this feature existed, or via a path that doesn't
// carry one through — e.g. Graph mail intake, which has no upload-time prompt).
export function sourceOf(c: { source?: string | null }): string | null {
  const s = (c.source ?? "").trim();
  return s || null;
}

export function loadSource(): SourceFilter {
  return (localStorage.getItem(SOURCE_STORAGE_KEY) as SourceFilter | null) ?? ALL_SOURCES;
}

// A custom event so same-tab listeners update too (the native `storage` event
// only fires in OTHER tabs/windows) — same trick as lib/year.ts.
const SOURCE_EVENT = "dashboard-source-change";

export function useGlobalSource(): [SourceFilter, (s: SourceFilter) => void] {
  const [source, setSourceState] = useState<SourceFilter>(loadSource);

  useEffect(() => {
    const sync = () => setSourceState(loadSource());
    window.addEventListener("storage", sync);
    window.addEventListener(SOURCE_EVENT, sync);
    return () => {
      window.removeEventListener("storage", sync);
      window.removeEventListener(SOURCE_EVENT, sync);
    };
  }, []);

  const setSource = (s: SourceFilter) => {
    localStorage.setItem(SOURCE_STORAGE_KEY, s);
    setSourceState(s);
    window.dispatchEvent(new Event(SOURCE_EVENT));
  };

  return [source, setSource];
}

// The "Sample Data" source (the SAMPLE-DEMO fixture candidate) is QA/demo
// tooling, not a real campaign — hidden from source-tag pickers in
// production always, and even in QA when Settings → toggled off. Callers
// deriving a distinct-sources list (Dashboard, Screening, Interviewer
// Timeslot Pools) filter it out using this.
export function useSampleDataFilter(): { label: string; visible: boolean } {
  const { data } = useQuery({
    queryKey: ["app-meta"],
    queryFn: async () =>
      (
        await api.get<{ sample_data_source_label: string; sample_data_visible: boolean }>("/meta")
      ).data,
    staleTime: 60_000,
    retry: false,
  });
  return {
    label: data?.sample_data_source_label ?? "Sample Data",
    visible: data?.sample_data_visible ?? true,
  };
}
