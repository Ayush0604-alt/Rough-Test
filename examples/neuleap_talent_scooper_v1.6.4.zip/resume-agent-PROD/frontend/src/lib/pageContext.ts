// The floating chatbot is mounted once, globally, and never unmounts as the
// recruiter navigates the app — so "what page is the user on" has to be
// derived fresh from the CURRENT route on every question asked, not
// captured once when the panel first opened. Callers should call this at
// submit time (reading the live `location`), not memoize the result.
export function derivePageContext(pathname: string, search: string): string {
  const params = new URLSearchParams(search);

  if (pathname === "/dashboard" || pathname === "/") {
    return "Dashboard — pipeline overview (stage counts, new-candidate shortlist)";
  }
  if (pathname === "/intake") return "Mailbox — resume intake mail processing";
  if (pathname === "/resumes") return "Resume Library";
  if (pathname === "/process-flow") return "Process Flow page";
  if (pathname === "/settings") return "Settings page";
  if (pathname === "/audit-logs") return "Activity Log (audit trail) page";

  const candidateProfile = pathname.match(/^\/candidates\/([^/]+)$/);
  if (candidateProfile) return `Candidate profile page for candidate ${candidateProfile[1]}`;

  const roundsCandidate = pathname.match(/^\/rounds\/([^/]+)$/);
  if (roundsCandidate) {
    return `Interview-round management page for candidate ${roundsCandidate[1]}`;
  }

  if (pathname === "/rounds") {
    const filters: string[] = [];
    if (params.get("bucket")) filters.push(`stage=${params.get("bucket")}`);
    if (params.get("q")) filters.push(`search="${params.get("q")}"`);
    if (params.get("aging")) filters.push(`aging=${params.get("aging")}`);
    if (params.get("tier")) filters.push(`tier=${params.get("tier")}`);
    return `Candidates list page${filters.length ? ` (filtered: ${filters.join(", ")})` : " (unfiltered)"}`;
  }

  return `App page: ${pathname}`;
}
