import type { CandidateAuditEntry } from "@/services/candidates";

// Yellow (New) → green (Hired) across the live pipeline stages; red flags a
// rejection; gray covers an admin close and any row without a stage attributed
// (pre-L4 pipeline rows written before the audit_log.stage column existed).
// Shared by ActionsAuditLog and StageTransitionNotes so both read one palette.
export const STAGE_COLOR: Record<string, string> = {
  New: "#eab308",
  Screening: "#a3e635",
  "Round 1": "#84cc16",
  "Round 2": "#65a30d",
  Final: "#16a34a",
  Hired: "#15803d",
  Reject: "#dc2626",
  Closed: "#6b7280",
};

// Steps that represent an actual STAGE TRANSITION (not just a metadata tweak).
export const TRANSITION_STEPS = new Set(["status_change", "round_updated", "round_created"]);

// The repo's _round_update_summary embeds the recruiter's notes as `feedback="…"`
// at the end of the line — split that back out so it can render as a highlighted,
// outlined callout instead of running on with the rest of the summary.
export function splitComment(text: string): { meta: string; comment: string | null } {
  const m = text.match(/feedback="([^"]*)"\s*$/);
  if (!m || m.index == null) return { meta: text, comment: null };
  return { meta: text.slice(0, m.index).replace(/\s*·\s*$/, "").trim(), comment: m[1] || null };
}

function stepLabel(step: string): string {
  return step.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}

// Most pipeline (L1-L3) Success rows carry no free-text detail — fall back to a
// plain "Step — Status" line so the entry is never blank.
export function entryText(e: CandidateAuditEntry): string {
  if (e.fail_reason && e.fail_reason.trim()) return e.fail_reason;
  return `${stepLabel(e.step)} — ${e.status}`;
}

export function fmtWhen(iso: string): string {
  return new Date(iso).toLocaleString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

// Whole days between two ISO timestamps (never negative) — used to show how
// long a candidate sat in one stage before their next transition (or "so far"
// for the current/most recent stage, where `endIso` is just-now).
export function daysBetween(startIso: string, endIso: string): number {
  const start = new Date(startIso).getTime();
  const end = new Date(endIso).getTime();
  return Math.max(0, Math.floor((end - start) / 86_400_000));
}
