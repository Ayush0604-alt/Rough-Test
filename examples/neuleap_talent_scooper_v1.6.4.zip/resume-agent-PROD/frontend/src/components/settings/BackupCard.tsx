import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  DatabaseBackup,
  Loader2,
  Save,
  RotateCcw,
  HardDrive,
  Database,
  Cloud,
  ShieldCheck,
  ShieldAlert,
  Play,
  History,
  CheckCircle2,
  XCircle,
} from "lucide-react";
import { backupService, fmtBytes, type BackupConfig, type BackupManifest } from "@/services/backup";
import { useAuth } from "@/context/AuthContext";
import { cn, apiErrorMessage } from "@/lib/utils";
import CollapsibleSection from "@/components/settings/CollapsibleSection";
import HowItWorks from "@/components/settings/HowItWorks";
import { useConfirm } from "@/components/common/ConfirmProvider";

const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

function StatusDot({ ok }: { ok: boolean }) {
  return ok ? (
    <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
  ) : (
    <XCircle className="h-3.5 w-3.5 text-rose-500" />
  );
}

function fmtDate(iso?: string | null) {
  if (!iso) return "never";
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? iso : d.toLocaleString();
}

export default function BackupCard() {
  return (
    <CollapsibleSection
      id="backup-dr"
      icon={DatabaseBackup}
      title="Backup & Disaster Recovery"
      desc="System health, scheduled backups (incremental + weekly full) to ≥2 locations, and restore — System Admin"
      colSpan="lg:col-span-2"
    >
      <BackupBody />
    </CollapsibleSection>
  );
}

function BackupBody() {
  const { user } = useAuth();
  const isSysadmin = user?.role === "sysadmin";
  const queryClient = useQueryClient();
  const confirm = useConfirm();

  const { data: health } = useQuery({
    queryKey: ["backup-health"],
    queryFn: async () => (await backupService.health()).data,
    refetchInterval: 30_000,
  });
  const { data: serverCfg } = useQuery({
    queryKey: ["backup-config"],
    queryFn: async () => (await backupService.getConfig()).data,
  });
  const { data: listData } = useQuery({
    queryKey: ["backup-list"],
    queryFn: async () => (await backupService.list()).data.backups,
  });

  const [cfg, setCfg] = useState<BackupConfig | null>(null);
  const [busy, setBusy] = useState<null | "save" | "revert" | "full" | "incremental" | "restore">(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    if (serverCfg) setCfg(serverCfg);
  }, [serverCfg]);

  const flash = (m: string) => {
    setNotice(m);
    setTimeout(() => setNotice(null), 4000);
  };
  const refresh = () => {
    queryClient.invalidateQueries({ queryKey: ["backup-health"] });
    queryClient.invalidateQueries({ queryKey: ["backup-list"] });
  };

  const save = async () => {
    if (!cfg) return;
    setBusy("save");
    setError(null);
    try {
      const { data } = await backupService.saveConfig(cfg);
      setCfg(data);
      queryClient.setQueryData(["backup-config"], data);
      flash("Backup schedule saved.");
    } catch (e) {
      setError(apiErrorMessage(e, "Couldn't save the backup config."));
    } finally {
      setBusy(null);
    }
  };

  const runBackup = async (kind: "full" | "incremental") => {
    setBusy(kind);
    setError(null);
    try {
      const { data } = await backupService.run(kind);
      if (data.status === "ok") flash(`${kind === "full" ? "Full" : "Incremental"} backup complete (${data.id}).`);
      else setError(`Backup failed: ${data.error ?? "unknown error"}`);
      refresh();
    } catch (e) {
      setError(apiErrorMessage(e, "Couldn't run the backup."));
    } finally {
      setBusy(null);
    }
  };

  const restore = async (b: BackupManifest) => {
    if (
      !(await confirm({
        title: `Restore from ${b.id}?`,
        message: `This REPLACES the current database${b.kind === "full" ? ", files, and configuration" : ""} with the backup's contents. Anything created since this backup will be lost.`,
        confirmLabel: "Restore",
        danger: true,
      }))
    )
      return;
    setBusy("restore");
    setError(null);
    try {
      const { data } = await backupService.restore(b.id);
      // An older backup is reconciled to the current schema on restore; if any
      // required column is still missing, warn instead of a plain success.
      const missing = data.integrity && data.integrity.ok === false ? data.integrity.missing ?? [] : [];
      if (missing.length > 0) {
        setError(
          `Restored from ${b.id}, but the schema is still behind the code (${missing.join(", ")}). ` +
            `Restart the app container to finish the migration.`
        );
      } else {
        flash(`Restored from ${b.id} — data${b.kind === "full" ? ", files, config" : ""} + schema reconciled to the current version.`);
      }
      refresh();
    } catch (e) {
      setError(apiErrorMessage(e, "Restore failed."));
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="space-y-4">
      <HowItWorks variant="dr" />

      {/* ── System health ── */}
      {health && (
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          <HealthTile icon={Database} label="Database" ok={health.database.ok} sub={health.database.version ?? health.database.error} />
          <HealthTile icon={HardDrive} label="Object store" ok={health.storage.ok}
            sub={health.storage.ok ? `${(health.storage.raw_objects ?? 0) + (health.storage.resume_objects ?? 0)} files` : health.storage.error} />
          <HealthTile icon={HardDrive} label="Disk free" ok={health.disk.ok} sub={fmtBytes(health.disk.free_bytes)} />
          <HealthTile icon={DatabaseBackup} label="Full sets" ok={health.backups.full_sets >= 2}
            sub={`${health.backups.full_sets} kept · ${health.backups.incrementals} incr`} />
        </div>
      )}
      {health && (
        <div className="flex flex-wrap gap-x-4 gap-y-1 text-[11px] text-muted-foreground">
          <span>Last full: <b className="text-foreground">{fmtDate(health.backups.last_full?.created_at)}</b></span>
          <span>Last incremental: <b className="text-foreground">{fmtDate(health.backups.last_incremental?.created_at)}</b></span>
          <span className="inline-flex items-center gap-1">Secondary <StatusDot ok={health.backups.secondary_configured} /></span>
          <span className="inline-flex items-center gap-1">Cloud <StatusDot ok={health.backups.cloud_configured} /></span>
        </div>
      )}

      {!isSysadmin && (
        <p className="rounded-lg border border-border/60 bg-secondary/20 px-3 py-2 text-[11px] text-muted-foreground">
          You can view backup status here. Editing the schedule, running a backup, or restoring is
          restricted to <b>System Admin</b>.
        </p>
      )}

      {/* ── Config + actions (System Admin) ── */}
      {isSysadmin && cfg && (
        <>
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => runBackup("full")}
              disabled={busy !== null}
              className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3 py-1.5 text-xs font-semibold text-white hover:bg-primary/90 disabled:opacity-40"
            >
              {busy === "full" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Play className="h-3.5 w-3.5" />}
              Backup now (full)
            </button>
            <button
              type="button"
              onClick={() => runBackup("incremental")}
              disabled={busy !== null}
              className="inline-flex items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-foreground hover:bg-secondary disabled:opacity-40"
            >
              {busy === "incremental" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <History className="h-3.5 w-3.5" />}
              Incremental now
            </button>
          </div>

          <div className="space-y-3 rounded-lg border border-border/60 bg-secondary/20 p-3">
            <label className="flex items-center gap-2 text-xs font-medium text-foreground">
              <input
                type="checkbox"
                checked={cfg.enabled}
                onChange={(e) => setCfg({ ...cfg, enabled: e.target.checked })}
                className="h-3.5 w-3.5 rounded border-border accent-primary"
              />
              Enable scheduled backups
            </label>

            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              <NumberField label="Incremental every (hours)" value={cfg.incremental_interval_hours} min={1} max={168}
                onChange={(v) => setCfg({ ...cfg, incremental_interval_hours: v })} />
              <div className="flex items-center justify-between gap-2 rounded-md border border-border bg-background px-2 py-1">
                <span className="text-[11px] text-muted-foreground">Weekly full on</span>
                <div className="flex items-center gap-1">
                  <select
                    value={cfg.full_weekly_day}
                    onChange={(e) => setCfg({ ...cfg, full_weekly_day: Number(e.target.value) })}
                    className="rounded border border-border bg-background px-1 py-0.5 text-[11px]"
                  >
                    {DAYS.map((d, i) => <option key={d} value={i}>{d}</option>)}
                  </select>
                  <span className="text-[11px] text-muted-foreground">@</span>
                  <input type="number" min={0} max={23} value={cfg.full_weekly_hour}
                    onChange={(e) => setCfg({ ...cfg, full_weekly_hour: Math.max(0, Math.min(23, Number(e.target.value))) })}
                    className="w-12 rounded border border-border bg-background px-1 py-0.5 text-right text-[11px]" />
                  <span className="text-[11px] text-muted-foreground">:00</span>
                </div>
              </div>
              <NumberField label="Keep full sets (min 2)" value={cfg.retention_full_sets} min={2} max={30}
                onChange={(v) => setCfg({ ...cfg, retention_full_sets: v })} />
              <NumberField label="Keep incrementals" value={cfg.retention_incrementals} min={1} max={200}
                onChange={(v) => setCfg({ ...cfg, retention_incrementals: v })} />
            </div>

            {/* Failure email notification */}
            <div className="space-y-1.5 rounded-md border border-border/60 bg-background/60 p-2.5">
              <label className="flex items-center gap-2 text-[11px] font-semibold text-foreground">
                <input type="checkbox" checked={cfg.notify_on_failure}
                  onChange={(e) => setCfg({ ...cfg, notify_on_failure: e.target.checked })}
                  className="h-3.5 w-3.5 rounded border-border accent-primary" />
                Email me if a backup fails
              </label>
              {cfg.notify_on_failure && (
                <TextField label="Notify emails (comma-separated — blank uses the Notifications recipient)"
                  placeholder="ops@neuleap.ai, admin@neuleap.ai"
                  value={cfg.notify_emails} onChange={(v) => setCfg({ ...cfg, notify_emails: v })} />
              )}
            </div>

            <TextField label="Secondary path (mounted disk / NAS — container path)" placeholder="/app/backups-secondary"
              value={cfg.secondary_dir} onChange={(v) => setCfg({ ...cfg, secondary_dir: v })} />

            {/* Cloud (S3-compatible) */}
            <div className="space-y-2 rounded-md border border-border/60 bg-background/60 p-2.5">
              <label className="flex items-center gap-2 text-[11px] font-semibold text-foreground">
                <Cloud className="h-3.5 w-3.5 text-sky-600" />
                <input type="checkbox" checked={cfg.cloud.enabled}
                  onChange={(e) => setCfg({ ...cfg, cloud: { ...cfg.cloud, enabled: e.target.checked } })}
                  className="h-3.5 w-3.5 rounded border-border accent-primary" />
                Off-site cloud copy (S3-compatible)
              </label>
              {cfg.cloud.enabled && (
                <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">
                  <TextField label="Bucket" value={cfg.cloud.bucket} onChange={(v) => setCfg({ ...cfg, cloud: { ...cfg.cloud, bucket: v } })} />
                  <TextField label="Prefix" value={cfg.cloud.prefix} onChange={(v) => setCfg({ ...cfg, cloud: { ...cfg.cloud, prefix: v } })} />
                  <TextField label="Endpoint (blank = AWS S3)" value={cfg.cloud.endpoint} onChange={(v) => setCfg({ ...cfg, cloud: { ...cfg.cloud, endpoint: v } })} />
                  <TextField label="Region" value={cfg.cloud.region} onChange={(v) => setCfg({ ...cfg, cloud: { ...cfg.cloud, region: v } })} />
                  <TextField label="Access key" value={cfg.cloud.access_key} onChange={(v) => setCfg({ ...cfg, cloud: { ...cfg.cloud, access_key: v } })} />
                  <TextField label={cfg.cloud.has_secret ? "Secret key (leave blank to keep)" : "Secret key"} value={cfg.cloud.secret_key}
                    type="password" onChange={(v) => setCfg({ ...cfg, cloud: { ...cfg.cloud, secret_key: v } })} />
                </div>
              )}
            </div>

            <div className="flex items-center justify-end gap-2">
              <button type="button"
                onClick={async () => { if (await confirm({ title: "Reset backup config to defaults?", message: "Your schedule, retention, secondary path, and cloud settings will be restored to the shipped defaults.", confirmLabel: "Reset", danger: true })) { setBusy("revert"); try { const { data } = await backupService.revertConfig(); setCfg(data); queryClient.setQueryData(["backup-config"], data); flash("Reset to defaults."); } finally { setBusy(null); } } }}
                disabled={busy !== null}
                className="inline-flex items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-foreground hover:bg-secondary disabled:opacity-40">
                {busy === "revert" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RotateCcw className="h-3.5 w-3.5" />} Reset
              </button>
              <button type="button" onClick={save} disabled={busy !== null}
                className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-primary/90 disabled:opacity-40">
                {busy === "save" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />} Save schedule
              </button>
            </div>
          </div>
        </>
      )}

      {error && <p className="text-[11px] font-medium text-rose-500">{error}</p>}
      {notice && <p className="text-[11px] font-medium text-emerald-600">{notice}</p>}

      {/* ── Available backups ── */}
      {listData && listData.length > 0 && (
        <div>
          <div className="mb-1.5 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Available backups</div>
          <div className="max-h-64 space-y-1.5 overflow-auto">
            {listData.map((b) => (
              <div key={b.id} className="flex items-center gap-2 rounded-lg border border-border/60 bg-secondary/10 px-2.5 py-1.5 text-[11px]">
                <span className={cn("rounded-full border px-1.5 py-0.5 text-[9px] font-semibold",
                  b.kind === "full" ? "border-primary/30 bg-primary/10 text-primary" : "border-border text-muted-foreground")}>
                  {b.kind}
                </span>
                <span className="font-mono text-foreground">{b.id}</span>
                <span className="text-muted-foreground">{fmtBytes(b.total_bytes)}</span>
                {b.targets?.secondary?.status === "ok" && <span title="Copied to secondary" className="text-emerald-600">2nd✓</span>}
                {b.targets?.cloud?.status === "ok" && <span title="Uploaded to cloud" className="text-sky-600">cloud✓</span>}
                <span className="ml-auto text-muted-foreground">{fmtDate(b.created_at)}</span>
                {isSysadmin && (
                  <button type="button" onClick={() => restore(b)} disabled={busy !== null}
                    title="Restore from this backup (destructive)"
                    className="rounded border border-border px-1.5 py-0.5 font-semibold text-foreground hover:bg-rose-500/10 hover:text-rose-500 disabled:opacity-40">
                    Restore
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function HealthTile({ icon: Icon, label, ok, sub }: { icon: React.ElementType; label: string; ok: boolean; sub?: string }) {
  return (
    <div className={cn("rounded-lg border p-2.5", ok ? "border-emerald-500/20 bg-emerald-500/5" : "border-rose-500/30 bg-rose-500/5")}>
      <div className="flex items-center gap-1.5">
        <Icon className="h-3.5 w-3.5 text-muted-foreground" />
        <span className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">{label}</span>
        {ok ? <ShieldCheck className="ml-auto h-3.5 w-3.5 text-emerald-600" /> : <ShieldAlert className="ml-auto h-3.5 w-3.5 text-rose-500" />}
      </div>
      <div className="mt-1 truncate text-xs font-semibold text-foreground" title={sub}>{sub ?? "—"}</div>
    </div>
  );
}

function NumberField({ label, value, min, max, onChange }: { label: string; value: number; min?: number; max?: number; onChange: (v: number) => void }) {
  return (
    <div className="flex items-center justify-between gap-2 rounded-md border border-border bg-background px-2 py-1">
      <span className="text-[11px] text-muted-foreground">{label}</span>
      <input type="number" min={min} max={max} value={value}
        onChange={(e) => onChange(Math.max(min ?? 0, Math.min(max ?? 9999, Number(e.target.value))))}
        className="w-16 rounded border border-border bg-background px-1 py-0.5 text-right text-[11px]" />
    </div>
  );
}

function TextField({ label, value, onChange, placeholder, type }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string; type?: string }) {
  return (
    <label className="block">
      <span className="text-[10px] font-medium text-muted-foreground">{label}</span>
      <input type={type ?? "text"} value={value} placeholder={placeholder} onChange={(e) => onChange(e.target.value)}
        className="mt-0.5 w-full rounded-md border border-border bg-background px-2 py-1 text-[11px] text-foreground outline-none focus:border-primary/50" />
    </label>
  );
}
