// Settings → Feedback (Admin / System Admin). Lists every in-app bug report +
// feature request, lets you triage the status, export to Excel, and delete.
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Download, Loader2, MessageSquareText, Trash2 } from "lucide-react";
import { feedbackService, type FeedbackStatus } from "@/services/feedback";
import { useConfirm } from "@/components/common/ConfirmProvider";
import CollapsibleSection from "./CollapsibleSection";
import { cn } from "@/lib/utils";

const QUERY_KEY = ["feedback-reports"];

const STATUS_LABEL: Record<FeedbackStatus, string> = {
  open: "Open",
  in_progress: "In progress",
  resolved: "Resolved",
  closed: "Closed",
};
const STATUSES: FeedbackStatus[] = ["open", "in_progress", "resolved", "closed"];

const MOSCOW_LABEL: Record<string, string> = {
  must: "Must",
  should: "Should",
  could: "Could",
  wont: "Won't",
};

const PRIORITY_TONE: Record<string, string> = {
  P1: "border-red-500/40 bg-red-500/10 text-red-600 dark:text-red-400",
  P2: "border-orange-500/40 bg-orange-500/10 text-orange-600 dark:text-orange-400",
  P3: "border-amber-500/40 bg-amber-500/10 text-amber-600 dark:text-amber-400",
  P4: "border-sky-500/40 bg-sky-500/10 text-sky-600 dark:text-sky-400",
  P5: "border-border bg-secondary text-muted-foreground",
};

function fmtDate(s: string | null): string {
  if (!s) return "—";
  const d = new Date(s);
  return Number.isNaN(d.getTime()) ? "—" : d.toLocaleString(undefined, { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
}

export default function FeedbackReportsCard() {
  const queryClient = useQueryClient();
  const confirm = useConfirm();
  const [exporting, setExporting] = useState(false);
  const { data: reports = [], isLoading } = useQuery({
    queryKey: QUERY_KEY,
    queryFn: async () => (await feedbackService.list()).data,
  });

  const setStatus = useMutation({
    mutationFn: ({ id, status }: { id: number; status: FeedbackStatus }) =>
      feedbackService.updateStatus(id, status),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: QUERY_KEY }),
  });
  const remove = useMutation({
    mutationFn: (id: number) => feedbackService.remove(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: QUERY_KEY }),
  });

  const exportXlsx = async () => {
    setExporting(true);
    try {
      await feedbackService.downloadXlsx();
    } finally {
      setExporting(false);
    }
  };

  const openCount = reports.filter((r) => r.status === "open" || r.status === "in_progress").length;

  return (
    <CollapsibleSection
      id="feedback"
      icon={MessageSquareText}
      title="Feedback — bug reports & feature requests"
      desc="Everything users have reported in-app; triage, export, or clear"
      colSpan="lg:col-span-2"
    >
      <div className="mb-3 flex items-center justify-between gap-2">
        <span className="text-[11px] text-muted-foreground">
          {reports.length} total · {openCount} open
        </span>
        <button
          onClick={exportXlsx}
          disabled={exporting || reports.length === 0}
          className="inline-flex items-center gap-1.5 rounded-lg border border-border px-2.5 py-1.5 text-xs font-medium text-foreground transition-colors hover:border-primary/40 hover:text-primary disabled:opacity-50"
        >
          {exporting ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Download className="h-3.5 w-3.5" />}
          Export Excel
        </button>
      </div>

      {isLoading ? (
        <div className="flex items-center gap-2 py-6 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading…
        </div>
      ) : reports.length === 0 ? (
        <p className="py-6 text-center text-xs text-muted-foreground">No reports yet.</p>
      ) : (
        <div className="max-h-[52vh] space-y-2 overflow-y-auto pr-1">
          {reports.map((r) => (
            <div
              key={r.id}
              className={cn(
                "rounded-lg border p-3",
                r.status === "resolved" || r.status === "closed"
                  ? "border-border/50 bg-secondary/20 opacity-70"
                  : "border-border/70"
              )}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span
                      className={cn(
                        "rounded-full border px-1.5 py-0.5 text-[9px] font-semibold",
                        PRIORITY_TONE[r.priority] ?? PRIORITY_TONE.P5
                      )}
                    >
                      {r.priority}
                    </span>
                    <span className="rounded-full border border-border bg-secondary px-1.5 py-0.5 text-[9px] font-semibold uppercase text-muted-foreground">
                      {r.kind === "bug" ? "Bug" : "Feature"}
                    </span>
                    {r.moscow && MOSCOW_LABEL[r.moscow] && (
                      <span className="rounded-full border border-violet-500/40 bg-violet-500/10 px-1.5 py-0.5 text-[9px] font-semibold text-violet-600 dark:text-violet-400">
                        {MOSCOW_LABEL[r.moscow]}
                      </span>
                    )}
                    <span className="text-sm font-medium text-foreground">{r.title}</span>
                  </div>
                  {r.description && (
                    <p className="mt-1 whitespace-pre-wrap text-xs text-muted-foreground">{r.description}</p>
                  )}
                  <p className="mt-1.5 text-[10px] text-muted-foreground">
                    {r.reporter_name || r.reporter_email} ({r.reporter_email}
                    {r.reporter_role ? ` · ${r.reporter_role}` : ""}) · {fmtDate(r.created_at)}
                  </p>
                </div>
                <div className="flex shrink-0 items-center gap-1.5">
                  <select
                    value={r.status}
                    onChange={(e) => setStatus.mutate({ id: r.id, status: e.target.value as FeedbackStatus })}
                    className="rounded-lg border border-border bg-secondary px-1.5 py-1 text-[10px] text-foreground focus:outline-none focus:border-primary/50"
                  >
                    {STATUSES.map((s) => (
                      <option key={s} value={s}>{STATUS_LABEL[s]}</option>
                    ))}
                  </select>
                  <button
                    onClick={async () => {
                      if (
                        await confirm({
                          title: "Delete this report?",
                          message: `Permanently delete "${r.title}"? This can't be undone.`,
                          confirmLabel: "Delete",
                          danger: true,
                        })
                      ) {
                        remove.mutate(r.id);
                      }
                    }}
                    title="Delete"
                    className="rounded-lg p-1.5 text-muted-foreground transition-colors hover:bg-red-500/10 hover:text-red-500"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </CollapsibleSection>
  );
}
