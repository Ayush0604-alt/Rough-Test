// Shared by the Settings page's top-of-page search box and every
// <CollapsibleSection> on the page (regardless of which file renders it —
// Settings/index.tsx itself, or a nested card like ExtractionAnalysisCard) —
// a plain DOM CustomEvent, so there's no need to lift/prop-drill open state
// through the whole page just so search can expand a section that happens to
// live in a different component.
export interface SectionRegistryEntry {
  id: string;
  title: string;
  keywords: string[];
}

// One entry per <CollapsibleSection id="..."> on the page. Multiple entries
// may point at the same id (e.g. "SKILL.md" / "Analysis Prompt" / "NLRS" all
// live in one merged tile) — searching any of those terms finds it.
export const SECTION_REGISTRY: SectionRegistryEntry[] = [
  { id: "user-management", title: "User Management", keywords: ["users", "accounts", "roles", "admin", "recruiter", "sysadmin"] },
  { id: "feedback", title: "Feedback", keywords: ["bug", "report", "feature request", "feedback", "issue", "priority", "p1", "export", "requests"] },
  { id: "pipeline-config", title: "Pipeline Configuration", keywords: ["run time", "retries", "archive", "schedule"] },
  { id: "notifications", title: "Notifications", keywords: ["email alerts", "manual review", "exhausted", "run summary"] },
  { id: "email-send-controls", title: "Email Send Controls", keywords: ["auto-send", "draft review", "send draft", "qa email", "confirmation", "round slot invite", "auto-send invites"] },
  { id: "chatbot", title: "Chatbot", keywords: ["floating chat", "neuleap buddy", "widget"] },
  { id: "interview-slot-picker", title: "Interview Slot Picker", keywords: ["slot link", "scheduling api", "email draft"] },
  { id: "candidate-sections", title: "Candidate Page Sections", keywords: ["quick signals", "thinking summary", "ats breakdown", "nlrs breakdown", "skills", "certificates", "career timeline", "round history"] },
  { id: "stream-definitions", title: "Stream Definitions", keywords: ["genai", "data eng", "keywords", "stream"] },
  { id: "cert-tags", title: "Certificate Filter Tags", keywords: ["aws", "google", "microsoft", "databricks", "snowflake"] },
  { id: "interviewer-access", title: "Interviewer Access", keywords: ["domains", "otp", "remember device", "revoke sessions", "interview link", "nli code"] },
  { id: "round-interviewers", title: "Round Interviewers", keywords: ["roster", "screening", "round 1", "round 2", "final", "hr", "joining followup", "onboarding", "interviewer roster"] },
  { id: "interview-scheduling", title: "Interview Scheduling", keywords: ["slot picker", "calendar", "reminder", "auto-reject", "graph", "qa calendar email", "qa email", "slot duration"] },
  { id: "extraction-analysis", title: "Extraction & Analysis", keywords: ["skill.md", "extraction prompt", "analysis report prompt", "nlrs", "weights", "rules", "nba bands", "re-extract", "batch"] },
  { id: "legacy-features", title: "Legacy Features", keywords: ["interview round button", "deprecated", "old", "flags", "temp"] },
  { id: "llm-model-keys", title: "LLM Model Keys", keywords: ["llm", "azure openai", "api key", "deployment", "model", "endpoint", "gpt", "per-module keys", "ai provider", "fallback deployment", "keys"] },
  { id: "referrals", title: "Referrals", keywords: ["referral", "referred by", "refer", "sender email", "domain", "clip", "campus", "internal referral"] },
  { id: "graph-api", title: "Graph API", keywords: ["graph", "microsoft graph", "azure", "tenant id", "client id", "client secret", "app registration", "mailbox auth", "outlook", "calendar", "oauth"] },
  { id: "backup-dr", title: "Backup & Disaster Recovery", keywords: ["backup", "disaster recovery", "dr", "restore", "health", "pg_dump", "snapshot", "incremental", "full backup", "retention", "cloud", "s3", "nas", "schedule", "system health"] },
  { id: "system-upgrade", title: "System Upgrade", keywords: ["upgrade", "update", "version", "bundle", "install", "deploy", "rollback", "seamless upgrade", "new version", "image"] },
  { id: "interview-question-generation", title: "Interview Question Generation", keywords: ["interview questions", "generate questions", "question modes", "question types", "aptitude", "logical reasoning", "prompt writing", "operations research", "analytical", "composition", "web search", "skill", "generation prompt", "question bank", "dropdown modes"] },
];

export const SECTION_FOCUS_EVENT = "settings-focus-section";

export function focusSection(id: string) {
  window.dispatchEvent(new CustomEvent(SECTION_FOCUS_EVENT, { detail: id }));
}

// Relevance scoring: exact title match > title starts-with > title includes
// > exact keyword > keyword includes > every query WORD found somewhere
// (title or keywords, not necessarily contiguous) > any query word found.
// The last two tiers matter for multi-word type-ahead queries — e.g. "qa
// email" should still find a section whose only keyword is the (non-
// contiguous) phrase "qa calendar email", not just an exact-substring match.
function scoreEntry(entry: SectionRegistryEntry, q: string): number {
  const title = entry.title.toLowerCase();
  const keywordsLower = entry.keywords.map((k) => k.toLowerCase());

  if (title === q) return 100;
  if (title.startsWith(q)) return 90;
  if (title.includes(q)) return 80;
  if (keywordsLower.some((k) => k === q)) return 75;
  if (keywordsLower.some((k) => k.includes(q))) return 70;

  const haystack = [title, ...keywordsLower].join(" | ");
  const tokens = q.split(/\s+/).filter(Boolean);
  if (tokens.length > 1 && tokens.every((t) => haystack.includes(t))) return 50;
  if (tokens.some((t) => t.length >= 2 && haystack.includes(t))) return 20;
  return 0;
}

/** Ranked matches for the Settings search box's type-ahead dropdown — every
 * section scoring above 0, closest first, capped at `limit`. */
export function findSectionMatches(query: string, limit = 6): SectionRegistryEntry[] {
  const q = query.trim().toLowerCase();
  if (!q) return [];
  return SECTION_REGISTRY
    .map((entry) => ({ entry, score: scoreEntry(entry, q) }))
    .filter((s) => s.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map((s) => s.entry);
}

export function findBestSectionMatch(query: string): SectionRegistryEntry | null {
  return findSectionMatches(query, 1)[0] ?? null;
}
