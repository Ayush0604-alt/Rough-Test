import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ListChecks, Plus, Trash2, Loader2, Save, RotateCcw, FileText, ChevronDown, Search } from "lucide-react";
import { interviewService, type InterviewModeConfig } from "@/services/interview";
import { apiErrorMessage, cn } from "@/lib/utils";
import { useConfirm } from "@/components/common/ConfirmProvider";
import CollapsibleSection from "@/components/settings/CollapsibleSection";

/**
 * Settings → Interview Question Generation (Admin only). Two editors:
 *  1. The question-generation MODES that populate the "Generate Interview
 *     Questions" multi-select dropdown — the built-ins are the default, but an
 *     Admin can add / edit / delete custom types (label, bucket_name, topic,
 *     web-search guidance) and reset back to the defaults.
 *  2. The generation SKILL/prompt — the logic the LLM follows (how web-search
 *     results are used, what "challenging at a level" means, composition
 *     rules). Editable to improve quality, with reset-to-default.
 *
 * Both persist server-side (require_admin) — see app/api/interview.py.
 */
export default function InterviewQuestionGenerationCard() {
  return (
    <CollapsibleSection
      id="interview-question-generation"
      icon={ListChecks}
      title="Interview Question Generation"
      desc="Manage the question-type modes in the Generate dropdown, and edit the generation SKILL that grounds them"
      colSpan="lg:col-span-2"
    >
      <div className="space-y-5">
        <ModesEditor />
        <div className="border-t border-border/60 pt-5">
          <PromptEditor />
        </div>
      </div>
    </CollapsibleSection>
  );
}

const BLANK: InterviewModeConfig = { key: "", label: "", bucket_name: "", topic: "", guidance: "" };

// Strip a trailing "Questions"/"Question" so a label like "SQL Aptitude Questions"
// seeds "SQL Aptitude ..." rather than "... Questions questions".
const cleanTopicBase = (s: string) =>
  s.replace(/\bquestions?\b/gi, "").replace(/[()]/g, " ").replace(/\s+/g, " ").trim();

// Suggested search phrasings that tend to fetch the best interview material for
// a topic — offered as one-click chips next to the topic field.
const topicSuggestions = (label: string, bucket: string): string[] => {
  const base = cleanTopicBase(bucket || label) || "the topic";
  return [
    `${base} interview questions and answers`,
    `latest ${base} interview questions`,
    `advanced ${base} problems with solutions`,
  ];
};

function ModesEditor() {
  const confirm = useConfirm();
  const queryClient = useQueryClient();
  const { data } = useQuery({
    queryKey: ["interview-modes"],
    queryFn: async () => (await interviewService.getModes()).data,
  });
  const [modes, setModes] = useState<InterviewModeConfig[]>([]);
  const [draft, setDraft] = useState<InterviewModeConfig>(BLANK);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    if (data) setModes(data);
  }, [data]);

  const flash = (msg: string) => {
    setNotice(msg);
    setTimeout(() => setNotice(null), 4000);
  };

  const save = useMutation({
    mutationFn: (next: InterviewModeConfig[]) => interviewService.saveModes(next),
    onSuccess: ({ data: saved }) => {
      queryClient.setQueryData(["interview-modes"], saved);
      setModes(saved);
      setError(null);
      flash("Saved — the Generate dropdown now offers these question types.");
    },
    onError: (e) => setError(apiErrorMessage(e, "Couldn't save the question modes.")),
  });

  const revert = useMutation({
    mutationFn: () => interviewService.revertModes(),
    onSuccess: ({ data: saved }) => {
      queryClient.setQueryData(["interview-modes"], saved);
      setModes(saved);
      setError(null);
      flash("Reset to the built-in default question types.");
    },
    onError: (e) => setError(apiErrorMessage(e, "Couldn't reset the question modes.")),
  });

  const setField = (i: number, key: keyof InterviewModeConfig, value: string) =>
    setModes((prev) => prev.map((m, idx) => (idx === i ? { ...m, [key]: value } : m)));

  const remove = (i: number) => setModes((prev) => prev.filter((_, idx) => idx !== i));

  const addDraft = () => {
    const label = draft.label.trim();
    const bucket = draft.bucket_name.trim();
    const topic = draft.topic.trim();
    if (!label || !bucket || !topic) {
      setError("A question type needs a label, a bucket name, and a web-search topic.");
      return;
    }
    setError(null);
    setModes((prev) => [
      ...prev,
      {
        key: "", // backend slugs it from the label
        label,
        bucket_name: bucket,
        topic,
        guidance: draft.guidance.trim(),
      },
    ]);
    setDraft(BLANK);
  };

  // Guard the whole list on save — every mode must carry a topic so "Search the
  // web" always has something good to fetch.
  const missingTopics = modes.filter((m) => !(m.topic || "").trim());

  const saveModes = () => {
    if (modes.length === 0) {
      setError("Keep at least one question type, or reset to the defaults.");
      return;
    }
    if (missingTopics.length > 0) {
      setError(
        `Add a web-search topic for: ${missingTopics.map((m) => m.label || "(unnamed)").join(", ")} — use Suggest to fill it.`
      );
      return;
    }
    save.mutate(modes);
  };

  return (
    <div className="space-y-3">
      <div>
        <div className="text-xs font-semibold text-foreground">Question-type modes</div>
        <p className="mt-0.5 text-[11px] leading-relaxed text-muted-foreground">
          Each mode is one selectable option in the candidate page's <b>Generate Interview
          Questions</b> multi-select. <b>Label</b> is what recruiters pick; <b>Bucket</b> names the
          section in the generated kit (and keys its composition weight); <b>Topic</b> (required)
          is the query the web search fetches when &ldquo;Search the web&rdquo; is on — use the
          <b> Suggested</b> chips for a query that pulls the best material; <b>Guidance</b> tells the
          model the level/style to target. Edits
          apply on the next kit generation.
        </p>
      </div>

      <div className="space-y-2">
        {modes.map((m, i) => (
          <div key={`${m.key || m.label}-${i}`} className="rounded-lg border border-border/60 bg-secondary/20 p-2.5">
            <div className="flex flex-col gap-1.5 sm:flex-row">
              <input
                value={m.label}
                onChange={(e) => setField(i, "label", e.target.value)}
                placeholder={'Dropdown label — e.g. "SQL Aptitude Questions"'}
                title="What recruiters see in the Generate dropdown"
                className="min-w-0 flex-1 rounded-md border border-border bg-background px-2 py-1 text-xs font-medium text-foreground outline-none focus:border-primary/50"
              />
              <input
                value={m.bucket_name}
                onChange={(e) => setField(i, "bucket_name", e.target.value)}
                placeholder={'Section title — e.g. "SQL Aptitude"'}
                title="The heading this mode's questions appear under in the kit"
                className="min-w-0 flex-1 rounded-md border border-border bg-background px-2 py-1 text-xs text-foreground outline-none focus:border-primary/50"
              />
              <button
                type="button"
                onClick={() => remove(i)}
                title="Remove this question type"
                className="shrink-0 self-start rounded-md p-1.5 text-muted-foreground transition-colors hover:bg-secondary hover:text-rose-500"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </div>
            <div className="mt-1.5 flex flex-col gap-1.5 sm:flex-row">
              <div className="relative flex min-w-0 flex-1 items-center">
                <input
                  value={m.topic}
                  onChange={(e) => setField(i, "topic", e.target.value)}
                  placeholder={'Web-search topic (required) — e.g. "SQL interview questions with answers"'}
                  title="Used when “Search the web” is on to fetch fresh questions for this topic"
                  className={cn(
                    "min-w-0 flex-1 rounded-md border bg-background py-1 pl-2 pr-7 text-[11px] text-foreground outline-none focus:border-primary/50",
                    (m.topic || "").trim() ? "border-border" : "border-amber-500/40"
                  )}
                />
                <button
                  type="button"
                  onClick={() => setField(i, "topic", topicSuggestions(m.label, m.bucket_name)[0])}
                  title="Suggest a good search query from this section"
                  className="absolute right-1 rounded p-0.5 text-muted-foreground transition-colors hover:bg-secondary hover:text-primary"
                >
                  <Search className="h-3 w-3" />
                </button>
              </div>
              <input
                value={m.guidance}
                onChange={(e) => setField(i, "guidance", e.target.value)}
                placeholder={'Level & style (optional) — e.g. "Joins, window functions & query tuning; hands-on, not definitions"'}
                title="Tells the model the depth/level and style of questions for this mode"
                className="min-w-0 flex-[2] rounded-md border border-border bg-background px-2 py-1 text-[11px] text-foreground outline-none focus:border-primary/50"
              />
            </div>
          </div>
        ))}
        {modes.length === 0 && (
          <p className="py-3 text-center text-[11px] text-muted-foreground">
            No question types — add one below or reset to the defaults.
          </p>
        )}
      </div>

      {/* Add a new mode */}
      <div className="rounded-lg border border-dashed border-border bg-secondary/10 p-2.5">
        <div className="mb-1.5 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
          Add a question type
        </div>
        <div className="flex flex-col gap-1.5 sm:flex-row">
          <input
            value={draft.label}
            onChange={(e) => { setDraft({ ...draft, label: e.target.value }); if (error) setError(null); }}
            placeholder={'Dropdown label — e.g. "Cloud Architecture Aptitude Questions"'}
            title="What recruiters see in the Generate dropdown"
            className="min-w-0 flex-1 rounded-md border border-border bg-background px-2 py-1 text-xs text-foreground outline-none focus:border-primary/50"
          />
          <input
            value={draft.bucket_name}
            onChange={(e) => { setDraft({ ...draft, bucket_name: e.target.value }); if (error) setError(null); }}
            placeholder={'Section title in the kit — e.g. "Cloud Architecture Aptitude"'}
            title="The heading this mode's questions appear under in the generated kit (also keys its composition weight)"
            className="min-w-0 flex-1 rounded-md border border-border bg-background px-2 py-1 text-xs text-foreground outline-none focus:border-primary/50"
          />
        </div>
        <div className="mt-1.5 flex flex-col gap-1.5 sm:flex-row">
          <input
            value={draft.topic}
            onChange={(e) => { setDraft({ ...draft, topic: e.target.value }); if (error) setError(null); }}
            placeholder={'Web-search topic (required) — e.g. "AWS solutions architect interview questions"'}
            title="Used when “Search the web” is on to fetch fresh, popular questions for this topic"
            className={cn(
              "min-w-0 flex-1 rounded-md border bg-background px-2 py-1 text-[11px] text-foreground outline-none focus:border-primary/50",
              draft.topic.trim() ? "border-border" : "border-amber-500/40"
            )}
          />
          <input
            value={draft.guidance}
            onChange={(e) => setDraft({ ...draft, guidance: e.target.value })}
            onKeyDown={(e) => e.key === "Enter" && addDraft()}
            placeholder={'Level & style (optional) — e.g. "Senior level: real-world scenarios & tradeoffs, not trivia"'}
            title="Tells the model the depth/level and the style of questions to produce for this mode"
            className="min-w-0 flex-[2] rounded-md border border-border bg-background px-2 py-1 text-[11px] text-foreground outline-none focus:border-primary/50"
          />
          <button
            type="button"
            onClick={addDraft}
            disabled={!draft.label.trim() || !draft.bucket_name.trim() || !draft.topic.trim()}
            className="inline-flex shrink-0 items-center justify-center gap-1 rounded-md border border-border px-2.5 py-1 text-xs font-semibold text-foreground transition-colors hover:bg-secondary disabled:opacity-40"
          >
            <Plus className="h-3.5 w-3.5" /> Add
          </button>
        </div>
        {/* Suggested search phrasings — click to fill the topic with a query that
            tends to fetch the best interview material for this section. */}
        {(draft.label.trim() || draft.bucket_name.trim()) && (
          <div className="mt-1.5 flex flex-wrap items-center gap-1">
            <span className="inline-flex items-center gap-1 text-[10px] font-medium text-muted-foreground">
              <Search className="h-3 w-3" /> Suggested:
            </span>
            {topicSuggestions(draft.label, draft.bucket_name).map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => { setDraft({ ...draft, topic: s }); if (error) setError(null); }}
                className="rounded-full border border-primary/30 bg-primary/5 px-2 py-0.5 text-[10px] text-primary transition-colors hover:bg-primary/10"
              >
                {s}
              </button>
            ))}
          </div>
        )}
      </div>

      {error && <p className="text-[11px] font-medium text-rose-500">{error}</p>}
      {notice && <p className="text-[11px] font-medium text-emerald-600">{notice}</p>}

      <div className="flex items-center justify-end gap-2">
        <button
          type="button"
          onClick={async () => {
            if (await confirm({ title: "Reset question types?", message: "Reset the question types back to the built-in defaults? Your custom types will be removed.", confirmLabel: "Reset", danger: true })) revert.mutate();
          }}
          disabled={revert.isPending || save.isPending}
          className="inline-flex items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-secondary disabled:opacity-40"
        >
          {revert.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RotateCcw className="h-3.5 w-3.5" />}
          Reset to default
        </button>
        <button
          type="button"
          onClick={saveModes}
          disabled={save.isPending}
          className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3.5 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-primary/90 disabled:opacity-40"
        >
          {save.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
          Save modes
        </button>
      </div>
    </div>
  );
}

function PromptEditor() {
  const confirm = useConfirm();
  const queryClient = useQueryClient();
  const { data } = useQuery({
    queryKey: ["interview-prompt"],
    queryFn: async () => (await interviewService.getPrompt()).data,
  });
  const [text, setText] = useState("");
  const [expanded, setExpanded] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    if (data) setText(data.prompt);
  }, [data]);

  const flash = (msg: string) => {
    setNotice(msg);
    setTimeout(() => setNotice(null), 4000);
  };

  const save = useMutation({
    mutationFn: (prompt: string) => interviewService.savePrompt(prompt),
    onSuccess: ({ data: saved }) => {
      queryClient.setQueryData(["interview-prompt"], saved);
      setText(saved.prompt);
      setError(null);
      flash("Saved — new kits use this generation logic.");
    },
    onError: (e) => setError(apiErrorMessage(e, "Couldn't save the generation SKILL.")),
  });

  const revert = useMutation({
    mutationFn: () => interviewService.revertPrompt(),
    onSuccess: ({ data: saved }) => {
      queryClient.setQueryData(["interview-prompt"], saved);
      setText(saved.prompt);
      setError(null);
      flash("Reset to the default generation SKILL.");
    },
    onError: (e) => setError(apiErrorMessage(e, "Couldn't reset the generation SKILL.")),
  });

  const isCustom = data?.is_custom ?? false;
  const dirty = data ? text !== data.prompt : false;

  return (
    <div className="space-y-3">
      <button
        type="button"
        onClick={() => setExpanded((v) => !v)}
        className="flex w-full items-center gap-2 text-left"
      >
        <FileText className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
        <div className="min-w-0 flex-1">
          <div className="text-xs font-semibold text-foreground">
            Generation SKILL{" "}
            <span
              className={cn(
                "ml-1 rounded-full border px-1.5 py-px text-[9px] font-semibold",
                isCustom
                  ? "border-amber-500/30 bg-amber-400/10 text-amber-600"
                  : "border-border bg-secondary text-muted-foreground"
              )}
            >
              {isCustom ? "customised" : "default"}
            </span>
          </div>
          <div className="text-[11px] text-muted-foreground">
            The prompt logic the model follows — how web-search results are used, what
            &ldquo;challenging at a level&rdquo; means, composition rules
          </div>
        </div>
        <ChevronDown className={cn("h-4 w-4 shrink-0 text-muted-foreground transition-transform", expanded && "rotate-180")} />
      </button>

      {expanded && (
        <>
          <textarea
            value={text}
            onChange={(e) => { setText(e.target.value); if (error) setError(null); }}
            spellCheck={false}
            rows={18}
            className="w-full resize-y rounded-lg border border-border bg-background px-3 py-2 font-mono text-[11px] leading-relaxed text-foreground outline-none focus:border-primary/50"
          />
          {error && <p className="text-[11px] font-medium text-rose-500">{error}</p>}
          {notice && <p className="text-[11px] font-medium text-emerald-600">{notice}</p>}
          <div className="flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={async () => {
                if (await confirm({ title: "Reset the generation SKILL back to the built-in default?", confirmLabel: "Reset", danger: true })) revert.mutate();
              }}
              disabled={revert.isPending || save.isPending || !isCustom}
              title={isCustom ? "Reset to the default prompt" : "Already on the default prompt"}
              className="inline-flex items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-secondary disabled:opacity-40"
            >
              {revert.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RotateCcw className="h-3.5 w-3.5" />}
              Reset to default
            </button>
            <button
              type="button"
              onClick={() => save.mutate(text)}
              disabled={save.isPending || !dirty}
              className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3.5 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-primary/90 disabled:opacity-40"
            >
              {save.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
              Save SKILL
            </button>
          </div>
        </>
      )}
    </div>
  );
}
