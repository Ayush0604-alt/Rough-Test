// Settings → Extraction & Analysis — Admin-ONLY (see app/api/extraction_settings.py;
// gated here too via the `isAdmin` check in Settings/index.tsx, not just hidden UI).
// One collapsed-by-default tile (see CollapsibleSection) holding three pieces,
// each with its own "re-run across a batch (by source tag)" action reusing the
// same batch grouping as Mailbox → Batch Archive:
//   1. SKILL.md — the whole extraction/analysis prompt file, download/upload+test/revert.
//   2. Analysis Report prompt — a "simple view" of just that one section (side by
//      side with #1 to save vertical space — they're edited/tested together).
//   3. NLRS weights / NBA bands / custom rules — computed live, so saving applies
//      instantly everywhere; "recalculate across a batch" is a read-only preview.
import { useEffect, useRef, useState } from "react";
import {
  AlertTriangle,
  Check,
  Download,
  FileCode,
  Gauge,
  Loader2,
  Play,
  Plus,
  RotateCcw,
  Save,
  Trash2,
  Upload,
  Wand2,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useConfirm } from "@/components/common/ConfirmProvider";
import CollapsibleSection from "./CollapsibleSection";
import { collapseUnchanged, diffLines, diffSizeExceeded, type DiffDisplayItem } from "@/lib/diffLines";
import {
  settingsService,
  type BatchRunResult,
  type NlrsConfig,
  type NlrsPreviewResult,
  type NlrsRule,
} from "@/services/settings";
import { batchArchiveService, type LiveBatch } from "@/services/batchArchive";

function errorDetail(e: unknown, fallback: string): string {
  const detail = (e as { response?: { data?: { detail?: string } } })?.response?.data?.detail;
  return detail ?? fallback;
}

function downloadText(filename: string, text: string) {
  const blob = new Blob([text], { type: "text/markdown" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  URL.revokeObjectURL(a.href);
}

// A lighter heading than the page-level SectionHeader — these three pieces
// now live inside ONE outer CollapsibleSection, so each just needs a small
// label, not a full card header.
function MiniHeader({ icon: Icon, title, desc }: { icon: React.ElementType; title: string; desc: string }) {
  return (
    <div className="mb-3 flex items-center gap-2">
      <Icon className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
      <div>
        <div className="text-xs font-semibold text-foreground">{title}</div>
        <div className="text-[10px] text-muted-foreground">{desc}</div>
      </div>
    </div>
  );
}

// ── Diff view — old (currently in the editor) vs new (uploaded file) ────────

function DiffLineRow({ item }: { item: DiffDisplayItem }) {
  if (item.type === "collapsed") {
    return (
      <div className="px-3 py-1 text-center text-[10px] text-muted-foreground">
        ⋯ {item.count} unchanged line{item.count === 1 ? "" : "s"} ⋯
      </div>
    );
  }
  return (
    <div
      className={cn(
        "whitespace-pre-wrap break-all px-3 py-0.5 font-mono text-[11px] leading-relaxed",
        item.type === "added" && "bg-emerald-500/10 text-emerald-700 dark:text-emerald-400",
        item.type === "removed" && "bg-rose-500/10 text-rose-700 dark:text-rose-400 line-through decoration-1",
        item.type === "same" && "text-muted-foreground"
      )}
    >
      <span className="mr-2 select-none opacity-60">{item.type === "added" ? "+" : item.type === "removed" ? "−" : " "}</span>
      {item.text || " "}
    </div>
  );
}

function DiffConfirmModal({
  title = "Confirm the change before it's incorporated",
  confirmLabel = "Confirm",
  vsLabel = "what's currently live",
  oldText,
  newText,
  onConfirm,
  onCancel,
}: {
  title?: string;
  confirmLabel?: string;
  vsLabel?: string;
  oldText: string;
  newText: string;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  const tooLarge = diffSizeExceeded(oldText, newText);
  const items = tooLarge ? [] : collapseUnchanged(diffLines(oldText, newText));
  const added = items.filter((i) => "type" in i && i.type === "added").length;
  const removed = items.filter((i) => "type" in i && i.type === "removed").length;

  return (
    <div
      className="fixed inset-0 z-[70] flex items-center justify-center bg-foreground/50 p-4 backdrop-blur-sm"
      onClick={onCancel}
    >
      <div
        className="flex max-h-[85vh] w-full max-w-3xl flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b border-border px-5 py-3.5">
          <div>
            <h3 className="text-sm font-bold text-foreground">{title}</h3>
            <p className="text-[11px] text-muted-foreground">
              {tooLarge
                ? "Too large to line-diff — review the content manually before confirming."
                : added === 0 && removed === 0
                  ? "No changes detected."
                  : `+${added} / −${removed} line(s) vs. ${vsLabel}.`}
            </p>
          </div>
          <button onClick={onCancel} className="rounded-lg p-1.5 text-muted-foreground hover:bg-secondary hover:text-foreground">
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto bg-secondary/20">
          {tooLarge ? (
            <pre className="whitespace-pre-wrap break-all p-3 font-mono text-[11px] text-foreground">{newText}</pre>
          ) : (
            items.map((item) => <DiffLineRow key={item.key} item={item} />)
          )}
        </div>
        <div className="flex justify-end gap-2 border-t border-border px-5 py-3.5">
          <button
            onClick={onCancel}
            className="rounded-lg border border-border px-3.5 py-1.5 text-xs font-semibold text-foreground hover:bg-secondary"
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3.5 py-1.5 text-xs font-semibold text-primary-foreground hover:bg-primary/90"
          >
            <Check className="h-3.5 w-3.5" /> {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Source-tag picker — same batches Mailbox → Batch Archive lists ──────────

function SourceBatchPicker({
  value,
  onChange,
}: {
  value: string | null | undefined;
  onChange: (v: string | null) => void;
}) {
  const [batches, setBatches] = useState<LiveBatch[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    batchArchiveService
      .listLive()
      .then(({ data }) => setBatches(data.batches))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  return (
    <select
      value={value === undefined ? "" : value === null ? "__none__" : value}
      onChange={(e) => onChange(e.target.value === "__none__" ? null : e.target.value)}
      className="min-w-[12rem] flex-1 rounded-lg border border-border bg-secondary px-2 py-1.5 text-xs text-foreground focus:outline-none focus:border-primary/50"
    >
      <option value="" disabled>
        {loading ? "Loading batches…" : "Choose a batch…"}
      </option>
      {batches.map((b) => (
        <option key={b.source ?? "__none__"} value={b.source === null ? "__none__" : b.source}>
          {b.source ?? "No source"} ({b.candidate_count})
        </option>
      ))}
    </select>
  );
}

// ── Generic "pick a batch, run an action, show the result" panel ────────────

function BatchRunPanel<T>({
  label,
  runLabel,
  onRun,
  renderResult,
  confirmMessage,
}: {
  label: string;
  runLabel: string;
  onRun: (source: string | null) => Promise<T>;
  renderResult: (result: T) => React.ReactNode;
  confirmMessage: string;
}) {
  const confirm = useConfirm();
  const [source, setSource] = useState<string | null | undefined>(undefined);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);

  const run = async () => {
    if (source === undefined) return;
    if (!(await confirm({ title: "Run across this batch?", message: confirmMessage, danger: true }))) return;
    setBusy(true);
    setError(null);
    setResult(null);
    try {
      setResult(await onRun(source));
    } catch (e) {
      setError(errorDetail(e, "Failed — try again."));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mt-3 rounded-lg border border-border bg-secondary/30 p-3">
      <div className="mb-2 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className="flex flex-wrap items-center gap-2">
        <SourceBatchPicker value={source} onChange={setSource} />
        <button
          onClick={run}
          disabled={busy || source === undefined}
          className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground transition-colors hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-50"
        >
          {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Play className="h-3.5 w-3.5" />}
          {runLabel}
        </button>
      </div>
      {error && <p className="mt-2 text-[11px] text-red-400">{error}</p>}
      {result && <div className="mt-3">{renderResult(result)}</div>}
    </div>
  );
}

function BatchRunSummary({ r }: { r: BatchRunResult }) {
  return (
    <p className="text-[11px] text-muted-foreground">
      <span className="font-semibold text-foreground">{r.succeeded}</span>/{r.total} succeeded
      {r.failed > 0 && <span className="text-amber-500"> · {r.failed} failed</span>}
      {r.errors && r.errors.length > 0 && (
        <span className="mt-1 block">
          {r.errors.slice(0, 5).map((e) => `${e.candidate_id}: ${e.error}`).join(" · ")}
        </span>
      )}
    </p>
  );
}

// ── 1. SKILL.md — whole-file override ────────────────────────────────────────

function SkillOverrideSection() {
  const confirm = useConfirm();
  const [overridden, setOverridden] = useState(false);
  const [defaultText, setDefaultText] = useState("");
  const [draft, setDraft] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [pendingUpload, setPendingUpload] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const load = () => {
    setLoading(true);
    settingsService
      .getSkillOverride()
      .then(({ data }) => {
        setOverridden(data.overridden);
        setDefaultText(data.default_text);
        setDraft(data.active_text);
      })
      .catch(() => setErr("Couldn't load SKILL.md."))
      .finally(() => setLoading(false));
  };
  useEffect(load, []);

  const save = async () => {
    setSaving(true);
    setErr(null);
    setMsg(null);
    try {
      const { data } = await settingsService.saveSkillOverride(draft);
      setOverridden(data.overridden);
      setMsg("Saved — now live for new extractions.");
    } catch (e) {
      setErr(errorDetail(e, "Couldn't save — check the file has valid MASTER_PROMPT/ANALYSIS_REPORT_PROMPT markers."));
    } finally {
      setSaving(false);
      setTimeout(() => setMsg(null), 4000);
    }
  };

  const revert = async () => {
    if (!(await confirm({ title: "Revert SKILL.md?", message: "Revert SKILL.md to the shipped default? Your saved override will be discarded.", confirmLabel: "Revert", danger: true }))) return;
    setSaving(true);
    try {
      const { data } = await settingsService.revertSkillOverride();
      setOverridden(data.overridden);
      setDraft(data.active_text);
      setMsg("Reverted to default.");
    } finally {
      setSaving(false);
      setTimeout(() => setMsg(null), 4000);
    }
  };

  const onFile = (file: File) => {
    const reader = new FileReader();
    // Don't touch the editor yet — show the diff-confirm gate first.
    reader.onload = () => setPendingUpload(String(reader.result ?? ""));
    reader.readAsText(file);
    if (fileRef.current) fileRef.current.value = ""; // allow re-picking the same file
  };

  return (
    <div>
      <MiniHeader
        icon={FileCode}
        title="SKILL.md — Extraction Prompt"
        desc="The master extraction prompt used for every resume."
      />
      {loading ? (
        <div className="flex items-center gap-2 py-4 text-xs text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading…
        </div>
      ) : (
        <>
          <div className="mb-2 flex flex-wrap items-center gap-2">
            <span
              className={cn(
                "inline-flex items-center rounded-full border px-2 py-0.5 text-[10px] font-semibold",
                overridden
                  ? "border-amber-500/30 bg-amber-400/10 text-amber-600"
                  : "border-emerald-500/30 bg-emerald-500/10 text-emerald-600"
              )}
            >
              {overridden ? "Custom override active" : "Using system default"}
            </span>
            <button
              onClick={() => downloadText("SKILL.md", draft)}
              className="inline-flex items-center gap-1.5 rounded-lg border border-border px-2.5 py-1 text-[11px] font-semibold text-muted-foreground hover:bg-secondary hover:text-foreground"
            >
              <Download className="h-3 w-3" /> Download current
            </button>
            <input
              ref={fileRef}
              type="file"
              accept=".md,text/markdown,text/plain"
              className="hidden"
              onChange={(e) => e.target.files?.[0] && onFile(e.target.files[0])}
            />
            <button
              onClick={() => fileRef.current?.click()}
              className="inline-flex items-center gap-1.5 rounded-lg border border-border px-2.5 py-1 text-[11px] font-semibold text-muted-foreground hover:bg-secondary hover:text-foreground"
            >
              <Upload className="h-3 w-3" /> Upload .md file
            </button>
          </div>
          {draft !== defaultText && (
            <button
              onClick={() => setDraft(defaultText)}
              className="mb-2 text-[11px] text-muted-foreground hover:text-foreground"
            >
              Load shipped default into editor
            </button>
          )}

          <textarea
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            spellCheck={false}
            rows={14}
            className="w-full rounded-lg border border-border bg-secondary/30 px-3 py-2 font-mono text-[11px] leading-relaxed text-foreground outline-none focus:border-primary/50"
          />

          {err && <p className="mt-2 text-[11px] text-red-400">{err}</p>}
          {msg && <p className="mt-2 text-[11px] text-emerald-500">{msg}</p>}

          <div className="mt-2 flex flex-wrap gap-2">
            <button
              onClick={save}
              disabled={saving || draft.trim() === ""}
              className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
            >
              {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
              Save &amp; test
            </button>
            <button
              onClick={revert}
              disabled={saving || !overridden}
              className="inline-flex items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-muted-foreground hover:bg-secondary disabled:cursor-not-allowed disabled:opacity-40"
            >
              <RotateCcw className="h-3.5 w-3.5" /> Revert to default
            </button>
          </div>

          <BatchRunPanel
            label="Re-do extraction & analysis across a batch (by source tag)"
            runLabel="Re-run batch"
            confirmMessage="Re-extract every candidate in this batch? This overwrites their extracted fields (name, skills, ATS score, Analysis Report, etc.) using the currently saved SKILL.md."
            onRun={(source) => settingsService.rerunSkillOverride(source).then((r) => r.data)}
            renderResult={(r) => <BatchRunSummary r={r} />}
          />

          {pendingUpload !== null && (
            <DiffConfirmModal
              title="Confirm the change before it's incorporated"
              confirmLabel="Use this file"
              vsLabel="what's currently in the editor"
              oldText={draft}
              newText={pendingUpload}
              onCancel={() => setPendingUpload(null)}
              onConfirm={() => {
                setDraft(pendingUpload);
                setPendingUpload(null);
              }}
            />
          )}
        </>
      )}
    </div>
  );
}

// ── 2. Analysis Report prompt — the "simple view" ────────────────────────────

function AnalysisPromptSection() {
  const confirm = useConfirm();
  const [overridden, setOverridden] = useState(false);
  const [defaultPrompt, setDefaultPrompt] = useState("");
  const [activePrompt, setActivePrompt] = useState("");
  const [draft, setDraft] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [pendingSave, setPendingSave] = useState<string | null>(null);

  const load = () => {
    setLoading(true);
    settingsService
      .getAnalysisPrompt()
      .then(({ data }) => {
        setOverridden(data.overridden);
        setDefaultPrompt(data.default_prompt);
        setActivePrompt(data.active_prompt);
        setDraft(data.active_prompt);
      })
      .catch(() => setErr("Couldn't load the Analysis Report prompt."))
      .finally(() => setLoading(false));
  };
  useEffect(load, []);

  const save = async (text: string) => {
    setSaving(true);
    setErr(null);
    setMsg(null);
    try {
      const { data } = await settingsService.saveAnalysisPrompt(text);
      setOverridden(data.overridden);
      setActivePrompt(data.active_prompt);
      setMsg("Saved — now live for new extractions.");
    } catch (e) {
      setErr(errorDetail(e, "Couldn't save."));
    } finally {
      setSaving(false);
      setTimeout(() => setMsg(null), 4000);
    }
  };

  const revert = async () => {
    if (!(await confirm({ title: "Revert the Analysis Report prompt to the shipped default?", confirmLabel: "Revert", danger: true }))) return;
    setSaving(true);
    try {
      const { data } = await settingsService.revertAnalysisPrompt();
      setOverridden(data.overridden);
      setActivePrompt(data.active_prompt);
      setDraft(data.active_prompt);
      setMsg("Reverted to default.");
    } finally {
      setSaving(false);
      setTimeout(() => setMsg(null), 4000);
    }
  };

  return (
    <div>
      <MiniHeader
        icon={Wand2}
        title="Analysis Report Prompt — quick view/edit"
        desc="Just the 5-point instruction, pulled out of SKILL.md for quick edits"
      />
      {loading ? (
        <div className="flex items-center gap-2 py-4 text-xs text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading…
        </div>
      ) : (
        <>
          <div className="mb-2">
            <span
              className={cn(
                "inline-flex items-center rounded-full border px-2 py-0.5 text-[10px] font-semibold",
                overridden
                  ? "border-amber-500/30 bg-amber-400/10 text-amber-600"
                  : "border-emerald-500/30 bg-emerald-500/10 text-emerald-600"
              )}
            >
              {overridden ? "Custom override active" : "Using system default"}
            </span>
          </div>

          <textarea
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            spellCheck={false}
            rows={14}
            className="w-full rounded-lg border border-border bg-secondary/30 px-3 py-2 font-mono text-[11px] leading-relaxed text-foreground outline-none focus:border-primary/50"
          />

          {err && <p className="mt-2 text-[11px] text-red-400">{err}</p>}
          {msg && <p className="mt-2 text-[11px] text-emerald-500">{msg}</p>}

          <div className="mt-2 flex flex-wrap gap-2">
            <button
              onClick={() => setPendingSave(draft)}
              disabled={saving || draft.trim() === ""}
              className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
            >
              {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
              Save &amp; test
            </button>
            <button
              onClick={revert}
              disabled={saving || !overridden}
              className="inline-flex items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-muted-foreground hover:bg-secondary disabled:cursor-not-allowed disabled:opacity-40"
            >
              <RotateCcw className="h-3.5 w-3.5" /> Revert to default
            </button>
            {draft !== defaultPrompt && (
              <button
                onClick={() => setDraft(defaultPrompt)}
                className="self-center text-[11px] text-muted-foreground hover:text-foreground"
              >
                Load shipped default into editor
              </button>
            )}
          </div>

          <BatchRunPanel
            label="Re-do the Analysis across a batch (by source tag)"
            runLabel="Re-run batch"
            confirmMessage="Regenerate the Analysis Report for every candidate in this batch using the currently saved prompt? Only the Analysis Report field changes — nothing else is re-extracted."
            onRun={(source) => settingsService.rerunAnalysisPrompt(source).then((r) => r.data)}
            renderResult={(r) => <BatchRunSummary r={r} />}
          />

          {pendingSave !== null && (
            <DiffConfirmModal
              title="Confirm the Analysis Report prompt change"
              confirmLabel="Save & test"
              vsLabel="what's currently live"
              oldText={activePrompt}
              newText={pendingSave}
              onCancel={() => setPendingSave(null)}
              onConfirm={() => {
                setPendingSave(null);
                void save(pendingSave);
              }}
            />
          )}
        </>
      )}
    </div>
  );
}

// ── 3. NLRS weights / NBA bands / custom rules ───────────────────────────────

const WEIGHT_LABELS: Record<keyof NlrsConfig["weights"], string> = {
  analysis_report: "Analysis Report",
  cgpa: "CGPA",
  certificates: "Certificates",
  experience: "Years of experience",
  ats: "ATS",
};

function newRule(): NlrsRule {
  return {
    id: (crypto as { randomUUID?: () => string }).randomUUID?.() ?? `rule-${Date.now()}-${Math.random()}`,
    label: "",
    field: "total_companieswitched",
    op: ">=",
    value: 0,
    points: 0,
  };
}

function NlrsSection() {
  const confirm = useConfirm();
  const [cfg, setCfg] = useState<NlrsConfig | null>(null);
  const [fields, setFields] = useState<string[]>([]);
  const [ops, setOps] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  const load = () => {
    setLoading(true);
    settingsService
      .getNlrsConfig()
      .then(({ data }) => {
        setCfg(data);
        setFields(data.allowed_rule_fields ?? []);
        setOps(data.allowed_rule_ops ?? []);
      })
      .catch(() => setErr("Couldn't load NLRS settings."))
      .finally(() => setLoading(false));
  };
  useEffect(load, []);

  const weightSum = cfg ? Object.values(cfg.weights).reduce((a, b) => a + b, 0) : 0;

  const save = async () => {
    if (!cfg) return;
    setSaving(true);
    setErr(null);
    setMsg(null);
    try {
      const { data } = await settingsService.saveNlrsConfig(cfg);
      setCfg(data);
      setMsg("Saved — applies to every candidate immediately (NLRS is computed live).");
    } catch (e) {
      setErr(errorDetail(e, "Couldn't save — check every rule has a field/operator/value/points."));
    } finally {
      setSaving(false);
      setTimeout(() => setMsg(null), 5000);
    }
  };

  const revert = async () => {
    if (!(await confirm({ title: "Revert NLRS to defaults?", message: "Revert NLRS weights, NBA bands, and custom rules to the shipped defaults?", confirmLabel: "Revert", danger: true }))) return;
    setSaving(true);
    try {
      const { data } = await settingsService.revertNlrsConfig();
      setCfg(data);
      setMsg("Reverted to default.");
    } finally {
      setSaving(false);
      setTimeout(() => setMsg(null), 4000);
    }
  };

  if (loading || !cfg) {
    return (
      <div>
        <MiniHeader icon={Gauge} title="NLRS Scoring" desc="Weights, Next-Best-Action bands, and custom rules" />
        <div className="flex items-center gap-2 py-4 text-xs text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading…
        </div>
      </div>
    );
  }

  return (
    <div>
      <MiniHeader
        icon={Gauge}
        title="NLRS Scoring"
        desc="Weights, Next-Best-Action bands, and custom rules — computed live, no re-extraction needed"
      />

      <div className="mb-4">
        <div className="mb-1.5 flex items-baseline justify-between">
          <span className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Weights</span>
          <span className={cn("text-[10px] font-semibold", Math.abs(weightSum - 1) < 0.01 ? "text-emerald-500" : "text-amber-500")}>
            Sum: {weightSum.toFixed(2)}
          </span>
        </div>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          {(Object.keys(WEIGHT_LABELS) as (keyof NlrsConfig["weights"])[]).map((key) => (
            <div key={key}>
              <label className="text-[10px] text-muted-foreground">{WEIGHT_LABELS[key]}</label>
              <input
                type="number"
                min={0}
                max={1}
                step={0.01}
                value={cfg.weights[key]}
                onChange={(e) =>
                  setCfg({ ...cfg, weights: { ...cfg.weights, [key]: Number(e.target.value) } })
                }
                className="mt-0.5 w-full rounded-lg border border-border bg-secondary px-2 py-1 text-xs text-foreground focus:outline-none focus:border-primary/50"
              />
            </div>
          ))}
        </div>
      </div>

      <div className="mb-4">
        <div className="mb-1.5 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
          Next Best Action bands
        </div>
        <p className="mb-2 text-[10px] text-muted-foreground">
          Above "Call now", three narrow fast-track bands let a genuinely exceptional candidate skip straight
          to a later round instead of clearing each one in turn — keep them well above 70 so only the very
          promising minority qualifies.
        </p>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
          <div>
            <label className="text-[10px] text-muted-foreground">Final round ≥</label>
            <input
              type="number"
              value={cfg.nba_bands.final_round}
              onChange={(e) => setCfg({ ...cfg, nba_bands: { ...cfg.nba_bands, final_round: Number(e.target.value) } })}
              className="mt-0.5 w-full rounded-lg border border-border bg-secondary px-2 py-1 text-xs text-foreground focus:outline-none focus:border-primary/50"
            />
          </div>
          <div>
            <label className="text-[10px] text-muted-foreground">Round 2 ≥</label>
            <input
              type="number"
              value={cfg.nba_bands.share_round2}
              onChange={(e) => setCfg({ ...cfg, nba_bands: { ...cfg.nba_bands, share_round2: Number(e.target.value) } })}
              className="mt-0.5 w-full rounded-lg border border-border bg-secondary px-2 py-1 text-xs text-foreground focus:outline-none focus:border-primary/50"
            />
          </div>
          <div>
            <label className="text-[10px] text-muted-foreground">Round 1 ≥</label>
            <input
              type="number"
              value={cfg.nba_bands.share_round1}
              onChange={(e) => setCfg({ ...cfg, nba_bands: { ...cfg.nba_bands, share_round1: Number(e.target.value) } })}
              className="mt-0.5 w-full rounded-lg border border-border bg-secondary px-2 py-1 text-xs text-foreground focus:outline-none focus:border-primary/50"
            />
          </div>
          <div>
            <label className="text-[10px] text-muted-foreground">Call now ≥</label>
            <input
              type="number"
              value={cfg.nba_bands.call_now}
              onChange={(e) => setCfg({ ...cfg, nba_bands: { ...cfg.nba_bands, call_now: Number(e.target.value) } })}
              className="mt-0.5 w-full rounded-lg border border-border bg-secondary px-2 py-1 text-xs text-foreground focus:outline-none focus:border-primary/50"
            />
          </div>
          <div>
            <label className="text-[10px] text-muted-foreground">Undecided ≥</label>
            <input
              type="number"
              value={cfg.nba_bands.undecided}
              onChange={(e) => setCfg({ ...cfg, nba_bands: { ...cfg.nba_bands, undecided: Number(e.target.value) } })}
              className="mt-0.5 w-full rounded-lg border border-border bg-secondary px-2 py-1 text-xs text-foreground focus:outline-none focus:border-primary/50"
            />
          </div>
        </div>
        {(cfg.nba_bands.final_round < cfg.nba_bands.share_round2 ||
          cfg.nba_bands.share_round2 < cfg.nba_bands.share_round1 ||
          cfg.nba_bands.share_round1 < cfg.nba_bands.call_now ||
          cfg.nba_bands.call_now < cfg.nba_bands.undecided) && (
          <p className="mt-1 text-[10px] text-amber-500">
            Bands should read Final round ≥ Round 2 ≥ Round 1 ≥ Call now ≥ Undecided — double-check these.
          </p>
        )}
      </div>

      <div className="mb-4">
        <div className="mb-1.5 flex items-center justify-between">
          <span className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
            Custom rules — flat point adjustments
          </span>
          <button
            onClick={() => setCfg({ ...cfg, rules: [...cfg.rules, newRule()] })}
            className="inline-flex items-center gap-1 rounded-lg border border-border px-2 py-0.5 text-[10px] font-semibold text-muted-foreground hover:bg-secondary hover:text-foreground"
          >
            <Plus className="h-3 w-3" /> Add rule
          </button>
        </div>
        {cfg.rules.length === 0 ? (
          <p className="text-[11px] text-muted-foreground">No custom rules — the score is just the weighted formula above.</p>
        ) : (
          <div className="space-y-1.5">
            {cfg.rules.map((rule, i) => (
              <div key={rule.id} className="flex flex-wrap items-center gap-1.5 rounded-lg border border-border/60 bg-secondary/20 p-2">
                <input
                  value={rule.label}
                  onChange={(e) => {
                    const rules = [...cfg.rules];
                    rules[i] = { ...rule, label: e.target.value };
                    setCfg({ ...cfg, rules });
                  }}
                  placeholder="Label (e.g. Frequent job hopper)"
                  className="min-w-[10rem] flex-1 rounded-md border border-border bg-secondary px-2 py-1 text-[11px] text-foreground focus:outline-none focus:border-primary/50"
                />
                <select
                  value={rule.field}
                  onChange={(e) => {
                    const rules = [...cfg.rules];
                    rules[i] = { ...rule, field: e.target.value };
                    setCfg({ ...cfg, rules });
                  }}
                  className="rounded-md border border-border bg-secondary px-1.5 py-1 text-[11px] text-foreground focus:outline-none focus:border-primary/50"
                >
                  {fields.map((f) => <option key={f} value={f}>{f}</option>)}
                </select>
                <select
                  value={rule.op}
                  onChange={(e) => {
                    const rules = [...cfg.rules];
                    rules[i] = { ...rule, op: e.target.value };
                    setCfg({ ...cfg, rules });
                  }}
                  className="rounded-md border border-border bg-secondary px-1.5 py-1 text-[11px] text-foreground focus:outline-none focus:border-primary/50"
                >
                  {ops.map((o) => <option key={o} value={o}>{o}</option>)}
                </select>
                <input
                  type="number"
                  value={rule.value}
                  onChange={(e) => {
                    const rules = [...cfg.rules];
                    rules[i] = { ...rule, value: Number(e.target.value) };
                    setCfg({ ...cfg, rules });
                  }}
                  className="w-16 rounded-md border border-border bg-secondary px-2 py-1 text-[11px] text-foreground focus:outline-none focus:border-primary/50"
                />
                <span className="text-[10px] text-muted-foreground">→</span>
                <input
                  type="number"
                  value={rule.points}
                  onChange={(e) => {
                    const rules = [...cfg.rules];
                    rules[i] = { ...rule, points: Number(e.target.value) };
                    setCfg({ ...cfg, rules });
                  }}
                  title="Points added (negative to subtract)"
                  className="w-16 rounded-md border border-border bg-secondary px-2 py-1 text-[11px] text-foreground focus:outline-none focus:border-primary/50"
                />
                <span className="text-[10px] text-muted-foreground">pts</span>
                <button
                  onClick={() => setCfg({ ...cfg, rules: cfg.rules.filter((r) => r.id !== rule.id) })}
                  className="ml-auto rounded-lg p-1 text-muted-foreground hover:bg-red-500/10 hover:text-red-400"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {err && <p className="mb-2 text-[11px] text-red-400">{err}</p>}
      {msg && <p className="mb-2 text-[11px] text-emerald-500">{msg}</p>}

      <div className="flex flex-wrap gap-2">
        <button
          onClick={save}
          disabled={saving}
          className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
        >
          {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
          Save
        </button>
        <button
          onClick={revert}
          disabled={saving}
          className="inline-flex items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-muted-foreground hover:bg-secondary disabled:opacity-40"
        >
          <RotateCcw className="h-3.5 w-3.5" /> Revert to default
        </button>
      </div>

      <BatchRunPanel
        label="Recalculate across a batch (by source tag) — preview only"
        runLabel="Preview batch"
        confirmMessage="Compute NLRS for every candidate in this batch using the CURRENTLY SAVED weights/bands/rules? This is read-only — NLRS is never stored, so nothing is written."
        onRun={(source) => settingsService.previewNlrsConfig(source).then((r) => r.data)}
        renderResult={(r: NlrsPreviewResult) => (
          <div>
            <p className="mb-2 text-[11px] text-muted-foreground">
              <span className="font-semibold text-foreground">{r.summary.count}</span> candidates · avg{" "}
              <span className="font-semibold text-foreground">{r.summary.avg_score ?? "—"}</span> · range{" "}
              {r.summary.min_score ?? "—"}–{r.summary.max_score ?? "—"}
              {r.truncated && <span className="text-amber-500"> · showing first 500</span>}
            </p>
            <div className="max-h-48 overflow-y-auto rounded-lg border border-border">
              <table className="w-full text-[11px]">
                <thead className="sticky top-0 bg-card">
                  <tr className="text-left text-muted-foreground">
                    <th className="px-2 py-1 font-medium">Candidate</th>
                    <th className="px-2 py-1 text-right font-medium">NLRS</th>
                  </tr>
                </thead>
                <tbody>
                  {r.candidates.map((c) => (
                    <tr key={c.candidate_id} className="border-t border-border/60">
                      <td className="px-2 py-1 text-foreground">{c.name ?? c.candidate_id}</td>
                      <td className="px-2 py-1 text-right tnum font-semibold text-foreground">{c.score.toFixed(1)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      />
    </div>
  );
}

export default function ExtractionAnalysisCard() {
  return (
    <CollapsibleSection
      id="extraction-analysis"
      icon={FileCode}
      title="Extraction & Analysis"
      desc="SKILL.md, the Analysis Report prompt, and NLRS scoring — Admin only"
      colSpan="lg:col-span-2"
    >
      <div className="mb-4 flex items-center gap-2 rounded-xl border border-amber-500/30 bg-amber-400/5 px-4 py-2.5">
        <AlertTriangle className="h-4 w-4 shrink-0 text-amber-500" />
        <p className="text-[11px] text-muted-foreground">
          <span className="font-semibold text-foreground">Admin only.</span> Changes here affect live extraction,
          the Analysis Report, and every candidate's NLRS score — test on a small batch before relying on a change broadly.
        </p>
      </div>
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <SkillOverrideSection />
        <AnalysisPromptSection />
      </div>
      <div className="mt-6 border-t border-border pt-5">
        <NlrsSection />
      </div>
    </CollapsibleSection>
  );
}
