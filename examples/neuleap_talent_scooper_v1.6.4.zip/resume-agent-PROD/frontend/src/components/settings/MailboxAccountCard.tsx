import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ChevronDown, ChevronRight, Inbox, KeyRound, Loader2, Save, ShieldAlert, X } from "lucide-react";
import { settingsService, type MailboxAccountSettings } from "@/services/settings";
import { useAuth } from "@/context/AuthContext";
import { cn, apiErrorMessage } from "@/lib/utils";

const FOLDER_FIELDS: { key: keyof MailboxAccountSettings; label: string; hint: string }[] = [
  { key: "scan_folder", label: "Folder to scan (Landing)", hint: "Where new candidate mail is picked up" },
  { key: "folder_processing", label: "Processing folder", hint: "Mail currently being handled by a run" },
  { key: "folder_processed", label: "Processed folder", hint: "Successfully handled mail lands here" },
  { key: "folder_failed", label: "Failed folder", hint: "Mail whose files failed processing" },
  { key: "folder_non_resume", label: "Non-Resume folder", hint: "Gate-rejected mail (no resume payload)" },
];

/**
 * Mailbox page → gear drawer → Mailbox Account — the intake mailbox
 * credentials + folder routing across processing outcomes. Deliberately
 * high-friction:
 *   1. A warning popup (risk briefing) gates the section on every expand.
 *   2. Saving requires the acting System Admin to re-enter their OWN
 *      password — same pattern as the email-send switches.
 * The mailbox password is stored ENCRYPTED at rest (Fernet, server-side) and
 * never travels back to the browser — only "a password is stored".
 */
export default function MailboxAccountCard() {
  const { user } = useAuth();
  const isSysadmin = user?.role === "sysadmin";
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [warningAcked, setWarningAcked] = useState(false);
  const [form, setForm] = useState<MailboxAccountSettings | null>(null);
  const [mailboxPassword, setMailboxPassword] = useState("");
  const [reauthOpen, setReauthOpen] = useState(false);
  const [ownPassword, setOwnPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const collapse = () => {
    setOpen(false);
    setWarningAcked(false);
    setForm(null);
    setMailboxPassword("");
    setError(null);
  };

  const { data: cfg } = useQuery({
    queryKey: ["mailbox-account"],
    queryFn: async () => (await settingsService.getMailboxAccount()).data,
    enabled: open && warningAcked,
  });
  const view = form ?? cfg ?? null;

  const save = useMutation({
    mutationFn: () =>
      settingsService.saveMailboxAccount({
        email: view!.email,
        scan_folder: view!.scan_folder,
        folder_processing: view!.folder_processing,
        folder_processed: view!.folder_processed,
        folder_failed: view!.folder_failed,
        folder_non_resume: view!.folder_non_resume,
        mailbox_password: mailboxPassword || undefined,
        username: user?.email ?? "",
        password: ownPassword,
      }),
    onSuccess: ({ data }) => {
      queryClient.setQueryData(["mailbox-account"], data);
      setForm(null);
      setMailboxPassword("");
      setOwnPassword("");
      setReauthOpen(false);
      setError(null);
      setNotice("Saved — the pipeline now scans/moves using this configuration.");
      setTimeout(() => setNotice(null), 5000);
    },
    onError: (e) => {
      setReauthOpen(false);
      setOwnPassword("");
      setError(apiErrorMessage(e, "Couldn't save the mailbox configuration."));
    },
  });

  const set = (key: keyof MailboxAccountSettings, value: string) => {
    if (!view) return;
    setForm({ ...view, [key]: value });
    if (error) setError(null);
  };

  return (
    <div className="surface overflow-hidden">
      <button
        type="button"
        onClick={() => (open ? collapse() : setOpen(true))}
        className="flex w-full items-center gap-2.5 px-5 py-3 text-left transition-colors hover:bg-secondary/30"
      >
        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-teal-500/10">
          <Inbox className="h-4 w-4 text-teal-600" />
        </div>
        <div className="min-w-0 flex-1">
          <h2 className="text-sm font-semibold text-ink">Mailbox Account &amp; Folder Routing</h2>
          <p className="text-[11px] text-ink-mute">
            The inbox the pipeline scans, its credentials (encrypted), and where each outcome's mail is moved.
          </p>
        </div>
        {open ? (
          <ChevronDown className="h-4 w-4 shrink-0 text-ink-mute" />
        ) : (
          <ChevronRight className="h-4 w-4 shrink-0 text-ink-mute" />
        )}
      </button>

      {open && warningAcked && !view && (
        <div className="flex items-center gap-2 border-t border-border px-5 py-4 text-xs text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading…
        </div>
      )}

      {open && warningAcked && view && (
        <div className="space-y-3 border-t border-border px-5 py-4">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div className="space-y-1">
              <label className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                Mailbox email
              </label>
              <input
                value={view.email}
                onChange={(e) => set("email", e.target.value)}
                disabled={!isSysadmin}
                className="w-full rounded-lg border border-border bg-secondary px-2.5 py-1.5 text-xs text-foreground outline-none focus:border-primary/50 disabled:opacity-60"
              />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                Mailbox password{" "}
                <span className="normal-case tracking-normal">
                  ({view.has_password ? "stored encrypted — leave blank to keep" : "none stored yet"})
                </span>
              </label>
              <input
                type="password"
                value={mailboxPassword}
                onChange={(e) => setMailboxPassword(e.target.value)}
                placeholder={view.has_password ? "••••••••  (unchanged)" : "Enter the mailbox password"}
                disabled={!isSysadmin}
                autoComplete="new-password"
                className="w-full rounded-lg border border-border bg-secondary px-2.5 py-1.5 text-xs text-foreground outline-none focus:border-primary/50 disabled:opacity-60"
              />
            </div>
            {FOLDER_FIELDS.map((f) => (
              <div key={f.key} className="space-y-1">
                <label className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                  {f.label}
                </label>
                <input
                  value={String(view[f.key] ?? "")}
                  onChange={(e) => set(f.key, e.target.value)}
                  disabled={!isSysadmin}
                  title={f.hint}
                  className="w-full rounded-lg border border-border bg-secondary px-2.5 py-1.5 text-xs text-foreground outline-none focus:border-primary/50 disabled:opacity-60"
                />
                <p className="text-[10px] text-muted-foreground">{f.hint}</p>
              </div>
            ))}
          </div>
          <p className="text-[10px] leading-relaxed text-muted-foreground">
            The password is encrypted at rest and never shown again. Today's intake authenticates
            via the Microsoft Graph app registration — the stored password is used only where a
            basic-auth/IMAP integration is enabled — but the mailbox address and folder names here
            drive the live pipeline immediately.
            {view.updated_at &&
              ` Last saved ${new Date(view.updated_at).toLocaleString("en-IN", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })} by ${view.updated_by ?? "—"}.`}
          </p>
          {error && <p className="text-[11px] font-medium text-rose-500">{error}</p>}
          {notice && <p className="text-[11px] font-medium text-emerald-600">{notice}</p>}
          {isSysadmin ? (
            <div className="flex justify-end">
              <button
                type="button"
                onClick={() => setReauthOpen(true)}
                disabled={save.isPending}
                className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3.5 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-primary/90 disabled:opacity-40"
              >
                <Save className="h-3.5 w-3.5" /> Save configuration…
              </button>
            </div>
          ) : (
            <p className="text-[11px] font-medium text-amber-600">
              Read-only — only a System Admin (confirming their own password) can change this.
            </p>
          )}
        </div>
      )}

      {/* Step 1 — the risk briefing, re-shown on every expand of the panel. */}
      {open && !warningAcked && (
        <div
          className="fixed inset-0 z-[70] flex items-center justify-center bg-foreground/50 p-4 backdrop-blur-sm"
          onClick={collapse}
        >
          <div
            className="w-full max-w-md rounded-2xl border border-border bg-card p-5 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start gap-3">
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-rose-500/10 text-rose-600">
                <ShieldAlert className="h-4.5 w-4.5" />
              </span>
              <div className="min-w-0">
                <h3 className="text-sm font-bold text-foreground">
                  🚨 This is the pipeline's front door
                </h3>
                <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                  These settings decide <b className="text-foreground">which inbox candidate mail is
                  read from</b> and <b className="text-foreground">where every processed email is
                  moved</b>. A wrong mailbox or folder name can silently stop intake or scatter
                  candidate mail; the stored credential grants full read/move access to that inbox.
                </p>
                <ul className="mt-2 list-disc space-y-1 pl-4 text-xs text-muted-foreground">
                  <li>The password is stored <b className="text-foreground">encrypted at rest</b> and never displayed again.</li>
                  <li>Saving requires re-entering <b className="text-foreground">your own System Admin password</b>.</li>
                  <li>Every change is written to the audit ledger (who, what — never the secret).</li>
                </ul>
              </div>
            </div>
            <div className="mt-5 flex justify-end gap-2">
              <button
                type="button"
                onClick={collapse}
                className="rounded-lg border border-border px-3.5 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-secondary"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => setWarningAcked(true)}
                className="inline-flex items-center gap-1.5 rounded-lg bg-amber-500 px-3.5 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-amber-600"
              >
                <ShieldAlert className="h-3.5 w-3.5" /> I understand, continue
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Step 2 — confirm the save with the SysAdmin's own password. */}
      {reauthOpen && (
        <div
          className="fixed inset-0 z-[70] flex items-center justify-center bg-foreground/50 p-4 backdrop-blur-sm"
          onClick={() => !save.isPending && setReauthOpen(false)}
        >
          <div
            className="w-full max-w-sm rounded-2xl border border-border bg-card p-5 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-2.5">
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                <KeyRound className="h-4.5 w-4.5" />
              </span>
              <div>
                <h3 className="text-sm font-bold text-foreground">Confirm with your password</h3>
                <p className="text-[11px] text-muted-foreground">{user?.email}</p>
              </div>
              <button
                onClick={() => setReauthOpen(false)}
                className="ml-auto rounded-lg p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
                aria-label="Close"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <p className="mt-3 text-xs leading-relaxed text-muted-foreground">
              You're changing the intake mailbox configuration — re-enter your own System Admin
              password to apply it.
            </p>
            <input
              type="password"
              value={ownPassword}
              onChange={(e) => setOwnPassword(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && ownPassword && save.mutate()}
              autoFocus
              autoComplete="current-password"
              placeholder="Your password"
              className="mt-3 w-full rounded-lg border border-border bg-background px-2.5 py-1.5 text-xs text-foreground outline-none focus:border-primary/50"
            />
            <div className="mt-4 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setReauthOpen(false)}
                disabled={save.isPending}
                className="rounded-lg border border-border px-3.5 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-secondary disabled:opacity-40"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => save.mutate()}
                disabled={save.isPending || !ownPassword}
                className={cn(
                  "inline-flex items-center gap-1.5 rounded-lg bg-primary px-3.5 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-primary/90 disabled:opacity-40"
                )}
              >
                {save.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
                Confirm & save
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
