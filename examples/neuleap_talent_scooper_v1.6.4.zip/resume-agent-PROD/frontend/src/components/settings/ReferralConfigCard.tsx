import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { UserPlus, Plus, Trash2, Loader2, Save } from "lucide-react";
import { settingsService, type ReferralEntry } from "@/services/settings";
import { apiErrorMessage } from "@/lib/utils";
import CollapsibleSection from "@/components/settings/CollapsibleSection";

/**
 * Settings → Referrals — the emails and domains whose resumes are classified
 * as referrals. Each entry carries its OWN optional message; the candidate
 * page shows a "referred by" clip with that entry's message (or just
 * "Referred by <sender>" when its message is blank).
 */
export default function ReferralConfigCard() {
  return (
    <CollapsibleSection
      id="referrals"
      icon={UserPlus}
      title="Referrals"
      desc="Sender emails/domains that mark a candidate as referred — each with its own clip message"
      colSpan="lg:col-span-2"
    >
      <ReferralBody />
    </CollapsibleSection>
  );
}

function EntryTable({
  kind,
  entries,
  onChange,
}: {
  kind: "email" | "domain";
  entries: ReferralEntry[];
  onChange: (next: ReferralEntry[]) => void;
}) {
  const [newValue, setNewValue] = useState("");
  const valuePlaceholder = kind === "email" ? "jane@neuleap.ai" : "neuleap.ai";
  const add = () => {
    const v = newValue.trim().toLowerCase();
    if (v && !entries.some((e) => e.value === v))
      onChange([...entries, { value: v, message: "", subject_pattern: "" }]);
    setNewValue("");
  };
  const setField = (i: number, key: "message" | "subject_pattern", value: string) =>
    onChange(entries.map((e, idx) => (idx === i ? { ...e, [key]: value.slice(0, key === "message" ? 500 : 200) } : e)));
  const remove = (i: number) => onChange(entries.filter((_, idx) => idx !== i));

  return (
    <div className="space-y-2">
      <label className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
        Referral {kind === "email" ? "emails" : "domains"}
      </label>
      {entries.length > 0 && (
        <div className="space-y-1.5">
          {entries.map((e, i) => (
            <div key={e.value} className="rounded-lg border border-border/60 bg-secondary/20 p-2">
              <div className="flex items-center gap-2">
                <span className="w-full shrink-0 truncate rounded-md bg-primary/5 px-2 py-1 text-xs font-medium text-foreground sm:w-52" title={e.value}>
                  {e.value}
                </span>
                <input
                  value={e.message}
                  onChange={(ev) => setField(i, "message", ev.target.value)}
                  maxLength={500}
                  placeholder="Clip message for this entry (optional)"
                  className="min-w-0 flex-1 rounded-md border border-border bg-background px-2 py-1 text-xs text-foreground outline-none focus:border-primary/50"
                />
                <button
                  type="button"
                  onClick={() => remove(i)}
                  title="Remove"
                  className="shrink-0 rounded-md p-1.5 text-muted-foreground transition-colors hover:bg-secondary hover:text-rose-500"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
              <div className="mt-1.5 flex items-center gap-2 pl-1 sm:pl-0">
                <span className="w-full shrink-0 text-right text-[10px] text-muted-foreground sm:w-52">
                  Extract referrer from subject:
                </span>
                <input
                  value={e.subject_pattern}
                  onChange={(ev) => setField(i, "subject_pattern", ev.target.value)}
                  maxLength={200}
                  placeholder="e.g. Referral by <Sender>   (optional)"
                  className="min-w-0 flex-1 rounded-md border border-border bg-background px-2 py-1 text-[11px] text-foreground outline-none focus:border-primary/50"
                />
                <span className="w-7 shrink-0" />
              </div>
            </div>
          ))}
        </div>
      )}
      <div className="flex gap-2">
        <input
          value={newValue}
          onChange={(ev) => setNewValue(ev.target.value)}
          onKeyDown={(ev) => {
            if (ev.key === "Enter" || ev.key === ",") {
              ev.preventDefault();
              add();
            }
          }}
          placeholder={valuePlaceholder}
          className="flex-1 rounded-lg border border-border bg-secondary px-2.5 py-1.5 text-xs text-foreground outline-none focus:border-primary/50"
        />
        <button
          type="button"
          onClick={add}
          disabled={!newValue.trim()}
          className="inline-flex shrink-0 items-center gap-1 rounded-lg border border-border px-2.5 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-secondary disabled:opacity-40"
        >
          <Plus className="h-3.5 w-3.5" /> Add
        </button>
      </div>
    </div>
  );
}

function ReferralBody() {
  const queryClient = useQueryClient();
  const { data } = useQuery({
    queryKey: ["referral-config"],
    queryFn: async () => (await settingsService.getReferralConfig()).data,
  });
  const [emails, setEmails] = useState<ReferralEntry[]>([]);
  const [domains, setDomains] = useState<ReferralEntry[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    if (data) {
      setEmails(data.emails);
      setDomains(data.domains);
    }
  }, [data]);

  const save = useMutation({
    mutationFn: () => settingsService.saveReferralConfig({ emails, domains }),
    onSuccess: ({ data: saved }) => {
      queryClient.setQueryData(["referral-config"], saved);
      queryClient.invalidateQueries({ queryKey: ["candidate"] });
      setError(null);
      setNotice("Saved — matching candidates now show a referral clip.");
      setTimeout(() => setNotice(null), 4000);
    },
    onError: (e) => setError(apiErrorMessage(e, "Couldn't save the referral configuration.")),
  });

  return (
    <div className="space-y-4">
      <p className="text-[11px] leading-relaxed text-muted-foreground">
        A candidate is marked as a <b>referral</b> when their resume arrived from one of the sender
        emails below, or any address under one of the domains. Each entry has its <b>own clip
        message</b> and an optional <b>subject pattern</b>. An exact email match takes precedence
        over a domain match.
      </p>
      <p className="rounded-lg border border-border/60 bg-secondary/20 px-3 py-2 text-[11px] leading-relaxed text-muted-foreground">
        <b>Subject pattern</b> (optional): give the subject STYLE with a{" "}
        <code className="rounded bg-primary/10 px-1 text-foreground">&lt;Sender&gt;</code> placeholder
        — e.g. <code className="rounded bg-primary/10 px-1 text-foreground">Referral by &lt;Sender&gt;</code>{" "}
        or <code className="rounded bg-primary/10 px-1 text-foreground">&lt;Sender&gt; referred this candidate</code>.
        When a pattern is set it acts as a <b>gate</b>: emails from this sender count as a referral{" "}
        <b>only</b> when their subject matches the pattern, and the name in the{" "}
        <code className="rounded bg-primary/10 px-1 text-foreground">&lt;Sender&gt;</code> slot becomes the
        &ldquo;Referred by&rdquo; (instead of the sending email). Leave it blank to treat every email
        from this sender as a referral, using the sending address.
      </p>

      <EntryTable kind="email" entries={emails} onChange={setEmails} />
      <EntryTable kind="domain" entries={domains} onChange={setDomains} />

      {error && <p className="text-[11px] font-medium text-rose-500">{error}</p>}
      {notice && <p className="text-[11px] font-medium text-emerald-600">{notice}</p>}

      <div className="flex justify-end">
        <button
          type="button"
          onClick={() => save.mutate()}
          disabled={save.isPending}
          className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3.5 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-primary/90 disabled:opacity-40"
        >
          {save.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
          Save referrals
        </button>
      </div>
    </div>
  );
}
