import { useState, type ComponentType } from "react";
import {
  Info,
  ChevronDown,
  Package,
  Server,
  RefreshCw,
  ShieldCheck,
  CheckCircle2,
  RotateCcw,
  Database,
  HardDrive,
  Cloud,
  KeyRound,
  CalendarClock,
  DatabaseBackup,
  ArrowRight,
  Plug,
} from "lucide-react";
import { cn } from "@/lib/utils";

// Collapsible "(i) How it works" illustration embedded in the Settings cards.
// Explains the updater-sidecar upgrade flow and the backup/restore (DR) flow as
// a small node+arrow diagram, built from styled boxes (not raw SVG) so it's
// theme-aware and matches the rest of the app automatically.

type Tone = "brand" | "ok" | "danger" | "amber" | "sky" | "violet" | "muted";

const TONE: Record<Tone, string> = {
  brand: "border-primary/30 bg-primary/10 text-primary",
  ok: "border-emerald-500/30 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400",
  danger: "border-rose-500/30 bg-rose-500/10 text-rose-600 dark:text-rose-400",
  amber: "border-amber-500/30 bg-amber-500/10 text-amber-600 dark:text-amber-400",
  sky: "border-sky-500/30 bg-sky-500/10 text-sky-600 dark:text-sky-400",
  violet: "border-violet-500/30 bg-violet-500/10 text-violet-600 dark:text-violet-400",
  muted: "border-border bg-secondary/40 text-muted-foreground",
};

function Node({
  icon: Icon,
  title,
  sub,
  tone = "brand",
  className,
}: {
  icon: ComponentType<{ className?: string }>;
  title: string;
  sub?: string;
  tone?: Tone;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex min-w-[92px] max-w-[140px] flex-col items-center gap-1 rounded-lg border px-2.5 py-2 text-center",
        TONE[tone],
        className
      )}
    >
      <Icon className="h-4 w-4 shrink-0" />
      <span className="text-[10.5px] font-semibold leading-tight">{title}</span>
      {sub && <span className="text-[9px] font-normal leading-tight opacity-80">{sub}</span>}
    </div>
  );
}

function Arrow({ label }: { label?: string }) {
  return (
    <div className="flex shrink-0 flex-col items-center justify-center px-0.5 text-muted-foreground">
      <ArrowRight className="h-3.5 w-3.5" />
      {label && <span className="mt-0.5 max-w-[80px] text-center text-[8.5px] leading-tight">{label}</span>}
    </div>
  );
}

function UpgradeDiagram() {
  return (
    <div className="space-y-2.5">
      <div className="flex flex-wrap items-center justify-center gap-1.5">
        <Node icon={Package} title="Signed bundle" sub="app+frontend+config" tone="brand" />
        <Arrow label="upload / drop" />
        <Node icon={Server} title="App" sub="pre-backup + request" tone="brand" />
        <Arrow label="file handshake" />
        <Node icon={Plug} title="Updater sidecar" sub="holds Docker socket" tone="amber" />
        <Arrow label="load → compose up" />
        <Node icon={RefreshCw} title="Swap app+UI" sub="volumes preserved" tone="brand" />
        <Arrow label="verify" />
        <Node icon={ShieldCheck} title="Health + checks" tone="amber" />
      </div>
      <div className="flex flex-wrap items-center justify-center gap-1.5">
        <Node icon={CheckCircle2} title="Success" sub="new version live" tone="ok" />
        <span className="px-1 text-[9px] font-semibold uppercase text-muted-foreground">or on failure</span>
        <Node icon={RotateCcw} title="Auto-rollback" sub="retag + DB restore" tone="danger" />
      </div>
      <div className={cn("flex items-center justify-center gap-1.5 rounded-lg border px-2.5 py-1.5", TONE.muted)}>
        <Database className="h-3.5 w-3.5 shrink-0" />
        <span className="text-[9.5px] leading-tight">
          Postgres + MinIO live in <b>named volumes</b> — never dropped during the swap, so your data is safe.
        </span>
      </div>
    </div>
  );
}

function DrDiagram() {
  return (
    <div className="space-y-2.5">
      <div className="flex flex-wrap items-center justify-center gap-1.5">
        <Node icon={CalendarClock} title="Scheduler" sub="hourly incr · weekly full" tone="brand" />
        <Arrow />
        <Node icon={DatabaseBackup} title="Backup engine" sub="full = whole system" tone="brand" />
      </div>
      {/* Snapshot contents */}
      <div className="flex flex-wrap items-center justify-center gap-1.5">
        <span className="text-[9px] font-semibold uppercase text-muted-foreground">captures</span>
        <Node icon={Database} title="Database" sub="pg_dump" tone="violet" />
        <Node icon={HardDrive} title="Files" sub="MinIO raw+resume" tone="violet" />
        <Node icon={KeyRound} title="Configuration" sub="secrets/ — all settings" tone="violet" />
      </div>
      {/* Fan-out ≥2 locations */}
      <div className="flex flex-wrap items-center justify-center gap-1.5">
        <span className="text-[9px] font-semibold uppercase text-muted-foreground">copied to ≥2</span>
        <Node icon={HardDrive} title="Primary" tone="ok" />
        <Node icon={HardDrive} title="Secondary" sub="disk / NAS" tone="ok" />
        <Node icon={Cloud} title="Cloud" sub="S3 (optional)" tone="sky" />
      </div>
      {/* Restore */}
      <div className={cn("flex flex-wrap items-center justify-center gap-1.5 rounded-lg border px-2 py-2", TONE.muted)}>
        <Node icon={RotateCcw} title="Restore a set" tone="amber" />
        <Arrow label="db + files + config → live reload" />
        <Node icon={CheckCircle2} title="System recovered" sub="exact point-in-time" tone="ok" />
      </div>
    </div>
  );
}

export default function HowItWorks({ variant }: { variant: "upgrade" | "dr" }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="rounded-lg border border-border/60 bg-secondary/10">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-[11px] font-semibold text-foreground hover:bg-secondary/30"
      >
        <Info className="h-3.5 w-3.5 text-primary" />
        How it works
        <span className="text-[10px] font-normal text-muted-foreground">
          {variant === "upgrade" ? "— updater-sidecar upgrade flow" : "— backup & restore flow"}
        </span>
        <ChevronDown className={cn("ml-auto h-3.5 w-3.5 text-muted-foreground transition-transform", open && "rotate-180")} />
      </button>
      {open && (
        <div className="border-t border-border/60 p-3">
          {variant === "upgrade" ? <UpgradeDiagram /> : <DrDiagram />}
        </div>
      )}
    </div>
  );
}
