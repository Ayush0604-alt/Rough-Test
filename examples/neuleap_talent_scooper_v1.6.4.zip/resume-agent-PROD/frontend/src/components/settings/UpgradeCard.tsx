import { useEffect, useRef, useState } from "react";
import {
  Rocket,
  Upload,
  Loader2,
  CheckCircle2,
  AlertTriangle,
  Package,
  ShieldCheck,
  ShieldAlert,
  RotateCcw,
  Sparkles,
  KeyRound,
  Save,
  FolderInput,
  RefreshCw,
} from "lucide-react";
import { upgradeService, type UpgradeConfig, type UpgradeManifest, type UpgradeStatus } from "@/services/upgrade";
import { useAuth } from "@/context/AuthContext";
import { cn, apiErrorMessage } from "@/lib/utils";
import CollapsibleSection from "@/components/settings/CollapsibleSection";
import HowItWorks from "@/components/settings/HowItWorks";
import { useConfirm } from "@/components/common/ConfirmProvider";

const ACTIVE = new Set(["queued", "running"]);

export default function UpgradeCard() {
  const { user } = useAuth();
  const isSysadmin = user?.role === "sysadmin";

  return (
    <CollapsibleSection
      id="system-upgrade"
      icon={Rocket}
      title="System Upgrade"
      desc="Upload a version bundle and upgrade in place — auto pre-backup, checks, and rollback on failure (System Admin)"
      colSpan="lg:col-span-2"
    >
      {isSysadmin ? <UpgradeBody /> : (
        <p className="rounded-lg border border-border/60 bg-secondary/20 px-3 py-2 text-[11px] text-muted-foreground">
          Upgrading the system is restricted to <b>System Admin</b>.
        </p>
      )}
    </CollapsibleSection>
  );
}

function fmtBytes(n?: number) {
  if (!n) return "";
  const u = ["B", "KB", "MB", "GB"];
  const i = Math.min(u.length - 1, Math.floor(Math.log(n) / Math.log(1024)));
  return `${(n / Math.pow(1024, i)).toFixed(1)} ${u[i]}`;
}

function UpgradeBody() {
  const confirm = useConfirm();
  const fileRef = useRef<HTMLInputElement>(null);
  // Tracks the previously-observed upgrade state so the auto-reload only fires
  // on a real active→success transition, not on a stale success loaded on mount.
  const prevStateRef = useRef<string | undefined>(undefined);
  const [manifest, setManifest] = useState<UpgradeManifest | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadPct, setUploadPct] = useState(0);
  const [starting, setStarting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [status, setStatus] = useState<UpgradeStatus | null>(null);
  const [polling, setPolling] = useState(false);
  const [updaterAlive, setUpdaterAlive] = useState<boolean | null>(null);
  const [signCfg, setSignCfg] = useState<UpgradeConfig | null>(null);
  const [savingCfg, setSavingCfg] = useState(false);
  const [bundles, setBundles] = useState<UpgradeManifest[]>([]);
  const [dropFiles, setDropFiles] = useState<{ filename: string; size_bytes: number }[]>([]);
  const [loadingDrop, setLoadingDrop] = useState<string | null>(null);
  const [reloadIn, setReloadIn] = useState<number | null>(null);

  const loadBundles = () =>
    upgradeService.listBundles().then(({ data }) => setBundles(data.bundles)).catch(() => {});
  const loadDropFiles = () =>
    upgradeService.listDrop().then(({ data }) => setDropFiles(data.files)).catch(() => {});

  // Poll status whenever an upgrade is active (survives the app restart: once the
  // backend is back it serves the final state from the shared status file).
  useEffect(() => {
    if (!polling) return;
    let stop = false;
    const tick = async () => {
      try {
        const { data } = await upgradeService.status();
        if (stop) return;
        setStatus(data);
        if (!ACTIVE.has(data.state)) setPolling(false); // terminal
      } catch {
        // backend/frontend restarting mid-swap — keep trying
      }
    };
    void tick();
    const h = setInterval(tick, 3000);
    return () => { stop = true; clearInterval(h); };
  }, [polling]);

  // Resume showing an in-progress/last upgrade + updater liveness + signing config.
  useEffect(() => {
    upgradeService.status().then(({ data }) => {
      setUpdaterAlive(data.updater_alive ?? null);
      if (data.state && data.state !== "idle") {
        setStatus(data);
        if (ACTIVE.has(data.state)) setPolling(true);
      }
    }).catch(() => {});
    upgradeService.getConfig().then(({ data }) => setSignCfg(data)).catch(() => {});
    void loadBundles();
    void loadDropFiles();
  }, []);

  // After a successful upgrade the NEW frontend bundle is live on the server, but
  // this browser is still running the OLD one (APP_VERSION is baked into the JS),
  // so the sidebar version + any UI changes won't appear until a full reload.
  // Auto-reload once on success — with a short grace period + a manual button —
  // so the operator doesn't have to refresh by hand to see the new version.
  //
  // IMPORTANT: only reload on a genuine active→success TRANSITION (an upgrade we
  // were watching just finished). status.json keeps the LAST upgrade's result, so
  // a "success" loaded on mount must never trigger a reload — otherwise reopening
  // this card starts an endless refresh loop.
  useEffect(() => {
    const prev = prevStateRef.current;
    prevStateRef.current = status?.state;
    if (status?.state !== "success" || !prev || !ACTIVE.has(prev)) return;
    setReloadIn(8);
    const h = setInterval(() => {
      setReloadIn((n) => {
        if (n === null) return null;
        if (n <= 1) { clearInterval(h); window.location.reload(); return 0; }
        return n - 1;
      });
    }, 1000);
    return () => clearInterval(h);
  }, [status?.state]);

  const onLoadDrop = async (filename: string) => {
    setLoadingDrop(filename);
    setError(null);
    setManifest(null);
    try {
      const { data } = await upgradeService.loadDrop(filename);
      setManifest(data.manifest);
      void loadBundles();
    } catch (err) {
      setError(apiErrorMessage(err, "Couldn't validate the bundle from the drop folder."));
    } finally {
      setLoadingDrop(null);
    }
  };

  const saveSigning = async () => {
    if (!signCfg) return;
    setSavingCfg(true);
    setError(null);
    try {
      const { data } = await upgradeService.saveConfig(signCfg);
      setSignCfg(data);
    } catch (err) {
      setError(apiErrorMessage(err, "Couldn't save the signing config."));
    } finally {
      setSavingCfg(false);
    }
  };

  const onPick = () => fileRef.current?.click();

  const onFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    setUploadPct(0);
    setError(null);
    setManifest(null);
    try {
      const { data } = await upgradeService.uploadBundle(file, (ev) => {
        if (ev.total) setUploadPct(Math.round((ev.loaded / ev.total) * 100));
      });
      setManifest(data.manifest);
      void loadBundles();
    } catch (err) {
      setError(apiErrorMessage(err, "Couldn't upload / validate the bundle."));
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const doStart = async (bundleId: string, version: string) => {
    if (!(await confirm({
      title: `Upgrade to ${version}?`,
      message: "A full backup is taken first, then the app + frontend are swapped and verified. If anything fails it auto-rolls-back. The app (including this page) will briefly restart.",
      confirmLabel: "Upgrade",
    }))) return;
    setStarting(true);
    setError(null);
    try {
      await upgradeService.start(bundleId);
      setStatus({ state: "queued", message: "Backup taken — starting the swap…" });
      setPolling(true);
    } catch (err) {
      setError(apiErrorMessage(err, "Couldn't start the upgrade."));
    } finally {
      setStarting(false);
    }
  };

  const startUpgrade = () => manifest && doStart(manifest.bundle_id, manifest.version);

  const active = status && ACTIVE.has(status.state);
  const success = status?.state === "success";
  const rolledBack = status?.state === "rolled_back";
  const failed = status?.state === "failed";

  return (
    <div className="space-y-4">
      <HowItWorks variant="upgrade" />

      {updaterAlive === false && (
        <div className="flex items-start gap-2 rounded-lg border border-amber-500/30 bg-amber-500/5 px-3 py-2 text-[11px] text-amber-700 dark:text-amber-400">
          <ShieldAlert className="mt-0.5 h-3.5 w-3.5 shrink-0" />
          <span>
            The updater sidecar isn't running, so upgrades can't execute. It's opt-in (it holds the
            Docker socket). Start it on the host with{" "}
            <code className="rounded bg-amber-500/10 px-1">docker compose --profile updater up -d</code>.
          </span>
        </div>
      )}

      {/* Upload */}
      <div className="rounded-lg border border-dashed border-border bg-secondary/10 p-3">
        <input ref={fileRef} type="file" accept=".tar" className="hidden" onChange={onFile} />
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={onPick}
            disabled={uploading || !!active}
            className="inline-flex items-center gap-1.5 rounded-lg border border-primary/40 bg-primary/5 px-3 py-1.5 text-xs font-semibold text-primary hover:bg-primary/10 disabled:opacity-40"
          >
            {uploading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Upload className="h-3.5 w-3.5" />}
            {uploading ? `Uploading ${uploadPct}%` : "Upload version bundle (.tar)"}
          </button>
          <span className="text-[10px] text-muted-foreground">
            Build it with <code className="rounded bg-primary/10 px-1">scripts/make-bundle.sh &lt;version&gt;</code>
          </span>
        </div>

        {manifest && (
          <div className="mt-3 rounded-lg border border-border bg-card p-3">
            <div className="flex items-center gap-2">
              <Package className="h-4 w-4 text-primary" />
              <span className="text-sm font-bold text-foreground">{manifest.version}</span>
              <span className="text-[10px] text-muted-foreground">{fmtBytes(manifest.size_bytes)}</span>
              <span className="ml-auto inline-flex items-center gap-1.5">
                {manifest.signature_verified ? (
                  <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-600">
                    <ShieldCheck className="h-3 w-3" /> signature verified
                  </span>
                ) : manifest.signed ? (
                  <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-amber-600">
                    <ShieldAlert className="h-3 w-3" /> signed (no key set)
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-muted-foreground">
                    <ShieldCheck className="h-3 w-3" /> validated
                  </span>
                )}
              </span>
            </div>
            {(manifest.has_env_additions || manifest.has_compose_overlay) && (
              <div className="mt-1.5 flex flex-wrap gap-1">
                {manifest.has_env_additions && (
                  <span className="rounded-full border border-sky-500/30 bg-sky-500/10 px-2 py-0.5 text-[10px] font-medium text-sky-600">
                    + updates .env
                  </span>
                )}
                {manifest.has_compose_overlay && (
                  <span className="rounded-full border border-violet-500/30 bg-violet-500/10 px-2 py-0.5 text-[10px] font-medium text-violet-600">
                    + updates compose
                  </span>
                )}
              </div>
            )}
            {manifest.features && manifest.features.length > 0 && (
              <ul className="mt-2 space-y-1">
                {manifest.features.map((f, i) => (
                  <li key={i} className="flex items-start gap-1.5 text-[11px] text-muted-foreground">
                    <Sparkles className="mt-0.5 h-3 w-3 shrink-0 text-primary" />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
            )}
            <button
              type="button"
              onClick={startUpgrade}
              disabled={starting || !!active || updaterAlive === false}
              title={updaterAlive === false ? "Start the updater sidecar first" : "Back up + upgrade"}
              className="mt-3 inline-flex items-center gap-1.5 rounded-lg bg-primary px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-primary/90 disabled:opacity-40"
            >
              {starting ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Rocket className="h-3.5 w-3.5" />}
              Upgrade now
            </button>
          </div>
        )}
      </div>

      {/* Server drop folder — for bundles too big for a browser upload
          (Cloudflare/proxy body-size limits). Copy the .tar onto the host at
          backups/upgrade/drop/ and load it here without any HTTP upload. */}
      <div className="rounded-lg border border-border/60 bg-secondary/10 p-3">
        <div className="flex items-center gap-2">
          <FolderInput className="h-4 w-4 text-primary" />
          <span className="text-[11px] font-semibold text-foreground">Install from the server drop folder</span>
          <button
            type="button"
            onClick={loadDropFiles}
            title="Rescan the drop folder"
            className="ml-auto inline-flex items-center gap-1 rounded border border-border/60 px-1.5 py-0.5 text-[10px] font-medium text-muted-foreground hover:bg-secondary/40"
          >
            <RefreshCw className="h-3 w-3" /> Rescan
          </button>
        </div>
        <p className="mt-1 text-[10px] leading-relaxed text-muted-foreground">
          For big bundles that a browser upload can't handle (Cloudflare caps uploads at ~100 MB),
          copy the <code className="rounded bg-primary/10 px-1">.tar</code> onto the host at{" "}
          <code className="rounded bg-primary/10 px-1">backups/upgrade/drop/</code> and load it here — no upload needed.
        </p>
        {dropFiles.length > 0 ? (
          <div className="mt-2 space-y-1.5">
            {dropFiles.map((f) => (
              <div key={f.filename} className="flex items-center gap-2 rounded-lg border border-border/60 bg-card px-2.5 py-1.5 text-[11px]">
                <Package className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                <span className="min-w-0 truncate font-mono text-foreground">{f.filename}</span>
                <span className="shrink-0 text-muted-foreground">{fmtBytes(f.size_bytes)}</span>
                <button
                  type="button"
                  onClick={() => onLoadDrop(f.filename)}
                  disabled={!!loadingDrop || !!active}
                  className="ml-auto inline-flex shrink-0 items-center gap-1 rounded border border-primary/30 bg-primary/5 px-1.5 py-0.5 font-semibold text-primary hover:bg-primary/10 disabled:opacity-40"
                >
                  {loadingDrop === f.filename ? <Loader2 className="h-3 w-3 animate-spin" /> : <ShieldCheck className="h-3 w-3" />}
                  Load & validate
                </button>
              </div>
            ))}
          </div>
        ) : (
          <p className="mt-2 text-[10px] italic text-muted-foreground">No .tar files found in the drop folder.</p>
        )}
      </div>

      {/* Uploaded bundles */}
      {bundles.length > 0 && (
        <div>
          <div className="mb-1.5 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Uploaded bundles</div>
          <div className="max-h-56 space-y-1.5 overflow-auto">
            {bundles.map((b) => (
              <div key={b.bundle_id} className="flex items-center gap-2 rounded-lg border border-border/60 bg-secondary/10 px-2.5 py-1.5 text-[11px]">
                <Package className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                <span className="font-semibold text-foreground">{b.version}</span>
                <span className="text-muted-foreground">{fmtBytes(b.size_bytes)}</span>
                {b.signature_verified ? (
                  <span className="inline-flex items-center gap-0.5 text-[10px] font-semibold text-emerald-600"><ShieldCheck className="h-3 w-3" /> verified</span>
                ) : b.signed ? (
                  <span className="inline-flex items-center gap-0.5 text-[10px] font-semibold text-amber-600"><ShieldAlert className="h-3 w-3" /> signed</span>
                ) : (
                  <span className="text-[10px] text-muted-foreground">unsigned</span>
                )}
                <button
                  type="button"
                  onClick={() => doStart(b.bundle_id, b.version)}
                  disabled={starting || !!active || updaterAlive === false}
                  title={updaterAlive === false ? "Start the updater sidecar first" : "Back up + install this bundle"}
                  className="ml-auto inline-flex items-center gap-1 rounded border border-primary/30 bg-primary/5 px-1.5 py-0.5 font-semibold text-primary hover:bg-primary/10 disabled:opacity-40"
                >
                  <Rocket className="h-3 w-3" /> Install
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {error && <p className="text-[11px] font-medium text-rose-500">{error}</p>}

      {/* Progress / result */}
      {status && status.state !== "idle" && (
        <div className={cn(
          "rounded-lg border p-3",
          success ? "border-emerald-500/30 bg-emerald-500/5"
            : rolledBack || failed ? "border-amber-500/30 bg-amber-500/5"
              : "border-border bg-secondary/20"
        )}>
          <div className="flex items-center gap-2">
            {active ? <Loader2 className="h-4 w-4 animate-spin text-primary" />
              : success ? <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                : rolledBack ? <RotateCcw className="h-4 w-4 text-amber-600" />
                  : <AlertTriangle className="h-4 w-4 text-amber-600" />}
            <span className="text-xs font-semibold text-foreground">
              {success ? "Upgrade successful"
                : rolledBack ? "Upgrade failed — reverted to previous version"
                  : failed ? "Upgrade failed"
                    : `Upgrading… ${status.phase ?? ""}`}
            </span>
            {status.version && <span className="ml-1 text-[11px] text-muted-foreground">{status.version}</span>}
          </div>
          {status.message && <p className="mt-1 text-[11px] text-muted-foreground">{status.message}</p>}
          {active && (
            <p className="mt-1.5 text-[10px] text-muted-foreground">
              The app (including this page) restarts during the swap — this page keeps polling and
              updates on its own; no need to refresh. It reloads automatically once the new version is live.
            </p>
          )}
          {success && reloadIn !== null && (
            <div className="mt-2 flex flex-wrap items-center gap-2 rounded-md border border-emerald-500/30 bg-emerald-500/10 px-2.5 py-1.5">
              <RefreshCw className="h-3.5 w-3.5 shrink-0 text-emerald-600" />
              <span className="text-[11px] text-foreground">
                {reloadIn > 0
                  ? `Reloading to load the new version in ${reloadIn}s…`
                  : "Reloading…"}
              </span>
              <button
                type="button"
                onClick={() => window.location.reload()}
                className="ml-auto inline-flex items-center gap-1 rounded border border-emerald-500/40 bg-emerald-500/10 px-2 py-0.5 text-[11px] font-semibold text-emerald-700 hover:bg-emerald-500/20 dark:text-emerald-400"
              >
                <RefreshCw className="h-3 w-3" /> Reload now
              </button>
            </div>
          )}
          {success && status.features && status.features.length > 0 && (
            <details className="mt-2">
              <summary className="cursor-pointer text-[11px] font-semibold text-primary">What's new — view features</summary>
              <ul className="mt-1 space-y-1">
                {status.features.map((f, i) => (
                  <li key={i} className="flex items-start gap-1.5 text-[11px] text-muted-foreground">
                    <Sparkles className="mt-0.5 h-3 w-3 shrink-0 text-primary" />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
            </details>
          )}
          {(rolledBack || failed) && status.pre_backup_id && (
            <p className="mt-1 text-[10px] text-muted-foreground">Pre-upgrade backup: {status.pre_backup_id}</p>
          )}
        </div>
      )}

      {/* Bundle signing (trust) */}
      {signCfg && (
        <div className="space-y-2 rounded-lg border border-border/60 bg-secondary/20 p-3">
          <div className="flex items-center gap-1.5 text-[11px] font-semibold text-foreground">
            <KeyRound className="h-3.5 w-3.5 text-primary" /> Bundle signing
          </div>
          <p className="text-[10px] leading-relaxed text-muted-foreground">
            Paste the Ed25519 <b>public</b> key (from <code className="rounded bg-primary/10 px-1">scripts/keygen.sh</code>).
            Once set, only bundles signed with the matching private key
            (<code className="rounded bg-primary/10 px-1">SIGN_KEY=… scripts/make-bundle.sh</code>) will install.
          </p>
          <textarea
            value={signCfg.public_key}
            onChange={(e) => setSignCfg({ ...signCfg, public_key: e.target.value })}
            spellCheck={false}
            rows={4}
            placeholder="-----BEGIN PUBLIC KEY-----&#10;…&#10;-----END PUBLIC KEY-----"
            className="w-full resize-y rounded-md border border-border bg-background px-2 py-1 font-mono text-[10px] text-foreground outline-none focus:border-primary/50"
          />
          <div className="flex items-center justify-between gap-2">
            <label className="flex items-center gap-2 text-[11px] text-foreground">
              <input type="checkbox" checked={signCfg.require_signature}
                onChange={(e) => setSignCfg({ ...signCfg, require_signature: e.target.checked })}
                className="h-3.5 w-3.5 rounded border-border accent-primary" />
              Require a valid signature (reject unsigned bundles)
            </label>
            <button type="button" onClick={saveSigning} disabled={savingCfg}
              className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3 py-1.5 text-xs font-semibold text-white hover:bg-primary/90 disabled:opacity-40">
              {savingCfg ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />} Save
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
