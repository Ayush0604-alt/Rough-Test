import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Network, KeyRound, Loader2, Save, ShieldAlert, X } from "lucide-react";
import { settingsService, type GraphConfigSettings } from "@/services/settings";
import { useAuth } from "@/context/AuthContext";
import { cn, apiErrorMessage } from "@/lib/utils";
import CollapsibleSection from "@/components/settings/CollapsibleSection";

/**
 * Settings → Graph API — the Azure app-registration credentials (tenant id,
 * client id, client secret) the mail-intake + calendar integration authenticates
 * with. Rendered in the standard CollapsibleSection shell, next to LLM Model Keys.
 * Same high-friction posture as the Mailbox Account / LLM Keys cards:
 *   1. A risk-briefing popup gates the content on every expand.
 *   2. Saving requires the acting System Admin to re-enter their OWN password.
 * The client secret is stored ENCRYPTED at rest and never travels back.
 */
export default function GraphApiCard() {
  return (
    <CollapsibleSection
      id="graph-api"
      icon={Network}
      title="Graph API"
      desc="Microsoft Graph app credentials for mail intake + calendar — secret encrypted at rest"
      colSpan="lg:col-span-2"
    >
      <GraphApiBody />
    </CollapsibleSection>
  );
}

function GraphApiBody() {
  const { user } = useAuth();
  const isSysadmin = user?.role === "sysadmin";
  const queryClient = useQueryClient();
  const [warningAcked, setWarningAcked] = useState(false);
  const [warningDeclined, setWarningDeclined] = useState(false);
  const [form, setForm] = useState<GraphConfigSettings | null>(null);
  const [clientSecret, setClientSecret] = useState("");
  const [reauthOpen, setReauthOpen] = useState(false);
  const [ownPassword, setOwnPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const { data: cfg } = useQuery({
    queryKey: ["graph-config"],
    queryFn: async () => (await settingsService.getGraphConfig()).data,
    enabled: warningAcked,
  });
  const view = form ?? cfg ?? null;

  const save = useMutation({
    mutationFn: () =>
      settingsService.saveGraphConfig({
        tenant_id: view!.tenant_id,
        client_id: view!.client_id,
        client_secret: clientSecret || undefined,
        username: user?.email ?? "",
        password: ownPassword,
      }),
    onSuccess: ({ data }) => {
      queryClient.setQueryData(["graph-config"], data);
      setForm(null);
      setClientSecret("");
      setOwnPassword("");
      setReauthOpen(false);
      setError(null);
      setNotice("Saved — mail intake + calendar now use these credentials.");
      setTimeout(() => setNotice(null), 5000);
    },
    onError: (e) => {
      setReauthOpen(false);
      setOwnPassword("");
      setError(apiErrorMessage(e, "Couldn't save the Graph API configuration."));
    },
  });

  const set = (key: keyof GraphConfigSettings, value: string) => {
    if (!view) return;
    setForm({ ...view, [key]: value });
    if (error) setError(null);
  };

  const inputCls =
    "w-full rounded-lg border border-border bg-secondary px-2.5 py-1.5 text-xs text-foreground outline-none focus:border-primary/50 disabled:opacity-60";

  if (!warningAcked && warningDeclined) {
    return (
      <div className="flex items-center justify-between gap-3 rounded-lg border border-amber-500/30 bg-amber-400/5 px-3 py-2.5">
        <p className="text-xs text-muted-foreground">
          The Graph API configuration stays hidden until you acknowledge the risk briefing.
        </p>
        <button
          type="button"
          onClick={() => setWarningDeclined(false)}
          className="inline-flex shrink-0 items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-secondary"
        >
          <ShieldAlert className="h-3.5 w-3.5" /> Review the warning
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {warningAcked && !view && (
        <div className="flex items-center gap-2 py-2 text-xs text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading…
        </div>
      )}

      {warningAcked && view && (
        <>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div className="space-y-1">
              <label className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                Tenant ID
              </label>
              <input
                value={view.tenant_id}
                onChange={(e) => set("tenant_id", e.target.value)}
                disabled={!isSysadmin}
                placeholder={view.env_tenant_present ? "using the environment tenant" : "Azure AD tenant (directory) ID"}
                className={inputCls}
              />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                Client ID
              </label>
              <input
                value={view.client_id}
                onChange={(e) => set("client_id", e.target.value)}
                disabled={!isSysadmin}
                placeholder={view.env_client_present ? "using the environment client id" : "App registration (application) ID"}
                className={inputCls}
              />
            </div>
            <div className="space-y-1 sm:col-span-2">
              <label className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                Client secret{" "}
                <span className="normal-case tracking-normal">
                  (
                  {view.has_client_secret
                    ? "stored encrypted — blank keeps it, \"-\" clears it"
                    : view.env_secret_present
                      ? "using the environment secret — set one here to override"
                      : "none stored"}
                  )
                </span>
              </label>
              <input
                type="password"
                value={clientSecret}
                onChange={(e) => setClientSecret(e.target.value)}
                placeholder={view.has_client_secret ? "••••••••  (unchanged)" : "App registration client secret VALUE"}
                disabled={!isSysadmin}
                autoComplete="new-password"
                className={inputCls}
              />
            </div>
          </div>

          <p className="text-[10px] leading-relaxed text-muted-foreground">
            Resolution: this config → environment variables (GRAPH_TENANT_ID / GRAPH_CLIENT_ID /
            GRAPH_CLIENT_SECRET). The mailbox address is configured separately under{" "}
            <b>Mailbox Account</b>. The secret is encrypted at rest (Fernet) and never displayed
            again; every save is audit-logged without the secret. A wrong value stops mail intake
            and interview-slot scheduling — the environment variables remain the safety net.
            {view.updated_at &&
              ` Last saved ${new Date(view.updated_at).toLocaleString("en-IN", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })} by ${view.updated_by ?? "—"}.`}
          </p>
          {error && <p className="text-[11px] font-medium text-rose-500">{error}</p>}
          {notice && <p className="text-[11px] font-medium text-emerald-600">{notice}</p>}
          {isSysadmin ? (
            <div className="flex justify-end">
              <button
                type="button"
                onClick={() => setReauthOpen(true)}
                disabled={save.isPending}
                className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3.5 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-primary/90 disabled:opacity-40"
              >
                <Save className="h-3.5 w-3.5" /> Save Graph credentials…
              </button>
            </div>
          ) : (
            <p className="text-[11px] font-medium text-amber-600">
              Read-only — only a System Admin (confirming their own password) can change this.
            </p>
          )}
        </>
      )}

      {/* Step 1 — risk briefing, re-shown on every expand. */}
      {!warningAcked && !warningDeclined && (
        <div
          className="fixed inset-0 z-[70] flex items-center justify-center bg-foreground/50 p-4 backdrop-blur-sm"
          onClick={() => setWarningDeclined(true)}
        >
          <div
            className="w-full max-w-md rounded-2xl border border-border bg-card p-5 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start gap-3">
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-rose-500/10 text-rose-600">
                <ShieldAlert className="h-4.5 w-4.5" />
              </span>
              <div className="min-w-0">
                <h3 className="text-sm font-bold text-foreground">🚨 This connects the mailbox &amp; calendar</h3>
                <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                  These credentials authenticate <b className="text-foreground">resume intake from
                  the mailbox and interview-slot scheduling on interviewers' calendars</b>. A wrong
                  tenant/client/secret silently stops mail processing; a leaked secret grants access
                  to the mailbox and calendars via your Azure app.
                </p>
                <ul className="mt-2 list-disc space-y-1 pl-4 text-xs text-muted-foreground">
                  <li>The secret is stored <b className="text-foreground">encrypted at rest</b> and never displayed again.</li>
                  <li>Saving requires re-entering <b className="text-foreground">your own System Admin password</b>.</li>
                  <li>Every change is audit-logged (who, what — never the secret).</li>
                  <li>Environment variables stay as the fallback if a stored value breaks.</li>
                </ul>
              </div>
            </div>
            <div className="mt-5 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setWarningDeclined(true)}
                className="rounded-lg border border-border px-3.5 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-secondary"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => setWarningAcked(true)}
                className="inline-flex items-center gap-1.5 rounded-lg bg-amber-500 px-3.5 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-amber-600"
              >
                <ShieldAlert className="h-3.5 w-3.5" /> I understand, continue
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Step 2 — confirm the save with the SysAdmin's own password. */}
      {reauthOpen && (
        <div
          className="fixed inset-0 z-[70] flex items-center justify-center bg-foreground/50 p-4 backdrop-blur-sm"
          onClick={() => !save.isPending && setReauthOpen(false)}
        >
          <div
            className="w-full max-w-sm rounded-2xl border border-border bg-card p-5 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-2.5">
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                <KeyRound className="h-4.5 w-4.5" />
              </span>
              <div>
                <h3 className="text-sm font-bold text-foreground">Confirm with your password</h3>
                <p className="text-[11px] text-muted-foreground">{user?.email}</p>
              </div>
              <button
                onClick={() => setReauthOpen(false)}
                className="ml-auto rounded-lg p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
                aria-label="Close"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <p className="mt-3 text-xs leading-relaxed text-muted-foreground">
              You're changing the Graph API credentials — re-enter your own System Admin password to
              apply it.
            </p>
            <input
              type="password"
              value={ownPassword}
              onChange={(e) => setOwnPassword(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && ownPassword && save.mutate()}
              autoFocus
              autoComplete="current-password"
              placeholder="Your password"
              className="mt-3 w-full rounded-lg border border-border bg-background px-2.5 py-1.5 text-xs text-foreground outline-none focus:border-primary/50"
            />
            <div className="mt-4 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setReauthOpen(false)}
                disabled={save.isPending}
                className="rounded-lg border border-border px-3.5 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-secondary disabled:opacity-40"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => save.mutate()}
                disabled={save.isPending || !ownPassword}
                className={cn(
                  "inline-flex items-center gap-1.5 rounded-lg bg-primary px-3.5 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-primary/90 disabled:opacity-40"
                )}
              >
                {save.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
                Confirm &amp; save
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
