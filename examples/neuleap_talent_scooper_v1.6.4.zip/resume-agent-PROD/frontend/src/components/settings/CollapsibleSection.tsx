// Every Settings section is collapsed by default and expands on click — or
// when the top-of-page search box (Settings/index.tsx) matches it, via a
// plain DOM event (see sectionRegistry.ts) so this works regardless of which
// file actually renders the section.
import { useEffect, useRef, useState } from "react";
import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";
import { SECTION_FOCUS_EVENT } from "./sectionRegistry";

export default function CollapsibleSection({
  id,
  icon: Icon,
  title,
  desc,
  defaultOpen = false,
  colSpan,
  children,
}: {
  id: string;
  icon: React.ElementType;
  title: string;
  desc: string;
  defaultOpen?: boolean;
  colSpan?: string;
  children: React.ReactNode;
}) {
  const [open, setOpen] = useState(defaultOpen);
  const [justFocused, setJustFocused] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onFocus = (e: Event) => {
      const detail = (e as CustomEvent<string>).detail;
      if (detail !== id) return;
      setOpen(true);
      // Wait a tick for the body to render before scrolling to it.
      requestAnimationFrame(() => ref.current?.scrollIntoView({ behavior: "smooth", block: "start" }));
      setJustFocused(true);
      setTimeout(() => setJustFocused(false), 1800);
    };
    window.addEventListener(SECTION_FOCUS_EVENT, onFocus);
    return () => window.removeEventListener(SECTION_FOCUS_EVENT, onFocus);
  }, [id]);

  return (
    <div
      ref={ref}
      id={id}
      className={cn(
        "rounded-xl border bg-card transition-shadow",
        justFocused ? "border-primary/60 ring-2 ring-primary/30" : "border-border",
        colSpan
      )}
    >
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-start gap-3 p-5 text-left"
      >
        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-secondary">
          <Icon className="h-4 w-4 text-muted-foreground" />
        </div>
        <div className="min-w-0 flex-1">
          <div className="text-sm font-semibold text-foreground">{title}</div>
          <div className="text-xs text-muted-foreground">{desc}</div>
        </div>
        <ChevronDown className={cn("mt-1 h-4 w-4 shrink-0 text-muted-foreground transition-transform", open && "rotate-180")} />
      </button>
      {open && <div className="px-5 pb-5">{children}</div>}
    </div>
  );
}
