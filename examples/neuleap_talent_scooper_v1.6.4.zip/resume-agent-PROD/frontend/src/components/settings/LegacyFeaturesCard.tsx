// Settings → Legacy Features — Admin-ONLY, TEMP SECTION (see
// app/services/legacy_features_config.py's docstring). Lets an Admin flip
// individual legacy UI affordances on/off during the transition to their
// replacements, without a code deploy. Delete a flag's row here (and its
// backend entry) once the old code path itself is deleted — this section is
// not meant to accumulate permanently.
import { Archive, Loader2 } from "lucide-react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { settingsService, type LegacyFeaturesSettings } from "@/services/settings";
import CollapsibleSection from "./CollapsibleSection";
import Toggle from "@/components/common/Toggle";

// Shares the exact query key Candidate/Screening read (["legacy-features-config"])
// so a save here invalidates their cache too — without this, a toggle saved on
// this page could sit stale on those pages for up to their 5-minute staleTime.
const QUERY_KEY = ["legacy-features-config"];

export default function LegacyFeaturesCard() {
  const queryClient = useQueryClient();
  const { data: cfg } = useQuery({
    queryKey: QUERY_KEY,
    queryFn: async () => (await settingsService.getLegacyFeatures()).data,
  });
  const save = useMutation({
    mutationFn: (next: LegacyFeaturesSettings) => settingsService.saveLegacyFeatures(next),
    onSuccess: ({ data }) => {
      queryClient.setQueryData(QUERY_KEY, data);
      queryClient.invalidateQueries({ queryKey: QUERY_KEY });
    },
  });

  if (!cfg) return null;

  return (
    <CollapsibleSection
      id="legacy-features"
      icon={Archive}
      title="Legacy Features [temp — will be removed]"
      desc="Toggle old UI affordances on/off while their replacements roll out"
      colSpan="lg:col-span-2"
    >
      <div className="flex items-center justify-between gap-3 py-1.5">
        <div className="min-w-0">
          <div className="text-xs font-medium text-foreground">"Interview Round" button</div>
          <div className="text-[11px] text-muted-foreground">
            The manual button (Candidate page + Screening table) that opens the standalone
            round-management page — superseded by interviewer timeslot pools + candidate
            self-serve booking. Off hides the button; the page itself still works if linked
            directly.
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          {save.isPending && <Loader2 className="h-3.5 w-3.5 animate-spin text-muted-foreground" />}
          <Toggle
            value={cfg.interview_round_button}
            onChange={(v) => save.mutate({ ...cfg, interview_round_button: v })}
            disabled={save.isPending}
          />
        </div>
      </div>
      <div className="flex items-center justify-between gap-3 border-t border-border/40 py-1.5">
        <div className="min-w-0">
          <div className="text-xs font-medium text-foreground">"Get slot link" button (external API)</div>
          <div className="text-[11px] text-muted-foreground">
            The email-draft button that calls the external scheduling API (Settings →
            Interview Slot Picker) — superseded by the native pool slot-picker link on the
            same draft. Off hides the button.
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          {save.isPending && <Loader2 className="h-3.5 w-3.5 animate-spin text-muted-foreground" />}
          <Toggle
            value={cfg.external_slot_link_button}
            onChange={(v) => save.mutate({ ...cfg, external_slot_link_button: v })}
            disabled={save.isPending}
          />
        </div>
      </div>
      <div className="flex items-center justify-between gap-3 border-t border-border/40 py-1.5">
        <div className="min-w-0">
          <div className="text-xs font-medium text-foreground">"Enrich" button (Question Banks)</div>
          <div className="text-[11px] text-muted-foreground">
            The per-bank AI backfill that adds hints, a scoring rubric, and an explanation to
            questions that lack them. Newly generated banks already include these, so it's only
            needed for older banks. Off hides the button.
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          {save.isPending && <Loader2 className="h-3.5 w-3.5 animate-spin text-muted-foreground" />}
          <Toggle
            value={cfg.qb_enrich_button}
            onChange={(v) => save.mutate({ ...cfg, qb_enrich_button: v })}
            disabled={save.isPending}
          />
        </div>
      </div>
      <div className="flex items-center justify-between gap-3 border-t border-border/40 py-1.5">
        <div className="min-w-0">
          <div className="text-xs font-medium text-foreground">"Duplicate" button (Question Banks)</div>
          <div className="text-[11px] text-muted-foreground">
            The per-bank "Duplicate" that copies a bank as its next version — superseded by
            Customize (which loads a bank verbatim, with its settings, and saves as a new
            version). Off hides the button.
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          {save.isPending && <Loader2 className="h-3.5 w-3.5 animate-spin text-muted-foreground" />}
          <Toggle
            value={cfg.qb_duplicate_button}
            onChange={(v) => save.mutate({ ...cfg, qb_duplicate_button: v })}
            disabled={save.isPending}
          />
        </div>
      </div>
      <div className="flex items-center justify-between gap-3 border-t border-border/40 py-1.5">
        <div className="min-w-0">
          <div className="text-xs font-medium text-foreground">"ATS" score column (dashboard tables)</div>
          <div className="text-[11px] text-muted-foreground">
            Shows the raw ATS score column on the dashboard candidate tables. Off hides it —
            ranking is driven by NLRS regardless (candidates always sort highest-NLRS-first).
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          {save.isPending && <Loader2 className="h-3.5 w-3.5 animate-spin text-muted-foreground" />}
          <Toggle
            value={cfg.ats_column}
            onChange={(v) => save.mutate({ ...cfg, ats_column: v })}
            disabled={save.isPending}
          />
        </div>
      </div>
      <div className="flex items-center justify-between gap-3 border-t border-border/40 py-1.5">
        <div className="min-w-0">
          <div className="text-xs font-medium text-foreground">"NLRS" score column (dashboard tables)</div>
          <div className="text-[11px] text-muted-foreground">
            Shows the raw NLRS score column on the dashboard candidate tables. Off hides it —
            candidates are still ranked highest-NLRS-first, the column just isn't displayed.
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          {save.isPending && <Loader2 className="h-3.5 w-3.5 animate-spin text-muted-foreground" />}
          <Toggle
            value={cfg.nlrs_column}
            onChange={(v) => save.mutate({ ...cfg, nlrs_column: v })}
            disabled={save.isPending}
          />
        </div>
      </div>
      <div className="flex items-center justify-between gap-3 border-t border-border/40 py-1.5">
        <div className="min-w-0">
          <div className="text-xs font-medium text-foreground">
            "Predicted NBA" status line (dashboard tables)
          </div>
          <div className="text-[11px] text-muted-foreground">
            The "Predicted / Applied / Overridden: …" line under the Report button on the
            dashboard candidate tables. Off hides it — the prediction is still shown (and
            appliable) inside the Report popover, and the row's Undecided button still works.
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          {save.isPending && <Loader2 className="h-3.5 w-3.5 animate-spin text-muted-foreground" />}
          <Toggle
            value={cfg.predicted_nba_status}
            onChange={(v) => save.mutate({ ...cfg, predicted_nba_status: v })}
            disabled={save.isPending}
          />
        </div>
      </div>
    </CollapsibleSection>
  );
}
