import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  BrainCircuit,
  ChevronDown,
  ChevronRight,
  KeyRound,
  Loader2,
  Save,
  ShieldAlert,
  X,
} from "lucide-react";
import { settingsService, type LlmConfigSettings } from "@/services/settings";
import { useAuth } from "@/context/AuthContext";
import { cn, apiErrorMessage } from "@/lib/utils";
import CollapsibleSection from "@/components/settings/CollapsibleSection";

// Human labels for the ledger/config module keys — same taxonomy as the
// Token Usage page, so key routing and cost attribution line up 1:1.
const MODULE_LABEL: Record<string, string> = {
  extraction: "Resume extraction + ATS",
  analysis_report: "Analysis report",
  timeline: "Career timeline",
  interview_questions: "Interview questions",
  jd_match: "JD match (batch scoring)",
  jd_match_explain: "JD match — score explanations",
  chatbot_sql: "Chatbot — query building",
  chatbot_narration: "Chatbot — answer narration",
};

type ModuleDraft = { endpoint: string; deployment: string; api_key: string };

/**
 * Settings → LLM Model Keys — the Azure OpenAI connection every LLM feature
 * uses (endpoint, API key, deployments) plus optional PER-MODULE overrides so
 * e.g. the chatbot can run on a cheaper deployment/key than extraction.
 * Rendered in the SAME CollapsibleSection shell as every other settings tile
 * (registered in sectionRegistry as "llm-model-keys" for the type-ahead).
 * Same high-friction posture as the Mailbox Account card:
 *   1. A risk-briefing popup gates the content on every expand (the body
 *      unmounts on collapse, so the acknowledgement never persists).
 *   2. Saving requires the acting System Admin to re-enter their OWN password.
 * Keys are stored ENCRYPTED at rest and never travel back to the browser.
 */
export default function LlmKeysCard() {
  return (
    <CollapsibleSection
      id="llm-model-keys"
      icon={BrainCircuit}
      title="LLM Model Keys"
      desc="The AI provider connection every LLM feature uses — keys encrypted at rest, with optional per-module deployments/keys"
      colSpan="lg:col-span-2"
    >
      <LlmKeysBody />
    </CollapsibleSection>
  );
}

function LlmKeysBody() {
  const { user } = useAuth();
  const isSysadmin = user?.role === "sysadmin";
  const queryClient = useQueryClient();
  // false on every mount — CollapsibleSection unmounts this body on collapse,
  // so the risk briefing re-gates every expand, same as the Mailbox card.
  const [warningAcked, setWarningAcked] = useState(false);
  const [warningDeclined, setWarningDeclined] = useState(false);
  const [form, setForm] = useState<LlmConfigSettings | null>(null);
  const [apiKey, setApiKey] = useState("");
  const [moduleDrafts, setModuleDrafts] = useState<Record<string, ModuleDraft>>({});
  const [expandedModule, setExpandedModule] = useState<string | null>(null);
  const [reauthOpen, setReauthOpen] = useState(false);
  const [ownPassword, setOwnPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const { data: cfg } = useQuery({
    queryKey: ["llm-config"],
    queryFn: async () => (await settingsService.getLlmConfig()).data,
    enabled: warningAcked,
  });
  const view = form ?? cfg ?? null;

  const draftFor = (m: string): ModuleDraft =>
    moduleDrafts[m] ?? {
      endpoint: view?.modules[m]?.endpoint ?? "",
      deployment: view?.modules[m]?.deployment ?? "",
      api_key: "",
    };

  const save = useMutation({
    mutationFn: () => {
      const modules: Record<string, ModuleDraft> = {};
      for (const m of view!.module_names) modules[m] = draftFor(m);
      return settingsService.saveLlmConfig({
        endpoint: view!.endpoint,
        api_key: apiKey || undefined,
        api_version: view!.api_version,
        deployment: view!.deployment,
        fallback_deployment: view!.fallback_deployment,
        modules,
        username: user?.email ?? "",
        password: ownPassword,
      });
    },
    onSuccess: ({ data }) => {
      queryClient.setQueryData(["llm-config"], data);
      setForm(null);
      setApiKey("");
      setModuleDrafts({});
      setOwnPassword("");
      setReauthOpen(false);
      setError(null);
      setNotice("Saved — the next LLM call in each module picks this up immediately.");
      setTimeout(() => setNotice(null), 5000);
    },
    onError: (e) => {
      setReauthOpen(false);
      setOwnPassword("");
      setError(apiErrorMessage(e, "Couldn't save the LLM key configuration."));
    },
  });

  const set = (key: keyof LlmConfigSettings, value: string) => {
    if (!view) return;
    setForm({ ...view, [key]: value });
    if (error) setError(null);
  };
  const setModule = (m: string, key: keyof ModuleDraft, value: string) => {
    setModuleDrafts((d) => ({ ...d, [m]: { ...draftFor(m), [key]: value } }));
    if (error) setError(null);
  };

  const inputCls =
    "w-full rounded-lg border border-border bg-secondary px-2.5 py-1.5 text-xs text-foreground outline-none focus:border-primary/50 disabled:opacity-60";

  // Declined the briefing — a quiet inline gate instead of the form.
  if (!warningAcked && warningDeclined) {
    return (
      <div className="flex items-center justify-between gap-3 rounded-lg border border-amber-500/30 bg-amber-400/5 px-3 py-2.5">
        <p className="text-xs text-muted-foreground">
          The LLM key configuration stays hidden until you acknowledge the risk briefing.
        </p>
        <button
          type="button"
          onClick={() => setWarningDeclined(false)}
          className="inline-flex shrink-0 items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-secondary"
        >
          <ShieldAlert className="h-3.5 w-3.5" /> Review the warning
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {warningAcked && !view && (
        <div className="flex items-center gap-2 py-2 text-xs text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading…
        </div>
      )}

      {warningAcked && view && (
        <>
          {/* Global connection */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div className="space-y-1 sm:col-span-2">
              <label className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                Azure OpenAI endpoint
              </label>
              <input
                value={view.endpoint}
                onChange={(e) => set("endpoint", e.target.value)}
                disabled={!isSysadmin}
                placeholder="https://<resource>.openai.azure.com"
                className={inputCls}
              />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                API key{" "}
                <span className="normal-case tracking-normal">
                  (
                  {view.has_api_key
                    ? "stored encrypted — blank keeps it, \"-\" clears it"
                    : view.env_key_present
                      ? "using the environment key — set one here to override"
                      : "none stored"}
                  )
                </span>
              </label>
              <input
                type="password"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder={view.has_api_key ? "••••••••  (unchanged)" : "Enter the API key"}
                disabled={!isSysadmin}
                autoComplete="new-password"
                className={inputCls}
              />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                API version
              </label>
              <input
                value={view.api_version}
                onChange={(e) => set("api_version", e.target.value)}
                disabled={!isSysadmin}
                placeholder="2025-01-01-preview"
                className={inputCls}
              />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                Default deployment (model)
              </label>
              <input
                value={view.deployment}
                onChange={(e) => set("deployment", e.target.value)}
                disabled={!isSysadmin}
                placeholder="gpt-4.1"
                className={inputCls}
              />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                Fallback deployment
              </label>
              <input
                value={view.fallback_deployment}
                onChange={(e) => set("fallback_deployment", e.target.value)}
                disabled={!isSysadmin}
                placeholder="Used when the primary deployment 404s"
                className={inputCls}
              />
            </div>
          </div>

          {/* Per-module overrides */}
          <div>
            <h3 className="mb-1 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
              Per-module overrides — optional
            </h3>
            <p className="mb-2 text-[10px] leading-relaxed text-muted-foreground">
              Give a module its own deployment, endpoint or key (e.g. run the chatbot on a cheaper
              model than extraction). Blank fields inherit the global connection above. Modules
              match the Token Usage page 1:1, so spend per key is directly visible there.
            </p>
            <div className="space-y-1.5">
              {view.module_names.map((m) => {
                const ov = view.modules[m];
                const d = draftFor(m);
                const active = !!(ov?.deployment || ov?.endpoint || ov?.has_api_key || d.deployment || d.endpoint || d.api_key);
                const expanded = expandedModule === m;
                return (
                  <div key={m} className={cn("rounded-lg border", active ? "border-violet-500/40 bg-violet-500/5" : "border-border/60")}>
                    <button
                      type="button"
                      onClick={() => setExpandedModule(expanded ? null : m)}
                      className="flex w-full items-center justify-between gap-2 px-3 py-2 text-left"
                    >
                      <span className="text-xs font-medium text-foreground">{MODULE_LABEL[m] ?? m}</span>
                      <span className="flex items-center gap-2">
                        {active && (
                          <span className="rounded-full bg-violet-500/15 px-2 py-0.5 text-[9px] font-bold text-violet-600">
                            override{ov?.has_api_key ? " · own key" : ""}
                          </span>
                        )}
                        {expanded ? (
                          <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
                        ) : (
                          <ChevronRight className="h-3.5 w-3.5 text-muted-foreground" />
                        )}
                      </span>
                    </button>
                    {expanded && (
                      <div className="grid grid-cols-1 gap-2 border-t border-border/50 px-3 py-2.5 sm:grid-cols-3">
                        <div className="space-y-1">
                          <label className="text-[9px] font-semibold uppercase tracking-wide text-muted-foreground">Deployment</label>
                          <input
                            value={d.deployment}
                            onChange={(e) => setModule(m, "deployment", e.target.value)}
                            disabled={!isSysadmin}
                            placeholder="inherit global"
                            className={inputCls}
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[9px] font-semibold uppercase tracking-wide text-muted-foreground">Endpoint</label>
                          <input
                            value={d.endpoint}
                            onChange={(e) => setModule(m, "endpoint", e.target.value)}
                            disabled={!isSysadmin}
                            placeholder="inherit global"
                            className={inputCls}
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[9px] font-semibold uppercase tracking-wide text-muted-foreground">
                            API key{" "}
                            <span className="normal-case tracking-normal">
                              ({ov?.has_api_key ? "stored — blank keeps, \"-\" clears" : "inherits global"})
                            </span>
                          </label>
                          <input
                            type="password"
                            value={d.api_key}
                            onChange={(e) => setModule(m, "api_key", e.target.value)}
                            disabled={!isSysadmin}
                            autoComplete="new-password"
                            placeholder={ov?.has_api_key ? "••••••••  (unchanged)" : "inherit global"}
                            className={inputCls}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          <p className="text-[10px] leading-relaxed text-muted-foreground">
            Resolution per call: module override → this global config → environment variables.
            Keys are encrypted at rest (Fernet) and never displayed again; every save is
            audit-logged without the secret. A broken value here can stop extraction, JD matching
            and the chatbot — the environment variables remain the safety net.
            {view.updated_at &&
              ` Last saved ${new Date(view.updated_at).toLocaleString("en-IN", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })} by ${view.updated_by ?? "—"}.`}
          </p>
          {error && <p className="text-[11px] font-medium text-rose-500">{error}</p>}
          {notice && <p className="text-[11px] font-medium text-emerald-600">{notice}</p>}
          {isSysadmin ? (
            <div className="flex justify-end">
              <button
                type="button"
                onClick={() => setReauthOpen(true)}
                disabled={save.isPending}
                className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3.5 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-primary/90 disabled:opacity-40"
              >
                <Save className="h-3.5 w-3.5" /> Save LLM keys…
              </button>
            </div>
          ) : (
            <p className="text-[11px] font-medium text-amber-600">
              Read-only — only a System Admin (confirming their own password) can change this.
            </p>
          )}
        </>
      )}

      {/* Step 1 — risk briefing, re-shown on every expand (body remounts). */}
      {!warningAcked && !warningDeclined && (
        <div
          className="fixed inset-0 z-[70] flex items-center justify-center bg-foreground/50 p-4 backdrop-blur-sm"
          onClick={() => setWarningDeclined(true)}
        >
          <div
            className="w-full max-w-md rounded-2xl border border-border bg-card p-5 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start gap-3">
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-rose-500/10 text-rose-600">
                <ShieldAlert className="h-4.5 w-4.5" />
              </span>
              <div className="min-w-0">
                <h3 className="text-sm font-bold text-foreground">🚨 These keys power every AI feature</h3>
                <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                  This connection drives <b className="text-foreground">resume extraction, ATS scoring,
                  analysis reports, interview questions, JD matching and the chatbot</b>. A wrong
                  endpoint/key silently stops all of them; a leaked key lets anyone spend on your
                  Azure OpenAI account.
                </p>
                <ul className="mt-2 list-disc space-y-1 pl-4 text-xs text-muted-foreground">
                  <li>Keys are stored <b className="text-foreground">encrypted at rest</b> and never displayed again.</li>
                  <li>Saving requires re-entering <b className="text-foreground">your own System Admin password</b>.</li>
                  <li>Every change is audit-logged (who, what — never the secret).</li>
                  <li>Environment variables stay as the fallback if a stored value breaks.</li>
                </ul>
              </div>
            </div>
            <div className="mt-5 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setWarningDeclined(true)}
                className="rounded-lg border border-border px-3.5 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-secondary"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => setWarningAcked(true)}
                className="inline-flex items-center gap-1.5 rounded-lg bg-amber-500 px-3.5 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-amber-600"
              >
                <ShieldAlert className="h-3.5 w-3.5" /> I understand, continue
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Step 2 — confirm the save with the SysAdmin's own password. */}
      {reauthOpen && (
        <div
          className="fixed inset-0 z-[70] flex items-center justify-center bg-foreground/50 p-4 backdrop-blur-sm"
          onClick={() => !save.isPending && setReauthOpen(false)}
        >
          <div
            className="w-full max-w-sm rounded-2xl border border-border bg-card p-5 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-2.5">
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                <KeyRound className="h-4.5 w-4.5" />
              </span>
              <div>
                <h3 className="text-sm font-bold text-foreground">Confirm with your password</h3>
                <p className="text-[11px] text-muted-foreground">{user?.email}</p>
              </div>
              <button
                onClick={() => setReauthOpen(false)}
                className="ml-auto rounded-lg p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
                aria-label="Close"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <p className="mt-3 text-xs leading-relaxed text-muted-foreground">
              You're changing the LLM provider keys — re-enter your own System Admin password to
              apply it.
            </p>
            <input
              type="password"
              value={ownPassword}
              onChange={(e) => setOwnPassword(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && ownPassword && save.mutate()}
              autoFocus
              autoComplete="current-password"
              placeholder="Your password"
              className="mt-3 w-full rounded-lg border border-border bg-background px-2.5 py-1.5 text-xs text-foreground outline-none focus:border-primary/50"
            />
            <div className="mt-4 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setReauthOpen(false)}
                disabled={save.isPending}
                className="rounded-lg border border-border px-3.5 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-secondary disabled:opacity-40"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => save.mutate()}
                disabled={save.isPending || !ownPassword}
                className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3.5 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-primary/90 disabled:opacity-40"
              >
                {save.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
                Confirm &amp; save
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
