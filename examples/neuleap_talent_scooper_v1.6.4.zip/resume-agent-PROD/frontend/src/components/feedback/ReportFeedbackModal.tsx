import { useState } from "react";
import { Bug, Check, Lightbulb, Loader2, X } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import {
  feedbackService,
  type FeedbackKind,
  type FeedbackMoscow,
  type FeedbackPriority,
} from "@/services/feedback";
import { apiErrorMessage } from "@/lib/utils";
import { cn } from "@/lib/utils";

const PRIORITIES: { value: FeedbackPriority; label: string }[] = [
  { value: "P1", label: "P1 — Critical / blocking" },
  { value: "P2", label: "P2 — High" },
  { value: "P3", label: "P3 — Medium" },
  { value: "P4", label: "P4 — Low" },
  { value: "P5", label: "P5 — Nice to have" },
];

// MoSCoW requirement classification — how essential this is, complementing the
// P1–P5 urgency above.
const MOSCOW: { value: FeedbackMoscow; label: string }[] = [
  { value: "must", label: "Must have" },
  { value: "should", label: "Should have" },
  { value: "could", label: "Could have" },
  { value: "wont", label: "Won't have (this time)" },
];

export default function ReportFeedbackModal({ onClose }: { onClose: () => void }) {
  const { user } = useAuth();
  const [kind, setKind] = useState<FeedbackKind>("bug");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [priority, setPriority] = useState<FeedbackPriority>("P3");
  const [moscow, setMoscow] = useState<FeedbackMoscow>("should");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  const submit = async () => {
    if (title.trim().length < 3) {
      setError("Please give it a short title (at least 3 characters).");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      await feedbackService.submit({ kind, title: title.trim(), description: description.trim(), priority, moscow });
      setDone(true);
    } catch (e) {
      setError(apiErrorMessage(e, "Couldn't submit — try again."));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center bg-black/40 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="surface-float w-full max-w-md p-5"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-sm font-semibold text-ink">Report a bug or request a feature</h2>
          <button
            onClick={onClose}
            className="rounded-lg p-1 text-ink-mute transition-colors hover:bg-secondary hover:text-ink"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {done ? (
          <div className="flex flex-col items-center gap-3 py-6 text-center">
            <Check className="h-10 w-10 text-emerald-500" />
            <p className="text-sm text-ink">Thanks! Your {kind === "bug" ? "report" : "request"} was submitted.</p>
            <button onClick={onClose} className="btn-brand mt-1">
              Done
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {/* Bug vs feature */}
            <div className="grid grid-cols-2 gap-2">
              {(
                [
                  { k: "bug" as const, label: "Bug", icon: Bug },
                  { k: "feature" as const, label: "Feature request", icon: Lightbulb },
                ]
              ).map(({ k, label, icon: Icon }) => (
                <button
                  key={k}
                  type="button"
                  onClick={() => setKind(k)}
                  className={cn(
                    "flex items-center justify-center gap-1.5 rounded-lg border px-3 py-2 text-xs font-medium transition-colors",
                    kind === k
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-border text-ink-mute hover:border-primary/40 hover:text-ink"
                  )}
                >
                  <Icon className="h-3.5 w-3.5" /> {label}
                </button>
              ))}
            </div>

            <div className="space-y-1">
              <label className="text-xs font-medium text-ink-mute">Title</label>
              <input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder={kind === "bug" ? "What went wrong, in a line" : "The feature you'd like, in a line"}
                className="w-full rounded-lg border border-border bg-secondary/40 px-2.5 py-1.5 text-sm text-ink outline-none focus:border-primary/50"
                maxLength={200}
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-medium text-ink-mute">Details</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={4}
                placeholder={
                  kind === "bug"
                    ? "Steps to reproduce, what you expected, what happened…"
                    : "What problem it solves, how it should work…"
                }
                className="w-full resize-y rounded-lg border border-border bg-secondary/40 px-2.5 py-1.5 text-sm text-ink outline-none focus:border-primary/50"
                maxLength={5000}
              />
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="space-y-1">
                <label className="text-xs font-medium text-ink-mute">Priority (urgency)</label>
                <select
                  value={priority}
                  onChange={(e) => setPriority(e.target.value as FeedbackPriority)}
                  className="w-full rounded-lg border border-border bg-secondary/40 px-2.5 py-1.5 text-sm text-ink outline-none focus:border-primary/50"
                >
                  {PRIORITIES.map((p) => (
                    <option key={p.value} value={p.value}>{p.label}</option>
                  ))}
                </select>
              </div>
              <div className="space-y-1">
                <label className="text-xs font-medium text-ink-mute">MoSCoW (importance)</label>
                <select
                  value={moscow}
                  onChange={(e) => setMoscow(e.target.value as FeedbackMoscow)}
                  className="w-full rounded-lg border border-border bg-secondary/40 px-2.5 py-1.5 text-sm text-ink outline-none focus:border-primary/50"
                >
                  {MOSCOW.map((m) => (
                    <option key={m.value} value={m.value}>{m.label}</option>
                  ))}
                </select>
              </div>
            </div>

            <p className="text-[11px] text-ink-mute">
              Submitting as <span className="font-medium text-ink">{user?.email}</span> — the team will see who reported it.
            </p>

            {error && (
              <p className="rounded-lg bg-red-500/10 px-3 py-2 text-xs font-medium text-red-600 dark:text-red-400">
                {error}
              </p>
            )}

            <div className="flex justify-end gap-2 pt-1">
              <button
                onClick={onClose}
                className="rounded-lg border border-border px-3 py-1.5 text-xs font-medium text-ink-mute hover:text-ink"
              >
                Cancel
              </button>
              <button onClick={submit} disabled={busy} className="btn-brand disabled:opacity-50">
                {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Submit"}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
