import { useState } from "react";
import { KeyRound, Loader2, X } from "lucide-react";
import { authService } from "@/services/auth";
import { useAuth } from "@/context/AuthContext";
import { cn, apiErrorMessage } from "@/lib/utils";

/**
 * Change-password dialog, used two ways:
 *  - From the profile menu ("Change password") — dismissible.
 *  - As the FORCED first-login / post-admin-reset gate (`forced`) — rendered
 *    over the whole app with no close/escape until the change succeeds, since
 *    the current password is a handover credential, not the user's own secret.
 */
export default function ChangePasswordModal({
  forced = false,
  onClose,
}: {
  forced?: boolean;
  onClose: () => void;
}) {
  const { user, markPasswordChanged } = useAuth();
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const mismatch = confirm !== "" && next !== confirm;
  const tooShort = next !== "" && next.length < 6;
  const canSave = !!current && next.length >= 6 && next === confirm && !busy;

  const submit = async () => {
    if (!canSave) return;
    setBusy(true);
    setError(null);
    try {
      await authService.changePassword(current, next);
      markPasswordChanged();
      onClose();
    } catch (e: unknown) {
      setError(apiErrorMessage(e, "Couldn't change the password — try again."));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-[70] flex items-center justify-center bg-foreground/50 p-4 backdrop-blur-sm"
      onClick={() => !forced && !busy && onClose()}
    >
      <div
        className="w-full max-w-sm rounded-2xl border border-border bg-card p-5 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
              <KeyRound className="h-4.5 w-4.5" />
            </span>
            <div>
              <h2 className="text-sm font-bold text-foreground">
                {forced ? "Set your own password" : "Change password"}
              </h2>
              <p className="text-[11px] text-muted-foreground">{user?.email}</p>
            </div>
          </div>
          {!forced && (
            <button
              onClick={onClose}
              className="rounded-lg p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
              aria-label="Close"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        {forced && (
          <p className="mt-3 rounded-lg border border-amber-500/30 bg-amber-400/10 px-3 py-2 text-[11px] leading-relaxed text-amber-700 dark:text-amber-400">
            Your password was set for you (first login or an admin reset) — please choose your own
            before continuing.
          </p>
        )}

        <div className="mt-4 space-y-3">
          <div className="space-y-1">
            <label className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
              Current password
            </label>
            <input
              type="password"
              value={current}
              onChange={(e) => setCurrent(e.target.value)}
              autoFocus
              autoComplete="current-password"
              className="w-full rounded-lg border border-border bg-background px-2.5 py-1.5 text-xs text-foreground outline-none focus:border-primary/50"
            />
          </div>
          <div className="space-y-1">
            <label className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
              New password
            </label>
            <input
              type="password"
              value={next}
              onChange={(e) => setNext(e.target.value)}
              autoComplete="new-password"
              className={cn(
                "w-full rounded-lg border bg-background px-2.5 py-1.5 text-xs text-foreground outline-none focus:border-primary/50",
                tooShort ? "border-destructive/60" : "border-border"
              )}
            />
            {tooShort && <p className="text-[10px] text-destructive">At least 6 characters.</p>}
          </div>
          <div className="space-y-1">
            <label className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
              Confirm new password
            </label>
            <input
              type="password"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              autoComplete="new-password"
              onKeyDown={(e) => e.key === "Enter" && submit()}
              className={cn(
                "w-full rounded-lg border bg-background px-2.5 py-1.5 text-xs text-foreground outline-none focus:border-primary/50",
                mismatch ? "border-destructive/60" : "border-border"
              )}
            />
            {mismatch && <p className="text-[10px] text-destructive">Passwords don't match.</p>}
          </div>
        </div>

        {error && <p className="mt-3 text-[11px] font-medium text-rose-500">{error}</p>}

        <div className="mt-5 flex justify-end gap-2">
          {!forced && (
            <button
              type="button"
              onClick={onClose}
              disabled={busy}
              className="rounded-lg border border-border px-3.5 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-secondary disabled:opacity-40"
            >
              Cancel
            </button>
          )}
          <button
            type="button"
            onClick={submit}
            disabled={!canSave}
            className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3.5 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-primary/90 disabled:opacity-40"
          >
            {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <KeyRound className="h-3.5 w-3.5" />}
            {forced ? "Save & continue" : "Change password"}
          </button>
        </div>
      </div>
    </div>
  );
}
