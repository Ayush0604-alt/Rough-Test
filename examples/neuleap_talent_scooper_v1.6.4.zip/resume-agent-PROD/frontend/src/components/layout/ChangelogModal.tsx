// "What's in this build" popup — opened by clicking the Version pill in the
// Sidebar footer (QA env only; the pill is a plain label elsewhere). Shows the
// current build's changelog (new features / bug fixes / changes to watch out
// for) with a "More" reveal for every previous version's entry.
import { useState } from "react";
import { X, Rocket, Bug, AlertTriangle, History, ChevronDown, ChevronUp } from "lucide-react";
import { APP_VERSION } from "@/config/version";
import { CHANGELOG, type ChangelogEntry } from "@/config/changelog";

function Section({
  icon,
  title,
  tone,
  items,
}: {
  icon: React.ReactNode;
  title: string;
  tone: string;
  items: string[];
}) {
  if (items.length === 0) return null;
  return (
    <div>
      <div className={`mb-1 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wide ${tone}`}>
        {icon}
        {title}
      </div>
      <ul className="space-y-1 pl-1">
        {items.map((it, i) => (
          <li key={i} className="flex gap-1.5 text-[11px] leading-relaxed text-foreground">
            <span className="mt-[7px] h-1 w-1 shrink-0 rounded-full bg-muted-foreground/50" />
            <span>{it}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function EntryBlock({ entry, headline }: { entry: ChangelogEntry; headline?: string }) {
  return (
    <div className="space-y-3 rounded-2xl border border-border/50 bg-card/40 px-4 py-3.5 backdrop-blur-md dark:bg-card/30">
      <div className="flex items-baseline justify-between gap-2">
        <span className="text-xs font-bold text-foreground">{headline ?? entry.version}</span>
        <span className="text-[10px] text-muted-foreground">{entry.date}</span>
      </div>
      <Section
        icon={<Rocket className="h-3 w-3" />}
        title="New features"
        tone="text-emerald-600"
        items={entry.features}
      />
      <Section icon={<Bug className="h-3 w-3" />} title="Bug fixes" tone="text-sky-600" items={entry.fixes} />
      <Section
        icon={<AlertTriangle className="h-3 w-3" />}
        title="Changes to watch out for"
        tone="text-amber-600"
        items={entry.watch}
      />
    </div>
  );
}

export default function ChangelogModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [showPrevious, setShowPrevious] = useState(false);
  if (!open) return null;
  const [current, ...previous] = CHANGELOG;

  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center bg-foreground/40 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="flex max-h-[85vh] w-full max-w-2xl flex-col overflow-hidden rounded-2xl border border-border/60 bg-card/80 shadow-xl backdrop-blur-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3 border-b border-border/60 px-5 py-3.5">
          <div className="min-w-0">
            <h2 className="truncate text-sm font-bold text-foreground">What's in this build</h2>
            <p className="text-[11px] text-muted-foreground">
              Version {APP_VERSION} — changelog per build; QA-only view
            </p>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="min-h-0 flex-1 space-y-3 overflow-y-auto px-5 py-4">
          <EntryBlock entry={current} headline={`${current.version} — this build`} />

          <button
            type="button"
            onClick={() => setShowPrevious((v) => !v)}
            className="flex w-full items-center justify-center gap-1.5 rounded-lg border border-border/60 px-3 py-1.5 text-[11px] font-semibold text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
          >
            <History className="h-3.5 w-3.5" />
            {showPrevious ? "Hide previous versions" : `More — see the ${previous.length} previous version${previous.length === 1 ? "" : "s"}`}
            {showPrevious ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
          </button>

          {showPrevious && previous.map((e) => <EntryBlock key={e.version} entry={e} />)}
        </div>

        <div className="flex items-center justify-end border-t border-border/60 px-5 py-3">
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-secondary"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
