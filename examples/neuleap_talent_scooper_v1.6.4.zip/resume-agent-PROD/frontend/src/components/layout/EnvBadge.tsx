import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { X } from "lucide-react";
import { api } from "@/services/api";
import { cn } from "@/lib/utils";
import { useAuth } from "@/context/AuthContext";

// Deploy-stage label — mirrors app.services.system_reset's production-alias
// list, since that's the one thing this badge exists to make obvious: the
// destructive full-DB wipe (Mailbox → Batch Archive → System Cleanup) is only
// reachable when this reads anything other than Production.
const LABELS: Record<string, string> = {
  production: "PROD",
  prod: "PROD",
  prd: "PROD",
  qa: "QA",
  dev: "DEV",
  development: "DEV",
  staging: "STAGING",
  uat: "UAT",
  test: "TEST",
};

// Claymorphic treatment: solid pastel "clay" fill + the layered shadows that
// sell the soft-extruded look (outer drop, light inner top edge, darker inner
// bottom edge). Text stays a deep tone of the same hue for contrast in both
// themes.
const CLAY: Record<string, { bg: string; text: string; shadow: string }> = {
  PROD: {
    bg: "#fecdd3",
    text: "#9f1239",
    shadow:
      "0 4px 10px rgba(159,18,57,0.30), inset 0 2px 3px rgba(255,255,255,0.75), inset 0 -2px 3px rgba(159,18,57,0.20)",
  },
  QA: {
    bg: "#fde68a",
    text: "#92400e",
    shadow:
      "0 4px 10px rgba(146,64,14,0.28), inset 0 2px 3px rgba(255,255,255,0.75), inset 0 -2px 3px rgba(146,64,14,0.20)",
  },
  DEV: {
    bg: "#bae6fd",
    text: "#075985",
    shadow:
      "0 4px 10px rgba(7,89,133,0.28), inset 0 2px 3px rgba(255,255,255,0.75), inset 0 -2px 3px rgba(7,89,133,0.20)",
  },
  STAGING: {
    bg: "#ddd6fe",
    text: "#5b21b6",
    shadow:
      "0 4px 10px rgba(91,33,182,0.28), inset 0 2px 3px rgba(255,255,255,0.75), inset 0 -2px 3px rgba(91,33,182,0.20)",
  },
};
const FALLBACK_CLAY = {
  bg: "#99f6e4",
  text: "#115e59",
  shadow:
    "0 4px 10px rgba(17,94,89,0.28), inset 0 2px 3px rgba(255,255,255,0.75), inset 0 -2px 3px rgba(17,94,89,0.20)",
};

export default function EnvBadge() {
  const { isAdmin } = useAuth();
  const [open, setOpen] = useState(false);
  const { data } = useQuery({
    queryKey: ["app-env"],
    queryFn: () => api.get<{ app_env: string }>("/meta").then((r) => r.data.app_env),
    staleTime: Infinity,
    retry: false,
  });

  if (!data) return null;
  const label = LABELS[data.trim().toLowerCase()] ?? data.trim().toUpperCase();
  const clay = CLAY[label] ?? FALLBACK_CLAY;
  const isProd = label === "PROD";

  return (
    <>
      <button
        type="button"
        onClick={() => isAdmin && setOpen(true)}
        title={
          isAdmin
            ? `Environment: ${data} — click for what this means for candidate emails (and how to go PROD)`
            : `Environment: ${data}`
        }
        className={cn(
          "inline-flex shrink-0 items-center rounded-full px-2.5 py-1 text-[10px] font-extrabold tracking-wide transition-transform",
          isAdmin ? "cursor-pointer hover:scale-105 active:scale-95" : "cursor-default"
        )}
        style={{ backgroundColor: clay.bg, color: clay.text, boxShadow: clay.shadow }}
      >
        {label}
      </button>

      {open && (
        <div
          className="fixed inset-0 z-[70] flex items-center justify-center bg-foreground/50 p-4 backdrop-blur-sm"
          onClick={() => setOpen(false)}
        >
          <div
            className="flex max-h-[85vh] w-full max-w-md flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-3 border-b border-border px-5 py-3.5">
              <h2 className="text-sm font-bold text-foreground">
                🚨 {isProd ? "This IS production" : "Candidate emails & this environment"}
              </h2>
              <button
                onClick={() => setOpen(false)}
                className="rounded-lg p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
                aria-label="Close"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="min-h-0 flex-1 space-y-3 overflow-y-auto px-5 py-4 text-xs leading-relaxed text-muted-foreground">
              <div className="rounded-lg border border-rose-500/30 bg-rose-500/5 px-3 py-2.5">
                <p className="font-semibold text-rose-600">
                  In a non-QA / PRD environment, every candidate-facing email — slot invites,
                  reminders, booking confirmations, expiry notices — is sent DIRECTLY to each
                  candidate's real address.
                </p>
                <p className="mt-1.5 text-rose-600/90">
                  That is exactly how production should behave — but it means a test run against
                  real candidate data emails real people.
                </p>
              </div>
              <p>
                In <span className="font-semibold text-foreground">{label}</span>
                {isProd
                  ? " there is NO safety redirect — treat every action as candidate-visible."
                  : (
                    <>
                      {" "}every candidate-facing email is instead redirected to the QA test inbox
                      (Settings → Interviewer Access → Interview Scheduling → QA calendar email), so
                      real candidates are never contacted while testing.
                    </>
                  )}
              </p>
              <div>
                <p className="font-semibold text-foreground">Testing a PROD-like scenario safely</p>
                <p className="mt-1">
                  Use resumes belonging to the QA team themselves (your own names and email
                  addresses) as the "candidates". The full flow — invites, reminders, bookings,
                  verdict emails — then exercises real delivery end-to-end while only ever emailing
                  the testers.
                </p>
              </div>
              <div>
                <p className="font-semibold text-foreground">Setting this deployment to PRD</p>
                <ol className="mt-1 list-decimal space-y-1 pl-4">
                  <li>
                    Edit the <code className="selectable rounded bg-secondary px-1">.env</code> file
                    next to <code className="selectable rounded bg-secondary px-1">docker-compose.yml</code>{" "}
                    and set <code className="selectable rounded bg-secondary px-1">APP_ENV=production</code>{" "}
                    (aliases: <code className="selectable rounded bg-secondary px-1">prod</code>,{" "}
                    <code className="selectable rounded bg-secondary px-1">prd</code>).
                  </li>
                  <li>
                    Restart the backend so it picks the value up:{" "}
                    <code className="selectable rounded bg-secondary px-1">docker compose up -d app</code>.
                  </li>
                  <li>Reload this page — the badge must read PROD (rose).</li>
                </ol>
                <p className="mt-1.5">
                  Going PROD also: disables the full-database wipe (System Cleanup), turns OFF the QA
                  email redirect, and removes the QA-only minute-based reminder intervals — days/hours
                  only.
                </p>
              </div>
            </div>
            <div className="flex justify-end border-t border-border px-5 py-3">
              <button
                type="button"
                onClick={() => setOpen(false)}
                className="rounded-lg bg-primary px-3.5 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-primary/90"
              >
                Understood
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
