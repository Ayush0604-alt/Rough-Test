import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

/**
 * The single source of page width, gutter, and vertical rhythm — every route renders its
 * content inside one of these so container widths can never drift apart again (see
 * DESIGN_AUDIT.md §C1). Replaces the per-page `p-4 sm:p-6 max-w-[…]` that each page used
 * to hand-roll with its own arbitrary width.
 *
 *   default  — data-dense pages (Dashboard, Resume Library, Candidate, Rounds, Screening list)
 *   focused  — single-column forms / detail (Screening detail, Settings)
 */
export default function PageContainer({
  size = "default",
  className,
  children,
}: {
  size?: "default" | "focused";
  className?: string;
  children: ReactNode;
}) {
  return (
    <div
      className={cn(
        "mx-auto w-full px-4 py-4 sm:px-6 space-y-4",
        // Default pages span the full screen width; "focused" stays a narrow column.
        size === "focused" ? "max-w-[820px]" : "max-w-none",
        className,
      )}
    >
      {children}
    </div>
  );
}
