import { NavLink } from "react-router-dom";
import { cn } from "@/lib/utils";
import { useBottomNavItems } from "./Sidebar";

/**
 * Mobile-only bottom tab bar (Instagram-style) — replaces the old hamburger +
 * slide-in drawer so every primary nav item is one tap away with no open/close
 * step. A deliberately short, fixed subset of the full nav list (see
 * `useBottomNavItems`) — Process Flow / Token Usage live in the account
 * dropdown instead so every tab here stays legible.
 *
 * Items are `flex-1` (equal-width) with a `min-w` floor; if a role's subset
 * still doesn't fit at that floor, the row scrolls horizontally instead of
 * squeezing icons/labels down to illegible sizes.
 */
export default function BottomNav() {
  const items = useBottomNavItems();

  return (
    <nav
      className="glass-chrome fixed inset-x-0 bottom-0 z-40 flex shrink-0 overflow-x-auto border-t border-border pb-[env(safe-area-inset-bottom)] md:hidden"
      aria-label="Primary"
    >
      {items.map(({ to, icon: Icon, label }) => (
        <NavLink
          key={to}
          to={to}
          className={({ isActive }) =>
            cn(
              // items-stretch (the default) — NOT items-center — so the icon/
              // label below actually take this item's real (possibly squeezed)
              // width; items-center let them size to their own content instead,
              // which left `truncate` with nothing narrow enough to clip
              // against and let long labels spill into neighboring tabs.
              "group flex min-w-[56px] flex-1 flex-col justify-center gap-0.5 px-1 py-2 text-[10px] font-medium transition-colors",
              isActive ? "text-primary" : "text-ink-mute hover:text-ink"
            )
          }
        >
          {({ isActive }) => (
            <>
              <Icon
                className={cn(
                  "mx-auto h-5 w-5 shrink-0 transition-colors",
                  isActive ? "text-primary" : "text-ink-mute group-hover:text-primary"
                )}
              />
              <span className="block w-full truncate text-center">{label}</span>
            </>
          )}
        </NavLink>
      ))}
    </nav>
  );
}
