import type { ReactNode } from "react";
import { useIsFetching, useQueryClient } from "@tanstack/react-query";
import { RefreshCw } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * In-app data refresh — refetches every mounted query so the page updates
 * without a full browser reload. Lives in the hero bar of every page (built into
 * PageHeader) and spins while any fetch is in flight.
 */
function HeaderRefreshButton() {
  const queryClient = useQueryClient();
  const fetching = useIsFetching();
  return (
    <button
      type="button"
      onClick={() => queryClient.invalidateQueries()}
      disabled={fetching > 0}
      title="Refresh this page's data"
      aria-label="Refresh"
      className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-border/70 bg-card/70 text-ink-mute transition-colors hover:border-primary/40 hover:text-primary disabled:opacity-60"
    >
      <RefreshCw className={cn("h-4 w-4", fetching > 0 && "animate-spin")} />
    </button>
  );
}

interface PageHeaderProps {
  /** Small all-caps eyebrow pill above the title (e.g. "Intake"). Optional. */
  eyebrow?: string;
  /** The large, thin display title (e.g. "Mail Master"). */
  title: string;
  /** Optional supporting line under the title. */
  subtitle?: ReactNode;
  /**
   * Optional control rendered on the title's own line, right next to it —
   * for a single filter/action that needs to stay there instead of dropping
   * into the (separately wrapping) `actions` row on narrow screens.
   */
  titleAdornment?: ReactNode;
  /** Optional right-aligned actions (buttons, badges, counts). */
  actions?: ReactNode;
  className?: string;
}

/**
 * The signature gradient-mesh hero band shared by every page header — Stripe-style:
 * a pastel mesh backdrop, an indigo eyebrow pill, a thin 32px display title with
 * negative tracking, and an optional right-side action slot.
 */
export default function PageHeader({
  eyebrow,
  title,
  subtitle,
  titleAdornment,
  actions,
  className,
}: PageHeaderProps) {
  return (
    <div className={cn("mesh-band shrink-0 px-4 py-2.5 sm:px-6", className)}>
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div className="min-w-0">
          {eyebrow && <span className="pill-tag-soft">{eyebrow}</span>}
          <div className="mt-1 flex flex-wrap items-center justify-between gap-2">
            <h1 className="text-base font-light leading-tight tracking-[-0.02em] text-ink break-words sm:text-lg">
              {title}
            </h1>
            {titleAdornment}
            {/* Mobile-only: anchored to the title row so it never gets
                isolated by itself when the (separately wrapping) actions row
                below needs its own line for a wide filter/search group. */}
            <div className="shrink-0 sm:hidden">
              <HeaderRefreshButton />
            </div>
          </div>
          {subtitle && <p className="mt-0.5 text-xs text-ink-mute">{subtitle}</p>}
        </div>
        {/* Desktop: Refresh stays paired with page-specific actions. */}
        <div className="flex shrink-0 flex-wrap items-center justify-end gap-2">
          <div className="hidden shrink-0 sm:block">
            <HeaderRefreshButton />
          </div>
          {actions}
        </div>
      </div>
    </div>
  );
}
