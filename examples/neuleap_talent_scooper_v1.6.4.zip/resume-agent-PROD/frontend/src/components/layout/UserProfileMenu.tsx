import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { Settings, LogOut, ShieldCheck, Quote, KeyRound, BookOpen, MessageSquarePlus, Workflow, Coins } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/context/AuthContext";
import ChangePasswordModal from "@/components/auth/ChangePasswordModal";
import HelpModal from "@/components/help/HelpModal";
import ChangelogModal from "@/components/layout/ChangelogModal";
import ReportFeedbackModal from "@/components/feedback/ReportFeedbackModal";
import { APP_VERSION } from "@/config/version";
import { api } from "@/services/api";
import type { UserRole } from "@/services/auth";

const ROLE_LABEL: Record<UserRole, string> = {
  admin: "Admin",
  recruiter: "Recruitment Manager",
  sysadmin: "System Admin",
};

function initialsFor(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return "?";
  return (parts[0][0] + (parts[1]?.[0] ?? "")).toUpperCase();
}

/** Logged-in user's avatar in the top-right corner — opens a dropdown with the
 * account summary, Settings (only for roles with access), and Sign out. Settings
 * moved here from its own standalone top-bar icon (SettingsButton, now removed). */
export default function UserProfileMenu() {
  const { user, canAccessBackoffice, isAdmin, logout } = useAuth();
  const [open, setOpen] = useState(false);
  const [changePwOpen, setChangePwOpen] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);
  const [feedbackOpen, setFeedbackOpen] = useState(false);
  const [changelogOpen, setChangelogOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  // The per-build changelog popup only exists in the QA env — same cached
  // ["app-env"] query the Sidebar's version pill uses, so no extra request.
  const { data: appEnv } = useQuery({
    queryKey: ["app-env"],
    queryFn: () => api.get<{ app_env: string }>("/meta").then((r) => r.data.app_env),
    staleTime: Infinity,
    retry: false,
  });
  const isQaEnv = (appEnv ?? "").trim().toLowerCase() === "qa";

  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  if (!user) return null;

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-label="Account menu"
        title={user.name}
        className="flex h-9 w-9 items-center justify-center rounded-full gradient-brand text-xs font-bold text-white transition-transform hover:scale-105"
      >
        {initialsFor(user.name)}
      </button>

      {open && (
        <div className="glass-panel absolute right-0 top-full z-40 mt-2 w-64 overflow-hidden p-1.5">
          <div className="flex items-center gap-3 rounded-xl px-2.5 py-2.5">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full gradient-brand text-sm font-bold text-white">
              {initialsFor(user.name)}
            </span>
            <div className="min-w-0">
              <div className="truncate text-sm font-semibold text-foreground">{user.name}</div>
              <div className="truncate text-[11px] text-muted-foreground">{user.email}</div>
            </div>
          </div>
          <div className="mx-2.5 mb-1.5 flex items-center gap-1">
            <span
              className={cn(
                "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-semibold",
                user.role === "admin"
                  ? "bg-primary/10 text-primary border border-primary/20"
                  : user.role === "sysadmin"
                    ? "bg-violet-500/10 text-violet-600 border border-violet-500/20"
                    : "bg-secondary text-muted-foreground border border-border"
              )}
            >
              {(user.role === "admin" || user.role === "sysadmin") && (
                <ShieldCheck className="h-3 w-3" />
              )}
              {ROLE_LABEL[user.role]}
            </span>
          </div>

          <div className="my-1 h-px bg-border" />

          {canAccessBackoffice && (
            <Link
              to="/settings"
              onClick={() => setOpen(false)}
              className="flex items-center gap-2.5 rounded-xl px-2.5 py-2 text-sm text-foreground transition-colors hover:bg-secondary"
            >
              <Settings className="h-4 w-4 text-muted-foreground" />
              Settings
            </Link>
          )}

          {/* Process Flow / Token Usage moved off the mobile bottom tab bar
              (only room for the day-to-day pages there) — this dropdown is
              their other home, on both mobile and desktop. */}
          <Link
            to="/process-flow"
            onClick={() => setOpen(false)}
            className="flex items-center gap-2.5 rounded-xl px-2.5 py-2 text-sm text-foreground transition-colors hover:bg-secondary"
          >
            <Workflow className="h-4 w-4 text-muted-foreground" />
            Process Flow
          </Link>

          {isAdmin && (
            <Link
              to="/token-usage"
              onClick={() => setOpen(false)}
              className="flex items-center gap-2.5 rounded-xl px-2.5 py-2 text-sm text-foreground transition-colors hover:bg-secondary"
            >
              <Coins className="h-4 w-4 text-muted-foreground" />
              Token Usage
            </Link>
          )}

          {/* Self-service password change — every login role (Admin / System
              Admin / Recruitment Manager) has one. */}
          <button
            type="button"
            onClick={() => {
              setOpen(false);
              setChangePwOpen(true);
            }}
            className="flex w-full items-center gap-2.5 rounded-xl px-2.5 py-2 text-left text-sm text-foreground transition-colors hover:bg-secondary"
          >
            <KeyRound className="h-4 w-4 text-muted-foreground" />
            Change password
          </button>

          {/* In-app User Manual — content filtered to the signed-in role
              (Admin sees everything; Recruitment Manager / System Admin see
              only the chapters that apply to them). */}
          <button
            type="button"
            onClick={() => {
              setOpen(false);
              setHelpOpen(true);
            }}
            className="flex w-full items-center gap-2.5 rounded-xl px-2.5 py-2 text-left text-sm text-foreground transition-colors hover:bg-secondary"
          >
            <BookOpen className="h-4 w-4 text-muted-foreground" />
            Help — User Manual
          </button>

          {/* Mirrors the Sidebar footer's own copy — this dropdown is the only
              way to reach it on mobile now that there's no drawer. */}
          <button
            type="button"
            onClick={() => {
              setOpen(false);
              setFeedbackOpen(true);
            }}
            className="flex w-full items-center gap-2.5 rounded-xl px-2.5 py-2 text-left text-sm text-foreground transition-colors hover:bg-secondary"
          >
            <MessageSquarePlus className="h-4 w-4 text-muted-foreground" />
            Report a bug / request a feature
          </button>

          {/* Brand footer — the space below the account actions and above Sign
              out was empty air; a small "manifesto" card (slogan + one-line
              description) fills it deliberately instead of leaving it dead,
              styled apart from the plain menu rows so it reads as a flourish. */}
          <div className="mx-1 my-1.5 rounded-xl border border-amber-500/15 bg-gradient-to-br from-primary/[0.07] via-transparent to-amber-500/[0.08] px-3 py-2.5">
            <div className="flex items-start gap-1.5">
              <Quote className="mt-0.5 h-3 w-3 shrink-0 text-amber-500/80" />
              <p className="text-[11px] italic leading-snug text-foreground">
                Send a post and watch the gates…
              </p>
            </div>
            <p className="mt-1.5 text-[10px] leading-snug text-muted-foreground">
              The Agentic AI solution to your professional talent hunt problem.
            </p>
          </div>

          <div className="my-1 h-px bg-border" />

          <button
            type="button"
            onClick={() => {
              setOpen(false);
              logout();
            }}
            className="flex w-full items-center gap-2.5 rounded-xl px-2.5 py-2 text-left text-sm text-foreground transition-colors hover:bg-secondary"
          >
            <LogOut className="h-4 w-4 text-muted-foreground" />
            Sign out
          </button>

          <button
            type="button"
            onClick={() => isQaEnv && setChangelogOpen(true)}
            disabled={!isQaEnv}
            title={isQaEnv ? "What's in this build — new features, bug fixes and changes to watch out for" : undefined}
            className={cn(
              "mt-2 flex w-full items-center gap-1.5 px-2.5 text-left",
              isQaEnv ? "cursor-pointer group" : "cursor-default"
            )}
          >
            <span className="relative flex h-1.5 w-1.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-60" />
              <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-emerald-500" />
            </span>
            <span
              className={cn(
                "text-[10px] font-medium text-muted-foreground tracking-wide",
                isQaEnv && "underline decoration-dotted underline-offset-2 transition-colors group-hover:text-foreground"
              )}
            >
              Version {APP_VERSION}
            </span>
          </button>
        </div>
      )}

      {feedbackOpen && <ReportFeedbackModal onClose={() => setFeedbackOpen(false)} />}
      <ChangelogModal open={changelogOpen} onClose={() => setChangelogOpen(false)} />

      {changePwOpen && <ChangePasswordModal onClose={() => setChangePwOpen(false)} />}
      {helpOpen && <HelpModal onClose={() => setHelpOpen(false)} />}
    </div>
  );
}
