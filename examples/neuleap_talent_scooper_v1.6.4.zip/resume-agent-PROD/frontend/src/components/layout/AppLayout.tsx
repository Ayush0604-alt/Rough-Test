import { useState } from "react";
import { Outlet } from "react-router-dom";
import Sidebar from "./Sidebar";
import BottomNav from "./BottomNav";
import TopBar from "./TopBar";
import EnvBadge from "./EnvBadge";
import ThemeToggle from "./ThemeToggle";
import UserProfileMenu from "./UserProfileMenu";
import NotificationBell from "@/components/notifications/NotificationBell";
import FloatingChatbot from "@/components/chatbot/FloatingChatbot";
import ChangePasswordModal from "@/components/auth/ChangePasswordModal";
import { useAuth } from "@/context/AuthContext";
import logo from "@/logo/neuleap_logo.png";

export default function AppLayout() {
  const { mustChangePassword } = useAuth();
  const [collapsed, setCollapsed] = useState(
    () => localStorage.getItem("sidebar-collapsed") === "1"
  );

  const toggleCollapsed = () =>
    setCollapsed((prev) => {
      const next = !prev;
      localStorage.setItem("sidebar-collapsed", next ? "1" : "0");
      return next;
    });

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Tablet+ static sidebar */}
      <div className="hidden shrink-0 md:flex">
        <Sidebar collapsed={collapsed} onToggleCollapse={toggleCollapsed} />
      </div>

      <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
        {/* Mobile top bar */}
        <header className="glass-chrome flex shrink-0 items-center gap-3 border-b border-border px-4 py-3 md:hidden">
          {/* min-w-0 + flex-1 on the logo+name block lets the NAME truncate
              first if a narrow phone can't fit it alongside the 3 fixed-width
              icon buttons, instead of overflowing the bar. */}
          <div className="flex min-w-0 flex-1 items-center gap-2">
            <img
              src={logo}
              alt="Talents Scooper"
              className="h-8 w-8 shrink-0 rounded-lg object-cover"
            />
            <span className="truncate text-[16px] font-semibold tracking-[-0.01em] text-ink">
              Talents Scooper
            </span>
          </div>
          <div className="ml-auto flex shrink-0 items-center gap-1.5">
            <EnvBadge />
            <ThemeToggle />
            <NotificationBell />
            <UserProfileMenu />
          </div>
        </header>

        {/* Desktop top bar (hosts the notification bell). */}
        <TopBar />

        {/* Clears the fixed mobile bottom tab bar (plus its own safe-area
            padding) so page content never sits underneath it. */}
        <main className="min-h-0 flex-1 overflow-y-auto pb-20 md:pb-0">
          <Outlet />
        </main>
      </div>

      {/* Mobile bottom tab bar — replaces the old hamburger + slide-in drawer */}
      <BottomNav />

      {/* Floating Neuleap Buddy launcher — available on every page */}
      <FloatingChatbot />

      {/* First-login / post-admin-reset gate — blocks the whole app behind a
          non-dismissible change-password dialog until the user sets their own. */}
      {mustChangePassword && <ChangePasswordModal forced onClose={() => {}} />}
    </div>
  );
}
