import NotificationBell from "@/components/notifications/NotificationBell";
import EnvBadge from "./EnvBadge";
import ThemeToggle from "./ThemeToggle";
import UserProfileMenu from "./UserProfileMenu";

/**
 * Slim, always-visible desktop top bar. Desktop had no persistent header (each page
 * renders its own PageHeader, mobile has its own bar) — this hosts the theme toggle,
 * notification bell, and the account menu (avatar → Settings/Sign out) on the right.
 * Hidden on mobile, where all three live in the mobile header.
 */
export default function TopBar() {
  return (
    <header className="glass-chrome sticky top-0 z-30 hidden shrink-0 items-center justify-end gap-2 border-b border-border px-4 py-2 md:flex">
      <EnvBadge />
      <ThemeToggle />
      <NotificationBell />
      <UserProfileMenu />
    </header>
  );
}
