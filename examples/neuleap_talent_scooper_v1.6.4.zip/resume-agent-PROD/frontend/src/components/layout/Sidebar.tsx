import { useState } from "react";
import { NavLink } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import {
  LayoutDashboard,
  Mail,
  FileText,
  ClipboardCheck,
  Workflow,
  PanelLeftClose,
  PanelLeftOpen,
  LogOut,
  Quote,
  Coins,
  Library,
  MessageSquarePlus,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/context/AuthContext";
import { APP_VERSION } from "@/config/version";
import { api } from "@/services/api";
import ChangelogModal from "@/components/layout/ChangelogModal";
import ReportFeedbackModal from "@/components/feedback/ReportFeedbackModal";
import logo from "@/logo/neuleap_logo.png";

// `backoffice: true` entries are hidden from Recruiter (canAccessBackoffice
// false) — the backend enforces the identical restriction server-side
// (require_backoffice_access) on every route behind them, this just keeps
// the nav item from appearing at all for that role.
// `recruiting: true` entries are hidden from System Admin (canAccessRecruiting
// false) — a pure back-office role with no reason to touch the candidate
// pipeline; frontend-only scoping (see AuthContext's canAccessRecruiting doc).
const navItems = [
  { to: "/dashboard", icon: LayoutDashboard, label: "Dashboard", recruiting: true },
  // { to: "/analytics", icon: BarChart3, label: "Candidate Analysis" }, // removed
  // Resume Library hidden from nav (route still works directly at /resumes).
  // { to: "/resumes", icon: FolderOpen, label: "Resume Library" },
  { to: "/rounds", icon: ClipboardCheck, label: "Candidates", recruiting: true },
  { to: "/question-banks", icon: Library, label: "Question Banks", recruiting: true },
  { to: "/process-flow", icon: Workflow, label: "Process Flow" },
  // { to: "/pipeline", ... } merged into Mailbox (redirects to /intake)
  { to: "/intake", icon: Mail, label: "Mailbox", backoffice: true },
  // { to: "/rounds", icon: CalendarClock, label: "Rounds" }, // hidden for now
  // Chatbot now lives in the floating launcher (FloatingChatbot), not the sidebar.
  { to: "/audit-logs", icon: FileText, label: "Activity Log", backoffice: true },
  // `adminOnly` — tokenomics is an Admin cost/operations view, not for
  // recruiters or sysadmins.
  { to: "/token-usage", icon: Coins, label: "Token Usage", adminOnly: true },
  // Settings moved to the top-bar profile dropdown.
];

/** The same role-filtered nav list backing the desktop rail (`Sidebar`) — every
 * primary-nav destination this role can see. */
export function useVisibleNavItems() {
  const { canAccessBackoffice, canAccessRecruiting, isAdmin } = useAuth();
  return navItems.filter(
    (item) =>
      (!item.backoffice || canAccessBackoffice) &&
      (!item.recruiting || canAccessRecruiting) &&
      (!item.adminOnly || isAdmin)
  );
}

// The mobile bottom tab bar only has room for the handful of pages used most
// often day-to-day — Process Flow and Token Usage live in the account
// dropdown instead (see UserProfileMenu), same as Settings/Help already do.
const BOTTOM_NAV_ROUTES = new Set(["/dashboard", "/rounds", "/question-banks", "/intake", "/audit-logs"]);

/** Role-filtered subset of `navItems` for `BottomNav` — a fixed, short list so
 * every tab stays legible instead of squeezing/scrolling to fit everything. */
export function useBottomNavItems() {
  return useVisibleNavItems().filter((item) => BOTTOM_NAV_ROUTES.has(item.to));
}

interface SidebarProps {
  /** Collapsed (icon-only) rail. */
  collapsed?: boolean;
  /** Toggles the collapsed state. */
  onToggleCollapse?: () => void;
}

/** Desktop-only nav rail (tablet+). Mobile uses `BottomNav` instead — see
 * `useVisibleNavItems` above for the shared nav-item list. */
export default function Sidebar({
  collapsed = false,
  onToggleCollapse,
}: SidebarProps) {
  const { user, logout } = useAuth();
  // The per-build changelog popup only exists in the QA env — same cached
  // ["app-env"] query the EnvBadge uses, so no extra request is made.
  const [changelogOpen, setChangelogOpen] = useState(false);
  const [feedbackOpen, setFeedbackOpen] = useState(false);
  const { data: appEnv } = useQuery({
    queryKey: ["app-env"],
    queryFn: () => api.get<{ app_env: string }>("/meta").then((r) => r.data.app_env),
    staleTime: Infinity,
    retry: false,
  });
  const isQaEnv = (appEnv ?? "").trim().toLowerCase() === "qa";
  const visibleNavItems = useVisibleNavItems();
  return (
    <aside
      className={cn(
        "flex h-full shrink-0 flex-col glass-sidebar transition-[width] duration-200",
        collapsed ? "w-[72px]" : "w-60"
      )}
    >
      {/* Brand */}
      <div className={cn("pt-5 pb-4", collapsed ? "px-2.5" : "px-4")}>
        <div
          className={cn(
            "flex items-center gap-2.5",
            collapsed && "justify-center"
          )}
        >
          <img
            src={logo}
            alt="Talents Scooper"
            className="h-9 w-9 shrink-0 rounded-lg object-cover"
          />
          {/* Two-line lockup — "Talents Scooper" is too long to sit on one
              line at a legible size inside a 240px rail alongside the logo
              and the collapse/close button, so the domain qualifier drops to
              its own smaller line instead of shrinking the whole thing.
              min-w-0 lets it truncate rather than push the ml-auto button
              off the edge if the rail is ever narrower than the full name. */}
          {!collapsed && (
            <div className="min-w-0 leading-tight">
              <div className="truncate text-[14.5px] font-semibold tracking-[-0.01em] text-ink">
                Talents Scooper
              </div>
              <div className="truncate text-[10px] font-semibold uppercase tracking-[0.08em] text-primary">
                @NeuLeap.Ai
              </div>
            </div>
          )}

          {/* Collapse toggle (shown when expanded) */}
          {onToggleCollapse && !collapsed && (
            <button
              type="button"
              aria-label="Collapse sidebar"
              title="Collapse sidebar"
              onClick={onToggleCollapse}
              className="ml-auto inline-flex h-8 w-8 items-center justify-center rounded-full text-ink-mute transition-colors hover:bg-secondary hover:text-ink"
            >
              <PanelLeftClose className="h-[18px] w-[18px]" />
            </button>
          )}
        </div>

        {/* Expand toggle (shown when collapsed) */}
        {onToggleCollapse && collapsed && (
          <button
            type="button"
            aria-label="Expand sidebar"
            title="Expand sidebar"
            onClick={onToggleCollapse}
            className="mx-auto mt-3 flex h-8 w-8 items-center justify-center rounded-full text-ink-mute transition-colors hover:bg-secondary hover:text-ink"
          >
            <PanelLeftOpen className="h-[18px] w-[18px]" />
          </button>
        )}

        {!collapsed && <div className="mt-3 divider-brand" />}
      </div>

      {/* Nav — sized to its own content (shrink-0), not flex-1: the manifesto
          panel below is what absorbs the leftover space now, so the nav
          block itself just takes however much room its items need. */}
      <nav
        className={cn(
          "shrink-0 overflow-y-auto py-2 space-y-0.5",
          collapsed ? "px-2" : "px-3"
        )}
      >
        {visibleNavItems.map(({ to, icon: Icon, label }) => (
          <NavLink
            key={to}
            to={to}
            title={collapsed ? label : undefined}
            className={({ isActive }) =>
              cn(
                "group flex items-center rounded-full text-[15px] font-normal transition-colors duration-150",
                collapsed ? "justify-center px-0 py-2.5" : "gap-3 px-3 py-2.5",
                isActive
                  ? "bg-accent text-brand-deep"
                  : "text-ink-mute hover:text-ink hover:bg-secondary"
              )
            }
          >
            {({ isActive }) => (
              <>
                <Icon
                  className={cn(
                    "h-4 w-4 shrink-0 transition-colors",
                    isActive ? "text-primary" : "text-ink-mute group-hover:text-primary"
                  )}
                />
                {!collapsed && label}
              </>
            )}
          </NavLink>
        ))}
      </nav>

      {/* Brand manifesto — takes over the flex-1 role the nav used to have,
          so it grows or shrinks automatically with however much room is left
          once the (role-gated, so variable) nav item count and the footer
          have taken what they need — few items free up a big canvas, many
          items and the panel comes along for the ride instead of leaving a
          shrunken card in a sea of blank space. min-h-0 lets it collapse
          toward nothing if a future nav list ever grows enough to need the
          room back; a real quote glyph the size of the slogan itself (with
          the text nested on top, not beside it) sits as a soft background
          watermark so the panel reads as a poster even when it's tall. */}
      {!collapsed ? (
        <div className="min-h-0 flex-1 px-3 py-2">
          <div className="relative flex h-full min-h-[88px] flex-col items-center justify-center gap-2.5 overflow-hidden rounded-2xl border border-amber-500/20 bg-gradient-to-br from-primary/[0.08] via-transparent to-amber-500/[0.12] px-5 py-4 text-center">
            <Quote className="pointer-events-none absolute -left-2 -top-3 h-16 w-16 rotate-180 text-primary/[0.07]" />
            <Quote className="h-5 w-5 shrink-0 text-amber-500/70" />
            <p className="max-w-[170px] text-[15px] font-medium italic leading-snug text-ink">
              Send a post and watch the gates…
            </p>
            <div className="h-px w-10 bg-gradient-to-r from-transparent via-amber-500/60 to-transparent" />
            <p className="max-w-[180px] text-[11px] leading-relaxed text-ink-mute">
              The Agentic AI solution to your professional talent hunt problem.
            </p>
          </div>
        </div>
      ) : (
        // Collapsed mode has no manifesto panel to act as the flex-1 filler —
        // without one, "Sign out" would sit right under the last nav icon
        // instead of pinned to the bottom of the rail. A bare spacer keeps the
        // footer position consistent between collapsed and expanded states.
        <div className="min-h-0 flex-1" />
      )}

      {/* Footer */}
      <div
        className={cn(
          "shrink-0 border-t border-border/60",
          collapsed ? "px-2 py-3" : "px-3 py-3"
        )}
      >
        <button
          type="button"
          onClick={() => setFeedbackOpen(true)}
          title={collapsed ? "Report a bug or request a feature" : undefined}
          className={cn(
            "group mb-1 flex w-full items-center rounded-full text-[15px] font-normal text-ink-mute transition-colors duration-150 hover:bg-secondary hover:text-ink",
            collapsed ? "justify-center px-0 py-2.5" : "gap-3 px-3 py-2.5"
          )}
        >
          <MessageSquarePlus className="h-4 w-4 shrink-0 text-ink-mute group-hover:text-primary" />
          {!collapsed && (
            <span className="min-w-0 flex-1 truncate text-left">Report a bug / request a feature</span>
          )}
        </button>

        <button
          type="button"
          onClick={logout}
          title={collapsed ? "Sign out" : undefined}
          className={cn(
            "group flex w-full items-center rounded-full text-[15px] font-normal text-ink-mute transition-colors duration-150 hover:bg-secondary hover:text-ink",
            collapsed ? "justify-center px-0 py-2.5" : "gap-3 px-3 py-2.5"
          )}
        >
          {/* Mirrored: lucide's default LogOut arrow can read as "entering" at a
              glance (arrow pointing the same rightward direction as LogIn,
              just past a door frame) — flipping it makes "exiting" unambiguous. */}
          <LogOut className="h-4 w-4 shrink-0 -scale-x-100 text-ink-mute group-hover:text-primary" />
          {!collapsed && (
            <span className="min-w-0 flex-1 truncate text-left">
              Sign out
              {user?.email && (
                <span className="block truncate text-[11px] text-muted-foreground">
                  {user.email}
                </span>
              )}
            </span>
          )}
        </button>

        {!collapsed && (
          <button
            type="button"
            onClick={() => isQaEnv && setChangelogOpen(true)}
            disabled={!isQaEnv}
            title={isQaEnv ? "What's in this build — new features, bug fixes and changes to watch out for" : undefined}
            className={cn(
              "mt-3 flex items-center gap-1.5 px-3 text-left",
              isQaEnv ? "cursor-pointer group" : "cursor-default"
            )}
          >
            <span className="relative flex h-1.5 w-1.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-60" />
              <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-emerald-500" />
            </span>
            <span
              className={cn(
                "text-[10px] font-medium text-muted-foreground tracking-wide",
                isQaEnv && "underline decoration-dotted underline-offset-2 transition-colors group-hover:text-foreground"
              )}
            >
              Version {APP_VERSION}
            </span>
          </button>
        )}
      </div>

      <ChangelogModal open={changelogOpen} onClose={() => setChangelogOpen(false)} />
      {feedbackOpen && <ReportFeedbackModal onClose={() => setFeedbackOpen(false)} />}
    </aside>
  );
}
