import { useCallback, useEffect, useRef, useState, type CSSProperties } from "react";
import { useLocation } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { X } from "lucide-react";
import Chatbot from "@/pages/Chatbot";
import { cn } from "@/lib/utils";
import { derivePageContext } from "@/lib/pageContext";
import { chatbotService } from "@/services/chatbot";

// Pill-mascot dimensions — drag math, viewport clamping, and default position
// all key off these, so they live in one place. Kept close to square (just a
// touch taller than wide) for a shorter, more compact silhouette than a true
// elongated pill.
const ICON_W = 50;
const ICON_H = 52;
const EDGE_MARGIN = 12;
const PANEL_GAP = 12;
// Below this width, AppLayout switches on the fixed mobile bottom tab bar
// (Tailwind's `md` breakpoint — see BottomNav's `md:hidden`) — the mascot's
// bottom clamp needs to clear it instead of sitting underneath/on top of it.
const MOBILE_BREAKPOINT = 768;
const BOTTOM_NAV_CLEARANCE = 76;

const POS_KEY = "chatbot:launcher-pos";

type Pos = { x: number; y: number };

function bottomMargin(): number {
  return window.innerWidth < MOBILE_BREAKPOINT ? BOTTOM_NAV_CLEARANCE : EDGE_MARGIN;
}

function clampPos(p: Pos): Pos {
  const maxX = Math.max(EDGE_MARGIN, window.innerWidth - ICON_W - EDGE_MARGIN);
  const maxY = Math.max(EDGE_MARGIN, window.innerHeight - ICON_H - bottomMargin());
  return {
    x: Math.min(Math.max(EDGE_MARGIN, p.x), maxX),
    y: Math.min(Math.max(EDGE_MARGIN, p.y), maxY),
  };
}

// Default: left edge, resting near the bottom — same "out of the way" corner
// feel as the old bottom-right pin, just mirrored per spec. Restored from
// wherever the user last dropped it, if anywhere.
function loadPos(): Pos {
  try {
    const raw = localStorage.getItem(POS_KEY);
    if (raw) {
      const p = JSON.parse(raw);
      if (typeof p?.x === "number" && typeof p?.y === "number") return clampPos(p);
    }
  } catch {
    /* localStorage unavailable — fall through to default */
  }
  return clampPos({ x: EDGE_MARGIN + 8, y: window.innerHeight - ICON_H - bottomMargin() - 8 });
}

/**
 * Floating "Neuleap Buddy" launcher — a frosted-glass pill mascot with two
 * blinking eyes, free to drag anywhere on screen (defaults to the bottom-left
 * corner; position persists across visits). Available on every page via
 * AppLayout. Clicking (not dragging) opens the full chat experience in a
 * glass panel anchored near wherever the mascot currently sits; the
 * conversation persists for the tab session (handled inside Chatbot), so
 * closing/reopening keeps the thread.
 */
export default function FloatingChatbot() {
  const [open, setOpen] = useState(false);
  const [maximized, setMaximized] = useState(false);
  const [pos, setPos] = useState<Pos>(loadPos);
  const { pathname, search } = useLocation();

  // Admin-controlled, shared on/off toggle (Settings → Chatbot) — not a
  // per-user preference. Defaults to shown while the check is in flight (and
  // if it ever fails) so a slow/broken request never silently removes the
  // feature; only an explicit `visible: false` hides it.
  const { data: widgetConfig } = useQuery({
    queryKey: ["chatbot-widget-config"],
    queryFn: async () => (await chatbotService.getWidgetConfig()).data,
    staleTime: 5 * 60 * 1000,
  });
  const widgetHidden = widgetConfig?.visible === false;

  // Re-derived on every render (not memoized) — this component never
  // unmounts as the recruiter navigates the app, so a fresh route means a
  // fresh page-context string handed to the next question they ask, even if
  // the panel has stayed open across several page changes.
  const pageContext = derivePageContext(pathname, search);

  const draggingRef = useRef(false);
  const movedRef = useRef(false);
  const dragStartRef = useRef({ mouseX: 0, mouseY: 0, elX: 0, elY: 0 });
  // Mirrors `pos` but updates SYNCHRONOUSLY on every move — a fast drag fires
  // several pointermove events before React has committed the corresponding
  // re-renders, so a callback closed over the `pos` *state* (via useCallback's
  // dependency array) can still see a stale value from before the drag
  // started. Reading/writing this ref instead sidesteps that entirely.
  const posRef = useRef(pos);

  const setPosBoth = useCallback((next: Pos) => {
    posRef.current = next;
    setPos(next);
  }, []);

  // Re-clamp on viewport resize so the mascot can never end up stranded
  // off-screen — also doubles as the trigger to recompute the open panel's
  // anchor (it's derived fresh from `pos` + the current viewport on render).
  useEffect(() => {
    const onResize = () => setPosBoth(clampPos(posRef.current));
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, [setPosBoth]);

  const onPointerDown = useCallback((e: React.PointerEvent<HTMLButtonElement>) => {
    // Without this, a mousedown+move on desktop is indistinguishable from the
    // browser's native "click-drag to select" gesture — it was starting
    // alongside our custom drag and painting its own translucent selection
    // rectangle (a sharp-cornered box) over the button, which is exactly the
    // square halo around the round icon. select-none (CSS) stops highlighted
    // TEXT from sticking; this stops the selection gesture from starting at
    // all, which is the part that was actually drawing the box.
    e.preventDefault();
    // Capture can throw (e.g. no "active" pointer registered for this id) —
    // never let that abort the rest of the handler, or a drag could never
    // start at all. Dragging itself doesn't depend on capture succeeding;
    // capture just keeps tracking correct if the pointer leaves the button.
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      /* non-fatal */
    }
    draggingRef.current = true;
    movedRef.current = false;
    dragStartRef.current = { mouseX: e.clientX, mouseY: e.clientY, elX: posRef.current.x, elY: posRef.current.y };
  }, []);

  const onPointerMove = useCallback((e: React.PointerEvent<HTMLButtonElement>) => {
    if (!draggingRef.current) return;
    const dx = e.clientX - dragStartRef.current.mouseX;
    const dy = e.clientY - dragStartRef.current.mouseY;
    if (Math.abs(dx) > 4 || Math.abs(dy) > 4) movedRef.current = true;
    setPosBoth(clampPos({ x: dragStartRef.current.elX + dx, y: dragStartRef.current.elY + dy }));
  }, [setPosBoth]);

  const endDrag = useCallback((e: React.PointerEvent<HTMLButtonElement>) => {
    if (!draggingRef.current) return;
    draggingRef.current = false;
    try {
      e.currentTarget.releasePointerCapture(e.pointerId);
    } catch {
      /* non-fatal */
    }
    if (movedRef.current) {
      try {
        localStorage.setItem(POS_KEY, JSON.stringify(posRef.current));
      } catch {
        /* non-fatal */
      }
    }
  }, []);

  const onLauncherClick = useCallback(() => {
    // A drag that moved the mascot shouldn't also toggle the chat — swallow
    // this one click, then resume normal click-to-open/close behavior.
    if (movedRef.current) {
      movedRef.current = false;
      return;
    }
    setOpen((o) => !o);
  }, []);

  // The /chatbot route already renders the full chat — the floating launcher
  // there is redundant and just overlaps the page's own composer. Also hidden
  // entirely when disabled via Settings → Chatbot.
  if (pathname.startsWith("/chatbot") || widgetHidden) return null;

  // Anchor the panel near the mascot's current position — prefer opening
  // below-and-right of it, but flip to above/left when that would overflow
  // the viewport, then clamp either way. A binary "which half of the screen
  // is the icon in" split isn't good enough on its own: the panel (up to
  // 620px tall) can still overflow the far edge even from the "correct" half
  // when the icon sits close to the midpoint, so every candidate position is
  // clamped against the panel's own measured size as the final step.
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  const panelW = Math.min(400, vw - 40);
  const panelH = Math.min(620, vh - 144);

  let left = pos.x;
  let openedLeft = false;
  if (left + panelW + EDGE_MARGIN > vw) {
    left = pos.x + ICON_W - panelW;
    openedLeft = true;
  }
  left = Math.min(Math.max(EDGE_MARGIN, left), Math.max(EDGE_MARGIN, vw - panelW - EDGE_MARGIN));

  let top = pos.y + ICON_H + PANEL_GAP;
  let openedAbove = false;
  if (top + panelH + EDGE_MARGIN > vh) {
    top = pos.y - PANEL_GAP - panelH;
    openedAbove = true;
  }
  top = Math.min(Math.max(EDGE_MARGIN, top), Math.max(EDGE_MARGIN, vh - panelH - EDGE_MARGIN));

  const panelStyle: CSSProperties = { left, top };
  const anchorRight = openedLeft;
  const anchorBottom = openedAbove;

  return (
    <>
      {/* Chat panel — claymorphic glass: frosted/translucent (glass) so it
          reads as a layer over live content, riding on the app's own puffy
          dual-shadow clay depth (var(--clay-shadow)/--clay-radius, same
          tokens as .surface-float elsewhere) instead of a flat single-
          direction drop shadow, so it matches the rest of the app's material
          language while still being unmistakably glass.
          Same split as the launcher button below: the open/close transform
          (scale + translate) lives on this OUTER div, while the blur/
          background/rounded-corner clipping lives on an inner div that never
          transforms — backdrop-filter + border-radius + a transform on one
          element is what causes the blur's square sampling box to bleed past
          the rounded corners in some browsers.
          Maximized swaps the icon-anchored width/height/position for a
          near-fullscreen inset (a fixed margin on all four sides) instead —
          same panel, just given the whole viewport to work with. */}
      <div
        className={cn(
          "fixed z-50 transition-all duration-200",
          maximized ? "" : "w-[min(400px,calc(100vw-2.5rem))] h-[min(620px,calc(100vh-9rem))]",
          open
            ? "pointer-events-auto translate-y-0 scale-100 opacity-100"
            : "pointer-events-none translate-y-3 scale-95 opacity-0",
        )}
        style={{
          ...(maximized
            ? { left: EDGE_MARGIN, top: EDGE_MARGIN, right: EDGE_MARGIN, bottom: EDGE_MARGIN }
            : panelStyle),
          transformOrigin: maximized ? "center" : `${anchorBottom ? "bottom" : "top"} ${anchorRight ? "right" : "left"}`,
        }}
        aria-hidden={!open}
      >
        <div
          className={cn(
            "flex h-full w-full flex-col overflow-hidden rounded-[var(--clay-radius)]",
            "border border-white/40 bg-white/70 backdrop-blur-2xl backdrop-saturate-150",
            "dark:border-white/10 dark:bg-slate-900/60 chatbot-clay-shadow",
          )}
        >
          {open && (
            <Chatbot
              onClose={() => {
                setOpen(false);
                setMaximized(false);
              }}
              pageContext={pageContext}
              maximized={maximized}
              onToggleMaximize={() => setMaximized((m) => !m)}
            />
          )}
        </div>
      </div>

      {/* Launcher — a shorter, more compact claymorphic-glass pill (frosted
          translucency + the same puffy dual shadow as the panel, plus a soft
          brand-color glow layered on top so the mascot still reads as
          colorful/friendly rather than a plain grey glass chip) with two
          blinking eyes. Draggable via pointer capture; not anchored to any
          corner.
          The blur/background/clipping live on an INNER div, not the button
          itself — combining backdrop-filter + border-radius + overflow-hidden
          with a CSS transform (the hover/active scale) on the very same
          element is a known cause of the blur's square sampling box bleeding
          past the rounded corners in some browser compositors (that's the
          "square corners poking out of the circle" artifact). Splitting them
          so the transform lives on the outer button and the blur+clip lives
          on a non-transformed inner layer sidesteps it entirely. */}
      <button
        type="button"
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={endDrag}
        onPointerCancel={endDrag}
        onClick={onLauncherClick}
        aria-label={open ? "Close Neuleap Buddy" : "Open Neuleap Buddy"}
        aria-expanded={open}
        style={{
          left: pos.x,
          top: pos.y,
          width: ICON_W,
          height: ICON_H,
          // iOS Safari flashes its own tap-highlight rectangle on a touched
          // element, and that highlight doesn't reliably respect
          // border-radius — a sharp-cornered box on a round button. This is
          // the mobile-Safari half of the "square around the circle" bug (the
          // preventDefault() in onPointerDown handles the desktop-mouse half:
          // native click-drag text/element selection).
          WebkitTapHighlightColor: "transparent",
        }}
        className={cn(
          "fixed z-50 touch-none select-none rounded-full cursor-grab",
          "chatbot-launcher-shadow transition-transform hover:scale-105 active:scale-95 active:cursor-grabbing",
        )}
      >
        <div
          className={cn(
            "relative flex h-full w-full items-center justify-center overflow-hidden rounded-full",
            "border border-white/40 bg-white/25 backdrop-blur-xl dark:border-white/15 dark:bg-white/10",
          )}
        >
          {/* Soft color wash behind the frosted surface — a plain grey pane
              reads as "glass panel", not "friendly bot"; this tints it. The
              gradient's own soft color stops already read as smooth without
              a `filter: blur()` — that filter was the real cause of the
              square-corner artifact reported on mobile (a filtered child
              isn't always reliably clipped by an ancestor's overflow-hidden
              + border-radius on every mobile browser compositor; the
              backdrop-filter split above fixed the container's OWN blur, but
              this decorative span had the same class of bug from a
              different property). Dropping the filter removes the risky
              property entirely instead of chasing per-browser clipping
              behavior we can't fully test. */}
          <span className="pointer-events-none absolute inset-0 bg-gradient-to-br from-primary/60 to-brand-deep/60" />

          {/* Face — two blinking eyes by default, crossfades to a close (X)
              glyph while the chat is open. */}
          <span
            className={cn(
              "relative flex items-center gap-2 transition-all duration-200",
              open ? "scale-50 opacity-0" : "scale-100 opacity-100",
            )}
          >
            <span className="animate-buddy-blink h-2.5 w-2.5 rounded-full bg-white shadow-[0_0_4px_rgba(255,255,255,0.6)]" />
            <span className="animate-buddy-blink h-2.5 w-2.5 rounded-full bg-white shadow-[0_0_4px_rgba(255,255,255,0.6)]" />
          </span>
          <X
            className={cn(
              "absolute h-5 w-5 text-white transition-all duration-200",
              open ? "rotate-0 scale-100 opacity-100" : "rotate-90 scale-50 opacity-0",
            )}
          />
        </div>
      </button>
    </>
  );
}
