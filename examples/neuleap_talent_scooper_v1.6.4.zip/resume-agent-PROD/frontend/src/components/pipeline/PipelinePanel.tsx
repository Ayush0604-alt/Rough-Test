import { useEffect, useRef, useState, type ReactNode } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Play, Loader2, CheckCircle2, AlertTriangle, Activity, RefreshCw } from "lucide-react";
import { pipelineService, type PipelineRunResult } from "@/services/pipeline";
import { emailsService } from "@/services/emails";
import { cn, formatDateTime } from "@/lib/utils";

function fmtTime(iso: string | null): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "—";
  return d.toLocaleString(undefined, { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
}

// Shared data/mutation logic behind the status banner + the "Last run" card —
// split into its own hook so the Mailbox page can render the banner (sticky,
// under the hero) and the "Last run" card (scrolls with the rest) as two
// independent pieces without duplicating any of the querying/mutation logic.
function usePipelineStatus() {
  const queryClient = useQueryClient();
  const [lastRun, setLastRun] = useState<PipelineRunResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Event-driven, NOT timer-driven. The status endpoint is polled ONLY while a batch
  // is actually running (to animate the progress bar); the instant it finishes,
  // polling stops. `runningRef` gates the interval. 3s is plenty for a progress bar
  // and keeps the network tab quiet (was 1.5s ≈ 40 calls/min).
  const runningRef = useRef(false);

  const { data: status, refetch: refetchStatus } = useQuery({
    queryKey: ["pipeline-status"],
    queryFn: async () => (await pipelineService.status()).data,
    refetchInterval: () => (runningRef.current ? 3000 : false),
  });

  const { data: runSummary } = useQuery({
    queryKey: ["run-summary"],
    queryFn: async () => (await emailsService.getRunSummary()).data,
    refetchInterval: false,
  });

  const { data: persistedRun } = useQuery({
    queryKey: ["pipeline-last-run"],
    queryFn: async () => (await pipelineService.lastRun()).data.last_run,
    refetchInterval: false,
  });

  const running = status?.running ?? false;
  // "Last:" time — the run-summary value when present, else the persisted last-run's
  // finish/start time (the run-summary feed can lag and show "—" while the batch
  // history already has the real timestamp).
  const lastRunAt =
    runSummary?.last_run || persistedRun?.finished_at || persistedRun?.started_at || null;
  const progTotal = status?.total ?? 0;
  const progDone = status?.done ?? 0;
  const progPct = progTotal > 0 ? Math.min(100, Math.round((progDone / progTotal) * 100)) : 0;

  const runAll = useMutation({
    // /run-all now starts the batch and returns immediately — the actual
    // result arrives later via status().result, once the background run
    // finishes (see the effect below). A batch can run many minutes, longer
    // than most reverse-proxy read timeouts tolerate on one held-open request.
    mutationFn: async () => (await pipelineService.runAll()).data,
    onMutate: () => setError(null),
    onSuccess: () => {
      // Kicked off — start polling status right away instead of waiting for
      // the next interval tick.
      refetchStatus();
    },
    onError: (e: unknown) => {
      const msg =
        (e as { response?: { status?: number; data?: { detail?: string } } })?.response?.data?.detail ??
        (e as { message?: string })?.message ??
        "Run failed";
      setError(String(msg));
    },
  });

  // The background run just finished — status().result is set exactly once
  // per completed run (it stays until the NEXT run overwrites it, so key off
  // object identity to only react the moment it actually changes).
  const seenResultRef = useRef<PipelineRunResult | null | undefined>(undefined);
  useEffect(() => {
    if (status?.result !== undefined && status.result !== seenResultRef.current) {
      seenResultRef.current = status.result;
      if (status.result) {
        setLastRun(status.result);
        queryClient.invalidateQueries({ queryKey: ["emails"] });
        queryClient.invalidateQueries({ queryKey: ["run-summary"] });
        queryClient.invalidateQueries({ queryKey: ["pipeline-last-run"] });
        queryClient.invalidateQueries({ queryKey: ["review-queue"] });
      }
    }
  }, [status?.result, queryClient]);

  const busy = running || runAll.isPending;
  const indeterminate = busy && progTotal === 0;

  runningRef.current = busy;
  useEffect(() => {
    if (runAll.isPending) refetchStatus();
  }, [runAll.isPending, refetchStatus]);

  return {
    status, runSummary, persistedRun, lastRun, error,
    running, lastRunAt, progTotal, progDone, progPct,
    runAll, busy, indeterminate,
  };
}

type PipelineStatus = ReturnType<typeof usePipelineStatus>;

// The run controls + live status banner — rendered as the TOP ROW of the
// merged Resume Processing card (see IntakeMailMaster/index.tsx): the parent
// surface provides the outer border, and only the counters the outcome grid
// below does NOT already show (Needs Review / Resolved) appear here —
// Processing/Processed/Failed used to be duplicated across both panels.
export function PipelineStatusBar({
  pipeline,
  needsReviewCount,
  statsToggle,
  onNeedsReviewClick,
  onResolvedClick,
}: {
  pipeline: PipelineStatus;
  needsReviewCount: number;
  // A compact control (e.g. the mini processing-stats donut) rendered in the
  // right-hand cluster before the counters.
  statsToggle?: ReactNode;
  // When provided, the Needs Review / Resolved counters become clickable
  // drill-ins (open the review subpage / filter the table to Resolved).
  onNeedsReviewClick?: () => void;
  onResolvedClick?: () => void;
}) {
  const { status, runSummary, lastRunAt, running, progTotal, progDone, progPct, runAll, busy, indeterminate, error } = pipeline;

  return (
    <>
      {/* Status banner + Run button */}
      <div
        className={cn(
          "p-4 flex items-center justify-between flex-wrap gap-3",
          running ? "bg-orange-400/5" : "bg-emerald-400/5"
        )}
      >
        <div className="flex items-center gap-3">
          <div
            className={cn(
              "w-8 h-8 rounded-lg flex items-center justify-center",
              running ? "bg-orange-400/15 text-orange-400" : "bg-emerald-400/15 text-emerald-400"
            )}
          >
            <Activity className="h-4 w-4" />
          </div>
          <div>
            <div className="text-sm font-bold text-foreground">
              {running ? "Batch running…" : "Idle — ready to run"}
            </div>
            <div className="text-xs text-muted-foreground">
              Next scheduled run: {formatDateTime(runSummary?.next_run)} · Last: {formatDateTime(lastRunAt)}
            </div>
          </div>
        </div>

        {running && (
          <div className="w-full order-last mt-1">
            <div className="mb-1.5 flex items-center justify-between text-xs">
              <span className="font-medium text-foreground">{status?.phase || "Working…"}</span>
              <span className="tnum text-muted-foreground">
                {progTotal > 0 ? `${progDone} / ${progTotal} mails · ${progPct}%` : "Starting…"}
              </span>
            </div>
            <div className="h-2 w-full overflow-hidden rounded-full bg-orange-500/15">
              {indeterminate ? (
                <div className="h-full w-1/4 rounded-full bg-orange-400 animate-indeterminate" />
              ) : (
                <div
                  className="h-full rounded-full bg-orange-400 transition-all duration-500 ease-out"
                  style={{ width: `${progPct}%` }}
                />
              )}
            </div>
          </div>
        )}

        <div className="flex flex-wrap items-center gap-2">
          {statsToggle}
          {[
            { label: "Needs Review", val: needsReviewCount, cls: "text-rose-600 border-rose-500/30 bg-rose-400/5", onClick: onNeedsReviewClick },
            { label: "Resolved", val: runSummary?.resolved ?? 0, cls: "text-slate-500 border-slate-500/30 bg-slate-400/5", onClick: onResolvedClick },
          ].map(({ label, val, cls, onClick }) => (
            <button
              key={label}
              type="button"
              onClick={onClick}
              disabled={!onClick}
              title={onClick ? `Show ${label}` : undefined}
              className={cn(
                "rounded-lg border px-3 py-1.5 flex flex-col items-center transition-colors",
                cls,
                onClick ? "cursor-pointer hover:brightness-95 hover:saturate-150" : "cursor-default",
              )}
            >
              <span className="text-lg font-bold">{val}</span>
              <span className="text-[10px] font-medium opacity-80">{label}</span>
            </button>
          ))}
          <button onClick={() => runAll.mutate()} disabled={busy} className="btn-brand ml-1">
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
            {runAll.isPending ? "Running…" : "Run pipeline"}
          </button>
        </div>
      </div>

      {error && (
        <div className="mx-4 mb-3 flex items-start gap-2 rounded-lg border border-red-500/30 bg-red-400/10 px-3 py-2 text-sm text-red-400">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}
    </>
  );
}

// The "Last run" result card — scrolls normally with the rest of the page.
export function PipelineLastRun({ pipeline }: { pipeline: PipelineStatus }) {
  const { lastRun, persistedRun } = pipeline;

  return (
    <div className="rounded-xl border border-border bg-card overflow-hidden">
      <div className="flex items-center justify-between border-b border-border px-5 py-3">
        <h2 className="text-sm font-semibold text-foreground">Last run</h2>
        <span className="text-xs font-mono text-blue-400">
          {lastRun?.batch_id ?? persistedRun?.batch_id ?? ""}
        </span>
      </div>

      {!lastRun && !persistedRun && (
        <div className="px-5 py-6 text-center text-sm text-muted-foreground">
          <RefreshCw className="h-5 w-5 mx-auto mb-2 opacity-40" />
          No runs yet — click <span className="font-medium text-foreground">Run pipeline</span> to start one.
        </div>
      )}

      {!lastRun && persistedRun && (
        <div className="flex flex-wrap items-center gap-x-8 gap-y-2 px-5 py-3">
          {[
            { label: "Mails in batch", val: persistedRun.mail_count },
            { label: "Processed", val: persistedRun.processed },
            { label: "With errors", val: persistedRun.failed },
          ].map(({ label, val }) => (
            <div key={label} className="flex items-baseline gap-2">
              <span className="stat-value text-2xl font-bold text-foreground tnum">{val}</span>
              <span className="text-xs text-muted-foreground">{label}</span>
            </div>
          ))}
          <span className="ml-auto text-xs text-muted-foreground">
            Ran {fmtTime(persistedRun.finished_at ?? persistedRun.started_at)}
          </span>
        </div>
      )}

      {lastRun?.skipped && (
        <div className="px-5 py-8 text-center text-sm text-muted-foreground">
          <RefreshCw className="h-5 w-5 mx-auto mb-2 opacity-40" />
          Mail queue is empty — nothing to process. The pipeline didn't run.
        </div>
      )}

      {lastRun && !lastRun.skipped && (
        <>
          <div className="flex flex-wrap items-center gap-x-8 gap-y-2 px-5 py-3 border-b border-border">
            {[
              { label: "Mails in batch", val: lastRun.mail_count },
              { label: "Mails processed", val: lastRun.processed },
              { label: "With errors", val: lastRun.results.filter((r) => r.error).length },
            ].map(({ label, val }) => (
              <div key={label} className="flex items-baseline gap-2">
                <span className="text-2xl font-bold text-foreground tnum">{val}</span>
                <span className="text-xs text-muted-foreground">{label}</span>
              </div>
            ))}
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-y border-border">
                  {["Email", "Files", "Passed", "Failed", "Extractions", "Status"].map((h) => (
                    <th key={h} className="px-4 py-2.5 text-left text-xs font-semibold text-muted-foreground">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {lastRun.results.map((r) => (
                  <tr key={r.e_id} className="border-b border-border/50">
                    <td className="px-4 py-2.5 text-xs font-mono text-blue-400">{r.e_id}</td>
                    <td className="px-4 py-2.5 text-xs text-foreground">{r.total_files ?? "—"}</td>
                    <td className="px-4 py-2.5 text-xs text-emerald-400">{r.passed ?? "—"}</td>
                    <td className="px-4 py-2.5 text-xs text-red-400">{r.failed ?? "—"}</td>
                    <td className="px-4 py-2.5 text-xs text-foreground">{r.extractions ?? "—"}</td>
                    <td className="px-4 py-2.5">
                      {r.error ? (
                        <span className="inline-flex items-center gap-1 text-xs text-red-400">
                          <AlertTriangle className="h-3 w-3" /> {r.error}
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-xs text-emerald-400">
                          <CheckCircle2 className="h-3 w-3" /> OK
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
                {lastRun.results.length === 0 && (
                  <tr>
                    <td colSpan={6} className="px-4 py-8 text-center text-sm text-muted-foreground">
                      No mails were pending — nothing to process.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}

export { usePipelineStatus };

// The pipeline run controls + live status + last-run summary, embeddable on the
// Mailbox page (previously the standalone /pipeline page) — kept as a single
// default export (PipelineStatusBar + PipelineLastRun back to back) for any
// caller that doesn't need to split them across a sticky boundary.
export default function PipelinePanel({
  needsReviewCount,
}: {
  needsReviewCount: number;
}) {
  const pipeline = usePipelineStatus();
  return (
    <>
      <PipelineStatusBar pipeline={pipeline} needsReviewCount={needsReviewCount} />
      <PipelineLastRun pipeline={pipeline} />
    </>
  );
}
