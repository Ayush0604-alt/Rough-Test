import { useState, useRef, Fragment } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  AlertTriangle,
  CheckCircle2,
  Loader2,
  Inbox,
  X,
  FileText,
  ExternalLink,
  Upload,
  ChevronDown,
  RotateCcw,
  Trash2,
  Play,
} from "lucide-react";
import { reviewQueueService } from "@/services/reviewQueue";
import type { ReviewItem, ReviewAction } from "@/types";
import type { ReviewGroup } from "@/types/review";
import { cn, titleCase } from "@/lib/utils";
import ResumeViewerModal from "@/components/candidate/ResumeViewerModal";

// ── Review queue ────────────────────────────────────────────────────────────
// Files/rows the pipeline could not auto-process (L2 drops, L1 missing links /
// failed downloads / invalid files). Surfaced on the Mailbox page so nothing is
// ever lost. (Previously lived inside the Screening page.)

const STAGE_COLORS: Record<string, string> = {
  L1: "text-sky-400 bg-sky-400/10 border-sky-500/30",
  L2: "text-violet-400 bg-violet-400/10 border-violet-500/30",
  L3: "text-amber-400 bg-amber-400/10 border-amber-500/30",
};

// Plain-English names for the internal pipeline stages.
const STAGE_LABELS: Record<string, string> = {
  L1: "Intake",
  L2: "Validation",
  L3: "Extraction",
};

type KindMeta = {
  label: string;
  cls: string;
  view: boolean; // show "View file"
  approve: "none" | "l3"; // show "This IS a resume → process"
  upload: boolean; // show "Upload resume"
  extract: boolean; // show "Run extraction" (Pending Extraction candidates)
};

const RV_ROSE = "text-rose-400 bg-rose-400/10 border-rose-500/30";
const RV_SKY = "text-sky-400 bg-sky-400/10 border-sky-500/30";
const RV_VIOLET = "text-violet-400 bg-violet-400/10 border-violet-500/30";
const RV_AMBER = "text-amber-400 bg-amber-400/10 border-amber-500/30";

// Per-kind label, chip styling, and which actions each kind exposes.
const KIND_META: Record<string, KindMeta> = {
  invalid_file:       { label: "Invalid file",       cls: RV_ROSE,   view: false, approve: "none", upload: false, extract: false },
  excel_row:          { label: "Excel row",          cls: RV_SKY,    view: false, approve: "none", upload: true,  extract: false },
  link_fetch:         { label: "Link failed",        cls: RV_SKY,    view: false, approve: "none", upload: true,  extract: false },
  corrupt:            { label: "Corrupt file",       cls: RV_ROSE,   view: false, approve: "none", upload: false, extract: false },
  not_resume:         { label: "Not a resume",       cls: RV_ROSE,   view: true,  approve: "l3",   upload: false, extract: false },
  duplicate:          { label: "Duplicate",          cls: RV_VIOLET, view: false, approve: "none", upload: false, extract: false },
  duplicate_hired:    { label: "Duplicate · hired",  cls: RV_VIOLET, view: false, approve: "none", upload: false, extract: false },
  reapplication:      { label: "Re-application",     cls: RV_VIOLET, view: true,  approve: "none", upload: false, extract: false },
  extraction_fail:    { label: "Extraction failed",  cls: RV_AMBER,  view: false, approve: "none", upload: false, extract: false },
  failed:             { label: "Failed",             cls: RV_ROSE,   view: true,  approve: "l3",   upload: false, extract: false },
  exhausted:          { label: "Retries exhausted",  cls: RV_ROSE,   view: true,  approve: "none", upload: false, extract: false },
  pending_extraction: { label: "Pending extraction", cls: RV_AMBER,  view: false, approve: "none", upload: false, extract: true  },
};
const FALLBACK_META: KindMeta = { label: "Needs review", cls: RV_ROSE, view: true, approve: "none", upload: false, extract: false };

// Two recruiter-facing buckets, mirrored by the Dashboard cards:
//  • pending — just needs a resume uploaded (excel row / failed link)
//  • manual  — needs a human decision (corrupt, not-a-resume, duplicate, re-application,
//    or a stuck extraction to run)
type ReviewFilter = "all" | "pending" | "manual" | "reapplication" | "duplicate" | "not_resume";
const PENDING_KINDS = new Set<string>(["excel_row", "link_fetch"]);
function categoryOf(kind: string): "pending" | "manual" {
  return PENDING_KINDS.has(kind) ? "pending" : "manual";
}
const isReapplicationKind = (kind: string) => kind === "reapplication";
const isDuplicateKind = (kind: string) => kind === "duplicate" || kind === "duplicate_hired";
const isNotResumeKind = (kind: string) => kind === "not_resume";
// Does an item belong under the given Show filter? "all" matches everything;
// "pending"/"manual" use the two-bucket split; "reapplication"/"duplicate"/
// "not_resume" are kind-specific subsets of the manual bucket.
function matchesFilter(kind: string, filter: ReviewFilter): boolean {
  switch (filter) {
    case "all": return true;
    case "pending":
    case "manual": return categoryOf(kind) === filter;
    case "reapplication": return isReapplicationKind(kind);
    case "duplicate": return isDuplicateKind(kind);
    case "not_resume": return isNotResumeKind(kind);
  }
}

function fmtReviewDate(s: string | null | undefined): string {
  if (!s) return "—";
  const d = new Date(s);
  if (isNaN(d.getTime())) return String(s);
  return d.toLocaleString("en-IN", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
}

// Group the flat item list into one container per email (e_id).
function groupByEmail(items: ReviewItem[]): ReviewGroup[] {
  const map = new Map<string, ReviewGroup>();
  for (const it of items) {
    const key = it.e_id ?? `__none_${it.review_id}`;
    let g = map.get(key);
    if (!g) {
      g = { e_id: it.e_id ?? "—", email: it.email, items: [] };
      map.set(key, g);
    }
    g.items.push(it);
  }
  return Array.from(map.values());
}

function ReviewItemRow({
  item,
  busy,
  variant = "open",
  onApprove,
  onUpload,
  onExtract,
  onDiscard,
  onRestore,
  onDeletePermanent,
}: {
  item: ReviewItem;
  busy: boolean;
  variant?: "open" | "discarded";
  onApprove: (id: number) => void;
  onUpload: (id: number, file: File) => void;
  onExtract: (candidateId: string) => void;
  onDiscard: (id: number) => void;
  onRestore: (id: number) => void;
  onDeletePermanent: (item: ReviewItem) => void;
}) {
  const navigate = useNavigate();
  const [showCols, setShowCols] = useState(false);
  const [showFile, setShowFile] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const meta = KIND_META[item.kind] ?? FALLBACK_META;
  const isDuplicate = item.kind === "duplicate" || item.kind === "duplicate_hired";
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const d = (item.details ?? {}) as Record<string, any>;
  const rowCells = (d.row_cells ?? {}) as Record<string, string>;
  const isExcel = item.kind === "excel_row";
  const candTarget = item.duplicate_of ?? item.candidate_id;
  const title = isExcel
    ? d.name
      ? titleCase(String(d.name))
      : "(no name on row)"
    : item.filename ?? item.reason ?? meta.label;

  return (
    <div className="px-4 py-3">
      <div className="flex items-start gap-3">
        <span className={cn("text-[10px] font-bold border rounded-md px-1.5 py-0.5 shrink-0 mt-0.5", meta.cls)}>
          {meta.label}
        </span>
        <div className="min-w-0 flex-1">
          <div className="text-xs font-semibold text-foreground truncate">{title}</div>

          {isExcel ? (
            <div className="text-[11px] text-muted-foreground mt-0.5 space-y-0.5">
              <div className="truncate">
                {d.email ? <span>{String(d.email)}</span> : null}
                {d.phone ? <span>{d.email ? " · " : ""}{String(d.phone)}</span> : null}
                {d.row_number ? <span> · row {String(d.row_number)}</span> : null}
              </div>
              <div className="truncate">
                Link: {d.resume_link ? String(d.resume_link) : <span className="text-rose-400">(missing)</span>}
                {item.reason ? <span> · {item.reason}</span> : null}
              </div>
              {Object.keys(rowCells).length > 0 && (
                <button
                  onClick={() => setShowCols((v) => !v)}
                  className="inline-flex items-center gap-1 text-[11px] font-medium text-sky-400 hover:text-sky-300 mt-0.5"
                >
                  <ChevronDown className={cn("h-3 w-3 transition-transform", showCols && "rotate-180")} />
                  {showCols ? "Hide columns" : "Show all columns"}
                </button>
              )}
              {showCols && (
                <div className="mt-1 rounded-lg border border-border bg-secondary/40 p-2 grid grid-cols-[auto_1fr] gap-x-3 gap-y-1">
                  {Object.entries(rowCells).map(([k, v]) => (
                    <Fragment key={k}>
                      <span className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide truncate">{k}</span>
                      <span className="text-[11px] text-foreground break-words">{v || <span className="text-muted-foreground">—</span>}</span>
                    </Fragment>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <div className="text-[11px] text-muted-foreground mt-0.5 truncate">
              {item.reason}
              {isDuplicate && item.duplicate_of ? (
                <>
                  {" · duplicate of "}
                  <button
                    onClick={() => navigate(`/candidates/${item.duplicate_of}`)}
                    className="underline hover:text-foreground font-medium"
                  >
                    {item.duplicate_of}
                  </button>
                </>
              ) : null}
            </div>
          )}
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          {variant === "discarded" ? (
            <>
              {meta.view && item.raw_s3_key && (
                <button
                  onClick={() => setShowFile(true)}
                  title="Preview the dropped file in-app"
                  className="flex items-center gap-1 text-[11px] font-semibold text-sky-400 border border-sky-500/30 bg-sky-400/10 rounded-lg px-2 py-1 hover:bg-sky-400/20"
                >
                  <FileText className="h-3 w-3" /> View file
                </button>
              )}
              <button
                onClick={() => onRestore(item.review_id)}
                disabled={busy}
                title="Re-open this item (undo discard)"
                className="flex items-center gap-1 text-[11px] font-semibold text-emerald-400 border border-emerald-500/30 bg-emerald-400/10 rounded-lg px-2 py-1 hover:bg-emerald-400/20 disabled:opacity-50"
              >
                <RotateCcw className="h-3 w-3" /> Restore
              </button>
              <button
                onClick={() => onDeletePermanent(item)}
                disabled={busy}
                title="Permanently delete the file from storage and remove this row"
                className="flex items-center gap-1 text-[11px] font-semibold text-rose-400 border border-rose-500/40 bg-rose-500/10 rounded-lg px-2 py-1 hover:bg-rose-500/20 disabled:opacity-50"
              >
                <Trash2 className="h-3 w-3" /> Delete permanently
              </button>
            </>
          ) : (
            <>
              {meta.view && item.raw_s3_key && (
                <button
                  onClick={() => setShowFile(true)}
                  title="Preview the dropped file in-app"
                  className="flex items-center gap-1 text-[11px] font-semibold text-sky-400 border border-sky-500/30 bg-sky-400/10 rounded-lg px-2 py-1 hover:bg-sky-400/20"
                >
                  <FileText className="h-3 w-3" /> View file
                </button>
              )}
              {meta.approve === "l3" && (
                <button
                  onClick={() => onApprove(item.review_id)}
                  disabled={busy}
                  title="Override the verdict — process this file into a candidate"
                  className="flex items-center gap-1 text-[11px] font-semibold text-emerald-400 border border-emerald-500/30 bg-emerald-400/10 rounded-lg px-2 py-1 hover:bg-emerald-400/20 disabled:opacity-50"
                >
                  <CheckCircle2 className="h-3 w-3" /> This IS a resume → process
                </button>
              )}
              {meta.upload && (
                <>
                  <input
                    ref={fileRef}
                    type="file"
                    className="hidden"
                    accept=".pdf,.docx,.doc,.png,.jpg,.jpeg"
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (f) onUpload(item.review_id, f);
                      e.target.value = "";
                    }}
                  />
                  <button
                    onClick={() => fileRef.current?.click()}
                    disabled={busy}
                    title="Upload the resume this row's link failed to fetch"
                    className="flex items-center gap-1 text-[11px] font-semibold text-emerald-400 border border-emerald-500/30 bg-emerald-400/10 rounded-lg px-2 py-1 hover:bg-emerald-400/20 disabled:opacity-50"
                  >
                    <Upload className="h-3 w-3" /> Upload resume
                  </button>
                </>
              )}
              {meta.extract && item.candidate_id && (
                <button
                  onClick={() => onExtract(item.candidate_id!)}
                  disabled={busy}
                  title="Run L3 extraction now — fills name, skills, experience & ATS"
                  className="flex items-center gap-1 text-[11px] font-semibold text-emerald-400 border border-emerald-500/30 bg-emerald-400/10 rounded-lg px-2 py-1 hover:bg-emerald-400/20 disabled:opacity-50"
                >
                  {busy ? <Loader2 className="h-3 w-3 animate-spin" /> : <Play className="h-3 w-3" />} Run extraction
                </button>
              )}
              {(isDuplicate || item.kind === "reapplication" || item.kind === "extraction_fail" || item.kind === "pending_extraction") && candTarget && (
                <button
                  onClick={() => navigate(`/candidates/${candTarget}`)}
                  className="flex items-center gap-1 text-[11px] font-semibold text-violet-400 border border-violet-500/30 bg-violet-400/10 rounded-lg px-2 py-1 hover:bg-violet-400/20"
                >
                  <ExternalLink className="h-3 w-3" /> View candidate
                </button>
              )}
              {/* A pending-extraction item is a live candidate, not junk — no Discard. */}
              {item.kind !== "pending_extraction" && (
                <button
                  onClick={() => onDiscard(item.review_id)}
                  disabled={busy}
                  className="flex items-center gap-1 text-[11px] font-semibold text-muted-foreground border border-border rounded-lg px-2 py-1 hover:text-foreground hover:bg-accent disabled:opacity-50"
                >
                  <X className="h-3 w-3" /> Discard
                </button>
              )}
            </>
          )}
        </div>
      </div>

      {showFile && (
        <ResumeViewerModal
          open={showFile}
          onClose={() => setShowFile(false)}
          fileName={item.filename ?? `review-${item.review_id}`}
          subtitle={item.e_id ? `${meta.label} · ${item.e_id}` : meta.label}
          fetchBlob={async () => (await reviewQueueService.fetchFile(item.review_id)).data}
          newTabUrl={reviewQueueService.fileUrl(item.review_id)}
        />
      )}
    </div>
  );
}

function EmailReviewCard({
  group,
  busy,
  variant = "open",
  onApprove,
  onUpload,
  onExtract,
  onDiscard,
  onRestore,
  onDeletePermanent,
}: {
  group: ReviewGroup;
  busy: boolean;
  variant?: "open" | "discarded";
  onApprove: (id: number) => void;
  onUpload: (id: number, file: File) => void;
  onExtract: (candidateId: string) => void;
  onDiscard: (id: number) => void;
  onRestore: (id: number) => void;
  onDeletePermanent: (item: ReviewItem) => void;
}) {
  const stage = group.items[0]?.stage ?? null;
  const sender = group.email?.sender_mail_id ?? "unknown sender";
  const subject = group.email?.subject ?? "(no subject)";
  const date = fmtReviewDate(group.email?.received_date ?? group.items[0]?.created_at);
  return (
    <div className="rounded-xl border border-border bg-card overflow-hidden">
      <div className="flex items-center gap-3 px-4 py-3 border-b border-border bg-secondary/30">
        <span
          className={cn(
            "text-[10px] font-bold border rounded-md px-1.5 py-0.5 shrink-0",
            STAGE_COLORS[stage ?? ""] ?? "text-muted-foreground bg-secondary border-border"
          )}
        >
          {stage ? STAGE_LABELS[stage] ?? stage : "—"}
        </span>
        <div className="min-w-0 flex-1">
          <div className="text-sm font-semibold text-foreground truncate">{subject}</div>
          <div className="text-[11px] text-muted-foreground truncate">
            {sender} · {group.e_id} · {date}
          </div>
        </div>
        <span className="text-[11px] font-bold text-amber-400 bg-amber-400/10 border border-amber-500/30 rounded-full px-2 py-0.5 shrink-0">
          {group.items.length} {group.items.length === 1 ? "item" : "items"}
        </span>
      </div>
      <div className="divide-y divide-border">
        {group.items.map((it) => (
          <ReviewItemRow
            key={it.review_id}
            item={it}
            busy={busy}
            variant={variant}
            onApprove={onApprove}
            onUpload={onUpload}
            onExtract={onExtract}
            onDiscard={onDiscard}
            onRestore={onRestore}
            onDeletePermanent={onDeletePermanent}
          />
        ))}
      </div>
    </div>
  );
}

// App-styled confirmation modal (replaces the native window.confirm).
function ConfirmDialog({
  open,
  title,
  message,
  confirmLabel = "Confirm",
  danger = false,
  busy = false,
  onConfirm,
  onCancel,
}: {
  open: boolean;
  title: string;
  message?: string;
  confirmLabel?: string;
  danger?: boolean;
  busy?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/40 backdrop-blur-sm p-4"
      onClick={onCancel}
    >
      <div className="surface w-full max-w-sm p-5" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start gap-3">
          <div
            className={cn(
              "w-9 h-9 rounded-xl flex items-center justify-center shrink-0",
              danger ? "bg-rose-500/15" : "bg-amber-500/15"
            )}
          >
            {danger ? (
              <Trash2 className="h-4 w-4 text-rose-400" />
            ) : (
              <AlertTriangle className="h-4 w-4 text-amber-400" />
            )}
          </div>
          <div className="min-w-0">
            <h2 className="text-sm font-bold text-foreground">{title}</h2>
            {message && (
              <p className="mt-1 text-xs text-muted-foreground whitespace-pre-line">{message}</p>
            )}
          </div>
        </div>
        <div className="mt-5 flex justify-end gap-2">
          <button
            onClick={onCancel}
            disabled={busy}
            className="rounded-lg border border-border px-3 py-2 text-xs font-medium text-muted-foreground hover:bg-secondary disabled:opacity-50"
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            disabled={busy}
            className={cn(
              "flex items-center gap-1.5 rounded-lg px-3 py-2 text-xs font-semibold disabled:opacity-50",
              danger
                ? "bg-rose-500 text-white hover:bg-rose-600 border border-rose-500"
                : "btn-brand"
            )}
          >
            {busy ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : danger ? (
              <Trash2 className="h-3.5 w-3.5" />
            ) : null}
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function ReviewQueue({ initialFilter = "all" }: { initialFilter?: ReviewFilter }) {
  const queryClient = useQueryClient();
  const [tab, setTab] = useState<"open" | "discarded">("open");
  const [filter, setFilter] = useState<ReviewFilter>(initialFilter);
  const [confirmDel, setConfirmDel] = useState<ReviewItem | null>(null);
  const [confirmDelAll, setConfirmDelAll] = useState(false);

  const { data: items = [], isLoading, isError } = useQuery({
    queryKey: ["review-queue"],
    queryFn: async () => (await reviewQueueService.list()).data,
  });
  const { data: discarded = [] } = useQuery({
    queryKey: ["review-queue", "discarded"],
    queryFn: async () => (await reviewQueueService.listDiscarded()).data,
  });

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["review-queue"] });
    queryClient.invalidateQueries({ queryKey: ["candidates"] });
    // Resolving an item changes a mail's open_reviews count, so the Intake table's
    // needs-review-while-unresolved state can flip the mail back to Processed.
    queryClient.invalidateQueries({ queryKey: ["emails"] });
  };

  const resolveItem = useMutation({
    mutationFn: ({ id, action }: { id: number; action: ReviewAction }) =>
      reviewQueueService.resolve(id, action),
    onSuccess: invalidate,
  });
  const approveItem = useMutation({
    mutationFn: (id: number) => reviewQueueService.approve(id),
    onSuccess: invalidate,
  });
  const uploadItem = useMutation({
    mutationFn: ({ id, file }: { id: number; file: File }) =>
      reviewQueueService.upload(id, file),
    onSuccess: invalidate,
  });
  const extractItem = useMutation({
    mutationFn: (candidateId: string) => reviewQueueService.runExtraction(candidateId),
    // Refresh whether extraction succeeds or fails — either way the candidate is
    // Active and leaves the Pending-Extraction list, so always re-pull.
    onSettled: invalidate,
  });
  const restoreItem = useMutation({
    mutationFn: (id: number) => reviewQueueService.restore(id),
    onSuccess: invalidate,
  });
  const deleteItem = useMutation({
    mutationFn: (id: number) => reviewQueueService.deletePermanent(id),
    onSuccess: invalidate,
  });
  const deleteAll = useMutation({
    mutationFn: () => reviewQueueService.deleteAllDiscarded(),
    onSuccess: invalidate,
  });

  const busy =
    resolveItem.isPending || approveItem.isPending || uploadItem.isPending ||
    extractItem.isPending || restoreItem.isPending || deleteItem.isPending ||
    deleteAll.isPending;

  const handleDeletePermanent = (item: ReviewItem) => setConfirmDel(item);
  const confirmName = confirmDel?.filename || confirmDel?.reason || confirmDel?.kind || "";
  const confirmMsg = confirmDel?.raw_s3_key
    ? "This also deletes the file from storage. This cannot be undone."
    : "This cannot be undone.";

  // Category counts (open tab only) — mirror the Dashboard's two cards, plus the
  // kind-specific Re-application / Duplicate subsets.
  const pendingCount = items.filter((i) => categoryOf(i.kind) === "pending").length;
  const reapplicationCount = items.filter((i) => isReapplicationKind(i.kind)).length;
  const duplicateCount = items.filter((i) => isDuplicateKind(i.kind)).length;
  const notResumeCount = items.filter((i) => isNotResumeKind(i.kind)).length;
  const visibleOpen = items.filter((i) => matchesFilter(i.kind, filter));

  const active = (tab === "open" ? visibleOpen : discarded) as ReviewItem[];
  const groups = groupByEmail(active);
  const tabCls = (on: boolean, color: string) =>
    cn(
      "text-xs font-semibold rounded-lg px-3 py-1.5 border transition-colors",
      on ? color : "text-muted-foreground border-border hover:text-foreground"
    );
  const filterCls = (on: boolean) =>
    cn(
      "text-[11px] font-semibold rounded-lg px-2.5 py-1 border transition-colors",
      on ? "text-primary bg-primary/10 border-primary/30"
         : "text-muted-foreground border-border hover:text-foreground"
    );

  return (
    <section className="space-y-3">
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 rounded-xl bg-amber-500/15 flex items-center justify-center shrink-0">
          <AlertTriangle className="h-5 w-5 text-amber-400" />
        </div>
        <div>
          <h2 className="text-sm font-bold text-foreground">Needs Review</h2>
          <p className="text-xs text-muted-foreground">
            Files &amp; rows the pipeline could not auto-process — <span className="font-medium text-foreground">Pending resume</span> just needs a file uploaded; the rest need a decision.
          </p>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <button
          onClick={() => setTab("open")}
          className={tabCls(tab === "open", "text-amber-400 bg-amber-400/10 border-amber-500/30")}
        >
          Open{items.length ? ` · ${items.length}` : ""}
        </button>
        <button
          onClick={() => setTab("discarded")}
          className={tabCls(tab === "discarded", "text-rose-400 bg-rose-500/10 border-rose-500/40")}
        >
          Discarded{discarded.length ? ` · ${discarded.length}` : ""}
        </button>

        {tab === "discarded" && discarded.length > 0 && (
          <button
            onClick={() => setConfirmDelAll(true)}
            disabled={busy}
            title="Permanently delete every discarded item and its file"
            className="ml-auto flex items-center gap-1.5 text-xs font-semibold text-rose-400 border border-rose-500/40 bg-rose-500/10 rounded-lg px-3 py-1.5 hover:bg-rose-500/20 disabled:opacity-50"
          >
            <Trash2 className="h-3.5 w-3.5" /> Delete all · {discarded.length}
          </button>
        )}
      </div>

      {tab === "open" && (
        <div className="flex items-center gap-2">
          <span className="text-[11px] text-muted-foreground mr-1">Show:</span>
          <button onClick={() => setFilter("all")} className={filterCls(filter === "all")}>
            All{items.length ? ` · ${items.length}` : ""}
          </button>
          <button onClick={() => setFilter("pending")} className={filterCls(filter === "pending")}>
            Pending resume{pendingCount ? ` · ${pendingCount}` : ""}
          </button>
          <button onClick={() => setFilter("reapplication")} className={filterCls(filter === "reapplication")}>
            Re-application{reapplicationCount ? ` · ${reapplicationCount}` : ""}
          </button>
          <button onClick={() => setFilter("duplicate")} className={filterCls(filter === "duplicate")}>
            Duplicate{duplicateCount ? ` · ${duplicateCount}` : ""}
          </button>
          <button onClick={() => setFilter("not_resume")} className={filterCls(filter === "not_resume")}>
            Not a resume{notResumeCount ? ` · ${notResumeCount}` : ""}
          </button>
        </div>
      )}

      {isLoading && tab === "open" ? (
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading review queue…
        </div>
      ) : isError && tab === "open" ? (
        <div className="text-sm text-red-400">Could not load the review queue.</div>
      ) : active.length === 0 ? (
        <div className="rounded-xl border border-border bg-card p-10 flex flex-col items-center gap-2 text-center">
          <Inbox className="h-8 w-8 text-emerald-400" />
          <p className="text-sm font-semibold text-foreground">
            {tab === "discarded"
              ? "Nothing discarded"
              : items.length > 0
                ? "Nothing in this category"
                : "All clear"}
          </p>
          <p className="text-xs text-muted-foreground">
            {tab === "discarded"
              ? "Discarded items appear here, where you can restore them or delete them permanently."
              : items.length > 0
                ? "No items match this filter — switch to “All” to see the rest."
                : "Nothing is waiting for review — every resume was processed."}
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {tab === "discarded" && (
            <p className="text-[11px] text-muted-foreground">
              Discarded items and their files are retained until you delete them permanently.
            </p>
          )}
          {groups.map((g) => (
            <EmailReviewCard
              key={g.e_id}
              group={g}
              busy={busy}
              variant={tab}
              onApprove={(id) => approveItem.mutate(id)}
              onUpload={(id, file) => uploadItem.mutate({ id, file })}
              onExtract={(cid) => extractItem.mutate(cid)}
              onDiscard={(id) => resolveItem.mutate({ id, action: "discard" })}
              onRestore={(id) => restoreItem.mutate(id)}
              onDeletePermanent={handleDeletePermanent}
            />
          ))}
        </div>
      )}

      <ConfirmDialog
        open={!!confirmDel}
        danger
        title={`Permanently delete "${confirmName}"?`}
        message={confirmMsg}
        confirmLabel="Delete permanently"
        busy={deleteItem.isPending}
        onCancel={() => setConfirmDel(null)}
        onConfirm={() => {
          if (confirmDel) deleteItem.mutate(confirmDel.review_id);
          setConfirmDel(null);
        }}
      />

      <ConfirmDialog
        open={confirmDelAll}
        danger
        title={`Permanently delete all ${discarded.length} discarded item${discarded.length === 1 ? "" : "s"}?`}
        message="This also deletes their files from storage. This cannot be undone."
        confirmLabel="Delete all"
        busy={deleteAll.isPending}
        onCancel={() => setConfirmDelAll(false)}
        onConfirm={() => {
          deleteAll.mutate();
          setConfirmDelAll(false);
        }}
      />
    </section>
  );
}
