// Column Config — the panel opened from the "Columns" button on the Candidates page.
// Toggle each configurable column on/off AND drag to reorder them (the list order = the
// table's left-to-right order). "Candidate Name" is pinned first and not draggable (it's
// the row identity); everything else can be dragged above/below. Save persists order +
// visibility to the backend (/settings/columns, shared by all users); the table updates.
import { useEffect, useRef, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { X, Save, Loader2, GripVertical, Pin, ArrowDownAZ, Search } from "lucide-react";
import { settingsService, type ColumnSetting } from "@/services/settings";
import { cn } from "@/lib/utils";

const PINNED_KEY = "candidate_name";

function Toggle({
  value,
  onChange,
  disabled,
}: {
  value: boolean;
  onChange: (v: boolean) => void;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      disabled={disabled}
      title={disabled ? "Always shown — can't be hidden" : undefined}
      onClick={() => !disabled && onChange(!value)}
      className={cn(
        "relative inline-flex h-5 w-9 items-center rounded-full transition-colors shrink-0",
        value ? "bg-primary" : "bg-secondary",
        disabled && "cursor-not-allowed opacity-60",
      )}
    >
      <span
        className={cn(
          "inline-block h-3.5 w-3.5 transform rounded-full bg-white shadow transition-transform",
          value ? "translate-x-4" : "translate-x-1",
        )}
      />
    </button>
  );
}

export default function ColumnConfigModal({
  open,
  columns,
  onClose,
}: {
  open: boolean;
  columns: ColumnSetting[];
  onClose: () => void;
}) {
  const queryClient = useQueryClient();
  const [draft, setDraft] = useState<ColumnSetting[]>([]);
  const [search, setSearch] = useState("");
  const dragKey = useRef<string | null>(null);
  const [dragging, setDragging] = useState<string | null>(null);

  // Re-seed from the saved config each open, with the pinned column forced first.
  useEffect(() => {
    if (!open) return;
    const pinned = columns.find((c) => c.key === PINNED_KEY);
    const rest = columns.filter((c) => c.key !== PINNED_KEY);
    // The pinned column can never be hidden — force it visible regardless of saved state.
    setDraft(pinned ? [{ ...pinned, visible: true }, ...rest] : rest);
    setSearch("");
  }, [open, columns]);

  // Search narrows what's SHOWN only — drag/reorder still operates on the full
  // `draft` array by key, so filtering never disturbs the underlying order.
  const visible = search.trim()
    ? draft.filter((c) => c.label.toLowerCase().includes(search.trim().toLowerCase()))
    : draft;

  const setVisible = (key: string, visible: boolean) =>
    setDraft((d) => d.map((c) => (c.key === key ? { ...c, visible } : c)));

  // Sort the column ORDER alphabetically by label (A→Z), keeping the pinned column first.
  const sortAlphabetically = () =>
    setDraft((d) => {
      const pinned = d.filter((c) => c.key === PINNED_KEY);
      const rest = d
        .filter((c) => c.key !== PINNED_KEY)
        .sort((a, b) => a.label.localeCompare(b.label));
      return [...pinned, ...rest];
    });

  // Live reorder: as the dragged row hovers another, splice it to that position. The pinned
  // row is never a drop target and never moves.
  const reorderOver = (overKey: string) => {
    const from = dragKey.current;
    if (!from || from === overKey || overKey === PINNED_KEY) return;
    setDraft((d) => {
      const arr = [...d];
      const fromIdx = arr.findIndex((c) => c.key === from);
      const overIdx = arr.findIndex((c) => c.key === overKey);
      if (fromIdx < 0 || overIdx < 0) return d;
      const [moved] = arr.splice(fromIdx, 1);
      arr.splice(overIdx, 0, moved);
      return arr;
    });
  };

  const save = useMutation({
    mutationFn: () =>
      settingsService.saveColumns(
        // The pinned column is always persisted visible, whatever the draft holds.
        draft.map((c) => ({ key: c.key, visible: c.key === PINNED_KEY ? true : c.visible })),
      ),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["column-config"] });
      onClose();
    },
  });

  if (!open) return null;
  // "All on?" ignores the pinned column (it's always on); the toggle only flips the rest.
  const allOn =
    draft.length > 0 && draft.every((c) => c.key === PINNED_KEY || c.visible);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/40 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="flex max-h-[85vh] w-full max-w-md flex-col rounded-2xl border border-border bg-card shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3 border-b border-border px-5 py-3.5">
          <div>
            <h2 className="text-sm font-bold text-foreground">Column Config</h2>
            <p className="text-[11px] text-muted-foreground">
              Toggle columns on/off, and drag to reorder them.
            </p>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="min-h-0 flex-1 overflow-auto px-5 py-3">
          <div className="relative mb-2">
            <Search className="absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search columns…"
              className="w-full rounded-lg border border-border bg-secondary py-1.5 pl-8 pr-2.5 text-xs text-foreground placeholder:text-muted-foreground focus:border-primary/50 focus:outline-none"
            />
          </div>
          <div className="mb-1.5 flex items-center justify-end gap-3">
            <button
              onClick={sortAlphabetically}
              title="Order columns alphabetically (A→Z)"
              className="inline-flex items-center gap-1 text-[11px] font-semibold text-primary transition-colors hover:text-primary/80"
            >
              <ArrowDownAZ className="h-3.5 w-3.5" />
              Sort A–Z
            </button>
            <button
              onClick={() =>
                setDraft((d) =>
                  d.map((c) => (c.key === PINNED_KEY ? c : { ...c, visible: !allOn })),
                )
              }
              className="text-[11px] font-semibold text-primary transition-colors hover:text-primary/80"
            >
              {allOn ? "Disable all" : "Enable all"}
            </button>
          </div>
          {visible.length === 0 && (
            <p className="py-4 text-center text-xs text-muted-foreground">No columns match "{search}".</p>
          )}
          <div className="space-y-0.5">
            {visible.map((c) => {
              const pinned = c.key === PINNED_KEY;
              return (
                <div
                  key={c.key}
                  draggable={!pinned}
                  onDragStart={() => {
                    if (!pinned) {
                      dragKey.current = c.key;
                      setDragging(c.key);
                    }
                  }}
                  onDragOver={(e) => {
                    e.preventDefault();
                    reorderOver(c.key);
                  }}
                  onDragEnd={() => {
                    dragKey.current = null;
                    setDragging(null);
                  }}
                  className={cn(
                    "flex items-center justify-between gap-2 rounded-lg px-2 py-1.5 transition-colors",
                    pinned ? "opacity-90" : "cursor-grab hover:bg-secondary/50 active:cursor-grabbing",
                    dragging === c.key && "bg-secondary",
                  )}
                >
                  <span className="flex min-w-0 items-center gap-2">
                    {pinned ? (
                      <Pin className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                    ) : (
                      <GripVertical className="h-3.5 w-3.5 shrink-0 text-muted-foreground/60" />
                    )}
                    <span className="truncate text-xs font-medium text-foreground">{c.label}</span>
                    {pinned && (
                      <span className="shrink-0 rounded-full bg-secondary px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wide text-muted-foreground">
                        Pinned
                      </span>
                    )}
                  </span>
                  <Toggle
                    value={pinned ? true : c.visible}
                    disabled={pinned}
                    onChange={(v) => setVisible(c.key, v)}
                  />
                </div>
              );
            })}
          </div>
        </div>

        <div className="flex items-center justify-end gap-2 border-t border-border px-5 py-3">
          {save.isError && (
            <span className="mr-auto text-[11px] text-rose-500">Save failed — try again.</span>
          )}
          <button
            onClick={onClose}
            className="rounded-xl border border-border px-3 py-2 text-xs font-medium text-foreground transition-colors hover:bg-secondary"
          >
            Cancel
          </button>
          <button
            onClick={() => save.mutate()}
            disabled={save.isPending}
            className="btn-brand inline-flex items-center gap-1.5 px-3 py-2 text-xs disabled:opacity-60"
          >
            {save.isPending ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <Save className="h-3.5 w-3.5" />
            )}
            Save
          </button>
        </div>
      </div>
    </div>
  );
}
