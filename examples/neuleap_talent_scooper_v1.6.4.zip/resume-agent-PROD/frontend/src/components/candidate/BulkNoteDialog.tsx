// Bulk apply a note (yellow, internal) or remark (blue, interviewer-visible)
// to every selected candidate at once — one text stamped on all, each becoming
// that candidate's latest and each logged to the Actions Audit Log (bulk).
import { useEffect, useState } from "react";
import { Loader2, StickyNote, X } from "lucide-react";
import { NOTE_MAX_CHARS } from "@/components/candidate/CandidateNote";

export default function BulkNoteDialog({
  open,
  kind,
  count,
  pending,
  onCancel,
  onApply,
}: {
  open: boolean;
  kind: "note" | "remark";
  count: number;
  pending?: boolean;
  onCancel: () => void;
  onApply: (text: string) => void;
}) {
  const [text, setText] = useState("");
  useEffect(() => {
    if (open) setText("");
  }, [open]);
  if (!open) return null;
  const isRemark = kind === "remark";
  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center bg-foreground/40 p-4 backdrop-blur-sm"
      onClick={() => !pending && onCancel()}
    >
      <div
        className="w-full max-w-md rounded-2xl border border-border bg-card p-5 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <span
              className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full ${isRemark ? "bg-sky-400/20 text-sky-600" : "bg-amber-400/20 text-amber-600"}`}
            >
              <StickyNote className="h-4.5 w-4.5" />
            </span>
            <div>
              <h3 className="text-sm font-bold text-foreground">
                Add {isRemark ? "remark" : "note"} to {count} candidate{count === 1 ? "" : "s"}
              </h3>
              <p className="text-[11px] text-muted-foreground">
                {isRemark
                  ? "Visible to the interviewer · blue badge by the name"
                  : "Internal · yellow badge by the name"}
              </p>
            </div>
          </div>
          <button
            onClick={onCancel}
            className="rounded-lg p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value.slice(0, NOTE_MAX_CHARS))}
          rows={4}
          autoFocus
          maxLength={NOTE_MAX_CHARS}
          placeholder={isRemark ? "One remark for all selected candidates…" : "One note for all selected candidates…"}
          className="mt-3 w-full resize-y rounded-lg border border-border bg-background px-2.5 py-1.5 text-xs text-foreground outline-none focus:border-primary/50"
        />
        <p className="mt-1 flex items-center justify-between gap-2 text-[10px] leading-relaxed text-muted-foreground">
          <span>
            The same text becomes the latest {isRemark ? "remark" : "note"} on every selected
            candidate (replacing any previous), logged marked (bulk).
          </span>
          <span className="shrink-0 tabular-nums">{text.length}/{NOTE_MAX_CHARS}</span>
        </p>
        <div className="mt-4 flex justify-end gap-2">
          <button
            type="button"
            onClick={onCancel}
            disabled={pending}
            className="rounded-lg border border-border px-3.5 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-secondary disabled:opacity-40"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={() => onApply(text.trim())}
            disabled={pending || !text.trim()}
            className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3.5 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-primary/90 disabled:opacity-40"
          >
            {pending && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
            Apply to {count}
          </button>
        </div>
      </div>
    </div>
  );
}
