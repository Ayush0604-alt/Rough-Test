import { useEffect, useRef, useState } from "react";
import {
  X,
  Loader2,
  AlertTriangle,
  Sparkles,
  RefreshCw,
  ChevronDown,
  Lightbulb,
  CornerDownRight,
  Download,
  Layers,
  Briefcase,
  Wrench,
  Copy,
  Check,
  ClipboardPlus,
  Feather,
  Gauge,
  Dumbbell,
  Globe,
  Sliders,
  ExternalLink,
  Library,
  Users,
  Plus,
} from "lucide-react";
import {
  interviewService,
  INTERVIEW_MODE_OPTIONS,
  MODE_BUCKET_LABEL,
  type InterviewEffort,
  type InterviewKit,
  type InterviewMode,
  type InterviewOptions,
  type InterviewQuestion,
} from "@/services/interview";
import { cn, formatScore } from "@/lib/utils";

interface Props {
  open: boolean;
  candidateId: string;
  onClose: () => void;
  // Modes/focus pre-selected before the panel opened (e.g. via the "Generate
  // Interview Questions" dropdown) — combined into every subsequent
  // Regenerate/Focus/difficulty call since those all spread the current opts.
  initialOptions?: InterviewOptions;
  // Overrides how a kit is fetched — defaults to the recruiter's authenticated
  // `interviewService.generate(candidateId, opts)`. Pass this to route through
  // a different auth surface (e.g. the interviewer's session-gated endpoint)
  // without duplicating this whole panel.
  fetchFn?: (opts: InterviewOptions) => Promise<InterviewKit>;
  // When provided, each question gets a select checkbox and a footer action
  // sends the checked ones back to the caller (e.g. the interviewer's
  // feedback sheet, so the candidate's actual response can be recorded
  // against the exact question that was asked).
  onUseQuestions?: (questions: { bucket: string; question: string }[]) => void;
  // When set, "Add to question bank" defaults the name to the NEXT version of
  // this base (e.g. customising "Michael Jackson - Thriller" → "… II"), instead
  // of a fresh suggested legend name.
  bankNameBase?: string;
  // Called after a bank is saved (so a host page can refresh its list).
  onSaved?: () => void;
  // When provided, the panel shows THESE exact questions on open instead of
  // generating a fresh kit (used by "Customize" to load a saved bank verbatim,
  // with its config). The user can still Regenerate; saving always creates a NEW
  // bank (a versioned name via bankNameBase), never overwrites the original.
  initialKit?: InterviewKit | null;
}

const DIFF_CLS: Record<string, string> = {
  Easy: "text-emerald-600 bg-emerald-500/10 border-emerald-500/30",
  Medium: "text-blue-600 bg-blue-500/10 border-blue-500/30",
  Hard: "text-amber-600 bg-amber-500/10 border-amber-500/30",
  "Very Hard": "text-rose-600 bg-rose-500/10 border-rose-500/30",
};

function QuestionCard({
  q,
  selected,
  onToggleSelect,
}: {
  q: InterviewQuestion;
  selected?: boolean;
  onToggleSelect?: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(q.question);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      // clipboard permission denied — button just stays as "Copy"
    }
  };

  return (
    <div className="rounded-xl border border-border bg-card p-3.5">
      <div className="flex items-start gap-2.5">
        {onToggleSelect && (
          <button
            type="button"
            onClick={onToggleSelect}
            className={cn(
              "mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded border transition-colors",
              selected ? "border-primary bg-primary text-white" : "border-border"
            )}
          >
            {selected && <Check className="h-3 w-3" />}
          </button>
        )}
        <p className="flex-1 text-sm font-medium text-foreground leading-snug">{q.question}</p>
        <span
          className={cn(
            "shrink-0 rounded-full border px-2 py-0.5 text-[10px] font-semibold",
            DIFF_CLS[q.difficulty] ?? DIFF_CLS.Medium
          )}
        >
          {q.difficulty}
        </span>
      </div>
      <div className="mt-1.5 flex items-start gap-1.5 text-[11px] text-muted-foreground">
        <Lightbulb className="mt-0.5 h-3 w-3 shrink-0 text-amber-500" />
        <span>{q.why}</span>
      </div>
      <div className="mt-2 flex items-center gap-3">
        <button
          onClick={() => setOpen((v) => !v)}
          className="inline-flex items-center gap-1 text-[11px] font-medium text-primary hover:underline"
        >
          <ChevronDown className={cn("h-3 w-3 transition-transform", open && "rotate-180")} />
          {open ? "Hide" : "Show"} ideal answer
        </button>
        <button
          onClick={copy}
          title="Copy this question — e.g. to paste into a Teams chat while interviewing"
          className="inline-flex items-center gap-1 text-[11px] font-medium text-muted-foreground hover:text-foreground"
        >
          {copied ? <Check className="h-3 w-3 text-emerald-500" /> : <Copy className="h-3 w-3" />}
          {copied ? "Copied" : "Copy"}
        </button>
      </div>
      {open && (
        <div className="mt-2 space-y-2 border-t border-border/60 pt-2">
          <div>
            <div className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
              A strong answer covers
            </div>
            <p className="mt-0.5 text-xs text-foreground/90">{q.strong_answer}</p>
          </div>
          {q.hints && q.hints.length > 0 && (
            <div>
              <div className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                Hints
              </div>
              <ul className="mt-0.5 space-y-0.5">
                {q.hints.map((h, i) => (
                  <li key={i} className="flex items-start gap-1.5 text-xs text-foreground/90">
                    <Lightbulb className="mt-0.5 h-3 w-3 shrink-0 text-amber-500" />
                    <span>{h}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
          {q.answer_points && q.answer_points.length > 0 && (
            <div>
              <div className="flex items-center justify-between">
                <div className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                  Scoring rubric
                </div>
                <span className="text-[10px] font-semibold text-muted-foreground">
                  out of {q.answer_points.reduce((s, p) => s + (p.marks || 0), 0)}
                </span>
              </div>
              <ul className="mt-0.5 space-y-1">
                {q.answer_points.map((p, i) => (
                  <li key={i} className="flex items-start gap-2 text-xs">
                    <span className="mt-px shrink-0 rounded bg-emerald-500/10 px-1.5 py-0.5 text-[10px] font-bold text-emerald-600">
                      +{p.marks}
                    </span>
                    <span className="text-foreground/90">{p.point}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
          {q.explanation && (
            <div>
              <div className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                Explanation
              </div>
              <p className="mt-0.5 text-xs text-foreground/90">{q.explanation}</p>
            </div>
          )}
          {q.follow_up && (
            <div className="flex items-start gap-1.5 text-xs text-muted-foreground">
              <CornerDownRight className="mt-0.5 h-3 w-3 shrink-0 text-violet-500" />
              <span>
                <span className="font-medium text-foreground">Follow-up: </span>
                {q.follow_up}
              </span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

const EFFORT_OPTIONS: { key: InterviewEffort; label: string; icon: typeof Feather }[] = [
  { key: "lighter", label: "Lighter", icon: Feather },
  { key: "medium", label: "Medium", icon: Gauge },
  { key: "harder", label: "Harder", icon: Dumbbell },
];

const selKey = (bucket: string, question: string) => `${bucket}::${question}`;

// The standard kit sections (before any opt-in aptitude modes). The "Projects"
// bucket becomes "Problem Solving" when generating a generic (cohort) kit — see
// the backend _generic_buckets / valid_sections.
const BASE_SECTIONS = [
  "Fundamentals", "Projects", "Role Fit",
  "Debugging & Troubleshooting", "Behavioral & Ownership", "Advanced Follow-up",
];
const BASE_SECTIONS_GENERIC = [
  "Fundamentals", "Problem Solving", "Role Fit",
  "Debugging & Troubleshooting", "Behavioral & Ownership", "Advanced Follow-up",
];

const MIX_COLORS = [
  "#6366f1", "#8b5cf6", "#ec4899", "#f59e0b", "#10b981",
  "#0ea5e9", "#ef4444", "#14b8a6", "#a855f7", "#f97316",
];
const MIX_TOTAL = 14; // approx total questions, for the per-section count preview

// Per-section difficulty level bubbles — click cycles B → I → E → A → B. Fed to
// the generator so each section's questions are pitched at that level.
type SectionLevel = "B" | "I" | "E" | "A";
const LEVEL_ORDER: SectionLevel[] = ["B", "I", "E", "A"];
const LEVEL_META: Record<SectionLevel, { name: string; cls: string; text: string }> = {
  B: { name: "Beginner", cls: "border-emerald-500/50 bg-emerald-500/15 text-emerald-600", text: "text-emerald-600" },
  I: { name: "Intermediate", cls: "border-sky-500/50 bg-sky-500/15 text-sky-600", text: "text-sky-600" },
  E: { name: "Expert", cls: "border-amber-500/50 bg-amber-500/15 text-amber-600", text: "text-amber-600" },
  A: { name: "Advanced", cls: "border-rose-500/50 bg-rose-500/15 text-rose-600", text: "text-rose-600" },
};
const nextLevel = (l: SectionLevel): SectionLevel =>
  LEVEL_ORDER[(LEVEL_ORDER.indexOf(l) + 1) % LEVEL_ORDER.length];

/**
 * Question-packaging control — an interactive stacked "mix" bar. Each section is
 * a segment whose WIDTH is its share of the total questions; drag the dividers
 * between segments to move share from one section to its neighbour. It replaces a
 * column of sliders with one direct, spatial control that shows the whole
 * composition (and the resulting per-section question counts) at a glance.
 */
function QuestionMixBar({
  sections,
  weights,
  onChange,
  levels,
  onLevelChange,
  total = MIX_TOTAL,
}: {
  sections: { key: string; label: string }[];
  weights: Record<string, number>;
  onChange: (next: Record<string, number>) => void;
  levels: Record<string, SectionLevel>;
  onLevelChange: (key: string, level: SectionLevel) => void;
  total?: number;
}) {
  const barRef = useRef<HTMLDivElement>(null);
  const dragging = useRef<number | null>(null);
  const MIN_SHARE = 0.06;

  const w = sections.map((s) => Math.max(0.0001, weights[s.key] ?? 2));
  const sum = w.reduce((a, b) => a + b, 0) || 1;
  const shares = w.map((x) => x / sum);

  const startDrag = (i: number) => (e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    dragging.current = i;
    barRef.current?.setPointerCapture(e.pointerId);
  };
  const onMove = (e: React.PointerEvent) => {
    const i = dragging.current;
    if (i === null || !barRef.current) return;
    const rect = barRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width;
    const before = shares.slice(0, i).reduce((a, b) => a + b, 0);
    const pair = shares[i] + shares[i + 1];
    const newI = Math.min(Math.max(x - before, MIN_SHARE), pair - MIN_SHARE);
    const next = [...shares];
    next[i] = newI;
    next[i + 1] = pair - newI;
    const nextWeights: Record<string, number> = { ...weights };
    sections.forEach((s, idx) => {
      nextWeights[s.key] = +(next[idx] * sum).toFixed(3);
    });
    onChange(nextWeights);
  };
  const endDrag = (e: React.PointerEvent) => {
    dragging.current = null;
    try { barRef.current?.releasePointerCapture(e.pointerId); } catch { /* noop */ }
  };

  return (
    <div className="space-y-2">
      <div
        ref={barRef}
        onPointerMove={onMove}
        onPointerUp={endDrag}
        className="relative flex h-10 w-full select-none overflow-hidden rounded-lg border border-border bg-secondary/40"
      >
        {sections.map((s, i) => {
          const color = MIX_COLORS[i % MIX_COLORS.length];
          const count = Math.max(1, Math.round(shares[i] * total));
          return (
            <div
              key={s.key}
              className="relative flex min-w-0 flex-col items-center justify-center px-1 text-center"
              style={{ width: `${shares[i] * 100}%`, backgroundColor: `${color}22` }}
              title={`${s.label} · about ${count} question${count === 1 ? "" : "s"}`}
            >
              <span className="w-full truncate text-[9px] font-semibold leading-tight" style={{ color }}>
                {s.label}
              </span>
              <span className="text-[9px] tabular-nums text-muted-foreground">{count}</span>
              {i < sections.length - 1 && (
                <div
                  onPointerDown={startDrag(i)}
                  className="absolute right-0 top-0 z-10 flex h-full w-3 translate-x-1/2 cursor-col-resize items-center justify-center"
                >
                  <span className="h-5 w-0.5 rounded-full bg-foreground/40" />
                </div>
              )}
            </div>
          );
        })}
      </div>
      {/* Per-section level bubbles — aligned under each section; click to cycle
          Beginner → Intermediate → Expert → Advanced. */}
      <div className="flex w-full">
        {sections.map((s, i) => {
          const lvl: SectionLevel = levels[s.key] ?? "I";
          const meta = LEVEL_META[lvl];
          return (
            <div key={s.key} className="flex min-w-0 justify-center px-0.5" style={{ width: `${shares[i] * 100}%` }}>
              <button
                type="button"
                onClick={() => onLevelChange(s.key, nextLevel(lvl))}
                title={`${s.label}: ${meta.name} — click to change level (B→I→E→A)`}
                className={cn(
                  "flex h-5 w-5 shrink-0 items-center justify-center rounded-full border text-[10px] font-bold leading-none transition-colors hover:brightness-95",
                  meta.cls
                )}
              >
                {lvl}
              </button>
            </div>
          );
        })}
      </div>
      <p className="text-[10px] text-muted-foreground">
        Drag a divider to shift how many questions come from each section. The bubble under a
        section (and the <b>[ ]</b> on each module below) sets its level — <b>B</b>-Beginner,{" "}
        <b>I</b>-Intermediate, <b>E</b>-Expert, <b>A</b>-Advanced (click to cycle). Counts are
        approximate (total ≈ {total}); press Apply to regenerate.
      </p>
    </div>
  );
}

export default function InterviewQuestionsPanel({
  open,
  candidateId,
  onClose,
  initialOptions,
  fetchFn,
  onUseQuestions,
  bankNameBase,
  onSaved,
  initialKit,
}: Props) {
  const [kit, setKit] = useState<InterviewKit | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [opts, setOpts] = useState<InterviewOptions>({});
  const [selected, setSelected] = useState<Set<string>>(new Set());
  // Config-driven modes (Settings) so custom types show their label + map to
  // the right composition bucket; falls back to the built-in defaults.
  const [modeCfg, setModeCfg] = useState<{ key: string; label: string; bucket_name: string }[]>([]);
  useEffect(() => {
    if (!open) return;
    interviewService
      .getModes()
      .then((r) => setModeCfg(r.data.map((m) => ({ key: m.key, label: m.label, bucket_name: m.bucket_name }))))
      .catch(() => {});
  }, [open]);
  const modeLabel = (key: string) =>
    modeCfg.find((m) => m.key === key)?.label ??
    INTERVIEW_MODE_OPTIONS.find((o) => o.key === key)?.label ??
    key;
  const modeBucket = (key: string) =>
    modeCfg.find((m) => m.key === key)?.bucket_name ??
    MODE_BUCKET_LABEL[key as InterviewMode] ??
    key;

  // Collapse the top controls to give the packaged questions more room.
  const [controlsOpen, setControlsOpen] = useState(true);

  // Save-as-question-bank flow — only offered on a generic (avoid-personalization)
  // kit, which is what makes a bank reusable across a cohort.
  const [bankOpen, setBankOpen] = useState(false);
  const [bankName, setBankName] = useState("");
  const [bankBusy, setBankBusy] = useState(false);
  const [bankError, setBankError] = useState<string | null>(null);
  const [bankSaved, setBankSaved] = useState<string | null>(null);

  // Every section the composition/packaging control covers: the standard kit
  // sections (generic vs profile-anchored) PLUS any selected aptitude modes.
  const allSections = (() => {
    const base = opts.avoid_personalization ? BASE_SECTIONS_GENERIC : BASE_SECTIONS;
    const out: { key: string; label: string }[] = base.map((n) => ({ key: n, label: n }));
    (opts.modes ?? []).forEach((m) => {
      const key = modeBucket(m);
      if (!out.some((s) => s.key === key)) out.push({ key, label: modeLabel(m) });
    });
    return out;
  })();
  const excludedSet = new Set(opts.exclude_sections ?? []);
  // Sections actually in the mix (the bar shows these); excluded ones are set
  // aside via the toggles below the bar.
  const mixSections = allSections.filter((s) => !excludedSet.has(s.key));
  const mixTotal = opts.total_questions ?? MIX_TOTAL;
  const setTotal = (n: number) =>
    setOpts((o) => ({ ...o, total_questions: Math.max(3, Math.min(40, n)) }));
  const toggleExclude = (key: string) =>
    setOpts((o) => {
      const cur = new Set(o.exclude_sections ?? []);
      if (cur.has(key)) cur.delete(key);
      // Never let the recruiter exclude every section — keep at least one.
      else if (allSections.filter((s) => !cur.has(s.key)).length > 1) cur.add(key);
      return { ...o, exclude_sections: [...cur] };
    });

  const load = (next: InterviewOptions) => {
    setLoading(true);
    setError(null);
    setOpts(next);
    setSelected(new Set());
    const generate = fetchFn ?? ((o: InterviewOptions) => interviewService.generate(candidateId, o).then((r) => r.data));
    generate(next)
      .then((data) => setKit(data))
      .catch((e) =>
        setError(e?.response?.data?.detail ?? e?.message ?? "Generation failed")
      )
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    if (open) {
      if (initialKit) {
        // Customize: show the saved kit verbatim (its exact questions + config),
        // no regeneration. Regenerate/Focus/difficulty still generate afresh.
        setKit(initialKit);
        setOpts(initialOptions ?? {});
        setSelected(new Set());
        setLoading(false);
        setError(null);
      } else {
        load(initialOptions ?? {});
      }
    } else {
      setKit(null);
      setError(null);
      setOpts({});
      setSelected(new Set());
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, candidateId]);

  if (!open) return null;

  const addSelectedToFeedback = () => {
    if (!kit || !onUseQuestions || selected.size === 0) return;
    const chosen: { bucket: string; question: string }[] = [];
    kit.buckets.forEach((b) => {
      b.questions.forEach((q) => {
        if (selected.has(selKey(b.name, q.question))) chosen.push({ bucket: b.name, question: q.question });
      });
    });
    onUseQuestions(chosen);
    setSelected(new Set());
  };

  const exportTxt = () => {
    if (!kit) return;
    const lines: string[] = [
      `Interview Kit — ${kit.summary.name}`,
      `${kit.summary.stream ?? ""} · ATS ${formatScore(kit.summary.atsscore)} · ${kit.summary.experience_type} · ${kit.summary.difficulty}`,
      "",
    ];
    kit.buckets.forEach((b) => {
      lines.push(`## ${b.name}`);
      b.questions.forEach((q, i) => {
        lines.push(`${i + 1}. [${q.difficulty}] ${q.question}`);
        lines.push(`   Why: ${q.why}`);
        lines.push(`   Strong answer: ${q.strong_answer}`);
        (q.hints ?? []).forEach((h) => lines.push(`   Hint: ${h}`));
        if (q.answer_points && q.answer_points.length > 0) {
          const max = q.answer_points.reduce((s, p) => s + (p.marks || 0), 0);
          lines.push(`   Rubric (out of ${max}):`);
          q.answer_points.forEach((p) => lines.push(`     +${p.marks}  ${p.point}`));
        }
        if (q.explanation) lines.push(`   Explanation: ${q.explanation}`);
        if (q.follow_up) lines.push(`   Follow-up: ${q.follow_up}`);
      });
      lines.push("");
    });
    const blob = new Blob([lines.join("\n")], { type: "text/plain" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `interview-kit-${candidateId}.txt`;
    a.click();
  };

  const openSaveBank = async () => {
    setBankError(null);
    setBankSaved(null);
    setBankOpen(true);
    setBankName("");
    try {
      // Customising an existing bank → keep its name and bump the version;
      // otherwise suggest a fresh legend name fitted to the kit's character.
      const { data } = bankNameBase
        ? await interviewService.nextVersionName(bankNameBase)
        : await interviewService.suggestBankName({
            difficulty: kit?.summary.difficulty,
            stream: kit?.summary.stream,
            modes: opts.modes ?? [],
          });
      setBankName(data.name);
    } catch {
      // Leave the field empty for the recruiter to name it themselves.
    }
  };

  const confirmSaveBank = async () => {
    if (!kit) return;
    const name = bankName.trim();
    if (!name) {
      setBankError("Give the question bank a name.");
      return;
    }
    setBankBusy(true);
    setBankError(null);
    try {
      await interviewService.saveBank({
        name,
        stream: kit.summary.stream,
        difficulty: kit.summary.difficulty,
        modes: opts.modes ?? [],
        buckets: kit.buckets,
        summary: kit.summary,
        sources: kit.sources ?? [],
        // Persist the exact composition + settings so Customize restores them 1:1.
        options: opts,
      });
      setBankSaved(name);
      setBankOpen(false);
      onSaved?.();
    } catch (e) {
      const detail = (e as { response?: { data?: { detail?: string } } })?.response?.data?.detail;
      setBankError(detail ?? "Couldn't save the question bank.");
    } finally {
      setBankBusy(false);
    }
  };

  const controls: { label: string; icon: typeof Layers; next: InterviewOptions }[] = [
    { label: "Regenerate", icon: RefreshCw, next: opts },
    { label: "Make easier", icon: ChevronDown, next: { ...opts, difficulty_bias: "easier" } },
    { label: "Make harder", icon: ChevronDown, next: { ...opts, difficulty_bias: "harder" } },
    { label: "Focus: Projects", icon: Layers, next: { ...opts, focus: "projects" } },
    { label: "Focus: Experience", icon: Briefcase, next: { ...opts, focus: "experience" } },
    { label: "Focus: System design", icon: Wrench, next: { ...opts, focus: "system_design" } },
  ];

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-foreground/40 backdrop-blur-sm">
      <div className="glass-panel flex h-full w-full max-w-xl flex-col border-y-0 border-r-0 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-border px-5 py-4">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl gradient-brand">
              <Sparkles className="h-4.5 w-4.5 text-white" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-foreground">Interview Questions</h2>
              <p className="text-[11px] text-muted-foreground">
                Context-aware kit · {candidateId}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-muted-foreground hover:bg-secondary hover:text-foreground"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Summary + controls */}
        {kit && !loading && (
          <div className="border-b border-border">
            {/* Slim identity bar — always visible; the Controls toggle collapses
                everything below it so the packaged questions get the full height. */}
            <div className="flex items-center gap-2 px-5 py-2.5">
              <span className="truncate text-sm font-semibold text-foreground">{kit.summary.name}</span>
              <span
                className={cn(
                  "shrink-0 rounded-full border px-2 py-0.5 text-[10px] font-semibold",
                  DIFF_CLS[kit.summary.difficulty] ?? DIFF_CLS.Medium
                )}
              >
                {kit.summary.difficulty}
              </span>
              {opts.avoid_personalization && (
                <span
                  className="inline-flex shrink-0 items-center gap-1 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2 py-0.5 text-[10px] font-medium text-emerald-600"
                  title="Generic questions — applies uniformly to a cohort, not personalized to this candidate"
                >
                  <Users className="h-2.5 w-2.5" /> generic
                </span>
              )}
              {onUseQuestions && selected.size > 0 && (
                <button
                  type="button"
                  onClick={addSelectedToFeedback}
                  title="Send the checked questions to the round's feedback sheet"
                  className="ml-auto inline-flex shrink-0 items-center gap-1 rounded-lg border border-primary/30 bg-primary/10 px-2.5 py-1 text-[10px] font-semibold text-primary hover:bg-primary/20"
                >
                  <ClipboardPlus className="h-3 w-3" /> Add {selected.size} to feedback sheet
                </button>
              )}
              <button
                type="button"
                onClick={() => setControlsOpen((v) => !v)}
                title={controlsOpen ? "Hide controls for more room" : "Show controls"}
                className={cn(
                  "inline-flex shrink-0 items-center gap-1 rounded-lg border border-border px-2 py-1 text-[10px] font-semibold text-muted-foreground hover:bg-secondary hover:text-foreground",
                  !(onUseQuestions && selected.size > 0) && "ml-auto"
                )}
              >
                <Sliders className="h-3 w-3" />
                {controlsOpen ? "Hide controls" : "Controls"}
                <ChevronDown className={cn("h-3 w-3 transition-transform", controlsOpen && "rotate-180")} />
              </button>
            </div>

            {controlsOpen ? (
              // Cap the controls' height and scroll internally — with 9+ sections,
              // the mix bar + level bubbles + section pills + effort + actions can
              // exceed the panel, so this keeps everything reachable and leaves the
              // packaged-questions list below usable.
              <div className="max-h-[46vh] space-y-3 overflow-y-auto px-5 pb-3">
                {/* Profile chips */}
                <div className="flex flex-wrap items-center gap-2 text-xs">
                  {kit.summary.stream && (
                    <span className="rounded-full border border-border px-2 py-0.5 text-[11px] text-muted-foreground">
                      {kit.summary.stream}
                    </span>
                  )}
                  <span className="rounded-full border border-border px-2 py-0.5 text-[11px] text-muted-foreground">
                    ATS {formatScore(kit.summary.atsscore)}
                  </span>
                  <span className="rounded-full border border-border px-2 py-0.5 text-[11px] text-muted-foreground">
                    {kit.summary.experience_type}
                  </span>
                  {kit.generated_by === "fallback" && (
                    <span className="rounded-full border border-amber-500/30 bg-amber-500/10 px-2 py-0.5 text-[10px] text-amber-600">
                      offline kit
                    </span>
                  )}
                </div>

                {/* Selected aptitude modes */}
                {opts.modes && opts.modes.length > 0 && (
                  <div className="flex flex-wrap gap-1.5">
                    {opts.modes.map((m) => (
                      <span
                        key={m}
                        className="rounded-full border border-violet-500/30 bg-violet-500/10 px-2 py-0.5 text-[10px] font-medium text-violet-600"
                      >
                        + {modeLabel(m)}
                      </span>
                    ))}
                  </div>
                )}

                {/* Search the web — only meaningful when aptitude modes are on. */}
                {opts.modes && opts.modes.length > 0 && (
                  <label className="flex items-center gap-2 rounded-lg border border-border/60 bg-secondary/20 px-3 py-2 text-[11px] text-foreground">
                    <input
                      type="checkbox"
                      checked={!!opts.search_web}
                      onChange={(e) =>
                        load({ ...opts, search_web: e.target.checked, variant: (opts.variant ?? 0) + 1 })
                      }
                      className="h-3.5 w-3.5 rounded border-border accent-primary"
                    />
                    <Globe className="h-3.5 w-3.5 text-sky-600" />
                    <span className="font-medium">Search the web</span>
                    <span className="text-muted-foreground">
                      — ground the selected sections in popular online resources
                    </span>
                  </label>
                )}

                {/* Question packaging — total count, per-section mix, and which
                    sections to include. */}
                <div className="space-y-2 rounded-lg border border-border/60 bg-secondary/20 px-3 py-2.5">
                  <div className="flex items-center justify-between gap-2">
                    <span className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                      <Sliders className="h-3 w-3" /> Question packaging — mix per section
                    </span>
                    {((opts.mode_weights && Object.keys(opts.mode_weights).length > 0) ||
                      opts.total_questions != null ||
                      (opts.exclude_sections?.length ?? 0) > 0) && (
                      <button
                        type="button"
                        onClick={() =>
                          setOpts((o) => ({ ...o, mode_weights: undefined, total_questions: undefined, exclude_sections: undefined, section_levels: undefined }))
                        }
                        className="text-[10px] font-medium text-muted-foreground hover:text-foreground"
                      >
                        Reset mix
                      </button>
                    )}
                  </div>

                  {/* Total questions stepper */}
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-medium text-muted-foreground">Total questions</span>
                    <div className="flex items-center overflow-hidden rounded-lg border border-border">
                      <button
                        type="button"
                        onClick={() => setTotal(mixTotal - 1)}
                        disabled={mixTotal <= 3}
                        className="px-2 py-1 text-xs font-bold text-muted-foreground hover:bg-secondary disabled:opacity-40"
                      >
                        −
                      </button>
                      <span className="w-8 text-center text-xs font-semibold tabular-nums text-foreground">{mixTotal}</span>
                      <button
                        type="button"
                        onClick={() => setTotal(mixTotal + 1)}
                        disabled={mixTotal >= 40}
                        className="px-2 py-1 text-xs font-bold text-muted-foreground hover:bg-secondary disabled:opacity-40"
                      >
                        +
                      </button>
                    </div>
                    <span className="text-[10px] text-muted-foreground">across {mixSections.length} section{mixSections.length === 1 ? "" : "s"}</span>
                  </div>

                  {mixSections.length > 0 && (
                    <QuestionMixBar
                      sections={mixSections}
                      weights={opts.mode_weights ?? {}}
                      total={mixTotal}
                      onChange={(w) => setOpts((o) => ({ ...o, mode_weights: w }))}
                      levels={(opts.section_levels ?? {}) as Record<string, SectionLevel>}
                      onLevelChange={(key, level) =>
                        setOpts((o) => ({ ...o, section_levels: { ...(o.section_levels ?? {}), [key]: level } }))
                      }
                    />
                  )}

                  {/* Include / exclude a section */}
                  <div className="flex flex-wrap gap-1">
                    {allSections.map((s) => {
                      const off = excludedSet.has(s.key);
                      const lvl = (opts.section_levels?.[s.key] ?? "I") as SectionLevel;
                      return (
                        <button
                          key={s.key}
                          type="button"
                          onClick={() => toggleExclude(s.key)}
                          title={off ? "Excluded — click to include" : "Included — click to exclude this section"}
                          className={cn(
                            "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-medium transition-colors",
                            off
                              ? "border-border bg-transparent text-muted-foreground line-through opacity-60"
                              : "border-primary/30 bg-primary/10 text-primary"
                          )}
                        >
                          {off ? <Plus className="h-2.5 w-2.5" /> : <X className="h-2.5 w-2.5" />}
                          {s.label}
                          {!off && (
                            <span
                              role="button"
                              tabIndex={0}
                              onClick={(e) => {
                                e.stopPropagation();
                                setOpts((o) => ({
                                  ...o,
                                  section_levels: {
                                    ...(o.section_levels ?? {}),
                                    [s.key]: nextLevel((o.section_levels?.[s.key] ?? "I") as SectionLevel),
                                  },
                                }));
                              }}
                              title={`Level: ${LEVEL_META[lvl].name} — click to cycle (B→I→E→A)`}
                              className={cn("ml-0.5 font-bold no-underline", LEVEL_META[lvl].text)}
                            >
                              [{lvl}]
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      // Round the drag-derived shares to small integer weights (>=1)
                      // so no section is floored to zero server-side, and drop any
                      // weights for now-excluded sections.
                      const mw = opts.mode_weights;
                      const rounded = mw
                        ? Object.fromEntries(
                            Object.entries(mw)
                              .filter(([k]) => !excludedSet.has(k))
                              .map(([k, v]) => [k, Math.max(1, Math.round(v))])
                          )
                        : undefined;
                      load({ ...opts, mode_weights: rounded, variant: (opts.variant ?? 0) + 1 });
                    }}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-2.5 py-1 text-[11px] font-semibold text-white transition-colors hover:bg-primary/90"
                  >
                    <RefreshCw className="h-3 w-3" /> Apply composition
                  </button>
                </div>

                {/* Effort — independent of "difficulty": how much hands-on WORK
                    answering takes, not how conceptually hard it is. */}
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Effort</span>
                  <div className="flex overflow-hidden rounded-lg border border-border">
                    {EFFORT_OPTIONS.map(({ key, label, icon: Icon }, i) => {
                      const active = (opts.effort ?? "lighter") === key;
                      return (
                        <button
                          key={key}
                          onClick={() => load({ ...opts, effort: key, variant: (opts.variant ?? 0) + 1 })}
                          title={
                            key === "lighter"
                              ? "Quick, conversational questions (today's default)"
                              : key === "medium"
                                ? "A short exercise the candidate works through live"
                                : "A real task to derive/build over several minutes, then present back"
                          }
                          className={cn(
                            "inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium transition-colors",
                            i > 0 && "border-l border-border",
                            active ? "bg-primary/10 text-primary" : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                          )}
                        >
                          <Icon className="h-3 w-3" />
                          {label}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Action buttons */}
                <div className="flex flex-wrap gap-1.5">
                  {controls.map(({ label, icon: Icon, next }) => (
                    <button
                      key={label}
                      // Bump the variant on every press so the same options still yield a
                      // fresh kit — otherwise Regenerate (and repeat presses) are no-ops.
                      onClick={() => load({ ...next, variant: (opts.variant ?? 0) + 1 })}
                      className="inline-flex items-center gap-1 rounded-lg border border-border px-2.5 py-1 text-[11px] font-medium text-muted-foreground hover:bg-secondary hover:text-foreground"
                    >
                      <Icon className="h-3 w-3" />
                      {label}
                    </button>
                  ))}
                  <button
                    onClick={exportTxt}
                    className="inline-flex items-center gap-1 rounded-lg border border-border px-2.5 py-1 text-[11px] font-medium text-muted-foreground hover:bg-secondary hover:text-foreground"
                  >
                    <Download className="h-3 w-3" /> Export
                  </button>
                  {opts.avoid_personalization && (
                    <button
                      onClick={openSaveBank}
                      title="Save this generic set as a reusable question bank for a cohort"
                      className="inline-flex items-center gap-1 rounded-lg border border-emerald-500/30 bg-emerald-500/10 px-2.5 py-1 text-[11px] font-semibold text-emerald-600 hover:bg-emerald-500/20"
                    >
                      <Library className="h-3 w-3" /> Add to question bank
                    </button>
                  )}
                </div>
                {onUseQuestions && (
                  <p className="text-[10px] text-muted-foreground">
                    Check questions below — an <b className="text-foreground">Add to feedback sheet</b> button appears at
                    the top once you do, where the checked questions go so you can record the candidate's response.
                  </p>
                )}
              </div>
            ) : (
              /* Collapsed — a slim strip keeps the core actions reachable. */
              <div className="flex flex-wrap gap-1.5 px-5 pb-2.5">
                <button
                  onClick={() => load({ ...opts, variant: (opts.variant ?? 0) + 1 })}
                  className="inline-flex items-center gap-1 rounded-lg border border-border px-2.5 py-1 text-[11px] font-medium text-muted-foreground hover:bg-secondary hover:text-foreground"
                >
                  <RefreshCw className="h-3 w-3" /> Regenerate
                </button>
                <button
                  onClick={exportTxt}
                  className="inline-flex items-center gap-1 rounded-lg border border-border px-2.5 py-1 text-[11px] font-medium text-muted-foreground hover:bg-secondary hover:text-foreground"
                >
                  <Download className="h-3 w-3" /> Export
                </button>
                {opts.avoid_personalization && (
                  <button
                    onClick={openSaveBank}
                    className="inline-flex items-center gap-1 rounded-lg border border-emerald-500/30 bg-emerald-500/10 px-2.5 py-1 text-[11px] font-semibold text-emerald-600 hover:bg-emerald-500/20"
                  >
                    <Library className="h-3 w-3" /> Add to question bank
                  </button>
                )}
                {onUseQuestions && (
                  <button
                    onClick={addSelectedToFeedback}
                    disabled={selected.size === 0}
                    className="inline-flex items-center gap-1 rounded-lg border border-primary/30 bg-primary/10 px-2.5 py-1 text-[11px] font-semibold text-primary hover:bg-primary/20 disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    <ClipboardPlus className="h-3 w-3" />
                    Add {selected.size > 0 ? selected.size : ""} to feedback sheet
                  </button>
                )}
              </div>
            )}
          </div>
        )}

        {/* Body */}
        <div className="flex-1 overflow-y-auto px-5 py-4">
          {loading && (
            <div className="flex h-full flex-col items-center justify-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="h-6 w-6 animate-spin text-primary" />
              Designing a tailored interview kit…
            </div>
          )}

          {error && !loading && (
            <div className="flex h-full flex-col items-center justify-center gap-3 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-destructive/10">
                <AlertTriangle className="h-6 w-6 text-destructive" />
              </div>
              <div className="text-sm font-semibold text-foreground">Couldn’t generate</div>
              <p className="max-w-xs text-xs text-muted-foreground">{error}</p>
              <button onClick={() => load(opts)} className="btn-brand text-xs px-3 py-2">
                <RefreshCw className="h-3.5 w-3.5" /> Retry
              </button>
            </div>
          )}

          {kit && !loading && !error && (
            <div className="space-y-5">
              {kit.buckets.map((b) => (
                <div key={b.name}>
                  <div className="mb-2 flex items-center gap-2">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-foreground">
                      {b.name}
                    </h3>
                    <span className="text-[10px] text-muted-foreground">
                      {b.questions.length}
                    </span>
                    <div className="h-px flex-1 bg-border" />
                  </div>
                  <div className="space-y-2.5">
                    {b.questions.map((q, i) => (
                      <QuestionCard
                        key={i}
                        q={q}
                        selected={onUseQuestions ? selected.has(selKey(b.name, q.question)) : undefined}
                        onToggleSelect={
                          onUseQuestions
                            ? () =>
                                setSelected((prev) => {
                                  const next = new Set(prev);
                                  const key = selKey(b.name, q.question);
                                  if (next.has(key)) next.delete(key);
                                  else next.add(key);
                                  return next;
                                })
                            : undefined
                        }
                      />
                    ))}
                  </div>
                </div>
              ))}

              {kit.sources && kit.sources.length > 0 && (
                <div className="rounded-lg border border-sky-500/20 bg-sky-500/5 px-3 py-2.5">
                  <div className="mb-1.5 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wide text-sky-700 dark:text-sky-400">
                    <Globe className="h-3 w-3" /> Prepared using these web sources
                  </div>
                  <ul className="space-y-1">
                    {kit.sources.map((s, i) => (
                      <li key={i} className="flex items-start gap-1.5 text-[11px]">
                        <span className="mt-0.5 shrink-0 rounded bg-sky-500/10 px-1 text-[9px] font-semibold text-sky-600">
                          {s.section}
                        </span>
                        <a
                          href={s.url}
                          target="_blank"
                          rel="noreferrer"
                          className="inline-flex min-w-0 items-center gap-1 truncate text-sky-700 hover:underline dark:text-sky-400"
                          title={s.url}
                        >
                          <span className="truncate">{s.title}</span>
                          <ExternalLink className="h-2.5 w-2.5 shrink-0" />
                        </a>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Saved-to-bank confirmation */}
        {bankSaved && (
          <div className="flex items-center gap-2 border-t border-border bg-emerald-500/5 px-5 py-2.5 text-[11px] text-emerald-700 dark:text-emerald-400">
            <Check className="h-3.5 w-3.5 shrink-0" />
            Saved as question bank <span className="font-semibold">“{bankSaved}”</span>. Assign it to a cohort from the Question Banks page.
            <button
              onClick={() => setBankSaved(null)}
              className="ml-auto rounded px-1.5 py-0.5 text-muted-foreground hover:text-foreground"
            >
              Dismiss
            </button>
          </div>
        )}
      </div>

      {/* Save-as-question-bank modal — names the bank after a classic legend. */}
      {bankOpen && (
        <div
          className="fixed inset-0 z-[60] flex items-center justify-center bg-foreground/40 p-4 backdrop-blur-sm"
          onClick={() => !bankBusy && setBankOpen(false)}
        >
          <div
            className="w-full max-w-sm rounded-2xl border border-border bg-card p-5 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start gap-3">
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-600">
                <Library className="h-4.5 w-4.5" />
              </span>
              <div className="min-w-0">
                <h3 className="text-sm font-bold text-foreground">Save as question bank</h3>
                <p className="mt-1 text-[12px] leading-relaxed text-muted-foreground">
                  This generic set can be reused across a cohort. It's saved under a codename you can
                  keep or change.
                </p>
              </div>
            </div>
            <div className="mt-3">
              <label className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                Question bank name
              </label>
              <input
                autoFocus
                value={bankName}
                onChange={(e) => { setBankName(e.target.value); if (bankError) setBankError(null); }}
                onKeyDown={(e) => e.key === "Enter" && !bankBusy && confirmSaveBank()}
                placeholder="e.g. Charlie Chaplin - The Kid"
                className="mt-1 w-full rounded-lg border border-border bg-secondary px-2.5 py-1.5 text-sm text-foreground outline-none focus:border-primary/50"
              />
              <p className="mt-1.5 text-[10px] text-muted-foreground">
                {kit ? kit.buckets.reduce((n, b) => n + b.questions.length, 0) : 0} questions ·{" "}
                {kit?.summary.stream ?? "all streams"} · {kit?.summary.difficulty}
              </p>
            </div>
            {bankError && <p className="mt-2 text-[11px] font-medium text-rose-500">{bankError}</p>}
            <div className="mt-5 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setBankOpen(false)}
                disabled={bankBusy}
                className="rounded-lg border border-border px-3.5 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-secondary disabled:opacity-40"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmSaveBank}
                disabled={bankBusy || !bankName.trim()}
                className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3.5 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-emerald-700 disabled:opacity-40"
              >
                {bankBusy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
                Save bank
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
