import { Award } from "lucide-react";
import { parseCertificates } from "@/types/candidate";
import type { CandidateMaster } from "@/types";

/** Premium certification cards with issuer/year. */
export default function CertificationCard({ c }: { c: CandidateMaster }) {
  const certs = parseCertificates(c.certificates);
  if (certs.length === 0) {
    return <p className="text-xs text-ink-mute">No certifications extracted.</p>;
  }
  return (
    <div className="space-y-2">
      {certs.map((cert, i) => (
        <div
          key={i}
          className="flex items-start gap-2.5 rounded-xl border border-amber-500/15 bg-amber-400/[0.04] px-3 py-2.5"
        >
          <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-amber-400/15 text-amber-400">
            <Award className="h-3.5 w-3.5" />
          </span>
          <div className="min-w-0">
            <div className="text-xs font-semibold leading-snug text-ink">{cert.name}</div>
            {(cert.issuer || cert.year) && (
              <div className="mt-0.5 text-[10px] text-ink-mute">
                {[cert.issuer, cert.year].filter(Boolean).join(" · ")}
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}
