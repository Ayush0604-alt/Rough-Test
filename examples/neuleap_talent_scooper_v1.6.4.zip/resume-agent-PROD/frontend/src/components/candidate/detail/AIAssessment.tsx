import { Sparkles, Star, ShieldAlert, Route, Gauge } from "lucide-react";
import { cn, formatExperience, formatScore } from "@/lib/utils";
import { streamBadge } from "@/lib/badges";
import type { CandidateMaster, ScoreComponent, ScorePenalty } from "@/types";

function toList(v: string[] | string | null | undefined): string[] {
  if (Array.isArray(v)) return v.map(String).filter(Boolean);
  if (typeof v === "string" && v.trim()) return v.split(" · ").filter(Boolean);
  return [];
}

// JSONB columns arrive as arrays; guard against legacy/null rows.
function asArray<T>(v: T[] | null | undefined): T[] {
  return Array.isArray(v) ? v : [];
}

// Below this ATS score, the breakdown is framed as "why this score is low".
const LOW_ATS = 50;
// A component scoring below this is weak enough to surface as a risk signal.
const WEAK_COMPONENT = 40;

/**
 * Structured intelligence report (replaces the paragraph blob): a role-context lead,
 * recommended track, strengths (from evidence), risk signals (derived from gaps/switches),
 * and the full analysis as a footnote.
 */
export default function AIAssessment({ c }: { c: CandidateMaster }) {
  const evidence = toList(c.evidence_snippets);
  const strengths = evidence.length
    ? evidence
    : [
        c.stream === "GenAI" ? "Strong LLM/RAG stack experience" : "Domain expertise confirmed",
        c.fresher_or_lateral === "Fresher"
          ? "Fresher with strong project portfolio"
          : `${formatExperience(c.yearofexp ?? 0)} relevant experience`,
      ];

  const breakdown = asArray<ScoreComponent>(c.score_breakdown);
  const penalties = asArray<ScorePenalty>(c.score_penalties);
  const cert = c.certification_bonus;
  const hasScore = c.atsscore != null;
  const isLow = hasScore && (c.atsscore as number) < LOW_ATS;

  // Risk signals, strongest first: deterministic ATS penalties (the authoritative
  // "why the score is low"), then weak scoring components, then derived resume risks.
  const risks: string[] = [];
  penalties.forEach((p) => risks.push(`${p.reason} (−${Math.round(p.points)})`));
  breakdown
    .filter((b) => b.subscore < WEAK_COMPONENT)
    .forEach((b) => risks.push(`Weak ${b.component.toLowerCase()} (${Math.round(b.subscore)}/100)`));
  if ((c.gap_count ?? 0) > 0)
    risks.push(`${c.gap_count} career gap${(c.gap_count ?? 0) > 1 ? "s" : ""}${c.gap_months ? ` · ${c.gap_months}mo total` : ""}`);
  if ((c.total_companieswitched ?? 0) >= 3)
    risks.push(`${c.total_companieswitched} company switches — check tenure`);
  if (c.education_status === "pursuing") risks.push("Education still in progress");

  if (!c.analysis && !c.role_context && evidence.length === 0 && !hasScore) {
    return (
      <p className="text-xs italic text-ink-mute">
        AI assessment will appear here once the resume has been analysed.
      </p>
    );
  }

  return (
    <div className="space-y-4">
      {c.role_context && (
        <div className="flex items-start gap-2">
          <Sparkles className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
          <p className="text-sm text-ink">{c.role_context}</p>
        </div>
      )}

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        {/* Strengths */}
        <div>
          <div className="mb-1.5 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wider text-emerald-400">
            <Star className="h-3 w-3" fill="currentColor" /> Strengths
          </div>
          <ul className="space-y-1">
            {strengths.map((s, i) => (
              <li key={i} className="flex items-start gap-1.5 text-[11px] text-ink-mute">
                <span className="mt-1 h-1 w-1 shrink-0 rounded-full bg-emerald-400" />
                {s}
              </li>
            ))}
          </ul>
        </div>

        {/* Risks */}
        <div>
          <div className="mb-1.5 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wider text-amber-400">
            <ShieldAlert className="h-3 w-3" /> Risk signals
          </div>
          {risks.length ? (
            <ul className="space-y-1">
              {risks.map((r, i) => (
                <li key={i} className="flex items-start gap-1.5 text-[11px] text-ink-mute">
                  <span className="mt-1 h-1 w-1 shrink-0 rounded-full bg-amber-400" />
                  {r}
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-[11px] text-ink-mute">No notable risks detected.</p>
          )}
        </div>
      </div>

      {/* Score breakdown — always shown when the ATS score is computed; framed as
          "why this score is low" for weak candidates so the reasons are explicit. */}
      {hasScore && (breakdown.length > 0 || penalties.length > 0) && (
        <div className="border-t border-border/60 pt-3">
          <div
            className={cn(
              "mb-2 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wider",
              isLow ? "text-rose-400" : "text-sky-400"
            )}
          >
            <Gauge className="h-3 w-3" />
            {isLow ? "Why this score is low" : "Score breakdown"}
            <span className="ml-auto font-bold tabular-nums text-ink">
              {formatScore(c.atsscore as number)}
              <span className="text-ink-mute">/100</span>
            </span>
          </div>

          <div className="space-y-1.5">
            {breakdown.map((b, i) => (
              <div key={i} className="flex items-center gap-2">
                <span className="w-32 shrink-0 truncate text-[11px] text-ink-mute" title={b.component}>
                  {b.component}
                </span>
                <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-border/60">
                  <div
                    className={cn(
                      "h-full rounded-full",
                      b.subscore < WEAK_COMPONENT ? "bg-rose-400" : b.subscore < 70 ? "bg-amber-400" : "bg-emerald-400"
                    )}
                    style={{ width: `${Math.max(0, Math.min(100, b.subscore))}%` }}
                  />
                </div>
                <span className="w-20 shrink-0 text-right text-[11px] tabular-nums text-ink-mute">
                  {Math.round(b.subscore)} → {b.weighted.toFixed(1)}
                </span>
              </div>
            ))}
          </div>

          {(penalties.length > 0 || (cert && cert.points > 0)) && (
            <div className="mt-2 flex flex-wrap gap-1.5">
              {penalties.map((p, i) => (
                <span
                  key={`p${i}`}
                  className="rounded-full border border-rose-500/30 bg-rose-400/10 px-2 py-0.5 text-[10px] font-semibold text-rose-400"
                >
                  −{Math.round(p.points)} {p.reason}
                </span>
              ))}
              {cert && cert.points > 0 && (
                <span className="rounded-full border border-emerald-500/30 bg-emerald-400/10 px-2 py-0.5 text-[10px] font-semibold text-emerald-400">
                  +{Math.round(cert.points)} certificate bonus
                </span>
              )}
            </div>
          )}
        </div>
      )}

      {c.recommendation && (
        <div className="flex items-center gap-2 border-t border-border/60 pt-3">
          <Route className="h-3.5 w-3.5 text-ink-mute" />
          <span className="text-[10px] font-semibold uppercase tracking-wider text-ink-mute">
            Recommended track
          </span>
          <span className={cn("rounded-full border px-2 py-0.5 text-xs font-semibold", streamBadge(c.recommendation))}>
            {c.recommendation}
          </span>
        </div>
      )}

      {c.analysis && (
        <p className="border-t border-border/60 pt-3 text-xs leading-relaxed text-ink-mute">
          {c.analysis}
        </p>
      )}
    </div>
  );
}
