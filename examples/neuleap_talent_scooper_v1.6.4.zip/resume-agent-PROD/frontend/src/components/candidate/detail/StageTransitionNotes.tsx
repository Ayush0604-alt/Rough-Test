import { useState } from "react";
import { ChevronDown, MessageSquare } from "lucide-react";
import { cn } from "@/lib/utils";
import { roundLabel } from "@/lib/rounds";
import { STAGE_COLOR, splitComment, entryText, fmtWhen } from "@/lib/candidateAudit";
import type { CandidateAuditEntry } from "@/services/candidates";

interface Transition {
  entry: CandidateAuditEntry;
  comment: string;
}

/**
 * Flat, latest-first list of the COMMENT captured at each stage transition (a
 * round's Pass/Fail outcome) — a quick-scan digest sitting above the full
 * Actions Audit Log below it. Collapsed by default, but the most recent
 * transition + its comment always shows; expanding reveals the rest, earliest
 * at the bottom.
 */
export default function StageTransitionNotes({ entries }: { entries: CandidateAuditEntry[] }) {
  const [open, setOpen] = useState(false);

  // entries arrives newest-first from the API — filtering preserves that order,
  // so the result is already "latest on top, earliest at the bottom".
  const transitions: Transition[] = entries
    .filter((e) => e.step === "round_updated")
    .map((e) => ({ entry: e, comment: splitComment(entryText(e)).comment }))
    .filter((t): t is Transition => !!t.comment);

  if (transitions.length === 0) return null;

  const [latest, ...rest] = transitions;

  const Row = ({ t }: { t: Transition }) => {
    const stage = t.entry.stage || "New";
    return (
      <div>
        <div className="flex items-center justify-between gap-2">
          <span className="text-[11px] font-bold" style={{ color: STAGE_COLOR[stage] ?? "#6b7280" }}>
            {roundLabel(stage)}
          </span>
          <span className="text-[10px] text-ink-mute">{fmtWhen(t.entry.created_at)}</span>
        </div>
        <div className="mt-1 flex items-start gap-1.5 rounded-lg border border-border bg-secondary/40 px-2.5 py-1.5">
          <MessageSquare className="mt-0.5 h-3 w-3 shrink-0 text-ink-mute" />
          <p className="text-xs text-ink">{t.comment}</p>
        </div>
      </div>
    );
  };

  return (
    <div className="rounded-2xl border border-border bg-card p-4 shadow-[0_1px_3px_hsla(var(--shadow-blue),0.08)] sm:col-span-6 sm:p-5 lg:col-span-12">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        disabled={rest.length === 0}
        className="flex w-full items-center justify-between gap-2 disabled:cursor-default"
      >
        <div className="flex items-center gap-2">
          <MessageSquare className="h-3.5 w-3.5 text-ink-mute" />
          <h3 className="text-xs font-bold uppercase tracking-wider text-ink-mute">Stage Transition Notes</h3>
          <span className="rounded-full bg-secondary px-1.5 py-px text-[10px] font-semibold text-ink-mute">
            {transitions.length}
          </span>
        </div>
        {rest.length > 0 && (
          <ChevronDown className={cn("h-4 w-4 shrink-0 text-ink-mute transition-transform", open && "rotate-180")} />
        )}
      </button>

      <div className="mt-3 space-y-3">
        <Row t={latest} />
        {open && rest.map((t) => <Row key={t.entry.log_id} t={t} />)}
      </div>
    </div>
  );
}
