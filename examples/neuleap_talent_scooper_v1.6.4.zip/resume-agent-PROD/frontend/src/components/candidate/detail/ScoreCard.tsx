import { motion } from "framer-motion";
import { cn, formatScore } from "@/lib/utils";
import { scoreBand, scoreFactors } from "@/lib/score";
import type { CandidateMaster } from "@/types";

/** Hero ATS score: radial gauge + fit band + a derived factor breakdown. */
export default function ScoreCard({ c }: { c: CandidateMaster }) {
  const score = c.atsscore;
  if (score == null) {
    return (
      <div className="flex h-full items-center text-xs text-ink-mute">
        Score pending — resume not yet analysed.
      </div>
    );
  }

  const band = scoreBand(score);
  const factors = scoreFactors(c);
  const R = 42;
  const C = 2 * Math.PI * R;
  const pct = Math.max(0, Math.min(100, score));

  return (
    <div className="flex flex-col gap-5 sm:flex-row sm:items-center">
      {/* Gauge */}
      <div className="relative mx-auto shrink-0" style={{ width: 116, height: 116 }}>
        <svg width="116" height="116" viewBox="0 0 116 116" className="-rotate-90">
          <circle cx="58" cy="58" r={R} fill="none" strokeWidth="9"
            className="text-secondary" stroke="currentColor" />
          <motion.circle
            cx="58" cy="58" r={R} fill="none" strokeWidth="9" strokeLinecap="round"
            className={band.text} stroke="currentColor"
            strokeDasharray={C}
            initial={{ strokeDashoffset: C }}
            animate={{ strokeDashoffset: C - (pct / 100) * C }}
            transition={{ duration: 0.7, ease: "easeOut" }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className={cn("tnum text-2xl font-black leading-none", band.text)}>
            {formatScore(score)}
          </span>
          <span className="text-[10px] text-ink-mute">/ 100</span>
        </div>
      </div>

      {/* Band + breakdown */}
      <div className="min-w-0 flex-1">
        <div className="mb-3 flex items-center gap-2">
          <span className={cn("text-sm font-semibold", band.text)}>{band.label} fit</span>
        </div>
        <div className="space-y-2">
          {factors.map((f) => (
            <div key={f.label}>
              <div className="mb-0.5 flex items-center justify-between text-[10px]">
                <span className="text-ink-mute">{f.label}</span>
                <span className={f.positive ? "text-ink" : "text-amber-400"}>{f.note}</span>
              </div>
              <div className="h-1.5 overflow-hidden rounded-full bg-secondary">
                <motion.div
                  className={cn("h-full rounded-full", f.positive ? band.bar : "bg-amber-500")}
                  initial={{ width: 0 }}
                  animate={{ width: `${f.value}%` }}
                  transition={{ duration: 0.5, ease: "easeOut" }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
