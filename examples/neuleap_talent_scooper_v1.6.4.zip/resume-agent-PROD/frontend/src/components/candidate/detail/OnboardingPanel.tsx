import { Check } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  ONBOARDING_STAGE_ORDER,
  ONBOARDING_STAGE_LABELS,
  ONBOARDING_STAGE_COLOR,
  DEFAULT_ONBOARDING_CHECKLIST,
  onboardingStageOf,
} from "@/lib/onboarding";
import type { CandidateMaster } from "@/types";

/**
 * Post-hire onboarding pipeline (Live Workflow) — shown on the candidate profile
 * only once Hired. A stage stepper (click any stage to jump there), the two
 * onboarding dates, and the fixed allocation checklist. All mutations stay in
 * the page and are passed in as callbacks.
 */
export default function OnboardingPanel({
  c,
  onSetStage,
  onSetDate,
  onToggleChecklistItem,
}: {
  c: CandidateMaster;
  onSetStage: (stage: string) => void;
  onSetDate: (field: "expected_join_date" | "onboarding_date", value: string) => void;
  onToggleChecklistItem: (key: string) => void;
}) {
  const currentStage = onboardingStageOf(c.onboarding_stage);
  const currentIndex = ONBOARDING_STAGE_ORDER.indexOf(currentStage);
  const checklist = c.onboarding_checklist ?? DEFAULT_ONBOARDING_CHECKLIST;

  return (
    <div className="space-y-4">
      {/* Stage stepper */}
      <div className="flex flex-wrap items-center gap-1.5">
        {ONBOARDING_STAGE_ORDER.map((stage, i) => {
          const isCurrent = stage === currentStage;
          const isPast = i < currentIndex;
          return (
            <button
              key={stage}
              type="button"
              onClick={() => onSetStage(stage)}
              title={`Set onboarding stage to “${ONBOARDING_STAGE_LABELS[stage]}”`}
              className={cn(
                "rounded-full border px-2.5 py-1 text-[10px] font-semibold transition-colors",
                isCurrent
                  ? "text-white shadow-sm"
                  : isPast
                    ? "border-border bg-secondary/60 text-ink-mute hover:text-ink"
                    : "border-border text-ink-mute hover:border-primary/40 hover:text-ink"
              )}
              style={isCurrent ? { backgroundColor: ONBOARDING_STAGE_COLOR[stage], borderColor: ONBOARDING_STAGE_COLOR[stage] } : undefined}
            >
              {isPast && <Check className="mr-1 inline h-2.5 w-2.5" />}
              {ONBOARDING_STAGE_LABELS[stage]}
            </button>
          );
        })}
      </div>

      {/* Dates */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <label className="space-y-1">
          <span className="text-[10px] font-semibold uppercase tracking-wide text-ink-mute">
            Expected Join Date
          </span>
          <input
            type="date"
            value={c.expected_join_date ?? ""}
            onChange={(e) => onSetDate("expected_join_date", e.target.value)}
            className="field-input h-8 w-full"
          />
        </label>
        <label className="space-y-1">
          <span className="text-[10px] font-semibold uppercase tracking-wide text-ink-mute">
            Onboarding Date
          </span>
          <input
            type="date"
            value={c.onboarding_date ?? ""}
            onChange={(e) => onSetDate("onboarding_date", e.target.value)}
            className="field-input h-8 w-full"
          />
        </label>
      </div>

      {/* Allocation checklist */}
      <div className="space-y-1.5">
        <span className="text-[10px] font-semibold uppercase tracking-wide text-ink-mute">
          Allocation Process Checklist
        </span>
        <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">
          {checklist.map((item) => (
            <button
              key={item.key}
              type="button"
              onClick={() => onToggleChecklistItem(item.key)}
              className="flex items-center gap-2 rounded-lg border border-border px-2.5 py-1.5 text-left text-xs text-ink transition-colors hover:bg-secondary"
            >
              <span
                className={cn(
                  "flex h-4 w-4 shrink-0 items-center justify-center rounded border transition-colors",
                  item.done ? "border-emerald-500 bg-emerald-500 text-white" : "border-border"
                )}
              >
                {item.done && <Check className="h-3 w-3" />}
              </span>
              <span className={item.done ? "text-ink-mute line-through" : ""}>{item.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
