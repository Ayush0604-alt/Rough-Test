import { GraduationCap, Briefcase, Clock, Building2, type LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import type { CandidateMaster, JobRole } from "@/types";

interface TimelineNode {
  icon: LucideIcon;
  title: string;
  subtitle?: string;
  meta?: string;
  gap?: boolean;
  current?: boolean;
  // Absolute month index (year*12 + month-1) used purely to order nodes chronologically.
  // Education with only a year sorts by January; nodes with no usable date sink to the top.
  sort: number;
}

// One LLM-extracted dated activity (app.extraction.engine `_normalize_timeline`). Dates are
// the raw strings the model copied ("YYYY-MM" / "YYYY"); open-ended roles carry is_current
// plus an end_date_resolved stamped by the backend (app.services.timeline.annotate_resolved).
interface TimelineEntry {
  activity_type?: string | null;
  organization?: string | null;
  company?: string | null;
  title?: string | null;
  role?: string | null;
  degree?: string | null;
  start_date?: string | null;
  end_date?: string | null;
  end_date_resolved?: string | null;
  is_current?: boolean;
}

const EDUCATION_TYPES = new Set(["education"]);
const PRESENT_MARKERS = new Set([
  "present", "current", "now", "till date", "todate", "to date", "ongoing",
  "till now", "currently",
]);

function rolesOf(v: CandidateMaster["job_roles"]): JobRole[] {
  if (!Array.isArray(v)) return [];
  return v.filter((r): r is JobRole => !!r && typeof r === "object");
}

function gapsOf(v: CandidateMaster["gap_ranges"]): { from: string; to: string; months: number }[] {
  return Array.isArray(v) ? v : [];
}

function entriesOf(v: CandidateMaster["timeline"]): TimelineEntry[] {
  if (!Array.isArray(v)) return [];
  return v.filter((e): e is TimelineEntry => !!e && typeof e === "object");
}

function dur(months?: number | null): string {
  if (!months || months <= 0) return "";
  return months >= 12 ? `${(months / 12).toFixed(1)}y` : `${months}mo`;
}

function isPresent(value?: string | null): boolean {
  return value != null && PRESENT_MARKERS.has(String(value).trim().toLowerCase());
}

// Parse a resume date into an absolute month index (year*12 + month-1); year-only anchors
// to January. Returns null when the date is absent/unparseable.
function monthIndex(value?: string | null): number | null {
  if (!value) return null;
  const text = String(value).trim();
  let m = /^(\d{4})[-/.](\d{1,2})$/.exec(text);
  if (m) {
    const month = Number(m[2]);
    if (month >= 1 && month <= 12) return Number(m[1]) * 12 + (month - 1);
  }
  m = /^(\d{4})$/.exec(text);
  if (m) return Number(m[1]) * 12;
  return null;
}

/** Build chronologically-sorted nodes from the dated `timeline` (the source of truth). */
function nodesFromTimeline(c: CandidateMaster, entries: TimelineEntry[]): TimelineNode[] {
  const nodes: TimelineNode[] = [];

  for (const e of entries) {
    const type = (e.activity_type ?? "").toString().trim().toLowerCase();
    const isEdu = EDUCATION_TYPES.has(type);
    const company = (e.organization ?? e.company ?? "").toString().trim();
    const title = (e.title ?? e.role ?? e.degree ?? "").toString().trim();
    if (!company && !title) continue;

    const startIdx = monthIndex(e.start_date);
    const current = !!e.is_current || isPresent(e.end_date);
    const endIdx = current
      ? monthIndex(e.end_date_resolved) ?? null
      : monthIndex(e.end_date);
    const months = startIdx != null && endIdx != null ? endIdx - startIdx : null;

    const meta = isEdu
      ? (endIdx != null
          ? String(Math.floor(endIdx / 12))
          : startIdx != null
            ? String(Math.floor(startIdx / 12))
            : undefined)
      : dur(months);

    // Order education by COMPLETION (end date) — a degree spanning 2018→2021 belongs at
    // 2021, the year shown on the right, not at its 2018 start (which would float it above
    // an SSLC completed in 2018). Roles still anchor on their START date.
    const sortAnchor = isEdu
      ? (endIdx ?? startIdx ?? -Infinity)
      : (startIdx ?? endIdx ?? -Infinity);

    nodes.push({
      icon: isEdu ? GraduationCap : Briefcase,
      title: title || company,
      subtitle: title && company ? company : undefined,
      meta,
      current: !isEdu && current,
      sort: sortAnchor,
    });
  }

  for (const g of gapsOf(c.gap_ranges)) {
    nodes.push({
      icon: Clock,
      title: "Career gap",
      subtitle: g.from && g.to ? `${g.from} → ${g.to}` : undefined,
      meta: dur(g.months),
      gap: true,
      sort: monthIndex(g.from) ?? Infinity,
    });
  }

  // Oldest → newest, so the year order reads top-to-bottom. A gap sorts by its start month,
  // landing between the roles it actually separates.
  nodes.sort((a, b) => a.sort - b.sort);
  return nodes;
}

/** Legacy fallback for rows extracted before the structured timeline existed: keep the
 *  original education → roles → gaps → current grouping (no reliable dates to sort by). */
function nodesLegacy(c: CandidateMaster): TimelineNode[] {
  const nodes: TimelineNode[] = [];

  if (c.clg || c.highest_coursecompleted || c.passoutyr) {
    nodes.push({
      icon: GraduationCap,
      title: c.highest_coursecompleted ? `${c.highest_coursecompleted}` : "Education",
      subtitle: c.clg ?? undefined,
      meta: c.passoutyr ? String(c.passoutyr) : c.education_status ?? undefined,
      sort: 0,
    });
  }

  for (const r of rolesOf(c.job_roles)) {
    const role = (r.role ?? "").toString().trim();
    const company = (r.company ?? "").toString().trim();
    if (!role && !company) continue;
    nodes.push({
      icon: Briefcase,
      title: role || company,
      subtitle: role && company ? company : undefined,
      meta: dur(r.months),
      sort: 0,
    });
  }

  for (const g of gapsOf(c.gap_ranges)) {
    nodes.push({
      icon: Clock,
      title: "Career gap",
      subtitle: g.from && g.to ? `${g.from} → ${g.to}` : undefined,
      meta: dur(g.months),
      gap: true,
      sort: 0,
    });
  }

  if (c.currentcompany) {
    nodes.push({
      icon: Building2,
      title: "Current role",
      subtitle: c.currentcompany,
      meta: c.currentlocation ?? undefined,
      sort: 0,
    });
  }

  return nodes;
}

/**
 * Vertical career timeline, ordered oldest → newest. Career gaps are FIRST-CLASS amber
 * nodes, never buried in text. Built from the structured dated `timeline` when present (so
 * roles, education, and gaps interleave in true chronological order); falls back to the
 * legacy grouping for rows extracted before the timeline field existed.
 */
export default function CareerTimeline({ c }: { c: CandidateMaster }) {
  const entries = entriesOf(c.timeline);
  const nodes = entries.length ? nodesFromTimeline(c, entries) : nodesLegacy(c);

  if (nodes.length === 0) {
    return <p className="text-xs text-ink-mute">No timeline data extracted yet.</p>;
  }

  return (
    <ol className="relative ml-1 space-y-4 border-l border-border pl-5">
      {nodes.map((n, i) => {
        const Icon = n.icon;
        return (
          <li key={i} className="relative">
            <span
              className={cn(
                "absolute -left-[27px] flex h-5 w-5 items-center justify-center rounded-full border",
                n.gap
                  ? "border-amber-500/40 bg-amber-400/15 text-amber-400"
                  : n.current
                    ? "border-emerald-500/40 bg-emerald-400/15 text-emerald-400"
                    : "border-border bg-card text-ink-mute",
              )}
            >
              <Icon className="h-3 w-3" />
            </span>
            <div className="flex items-baseline justify-between gap-2">
              <span className={cn("text-xs font-semibold", n.gap ? "text-amber-400" : "text-ink")}>
                {n.title}
                {n.current && (
                  <span className="ml-1.5 text-[10px] font-medium text-emerald-400">· now</span>
                )}
              </span>
              {n.meta && <span className="tnum shrink-0 text-[10px] text-ink-mute">{n.meta}</span>}
            </div>
            {n.subtitle && <div className="text-[11px] text-ink-mute">{n.subtitle}</div>}
          </li>
        );
      })}
    </ol>
  );
}
