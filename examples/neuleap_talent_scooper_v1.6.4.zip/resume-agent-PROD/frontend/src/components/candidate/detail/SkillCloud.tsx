/** Primary-skills pill cloud. */
export default function SkillCloud({ skills }: { skills: string[] }) {
  if (skills.length === 0) {
    return <p className="text-xs text-ink-mute">No skills extracted.</p>;
  }
  return (
    <div className="flex flex-wrap gap-1.5">
      {skills.map((s, i) => (
        <span
          key={i}
          className="inline-flex items-center rounded-full border border-border bg-secondary/50 px-2.5 py-0.5 text-[11px] font-medium text-ink"
        >
          {s}
        </span>
      ))}
    </div>
  );
}
