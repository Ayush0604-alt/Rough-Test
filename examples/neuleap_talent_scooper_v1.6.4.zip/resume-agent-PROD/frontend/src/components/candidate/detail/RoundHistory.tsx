import { useState } from "react";
import { Briefcase, CalendarDays, FastForward, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { outcomeBadge, outcomeLabel } from "@/lib/badges";
import type { Round } from "@/types/rounds";

// Feedback can be a full interviewer Q&A transcript (hundreds of words) — clamp
// the in-card preview and let "More" open the full text in a scrollable popup
// instead of stretching the round card to fit it.
const FEEDBACK_PREVIEW_CHARS = 160;

// Interview-stage order — used to detect fast-tracks: a jump from one round
// straight past the next planned one leaves a gap in this sequence.
const STAGE_SEQ = ["Screening", "Round 1", "Round 2", "Round 3", "Final"];

// The written justification an interviewer records when promoting a candidate
// past the natural next stage — folded into the verdict feedback as
// "[Promotion justification — <label>]: <reason>" (see InterviewAccess).
const PROMO_RE = /\[Promotion justification[^\]]*\]:\s*([\s\S]+?)\s*$/;

function fastTrackReason(feedback: string | null | undefined): string | null {
  const m = (feedback ?? "").match(PROMO_RE);
  return m ? m[1].trim() : null;
}

type HistoryItem =
  | { type: "round"; round: Round }
  | { type: "fasttrack"; key: string; skipped: string[]; reason: string | null };

// Interleave the real round rows with merged "Fast-tracked" cards wherever the
// stage sequence has a gap: skipped stages between two rounds carry the reason
// written on the PREVIOUS round's verdict; a gap before the FIRST round means
// the candidate was fast-tracked straight from intake (predicted NBA).
function buildHistory(rounds: Round[]): HistoryItem[] {
  const ordered = [...rounds].sort((a, b) => a.round_id - b.round_id);
  const items: HistoryItem[] = [];
  let prevIdx = -1; // stage index of the previous round; -1 = intake ("New")
  let prev: Round | null = null;
  ordered.forEach((r) => {
    const idx = STAGE_SEQ.indexOf((r.round_name ?? "").trim());
    if (idx > prevIdx + 1 && idx !== -1) {
      const skipped = STAGE_SEQ.slice(prevIdx + 1, idx);
      items.push({
        type: "fasttrack",
        key: `ft-${r.round_id}`,
        skipped,
        reason: prev ? fastTrackReason(prev.feedback) : null,
      });
    }
    items.push({ type: "round", round: r });
    if (idx !== -1) prevIdx = idx;
    prev = r;
  });
  return items;
}

/** Round-history cards — shared by the candidate profile page AND the external
 * interviewer view, so both show the SAME story (the interviewer payload just
 * omits compensation fields, which then simply don't render). Fast-tracked
 * jumps render as their own merged card with the recorded promotion reason. */
export default function RoundHistory({
  rounds,
  role,
  activeRoundId,
}: {
  rounds: Round[];
  role?: string | null;
  // Highlights the round an interviewer link is scoped to (interviewer view).
  activeRoundId?: number | null;
}) {
  const [expanded, setExpanded] = useState<Round | null>(null);

  if (rounds.length === 0) {
    return <p className="text-xs text-ink-mute">No rounds scheduled yet.</p>;
  }
  const items = buildHistory(rounds);
  return (
    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
      {items.map((item) =>
        item.type === "fasttrack" ? (
          <div
            key={item.key}
            className="rounded-xl border border-violet-500/30 bg-violet-500/5 p-3"
          >
            <div className="mb-1.5 flex items-center gap-2">
              <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-violet-500/15 text-violet-600">
                <FastForward className="h-3 w-3" />
              </span>
              <span className="text-xs font-bold text-violet-600">Fast-tracked</span>
              <span className="truncate text-[10px] text-ink-mute">
                skipped {item.skipped.join(" · ")}
              </span>
            </div>
            {item.reason ? (
              <p className="whitespace-pre-line break-words text-[11px] italic leading-relaxed text-ink">
                "{item.reason}"
              </p>
            ) : (
              <p className="text-[11px] leading-relaxed text-ink-mute">
                Promoted past {item.skipped.length === 1 ? "this round" : "these rounds"} by the
                system prediction / verdict — no written reason recorded.
              </p>
            )}
          </div>
        ) : (
          <div
            key={item.round.round_id}
            className={cn(
              "rounded-xl border p-3",
              item.round.round_id === activeRoundId
                ? "border-primary/40 bg-primary/5"
                : "border-border bg-secondary/30"
            )}
          >
            <div className="mb-2 flex items-center justify-between">
              <div className="flex items-center gap-2">
                {/* Always the REAL round name — "Interview slots shared" is a
                    pipeline-stage relabel (roundLabel), not a round. */}
                <span className="text-xs font-bold text-ink">{item.round.round_name}</span>
                {/* The candidate's ROLE (Gen AI / Data Eng), not their skills. */}
                {role && <span className="text-[10px] text-ink-mute">· {role}</span>}
              </div>
              <span
                className={cn(
                  "rounded-full border px-2 py-0.5 text-[10px] font-semibold",
                  item.round.outcome ? outcomeBadge(item.round.outcome) : "border-border bg-secondary text-ink-mute"
                )}
              >
                {item.round.outcome ? outcomeLabel(item.round.outcome) : "Pending"}
              </span>
            </div>
            <div className="grid grid-cols-2 gap-x-4 gap-y-1">
              {item.round.interviewer && (
                <div className="flex items-center gap-1.5 text-[10px] text-ink-mute">
                  <Briefcase className="h-3 w-3" /> {item.round.interviewer}
                </div>
              )}
              {item.round.scheduled_on && (
                <div className="flex items-center gap-1.5 text-[10px] text-ink-mute">
                  <CalendarDays className="h-3 w-3" />
                  {new Date(item.round.scheduled_on).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
                </div>
              )}
              {item.round.current_ctc != null && (
                <div className="text-[10px] text-ink-mute">
                  Current CTC: <span className="tnum font-medium text-ink">₹{item.round.current_ctc}L</span>
                </div>
              )}
              {item.round.expected_ctc != null && (
                <div className="text-[10px] text-ink-mute">
                  Expected: <span className="tnum font-medium text-ink">₹{item.round.expected_ctc}L</span>
                </div>
              )}
              {item.round.relocation != null && (
                <div className="text-[10px] text-ink-mute">
                  Relocation:{" "}
                  <span className={item.round.relocation ? "text-emerald-400" : "text-red-400"}>
                    {item.round.relocation ? "Yes" : "No"}
                  </span>
                </div>
              )}
              {item.round.score != null && (
                <div className="text-[10px] text-ink-mute">
                  Score: <span className="tnum font-medium text-ink">{item.round.score}/10</span>
                </div>
              )}
            </div>
            {item.round.feedback && (
              <div className="mt-2 rounded-md bg-secondary/50 px-2 py-1.5 text-[10px] italic text-ink-mute">
                <p className="line-clamp-3 whitespace-pre-line break-words">"{item.round.feedback}"</p>
                {item.round.feedback.length > FEEDBACK_PREVIEW_CHARS && (
                  <button
                    onClick={() => setExpanded(item.round)}
                    className="mt-1 font-semibold not-italic text-primary hover:text-primary/80"
                  >
                    More
                  </button>
                )}
              </div>
            )}
          </div>
        )
      )}

      {expanded && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/40 p-4 backdrop-blur-sm"
          onClick={() => setExpanded(null)}
        >
          <div
            className="flex max-h-[85vh] w-full max-w-lg flex-col rounded-2xl border border-border bg-card shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex shrink-0 items-start justify-between gap-3 border-b border-border px-5 py-3.5">
              <div className="min-w-0">
                <h2 className="truncate text-sm font-bold text-foreground">{expanded.round_name} feedback</h2>
                {expanded.outcome && (
                  <span className={cn("mt-1 inline-block rounded-full border px-2 py-0.5 text-[10px] font-semibold", outcomeBadge(expanded.outcome))}>
                    {outcomeLabel(expanded.outcome)}
                  </span>
                )}
              </div>
              <button
                onClick={() => setExpanded(null)}
                className="shrink-0 rounded-lg p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="min-h-0 flex-1 overflow-y-auto px-5 py-4">
              <p className="whitespace-pre-line break-words text-xs italic leading-relaxed text-ink-mute">
                "{expanded.feedback}"
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
