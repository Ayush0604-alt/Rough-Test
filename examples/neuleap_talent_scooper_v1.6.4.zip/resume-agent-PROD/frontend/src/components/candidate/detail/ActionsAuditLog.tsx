import { useState } from "react";
import { ChevronDown, Layers, Mail, MessageSquare } from "lucide-react";
import { cn } from "@/lib/utils";
import { STAGE_COLOR, TRANSITION_STEPS, splitComment, entryText, fmtWhen } from "@/lib/candidateAudit";
import type { CandidateAuditEntry } from "@/services/candidates";

/**
 * Collapsed-by-default trail of every audit_log row for this candidate — L1 (mail
 * intake) through L4 (recruiter actions) — one flat list, strictly reverse
 * chronological (entries arrive newest-first from the API): latest at the top,
 * oldest at the bottom. Stage-transition entries (status change, round outcome,
 * round created) render bolder, and any comment captured on that transition shows
 * in its own outlined box. A row about an email draft (generated/marked ready/
 * sent) gets a "view email" button that opens that exact draft for review.
 */
export default function ActionsAuditLog({
  entries,
  onViewEmail,
}: {
  entries: CandidateAuditEntry[];
  onViewEmail: (draftId: number) => void;
}) {
  const [open, setOpen] = useState(false);

  return (
    <div className="rounded-2xl border border-border bg-card p-4 shadow-[0_1px_3px_hsla(var(--shadow-blue),0.08)] sm:col-span-6 sm:p-5 lg:col-span-12">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="flex w-full items-center justify-between gap-2"
      >
        <div className="flex items-center gap-2">
          <Layers className="h-3.5 w-3.5 text-ink-mute" />
          <h3 className="text-xs font-bold uppercase tracking-wider text-ink-mute">Actions Audit Log</h3>
          <span className="rounded-full bg-secondary px-1.5 py-px text-[10px] font-semibold text-ink-mute">
            {entries.length}
          </span>
        </div>
        <ChevronDown className={cn("h-4 w-4 shrink-0 text-ink-mute transition-transform", open && "rotate-180")} />
      </button>

      {open && (
        entries.length === 0 ? (
          <p className="mt-3 text-xs text-ink-mute">No recorded actions yet.</p>
        ) : (
          <ul className="mt-4 space-y-2.5 border-l border-border pl-3.5">
            {entries.map((e) => {
              const isTransition = TRANSITION_STEPS.has(e.step);
              const { meta, comment } = splitComment(entryText(e));
              const stage = e.stage || "New";
              return (
                <li key={e.log_id} className="text-[11px]">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex min-w-0 items-start gap-1.5">
                      <span
                        className="mt-[3px] h-1.5 w-1.5 shrink-0 rounded-full"
                        style={{ backgroundColor: STAGE_COLOR[stage] ?? "#6b7280" }}
                        title={stage}
                      />
                      <span className={cn(isTransition ? "font-semibold text-ink" : "text-ink-mute")}>
                        {meta}
                      </span>
                    </div>
                    <div className="flex shrink-0 items-center gap-2">
                      {e.draft_id != null && (
                        <button
                          type="button"
                          onClick={() => onViewEmail(e.draft_id!)}
                          title="View this email — drafted/edited/sent content"
                          className="flex items-center gap-1 rounded-md px-1.5 py-0.5 text-[10px] font-semibold text-primary transition-colors hover:bg-primary/10"
                        >
                          <Mail className="h-3 w-3" />
                          View email
                        </button>
                      )}
                      <span className="whitespace-nowrap text-ink-mute">{fmtWhen(e.created_at)}</span>
                    </div>
                  </div>
                  {comment && (
                    <div className="mt-1 flex items-start gap-1.5 rounded-lg border border-border bg-secondary/40 px-2.5 py-1.5">
                      <MessageSquare className="mt-0.5 h-3 w-3 shrink-0 text-ink-mute" />
                      <p className="text-ink">{comment}</p>
                    </div>
                  )}
                </li>
              );
            })}
          </ul>
        )
      )}
    </div>
  );
}
