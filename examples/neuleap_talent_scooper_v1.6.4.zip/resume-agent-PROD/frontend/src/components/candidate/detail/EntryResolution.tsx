import { FileText } from "lucide-react";
import type { CandidateMaster } from "@/types";

/**
 * Recruiter-resolved entry exceptions (reapplication / pending-resume).
 * Purely presentational — all mutations stay in the page and are passed in as callbacks,
 * so behavior is identical to the original implementation.
 */
export default function EntryResolution({
  c,
  onViewResume,
  onAcceptReapplication,
  onIgnoreReapplication,
  onUpload,
  reapplicationPending,
  uploadPending,
  uploadError,
  uploadNote,
}: {
  c: CandidateMaster;
  onViewResume: (which: "current" | "pending") => void;
  onAcceptReapplication: () => void;
  onIgnoreReapplication: () => void;
  onUpload: (file: File) => void;
  reapplicationPending: boolean;
  uploadPending: boolean;
  uploadError?: string | null;
  uploadNote?: string | null;
}) {
  if (c.previously_seen) {
    return (
      <div className="space-y-2">
        <p className="text-[11px] text-ink-mute">
          Reapplication detected — a new resume is pending against this existing record.
          Compare both, then accept (the new file replaces the old and re-runs extraction)
          or ignore (discard the new file).
        </p>
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => onViewResume("current")}
            disabled={!c.s3_file_path}
            className="flex items-center gap-1.5 rounded-lg border border-border px-2.5 py-1.5 text-xs font-medium text-ink transition-colors hover:border-primary/40 hover:bg-secondary disabled:opacity-40"
          >
            <FileText className="h-3 w-3" /> View current resume
          </button>
          <button
            onClick={() => onViewResume("pending")}
            disabled={!c.pending_review_file}
            className="flex items-center gap-1.5 rounded-lg border border-primary/40 bg-primary/5 px-2.5 py-1.5 text-xs font-medium text-primary transition-colors hover:bg-primary/10 disabled:opacity-40"
          >
            <FileText className="h-3 w-3" /> View new resume
          </button>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={onAcceptReapplication}
            disabled={reapplicationPending}
            className="rounded-lg border border-emerald-500/30 bg-emerald-500/5 px-3 py-1.5 text-xs font-medium text-emerald-400 transition-colors hover:bg-emerald-500/10 disabled:opacity-50"
          >
            Accept (new replaces old + re-extract)
          </button>
          <button
            onClick={onIgnoreReapplication}
            disabled={reapplicationPending}
            className="rounded-lg border border-slate-500/30 bg-slate-500/5 px-3 py-1.5 text-xs font-medium text-slate-400 transition-colors hover:bg-slate-500/10 disabled:opacity-50"
          >
            Ignore (discard new file)
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <p className="text-[11px] text-ink-mute">
        Awaiting resume — upload one to activate this candidate.
      </p>
      <div className="flex flex-wrap items-center gap-2">
        <label className="cursor-pointer rounded-lg border border-blue-500/30 bg-blue-500/5 px-3 py-1.5 text-xs font-medium text-blue-400 transition-colors hover:bg-blue-500/10">
          {uploadPending ? "Uploading…" : "Upload Resume"}
          <input
            type="file"
            accept=".pdf,.docx,.doc,.jpg,.jpeg,.png"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) onUpload(f);
            }}
          />
        </label>
      </div>
      {uploadError && <span className="text-[10px] text-red-400">{uploadError}</span>}
      {uploadNote && <span className="text-[10px] text-amber-500">{uploadNote}</span>}
    </div>
  );
}
