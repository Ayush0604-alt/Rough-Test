import { useEffect, useRef, useState } from "react";
import { X, Download, Loader2, AlertTriangle, FileText, ExternalLink } from "lucide-react";
import { renderAsync } from "docx-preview";
import { candidatesService } from "@/services/candidates";

interface Props {
  open: boolean;
  fileName?: string | null;
  onClose: () => void;
  // ── Candidate mode (default): streams the candidate's stored resume. ──
  candidateId?: string;
  which?: "current" | "pending";   // "pending" = the re-application's new file
  // ── Generic mode: supply a blob fetcher (e.g. a review-queue dropped file that
  //    has no candidate yet). When set, it overrides the candidate fetch. ──
  fetchBlob?: () => Promise<Blob>;
  newTabUrl?: string;              // "Open in new tab" target (defaults to the resume URL)
  subtitle?: string;              // header line under the filename (defaults to candidateId)
}

function extOf(name: string): string {
  const m = name.toLowerCase().match(/\.([a-z0-9]+)$/);
  return m ? m[1] : "";
}

export default function ResumeViewerModal({
  open,
  candidateId,
  fileName,
  which = "current",
  fetchBlob,
  newTabUrl,
  subtitle,
  onClose,
}: Props) {
  const [url, setUrl] = useState<string | null>(null);
  const [blob, setBlob] = useState<Blob | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const docxRef = useRef<HTMLDivElement>(null);

  // Keep the latest fetcher without making it an effect dependency (it's a new
  // closure each render). The effect re-runs on the stable `loadKey` instead.
  const fetchRef = useRef(fetchBlob);
  fetchRef.current = fetchBlob;
  const loadKey = fetchBlob ? `blob:${newTabUrl ?? fileName ?? ""}` : `${candidateId}:${which}`;

  // "Open in new tab" + header subtitle: explicit prop wins, else fall back to the
  // candidate resume URL / candidateId (candidate mode).
  const tabUrl = newTabUrl ?? (candidateId ? candidatesService.resumeUrl(candidateId) : null);
  const subLine = subtitle ?? candidateId ?? "";

  const name = fileName ? fileName.split("/").pop() ?? "resume" : "resume";
  const ext = extOf(name);
  const isPdf = ext === "pdf";
  const isImage = ["png", "jpg", "jpeg", "gif", "bmp", "tiff", "tif"].includes(ext);
  // .docx (OOXML) renders faithfully in-browser via docx-preview — no format conversion,
  // so the original styles/tables/alignment are preserved. Legacy binary .doc isn't OOXML
  // and still falls back to download.
  const isDocx = ext === "docx";

  useEffect(() => {
    if (!open) return;
    let revoke: string | null = null;
    setLoading(true);
    setError(null);
    setUrl(null);
    setBlob(null);
    // Generic mode: use the supplied fetcher. Candidate mode: stream the stored resume.
    const load = fetchRef.current
      ? fetchRef.current()
      : candidatesService.fetchResume(candidateId as string, which).then((res) => res.data as Blob);
    load
      .then((data) => {
        const objUrl = URL.createObjectURL(data);
        revoke = objUrl;
        setBlob(data);
        setUrl(objUrl);
      })
      .catch(async (e) => {
        // Blob error responses need to be read as text to get the detail.
        let detail = "Could not load resume.";
        const data = e?.response?.data;
        if (data instanceof Blob) {
          try {
            const txt = await data.text();
            detail = JSON.parse(txt)?.detail ?? detail;
          } catch {
            /* keep default */
          }
        } else if (e?.message) {
          detail = e.message;
        }
        setError(detail);
      })
      .finally(() => setLoading(false));

    return () => {
      if (revoke) URL.revokeObjectURL(revoke);
    };
  }, [open, loadKey]);

  // Render .docx into its container once the bytes arrive. docx-preview parses the OOXML
  // and emits styled HTML (pages, tables, images) — the document is shown as authored, not
  // converted. Runs after the container is mounted (url set ⇒ docx branch rendered).
  useEffect(() => {
    if (!open || !isDocx || !blob || loading || error) return;
    const container = docxRef.current;
    if (!container) return;
    let cancelled = false;
    container.innerHTML = "";
    renderAsync(blob, container, undefined, {
      className: "docx",
      inWrapper: true,
      ignoreLastRenderedPageBreak: true,
    }).catch(() => {
      if (!cancelled) setError("This .docx couldn’t be rendered — download it to view.");
    });
    return () => {
      cancelled = true;
      container.innerHTML = "";
    };
  }, [open, isDocx, blob, loading, error, url]);

  if (!open) return null;

  const download = () => {
    if (!url) return;
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    a.click();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/40 backdrop-blur-sm p-4">
      <div className="surface flex h-[88vh] w-full max-w-4xl flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-border px-5 py-3.5">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg gradient-brand">
              <FileText className="h-4 w-4 text-white" />
            </div>
            <div className="min-w-0">
              <div className="text-sm font-semibold text-foreground truncate">{name}</div>
              {subLine && <div className="text-[11px] text-muted-foreground">{subLine}</div>}
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            {url && (
              <>
                {tabUrl && (
                  <a
                    href={tabUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 rounded-lg border border-border px-2.5 py-1.5 text-xs font-medium text-muted-foreground hover:bg-secondary"
                  >
                    <ExternalLink className="h-3.5 w-3.5" /> New tab
                  </a>
                )}
                <button
                  onClick={download}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-border px-2.5 py-1.5 text-xs font-medium text-muted-foreground hover:bg-secondary"
                >
                  <Download className="h-3.5 w-3.5" /> Download
                </button>
              </>
            )}
            <button
              onClick={onClose}
              className="rounded-lg p-1.5 text-muted-foreground hover:bg-secondary hover:text-foreground"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 bg-secondary/40 overflow-auto">
          {loading && (
            <div className="flex h-full flex-col items-center justify-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="h-5 w-5 animate-spin text-primary" />
              Loading resume…
            </div>
          )}

          {error && !loading && (
            <div className="flex h-full flex-col items-center justify-center gap-2 px-6 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-destructive/10">
                <AlertTriangle className="h-6 w-6 text-destructive" />
              </div>
              <div className="text-sm font-semibold text-foreground">Couldn’t open resume</div>
              <div className="text-xs text-muted-foreground max-w-sm">{error}</div>
            </div>
          )}

          {url && !loading && !error && (
            <>
              {isPdf && <iframe src={url} title="resume" className="h-full w-full border-0" />}
              {isImage && (
                <div className="flex h-full items-center justify-center p-4">
                  <img src={url} alt="resume" className="max-h-full max-w-full rounded-lg shadow" />
                </div>
              )}
              {isDocx && (
                <div ref={docxRef} className="docx-host flex min-h-full justify-center p-4" />
              )}
              {!isPdf && !isImage && !isDocx && (
                <div className="flex h-full flex-col items-center justify-center gap-3 px-6 text-center">
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-secondary">
                    <FileText className="h-6 w-6 text-muted-foreground" />
                  </div>
                  <div className="text-sm font-semibold text-foreground">
                    Preview not supported for .{ext || "file"}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    This format can’t render in the browser — download it to view.
                  </p>
                  <button onClick={download} className="btn-brand">
                    <Download className="h-4 w-4" /> Download {name}
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
