// Comment/reason gate for every NBA action — Apply predicted (single + bulk)
// and the Admin's manual change. The reason typed here is appended to the
// candidate's Actions Audit Log entry ("— Reason: …"); bulk applies record
// the SAME comment on every affected candidate, marked "(bulk-apply)".
// Cancel abandons the action entirely; Apply proceeds (comment optional).
import { useEffect, useState } from "react";
import { Loader2, MessageSquarePlus } from "lucide-react";

export default function NbaCommentDialog({
  open,
  title,
  message,
  bulkCount,
  pending = false,
  confirmLabel = "Apply",
  onCancel,
  onApply,
}: {
  open: boolean;
  title: string;
  message?: React.ReactNode;
  // Set for bulk applies — shows the shared-comment / (bulk-apply) note.
  bulkCount?: number;
  pending?: boolean;
  confirmLabel?: string;
  onCancel: () => void;
  onApply: (comment: string) => void;
}) {
  const [comment, setComment] = useState("");
  useEffect(() => {
    if (open) setComment("");
  }, [open]);
  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center bg-foreground/40 p-4 backdrop-blur-sm"
      onClick={() => !pending && onCancel()}
    >
      <div
        className="w-full max-w-md rounded-2xl border border-border bg-card p-5 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start gap-3">
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
            <MessageSquarePlus className="h-4.5 w-4.5" />
          </span>
          <div className="min-w-0">
            <h3 className="text-sm font-bold text-foreground">{title}</h3>
            {message && <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{message}</p>}
          </div>
        </div>

        <div className="mt-3 space-y-1">
          <label className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
            Comment / reason — recorded in the Actions Audit Log
          </label>
          <textarea
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            rows={3}
            autoFocus
            placeholder="Why this action? (optional, but it makes the audit trail readable later)"
            className="w-full resize-y rounded-lg border border-border bg-background px-2.5 py-1.5 text-xs text-foreground outline-none focus:border-primary/50"
          />
          {bulkCount != null && bulkCount > 0 && (
            <p className="text-[10px] leading-relaxed text-amber-600">
              This same comment is recorded on all {bulkCount} affected candidate
              {bulkCount === 1 ? "" : "s"}, marked <b>(bulk-apply)</b>.
            </p>
          )}
        </div>

        <div className="mt-4 flex justify-end gap-2">
          <button
            type="button"
            onClick={onCancel}
            disabled={pending}
            className="rounded-lg border border-border px-3.5 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-secondary disabled:opacity-40"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={() => onApply(comment.trim())}
            disabled={pending}
            className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3.5 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-primary/90 disabled:opacity-40"
          >
            {pending && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
