// Candidate sticky notes — a recruiter can stick a note on a candidate at any
// time. The LATEST note lives on candidate_master.latest_note and renders as
// a yellow sticky on the Candidate page (plus a small sticky badge next to
// the candidate's name anywhere lists show it); the FULL history is in the
// Actions Audit Log (step = candidate_note), which the sticky's footnote
// points at. Deliberately single-theme: a sticky note is yellow, both modes.
import { useEffect, useState } from "react";
import { Loader2, StickyNote, Trash2, UserPlus, X } from "lucide-react";

// Referral payload — enriched onto candidate rows (list) and detail by the API
// when the resume's sender matches Settings → Referrals. message may be "".
export interface CandidateReferral {
  referred_by: string;
  message: string;
}

/** Green referral symbol next to a candidate's name — shown wherever the name
 *  appears when the candidate is a referral. Tooltip = referred-by (+ message). */
export function ReferralBadge({ referral, className }: { referral?: CandidateReferral | null; className?: string }) {
  if (!referral?.referred_by) return null;
  const tip = referral.message
    ? `${referral.message} — Referred by: ${referral.referred_by}`
    : `Referred by: ${referral.referred_by}`;
  return (
    <span
      title={tip}
      className={`inline-flex shrink-0 items-center justify-center ${className ?? ""}`}
    >
      <UserPlus className="h-3.5 w-3.5 text-emerald-600" />
    </span>
  );
}

export interface CandidateNotePayload {
  text: string;
  author: string;
  created_at: string;
}

// Notes and remarks are short by design — capped so they stay readable inside
// the sticky card without overflowing it (also enforced server-side).
export const NOTE_MAX_CHARS = 250;

const fmtWhen = (iso: string) => {
  const d = new Date(iso);
  return Number.isNaN(d.getTime())
    ? ""
    : d.toLocaleString("en-IN", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
};

/** Small yellow sticky symbol next to a candidate's name — tooltip = the note. */
export function NoteBadge({ note, className }: { note?: CandidateNotePayload | null; className?: string }) {
  if (!note?.text) return null;
  return (
    <span
      title={`Note (${note.author}${note.created_at ? `, ${fmtWhen(note.created_at)}` : ""}): ${note.text}`}
      className={`inline-flex shrink-0 items-center justify-center ${className ?? ""}`}
    >
      <StickyNote className="h-3.5 w-3.5 fill-amber-300/70 text-amber-600" />
    </span>
  );
}

/** The sticky note itself — latest note only, with the history footnote. */
export function StickyNoteCard({
  note,
  onAdd,
  onDelete,
}: {
  note?: CandidateNotePayload | null;
  onAdd: () => void;
  // Deletes the LATEST note (clears the sticky + badge). The deletion — old
  // text included — is written to the Actions Audit Log by the backend.
  onDelete?: () => void;
}) {
  if (!note?.text) return null;
  return (
    <div className="w-full max-w-xs shrink-0 self-start sm:w-64">
      <div className="-rotate-1 rounded-sm border border-amber-300/60 bg-amber-100 px-3.5 pb-2.5 pt-3 shadow-[2px_4px_10px_rgba(120,84,10,0.25)]">
        <div className="mb-1 flex items-center justify-between gap-2">
          <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wide text-amber-700">
            <StickyNote className="h-3 w-3" /> Note
          </span>
          <span className="flex items-center gap-0.5">
            <button
              type="button"
              onClick={onAdd}
              className="rounded px-1.5 py-0.5 text-[10px] font-semibold text-amber-700 underline decoration-dotted underline-offset-2 hover:bg-amber-200/70"
            >
              Add note
            </button>
            {onDelete && (
              <button
                type="button"
                onClick={onDelete}
                title="Delete this note — the deletion is recorded in the Actions Audit Log"
                className="rounded p-1 text-amber-700 transition-colors hover:bg-amber-200/70 hover:text-rose-600"
              >
                <Trash2 className="h-3 w-3" />
              </button>
            )}
          </span>
        </div>
        <p className="max-w-full overflow-hidden whitespace-pre-wrap break-words [overflow-wrap:anywhere] text-xs leading-relaxed text-amber-950">
          {note.text}
        </p>
        <p className="mt-1.5 text-[10px] text-amber-700/90">
          — {note.author}
          {note.created_at ? ` · ${fmtWhen(note.created_at)}` : ""}
        </p>
        <p className="mt-1 border-t border-amber-300/60 pt-1 text-[9px] italic leading-snug text-amber-700/80">
          Latest note only — see the Actions Audit Log below for the full notes history.
        </p>
      </div>
    </div>
  );
}

/** The remark postit — blue, and noted as interviewer-visible. Edit opens the
 *  remark dialog; the footnote points at the history in the Actions Audit Log. */
export function StickyRemarkCard({
  remark,
  onEdit,
  // Read-only variant (interviewer view): no Edit link, and the footnote drops
  // the "visible to the interviewer" line (they ARE the interviewer).
  readOnly = false,
}: {
  remark?: CandidateNotePayload | null;
  onEdit?: () => void;
  readOnly?: boolean;
}) {
  if (!remark?.text) return null;
  return (
    <div className="w-full max-w-xs shrink-0 self-start sm:w-64">
      <div className="rotate-1 rounded-sm border border-sky-300/60 bg-sky-100 px-3.5 pb-2.5 pt-3 shadow-[2px_4px_10px_rgba(10,74,120,0.25)]">
        <div className="mb-1 flex items-center justify-between gap-2">
          <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wide text-sky-700">
            <StickyNote className="h-3 w-3" /> {readOnly ? "Recruiter's remark" : "Remark"}
          </span>
          {!readOnly && onEdit && (
            <button
              type="button"
              onClick={onEdit}
              className="rounded px-1.5 py-0.5 text-[10px] font-semibold text-sky-700 underline decoration-dotted underline-offset-2 hover:bg-sky-200/70"
            >
              Edit
            </button>
          )}
        </div>
        <p className="max-w-full overflow-hidden whitespace-pre-wrap break-words [overflow-wrap:anywhere] text-xs leading-relaxed text-sky-950">
          {remark.text}
        </p>
        <p className="mt-1.5 text-[10px] text-sky-700/90">
          — {remark.author}
          {remark.created_at ? ` · ${fmtWhen(remark.created_at)}` : ""}
        </p>
        {!readOnly && (
          <p className="mt-1 border-t border-sky-300/60 pt-1 text-[9px] italic leading-snug text-sky-700/80">
            Visible to the interviewer · full history in the Actions Audit Log below.
          </p>
        )}
      </div>
    </div>
  );
}

/** Small BLUE note symbol next to a candidate's name — the remark (shared
 *  with the interviewer, unlike the yellow internal note). Tooltip = text. */
export function RemarkBadge({ remark, className }: { remark?: CandidateNotePayload | null; className?: string }) {
  if (!remark?.text) return null;
  return (
    <span
      title={`Remark (${remark.author}${remark.created_at ? `, ${fmtWhen(remark.created_at)}` : ""}): ${remark.text}`}
      className={`inline-flex shrink-0 items-center justify-center ${className ?? ""}`}
    >
      <StickyNote className="h-3.5 w-3.5 fill-sky-300/70 text-sky-600" />
    </span>
  );
}

/** Popup to write/edit a REMARK (blue, interviewer-visible). Prefills with the
 *  current remark; empty save removes it. */
export function EditRemarkDialog({
  open,
  candidateName,
  current,
  pending,
  onCancel,
  onSave,
}: {
  open: boolean;
  candidateName: string;
  current?: CandidateNotePayload | null;
  pending?: boolean;
  onCancel: () => void;
  onSave: (text: string) => void;
}) {
  const [text, setText] = useState("");
  useEffect(() => {
    if (open) setText(current?.text ?? "");
  }, [open, current]);
  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center bg-foreground/40 p-4 backdrop-blur-sm"
      onClick={() => !pending && onCancel()}
    >
      <div
        className="w-full max-w-md rounded-2xl border border-border bg-card p-5 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-sky-400/20 text-sky-600">
              <StickyNote className="h-4.5 w-4.5" />
            </span>
            <div>
              <h3 className="text-sm font-bold text-foreground">
                {current?.text ? "Edit remark" : "Add a remark"}
              </h3>
              <p className="text-[11px] text-muted-foreground">{candidateName}</p>
            </div>
          </div>
          <button
            onClick={onCancel}
            className="rounded-lg p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value.slice(0, NOTE_MAX_CHARS))}
          rows={4}
          autoFocus
          maxLength={NOTE_MAX_CHARS}
          placeholder="A remark for the record — also shown to the interviewer…"
          className="mt-3 w-full resize-y rounded-lg border border-border bg-background px-2.5 py-1.5 text-xs text-foreground outline-none focus:border-primary/50"
        />
        <p className="mt-1 flex items-center justify-between text-[10px] text-muted-foreground">
          <span>
            Only one remark stays (replacing any previous). It's <b>visible to the interviewer</b>;
            save it empty to remove it.
          </span>
          <span className="shrink-0 tabular-nums">{text.length}/{NOTE_MAX_CHARS}</span>
        </p>
        <div className="mt-4 flex justify-end gap-2">
          <button
            type="button"
            onClick={onCancel}
            disabled={pending}
            className="rounded-lg border border-border px-3.5 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-secondary disabled:opacity-40"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={() => onSave(text.trim())}
            disabled={pending || text.trim() === (current?.text ?? "")}
            className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3.5 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-primary/90 disabled:opacity-40"
          >
            {pending && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
            {text.trim() ? "Save remark" : current?.text ? "Remove remark" : "Save"}
          </button>
        </div>
      </div>
    </div>
  );
}

/** Popup to write a note — Cancel abandons, Save sticks it + logs it. */
export function AddNoteDialog({
  open,
  candidateName,
  pending,
  onCancel,
  onSave,
}: {
  open: boolean;
  candidateName: string;
  pending?: boolean;
  onCancel: () => void;
  onSave: (text: string) => void;
}) {
  const [text, setText] = useState("");
  useEffect(() => {
    if (open) setText("");
  }, [open]);
  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center bg-foreground/40 p-4 backdrop-blur-sm"
      onClick={() => !pending && onCancel()}
    >
      <div
        className="w-full max-w-md rounded-2xl border border-border bg-card p-5 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-amber-400/20 text-amber-600">
              <StickyNote className="h-4.5 w-4.5" />
            </span>
            <div>
              <h3 className="text-sm font-bold text-foreground">Add a note</h3>
              <p className="text-[11px] text-muted-foreground">{candidateName}</p>
            </div>
          </div>
          <button
            onClick={onCancel}
            className="rounded-lg p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value.slice(0, NOTE_MAX_CHARS))}
          rows={4}
          autoFocus
          maxLength={NOTE_MAX_CHARS}
          placeholder="Anything worth remembering about this candidate…"
          className="mt-3 w-full resize-y rounded-lg border border-border bg-background px-2.5 py-1.5 text-xs text-foreground outline-none focus:border-primary/50"
        />
        <p className="mt-1 flex items-center justify-between text-[10px] text-muted-foreground">
          <span>
            Becomes the candidate's sticky note (replacing the previous one) and is recorded in the
            Actions Audit Log.
          </span>
          <span className="shrink-0 tabular-nums">{text.length}/{NOTE_MAX_CHARS}</span>
        </p>
        <div className="mt-4 flex justify-end gap-2">
          <button
            type="button"
            onClick={onCancel}
            disabled={pending}
            className="rounded-lg border border-border px-3.5 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-secondary disabled:opacity-40"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={() => onSave(text.trim())}
            disabled={pending || !text.trim()}
            className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3.5 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-primary/90 disabled:opacity-40"
          >
            {pending && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
            Stick it
          </button>
        </div>
      </div>
    </div>
  );
}
