// "Why this NLRS" breakdown — mirrors ScoreBreakdown.tsx's ATS treatment, but
// built from c.nlrs.components (label/weight/subscore/weighted, computed live
// by app.services.nlrs) instead of the ATS score columns. No penalties/bonus
// row here — NLRS has no such concept, just weighted components.
import { cn, formatScore } from "@/lib/utils";
import type { CandidateMaster } from "@/types";

// Bar/number colour for a 0–100 dimension subscore — same bands as ScoreBreakdown.
function subscoreTone(s: number): { bar: string; text: string } {
  if (s >= 60) return { bar: "bg-emerald-400/70", text: "text-emerald-500" };
  if (s >= 40) return { bar: "bg-amber-400/70", text: "text-amber-500" };
  return { bar: "bg-rose-400/70", text: "text-rose-500" };
}

export function hasNlrsBreakdown(c: CandidateMaster): boolean {
  return c.nlrs != null && c.nlrs.components.length > 0;
}

export default function NlrsScoreBreakdown({ c }: { c: CandidateMaster }) {
  if (c.nlrs == null || c.nlrs.components.length === 0) return null;
  const score = c.nlrs.score;
  const band = score >= 70 ? "strong match" : score >= 45 ? "solid match" : "weak match";

  return (
    <div>
      <div className="mb-2.5 flex items-baseline justify-between gap-2">
        <span className="text-[10px] font-semibold uppercase tracking-wide text-ink-mute">
          NLRS Score Breakdown
        </span>
        <span className="tnum text-xs font-bold text-ink">
          {formatScore(score)}
          <span className="font-medium text-ink-mute">/100 · {band}</span>
        </span>
      </div>

      <div className="space-y-1.5">
        {c.nlrs.components.map((k) => {
          const sub = Math.round(k.subscore);
          const tone = subscoreTone(k.subscore);
          return (
            <div key={k.label} className="flex items-center gap-2">
              <span className="w-28 shrink-0 truncate text-[11px] text-ink-mute" title={k.label}>
                {k.label}
              </span>
              <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-secondary">
                <div className={cn("h-full rounded-full", tone.bar)} style={{ width: `${Math.max(2, sub)}%` }} />
              </div>
              <span className={cn("w-7 shrink-0 text-right tnum text-[11px] font-semibold", tone.text)}>{sub}</span>
              <span className="w-12 shrink-0 text-right tnum text-[11px] text-ink-mute">+{k.weighted.toFixed(1)}</span>
            </div>
          );
        })}
      </div>

      <p className="mt-2 text-[10px] leading-relaxed text-ink-mute/80">
        Bars show each area scored out of 100; the right column is the points it added to the {formatScore(score)}/100 total.
      </p>
    </div>
  );
}
