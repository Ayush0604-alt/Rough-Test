// Deterministic "why this ATS score" breakdown — built straight from the score columns
// (app.services.ats_scoring): each dimension's 0–100 subscore as a bar, the points it
// contributed to the total, plus any certificate bonus and penalties. No LLM, no prose —
// the bars and numbers ARE the explanation, and the contributions (+ bonus − penalties)
// reconcile exactly to the displayed score.
//
// Shared by the Candidate profile page and the Screening table's clickable ATS popover.
import type { ReactNode } from "react";
import { X } from "lucide-react";
import { cn, formatScore, formatExperience, titleCase } from "@/lib/utils";
import { parseCertificates, type AnalysisReport, type CandidateMaster } from "@/types";

// The popover shell shared by every clickable score cell (ATS/NLRS, Screening/
// Dashboard) — name + candidate_id header, close button, body slot. Pulled out
// once this became a 4th near-identical copy (ATS + NLRS × Screening + Dashboard)
// rather than kept as hand-rolled JSX in each table.
export function ScorePopoverModal({
  candidate,
  subtitle,
  onClose,
  children,
}: {
  candidate: CandidateMaster;
  subtitle: string;
  onClose: () => void;
  children: ReactNode;
}) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/40 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="flex max-h-[85vh] w-full max-w-md flex-col rounded-2xl border border-border bg-card shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex shrink-0 items-start justify-between gap-3 border-b border-border px-5 py-3.5">
          <div className="min-w-0">
            <h2 className="truncate text-sm font-bold text-foreground">
              {candidate.name ? titleCase(candidate.name) : candidate.candidate_id}
            </h2>
            <p className="text-[11px] text-muted-foreground">
              {subtitle} · {candidate.candidate_id}
            </p>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto px-5 py-4">{children}</div>
      </div>
    </div>
  );
}

// Plain-English label for each score component, keyed to the labels emitted by
// app.services.ats_scoring. Falls back to the raw label if one is unmapped.
const SCORE_COMPONENT_LABEL: Record<string, string> = {
  "llm track fit": "Role fit",
  "skill / keyword match": "Skills & keywords",
  "experience match": "Work experience",
  "education match": "Education",
  "resume format / completeness": "Resume completeness",
};

export function componentLabel(component: string): string {
  return SCORE_COMPONENT_LABEL[component.toLowerCase().trim()] ?? component;
}

// Bar/number colour for a 0–100 dimension subscore: strong (green) / mixed (amber) /
// weak (rose). Keeps the breakdown scannable at a glance.
function subscoreTone(s: number): { bar: string; text: string } {
  if (s >= 60) return { bar: "bg-emerald-400/70", text: "text-emerald-500" };
  if (s >= 40) return { bar: "bg-amber-400/70", text: "text-amber-500" };
  return { bar: "bg-rose-400/70", text: "text-rose-500" };
}

// The weighted breakdown rows (weight > 0), strongest contribution first.
function rows(c: CandidateMaster) {
  return (Array.isArray(c.score_breakdown) ? c.score_breakdown : [])
    .filter((b) => b.weight > 0)
    .sort((a, b) => b.weighted - a.weighted);
}

// True when there's an ATS score AND at least one weighted dimension to explain — the gate
// for making the score clickable.
export function hasScoreBreakdown(c: CandidateMaster): boolean {
  return c.atsscore != null && rows(c).length > 0;
}

export default function ScoreBreakdown({ c }: { c: CandidateMaster }) {
  if (c.atsscore == null) return null;
  const breakdown = rows(c);
  const penalties = Array.isArray(c.score_penalties) ? c.score_penalties : [];
  const cert = c.certification_bonus;
  const score = c.atsscore;
  if (breakdown.length === 0) return null;

  const band =
    score >= 75 ? "strong match"
    : score >= 50 ? "solid match"
    : score >= 30 ? "partial match"
    : "weak match";

  return (
    <div>
      <div className="mb-2.5 flex items-baseline justify-between gap-2">
        <span className="text-[10px] font-semibold uppercase tracking-wide text-ink-mute">
          ATS Score Breakdown
        </span>
        <span className="tnum text-xs font-bold text-ink">
          {formatScore(score)}
          <span className="font-medium text-ink-mute">/100 · {band}</span>
        </span>
      </div>

      <div className="space-y-1.5">
        {breakdown.map((b) => {
          const sub = Math.round(b.subscore);
          const tone = subscoreTone(b.subscore);
          return (
            <div key={b.component} className="flex items-center gap-2">
              <span className="w-28 shrink-0 truncate text-[11px] text-ink-mute" title={componentLabel(b.component)}>
                {componentLabel(b.component)}
              </span>
              <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-secondary">
                <div className={cn("h-full rounded-full", tone.bar)} style={{ width: `${Math.max(2, sub)}%` }} />
              </div>
              <span className={cn("w-7 shrink-0 text-right tnum text-[11px] font-semibold", tone.text)}>{sub}</span>
              <span className="w-12 shrink-0 text-right tnum text-[11px] text-ink-mute">+{b.weighted.toFixed(1)}</span>
            </div>
          );
        })}
      </div>

      {(penalties.length > 0 || (cert && cert.points > 0)) && (
        <div className="mt-2 space-y-1 border-t border-border/40 pt-2">
          {cert && cert.points > 0 && (
            <div className="flex items-center justify-between gap-2 text-[11px]">
              <span className="text-ink-mute">
                Certification bonus{cert.certs?.length ? ` (${cert.certs.length})` : ""}
              </span>
              <span className="tnum font-semibold text-emerald-500">+{cert.points.toFixed(1)}</span>
            </div>
          )}
          {penalties.map((p, i) => (
            <div key={i} className="flex items-center justify-between gap-2 text-[11px]">
              <span className="text-ink-mute">{p.reason}</span>
              <span className="tnum shrink-0 font-semibold text-rose-500">−{Math.round(p.points)}</span>
            </div>
          ))}
        </div>
      )}

      <p className="mt-2 text-[10px] leading-relaxed text-ink-mute/80">
        Bars show each area scored out of 100; the right column is the points it added to the {score}/100 total.
      </p>
    </div>
  );
}

// "Why this NLRS score" breakdown — same bars-are-the-explanation treatment as
// ScoreBreakdown above, but for the NLRS composite (app.services.nlrs): each
// component already carries its own weight/subscore/weighted contribution, so
// this needs no separate label-mapping or reconstruction, just the same layout.
// Shared by the Candidate profile page and the Screening table's clickable
// NLRS popover.

// Mirrors the NLRS-banded predicted-NBA thresholds in app/services/nlrs.py
// (>=70 call_now, >=45 undecided, else reject) so the band reads consistently
// with whatever NBA the score actually predicted.
function nlrsBand(score: number): string {
  if (score >= 70) return "strong candidate";
  if (score >= 45) return "borderline candidate";
  return "weak candidate";
}

// True when there's an NLRS score AND at least one component to explain — the
// gate for making the score clickable.
export function hasNlrsBreakdown(c: CandidateMaster): boolean {
  return c.nlrs != null && c.nlrs.components.length > 0;
}

// The underlying raw figure behind a component's normalized 0–100 subscore —
// e.g. "Years of experience: 70" reads a lot clearer as "70 (7.0y)". Only the
// components with a simple 1:1 real-world number get one; "Analysis Report" is
// an LLM read with no single raw figure to show.
function nlrsActualValue(label: string, c: CandidateMaster): string | null {
  switch (label) {
    case "Years of experience":
      return c.fresher_or_lateral === "Fresher" || !c.yearofexp ? "0.0y" : formatExperience(c.yearofexp);
    case "Certificates": {
      const n = parseCertificates(c.certificates).length;
      return `${n} cert${n === 1 ? "" : "s"}`;
    }
    case "ATS":
      return c.atsscore != null ? formatScore(c.atsscore) : null;
    default:
      return null;
  }
}

export function NlrsBreakdown({ c }: { c: CandidateMaster }) {
  const nlrs = c.nlrs;
  if (!nlrs || nlrs.components.length === 0) return null;
  const score = nlrs.score;
  const components = [...nlrs.components].sort((a, b) => b.weighted - a.weighted);

  return (
    <div>
      <div className="mb-2.5 flex items-baseline justify-between gap-2">
        <span className="text-[10px] font-semibold uppercase tracking-wide text-ink-mute">
          NLRS Breakdown
        </span>
        <span className="tnum text-xs font-bold text-ink">
          {formatScore(score)}
          <span className="font-medium text-ink-mute">/100 · {nlrsBand(score)}</span>
        </span>
      </div>

      <div className="space-y-1.5">
        {components.map((comp) => {
          const sub = Math.round(comp.subscore);
          const tone = subscoreTone(comp.subscore);
          const actual = nlrsActualValue(comp.label, c);
          return (
            <div key={comp.label} className="flex items-center gap-2">
              <span className="w-28 shrink-0 truncate text-[11px] text-ink-mute" title={comp.label}>
                {comp.label}
              </span>
              <span className="w-14 shrink-0 truncate text-right tnum text-[10px] text-ink-mute/70" title={actual ?? undefined}>
                {actual ?? ""}
              </span>
              <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-secondary">
                <div className={cn("h-full rounded-full", tone.bar)} style={{ width: `${Math.max(2, sub)}%` }} />
              </div>
              <span className={cn("w-7 shrink-0 text-right tnum text-[11px] font-semibold", tone.text)}>{sub}</span>
              <span className="w-12 shrink-0 text-right tnum text-[11px] text-ink-mute">
                +{comp.weighted.toFixed(1)}
              </span>
            </div>
          );
        })}
      </div>

      <p className="mt-2 text-[10px] leading-relaxed text-ink-mute/80">
        Bars show each area scored out of 100; the right column is the points it added to the {formatScore(score)}/100
        total — weighted 65% Analysis Report · 20% Certificates · 10% Experience · 5% ATS.
      </p>
    </div>
  );
}

// NBA keys the NLRS-band predictor uses to fast-track a candidate PAST one or
// more rounds (app.services.nlrs.predicted_nba_key's three high bands, above
// the long-standing "call_now"/Screening baseline) — see nlrs_config.py.
// Skipping rounds is consequential enough to warrant more than a one-line
// reason, so these get the fuller strengths/pros-cons treatment below.
const _FAST_TRACK_KEYS = new Set(["final_round", "share_round2", "share_round1"]);

function componentActual(label: string, c: CandidateMaster): string {
  const v = nlrsActualValue(label, c);
  return v ? ` (${v})` : "";
}

// ── Analysis-report grounding — the prediction's REASONING leads with what the
// analyst (LLM) actually concluded about THIS candidate, not the score math.
// The NLRS number decides which band fires; the Analysis Report says WHY the
// candidate deserved that read, so the explanation quotes it directly and only
// footnotes the numbers. ──

// The LLM's holistic prose read — everything in `analysis` before the numeric
// "ATS NN/100 (scored)" tail (same split as screeningColumns' Thinking Summary).
function analysisNarrative(c: CandidateMaster): string {
  return (c.analysis ?? "").split(/\n*\s*ATS\s+\d+\/100\s*\((?:deterministic|scored)\)/i)[0].trim();
}

function splitSentences(text: string): string[] {
  return (text.replace(/\s+/g, " ").match(/[^.!?]+[.!?]+(?:\s|$)|[^.!?]+$/g) ?? [])
    .map((s) => s.trim())
    .filter(Boolean);
}

// The structured Analysis Report (experience level, projects, certs, gaps…) —
// tolerate the legacy string-encoded form.
function parsedReport(c: CandidateMaster): AnalysisReport | null {
  const r = c.analysis_report;
  if (!r) return null;
  if (typeof r === "string") {
    try {
      const o = JSON.parse(r);
      return o && typeof o === "object" ? (o as AnalysisReport) : null;
    } catch {
      return null;
    }
  }
  return r;
}

// First sentence of a report field — the fields are already tight, but one
// sentence keeps the reasons list scannable.
function firstSentence(text: string | null | undefined): string | null {
  const s = splitSentences((text ?? "").trim());
  return s.length ? s[0] : null;
}

// The verified career-gap finding, if the analysis found one — the single most
// interview-worthy caveat the report produces (e.g. "Verified timeline shows 1
// career gap totaling 4 months."). Deliberately searches the FULL analysis
// text (the verification tail included), and skips "0 gaps" phrasings.
function gapFinding(c: CandidateMaster): string | null {
  for (const s of splitSentences(c.analysis ?? "")) {
    if (/career gap|employment gap/i.test(s) && !/\b(0|no|zero)\s+(career|employment)?\s*gaps?/i.test(s)) {
      return s;
    }
  }
  return null;
}

// Compact numeric footnote: the composite + each component's subscore, so the
// numbers stay available without being the story.
function scoreFootnote(c: CandidateMaster): string {
  const nlrs = c.nlrs!;
  const parts = [...nlrs.components]
    .sort((a, b) => b.weighted - a.weighted)
    .map((k) => `${k.label}${componentActual(k.label, c)} ${Math.round(k.subscore)}`);
  return `Backed by the numbers: NLRS ${formatScore(nlrs.score)}/100 · ${parts.join(" · ")}.`;
}

// "Why was THIS action predicted" explanation — the SAME fuller treatment for
// every prediction: an adaptive intro grounded in the Analysis Report, a
// numbered list of reasons (role fit → experience → certifications → projects,
// falling back to the top scoring components), then Strengths / Concerns. A
// fast-track prediction (straight to Round 1/Round 2/Final) additionally gets
// its "skip ahead" framing + emerald styling; everything else is neutral.
export function PredictedNbaReason({ c, predictedLabel }: { c: CandidateMaster; predictedLabel: string }) {
  const nlrs = c.nlrs;
  if (!nlrs || nlrs.components.length === 0) return null;

  const isFastTrack = !!(c.predicted_nba && _FAST_TRACK_KEYS.has(c.predicted_nba));
  const report = parsedReport(c);
  const narrative = analysisNarrative(c);
  const gap = gapFinding(c);

  // Reasons for THIS call — strongest evidence first (role fit → experience →
  // certifications → projects), falling back to the top scoring components when
  // there's no analysis narrative at all.
  const reasons: { label: string; text: string }[] = [];
  const fit = splitSentences(narrative)[0];
  if (fit) reasons.push({ label: "Role fit", text: fit });
  const exp = firstSentence(report?.experience_level);
  if (exp) reasons.push({ label: "Experience", text: exp });
  const certs = firstSentence(report?.professional_certifications);
  if (certs) reasons.push({ label: "Certifications", text: certs });
  const projects = firstSentence(report?.company_projects);
  if (projects) reasons.push({ label: "Hands-on projects", text: projects });
  if (reasons.length === 0) {
    for (const k of [...nlrs.components].sort((a, b) => b.subscore - a.subscore).slice(0, 3)) {
      reasons.push({ label: k.label, text: `${Math.round(k.subscore)}/100${componentActual(k.label, c)}.` });
    }
  }
  const topReasons = reasons.slice(0, 3);

  // Strengths: analysis evidence beyond the top-3 reasons + positive rule
  // adjustments, else the components scoring ≥70. Concerns: report caveats
  // (career gaps) first, then whatever the scoring flagged as comparatively weak.
  const usedTexts = new Set(topReasons.map((r) => r.text));
  const strengths: string[] = reasons.filter((r) => !usedTexts.has(r.text)).map((r) => r.text);
  for (const a of nlrs.adjustments.filter((x) => x.points > 0)) strengths.push(`${a.label} (+${a.points} pts).`);
  if (strengths.length === 0) {
    for (const k of nlrs.components.filter((k) => k.subscore >= 70)) {
      strengths.push(`${k.label}${componentActual(k.label, c)} — ${Math.round(k.subscore)}/100.`);
    }
  }
  const concerns: string[] = [];
  if (gap) concerns.push(`${gap} Worth asking about directly.`);
  for (const k of nlrs.components.filter((x) => x.subscore < 50)) {
    concerns.push(`${k.label}${componentActual(k.label, c)} is comparatively weak at ${Math.round(k.subscore)}/100 — confirm in interview.`);
  }
  for (const a of nlrs.adjustments.filter((x) => x.points < 0)) {
    concerns.push(`${a.label} (${a.points} pts) — worth a direct question.`);
  }

  // Intro adapts to the prediction: fast-track keeps its "skip ahead" framing;
  // every other prediction gets a neutral lead grounded in the Analysis Report.
  const lead = splitSentences(narrative).slice(0, 2).join(" ");
  const introText = isFastTrack
    ? `Predicted "${predictedLabel}" — the Analysis Report reads this profile as an exceptional fit, and the composite cleared the fast-track bar reserved for exactly that, so the system recommends skipping ahead rather than repeating rounds a clearly promising candidate doesn't need.`
    : lead
      ? `Predicted "${predictedLabel}" — from the Analysis Report: ${lead} Weighted with certificates, experience and ATS, the NLRS is ${formatScore(nlrs.score)}/100 (${nlrsBand(nlrs.score)}), which maps to this action.`
      : `Predicted "${predictedLabel}" from an NLRS of ${formatScore(nlrs.score)}/100 (${nlrsBand(nlrs.score)}), driven mainly by ${[...nlrs.components].sort((a, b) => b.weighted - a.weighted)[0].label}.`;

  return (
    <div
      className={cn(
        "space-y-3 rounded-lg border p-3",
        isFastTrack ? "border-emerald-500/30 bg-emerald-500/5" : "border-border bg-secondary/30",
      )}
    >
      <div>
        <span
          className={cn(
            "text-[10px] font-semibold uppercase tracking-wide",
            isFastTrack ? "text-emerald-700 dark:text-emerald-400" : "text-ink-mute",
          )}
        >
          {isFastTrack ? `Fast-tracked — ${formatScore(nlrs.score)}/100 NLRS` : "Why this prediction"}
        </span>
        <p className="mt-1 text-xs leading-relaxed text-ink">{introText}</p>
      </div>

      <div>
        <span className="text-[10px] font-semibold uppercase tracking-wide text-ink-mute">
          {topReasons.length} reason{topReasons.length === 1 ? "" : "s"} for this call
        </span>
        <ol className="mt-1.5 space-y-1 pl-4 text-xs leading-relaxed text-ink [list-style-type:decimal]">
          {topReasons.map((r) => (
            <li key={r.label}>
              <span className="font-semibold">{r.label}</span>: {r.text}
            </li>
          ))}
        </ol>
        <p className="mt-1.5 text-[10px] leading-relaxed text-ink-mute/80">{scoreFootnote(c)}</p>
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <div>
          <span className="text-[10px] font-semibold uppercase tracking-wide text-emerald-700 dark:text-emerald-400">
            Strengths
          </span>
          <ul className="mt-1.5 space-y-1 pl-4 text-[11px] leading-relaxed text-ink [list-style-type:disc]">
            {strengths.map((p) => (
              <li key={p}>{p}</li>
            ))}
            {strengths.length === 0 && (
              <li>No standout dimension surfaced — the profile reads as broadly average on the scored signals.</li>
            )}
          </ul>
        </div>
        <div>
          <span className="text-[10px] font-semibold uppercase tracking-wide text-rose-600 dark:text-rose-400">
            Concerns
          </span>
          <ul className="mt-1.5 space-y-1 pl-4 text-[11px] leading-relaxed text-ink [list-style-type:disc]">
            {concerns.map((p) => (
              <li key={p}>{p}</li>
            ))}
            {concerns.length === 0 && (
              <li>The analysis surfaced no caveats — but a report doesn't replace a live read on communication/culture fit.</li>
            )}
          </ul>
        </div>
      </div>
    </div>
  );
}
