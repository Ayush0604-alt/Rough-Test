// The recruiter-facing "Analysis Report" — a model-generated 5-point screening summary
// (L3 extraction → ats.analysis_report). Shared by the candidate profile card and the
// Screening-list popover so the parse + render logic lives in ONE place.
import type { CandidateMaster, AnalysisReport } from "@/types";
import { cn } from "@/lib/utils";

// The five fixed points, in display order, with their human labels.
export const ANALYSIS_REPORT_POINTS: { key: keyof AnalysisReport; label: string }[] = [
  { key: "experience_level", label: "Fresher or Experienced" },
  { key: "graduation_and_window", label: "Graduation & Window" },
  { key: "work_start_and_gap", label: "Career Start & Gap" },
  { key: "company_projects", label: "Company Projects" },
  { key: "professional_certifications", label: "Industry Certifications" },
];

// analysis_report arrives as an object (or a JSON string from legacy/JSONB). Returns the
// non-empty points in display order, or [] when there is nothing to show.
export function parseAnalysisReport(
  v: CandidateMaster["analysis_report"],
): { label: string; text: string }[] {
  let report: AnalysisReport | null = null;
  if (v && typeof v === "object") {
    report = v as AnalysisReport;
  } else if (typeof v === "string" && v.trim()) {
    try {
      const parsed = JSON.parse(v);
      if (parsed && typeof parsed === "object") report = parsed as AnalysisReport;
    } catch {
      return [];
    }
  }
  if (!report) return [];
  return ANALYSIS_REPORT_POINTS.map(({ key, label }) => {
    const text = (report?.[key] ?? "").toString().trim();
    return text ? { label, text } : null;
  }).filter((x): x is { label: string; text: string } => x !== null);
}

// True when the candidate has at least one non-empty analysis-report point.
export function hasAnalysisReport(c: CandidateMaster): boolean {
  return parseAnalysisReport(c.analysis_report).length > 0;
}

// The numbered 5-point list. Renders a gentle empty state when nothing is stored yet.
export default function AnalysisReportBody({ c }: { c: CandidateMaster }) {
  const points = parseAnalysisReport(c.analysis_report);
  if (points.length === 0) {
    return (
      <p className="text-sm leading-relaxed text-muted-foreground">
        No analysis report yet — re-run extraction on this candidate to generate one.
      </p>
    );
  }
  return (
    <ol>
      {points.map(({ label, text }, i) => (
        <li
          key={label}
          className={cn(
            "flex gap-2.5 py-2.5 first:pt-0 last:pb-0",
            i < points.length - 1 && "border-b border-border/60",
          )}
        >
          <span className="mt-px flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary/10 text-[11px] font-bold text-primary">
            {i + 1}
          </span>
          <div className="min-w-0">
            <div className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
              {label}
            </div>
            <p className="mt-0.5 text-sm leading-relaxed text-foreground">{text}</p>
          </div>
        </li>
      ))}
    </ol>
  );
}
