import { useState } from "react";
import { X, Pencil, Check } from "lucide-react";
import { cn, titleCase } from "@/lib/utils";
import type { CandidateMaster } from "@/types/candidate";

// ── Next Best Action (NBA) override ─────────────────────────────────────────────
// Recruiter triage shown on the Dashboard's "New Potential Candidates" list and the
// Candidate detail page's "Proposed Next Best Action" box: a suggested next action
// (derived from ATS) that the recruiter can override via the "Update" dropdown.
// NOTE: the chosen override is captured and audit-logged (PATCH /next-action), but
// the described agent actions — sending the ack-email, moving the candidate through
// rounds, or handing off to a Hiring/Onboarding system — are NOT yet automated. The
// description text documents what SHOULD happen once that automation exists.
export type NbaKey =
  | "call_now"
  | "reject"
  | "undecided"
  | "office_interview"
  | "final_round"
  | "share_round3"
  | "share_round2"
  | "share_round1"
  | "hire"
  | "custom";

export interface NbaOverride {
  key: NbaKey;
  text?: string | null; // free-text instruction, set when key === "custom"
}

export const NBA_OPTIONS: { key: NbaKey; label: string; full: string }[] = [
  {
    key: "call_now",
    label: "Share interview slots for Screening",
    full: "Agent action: send an ack-email — acknowledge & ask the candidate to pick an interview slot via the link in the email",
  },
  {
    key: "reject",
    label: "Straight Reject",
    full: "Agent action: candidate is rejected & no email is sent — moves to the Reject bucket",
  },
  {
    key: "undecided",
    label: "Undecided for now",
    full: "Most freshers/interns fall here. Agent action: send an ack-email — let the candidate know we'll reach back when a matching opportunity arises. Moves to the Undecided bucket, so they can be pulled back into Round 1 or any other stage later (including a follow-up slot-picker email) once a matching opportunity arises",
  },
  {
    key: "office_interview",
    label: "Share interview slots for Final round (in-office)",
    full: "Agent action: send an ack-email — ask the candidate to pick an in-office interview slot via the link and come to the office — moves to the Final round",
  },
  {
    key: "final_round",
    label: "Share interview slots for Final round",
    full: "Agent action: send an ack-email — ask the candidate to pick an interview slot via the link in the email — moves to the Final round",
  },
  {
    key: "share_round2",
    label: "Share interview slots for Round 2",
    full: "System-predicted for a very strong candidate (NLRS fast-track band). Agent action: send an ack-email — ask the candidate to pick a Round 2 interview slot via the link in the email, skipping Screening and Round 1 to cut needless cycles for a clearly promising profile — moves to Round 2",
  },
  {
    key: "share_round1",
    label: "Share interview slots for Round 1",
    full: "System-predicted for a strong candidate (NLRS fast-track band). Agent action: send an ack-email — ask the candidate to pick a Round 1 interview slot via the link in the email, skipping Screening to cut needless cycles for a clearly promising profile — moves to Round 1",
  },
  {
    key: "share_round3",
    label: "Share interview slots for Round 3",
    full: "Agent action: send an ack-email — ask the candidate to pick a Round 3 interview slot via the link in the email — moves to Round 3 (the optional round, offered when the candidate's plan includes it)",
  },
  {
    key: "hire",
    label: "Mark for Immediate Hire / Send Offer letter",
    full: "Agent action: move to the Hiring System for offer preparation & invitation, then immediate onboarding (or wait out the notice period) — once joined, move to the Onboarding system for allocation & processing",
  },
  { key: "custom", label: "Custom", full: "Special instruction to the recruiter on this candidate" },
];

// Suggested NBA from the ATS score — the default shown until the recruiter overrides.
export function suggestedNba(c: CandidateMaster): NbaKey {
  const s = c.atsscore ?? 0;
  if (s >= 70) return "call_now";
  if (s >= 45) return "undecided";
  return "reject";
}

// The round each stage-moving NBA key sends the candidate to — mirrors the
// backend's _NBA_ROUND_EFFECTS (app/api/rounds.py) plus call_now (Screening).
const NBA_KEY_STAGE: Partial<Record<NbaKey, string>> = {
  call_now: "Screening",
  share_round1: "Round 1",
  share_round2: "Round 2",
  share_round3: "Round 3",
  final_round: "Final",
  office_interview: "Final",
};
const STAGE_FLOW = ["Screening", "Round 1", "Round 2", "Round 3", "Final"];

// Presentation order for the picker — walks the interview flow first
// (Screening → Round 1 → Round 2 → Round 3 → Final → in-office Final → Hire),
// then the park/stop actions, with Custom always last.
const NBA_KEY_ORDER: NbaKey[] = [
  "call_now",
  "share_round1",
  "share_round2",
  "share_round3",
  "final_round",
  "office_interview",
  "hire",
  "undecided",
  "reject",
  "custom",
];

// The suggestion the picker should highlight — the NLRS-predicted NBA when one
// exists (it's the system's real, candidate-specific call), else the applied
// override's own key, else the coarse ATS-band default. Without this, a
// candidate the system marked for Round 2 showed "Share slots for Screening"
// as Suggested.
export function suggestedNbaFor(c: CandidateMaster): NbaKey {
  return (c.predicted_nba as NbaKey | null) ?? c.next_action_override?.key ?? suggestedNba(c);
}

// The NBA options that make sense for THIS candidate's position in the flow.
// "Position" is the FURTHER of (a) the round they're actually in and (b) the
// round their predicted/applied NBA already points them at — a candidate the
// system marked for Round 2 (even while still New, prediction unapplied) must
// not be offered Screening/Round 1 slots again. The NBA-implied stage itself
// stays offered (it's a destination not yet reached); everything before it is
// a backward move and is dropped. Round 3 only appears when their plan
// includes it, non-stage actions (reject/undecided/hire/custom) always
// remain, and the result is in process order (NBA_KEY_ORDER) so the list
// reads like the flow itself.
export function nbaOptionsFor(c: CandidateMaster): typeof NBA_OPTIONS {
  const nbaKey = (c.next_action_override?.key ?? c.predicted_nba) as NbaKey | undefined;
  // A candidate parked in Reject/Undecided sits OUTSIDE the flow — pulling
  // them back in may restart ANYWHERE (redo the very round they fell at, or
  // even Screening), so every stage option is offered. The forward-only floor
  // below is only for candidates actively progressing: their roundname marks
  // ground already covered, a parked candidate's roundname merely marks where
  // they stopped.
  const parked =
    c.status === "Rejected" ||
    c.status === "Undecided" ||
    c.round_status === "Rejected" ||
    nbaKey === "reject" ||
    nbaKey === "undecided";
  const roundIdx = parked ? -1 : STAGE_FLOW.indexOf((c.roundname ?? "").trim()); // -1 = New
  const nbaStage = !parked && nbaKey ? NBA_KEY_STAGE[nbaKey] : undefined;
  const nbaIdx = nbaStage ? STAGE_FLOW.indexOf(nbaStage) - 1 : -1;
  const curIdx = Math.max(roundIdx, nbaIdx);
  return NBA_OPTIONS.filter((o) => {
    const stage = NBA_KEY_STAGE[o.key];
    if (!stage) return true;
    if (o.key === "share_round3" && !c.include_round3) return false;
    return STAGE_FLOW.indexOf(stage) > curIdx;
  }).sort((a, b) => NBA_KEY_ORDER.indexOf(a.key) - NBA_KEY_ORDER.indexOf(b.key));
}

// The NBA override option list — shared by the standalone "Update Next Action"
// dropdown and the bottom of the Analysis Report popup. Option 4 ("Custom") reveals
// a free-text instruction box.
export function NbaOptionsList({
  current,
  suggested,
  onSave,
  options,
}: {
  current?: NbaOverride;
  suggested: NbaKey;
  onSave: (ov: NbaOverride) => void;
  // Pass nbaOptionsFor(candidate) to scope the stage-moving actions to the
  // candidate's current position in the flow; defaults to the full list.
  options?: typeof NBA_OPTIONS;
}) {
  const [text, setText] = useState(current?.key === "custom" ? current.text ?? "" : "");

  return (
    <div className="space-y-1.5">
      {(options ?? NBA_OPTIONS).map((o) => {
        if (o.key === "custom") {
          return (
            <div key={o.key} className="rounded-xl border border-border p-2.5">
              <div className="mb-1.5 flex items-center gap-1.5 text-xs font-semibold text-foreground">
                <Pencil className="h-3.5 w-3.5 text-muted-foreground" /> Custom instruction
              </div>
              <textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                rows={2}
                placeholder="Type the next action…"
                className="w-full resize-none rounded-lg border border-border bg-background px-2.5 py-1.5 text-xs text-foreground outline-none focus:border-primary/50"
              />
              <button
                type="button"
                disabled={!text.trim()}
                onClick={() => onSave({ key: "custom", text: text.trim() })}
                className="mt-1.5 w-full rounded-lg bg-primary px-3 py-1.5 text-xs font-semibold text-white transition-opacity disabled:opacity-40"
              >
                Save instruction
              </button>
            </div>
          );
        }
        const selected = current?.key === o.key;
        const isSuggested = !current && o.key === suggested;
        return (
          <button
            key={o.key}
            type="button"
            onClick={() => onSave({ key: o.key })}
            className={cn(
              "flex w-full items-start gap-2 rounded-xl border px-3 py-2.5 text-left transition-colors",
              selected ? "border-primary/40 bg-primary/5" : "border-border hover:bg-secondary/60",
            )}
          >
            <span
              className={cn(
                "mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full border",
                selected ? "border-primary bg-primary text-white" : "border-muted-foreground/40",
              )}
            >
              {selected && <Check className="h-3 w-3" />}
            </span>
            <span className="min-w-0">
              <span className="flex items-center gap-1.5 text-xs font-semibold text-foreground">
                {o.label}
                {isSuggested && (
                  <span className="rounded-full bg-sky-500/10 px-1.5 py-px text-[9px] font-semibold text-sky-600">
                    Suggested
                  </span>
                )}
              </span>
              <span className="mt-0.5 block text-[11px] leading-snug text-muted-foreground">
                {o.full}
              </span>
            </span>
          </button>
        );
      })}
    </div>
  );
}

// The "Update Next Action" dropdown — a popover (bottom-sheet on mobile) wrapping
// NbaOptionsList with a candidate header.
export function NbaModal({
  candidate,
  current,
  suggested,
  onClose,
  onSave,
}: {
  candidate: CandidateMaster;
  current?: NbaOverride;
  suggested: NbaKey;
  onClose: () => void;
  onSave: (ov: NbaOverride) => void;
}) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-foreground/40 backdrop-blur-sm sm:items-center sm:p-4"
      onClick={onClose}
    >
      <div
        className="max-h-[85vh] w-full max-w-md overflow-hidden rounded-t-2xl border border-border bg-card shadow-xl sm:rounded-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3 border-b border-border px-5 py-3.5">
          <div className="min-w-0">
            <h2 className="truncate text-sm font-bold text-foreground">
              {candidate.name ? titleCase(candidate.name) : candidate.candidate_id}
            </h2>
            <p className="text-[11px] text-muted-foreground">Update Next Action</p>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        {/* 7 options each with a description easily exceed a laptop's viewport
            height — cap and scroll the body instead of the whole card
            overflowing past the top/bottom of the screen (the header and Save
            button were literally unreachable before this). */}
        <div className="max-h-[calc(85vh-3.5rem)] overflow-auto p-3">
          {/* The candidate-specific suggestion (predicted NBA) beats the
              coarse ATS-band default the callers pass — see suggestedNbaFor. */}
          <NbaOptionsList
            current={current}
            suggested={suggestedNbaFor(candidate) ?? suggested}
            onSave={onSave}
            options={nbaOptionsFor(candidate)}
          />
        </div>
      </div>
    </div>
  );
}

// Resolve an override (or the ATS-derived suggestion) to its display label.
// Defensive: a stored override key can predate an NBA_OPTIONS change (the option
// set has been renamed/reshaped before) — fall back to the raw key instead of
// throwing, so one stale row never blanks a whole list/page.
export function nbaLabel(c: CandidateMaster, override?: NbaOverride): string {
  const key = override?.key ?? suggestedNba(c);
  if (key === "custom") return override?.text?.trim() || "Custom instruction";
  return NBA_OPTIONS.find((o) => o.key === key)?.label ?? key;
}

// A candidate's NBA has exactly one of three states at any time — this is the
// single source of truth so every list/popup that shows it agrees:
//   Predicted  — still New-stage, nothing actioned yet (predicted_nba is set).
//   Applied    — the recruiter clicked Apply on the prediction as-is.
//   Overridden — an admin picked a different action via the override picker.
// predicted_nba goes null the instant EITHER Apply or Override saves (see
// app.services.nlrs.enrich_with_nlrs), so without this a candidate who was
// just actioned would misleadingly read as "no prediction" / blank.
export function nbaStatus(
  c: CandidateMaster,
): { tag: "Predicted" | "Applied" | "Overridden"; label: string } | null {
  if (c.predicted_nba) {
    return { tag: "Predicted", label: NBA_OPTIONS.find((o) => o.key === c.predicted_nba)?.label ?? c.predicted_nba };
  }
  if (c.next_action_override) {
    // Rows saved before `source` existed have neither value — infer the best
    // we can: a "custom" key can only ever come from the admin-only override
    // picker (Apply always computes a real predicted key, never "custom"), so
    // that's a reliable tell even without `source`. Otherwise default to
    // "Applied", the far more common path (Apply is available to every role;
    // the override picker is Admin-only).
    const tag =
      c.next_action_override.source === "manual" || c.next_action_override.key === "custom"
        ? "Overridden"
        : "Applied";
    return { tag, label: nbaLabel(c, c.next_action_override) };
  }
  return null;
}
