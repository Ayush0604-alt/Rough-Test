import { AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * Blinking caution shown next to a candidate's name when an auto-send slot-invite
 * was PAUSED because the interview slot-picker link couldn't be inserted (see
 * app.api.rounds._apply_nba_key). Hover for the reason; it clears once the draft
 * is sent (manually or after the pool/URL is fixed). Renders nothing when there's
 * no block.
 */
export default function InviteBlockBadge({
  reason,
  className,
}: {
  reason?: string | null;
  className?: string;
}) {
  if (!reason) return null;
  return (
    <span
      title={reason}
      aria-label={`Auto-send paused — ${reason}`}
      className={cn(
        "inline-flex shrink-0 animate-pulse items-center text-amber-500",
        className
      )}
    >
      <AlertTriangle className="h-3.5 w-3.5" />
    </span>
  );
}
