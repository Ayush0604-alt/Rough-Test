// The "Analysis Report" popover — Predicted NBA + Apply, quick facts, credentials,
// summary, the 5-point Analysis Report, and (Admin only) a "Change" trigger for
// manual NBA override. Shared by the Dashboard "New Potential Candidates Added"
// list and the Candidate profile page's "Report" button so both stay
// pixel-identical and only need one place to fix. Body text is deliberately
// text-sm/font-normal throughout — the app's global thin (300) display weight
// reads too light at the tiny sizes a dense info popup like this needs, in both
// themes. Apply and Change sit on opposite sides of the header, deliberately far
// apart — Apply commits the predicted action, Change opens a totally different
// one, so putting them side by side invited mis-clicks.
import { Fragment, useState } from "react";
import { NoteBadge, ReferralBadge } from "@/components/candidate/CandidateNote";
import {
  X,
  Check,
  FileText,
  Zap,
  Briefcase,
  Percent,
  Gauge,
  Clock3,
  GraduationCap,
  Award,
  Quote,
  ClipboardList,
  Settings2,
  Tag,
  ChevronDown,
} from "lucide-react";
import { cn, titleCase, formatExperience, formatScore, formatDate } from "@/lib/utils";
import { parseCertificates, type CandidateMaster } from "@/types/candidate";
import AnalysisReportBody from "./AnalysisReport";
import { NlrsBreakdown, PredictedNbaReason, hasNlrsBreakdown, ScorePopoverModal } from "./ScoreBreakdown";
import { NBA_OPTIONS, NbaModal, nbaStatus, suggestedNba, type NbaOverride } from "./NextActionOverride";
import { EmailDraftBadge } from "./EmailDraftReview";
import ConfirmDialog from "@/components/common/ConfirmDialog";

// Aging tier threshold — mirrors the Dashboard/Screening "stalled" cutoff.
const AGING_DAYS = 15;

// Exp/CGPA only — NLRS is rendered separately below (it's clickable, opening
// the same breakdown popover as the Dashboard/Screening tables).
function quickFacts(
  c: CandidateMaster,
): { icon: React.ElementType; label: string; value: string }[] {
  return [
    {
      icon: Briefcase,
      label: "Exp",
      value: c.fresher_or_lateral === "Fresher" ? "Fresher" : formatExperience(c.yearofexp),
    },
    { icon: Percent, label: "CGPA", value: c.cgpa != null ? c.cgpa.toFixed(1) : "—" },
  ];
}

export default function AnalysisReportModal({
  candidate,
  agingDays,
  isAdmin,
  canApplyPredicted,
  onClose,
  onViewResume,
  onApplyPredicted,
  applyPending,
  onOverrideSave,
  onReviewDraft,
}: {
  candidate: CandidateMaster;
  // Whole days in the candidate's current state, or null when unavailable
  // (terminal/no round yet) — the caller already has this computed.
  agingDays: number | null;
  isAdmin: boolean;
  // Settings → "Recruiters can apply predicted NBA" (always true for Admin,
  // regardless of that setting) — when false, a Recruiter sees "Admin review
  // pending…" in place of the Apply button. The apply-predicted-nba endpoint
  // enforces this server-side too, so this is UX, not the only gate.
  canApplyPredicted: boolean;
  onClose: () => void;
  onViewResume: () => void;
  onApplyPredicted: () => void;
  applyPending: boolean;
  onOverrideSave: (ov: NbaOverride) => void;
  onReviewDraft: () => void;
}) {
  const predictedLabel = candidate.predicted_nba
    ? NBA_OPTIONS.find((o) => o.key === candidate.predicted_nba)?.label ?? candidate.predicted_nba
    : null;
  // Once Apply or Change saves, predicted_nba goes null server-side — status
  // is what keeps the header from misleadingly reading "no prediction" for a
  // candidate that actually was already actioned (Applied or Overridden).
  const status = nbaStatus(candidate);
  const certs = parseCertificates(candidate.certificates);

  // Change (manual override) opens the existing NbaModal on top of this popup —
  // Admin-only, same as the PATCH endpoint it drives. Apply asks for confirmation
  // first since it moves the candidate forward immediately with no undo.
  const [changeOpen, setChangeOpen] = useState(false);
  const [confirmApplyOpen, setConfirmApplyOpen] = useState(false);
  const [nlrsOpen, setNlrsOpen] = useState(false);
  // The NLRS bars are the mechanics behind the prediction, not the point of
  // this popup when it's opened to explain a decision — collapsed by
  // default so the reason paragraph (and Apply/Change) lead instead.
  const [breakdownOpen, setBreakdownOpen] = useState(false);

  return (
    <Fragment>
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/40 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="flex max-h-[85vh] w-full max-w-lg flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header — Name on its own line, then an actions row with Apply pinned
            left and Predicted NBA + Change pinned right (Apply commits the
            prediction, Change opens a completely different one — kept far apart
            so a slip of the thumb can't fire the wrong one). Below sm: the row
            stacks into two explicit, always-left-aligned lines instead of
            relying on flex-wrap — a wrapped single flex item under
            justify-between lands at the start (not the end), which combined
            with the old text-right styling produced a mismatched, "off" look
            on phones (Apply flush left, but the Predicted NBA block righ-
            t-aligned inside a box only as wide as its own longest line, so it
            appeared to float independently instead of lining up). Close floats
            top-right — only the name gets right-padding to clear it.
            shrink-0: the header's real height varies (it can wrap to 2+ lines,
            plus an optional email-draft badge row) — it must never be
            squeezed by the flex layout below. */}
        <div className="relative shrink-0 border-b border-border px-5 py-3.5">
          <div className="min-w-0 pr-8">
            <h2 className="flex items-center gap-1.5 truncate text-base font-bold text-foreground">
              {candidate.name ? titleCase(candidate.name) : candidate.candidate_id}
              <ReferralBadge referral={candidate.referral} />
              <NoteBadge note={candidate.latest_note} />
            </h2>
            <p className="text-xs text-muted-foreground">{candidate.candidate_id}</p>
          </div>

          <div className="mt-3 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
              {predictedLabel ? (
                canApplyPredicted ? (
                  <button
                    type="button"
                    onClick={() => setConfirmApplyOpen(true)}
                    disabled={applyPending}
                    title="Apply the predicted Next Best Action — moves the candidate forward"
                    className="inline-flex shrink-0 items-center gap-1 rounded-full border border-emerald-500/40 bg-emerald-500/10 px-2.5 py-1 text-xs font-semibold text-emerald-600 transition-colors hover:bg-emerald-500/20 disabled:opacity-40"
                  >
                    <Check className="h-3 w-3" /> Apply
                  </button>
                ) : (
                  <span
                    title="Ask an Admin to turn this on in Settings, or to review this candidate directly"
                    className="inline-flex shrink-0 items-center gap-1 rounded-full border border-border bg-secondary px-2.5 py-1 text-xs font-medium text-muted-foreground"
                  >
                    <Clock3 className="h-3 w-3" /> Admin review pending…
                  </span>
                )
              ) : !status ? (
                <span className="text-xs text-muted-foreground">No prediction yet</span>
              ) : null}
            </div>

            <div className="flex items-center justify-between gap-2 sm:justify-end">
              {status && (
                status.tag === "Predicted" && hasNlrsBreakdown(candidate) ? (
                  <button
                    type="button"
                    onClick={() => setNlrsOpen(true)}
                    title="Show why this action was predicted for this candidate"
                    className="min-w-0 rounded-lg transition-colors hover:bg-secondary sm:text-right"
                  >
                    <div className="flex items-center gap-1 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground sm:justify-end">
                      <Zap className="h-3 w-3" />
                      {status.tag}
                    </div>
                    <div className="text-sm font-semibold text-foreground underline decoration-dotted underline-offset-2">
                      {status.label}
                    </div>
                  </button>
                ) : (
                  <div className="min-w-0 sm:text-right">
                    <div className="flex items-center gap-1 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground sm:justify-end">
                      <Zap className="h-3 w-3" />
                      {status.tag}
                    </div>
                    <div
                      className={cn(
                        "text-sm font-semibold",
                        status.tag === "Applied"
                          ? "text-emerald-600"
                          : status.tag === "Overridden"
                            ? "text-amber-600"
                            : "text-foreground",
                      )}
                    >
                      {status.label}
                    </div>
                  </div>
                )
              )}
              {isAdmin && (
                <button
                  type="button"
                  onClick={() => setChangeOpen(true)}
                  title="Override the Next Best Action"
                  className="inline-flex shrink-0 items-center gap-1 rounded-full border border-border px-2.5 py-1 text-xs font-semibold text-foreground transition-colors hover:border-primary/40 hover:bg-secondary"
                >
                  <Settings2 className="h-3 w-3" /> Change
                </button>
              )}
            </div>
          </div>

          {candidate.pending_email_draft && (
            <div className="mt-2">
              <EmailDraftBadge draft={candidate.pending_email_draft} onClick={onReviewDraft} />
            </div>
          )}

          <button
            onClick={onClose}
            className="absolute right-3 top-3 rounded-lg p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="min-h-0 flex-1 space-y-5 overflow-auto px-5 py-4">
          <button
            type="button"
            onClick={onViewResume}
            disabled={!candidate.s3_file_path}
            title={candidate.s3_file_path ? "Open resume viewer" : "No resume on file"}
            className="flex w-full items-center justify-center gap-1.5 rounded-xl border border-border px-3 py-2 text-sm font-medium text-foreground transition-colors hover:border-primary/40 hover:bg-secondary disabled:cursor-not-allowed disabled:opacity-40 sm:w-auto"
          >
            <FileText className="h-3.5 w-3.5" />
            View Resume
          </button>

          {/* Quick facts — Exp/CGPA/NLRS grouped left, Aging right. */}
          <div className="flex items-center justify-between rounded-xl border border-border bg-secondary/30 px-3.5 py-2.5">
            <div className="flex items-center gap-5">
              {quickFacts(candidate).map(({ icon: Icon, label, value }) => (
                <div key={label}>
                  <div className="flex items-center gap-1 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                    <Icon className="h-3 w-3" />
                    {label}
                  </div>
                  <div className="tnum text-base font-bold text-foreground">{value}</div>
                </div>
              ))}
              <div>
                <div className="flex items-center gap-1 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                  <Gauge className="h-3 w-3" />
                  NLRS
                </div>
                {hasNlrsBreakdown(candidate) ? (
                  <button
                    type="button"
                    onClick={() => setNlrsOpen(true)}
                    title="Show NLRS score breakdown"
                    className="tnum text-base font-bold text-foreground underline decoration-dotted underline-offset-2 transition-colors hover:text-primary"
                  >
                    {formatScore(candidate.nlrs?.score)}
                  </button>
                ) : (
                  <div className="tnum text-base font-bold text-foreground">{formatScore(candidate.nlrs?.score)}</div>
                )}
              </div>
            </div>
            <div className="text-right">
              <div className="flex items-center justify-end gap-1 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                <Clock3 className="h-3 w-3" />
                Aging
              </div>
              <div
                className={cn(
                  "tnum text-base font-bold",
                  agingDays != null && agingDays > AGING_DAYS ? "text-rose-500" : "text-foreground",
                )}
                title={`Received ${formatDate(candidate.mail_send_date)}`}
              >
                {agingDays != null ? `${agingDays}d` : "—"}
              </div>
            </div>
          </div>

          {/* Background — Source + College + Certificates grouped as one credentials card. */}
          <div className="divide-y divide-border rounded-xl border border-border">
            <div className="flex items-start gap-2.5 px-3.5 py-2.5">
              <Tag className="mt-0.5 h-3.5 w-3.5 shrink-0 text-muted-foreground" />
              <div className="min-w-0">
                <div className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Source</div>
                <p className="mt-0.5 text-sm text-foreground">{candidate.source ?? "—"}</p>
              </div>
            </div>
            <div className="flex items-start gap-2.5 px-3.5 py-2.5">
              <GraduationCap className="mt-0.5 h-3.5 w-3.5 shrink-0 text-muted-foreground" />
              <div className="min-w-0">
                <div className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">College</div>
                <p className="mt-0.5 text-sm text-foreground">{candidate.clg ?? "—"}</p>
              </div>
            </div>
            <div className="flex items-start gap-2.5 px-3.5 py-2.5">
              <Award className="mt-0.5 h-3.5 w-3.5 shrink-0 text-muted-foreground" />
              <div className="min-w-0 flex-1">
                <div className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Certificates</div>
                {certs.length === 0 ? (
                  <p className="mt-0.5 text-sm text-foreground">—</p>
                ) : (
                  <ul className="mt-1 list-disc space-y-1 pl-4 text-sm leading-relaxed text-foreground marker:text-muted-foreground">
                    {certs.map((cert) => (
                      <li key={cert.name}>{cert.name}</li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          </div>

          {/* One-Line Summary — quote treatment since it's a narrative line. */}
          <div className="flex gap-2.5 rounded-xl border-l-2 border-primary/40 bg-primary/[0.03] px-3.5 py-2.5">
            <Quote className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary/60" />
            <div className="min-w-0">
              <div className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">One-Line Summary</div>
              <p className="mt-0.5 text-sm italic leading-relaxed text-foreground">
                {candidate.role_context ?? "—"}
              </p>
            </div>
          </div>

          <div>
            <div className="mb-2 flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
              <ClipboardList className="h-3.5 w-3.5" />
              Analysis Report
            </div>
            <div className="rounded-xl border border-border bg-secondary/20 p-3.5">
              <AnalysisReportBody c={candidate} />
            </div>
          </div>
        </div>
      </div>
    </div>

    {/* Manual NBA override is Admin-only — hidden for the Recruitment Manager
        here just as it is elsewhere (and the PATCH endpoint 403s a recruiter
        regardless). Opened via the "Change" button in the header, stacked on
        top of this popup as a SIBLING (not nested inside its backdrop) so
        clicking the override modal's own backdrop doesn't bubble up and close
        this popup too. */}
    {isAdmin && changeOpen && (
      <NbaModal
        candidate={candidate}
        current={candidate.next_action_override ?? undefined}
        suggested={suggestedNba(candidate)}
        onClose={() => setChangeOpen(false)}
        onSave={(ov) => {
          setChangeOpen(false);
          onOverrideSave(ov);
        }}
      />
    )}

    {nlrsOpen && (() => {
      const showReason = status?.tag === "Predicted" && !!predictedLabel;
      // When opened to explain a prediction, the reason paragraph (+ Apply/
      // Change) is the point — the score bars are the mechanics behind it,
      // tucked behind a toggle instead of competing for attention. Opened
      // straight from the NLRS number (no reason to show), the bars ARE the
      // point, so they stay visible immediately.
      const showBreakdown = breakdownOpen || !showReason;
      return (
        <ScorePopoverModal candidate={candidate} subtitle="Why this NLRS score" onClose={() => setNlrsOpen(false)}>
          <div className="space-y-3">
            {showReason && (
              <>
                <PredictedNbaReason c={candidate} predictedLabel={predictedLabel!} />
                <div className="flex items-center gap-2">
                  {canApplyPredicted ? (
                    <button
                      type="button"
                      onClick={() => setConfirmApplyOpen(true)}
                      disabled={applyPending}
                      title="Apply the predicted Next Best Action — moves the candidate forward"
                      className="inline-flex shrink-0 items-center gap-1 rounded-full border border-emerald-500/40 bg-emerald-500/10 px-2.5 py-1 text-xs font-semibold text-emerald-600 transition-colors hover:bg-emerald-500/20 disabled:opacity-40"
                    >
                      <Check className="h-3 w-3" /> Apply
                    </button>
                  ) : (
                    <span
                      title="Ask an Admin to turn this on in Settings, or to review this candidate directly"
                      className="inline-flex shrink-0 items-center gap-1 rounded-full border border-border bg-secondary px-2.5 py-1 text-xs font-medium text-muted-foreground"
                    >
                      <Clock3 className="h-3 w-3" /> Admin review pending…
                    </span>
                  )}
                  {isAdmin && (
                    <button
                      type="button"
                      onClick={() => {
                        // Close this popover first — Change opens a full
                        // override picker, and stacking it behind/above the
                        // NLRS breakdown reads as cluttered rather than useful.
                        setNlrsOpen(false);
                        setChangeOpen(true);
                      }}
                      title="Override the Next Best Action"
                      className="inline-flex shrink-0 items-center gap-1 rounded-full border border-border px-2.5 py-1 text-xs font-semibold text-foreground transition-colors hover:border-primary/40 hover:bg-secondary"
                    >
                      <Settings2 className="h-3 w-3" /> Change
                    </button>
                  )}
                </div>
              </>
            )}

            <div>
              {showReason && (
                <button
                  type="button"
                  onClick={() => setBreakdownOpen((v) => !v)}
                  className="flex w-full items-center gap-1.5 text-[11px] font-semibold text-muted-foreground transition-colors hover:text-foreground"
                >
                  <ChevronDown className={cn("h-3.5 w-3.5 transition-transform", !showBreakdown && "-rotate-90")} />
                  NLRS score breakdown
                </button>
              )}
              {showBreakdown && (
                <div className={showReason ? "mt-2.5" : undefined}>
                  <NlrsBreakdown c={candidate} />
                </div>
              )}
            </div>
          </div>
        </ScorePopoverModal>
      );
    })()}

    <ConfirmDialog
      open={confirmApplyOpen}
      title="Apply predicted Next Best Action?"
      message={
        <>
          This moves{" "}
          <span className="font-semibold text-foreground">
            {candidate.name ? titleCase(candidate.name) : candidate.candidate_id}
          </span>{" "}
          forward as <span className="font-semibold text-foreground">{predictedLabel}</span> right away.
        </>
      }
      confirmLabel="Apply"
      pending={applyPending}
      onCancel={() => setConfirmApplyOpen(false)}
      onConfirm={() => {
        setConfirmApplyOpen(false);
        onApplyPredicted();
      }}
    />
    </Fragment>
  );
}
