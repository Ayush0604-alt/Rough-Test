// Bulk Filter — the panel opened from the "Filters" button on the Candidates page.
// One tab per filterable column (numeric ranges, categorical multi-selects, and keyword
// "contains" boxes). The recruiter sets any combination, hits "Apply filter", and the table
// both narrows to the matching candidates AND auto-reveals the columns they filtered on
// (see activeBulkColumnKeys). Facets AND together; an unset facet is ignored.
//
// This file owns the BulkFilters shape and its pure predicate (bulkFilterMatches). A couple
// of facets (Aging, Source) depend on data the row alone doesn't carry, so the Screening
// list passes them in via BulkMatchContext.
import { useEffect, useMemo, useState } from "react";
import { X, RotateCcw, Filter, Check, Lock, Search } from "lucide-react";
import type { CandidateMaster, JobRole } from "@/types";
import { certMatches, roundStageBucket, ROUND_FILTER_BUCKETS, roundLabel } from "@/lib/rounds";
import { cn } from "@/lib/utils";

// A two-sided inclusive numeric range. null on either side = unbounded that side.
export interface NumRange {
  min: number | null;
  max: number | null;
}

// Facets where 2+ options can be checked — each carries its own AND/OR mode (see
// MatchMode below) instead of the whole modal having one global setting, since
// "must have ALL of these skills" and "must be EITHER of these round stages"
// are both real recruiter asks on different tabs.
export type MultiFacetKey =
  | "streams"
  | "types"
  | "highestDegree"
  | "roundStatus"
  | "source"
  | "sourceTag"
  | "certs"
  | "domainTags"
  | "locationTags"
  | "jobRoleTags"
  | "primarySkillTags";

// "or" = candidate matches ANY checked option (the historical/default behavior
// for most facets). "and" = candidate must match EVERY checked option — only
// meaningful for facets backed by a multi-valued candidate field (Certificates,
// Primary Skills, Job Role); for single-valued fields (Stream, Round Status, …)
// checking 2+ options with "and" can never match anything, which is expected
// set-theoretically rather than a bug.
export type MatchMode = "or" | "and";

export interface BulkFilters {
  // Numeric ranges
  ats: NumRange; // atsscore 0–100
  experience: NumRange; // yearofexp (years)
  cgpa: NumRange; // cgpa 0–10
  passoutYear: NumRange; // passoutyr
  careerGap: NumRange; // gap_months (months)
  aging: NumRange; // days in current stage (context-supplied)
  // Categorical multi-selects (mode-controlled OR/AND within a facet — see matchMode)
  streams: string[];
  types: string[]; // Fresher / Lateral
  highestDegree: string[];
  roundStatus: string[]; // pipeline buckets
  source: string[]; // "Mail" | "Manual Upload" — the intake CHANNEL
  sourceTag: string[]; // registered social-post source tags (candidate.source)
  certs: string[]; // checked cert tags
  certKeyword: string; // free-text cert match (ANDed on top, regardless of mode)
  // Keyword "contains" boxes (comma-separated terms, ANDed) + chip pickers
  locationTags: string[]; // checked location chips
  location: string; // free-text location keyword (ANDed on top)
  domainTags: string[]; // checked domain chips
  domain: string; // free-text domain keyword (ANDed on top)
  college: string;
  currentCompany: string;
  jobRoleTags: string[]; // checked job-role chips (candidate may hold several)
  jobRole: string; // free-text job-role keyword (ANDed on top)
  projects: string;
  primarySkillTags: string[]; // checked common-skill chips
  primarySkills: string; // free-text skills keyword (ANDed on top)
  // Received-date range over mail_send_date
  dateFrom: string;
  dateTo: string;
  // Per-facet AND/OR — see MultiFacetKey/MatchMode above. Missing keys default to
  // "or" (loadBulkFilters merges over DEFAULT_MATCH_MODE so old saved filters and
  // new facets both resolve safely).
  matchMode: Record<MultiFacetKey, MatchMode>;
}

// Mirrors today's hardcoded behavior exactly, so extending BulkFilters with
// per-facet modes changes nothing for anyone with a filter already saved:
// Certificates and Primary Skills were always ANDed; everything else was ORed.
export const DEFAULT_MATCH_MODE: Record<MultiFacetKey, MatchMode> = {
  streams: "or",
  types: "or",
  highestDegree: "or",
  roundStatus: "or",
  source: "or",
  sourceTag: "or",
  certs: "and",
  domainTags: "or",
  locationTags: "or",
  jobRoleTags: "or",
  primarySkillTags: "and",
};

export const EMPTY_BULK_FILTERS: BulkFilters = {
  ats: { min: null, max: null },
  experience: { min: null, max: null },
  cgpa: { min: null, max: null },
  passoutYear: { min: null, max: null },
  careerGap: { min: null, max: null },
  aging: { min: null, max: null },
  streams: [],
  types: [],
  highestDegree: [],
  roundStatus: [],
  source: [],
  sourceTag: [],
  certs: [],
  certKeyword: "",
  locationTags: [],
  location: "",
  domainTags: [],
  domain: "",
  college: "",
  currentCompany: "",
  jobRoleTags: [],
  jobRole: "",
  projects: "",
  primarySkillTags: [],
  primarySkills: "",
  dateFrom: "",
  dateTo: "",
  matchMode: DEFAULT_MATCH_MODE,
};

// ── Persistence ────────────────────────────────────────────────────────────────
// Keep the applied filter across reloads (recruiters lose work otherwise). Stored in
// localStorage and merged over EMPTY on load, so adding new facets later stays compatible.
const BULK_FILTERS_KEY = "neuleap.screening.bulkFilters.v1";

export function loadBulkFilters(): BulkFilters {
  try {
    const raw = localStorage.getItem(BULK_FILTERS_KEY);
    if (!raw) return EMPTY_BULK_FILTERS;
    const saved = JSON.parse(raw) as Partial<BulkFilters>;
    // matchMode merges key-by-key too, so a saved filter from before a new facet
    // existed still resolves that facet to its correct default mode.
    return {
      ...EMPTY_BULK_FILTERS,
      ...saved,
      matchMode: { ...DEFAULT_MATCH_MODE, ...(saved.matchMode ?? {}) },
    };
  } catch {
    return EMPTY_BULK_FILTERS;
  }
}

export function saveBulkFilters(f: BulkFilters): void {
  try {
    if (bulkActiveCount(f) === 0) localStorage.removeItem(BULK_FILTERS_KEY);
    else localStorage.setItem(BULK_FILTERS_KEY, JSON.stringify(f));
  } catch {
    /* ignore quota / privacy-mode errors — persistence is best-effort */
  }
}

// Row-external values the predicate needs but CandidateMaster doesn't carry directly.
export interface BulkMatchContext {
  aging: number | null; // computed days-in-stage for this candidate
  source: "mail" | "manual" | null; // derived from the source email (sender "direct" = manual)
}

const STREAM_OPTIONS = ["GenAI", "Data Eng", "Not Relevant"];
const TYPE_OPTIONS = ["Fresher", "Lateral"];
const DEGREE_OPTIONS = ["Bachelor", "Master", "PhD", "Diploma"];
const SOURCE_OPTIONS = ["Mail", "Manual Upload"];

const rangeSet = (r: NumRange): boolean => r.min != null || r.max != null;

const inRange = (v: number | null | undefined, r: NumRange): boolean => {
  if (!rangeSet(r)) return true;
  if (v == null) return false;
  if (r.min != null && v < r.min) return false;
  if (r.max != null && v > r.max) return false;
  return true;
};

// Flatten a list-ish field (array / " · "-joined string / null) to a single lowercase blob.
function listBlob(v: string[] | string | null | undefined): string {
  if (Array.isArray(v)) return v.map(String).join(" ").toLowerCase();
  if (typeof v === "string") return v.toLowerCase();
  return "";
}

// Raw role titles from the job_roles field (the `role`, company dropped).
function roleTitles(v: CandidateMaster["job_roles"]): string[] {
  if (Array.isArray(v))
    return v.map((r) => (typeof r === "string" ? r : (r as JobRole).role ?? "")).filter(Boolean);
  if (typeof v === "string" && v.trim()) return v.split(" · ").filter(Boolean);
  return [];
}

// Free-form resume role titles are noisy ("Associate QA Engineer - ||", "Backend AI
// engineer (C++/Python developer)", "JOB TILE"). Classify each into a small set of standard
// ≤2-word buckets by keyword (first match wins, so list specific roles before the generic
// "engineer/developer" catch-alls). Unrecognised junk returns "" and is simply dropped.
const ROLE_RULES: [string, string[]][] = [
  ["Data Engineer", ["data engineer", "data eng"]],
  ["Data Scientist", ["data scientist", "data science"]],
  ["Data Analyst", ["data analyst"]],
  ["ML Engineer", ["ml engineer", "machine learning", "mlops"]],
  ["GenAI Engineer", ["genai", "gen ai", "generative", "llm"]],
  ["AI Engineer", ["ai engineer", "ai/ml", "artificial intelligence"]],
  ["QA Engineer", ["qa", "quality assurance", "sdet", "test engineer", "tester", "automation test"]],
  ["DevOps Engineer", ["devops", "dev ops", "site reliability", "sre"]],
  ["Cloud Engineer", ["cloud"]],
  ["Cybersecurity", ["security", "cyber", "soc analyst"]],
  ["Blockchain Developer", ["blockchain", "web3", "solidity"]],
  ["UX Designer", ["ux", "ui/ux", "designer", "product design"]],
  ["Business Analyst", ["business analyst"]],
  ["Project Manager", ["project manager", "program manager", "engineering manager", "team lead", "scrum"]],
  ["Research Assistant", ["research"]],
  ["Solution Engineer", ["solution"]],
  ["Backend Developer", ["backend", "back-end", "back end", "java developer", "python developer"]],
  ["Frontend Developer", ["frontend", "front-end", "front end", "react"]],
  ["Full Stack", ["full stack", "full-stack", "fullstack"]],
  ["Software Developer", ["software developer", "software engineer", "sde", "developer", "programmer", "engineer"]],
  ["Consultant", ["consultant"]],
  ["Intern", ["intern", "trainee"]],
];

// One raw role title → its standard bucket label (or "" when nothing matches).
export function normalizeRole(raw: string | null | undefined): string {
  const s = (raw ?? "").toLowerCase();
  if (!s.trim()) return "";
  for (const [label, keys] of ROLE_RULES) if (keys.some((k) => s.includes(k))) return label;
  return "";
}

// The distinct standard role buckets a candidate holds — drives the Job Role chips + matching.
export function candidateRoleLabels(v: CandidateMaster["job_roles"]): string[] {
  return [...new Set(roleTitles(v).map(normalizeRole).filter(Boolean))];
}

function jobRolesBlob(v: CandidateMaster["job_roles"]): string {
  if (Array.isArray(v)) {
    return v
      .map((r) =>
        typeof r === "string" ? r : [(r as JobRole).role, (r as JobRole).company].filter(Boolean).join(" "),
      )
      .join(" ")
      .toLowerCase();
  }
  return listBlob(v as string | null | undefined);
}

// Country / nationality tokens dropped from a location so chips collapse to "City, State".
const COUNTRY_TOKENS = new Set([
  "india", "bharat", "uk", "u.k", "u.k.", "united kingdom", "england",
  "usa", "u.s", "u.s.", "u.s.a", "u.s.a.", "united states", "america",
]);

// Title-case a word, but leave short all-caps abbreviations (UK, M.P) intact.
function titleWord(w: string): string {
  if (w.length <= 3 && w === w.toUpperCase()) return w;
  return w.charAt(0).toUpperCase() + w.slice(1).toLowerCase();
}

// Collapse a free-form location to a canonical "City, State" (or just "City"): strip
// pincodes and country suffixes, drop any sub-locality (keep the last two parts), and
// normalise case/spacing so "PUNE", "Pune, India", "Moshi, Pune, Maharashtra, India" all
// fold together. Used for the Location chip options AND for matching a candidate against them.
export function normalizeLocation(raw: string | null | undefined): string {
  if (!raw) return "";
  const parts = raw
    .split(",")
    .map((p) => p.replace(/[-–]?\s*\d{3,}\s*$/, "").replace(/\b\d{4,}\b/g, "").replace(/\s+/g, " ").trim())
    .filter(Boolean)
    .filter((p) => !COUNTRY_TOKENS.has(p.toLowerCase()));
  if (parts.length === 0) return "";
  // City + State = the last two meaningful parts; this drops a leading sub-locality.
  return parts
    .slice(-2)
    .map((p) => p.split(" ").map(titleWord).join(" "))
    .join(", ");
}

// Every comma-separated term in `query` must appear in `haystack` (AND). Empty query passes.
function textMatch(haystack: string, query: string): boolean {
  const terms = query
    .split(",")
    .map((t) => t.trim().toLowerCase())
    .filter(Boolean);
  if (terms.length === 0) return true;
  return terms.every((t) => haystack.includes(t));
}

// A checked-set match against a SINGLE candidate value (Stream, Round Status, …).
// "or" = the candidate's value is any one of the checked options. "and" with 2+
// checked options can never match a single-valued field — that's the correct,
// expected result (not a special case to code around).
function matchSingle(selected: string[], value: string, mode: MatchMode): boolean {
  if (selected.length === 0) return true;
  if (mode === "and") return selected.every((v) => v === value);
  return selected.includes(value);
}

// A checked-set match against a MULTI-valued candidate field (Certificates,
// Primary Skills, Job Role) via a per-option test function.
function matchMulti(selected: string[], test: (term: string) => boolean, mode: MatchMode): boolean {
  if (selected.length === 0) return true;
  return mode === "and" ? selected.every(test) : selected.some(test);
}

// Pure predicate: does a candidate pass EVERY active facet? Unset facets are skipped.
export function bulkFilterMatches(
  c: CandidateMaster,
  f: BulkFilters,
  ctx: BulkMatchContext = { aging: null, source: null },
): boolean {
  const mode = f.matchMode ?? DEFAULT_MATCH_MODE;
  // Numeric ranges
  if (!inRange(c.atsscore, f.ats)) return false;
  if (!inRange(c.yearofexp, f.experience)) return false;
  if (!inRange(c.cgpa ?? null, f.cgpa)) return false;
  if (!inRange(c.passoutyr, f.passoutYear)) return false;
  if (!inRange(c.gap_months ?? null, f.careerGap)) return false;
  if (!inRange(ctx.aging, f.aging)) return false;
  // Categorical
  if (!matchSingle(f.streams, c.stream ?? "", mode.streams)) return false;
  if (!matchSingle(f.types, c.fresher_or_lateral ?? "", mode.types)) return false;
  if (!matchSingle(f.highestDegree, c.highest_coursecompleted ?? "", mode.highestDegree)) return false;
  if (!matchSingle(f.roundStatus, roundStageBucket(c) ?? "", mode.roundStatus)) return false;
  if (f.source.length) {
    const label = ctx.source === "manual" ? "Manual Upload" : ctx.source === "mail" ? "Mail" : null;
    if (!matchSingle(f.source, label ?? "", mode.source)) return false;
  }
  // Source (registered post tag) — the recruiter-typed intake source, distinct
  // from the Mail/Manual Upload channel above.
  if (!matchSingle(f.sourceTag, c.source ?? "", mode.sourceTag)) return false;
  // Certificates — checked tags (mode-controlled) + keyword, keyword always ANDed on top.
  if (!matchMulti(f.certs, (t) => certMatches(c, t), mode.certs)) return false;
  if (f.certKeyword.trim() && !certMatches(c, f.certKeyword.trim())) return false;
  // Keyword "contains" boxes
  // Location — checked chips match the candidate's normalized City, State; the keyword
  // box still matches against the raw location so sub-locality searches keep working.
  const locNorm = normalizeLocation(c.currentlocation).toLowerCase();
  if (!matchSingle(f.locationTags.map((t) => t.toLowerCase()), locNorm, mode.locationTags)) return false;
  if (!textMatch((c.currentlocation ?? "").toLowerCase(), f.location)) return false;
  // Domain — checked chips match the candidate's single domain; keyword ANDs on top.
  const dom = (c.domain ?? "").toLowerCase();
  if (!matchSingle(f.domainTags.map((t) => t.toLowerCase()), dom, mode.domainTags)) return false;
  if (!textMatch(dom, f.domain)) return false;
  if (!textMatch((c.clg ?? "").toLowerCase(), f.college)) return false;
  if (!textMatch((c.currentcompany ?? "").toLowerCase(), f.currentCompany)) return false;
  // Job Role — checked chips match against the candidate's standard role buckets
  // (mode-controlled); the keyword box still searches the raw role text.
  const candRoles = candidateRoleLabels(c.job_roles);
  if (!matchMulti(f.jobRoleTags, (t) => candRoles.includes(t), mode.jobRoleTags)) return false;
  if (!textMatch(jobRolesBlob(c.job_roles), f.jobRole)) return false;
  if (!textMatch(listBlob(c.projects), f.projects)) return false;
  // Primary skills — checked chips (mode-controlled) + every keyword term, keyword
  // terms always ANDed on top regardless of the chip mode.
  const skillsBlob = listBlob(c.primary_skills);
  if (!matchMulti(f.primarySkillTags, (t) => skillsBlob.includes(t.toLowerCase()), mode.primarySkillTags))
    return false;
  if (!textMatch(skillsBlob, f.primarySkills)) return false;
  // Received date
  if (f.dateFrom || f.dateTo) {
    const d = (c.mail_send_date ?? "").slice(0, 10);
    if (!d) return false;
    if (f.dateFrom && d < f.dateFrom) return false;
    if (f.dateTo && d > f.dateTo) return false;
  }
  return true;
}

// Configurable-column keys to force-visible for the active facets ("dynamic columns").
// ATS, Stream, Received, Aging, Round Status are operational columns handled by the table's
// own show-flags; the Mail/Manual Upload channel facet has no column. The rest map to
// keys in the column registry.
export function activeBulkColumnKeys(f: BulkFilters): string[] {
  const keys: string[] = [];
  if (rangeSet(f.experience)) keys.push("experience");
  if (rangeSet(f.cgpa)) keys.push("cgpa");
  if (rangeSet(f.passoutYear)) keys.push("passout_year");
  if (rangeSet(f.careerGap)) keys.push("career_gap");
  if (f.highestDegree.length) keys.push("highest_degree");
  if (f.types.length) keys.push("fresher_or_lateral");
  if (f.sourceTag.length) keys.push("source");
  if (f.certs.length || f.certKeyword.trim()) keys.push("certificates");
  if (f.locationTags.length || f.location.trim()) keys.push("location");
  if (f.domainTags.length || f.domain.trim()) keys.push("domain");
  if (f.college.trim()) keys.push("college");
  if (f.currentCompany.trim()) keys.push("current_company");
  if (f.jobRoleTags.length || f.jobRole.trim()) keys.push("job_role");
  if (f.projects.trim()) keys.push("projects");
  if (f.primarySkillTags.length || f.primarySkills.trim()) keys.push("primary_skills");
  return keys;
}

const textActive = (s: string) => s.trim() !== "";

// How many facets are active — drives the count badge on the "Filters" button.
export function bulkActiveCount(f: BulkFilters): number {
  let n = 0;
  [f.ats, f.experience, f.cgpa, f.passoutYear, f.careerGap, f.aging].forEach((r) => {
    if (rangeSet(r)) n++;
  });
  [f.streams, f.types, f.highestDegree, f.roundStatus, f.source, f.sourceTag].forEach((a) => {
    if (a.length) n++;
  });
  if (f.certs.length || f.certKeyword.trim()) n++;
  [f.college, f.currentCompany, f.projects].forEach((s) => {
    if (textActive(s)) n++;
  });
  if (f.locationTags.length || textActive(f.location)) n++;
  if (f.domainTags.length || textActive(f.domain)) n++;
  if (f.jobRoleTags.length || textActive(f.jobRole)) n++;
  if (f.primarySkillTags.length || textActive(f.primarySkills)) n++;
  if (f.dateFrom || f.dateTo) n++;
  return n;
}

type TabId =
  | "ats"
  | "nlrs"
  | "cgpa"
  | "highestDegree"
  | "passoutYear"
  | "college"
  | "experience"
  | "careerGap"
  | "currentCompany"
  | "jobRole"
  | "domain"
  | "primarySkills"
  | "projects"
  | "certs"
  | "location"
  | "stream"
  | "type"
  | "roundStatus"
  | "aging"
  | "date"
  | "source"
  | "sourceTag";

const TABS: { id: TabId; label: string; group: string }[] = [
  { id: "ats", label: "ATS Score", group: "Scores" },
  { id: "nlrs", label: "NLRS", group: "Scores" },
  { id: "cgpa", label: "CGPA", group: "Education" },
  { id: "highestDegree", label: "Highest Degree", group: "Education" },
  { id: "passoutYear", label: "Passout Year", group: "Education" },
  { id: "college", label: "College", group: "Education" },
  { id: "experience", label: "Experience", group: "Experience" },
  { id: "careerGap", label: "Career Gap", group: "Experience" },
  { id: "currentCompany", label: "Current Company", group: "Experience" },
  { id: "jobRole", label: "Job Role", group: "Experience" },
  { id: "domain", label: "Domain", group: "Skills" },
  { id: "primarySkills", label: "Primary Skills", group: "Skills" },
  { id: "projects", label: "Projects", group: "Skills" },
  { id: "certs", label: "Certificates", group: "Skills" },
  { id: "location", label: "Location", group: "Profile" },
  { id: "sourceTag", label: "Source", group: "Profile" },
  { id: "source", label: "Source Channel", group: "Profile" },
  { id: "stream", label: "Stream", group: "Pipeline" },
  { id: "type", label: "Fresher / Lateral", group: "Pipeline" },
  { id: "roundStatus", label: "Round Status", group: "Pipeline" },
  { id: "aging", label: "Aging", group: "Pipeline" },
  { id: "date", label: "Received", group: "Pipeline" },
];

// Per-tab "is this facet set?" — drives the dot beside each tab in the rail.
function tabActive(id: TabId, f: BulkFilters): boolean {
  switch (id) {
    case "ats": return rangeSet(f.ats);
    case "nlrs": return false;
    case "cgpa": return rangeSet(f.cgpa);
    case "highestDegree": return f.highestDegree.length > 0;
    case "passoutYear": return rangeSet(f.passoutYear);
    case "college": return textActive(f.college);
    case "experience": return rangeSet(f.experience);
    case "careerGap": return rangeSet(f.careerGap);
    case "currentCompany": return textActive(f.currentCompany);
    case "jobRole": return f.jobRoleTags.length > 0 || textActive(f.jobRole);
    case "domain": return f.domainTags.length > 0 || textActive(f.domain);
    case "primarySkills": return f.primarySkillTags.length > 0 || textActive(f.primarySkills);
    case "projects": return textActive(f.projects);
    case "certs": return f.certs.length > 0 || textActive(f.certKeyword);
    case "location": return f.locationTags.length > 0 || textActive(f.location);
    case "stream": return f.streams.length > 0;
    case "type": return f.types.length > 0;
    case "roundStatus": return f.roundStatus.length > 0;
    case "aging": return rangeSet(f.aging);
    case "date": return f.dateFrom !== "" || f.dateTo !== "";
    case "source": return f.source.length > 0;
    case "sourceTag": return f.sourceTag.length > 0;
  }
}

function NumberField({
  value,
  onChange,
  placeholder,
  min,
  max,
  step,
}: {
  value: number | null;
  onChange: (v: number | null) => void;
  placeholder: string;
  min?: number;
  max?: number;
  step?: number;
}) {
  return (
    <input
      type="number"
      value={value ?? ""}
      min={min}
      max={max}
      step={step}
      placeholder={placeholder}
      onChange={(e) => onChange(e.target.value === "" ? null : Number(e.target.value))}
      className="w-full rounded-lg border border-border bg-secondary px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary/50 focus:outline-none tnum"
    />
  );
}

function RangeTab({
  label,
  unit,
  range,
  onChange,
  min,
  max,
  step,
  presets,
}: {
  label: string;
  unit?: string;
  range: NumRange;
  onChange: (r: NumRange) => void;
  min?: number;
  max?: number;
  step?: number;
  presets?: { label: string; range: NumRange }[];
}) {
  return (
    <div className="space-y-4">
      <div>
        <p className="text-sm font-semibold text-foreground">{label}</p>
        <p className="text-[11px] text-muted-foreground">
          Match candidates whose {label.toLowerCase()} falls in this range
          {unit ? ` (${unit})` : ""}. Leave a side blank for no bound.
        </p>
      </div>
      <div className="flex items-end gap-3">
        <label className="flex-1">
          <span className="mb-1 block text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
            Min
          </span>
          <NumberField
            value={range.min}
            onChange={(v) => onChange({ ...range, min: v })}
            placeholder="Any"
            min={min}
            max={max}
            step={step}
          />
        </label>
        <span className="pb-2 text-muted-foreground">–</span>
        <label className="flex-1">
          <span className="mb-1 block text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
            Max
          </span>
          <NumberField
            value={range.max}
            onChange={(v) => onChange({ ...range, max: v })}
            placeholder="Any"
            min={min}
            max={max}
            step={step}
          />
        </label>
      </div>
      {presets && presets.length > 0 && (
        <div className="flex flex-wrap gap-1.5">
          {presets.map((p) => {
            const active = p.range.min === range.min && p.range.max === range.max;
            return (
              <button
                key={p.label}
                onClick={() => onChange(active ? { min: null, max: null } : p.range)}
                className={cn(
                  "rounded-full border px-2.5 py-1 text-[11px] font-semibold transition-colors",
                  active
                    ? "border-primary/50 bg-primary/10 text-primary"
                    : "border-border text-muted-foreground hover:border-primary/40 hover:text-foreground",
                )}
              >
                {p.label}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

// Shown next to any facet's label once 2+ options are checked — lets the
// recruiter flip between "match ANY checked option" and "match ALL of them".
function MatchModeToggle({ mode, onChange }: { mode: MatchMode; onChange: (m: MatchMode) => void }) {
  return (
    <div className="inline-flex shrink-0 items-center rounded-full border border-border p-0.5 text-[10px] font-bold">
      {(["or", "and"] as MatchMode[]).map((m) => (
        <button
          key={m}
          type="button"
          onClick={() => onChange(m)}
          title={m === "or" ? "Match ANY checked option" : "Match ALL checked options"}
          className={cn(
            "rounded-full px-2 py-0.5 uppercase tracking-wide transition-colors",
            mode === m ? "bg-primary text-white" : "text-muted-foreground hover:text-foreground",
          )}
        >
          {m}
        </button>
      ))}
    </div>
  );
}

function CheckTab({
  label,
  hint,
  options,
  selected,
  onToggle,
  optionLabel,
  footer,
  mode,
  onModeChange,
}: {
  label: string;
  hint?: string;
  options: readonly string[];
  selected: string[];
  onToggle: (v: string) => void;
  optionLabel?: (v: string) => string;
  footer?: React.ReactNode;
  mode?: MatchMode;
  onModeChange?: (m: MatchMode) => void;
}) {
  return (
    <div className="space-y-3">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-sm font-semibold text-foreground">{label}</p>
          {hint && <p className="text-[11px] text-muted-foreground">{hint}</p>}
        </div>
        {mode && onModeChange && selected.length > 1 && (
          <MatchModeToggle mode={mode} onChange={onModeChange} />
        )}
      </div>
      {options.length === 0 ? (
        <p className="text-xs text-muted-foreground">No options available.</p>
      ) : (
        <div className="space-y-1">
          {options.map((opt) => {
            const on = selected.includes(opt);
            return (
              <button
                key={opt}
                onClick={() => onToggle(opt)}
                className="flex w-full items-center gap-2.5 rounded-lg px-2 py-1.5 text-left transition-colors hover:bg-secondary/50"
              >
                <span
                  className={cn(
                    "flex h-4 w-4 items-center justify-center rounded border transition-colors",
                    on ? "border-primary bg-primary text-white" : "border-border",
                  )}
                >
                  {on && <Check className="h-3 w-3" />}
                </span>
                <span className="text-sm text-foreground">{optionLabel ? optionLabel(opt) : opt}</span>
              </button>
            );
          })}
        </div>
      )}
      {footer}
    </div>
  );
}

function KeywordTab({
  label,
  value,
  onChange,
  example,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  example?: string;
}) {
  return (
    <div className="space-y-3">
      <div>
        <p className="text-sm font-semibold text-foreground">{label}</p>
        <p className="text-[11px] text-muted-foreground">
          Matches candidates whose {label.toLowerCase()} contains the text. Separate multiple terms
          with commas — all must match.{example ? ` e.g. ${example}` : ""}
        </p>
      </div>
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={`Search ${label.toLowerCase()}…`}
        className="w-full rounded-lg border border-border bg-secondary px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary/50 focus:outline-none"
      />
    </div>
  );
}

// Checkable chips (distinct values from the data) + a free-text keyword box. Used by the
// Domain / Location / Job Role tabs.
function ChipKeywordTab({
  label,
  hint,
  options,
  tags,
  onToggle,
  keyword,
  onKeyword,
  placeholder,
  mode,
  onModeChange,
}: {
  label: string;
  hint: string;
  options: string[];
  tags: string[];
  onToggle: (v: string) => void;
  keyword: string;
  onKeyword: (v: string) => void;
  placeholder: string;
  mode?: MatchMode;
  onModeChange?: (m: MatchMode) => void;
}) {
  return (
    <div className="space-y-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-sm font-semibold text-foreground">{label}</p>
          <p className="text-[11px] text-muted-foreground">{hint}</p>
        </div>
        {mode && onModeChange && tags.length > 1 && (
          <MatchModeToggle mode={mode} onChange={onModeChange} />
        )}
      </div>
      {options.length > 0 && (
        <div className="flex max-h-56 flex-wrap gap-1.5 overflow-auto">
          {options.map((o) => {
            const on = tags.includes(o);
            return (
              <button
                key={o}
                onClick={() => onToggle(o)}
                className={cn(
                  "inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-[11px] font-semibold transition-colors",
                  on
                    ? "border-primary/50 bg-primary/10 text-primary"
                    : "border-border text-muted-foreground hover:border-primary/40 hover:text-foreground",
                )}
              >
                {on && <Check className="h-3 w-3" />}
                {o}
              </button>
            );
          })}
        </div>
      )}
      <div>
        <p className="mb-1 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
          Other keyword
        </p>
        <input
          type="text"
          value={keyword}
          onChange={(e) => onKeyword(e.target.value)}
          placeholder={placeholder}
          className="w-full rounded-lg border border-border bg-secondary px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary/50 focus:outline-none"
        />
      </div>
    </div>
  );
}

export default function BulkFilterModal({
  open,
  applied,
  certTags,
  skillGroups,
  domainOptions,
  locationOptions,
  jobRoleOptions,
  sourceTagOptions,
  onApply,
  onClose,
}: {
  open: boolean;
  applied: BulkFilters;
  certTags: string[];
  // Common skills per stream (admin-curated in Settings → stream_keywords) shown as
  // checkable chips on the Primary Skills tab.
  skillGroups: Record<string, string[]>;
  // Distinct values present in the candidate list — the chip options for these tabs.
  domainOptions: string[];
  locationOptions: string[];
  jobRoleOptions: string[];
  // Registered social-post source tags (Mailbox → "Register recent social post as a
  // source tag") — the option list for the Source tab, distinct from the candidate
  // list itself since a tag can be registered before any candidate carries it yet.
  sourceTagOptions: string[];
  onApply: (f: BulkFilters) => void;
  onClose: () => void;
}) {
  const [draft, setDraft] = useState<BulkFilters>(applied);
  const [tab, setTab] = useState<TabId>("ats");
  const [tabSearch, setTabSearch] = useState("");

  // Re-seed the draft from the applied filters every time the modal opens, so a
  // cancelled edit doesn't leak into the next open.
  useEffect(() => {
    if (open) {
      setDraft(applied);
      setTabSearch("");
    }
  }, [open, applied]);

  const activeCount = useMemo(() => bulkActiveCount(draft), [draft]);

  if (!open) return null;

  const setRange = (key: "ats" | "experience" | "cgpa" | "passoutYear" | "careerGap" | "aging") =>
    (r: NumRange) => setDraft((d) => ({ ...d, [key]: r }));
  const toggleIn =
    (
      key:
        | "certs"
        | "streams"
        | "types"
        | "highestDegree"
        | "roundStatus"
        | "source"
        | "sourceTag"
        | "primarySkillTags"
        | "domainTags"
        | "locationTags"
        | "jobRoleTags",
    ) =>
    (v: string) =>
      setDraft((d) => {
        const cur = d[key];
        return { ...d, [key]: cur.includes(v) ? cur.filter((x) => x !== v) : [...cur, v] };
      });
  const setText =
    (key: "location" | "domain" | "college" | "currentCompany" | "jobRole" | "projects" | "primarySkills") =>
    (v: string) =>
      setDraft((d) => ({ ...d, [key]: v }));
  const setMode = (key: MultiFacetKey) => (m: MatchMode) =>
    setDraft((d) => ({ ...d, matchMode: { ...d.matchMode, [key]: m } }));
  const visibleTabs = tabSearch.trim()
    ? TABS.filter((t) => t.label.toLowerCase().includes(tabSearch.trim().toLowerCase()))
    : TABS;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/40 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="flex max-h-[88vh] w-full max-w-4xl flex-col rounded-2xl border border-border bg-card shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3 border-b border-border px-5 py-3.5">
          <div>
            <h2 className="flex items-center gap-2 text-sm font-bold text-foreground">
              <Filter className="h-4 w-4 text-primary" />
              Bulk Filters
            </h2>
            <p className="text-[11px] text-muted-foreground">
              Set a range, selection, or keyword on any tab. Filtered attributes also appear as table columns.
            </p>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="flex min-h-0 flex-1">
          {/* Vertical tab rail, grouped — a dot marks tabs that already have a value set. */}
          <div className="flex w-48 shrink-0 flex-col border-r border-border">
            <div className="relative shrink-0 px-2.5 pb-1.5 pt-2">
              <Search className="absolute left-5 top-1/2 h-3 w-3 -translate-y-1/2 text-muted-foreground" />
              <input
                value={tabSearch}
                onChange={(e) => setTabSearch(e.target.value)}
                placeholder="Search filters…"
                className="w-full rounded-lg border border-border bg-secondary py-1 pl-7 pr-2 text-[11px] text-foreground placeholder:text-muted-foreground focus:border-primary/50 focus:outline-none"
              />
            </div>
            <div className="min-h-0 flex-1 overflow-auto pb-2">
              {visibleTabs.length === 0 && (
                <p className="px-4 py-3 text-[11px] text-muted-foreground">No filters match "{tabSearch}".</p>
              )}
              {visibleTabs.map((t, i) => {
                const on = tabActive(t.id, draft);
                const newGroup = i === 0 || visibleTabs[i - 1].group !== t.group;
                return (
                  <div key={t.id}>
                    {newGroup && (
                      <p className="px-4 pb-1 pt-2 text-[9px] font-bold uppercase tracking-wider text-muted-foreground/60">
                        {t.group}
                      </p>
                    )}
                    <button
                      onClick={() => setTab(t.id)}
                      className={cn(
                        "flex w-full items-center justify-between gap-2 px-4 py-1.5 text-left text-xs font-medium transition-colors",
                        tab === t.id
                          ? "border-r-2 border-primary bg-primary/5 text-primary"
                          : "text-muted-foreground hover:bg-secondary/50 hover:text-foreground",
                      )}
                    >
                      {t.label}
                      {on && <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="min-h-0 flex-1 overflow-auto px-5 py-4">
            {tab === "ats" && (
              <RangeTab
                label="ATS Score"
                range={draft.ats}
                onChange={setRange("ats")}
                min={0}
                max={100}
                presets={[
                  { label: "≥ 80", range: { min: 80, max: null } },
                  { label: "≥ 60", range: { min: 60, max: null } },
                  { label: "40 – 60", range: { min: 40, max: 60 } },
                ]}
              />
            )}
            {tab === "nlrs" && (
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Lock className="h-4 w-4 text-muted-foreground" />
                  <p className="text-sm font-semibold text-foreground">NLRS (Neuleap Resume Score)</p>
                </div>
                <div className="rounded-lg border border-dashed border-border bg-secondary/40 px-4 py-6 text-center">
                  <p className="text-xs font-medium text-foreground">No score data yet</p>
                  <p className="mt-1 text-[11px] text-muted-foreground">
                    This filter activates once the resume-insights feature stores an NLRS on each
                    candidate. Until then it's disabled so it can't hide everyone.
                  </p>
                </div>
              </div>
            )}
            {tab === "cgpa" && (
              <RangeTab
                label="CGPA"
                range={draft.cgpa}
                onChange={setRange("cgpa")}
                min={0}
                max={10}
                step={0.1}
                presets={[
                  { label: "≥ 8", range: { min: 8, max: null } },
                  { label: "≥ 7", range: { min: 7, max: null } },
                  { label: "≥ 6", range: { min: 6, max: null } },
                ]}
              />
            )}
            {tab === "highestDegree" && (
              <CheckTab
                label="Highest Degree"
                options={DEGREE_OPTIONS}
                selected={draft.highestDegree}
                onToggle={toggleIn("highestDegree")}
                mode={draft.matchMode.highestDegree}
                onModeChange={setMode("highestDegree")}
              />
            )}
            {tab === "passoutYear" && (
              <RangeTab
                label="Passout Year"
                range={draft.passoutYear}
                onChange={setRange("passoutYear")}
                min={1980}
                max={2100}
              />
            )}
            {tab === "college" && (
              <KeywordTab label="College" value={draft.college} onChange={setText("college")} />
            )}
            {tab === "experience" && (
              <RangeTab
                label="Experience"
                unit="years"
                range={draft.experience}
                onChange={setRange("experience")}
                min={0}
                step={0.5}
                presets={[
                  { label: "0 – 2", range: { min: 0, max: 2 } },
                  { label: "2 – 4", range: { min: 2, max: 4 } },
                  { label: "4 – 6", range: { min: 4, max: 6 } },
                  { label: "6+", range: { min: 6, max: null } },
                ]}
              />
            )}
            {tab === "careerGap" && (
              <RangeTab
                label="Career Gap"
                unit="months"
                range={draft.careerGap}
                onChange={setRange("careerGap")}
                min={0}
                presets={[
                  { label: "No gap (0)", range: { min: 0, max: 0 } },
                  { label: "≤ 6 mo", range: { min: 0, max: 6 } },
                  { label: "> 6 mo", range: { min: 7, max: null } },
                ]}
              />
            )}
            {tab === "currentCompany" && (
              <KeywordTab
                label="Current Company"
                value={draft.currentCompany}
                onChange={setText("currentCompany")}
              />
            )}
            {tab === "jobRole" && (
              <ChipKeywordTab
                label="Job Role"
                hint="Check known roles (ANY by default — flip to ALL if a candidate must hold every checked role), and/or add your own keyword."
                options={jobRoleOptions}
                tags={draft.jobRoleTags}
                onToggle={toggleIn("jobRoleTags")}
                keyword={draft.jobRole}
                onKeyword={setText("jobRole")}
                placeholder="+ keyword, comma-separated (e.g. ml, backend)…"
                mode={draft.matchMode.jobRoleTags}
                onModeChange={setMode("jobRoleTags")}
              />
            )}
            {tab === "domain" && (
              <ChipKeywordTab
                label="Domain"
                hint="Check one or more domains (a candidate matches any selected), and/or add your own keyword."
                options={domainOptions}
                tags={draft.domainTags}
                onToggle={toggleIn("domainTags")}
                keyword={draft.domain}
                onKeyword={setText("domain")}
                placeholder="+ keyword, comma-separated (e.g. blockchain, security)…"
                mode={draft.matchMode.domainTags}
                onModeChange={setMode("domainTags")}
              />
            )}
            {tab === "primarySkills" && (
              <div className="space-y-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-sm font-semibold text-foreground">Primary Skills</p>
                    <p className="text-[11px] text-muted-foreground">
                      Check the common skills a candidate must have, and/or add your own keywords
                      (comma-separated, always ANDed). Chips default to ALL — flip to ANY for a
                      candidate matching just one of them.
                    </p>
                  </div>
                  {draft.primarySkillTags.length > 1 && (
                    <MatchModeToggle mode={draft.matchMode.primarySkillTags} onChange={setMode("primarySkillTags")} />
                  )}
                </div>
                {Object.entries(skillGroups)
                  .filter(([, skills]) => skills.length > 0)
                  .map(([group, skills]) => (
                    <div key={group} className="space-y-1.5">
                      <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground/60">
                        {group}
                      </p>
                      <div className="flex flex-wrap gap-1.5">
                        {skills.map((s) => {
                          const on = draft.primarySkillTags.includes(s);
                          return (
                            <button
                              key={`${group}-${s}`}
                              onClick={() => toggleIn("primarySkillTags")(s)}
                              className={cn(
                                "inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-[11px] font-semibold transition-colors",
                                on
                                  ? "border-primary/50 bg-primary/10 text-primary"
                                  : "border-border text-muted-foreground hover:border-primary/40 hover:text-foreground",
                              )}
                            >
                              {on && <Check className="h-3 w-3" />}
                              {s}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                {Object.keys(skillGroups).length === 0 && (
                  <p className="text-[11px] text-muted-foreground">
                    No preset skills configured — use the keyword box below.
                  </p>
                )}
                <div>
                  <p className="mb-1 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                    Other keywords
                  </p>
                  <input
                    type="text"
                    value={draft.primarySkills}
                    onChange={(e) => setText("primarySkills")(e.target.value)}
                    placeholder="+ keyword, comma-separated (e.g. fastapi, langgraph)…"
                    className="w-full rounded-lg border border-border bg-secondary px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary/50 focus:outline-none"
                  />
                </div>
              </div>
            )}
            {tab === "projects" && (
              <KeywordTab label="Projects" value={draft.projects} onChange={setText("projects")} />
            )}
            {tab === "certs" && (
              <CheckTab
                label="Certificates"
                hint="Checked tags default to ALL matching (flip to ANY for just one) — the keyword always ANDs on top."
                options={certTags}
                selected={draft.certs}
                onToggle={toggleIn("certs")}
                mode={draft.matchMode.certs}
                onModeChange={setMode("certs")}
                footer={
                  <input
                    type="text"
                    value={draft.certKeyword}
                    onChange={(e) => setDraft((d) => ({ ...d, certKeyword: e.target.value }))}
                    placeholder="+ keyword (matches any cert name or issuer)…"
                    className="w-full rounded-lg border border-border bg-secondary px-3 py-2 text-xs text-foreground placeholder:text-muted-foreground focus:border-primary/50 focus:outline-none"
                  />
                }
              />
            )}
            {tab === "location" && (
              <ChipKeywordTab
                label="Location"
                hint="Check known locations (a candidate matches any selected), and/or add your own keyword."
                options={locationOptions}
                tags={draft.locationTags}
                onToggle={toggleIn("locationTags")}
                keyword={draft.location}
                onKeyword={setText("location")}
                placeholder="+ keyword, comma-separated (e.g. bengaluru, remote)…"
                mode={draft.matchMode.locationTags}
                onModeChange={setMode("locationTags")}
              />
            )}
            {tab === "sourceTag" && (
              <CheckTab
                label="Source"
                hint="The registered social-post tag stamped as this candidate's intake source — see Mailbox → Register recent social post as a source tag."
                options={sourceTagOptions}
                selected={draft.sourceTag}
                onToggle={toggleIn("sourceTag")}
                mode={draft.matchMode.sourceTag}
                onModeChange={setMode("sourceTag")}
              />
            )}
            {tab === "source" && (
              <CheckTab
                label="Source Channel"
                hint="Where the candidate came from — a forwarded/recruiter mail vs a manual file upload."
                options={SOURCE_OPTIONS}
                selected={draft.source}
                onToggle={toggleIn("source")}
                mode={draft.matchMode.source}
                onModeChange={setMode("source")}
              />
            )}
            {tab === "stream" && (
              <CheckTab
                label="Stream"
                options={STREAM_OPTIONS}
                selected={draft.streams}
                onToggle={toggleIn("streams")}
                mode={draft.matchMode.streams}
                onModeChange={setMode("streams")}
              />
            )}
            {tab === "type" && (
              <CheckTab
                label="Fresher / Lateral"
                options={TYPE_OPTIONS}
                selected={draft.types}
                onToggle={toggleIn("types")}
                mode={draft.matchMode.types}
                onModeChange={setMode("types")}
              />
            )}
            {tab === "roundStatus" && (
              <CheckTab
                label="Round Status"
                hint="The candidate's current pipeline stage."
                options={ROUND_FILTER_BUCKETS}
                selected={draft.roundStatus}
                onToggle={toggleIn("roundStatus")}
                optionLabel={(b) => roundLabel(b)}
                mode={draft.matchMode.roundStatus}
                onModeChange={setMode("roundStatus")}
              />
            )}
            {tab === "aging" && (
              <RangeTab
                label="Aging"
                unit="days in current stage"
                range={draft.aging}
                onChange={setRange("aging")}
                min={0}
                presets={[
                  { label: "≤ 15d", range: { min: 0, max: 15 } },
                  { label: "16 – 30d", range: { min: 16, max: 30 } },
                  { label: "> 30d", range: { min: 31, max: null } },
                ]}
              />
            )}
            {tab === "date" && (
              <div className="space-y-4">
                <div>
                  <p className="text-sm font-semibold text-foreground">Received Date</p>
                  <p className="text-[11px] text-muted-foreground">
                    Filter by when the résumé arrived (mail received date).
                  </p>
                </div>
                <div className="flex items-end gap-3">
                  <label className="flex-1">
                    <span className="mb-1 block text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                      From
                    </span>
                    <input
                      type="date"
                      value={draft.dateFrom}
                      max={draft.dateTo || undefined}
                      onChange={(e) => setDraft((d) => ({ ...d, dateFrom: e.target.value }))}
                      className="w-full rounded-lg border border-border bg-secondary px-3 py-2 text-sm text-foreground focus:border-primary/50 focus:outline-none tnum"
                    />
                  </label>
                  <span className="pb-2 text-muted-foreground">–</span>
                  <label className="flex-1">
                    <span className="mb-1 block text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                      To
                    </span>
                    <input
                      type="date"
                      value={draft.dateTo}
                      min={draft.dateFrom || undefined}
                      onChange={(e) => setDraft((d) => ({ ...d, dateTo: e.target.value }))}
                      className="w-full rounded-lg border border-border bg-secondary px-3 py-2 text-sm text-foreground focus:border-primary/50 focus:outline-none tnum"
                    />
                  </label>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center justify-between gap-2 border-t border-border px-5 py-3">
          <button
            onClick={() => setDraft(EMPTY_BULK_FILTERS)}
            className="inline-flex items-center gap-1.5 rounded-xl border border-border px-3 py-2 text-xs font-medium text-foreground transition-colors hover:bg-secondary"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            Clear all
          </button>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="rounded-xl border border-border px-3 py-2 text-xs font-medium text-foreground transition-colors hover:bg-secondary"
            >
              Cancel
            </button>
            <button
              onClick={() => {
                onApply(draft);
                onClose();
              }}
              className="btn-brand inline-flex items-center gap-1.5 px-3 py-2 text-xs"
            >
              <Filter className="h-3.5 w-3.5" />
              Apply filter{activeCount > 0 ? ` (${activeCount})` : ""}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
