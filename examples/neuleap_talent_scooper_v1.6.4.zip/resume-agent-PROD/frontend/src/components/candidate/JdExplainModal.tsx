// "Why this score?" — detailed breakdown behind one candidate's JD-match
// score, opened by clicking the score in the Screening page's JD Match
// column. Fetched on demand (one candidate per call, cached per JD via
// TanStack Query) so the richer analysis is only paid for when asked.
import { useQuery } from "@tanstack/react-query";
import { X, Loader2, CheckCircle2, XCircle, Sparkles, AlertTriangle } from "lucide-react";
import { jdMatchService, type JdMatchResult } from "@/services/jdMatch";
import { cn, apiErrorMessage } from "@/lib/utils";

// Tiny stable hash so the query key doesn't carry the whole JD text.
function hashText(s: string): string {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = ((h << 5) - h + s.charCodeAt(i)) | 0;
  return h.toString(36);
}

const scoreTone = (score: number | null) =>
  score == null
    ? "text-muted-foreground"
    : score >= 70
      ? "text-emerald-500"
      : score >= 45
        ? "text-amber-500"
        : "text-rose-500";

const barTone = (score: number | null) =>
  score == null ? "#94a3b8" : score >= 70 ? "#10b981" : score >= 45 ? "#f59e0b" : "#f43f5e";

export default function JdExplainModal({
  candidateId,
  candidateName,
  result,
  jdText,
  onClose,
}: {
  candidateId: string;
  candidateName: string;
  result: JdMatchResult | null;
  jdText: string;
  onClose: () => void;
}) {
  const { data, isLoading, error } = useQuery({
    queryKey: ["jd-explain", hashText(jdText), candidateId],
    queryFn: async () =>
      (
        await jdMatchService.explain(jdText, candidateId, result?.score ?? null, result?.note ?? null)
      ).data,
    staleTime: Infinity,
    retry: false,
  });

  const shownScore = data?.score ?? result?.score ?? null;

  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center bg-foreground/40 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="flex max-h-[85vh] w-full max-w-2xl flex-col overflow-hidden rounded-2xl border border-border/60 bg-card/80 shadow-xl backdrop-blur-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3 border-b border-border/60 px-5 py-3.5">
          <div className="flex min-w-0 items-center gap-3">
            <span className={cn("stat-value text-2xl font-extrabold tabular-nums", scoreTone(shownScore))}>
              {shownScore ?? "—"}
            </span>
            <div className="min-w-0">
              <h2 className="truncate text-sm font-bold text-foreground">
                JD match — {candidateName}
              </h2>
              <p className="text-[11px] text-muted-foreground">
                Why this score, against the JD you supplied
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="min-h-0 flex-1 space-y-4 overflow-y-auto px-5 py-4">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center gap-2 py-10 text-xs text-muted-foreground">
              <Loader2 className="h-5 w-5 animate-spin" />
              Analysing this candidate against the JD…
            </div>
          ) : error ? (
            <div className="flex items-start gap-2 rounded-xl border border-rose-500/30 bg-rose-500/10 px-3 py-2.5">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-rose-500" />
              <p className="text-[11px] text-rose-600">
                {apiErrorMessage(error, "Couldn't build the detailed explanation. Try again.")}
                {result?.note && (
                  <span className="mt-1 block text-muted-foreground">
                    Batch-scoring note: {result.note}
                  </span>
                )}
              </p>
            </div>
          ) : data ? (
            <>
              {/* Verdict */}
              {data.summary && (
                <div className="flex items-start gap-2 rounded-2xl border border-border/50 bg-card/40 px-4 py-3 backdrop-blur-md dark:bg-card/30">
                  <Sparkles className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                  <p className="text-xs leading-relaxed text-foreground">{data.summary}</p>
                </div>
              )}

              {/* Dimension bars */}
              {data.dimensions.length > 0 && (
                <div>
                  <span className="mb-2 block text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                    Score breakdown
                  </span>
                  <div className="space-y-2 rounded-2xl border border-border/50 bg-card/40 px-4 py-3 backdrop-blur-md dark:bg-card/30">
                    {data.dimensions.map((d) => (
                      <div key={d.name} className="flex items-center gap-2.5">
                        <span className="w-28 shrink-0 truncate text-right text-[10px] font-medium text-muted-foreground">
                          {d.name}
                        </span>
                        <div className="h-2 min-w-0 flex-1 overflow-hidden rounded-full bg-secondary/70">
                          <div
                            className="h-full rounded-full transition-all duration-500"
                            style={{
                              width: `${d.score ?? 0}%`,
                              backgroundImage: `linear-gradient(90deg, ${barTone(d.score)}cc, ${barTone(d.score)})`,
                            }}
                          />
                        </div>
                        <span className={cn("w-8 shrink-0 text-right text-[11px] font-bold tabular-nums", scoreTone(d.score))}>
                          {d.score ?? "—"}
                        </span>
                        <span className="hidden w-64 shrink-0 truncate text-[10px] text-muted-foreground sm:block" title={d.reason}>
                          {d.reason}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Strengths vs gaps */}
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="rounded-2xl border border-emerald-500/25 bg-emerald-500/5 px-4 py-3">
                  <span className="mb-1.5 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wide text-emerald-600">
                    <CheckCircle2 className="h-3 w-3" /> Meets the JD
                  </span>
                  {data.strengths.length === 0 ? (
                    <p className="text-[11px] text-muted-foreground">Nothing clearly matched.</p>
                  ) : (
                    <ul className="space-y-1.5">
                      {data.strengths.map((s, i) => (
                        <li key={i} className="flex gap-1.5 text-[11px] leading-relaxed text-foreground">
                          <span className="mt-[7px] h-1 w-1 shrink-0 rounded-full bg-emerald-500/70" />
                          <span>{s}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
                <div className="rounded-2xl border border-rose-500/25 bg-rose-500/5 px-4 py-3">
                  <span className="mb-1.5 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wide text-rose-600">
                    <XCircle className="h-3 w-3" /> Missing / unclear
                  </span>
                  {data.gaps.length === 0 ? (
                    <p className="text-[11px] text-muted-foreground">No notable gaps found.</p>
                  ) : (
                    <ul className="space-y-1.5">
                      {data.gaps.map((g, i) => (
                        <li key={i} className="flex gap-1.5 text-[11px] leading-relaxed text-foreground">
                          <span className="mt-[7px] h-1 w-1 shrink-0 rounded-full bg-rose-500/70" />
                          <span>{g}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>

              <p className="text-[10px] text-muted-foreground/80">
                Grounded in the candidate's extracted profile and analysis report versus the JD's
                requirements. Session-only — nothing is written to the candidate's record.
              </p>
            </>
          ) : null}
        </div>

        <div className="flex items-center justify-end border-t border-border/60 px-5 py-3">
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-secondary"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
