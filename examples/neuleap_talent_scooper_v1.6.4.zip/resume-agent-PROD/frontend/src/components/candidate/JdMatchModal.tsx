// "Match JD" modal — paste or upload a job description, score it against the
// Screening page's currently filtered candidate list in one batched LLM call
// (app.services.jd_match). Results are session-only (kept in the caller's
// component state, not persisted) and feed the "JD Match Score" column.
import { useRef, useState } from "react";
import { X, Upload, Loader2, Sparkles } from "lucide-react";
import { jdMatchService, type JdMatchResult } from "@/services/jdMatch";

const MAX_CANDIDATES = 100;
const ACCEPTED_EXT = ".pdf,.docx,.doc,.txt";

export default function JdMatchModal({
  candidateIds,
  onClose,
  onResults,
}: {
  // The candidates to score — the Screening page's currently filtered list
  // (pre-pagination), so "match" means "against everyone my filters show".
  candidateIds: string[];
  onClose: () => void;
  // Also hands back the JD text the scores were computed against — the caller
  // keeps it so the per-candidate "why this score?" popup can reference it.
  onResults: (results: JdMatchResult[], jdText: string) => void;
}) {
  const [jdText, setJdText] = useState("");
  const [extracting, setExtracting] = useState(false);
  const [scoring, setScoring] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const tooMany = candidateIds.length > MAX_CANDIDATES;

  const onFilePicked = async (file: File) => {
    setExtracting(true);
    setError(null);
    try {
      const { data } = await jdMatchService.extractText(file);
      setJdText(data.text);
    } catch (e: unknown) {
      const detail = (e as { response?: { data?: { detail?: string } } })?.response?.data?.detail;
      setError(detail ?? "Couldn't extract text from that file.");
    } finally {
      setExtracting(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const runMatch = async () => {
    if (!jdText.trim()) {
      setError("Paste or upload a job description first.");
      return;
    }
    if (tooMany) return;
    setScoring(true);
    setError(null);
    try {
      const { data } = await jdMatchService.score(jdText, candidateIds);
      onResults(data.results, jdText);
      onClose();
    } catch (e: unknown) {
      const detail = (e as { response?: { data?: { detail?: string } } })?.response?.data?.detail;
      setError(detail ?? "Couldn't score candidates against this JD.");
    } finally {
      setScoring(false);
    }
  };

  const busy = extracting || scoring;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/40 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="flex max-h-[85vh] w-full max-w-lg flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3 border-b border-border px-5 py-3.5">
          <div className="min-w-0">
            <h2 className="truncate text-sm font-bold text-foreground">Match Job Description</h2>
            <p className="text-[11px] text-muted-foreground">
              Scores every candidate your current filters show ({candidateIds.length}) against this JD.
            </p>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="min-h-0 flex-1 space-y-3 overflow-auto px-5 py-4">
          <div className="rounded-lg border border-amber-500/30 bg-amber-400/10 px-3 py-2 text-[11px] leading-relaxed text-amber-700 dark:text-amber-400">
            <b>Token-intensive.</b> Every candidate in scope ({candidateIds.length} right now) is
            sent to the AI in one large call — cost grows with the candidate count and the JD's
            length. Narrow your filters to a shortlist first: cheaper, faster, and the scores
            differentiate better. Results live only in this browser session (re-running spends
            tokens again) and are AI estimates grounded in extracted profiles — verify before
            acting on a low score. Usage is metered on the Token Usage page.
          </div>
          {tooMany && (
            <p className="rounded-lg border border-amber-500/30 bg-amber-400/10 px-3 py-2 text-[11px] text-amber-600">
              {candidateIds.length} candidates match your current filters — JD matching is capped at{" "}
              {MAX_CANDIDATES}. Narrow your filters (e.g. a stream, stage, or date range) and try again.
            </p>
          )}

          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                Job Description
              </label>
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                disabled={busy}
                className="inline-flex items-center gap-1.5 rounded-lg border border-border px-2 py-1 text-[11px] font-semibold text-foreground transition-colors hover:bg-secondary disabled:opacity-40"
              >
                {extracting ? (
                  <Loader2 className="h-3 w-3 animate-spin" />
                ) : (
                  <Upload className="h-3 w-3" />
                )}
                Upload file
              </button>
              <input
                ref={fileRef}
                type="file"
                accept={ACCEPTED_EXT}
                className="hidden"
                onChange={(e) => e.target.files?.[0] && onFilePicked(e.target.files[0])}
              />
            </div>
            <textarea
              value={jdText}
              onChange={(e) => setJdText(e.target.value)}
              placeholder="Paste the job description here, or upload a .pdf/.docx/.doc/.txt file above…"
              rows={12}
              disabled={extracting}
              className="w-full resize-y rounded-lg border border-border bg-background px-2.5 py-1.5 text-xs text-foreground outline-none focus:border-primary/50 disabled:opacity-60"
            />
          </div>

          {error && <p className="text-[11px] text-red-400">{error}</p>}
        </div>

        <div className="flex items-center justify-end gap-2 border-t border-border px-5 py-3">
          <button
            type="button"
            onClick={onClose}
            disabled={busy}
            className="rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-secondary disabled:opacity-40"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={runMatch}
            disabled={busy || tooMany || !jdText.trim()}
            className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3 py-1.5 text-xs font-semibold text-white transition-opacity disabled:opacity-40"
          >
            {scoring ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Sparkles className="h-3.5 w-3.5" />}
            {scoring ? "Scoring…" : "Match candidates"}
          </button>
        </div>
      </div>
    </div>
  );
}
