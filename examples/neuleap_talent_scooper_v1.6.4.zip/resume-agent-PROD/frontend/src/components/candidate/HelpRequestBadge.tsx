import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { CheckCircle2, Loader2, RotateCcw, X } from "lucide-react";
import { candidatesService } from "@/services/candidates";
import { cn, titleCase } from "@/lib/utils";
import type { CandidateMaster } from "@/types";

/**
 * Red "!" on a candidate's status tracking while an UNRESOLVED "Need help"
 * message (sent from the slot-picker page) is waiting. Click opens the
 * message with a "Mark handled" action — handling clears the flag; the
 * message itself stays in the candidate's Actions Audit Log.
 */
export default function HelpRequestBadge({ candidate }: { candidate: CandidateMaster }) {
  const [open, setOpen] = useState(false);
  const queryClient = useQueryClient();
  const hr = candidate.help_request;

  const resolve = useMutation({
    mutationFn: () => candidatesService.resolveHelpRequest(candidate.candidate_id),
    onSuccess: () => {
      setOpen(false);
      queryClient.invalidateQueries({ queryKey: ["candidates"] });
    },
  });
  const resetRound = useMutation({
    mutationFn: () => candidatesService.resetHelpRound(candidate.candidate_id),
    onSuccess: () => {
      setOpen(false);
      queryClient.invalidateQueries({ queryKey: ["candidates"] });
    },
  });

  if (!hr || hr.resolved) return null;

  return (
    <>
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          setOpen(true);
        }}
        title={`Candidate asked for help${hr.round_name ? ` (${hr.round_name})` : ""} — click to read`}
        className="inline-flex h-4 w-4 shrink-0 animate-pulse items-center justify-center rounded-full bg-rose-500 text-[10px] font-black leading-none text-white"
      >
        !
      </button>

      {open && (
        <div
          className="fixed inset-0 z-[70] flex items-center justify-center bg-foreground/50 p-4 backdrop-blur-sm"
          onClick={(e) => {
            e.stopPropagation();
            setOpen(false);
          }}
        >
          <div
            className="w-full max-w-sm rounded-2xl border border-border bg-card p-5 shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <h3 className="text-sm font-bold text-foreground">
                  {candidate.name ? titleCase(candidate.name) : candidate.candidate_id} needs help
                </h3>
                <p className="text-[11px] text-muted-foreground">
                  Sent from the slot-picker page
                  {hr.round_name ? ` · ${hr.round_name}` : ""}
                  {hr.created_at
                    ? ` · ${new Date(hr.created_at).toLocaleString("en-IN", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}`
                    : ""}
                </p>
              </div>
              <button
                onClick={() => setOpen(false)}
                className="rounded-lg p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
                aria-label="Close"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <p className="selectable mt-3 whitespace-pre-line break-words rounded-lg border border-rose-500/20 bg-rose-500/5 px-3 py-2 text-xs leading-relaxed text-foreground">
              "{hr.message}"
            </p>
            <p className="mt-2 text-[10px] text-muted-foreground">
              Take whatever next action fits (adjust slots, reach out directly, change the NBA…),
              then mark this handled to clear the flag. The message stays in the Actions Audit Log.
              <span className="mt-1 block">
                <b className="text-foreground">Reset this round</b> puts them back at the start of{" "}
                {hr.round_name ? <b className="text-foreground">{hr.round_name}</b> : "their current round"}:
                the old picker link is disabled and a fresh slot-invite draft is generated for the
                usual review-and-send flow. Cancel any already-booked meeting from the calendar.
              </span>
            </p>
            {resetRound.isError && (
              <p className="mt-2 text-[11px] font-medium text-rose-500">
                Couldn't reset the round — check the candidate is still in a round and try again.
              </p>
            )}
            <div className="mt-4 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setOpen(false)}
                className="rounded-lg border border-border px-3.5 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-secondary"
              >
                Close
              </button>
              <button
                type="button"
                onClick={() => resetRound.mutate()}
                disabled={resetRound.isPending || resolve.isPending}
                title="Back to this round's initial stage — old link disabled, fresh slot-invite draft for review, help request marked handled"
                className="inline-flex items-center gap-1.5 rounded-lg border border-amber-500/50 bg-amber-400/10 px-3.5 py-1.5 text-xs font-semibold text-amber-700 transition-colors hover:bg-amber-400/20 disabled:opacity-50 dark:text-amber-400"
              >
                {resetRound.isPending ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <RotateCcw className="h-3.5 w-3.5" />
                )}
                Reset this round
              </button>
              <button
                type="button"
                onClick={() => resolve.mutate()}
                disabled={resolve.isPending}
                className={cn(
                  "inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3.5 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-emerald-700 disabled:opacity-50"
                )}
              >
                {resolve.isPending ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <CheckCircle2 className="h-3.5 w-3.5" />
                )}
                Mark handled
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
