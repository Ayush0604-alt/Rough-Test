import { cn } from "@/lib/utils";

/**
 * Compact KPI tile used inside a BentoCard's body (e.g. the quick-signals cluster).
 * Tabular numerics; tone tints the value.
 */
export default function BentoStat({
  label,
  value,
  unit,
  icon: Icon,
  tone = "default",
  className,
}: {
  label: string;
  value: React.ReactNode;
  unit?: string;
  icon?: React.ElementType;
  tone?: "default" | "good" | "warn" | "bad";
  className?: string;
}) {
  const toneCls =
    tone === "good" ? "text-emerald-400"
    : tone === "warn" ? "text-amber-400"
    : tone === "bad" ? "text-red-400"
    : "text-ink";
  return (
    <div className={cn("rounded-xl border border-border bg-secondary/30 p-3", className)}>
      <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wide text-ink-mute">
        {Icon && <Icon className="h-3 w-3" />}
        {label}
      </div>
      <div className={cn("tnum mt-1 truncate text-xl font-semibold leading-none", toneCls)} title={typeof value === "string" || typeof value === "number" ? String(value) : undefined}>
        {value}
        {unit && <span className="ml-1 text-xs font-normal text-ink-mute">{unit}</span>}
      </div>
    </div>
  );
}
