import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { fadeRise } from "@/lib/motion";

export type BentoTone = "default" | "accent" | "success" | "warn" | "danger";

export interface BentoSpan {
  base?: 1; // mobile is always single-column
  sm?: 1 | 2 | 3 | 4 | 5 | 6;
  lg?: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12;
}

// Literal class maps so Tailwind's JIT keeps them (no dynamic string building).
const SM: Record<number, string> = {
  1: "sm:col-span-1", 2: "sm:col-span-2", 3: "sm:col-span-3",
  4: "sm:col-span-4", 5: "sm:col-span-5", 6: "sm:col-span-6",
};
const LG: Record<number, string> = {
  1: "lg:col-span-1", 2: "lg:col-span-2", 3: "lg:col-span-3", 4: "lg:col-span-4",
  5: "lg:col-span-5", 6: "lg:col-span-6", 7: "lg:col-span-7", 8: "lg:col-span-8",
  9: "lg:col-span-9", 10: "lg:col-span-10", 11: "lg:col-span-11", 12: "lg:col-span-12",
};
const ROW: Record<number, string> = {
  1: "lg:row-span-1", 2: "lg:row-span-2", 3: "lg:row-span-3",
};

// Claymorphic: no hairline border — a faint tint wash carries the tone instead,
// with the puffy shadow (--clay-shadow-sm) doing the edge-definition work.
const TONE: Record<BentoTone, string> = {
  default: "",
  accent: "bg-primary/[0.03]",
  success: "bg-emerald-400/[0.04]",
  warn: "bg-orange-400/[0.04]",
  danger: "bg-red-400/[0.04]",
};

export interface BentoCardProps {
  span?: BentoSpan;
  rowSpan?: 1 | 2 | 3;
  title?: string;
  icon?: React.ElementType;
  /** Right-aligned header slot (buttons, counts, badges). */
  actions?: React.ReactNode;
  tone?: BentoTone;
  /** Set false to remove inner padding (e.g. when child owns its own layout). */
  padded?: boolean;
  className?: string;
  /** Extra classes on the inner content wrapper. */
  bodyClassName?: string;
  children?: React.ReactNode;
}

/**
 * The one Bento tile. Owns radius, border, elevation, optional header row, tone accents,
 * responsive column/row spans, and the fade-rise mount. Every page tile is a BentoCard —
 * pages never hand-roll card markup (see docs/COMPONENT_ARCHITECTURE.md).
 */
export default function BentoCard({
  span,
  rowSpan,
  title,
  icon: Icon,
  actions,
  tone = "default",
  padded = true,
  className,
  bodyClassName,
  children,
}: BentoCardProps) {
  return (
    <motion.section
      variants={fadeRise}
      className={cn(
        "rounded-[26px] border-0 bg-card clay-shadow-sm",
        TONE[tone],
        span?.sm && SM[span.sm],
        span?.lg && LG[span.lg],
        rowSpan && ROW[rowSpan],
        padded && "p-4 sm:p-5",
        className,
      )}
    >
      {(title || actions) && (
        <header className="mb-3 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            {Icon && <Icon className="h-3.5 w-3.5 text-ink-mute" />}
            {title && (
              <h3 className="text-xs font-bold uppercase tracking-wider text-ink-mute">
                {title}
              </h3>
            )}
          </div>
          {actions}
        </header>
      )}
      <div className={bodyClassName}>{children}</div>
    </motion.section>
  );
}
