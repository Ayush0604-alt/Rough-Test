import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { stagger } from "@/lib/motion";

/**
 * A 12-column responsive Bento grid. Children are `BentoCard`s whose `span` prop sets
 * their column spans per breakpoint; on mobile everything collapses to a single column.
 * Mounts its children with a subtle stagger.
 */
export default function BentoGrid({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <motion.div
      variants={stagger}
      initial="hidden"
      animate="show"
      className={cn(
        "grid grid-cols-1 gap-3 sm:grid-cols-6 sm:gap-3 lg:grid-cols-12",
        className,
      )}
    >
      {children}
    </motion.div>
  );
}
