import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Bell,
  CheckCheck,
  AlertTriangle,
  AlertCircle,
  CheckCircle2,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useNotifications } from "@/hooks/useNotifications";
import type { AppNotification, NotificationSeverity } from "@/types/notification";

// Severity → row accent + icon, reusing the Activity Log palette.
const SEVERITY: Record<
  NotificationSeverity,
  { icon: React.ElementType; stripe: string; iconCls: string }
> = {
  action: { icon: AlertCircle, stripe: "bg-orange-400", iconCls: "text-orange-400" },
  health: { icon: AlertTriangle, stripe: "bg-red-400", iconCls: "text-red-400" },
  info: { icon: CheckCircle2, stripe: "bg-emerald-400", iconCls: "text-emerald-400" },
};

function relativeTime(iso: string | null): string {
  if (!iso) return "";
  const then = new Date(iso).getTime();
  if (Number.isNaN(then)) return "";
  const secs = Math.round((Date.now() - then) / 1000);
  if (secs < 60) return "just now";
  const mins = Math.round(secs / 60);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.round(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.round(hrs / 24);
  return `${days}d ago`;
}

export default function NotificationBell() {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const { items, unreadCount, hasUnreadAction, isUnread, markAllRead } =
    useNotifications();

  // Close on outside-click / Escape.
  useEffect(() => {
    if (!open) return;
    const onClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("mousedown", onClick);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onClick);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const handleOpen = (next: boolean) => {
    setOpen(next);
    if (next && unreadCount > 0) markAllRead(); // opening the panel = seen
  };

  const goTo = (n: AppNotification) => {
    setOpen(false);
    if (n.link) navigate(n.link);
  };

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        aria-label="Notifications"
        onClick={() => handleOpen(!open)}
        className="relative inline-flex h-10 w-10 items-center justify-center rounded-full text-ink-mute transition-colors hover:bg-secondary hover:text-ink"
      >
        <Bell className="h-5 w-5" />
        {unreadCount > 0 && (
          <span
            className={cn(
              "absolute -top-0.5 -right-0.5 inline-flex min-w-[18px] h-[18px] items-center justify-center rounded-full px-1 text-[10px] font-bold text-white",
              hasUnreadAction ? "bg-orange-500" : "bg-primary",
            )}
          >
            {unreadCount > 9 ? "9+" : unreadCount}
            {hasUnreadAction && (
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-orange-400 opacity-60" />
            )}
          </span>
        )}
      </button>

      {open && (
        <div className="glass-panel fixed inset-x-3 top-16 z-50 overflow-hidden rounded-xl shadow-xl sm:absolute sm:inset-x-auto sm:right-0 sm:top-auto sm:mt-2 sm:w-[340px] sm:max-w-[calc(100vw-2rem)]">
          <div className="flex items-center justify-between border-b border-border px-4 py-2.5">
            <span className="text-sm font-semibold text-ink">Notifications</span>
            <button
              type="button"
              onClick={markAllRead}
              className="inline-flex items-center gap-1 text-xs text-ink-mute transition-colors hover:text-ink"
            >
              <CheckCheck className="h-3.5 w-3.5" />
              Mark all read
            </button>
          </div>

          <div className="max-h-[60vh] overflow-y-auto">
            {items.length === 0 ? (
              <div className="px-4 py-10 text-center">
                <div className="text-2xl">🎉</div>
                <p className="mt-1 text-sm text-ink-mute">You're all caught up</p>
              </div>
            ) : (
              items.map((n) => {
                const cfg = SEVERITY[n.severity] ?? SEVERITY.info;
                const Icon = cfg.icon;
                const unread = isUnread(n);
                return (
                  <button
                    key={n.id}
                    type="button"
                    onClick={() => goTo(n)}
                    className={cn(
                      "flex w-full items-start gap-2.5 border-b border-border/50 px-3 py-2.5 text-left transition-colors hover:bg-accent/50",
                      !unread && "opacity-65",
                    )}
                  >
                    {/* Leading status dot — only while unread; clears once read. */}
                    {unread ? (
                      <span className={cn("mt-1 h-2 w-2 shrink-0 rounded-full", cfg.stripe)} />
                    ) : (
                      <span className="mt-1 h-2 w-2 shrink-0" />
                    )}
                    <Icon className={cn("mt-0.5 h-4 w-4 shrink-0", cfg.iconCls)} />
                    <span className="min-w-0 flex-1">
                      <span className="flex items-center gap-1.5">
                        {unread && <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />}
                        <span className="truncate text-[13px] font-medium text-ink">
                          {n.title}
                        </span>
                      </span>
                      {n.body && (
                        <span className="mt-0.5 block text-xs leading-snug text-ink-mute">
                          {n.body}
                        </span>
                      )}
                      <span className="mt-0.5 block text-[10px] text-muted-foreground">
                        {relativeTime(n.created_at)}
                      </span>
                    </span>
                  </button>
                );
              })
            )}
          </div>

          <button
            type="button"
            onClick={() => {
              setOpen(false);
              navigate("/audit-logs");
            }}
            className="w-full border-t border-border px-4 py-2.5 text-center text-xs font-medium text-primary transition-colors hover:bg-accent/50"
          >
            View all activity →
          </button>
        </div>
      )}
    </div>
  );
}
