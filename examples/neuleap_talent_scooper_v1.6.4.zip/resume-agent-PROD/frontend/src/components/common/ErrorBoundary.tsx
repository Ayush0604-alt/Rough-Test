import { Component, type ErrorInfo, type ReactNode } from "react";

/**
 * Last-resort error boundary — a render crash anywhere below used to unmount
 * the ENTIRE app into a silent white page (e.g. a FastAPI 422 detail object
 * rendered as a React child, error #31). Now the user sees what broke and can
 * reload, and the message is worth screenshotting in a bug report.
 */
export default class ErrorBoundary extends Component<
  { children: ReactNode },
  { error: Error | null }
> {
  state = { error: null as Error | null };

  static getDerivedStateFromError(error: Error) {
    return { error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error("ErrorBoundary caught:", error, info.componentStack);
  }

  render() {
    if (!this.state.error) return this.props.children;
    return (
      <div className="flex min-h-screen items-center justify-center bg-background p-6">
        <div className="w-full max-w-md rounded-2xl border border-border bg-card p-6 shadow-xl">
          <h1 className="text-base font-bold text-foreground">Something went wrong</h1>
          <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
            The page hit an unexpected error and couldn't continue. Reloading usually fixes it —
            if it keeps happening, share the message below with the team.
          </p>
          <pre className="selectable mt-3 max-h-40 overflow-auto whitespace-pre-wrap rounded-lg border border-border bg-secondary/40 p-3 text-[11px] leading-relaxed text-rose-500">
            {String(this.state.error?.message ?? this.state.error)}
          </pre>
          <button
            type="button"
            onClick={() => window.location.reload()}
            className="mt-4 w-full rounded-lg bg-primary px-3 py-2 text-xs font-semibold text-white transition-colors hover:bg-primary/90"
          >
            Reload page
          </button>
        </div>
      </div>
    );
  }
}
