import { useId } from "react";
import { ArrowUpRight, ArrowDownRight, Minus } from "lucide-react";
import { cn } from "@/lib/utils";

export type Accent = "blue" | "violet" | "amber" | "emerald" | "orange" | "rose" | "sky";

const ACCENTS: Record<Accent, { hex: string; badge: string; icon: string }> = {
  blue: { hex: "#533afd", badge: "bg-[#533afd]/10", icon: "text-[#533afd]" },
  violet: { hex: "#665efd", badge: "bg-[#665efd]/10", icon: "text-[#4434d4]" },
  amber: { hex: "#d97706", badge: "bg-amber-500/10", icon: "text-amber-600" },
  emerald: { hex: "#059669", badge: "bg-emerald-500/10", icon: "text-emerald-600" },
  orange: { hex: "#ea580c", badge: "bg-orange-500/10", icon: "text-orange-600" },
  rose: { hex: "#ea2261", badge: "bg-[#ea2261]/10", icon: "text-[#ea2261]" },
  sky: { hex: "#0284c7", badge: "bg-sky-500/10", icon: "text-sky-600" },
};

/** Catmull-Rom → cubic-bézier so the waveform is a smooth flowing curve. */
function smoothPath(points: { x: number; y: number }[]): string {
  if (points.length < 2) return "";
  let d = `M ${points[0].x},${points[0].y}`;
  for (let i = 0; i < points.length - 1; i++) {
    const p0 = points[i - 1] ?? points[i];
    const p1 = points[i];
    const p2 = points[i + 1];
    const p3 = points[i + 2] ?? p2;
    const c1x = p1.x + (p2.x - p0.x) / 6;
    const c1y = p1.y + (p2.y - p0.y) / 6;
    const c2x = p2.x - (p3.x - p1.x) / 6;
    const c2y = p2.y - (p3.y - p1.y) / 6;
    d += ` C ${c1x},${c1y} ${c2x},${c2y} ${p2.x},${p2.y}`;
  }
  return d;
}

function Waveform({ data, hex }: { data: number[]; hex: string }) {
  const gid = useId();
  const W = 100;
  const H = 30;
  const series = data.length >= 2 ? data : [3, 5, 4, 6, 5, 7, 6, 8];
  const min = Math.min(...series);
  const max = Math.max(...series);
  const span = max - min || 1;
  const pts = series.map((v, i) => ({
    x: (i / (series.length - 1)) * W,
    // 4px top/bottom padding inside the 30-unit box.
    y: 26 - ((v - min) / span) * 22,
  }));
  const line = smoothPath(pts);
  const area = `${line} L ${W},${H} L 0,${H} Z`;

  return (
    <svg
      className="absolute inset-x-0 bottom-0 h-9 w-full stat-wave"
      viewBox={`0 0 ${W} ${H}`}
      preserveAspectRatio="none"
      aria-hidden="true"
    >
      <defs>
        <linearGradient id={`fill-${gid}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={hex} stopOpacity="0.18" />
          <stop offset="100%" stopColor={hex} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={area} fill={`url(#fill-${gid})`} stroke="none" />
      <path d={line} fill="none" stroke={hex} strokeWidth="1.1" strokeOpacity="0.6"
        strokeLinecap="round" vectorEffect="non-scaling-stroke" />
    </svg>
  );
}

export interface StatCardProps {
  label: string;
  value: number | string;
  icon: React.ElementType;
  accent?: Accent;
  delta?: string;
  trend?: "up" | "down" | "flat";
  hint?: string;
  data?: number[];
  onClick?: () => void;
  // "pill" is the compact, single-line chip used for the mobile tile row — icon +
  // value + label only, no waveform/hint, sized to its content instead of a grid cell.
  variant?: "card" | "pill";
  // Pill-only: an extra chip after the label (e.g. "Oldest 12d") for stages that
  // track an oldest-in-stage age alongside their count.
  sub?: React.ReactNode;
  // Pill-only: skip the sm:+ size escalation and stay at the small mobile
  // sizing at every breakpoint — for a row with many tiles that needs to stay
  // on one line (e.g. the Dashboard's stage tiles) rather than grow with viewport.
  compact?: boolean;
}

export default function StatCard({
  label,
  value,
  icon: Icon,
  accent = "blue",
  delta,
  trend = "flat",
  hint,
  data,
  onClick,
  variant = "card",
  sub,
  compact = false,
}: StatCardProps) {
  const a = ACCENTS[accent];
  const TrendIcon = trend === "up" ? ArrowUpRight : trend === "down" ? ArrowDownRight : Minus;
  const trendCls =
    trend === "up" ? "text-emerald-600" : trend === "down" ? "text-rose-600" : "text-muted-foreground";

  const Wrapper = onClick ? "button" : "div";

  if (variant === "pill") {
    return (
      <Wrapper
        onClick={onClick}
        className={cn(
          // .surface bakes in rounded-2xl — !rounded-full forces the pill shape to win.
          "surface inline-flex shrink-0 items-center !rounded-full transition-all duration-200",
          compact
            ? "gap-1 px-2 py-1 sm:gap-1.5 sm:px-2.5 sm:py-1.5 lg:gap-2 lg:px-3 lg:py-1.5"
            : "gap-1.5 px-2.5 py-1.5 sm:gap-2 sm:px-3.5 sm:py-2",
          onClick && "active:scale-95 cursor-pointer sm:hover:-translate-y-0.5 sm:hover:shadow-[0_12px_28px_-16px_rgba(16,24,40,0.25)]"
        )}
      >
        <span
          className={cn(
            "flex shrink-0 items-center justify-center rounded-full",
            compact ? "h-4 w-4 sm:h-5 sm:w-5 lg:h-6 lg:w-6" : "h-5 w-5 sm:h-7 sm:w-7",
            a.badge,
          )}
        >
          <Icon className={cn(compact ? "h-2.5 w-2.5 sm:h-3 sm:w-3 lg:h-3.5 lg:w-3.5" : "h-3 w-3 sm:h-3.5 sm:w-3.5", a.icon)} />
        </span>
        <span
          className={cn(
            "stat-value font-semibold leading-none text-ink",
            compact ? "text-xs sm:text-sm lg:text-base" : "text-sm sm:text-base",
          )}
        >
          {value}
        </span>
        <span
          className={cn(
            "whitespace-nowrap font-medium text-ink-mute",
            compact ? "text-[9px] sm:text-[10px] lg:text-xs" : "text-[10px] sm:text-xs",
          )}
        >
          {label}
        </span>
        {sub}
      </Wrapper>
    );
  }

  return (
    <Wrapper
      onClick={onClick}
      className={cn(
        "surface relative overflow-hidden p-2.5 text-left transition-all duration-200",
        onClick && "hover:-translate-y-0.5 hover:shadow-[0_12px_28px_-16px_rgba(16,24,40,0.25)] cursor-pointer"
      )}
    >
      {/* Top row: icon badge + delta */}
      <div className="flex items-start justify-between">
        <div className={cn("flex h-6 w-6 items-center justify-center rounded-full", a.badge)}>
          <Icon className={cn("h-3.5 w-3.5", a.icon)} />
        </div>
        {delta && (
          <span className={cn("inline-flex items-center gap-0.5 text-[10px] font-semibold", trendCls)}>
            <TrendIcon className="h-3 w-3" />
            {delta}
          </span>
        )}
      </div>

      {/* Value + label */}
      <div className="mt-1.5">
        <div className="stat-value text-lg font-light leading-none text-ink">
          {value}
        </div>
        <div className="mt-0.5 text-[11px] font-normal text-ink-mute">{label}</div>
      </div>

      {/* Hint sits above the wave */}
      {hint && <div className="relative z-10 mt-0.5 text-[10px] text-muted-foreground/80">{hint}</div>}

      {/* Waveform along the bottom edge */}
      <Waveform data={data ?? []} hex={a.hex} />

      {/* spacer so content clears the wave */}
      <div className="h-1.5" />
    </Wrapper>
  );
}
