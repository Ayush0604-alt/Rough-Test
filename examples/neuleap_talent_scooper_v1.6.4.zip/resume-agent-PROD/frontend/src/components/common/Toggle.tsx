import { cn } from "@/lib/utils";

// Small on/off switch — shared version of the one Settings/index.tsx defines
// locally, for use outside the Settings page (e.g. Mailbox → Batch Archive's
// per-source toggles).
export default function Toggle({
  value,
  onChange,
  disabled,
}: {
  value: boolean;
  onChange: (v: boolean) => void;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={() => onChange(!value)}
      disabled={disabled}
      className={cn(
        "relative inline-flex h-5 w-9 shrink-0 items-center rounded-full transition-colors disabled:cursor-not-allowed disabled:opacity-50",
        value ? "bg-primary" : "bg-secondary"
      )}
    >
      <span
        className={cn(
          "inline-block h-3.5 w-3.5 transform rounded-full bg-white shadow transition-transform",
          value ? "translate-x-4" : "translate-x-1"
        )}
      />
    </button>
  );
}
