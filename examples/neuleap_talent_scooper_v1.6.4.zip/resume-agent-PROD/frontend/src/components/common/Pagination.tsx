import type { ReactNode } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

interface PaginationProps {
  page: number;
  pageCount: number;
  total: number;
  pageSize: number;
  startIndex: number;
  onPage: (p: number) => void;
  /** Plural noun for the items being paged, e.g. "resumes", "entries". */
  itemLabel?: string;
  /** Show the "Showing X–Y of N" line under the controls. Default true. */
  showCount?: boolean;
  /** Optional page-size picker, rendered alongside the page buttons — callers
   *  that let the user adjust rows-per-page pass their own control here
   *  (e.g. a FilterDropdown) rather than this component owning that state. */
  pageSizeControl?: ReactNode;
  className?: string;
}

// Size of the sliding page window (how many numbered buttons stay visible).
const WINDOW = 5;

/** A sliding window of up to WINDOW consecutive page numbers, centered on the active
 *  page and clamped to [1, pageCount], e.g. [4, 5, 6, 7, 8] → slides as page moves. */
function pageWindow(page: number, pageCount: number): number[] {
  const size = Math.min(WINDOW, pageCount);
  let start = Math.max(1, page - Math.floor(WINDOW / 2));
  // Clamp at the upper edge so the window keeps its full width near the last page.
  if (start + size - 1 > pageCount) start = pageCount - size + 1;
  return Array.from({ length: size }, (_, i) => start + i);
}

export default function Pagination({
  page,
  pageCount,
  total,
  pageSize,
  startIndex,
  onPage,
  itemLabel = "items",
  showCount = true,
  pageSizeControl,
  className,
}: PaginationProps) {
  if (total === 0) return null;

  const from = startIndex + 1;
  const to = Math.min(startIndex + pageSize, total);

  const btn =
    "inline-flex items-center justify-center h-7 min-w-7 px-1.5 rounded-lg border text-xs font-medium transition-colors disabled:opacity-40 disabled:pointer-events-none";

  return (
    <div className={cn("flex flex-col items-center gap-2", className)}>
      {(pageCount > 1 || pageSizeControl) && (
        <div className="flex flex-wrap items-center justify-center gap-3">
          {pageCount > 1 && (
            <div className="flex items-center justify-center gap-1">
              <button
                onClick={() => onPage(page - 1)}
                disabled={page <= 1}
                aria-label="Previous page"
                className={cn(btn, "border-border text-muted-foreground hover:text-foreground")}
              >
                <ChevronLeft className="h-3.5 w-3.5" />
              </button>

              {pageWindow(page, pageCount).map((p) => (
                <button
                  key={p}
                  onClick={() => onPage(p)}
                  aria-current={p === page ? "page" : undefined}
                  className={cn(
                    btn,
                    p === page
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-border text-muted-foreground hover:text-foreground"
                  )}
                >
                  {p}
                </button>
              ))}

              <button
                onClick={() => onPage(page + 1)}
                disabled={page >= pageCount}
                aria-label="Next page"
                className={cn(btn, "border-border text-muted-foreground hover:text-foreground")}
              >
                <ChevronRight className="h-3.5 w-3.5" />
              </button>
            </div>
          )}
          {pageSizeControl}
        </div>
      )}

      {showCount && (
        <span className="text-xs text-muted-foreground tnum">
          Showing {from}–{to} of {total} {itemLabel}
        </span>
      )}
    </div>
  );
}
