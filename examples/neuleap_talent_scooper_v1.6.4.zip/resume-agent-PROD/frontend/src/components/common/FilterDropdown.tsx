import { useEffect, useRef, useState } from "react";
import { Check, ChevronDown, Search, X } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * The single source of truth for every toolbar filter/sort dropdown (Dashboard,
 * Screening, …) so they never drift into the OS-rendered `<select>` look again.
 *
 *  - multi-select (default): checkboxes, stays open while toggling, shows a count badge.
 *  - `single`: radio style, closes on pick — used for the year/sort pickers. Pass
 *    `allowClear={false}` for required single-selects (year, sort) that always carry a
 *    value, so the "Clear selection" row is hidden.
 */
export default function FilterDropdown({
  label,
  icon,
  options,
  selected,
  onToggle,
  onClear,
  footer,
  width = "w-52",
  single = false,
  allowClear = true,
  optionLabel,
  align = "left",
  openUp = false,
  searchable = false,
  searchPlaceholder = "Search…",
  searchLimit,
}: {
  label: string;
  icon?: React.ReactNode;
  options: readonly string[];
  selected: Set<string>;
  onToggle: (v: string) => void;
  onClear: () => void;
  footer?: React.ReactNode;
  width?: string;
  single?: boolean;
  allowClear?: boolean;
  optionLabel?: (value: string) => string;
  // Which edge of the trigger the menu aligns to. Use "right" when the trigger
  // sits at the far right of its container so the menu doesn't overflow.
  align?: "left" | "right";
  // Open the menu ABOVE the trigger instead of below. Use this when the trigger
  // sits near the bottom of the page (e.g. a pagination control) — opening
  // downward there grows the scrollable page height and reads as the whole
  // page "jumping"/pushing down instead of just revealing a small menu.
  openUp?: boolean;
  // Adds a type-ahead search box above the option list — for pickers whose
  // option list can grow large (e.g. free-text source tags). Filters by
  // substring match against `optionLabel(opt)` (or `opt` itself).
  searchable?: boolean;
  searchPlaceholder?: string;
  // While the search box is empty, cap the visible list to the first N
  // options (the caller controls ordering — e.g. most-recent-first) so a long
  // list doesn't dominate the panel. A non-empty query always searches the
  // FULL option list, uncapped, so nothing outside the cap is unreachable.
  searchLimit?: number;
}) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const ref = useRef<HTMLDivElement>(null);
  const count = selected.size;

  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  // Reset the search box each time the panel closes, so reopening it always
  // starts from the same capped "latest N" view rather than a stale filter.
  useEffect(() => {
    if (!open) setQuery("");
  }, [open]);

  const trimmedQuery = query.trim().toLowerCase();
  const searched =
    searchable && trimmedQuery
      ? options.filter((opt) => (optionLabel ? optionLabel(opt) : opt).toLowerCase().includes(trimmedQuery))
      : options;
  const visibleOptions =
    searchable && !trimmedQuery && searchLimit != null ? searched.slice(0, searchLimit) : searched;
  const truncated = searchable && !trimmedQuery && searchLimit != null && options.length > searchLimit;

  return (
    <div ref={ref} className="relative shrink-0">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className={cn(
          "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium transition-colors",
          count > 0
            ? "border-primary bg-primary/10 text-primary"
            : "border-border text-muted-foreground hover:text-foreground hover:border-border/80"
        )}
      >
        {icon}
        {label}
        {count > 0 && !single && (
          <span className="rounded-full bg-primary/20 px-1.5 text-[10px] font-bold leading-4">
            {count}
          </span>
        )}
        <ChevronDown className={cn("h-3 w-3 transition-transform", open && "rotate-180")} />
      </button>
      {open && (
        <div
          className={cn(
            "absolute z-40 rounded-xl border border-border bg-card p-1.5 shadow-lg",
            openUp ? "bottom-full mb-1.5" : "top-full mt-1.5",
            align === "right" ? "right-0" : "left-0",
            width
          )}
        >
          {count > 0 && allowClear && (
            <button
              onClick={onClear}
              className="mb-1 flex w-full items-center justify-between rounded-lg px-2 py-1 text-left text-[11px] font-medium text-muted-foreground hover:bg-secondary hover:text-foreground"
            >
              Clear selection
              <X className="h-3 w-3" />
            </button>
          )}
          {searchable && (
            <div className="relative mb-1">
              <Search className="pointer-events-none absolute left-2 top-1/2 h-3 w-3 -translate-y-1/2 text-muted-foreground" />
              <input
                autoFocus
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={searchPlaceholder}
                className="w-full rounded-lg border border-border bg-secondary/40 py-1.5 pl-7 pr-2 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50"
              />
            </div>
          )}
          <div className="max-h-60 overflow-y-auto">
            {visibleOptions.length === 0 && (
              <p className="px-2 py-2 text-[11px] text-muted-foreground">No matches.</p>
            )}
            {visibleOptions.map((opt) => {
              const active = selected.has(opt);
              return (
                <button
                  key={opt}
                  onClick={() => {
                    onToggle(opt);
                    if (single) setOpen(false);
                  }}
                  className="flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left text-xs text-foreground hover:bg-secondary"
                >
                  <span
                    className={cn(
                      "flex h-4 w-4 shrink-0 items-center justify-center border transition-colors",
                      single ? "rounded-full" : "rounded",
                      active ? "border-primary bg-primary text-white" : "border-border"
                    )}
                  >
                    {active &&
                      (single ? (
                        <span className="h-1.5 w-1.5 rounded-full bg-white" />
                      ) : (
                        <Check className="h-3 w-3" />
                      ))}
                  </span>
                  {optionLabel ? optionLabel(opt) : opt}
                </button>
              );
            })}
          </div>
          {truncated && (
            <p className="px-2 pt-1.5 text-center text-[10px] text-muted-foreground">
              Showing the latest {searchLimit} of {options.length} — search for more
            </p>
          )}
          {footer && <div className="mt-1 border-t border-border pt-1.5">{footer}</div>}
        </div>
      )}
    </div>
  );
}
