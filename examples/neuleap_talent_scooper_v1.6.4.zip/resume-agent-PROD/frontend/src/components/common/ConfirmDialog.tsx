import type { ReactNode } from "react";
import { Check, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";

// Generic "are you sure?" confirmation — stacks above any other open modal
// (z-[60] vs. the app's usual z-50) so it can gate a destructive/irreversible
// action (e.g. applying a predicted NBA) triggered from inside another popup.
export default function ConfirmDialog({
  open,
  title,
  message,
  confirmLabel = "Confirm",
  cancelLabel = "Cancel",
  pending = false,
  pendingLabel = "Applying…",
  // "positive" (default) — a forward-moving action like applying an NBA.
  // "destructive" — data loss (archive/delete/wipe): rose icon + button
  // instead of the default green, so severity reads at a glance.
  tone = "positive",
  onConfirm,
  onCancel,
}: {
  open: boolean;
  title: string;
  message: ReactNode;
  confirmLabel?: string;
  cancelLabel?: string;
  pending?: boolean;
  pendingLabel?: string;
  tone?: "positive" | "destructive";
  onConfirm: () => void;
  onCancel: () => void;
}) {
  if (!open) return null;
  const destructive = tone === "destructive";
  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center bg-foreground/50 p-4 backdrop-blur-sm"
      onClick={onCancel}
    >
      <div
        className="w-full max-w-sm rounded-2xl border border-border bg-card p-5 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start gap-3">
          <span
            className={cn(
              "flex h-9 w-9 shrink-0 items-center justify-center rounded-full",
              destructive ? "bg-rose-500/10 text-rose-600" : "bg-emerald-500/10 text-emerald-600",
            )}
          >
            {destructive ? <AlertTriangle className="h-4.5 w-4.5" /> : <Check className="h-4.5 w-4.5" />}
          </span>
          <div className="min-w-0">
            <h3 className="text-sm font-bold text-foreground">{title}</h3>
            <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{message}</p>
          </div>
        </div>
        <div className="mt-5 flex justify-end gap-2">
          <button
            type="button"
            onClick={onCancel}
            className="rounded-lg border border-border px-3.5 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-secondary"
          >
            {cancelLabel}
          </button>
          <button
            type="button"
            onClick={onConfirm}
            disabled={pending}
            className={cn(
              "rounded-lg px-3.5 py-1.5 text-xs font-semibold text-white transition-colors disabled:opacity-50",
              destructive ? "bg-rose-600 hover:bg-rose-700" : "bg-emerald-600 hover:bg-emerald-700",
            )}
          >
            {pending ? pendingLabel : confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
