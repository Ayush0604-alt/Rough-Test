// Mailbox → "Batch Archive" — archive/restore/prune resumes by source tag, and
// (Admin only) wipe the whole database for a fresh QA reload. A "batch" here
// is every candidate + email sharing one source tag; "No source" is its own
// selectable batch for untagged intake. See app.services.batch_archive /
// app.services.system_reset for exactly what each action does server-side.
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Archive,
  ArchiveRestore,
  Trash2,
  Tag,
  Loader2,
  ShieldAlert,
  RotateCcw,
  ChevronDown,
  ChevronRight,
} from "lucide-react";
import {
  batchArchiveService,
  NO_SOURCE_KEY,
  type LiveBatch,
  type ArchivedBatch,
} from "@/services/batchArchive";
import { systemResetService } from "@/services/systemReset";
import { useAuth } from "@/context/AuthContext";
import { cn } from "@/lib/utils";
import ConfirmDialog from "@/components/common/ConfirmDialog";
import Toggle from "@/components/common/Toggle";

type Tab = "live" | "archived" | "cleanup";

const NO_SOURCE_LABEL = "No source";

function fmtDate(s: string | null): string {
  if (!s) return "—";
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return s;
  return d.toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });
}

export default function BatchArchivePanel() {
  const { isAdmin } = useAuth();
  const [tab, setTab] = useState<Tab>("live");
  // Collapsed by default — this section holds destructive actions (archive,
  // permanent delete, full DB wipe) that have no business being open-by-default
  // on a page recruiters visit constantly. A warning POPUP (not just a banner)
  // gates every expand — collapsing resets the ack, so it re-prompts next time
  // too, rather than being a one-off dismissal.
  const [open, setOpen] = useState(false);
  const [warningAcked, setWarningAcked] = useState(false);

  const expand = () => setOpen(true);
  const collapse = () => {
    setOpen(false);
    setWarningAcked(false);
  };

  return (
    <div className="surface overflow-hidden">
      <button
        type="button"
        onClick={() => (open ? collapse() : expand())}
        className="flex w-full items-center gap-2.5 px-5 py-3 text-left transition-colors hover:bg-secondary/30"
      >
        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-violet-500/10">
          <Archive className="h-4 w-4 text-violet-500" />
        </div>
        <div className="min-w-0 flex-1">
          <h2 className="text-sm font-semibold text-ink">Batch Archive</h2>
          <p className="text-[11px] text-ink-mute">
            Archive, restore, or permanently delete resumes grouped by their source tag.
          </p>
        </div>
        {open ? (
          <ChevronDown className="h-4 w-4 shrink-0 text-ink-mute" />
        ) : (
          <ChevronRight className="h-4 w-4 shrink-0 text-ink-mute" />
        )}
      </button>

      {open && !warningAcked && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/40 p-4 backdrop-blur-sm"
          onClick={collapse}
        >
          <div
            className="w-full max-w-sm rounded-2xl border border-border bg-card p-5 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start gap-3">
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-amber-400/10 text-amber-500">
                <ShieldAlert className="h-4.5 w-4.5" />
              </span>
              <div className="min-w-0">
                <h3 className="text-sm font-bold text-foreground">This section can remove data</h3>
                <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                  Archiving hides a batch until it's retrieved, but deleting or wiping is{" "}
                  <span className="font-semibold text-foreground">permanent</span>. Double-check the
                  source tag and candidate count before confirming any action here.
                </p>
              </div>
            </div>
            <div className="mt-5 flex justify-end gap-2">
              <button
                type="button"
                onClick={collapse}
                className="rounded-lg border border-border px-3.5 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-secondary"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => setWarningAcked(true)}
                className="inline-flex items-center gap-1.5 rounded-lg bg-amber-500 px-3.5 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-amber-600"
              >
                <ShieldAlert className="h-3.5 w-3.5" /> I understand, continue
              </button>
            </div>
          </div>
        </div>
      )}

      {open && warningAcked && (
        <div className="border-t border-border">
          <div className="flex items-center gap-1 border-b border-border px-5 pt-2.5">
            {(
              [
                ["live", "Live batches"],
                ["archived", "Archived batches"],
                ...(isAdmin ? ([["cleanup", "System Cleanup"]] as [Tab, string][]) : []),
              ] as [Tab, string][]
            ).map(([id, label]) => (
              <button
                key={id}
                onClick={() => setTab(id)}
                className={cn(
                  "rounded-t-lg px-3 py-1.5 text-xs font-semibold transition-colors",
                  tab === id
                    ? "border-b-2 border-primary text-primary"
                    : "border-b-2 border-transparent text-ink-mute hover:text-ink",
                )}
              >
                {label}
              </button>
            ))}
          </div>

          {tab === "live" && <LiveBatchesTab />}
          {tab === "archived" && <ArchivedBatchesTab />}
          {tab === "cleanup" && isAdmin && <SystemCleanupTab />}
        </div>
      )}
    </div>
  );
}

// ── Live batches — archive a batch ──────────────────────────────────────────

function LiveBatchesTab() {
  const queryClient = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["batches-live"],
    queryFn: async () => (await batchArchiveService.listLive()).data.batches,
  });
  const { data: recruiterApply } = useQuery({
    queryKey: ["recruiter-apply-nba"],
    queryFn: async () => (await batchArchiveService.getRecruiterApplyNba()).data,
  });
  const [confirmFor, setConfirmFor] = useState<LiveBatch | null>(null);
  // Turning this ON is the consequential direction (a Recruiter can then move
  // candidates from this source forward with no Admin review) — confirm
  // first. Turning it back off is always free, no confirmation needed.
  const [confirmEnableFor, setConfirmEnableFor] = useState<LiveBatch | null>(null);

  const archive = useMutation({
    mutationFn: (source: string | null) => batchArchiveService.archive(source),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["batches-live"] });
      queryClient.invalidateQueries({ queryKey: ["batches-archived"] });
      queryClient.invalidateQueries({ queryKey: ["candidates"] });
      queryClient.invalidateQueries({ queryKey: ["emails"] });
      setConfirmFor(null);
    },
  });

  const setRecruiterApply = useMutation({
    mutationFn: ({ source, enabled }: { source: string | null; enabled: boolean }) =>
      batchArchiveService.saveRecruiterApplyNba(source, enabled),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["recruiter-apply-nba"] }),
  });

  const batches = data ?? [];

  return (
    <div className="px-5 py-4">
      {isLoading ? (
        <div className="flex items-center gap-2 py-6 text-sm text-ink-mute">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading batches…
        </div>
      ) : batches.length === 0 ? (
        <p className="py-6 text-center text-xs text-ink-mute">No candidates to archive yet.</p>
      ) : (
        <ul className="divide-y divide-border">
          {batches.map((b) => (
            <li key={b.source ?? "__none__"} className="flex items-center gap-3 py-2.5">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-secondary">
                <Tag className="h-4 w-4 text-ink-mute" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="truncate text-sm font-medium text-ink">
                  {b.source ?? NO_SOURCE_LABEL}
                </div>
                <div className="truncate text-[11px] text-ink-mute">
                  {b.candidate_count} candidate{b.candidate_count === 1 ? "" : "s"} · {fmtDate(b.oldest)} – {fmtDate(b.newest)}
                </div>
              </div>
              <div
                className="flex shrink-0 items-center gap-2 rounded-lg border border-border/60 bg-secondary/30 py-1 pl-2.5 pr-1.5"
                title="Whether a Recruiter can apply a predicted NBA (or schedule a round) for a still-New candidate from this source without Admin review first"
              >
                <span className="text-right text-[9px] font-normal leading-snug text-ink-mute/70">
                  Recruiter can apply the
                  <br />
                  predicted NBA
                </span>
                <Toggle
                  value={recruiterApply?.sources[b.source ?? NO_SOURCE_KEY] ?? false}
                  onChange={(v) =>
                    v ? setConfirmEnableFor(b) : setRecruiterApply.mutate({ source: b.source, enabled: false })
                  }
                  disabled={setRecruiterApply.isPending}
                />
              </div>
              <button
                onClick={() => setConfirmFor(b)}
                className="inline-flex shrink-0 items-center gap-1.5 rounded-lg border border-border px-2.5 py-1.5 text-[11px] font-semibold text-ink-mute transition-colors hover:border-rose-500/40 hover:bg-rose-500/10 hover:text-rose-600"
              >
                <Archive className="h-3.5 w-3.5" />
                Archive
              </button>
            </li>
          ))}
        </ul>
      )}

      <ConfirmDialog
        open={!!confirmFor}
        tone="destructive"
        title="Archive this batch?"
        message={
          confirmFor && (
            <>
              <span className="font-semibold text-foreground">{confirmFor.candidate_count}</span> candidate
              {confirmFor.candidate_count === 1 ? "" : "s"} tagged{" "}
              <span className="font-semibold text-foreground">
                {confirmFor.source ?? NO_SOURCE_LABEL}
              </span>{" "}
              (and their emails) will disappear from Dashboard, Candidates, and Mailbox until you
              retrieve this batch again from Archived Batches.
              {archive.isError && (
                <span className="mt-2 block font-medium text-rose-500">
                  Archiving failed —{" "}
                  {(archive.error as { response?: { data?: { detail?: string } } })?.response?.data
                    ?.detail ?? "an unexpected server error occurred. Try again."}
                </span>
              )}
            </>
          )
        }
        confirmLabel="Archive batch"
        pendingLabel="Archiving…"
        pending={archive.isPending}
        onCancel={() => setConfirmFor(null)}
        onConfirm={() => confirmFor && archive.mutate(confirmFor.source)}
      />

      <ConfirmDialog
        open={!!confirmEnableFor}
        title="Let Recruiters apply the predicted NBA for this source?"
        message={
          confirmEnableFor && (
            <>
              Recruiters will be able to apply the predicted Next Best Action — and directly schedule
              rounds — for any candidate tagged{" "}
              <span className="font-semibold text-foreground">
                {confirmEnableFor.source ?? NO_SOURCE_LABEL}
              </span>
              , without an Admin reviewing them first. This applies only to candidates from this source.
            </>
          )
        }
        confirmLabel="Enable"
        pending={setRecruiterApply.isPending}
        onCancel={() => setConfirmEnableFor(null)}
        onConfirm={() => {
          if (confirmEnableFor) setRecruiterApply.mutate({ source: confirmEnableFor.source, enabled: true });
          setConfirmEnableFor(null);
        }}
      />
    </div>
  );
}

// ── Archived batches — retrieve (restore) or permanently delete (prune) ─────

function ArchivedBatchesTab() {
  const queryClient = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["batches-archived"],
    queryFn: async () => (await batchArchiveService.listArchived()).data.batches,
  });
  const [restoreFor, setRestoreFor] = useState<ArchivedBatch | null>(null);
  const [pruneFor, setPruneFor] = useState<ArchivedBatch | null>(null);

  const invalidateAfterMove = () => {
    queryClient.invalidateQueries({ queryKey: ["batches-live"] });
    queryClient.invalidateQueries({ queryKey: ["batches-archived"] });
    queryClient.invalidateQueries({ queryKey: ["candidates"] });
    queryClient.invalidateQueries({ queryKey: ["emails"] });
  };

  const restore = useMutation({
    mutationFn: (source: string | null) => batchArchiveService.restore(source),
    onSuccess: () => {
      invalidateAfterMove();
      setRestoreFor(null);
    },
  });
  const prune = useMutation({
    mutationFn: (source: string | null) => batchArchiveService.prune(source),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["batches-archived"] });
      setPruneFor(null);
    },
  });

  const batches = data ?? [];

  return (
    <div className="px-5 py-4">
      {isLoading ? (
        <div className="flex items-center gap-2 py-6 text-sm text-ink-mute">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading archived batches…
        </div>
      ) : batches.length === 0 ? (
        <p className="py-6 text-center text-xs text-ink-mute">Nothing archived yet.</p>
      ) : (
        <ul className="divide-y divide-border">
          {batches.map((b) => (
            <li key={b.source ?? "__none__"} className="flex items-center gap-3 py-2.5">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-secondary">
                <Tag className="h-4 w-4 text-ink-mute" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="truncate text-sm font-medium text-ink">
                  {b.source ?? NO_SOURCE_LABEL}
                </div>
                <div className="truncate text-[11px] text-ink-mute">
                  {b.candidate_count} candidate{b.candidate_count === 1 ? "" : "s"} · archived{" "}
                  {fmtDate(b.archived_from)}
                  {b.archived_from !== b.archived_to ? ` – ${fmtDate(b.archived_to)}` : ""}
                </div>
              </div>
              <button
                onClick={() => setRestoreFor(b)}
                className="inline-flex shrink-0 items-center gap-1.5 rounded-lg border border-border px-2.5 py-1.5 text-[11px] font-semibold text-ink-mute transition-colors hover:border-emerald-500/40 hover:bg-emerald-500/10 hover:text-emerald-600"
              >
                <ArchiveRestore className="h-3.5 w-3.5" />
                Retrieve
              </button>
              <button
                onClick={() => setPruneFor(b)}
                title="Permanently delete — cannot be undone"
                className="inline-flex shrink-0 items-center gap-1.5 rounded-lg border border-border px-2.5 py-1.5 text-[11px] font-semibold text-ink-mute transition-colors hover:border-rose-500/40 hover:bg-rose-500/10 hover:text-rose-600"
              >
                <Trash2 className="h-3.5 w-3.5" />
                Delete
              </button>
            </li>
          ))}
        </ul>
      )}

      <ConfirmDialog
        open={!!restoreFor}
        title="Retrieve this batch?"
        message={
          restoreFor && (
            <>
              <span className="font-semibold text-foreground">{restoreFor.candidate_count}</span>{" "}
              candidate{restoreFor.candidate_count === 1 ? "" : "s"} tagged{" "}
              <span className="font-semibold text-foreground">
                {restoreFor.source ?? NO_SOURCE_LABEL}
              </span>{" "}
              will reappear on Dashboard, Candidates, and Mailbox.
            </>
          )
        }
        confirmLabel="Retrieve batch"
        pendingLabel="Retrieving…"
        pending={restore.isPending}
        onCancel={() => setRestoreFor(null)}
        onConfirm={() => restoreFor && restore.mutate(restoreFor.source)}
      />

      <ConfirmDialog
        open={!!pruneFor}
        tone="destructive"
        title="Permanently delete this batch?"
        message={
          pruneFor && (
            <>
              <span className="font-semibold text-foreground">{pruneFor.candidate_count}</span>{" "}
              candidate{pruneFor.candidate_count === 1 ? "" : "s"} tagged{" "}
              <span className="font-semibold text-foreground">
                {pruneFor.source ?? NO_SOURCE_LABEL}
              </span>{" "}
              — including their resume files — will be permanently deleted. This cannot be undone.
            </>
          )
        }
        confirmLabel="Delete permanently"
        pendingLabel="Deleting…"
        pending={prune.isPending}
        onCancel={() => setPruneFor(null)}
        onConfirm={() => pruneFor && prune.mutate(pruneFor.source)}
      />
    </div>
  );
}

// ── System Cleanup — full database wipe, QA-only, Admin-only ───────────────

function SystemCleanupTab() {
  const queryClient = useQueryClient();
  const { data: info } = useQuery({
    queryKey: ["system-wipe-info"],
    queryFn: async () => (await systemResetService.info()).data,
  });
  const [confirmStep, setConfirmStep] = useState(false);
  const [challengeOpen, setChallengeOpen] = useState(false);
  const [typed, setTyped] = useState("");
  const [result, setResult] = useState<{ tables: number; files: number } | null>(null);

  const wipe = useMutation({
    mutationFn: (confirm: string) => systemResetService.wipe(confirm),
    onSuccess: (res) => {
      setChallengeOpen(false);
      setTyped("");
      setResult({ tables: res.data.tables_truncated, files: res.data.object_store_files_removed });
      // A wipe affects nearly every query in the app — invalidate everything
      // rather than hand-picking keys that will inevitably miss one.
      queryClient.invalidateQueries();
    },
  });

  const allowed = info?.allowed ?? false;
  const phrase = info?.confirm_phrase ?? "";
  const matches = typed === phrase;

  return (
    <div className="px-5 py-4">
      <div className="flex items-start gap-3 rounded-xl border border-rose-500/30 bg-rose-500/5 px-4 py-3.5">
        <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-rose-500" />
        <div className="min-w-0 text-xs leading-relaxed text-ink-mute">
          <p className="font-semibold text-foreground">This permanently deletes ALL data.</p>
          <p className="mt-1">
            Every candidate, email, round, archive, review-queue item, and audit-log entry is
            wiped and ID numbering resets — for reloading fresh test data in QA. Login accounts
            and system settings (source tags, column config, …) are preserved.
          </p>
          {!allowed && (
            <p className="mt-2 font-semibold text-rose-600">
              Disabled here — only available when the server is configured as a QA environment
              (APP_ENV=qa).
            </p>
          )}
        </div>
      </div>

      <button
        onClick={() => setConfirmStep(true)}
        disabled={!allowed}
        className="mt-4 inline-flex items-center gap-1.5 rounded-lg border border-rose-500/40 bg-rose-500/10 px-3 py-1.5 text-xs font-semibold text-rose-600 transition-colors hover:bg-rose-500/20 disabled:cursor-not-allowed disabled:opacity-40"
      >
        <Trash2 className="h-3.5 w-3.5" />
        Clean up database
      </button>

      {result && (
        <p className="mt-3 text-[11px] text-ink-mute">
          Done — {result.tables} tables truncated, {result.files} stored file
          {result.files === 1 ? "" : "s"} removed.
        </p>
      )}

      {/* Step 1 — plain "are you sure", same as any other destructive action. */}
      <ConfirmDialog
        open={confirmStep}
        tone="destructive"
        title="Wipe the entire database?"
        message="Every candidate, email, round, and log entry will be gone. This cannot be undone. You'll be asked to confirm once more."
        confirmLabel="Continue"
        onCancel={() => setConfirmStep(false)}
        onConfirm={() => {
          setConfirmStep(false);
          setChallengeOpen(true);
        }}
      />

      {/* Step 2 — typed challenge: retype the database name exactly. No amount
          of accidental clicking can trigger this by itself. */}
      {challengeOpen && (
        <div
          className="fixed inset-0 z-[60] flex items-center justify-center bg-foreground/50 p-4 backdrop-blur-sm"
          onClick={() => {
            setChallengeOpen(false);
            setTyped("");
          }}
        >
          <div
            className="w-full max-w-sm rounded-2xl border border-border bg-card p-5 shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start gap-3">
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-rose-500/10 text-rose-600">
                <ShieldAlert className="h-4.5 w-4.5" />
              </span>
              <div className="min-w-0">
                <h3 className="text-sm font-bold text-foreground">Last check</h3>
                <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                  Type <span className="font-mono font-semibold text-foreground">{phrase}</span> below
                  to confirm you want to wipe this database.
                </p>
              </div>
            </div>
            <input
              autoFocus
              value={typed}
              onChange={(e) => setTyped(e.target.value)}
              placeholder={phrase}
              className="mt-3 w-full rounded-lg border border-border bg-secondary px-3 py-2 font-mono text-sm text-foreground placeholder:text-muted-foreground focus:border-rose-500/50 focus:outline-none"
            />
            <div className="mt-5 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => {
                  setChallengeOpen(false);
                  setTyped("");
                }}
                className="rounded-lg border border-border px-3.5 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-secondary"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => wipe.mutate(typed)}
                disabled={!matches || wipe.isPending}
                className="inline-flex items-center gap-1.5 rounded-lg bg-rose-600 px-3.5 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-rose-700 disabled:opacity-40"
              >
                {wipe.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RotateCcw className="h-3.5 w-3.5" />}
                {wipe.isPending ? "Wiping…" : "Wipe now"}
              </button>
            </div>
            {wipe.isError && (
              <p className="mt-2 text-[11px] text-rose-500">
                {(wipe.error as { response?: { data?: { detail?: string } } })?.response?.data?.detail ??
                  "Wipe failed — nothing was changed."}
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
