import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Clock, FileText, Loader2, Tag, Trash2 } from "lucide-react";
import { intakeService, type PendingItem } from "@/services/intake";
import { cn } from "@/lib/utils";

// Files added manually via the upload button that are STAGED and waiting for the next
// pipeline run. Each can be discarded (removed from the queue) before it's processed.
// Run the pipeline from the PipelinePanel above; processed items leave this list.
export default function UploadQueuePanel() {
  const queryClient = useQueryClient();

  const { data, isLoading } = useQuery({
    queryKey: ["intake-pending"],
    queryFn: async () => (await intakeService.listPending()).data,
  });
  const items = data?.items ?? [];

  const discard = useMutation({
    mutationFn: (eId: string) => intakeService.discardPending(eId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["intake-pending"] });
      queryClient.invalidateQueries({ queryKey: ["emails"] });
    },
  });

  // Nothing staged → hide the panel entirely (keeps the Mailbox uncluttered).
  if (!isLoading && items.length === 0) return null;

  return (
    <div className="surface overflow-hidden">
      <div className="flex items-center gap-2.5 border-b border-border px-5 py-3">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-500/10">
          <Clock className="h-4 w-4 text-blue-500" />
        </div>
        <div className="min-w-0 flex-1">
          <h2 className="text-sm font-semibold text-ink">Upload queue</h2>
          <p className="text-[11px] text-ink-mute">
            Manually uploaded files waiting for the next pipeline run — run it from the panel above.
          </p>
        </div>
        <span className="shrink-0 rounded-full border border-blue-500/30 bg-blue-500/10 px-2.5 py-0.5 text-xs font-bold text-blue-600 tnum">
          {items.length}
        </span>
      </div>

      {isLoading ? (
        <div className="flex items-center gap-2 px-5 py-6 text-sm text-ink-mute">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading queue…
        </div>
      ) : (
        <ul className="divide-y divide-border">
          {items.map((item) => (
            <QueueRow
              key={item.e_id}
              item={item}
              busy={discard.isPending}
              onDiscard={() => discard.mutate(item.e_id)}
            />
          ))}
        </ul>
      )}
    </div>
  );
}

function QueueRow({
  item,
  busy,
  onDiscard,
}: {
  item: PendingItem;
  busy: boolean;
  onDiscard: () => void;
}) {
  const fileLabel =
    item.attachments.length === 0
      ? item.subject || item.e_id
      : item.attachments.length === 1
        ? item.attachments[0]
        : `${item.attachments[0]} +${item.attachments.length - 1} more`;
  return (
    <li className="flex items-center gap-3 px-5 py-3">
      <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-secondary">
        <FileText className="h-4 w-4 text-ink-mute" />
      </div>
      <div className="min-w-0 flex-1">
        <div className="truncate text-sm font-medium text-ink">{fileLabel}</div>
        <div className="truncate text-[11px] text-ink-mute">
          {item.e_id}
          {item.received_date ? ` · ${item.received_date}` : ""}
        </div>
      </div>
      {item.candidate_source && (
        <span
          title="Source tag attached to this batch"
          className="inline-flex shrink-0 items-center gap-1 rounded-full border border-border bg-secondary px-2 py-0.5 text-[10px] font-semibold text-ink-mute"
        >
          <Tag className="h-2.5 w-2.5" />
          {item.candidate_source}
        </span>
      )}
      <span
        className={cn(
          "shrink-0 rounded-full border px-2 py-0.5 text-[10px] font-semibold",
          "border-blue-500/30 bg-blue-500/10 text-blue-600"
        )}
      >
        Queued
      </span>
      <button
        onClick={onDiscard}
        disabled={busy}
        title="Remove this file from the queue (it won't be processed)"
        className="flex shrink-0 items-center gap-1 rounded-lg border border-border px-2 py-1 text-[11px] font-semibold text-ink-mute transition-colors hover:border-rose-500/40 hover:bg-rose-500/10 hover:text-rose-600 disabled:opacity-50"
      >
        {busy ? <Loader2 className="h-3 w-3 animate-spin" /> : <Trash2 className="h-3 w-3" />}
        Discard
      </button>
    </li>
  );
}
