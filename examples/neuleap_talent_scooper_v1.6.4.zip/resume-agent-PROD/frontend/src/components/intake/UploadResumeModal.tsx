import { useEffect, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  UploadCloud,
  X,
  Loader2,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Clock,
  Plus,
} from "lucide-react";
import { intakeService, ACCEPTED_UPLOAD_EXT } from "@/services/intake";
import { sourceTagsService } from "@/services/sourceTags";
import { cn } from "@/lib/utils";

// Per-type upload size caps (MB). Mirrors the backend defaults in app/mail_config.py
// (MAX_UPLOAD_BYTES) — the server stays the source of truth; this is a pre-upload guard
// so an over-limit file is caught before it's queued only to FAIL in the pipeline.
const MAX_UPLOAD_MB: Record<string, number> = {
  pdf: 10,
  docx: 25,
  doc: 25,
  jpg: 10,
  jpeg: 10,
  png: 10,
  zip: 100,
  xlsx: 25,
};
const DEFAULT_MAX_MB = 25;
const MB = 1024 * 1024;

function extOf(name: string): string {
  const i = name.lastIndexOf(".");
  return i >= 0 ? name.slice(i + 1).toLowerCase() : "";
}

function limitMbFor(name: string): number {
  return MAX_UPLOAD_MB[extOf(name)] ?? DEFAULT_MAX_MB;
}

function formatSize(bytes: number): string {
  return bytes >= MB ? `${(bytes / MB).toFixed(1)} MB` : `${(bytes / 1024).toFixed(1)} KB`;
}

interface Props {
  open: boolean;
  onClose: () => void;
  onUploaded?: () => void;
}

type Phase = "idle" | "staging" | "queued" | "error";

export default function UploadResumeModal({ open, onClose, onUploaded }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  // Mandatory — attached to every candidate this batch produces (filterable on
  // the Dashboard). Kept across "Upload another" so a multi-file batch from the
  // same source doesn't need retyping; cleared only when the modal fully closes.
  const [source, setSource] = useState("");
  const [sourceOpen, setSourceOpen] = useState(false);
  const sourceBoxRef = useRef<HTMLDivElement>(null);
  const [dragOver, setDragOver] = useState(false);
  const [phase, setPhase] = useState<Phase>("idle");
  const [error, setError] = useState<string | null>(null);

  // Known sources for the typeahead — registered social-post tags (see
  // RegisterSourceTagModal) plus any distinct source recruiters have typed on
  // past uploads. Read-only here; this modal never creates a registered tag.
  const { data: knownSources = [] } = useQuery({
    queryKey: ["source-tags"],
    queryFn: async () => (await sourceTagsService.list()).data,
    enabled: open,
    select: (data) => Array.from(new Set(data.tags.map((t) => t.label))),
  });

  // Close the suggestion list on an outside click.
  useEffect(() => {
    if (!sourceOpen) return;
    const onDown = (e: MouseEvent) => {
      if (sourceBoxRef.current && !sourceBoxRef.current.contains(e.target as Node)) setSourceOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [sourceOpen]);

  if (!open) return null;

  const sourceQuery = source.trim().toLowerCase();
  const sourceMatches = knownSources.filter((s) => s.toLowerCase().includes(sourceQuery));
  // The typed text is only offered as its own "create" row when it isn't
  // already an exact match for a known source (no point suggesting a duplicate).
  const showCustomRow = sourceQuery.length > 0 && !knownSources.some((s) => s.toLowerCase() === sourceQuery);

  const resetFile = () => {
    setFile(null);
    setPhase("idle");
    setError(null);
  };

  const handleClose = () => {
    resetFile();
    setSource("");
    onClose();
  };

  // Per-type size pre-check: which limit applies and whether the file is over it.
  const limitMb = file ? limitMbFor(file.name) : 0;
  const oversize = !!file && file.size > limitMb * MB;
  const sourceMissing = !source.trim();

  const handleUpload = async () => {
    if (!file || oversize || sourceMissing) return;
    setError(null);
    setPhase("staging");
    try {
      // Queue only — the upload is added to the queue, not processed now.
      // The next pipeline run (manual or the daily scheduled run) processes it.
      await intakeService.stageUpload(file, source.trim());
      setPhase("queued");
      onUploaded?.();
    } catch (e: unknown) {
      const detail =
        (e as { response?: { data?: { detail?: string } } })?.response?.data?.detail ??
        (e as { message?: string })?.message ??
        "Upload failed";
      setError(String(detail));
      setPhase("error");
    }
  };

  const busy = phase === "staging";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/40 backdrop-blur-sm p-4">
      <div className="glass-panel w-full max-w-lg rounded-2xl shadow-xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-border px-5 py-4">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl gradient-brand">
              <UploadCloud className="h-4.5 w-4.5 text-white" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-foreground">Add to Intake queue</h2>
              <p className="text-[11px] text-muted-foreground">
                Staged as a direct mail · processed on the next pipeline run
              </p>
            </div>
          </div>
          <button
            onClick={handleClose}
            disabled={busy}
            className="rounded-lg p-1.5 text-muted-foreground hover:bg-secondary hover:text-foreground disabled:opacity-40"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="space-y-4 p-5">
          {(phase === "idle" || phase === "error" || phase === "staging") && (
            <>
              {/* Source — mandatory, attached to every candidate this batch produces.
                  Typeahead: typing always offers "Use '<text>'" first (create a new,
                  ad-hoc source), then any registered/previously-used source it matches. */}
              <div ref={sourceBoxRef} className="relative space-y-1.5">
                <label className="text-xs font-medium text-foreground">
                  Source <span className="text-destructive">*</span>
                </label>
                <input
                  type="text"
                  value={source}
                  onChange={(e) => {
                    setSource(e.target.value);
                    setSourceOpen(true);
                  }}
                  onFocus={() => setSourceOpen(true)}
                  disabled={busy}
                  placeholder="e.g. LinkedIn, Naukri, Referral - Jane, Job Fair Feb 2026"
                  className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm text-foreground outline-none focus:border-primary/50 disabled:opacity-60"
                />
                <p className="text-[11px] text-muted-foreground">
                  Attached to every candidate extracted from this batch — filterable later on the Dashboard.
                </p>

                {sourceOpen && (showCustomRow || sourceMatches.length > 0) && (
                  <div className="absolute left-0 right-0 top-full z-10 mt-1 max-h-52 overflow-auto rounded-lg border border-border bg-card p-1 shadow-lg">
                    {showCustomRow && (
                      <button
                        type="button"
                        onClick={() => setSourceOpen(false)}
                        className="flex w-full items-center gap-2 rounded-md px-2.5 py-1.5 text-left text-xs text-foreground transition-colors hover:bg-secondary"
                      >
                        <Plus className="h-3.5 w-3.5 shrink-0 text-primary" />
                        Use &ldquo;{source.trim()}&rdquo;
                      </button>
                    )}
                    {sourceMatches.map((s) => (
                      <button
                        key={s}
                        type="button"
                        onClick={() => {
                          setSource(s);
                          setSourceOpen(false);
                        }}
                        className="flex w-full items-center gap-2 truncate rounded-md px-2.5 py-1.5 text-left text-xs text-foreground transition-colors hover:bg-secondary"
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Dropzone */}
              <div
                onClick={() => !busy && inputRef.current?.click()}
                onDragOver={(e) => {
                  e.preventDefault();
                  setDragOver(true);
                }}
                onDragLeave={() => setDragOver(false)}
                onDrop={(e) => {
                  e.preventDefault();
                  setDragOver(false);
                  const f = e.dataTransfer.files?.[0];
                  if (f) setFile(f);
                }}
                className={cn(
                  "flex cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed px-6 py-10 text-center transition-colors",
                  dragOver
                    ? "border-primary bg-primary/5"
                    : "border-border hover:border-primary/50 hover:bg-secondary/40"
                )}
              >
                <input
                  ref={inputRef}
                  type="file"
                  accept={ACCEPTED_UPLOAD_EXT}
                  className="hidden"
                  onChange={(e) => setFile(e.target.files?.[0] ?? null)}
                />
                {file ? (
                  <>
                    <FileText className={cn("h-7 w-7", oversize ? "text-amber-500" : "text-primary")} />
                    <span className="text-sm font-medium text-foreground">{file.name}</span>
                    <span className={cn("text-[11px]", oversize ? "text-amber-500" : "text-muted-foreground")}>
                      {formatSize(file.size)} · limit {limitMb} MB · click to change
                    </span>
                  </>
                ) : (
                  <>
                    <UploadCloud className="h-7 w-7 text-muted-foreground" />
                    <span className="text-sm font-medium text-foreground">
                      Drop a file or click to browse
                    </span>
                    <span className="text-[11px] text-muted-foreground">
                      PDF, DOCX, DOC · ZIP (many resumes) · XLSX (candidate sheet)
                    </span>
                    <span className="text-[10px] text-muted-foreground">
                      Max size — PDF/images 10 MB · DOCX/DOC/XLSX 25 MB · ZIP 100 MB
                    </span>
                  </>
                )}
              </div>

              <div className="flex items-start gap-2 rounded-lg border border-border bg-secondary/40 px-3 py-2 text-[11px] text-muted-foreground">
                <Clock className="mt-0.5 h-3.5 w-3.5 shrink-0 text-blue-500" />
                <span>
                  Uploads are <span className="font-medium text-foreground">queued</span>, not processed
                  immediately. They run on the next pipeline run (daily 3:30 AM IST) or when you click
                  <span className="font-medium text-foreground"> Run pipeline</span>.
                </span>
              </div>

              {oversize && file && (
                <div className="flex items-start gap-2 rounded-lg border border-amber-500/30 bg-amber-400/10 px-3 py-2 text-xs text-amber-600">
                  <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                  <span>
                    This {extOf(file.name).toUpperCase() || "file"} is{" "}
                    <span className="font-semibold">{formatSize(file.size)}</span>, over the{" "}
                    <span className="font-semibold">{limitMb} MB</span> limit for this file type. It
                    would be rejected by the pipeline — please choose a smaller file.
                  </span>
                </div>
              )}

              {error && (
                <div className="flex items-start gap-2 rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-xs text-destructive">
                  <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              <div className="flex justify-end gap-2 pt-1">
                <button
                  onClick={handleClose}
                  className="rounded-lg border border-border px-4 py-2 text-sm font-medium text-muted-foreground hover:bg-secondary"
                >
                  Cancel
                </button>
                <button
                  onClick={handleUpload}
                  disabled={!file || busy || oversize || sourceMissing}
                  title={sourceMissing ? "Enter a source before adding to the queue" : undefined}
                  className="btn-brand"
                >
                  {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <UploadCloud className="h-4 w-4" />}
                  {busy ? "Adding…" : "Add to queue"}
                </button>
              </div>
            </>
          )}

          {phase === "queued" && (
            <div className="space-y-4">
              <div className="flex flex-col items-center gap-2 py-2 text-center">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-blue-500/10">
                  <Clock className="h-6 w-6 text-blue-500" />
                </div>
                <div className="text-sm font-semibold text-foreground">Added to the queue</div>
                <p className="text-xs text-muted-foreground max-w-sm">
                  It now appears in <span className="font-medium text-foreground">Upload queue</span> on
                  the Mailbox page. Add more files, then run the pipeline from there when you're ready —
                  you can discard any file before it runs.
                </p>
              </div>

              <div className="flex justify-center gap-2 pt-1">
                <button
                  onClick={resetFile}
                  className="btn-brand"
                >
                  <UploadCloud className="h-4 w-4" /> Upload another
                </button>
                <button onClick={handleClose} className="rounded-lg border border-border px-4 py-2 text-sm font-medium text-foreground hover:bg-secondary">
                  <CheckCircle2 className="mr-1.5 inline h-4 w-4 text-emerald-500" /> Done
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
