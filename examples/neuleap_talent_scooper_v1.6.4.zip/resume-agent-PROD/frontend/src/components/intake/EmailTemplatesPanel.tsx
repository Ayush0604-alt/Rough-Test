import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ChevronDown, ChevronRight, Loader2, MailPlus, RotateCcw, Save, ShieldAlert } from "lucide-react";
import { settingsService, type EmailBaseTemplate } from "@/services/settings";
import { useAuth } from "@/context/AuthContext";
import { cn, apiErrorMessage } from "@/lib/utils";

/**
 * Email Base Templates — the per-NBA-key subject/body every generated email
 * draft STARTS from (app/services/email_templates.py + the JSON-backed
 * overrides in email_template_overrides.py). Editing here changes what
 * future drafts are built from; existing drafts are untouched. Same
 * collapsed-card pattern as the other Archives & Interview Slots panels.
 */
export default function EmailTemplatesPanel() {
  const { isAdmin } = useAuth();
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  // A warning POPUP gates every expand (same pattern as Batch Archive) —
  // these templates become REAL candidate-facing emails; collapsing resets
  // the ack so it re-prompts next time rather than being a one-off dismissal.
  const [warningAcked, setWarningAcked] = useState(false);
  const [editingKey, setEditingKey] = useState<string | null>(null);
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const collapse = () => {
    setOpen(false);
    setWarningAcked(false);
    setEditingKey(null);
  };

  const { data, isLoading } = useQuery({
    queryKey: ["email-base-templates"],
    queryFn: async () => (await settingsService.getEmailTemplates()).data,
    enabled: open && warningAcked,
  });

  const save = useMutation({
    mutationFn: (payload: { key: string; subject: string; body: string }) =>
      settingsService.saveEmailTemplate(payload),
    onSuccess: (_res, payload) => {
      queryClient.invalidateQueries({ queryKey: ["email-base-templates"] });
      setEditingKey(null);
      setError(null);
      setNotice(
        payload.subject || payload.body
          ? "Template saved — new drafts will start from it."
          : "Template reverted to the shipped default."
      );
      setTimeout(() => setNotice(null), 4000);
    },
    onError: (e) => setError(apiErrorMessage(e, "Couldn't save the template.")),
  });

  const startEdit = (t: EmailBaseTemplate) => {
    setEditingKey(t.key);
    setSubject(t.subject);
    setBody(t.body);
    setError(null);
    setNotice(null);
  };

  return (
    <div className="surface overflow-hidden">
      <button
        type="button"
        onClick={() => (open ? collapse() : setOpen(true))}
        className="flex w-full items-center gap-2.5 px-5 py-3 text-left transition-colors hover:bg-secondary/30"
      >
        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-sky-500/10">
          <MailPlus className="h-4 w-4 text-sky-500" />
        </div>
        <div className="min-w-0 flex-1">
          <h2 className="text-sm font-semibold text-ink">Email Base Templates</h2>
          <p className="text-[11px] text-ink-mute">
            The subject &amp; body each generated email draft starts from — per next-action type.
          </p>
        </div>
        {open ? (
          <ChevronDown className="h-4 w-4 shrink-0 text-ink-mute" />
        ) : (
          <ChevronRight className="h-4 w-4 shrink-0 text-ink-mute" />
        )}
      </button>

      {open && !warningAcked && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/40 p-4 backdrop-blur-sm"
          onClick={collapse}
        >
          <div
            className="w-full max-w-sm rounded-2xl border border-border bg-card p-5 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start gap-3">
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-amber-400/10 text-amber-500">
                <ShieldAlert className="h-4.5 w-4.5" />
              </span>
              <div className="min-w-0">
                <h3 className="text-sm font-bold text-foreground">
                  These templates become real candidate emails
                </h3>
                <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                  Every future draft for the matching next-action starts from this text — a typo,
                  wrong tone, or a broken{" "}
                  <span className="font-semibold text-foreground">[interview-slot-picker-link]</span>{" "}
                  placeholder goes out to real candidates once a draft is sent. Each template can be
                  reset to its shipped default at any time.
                </p>
              </div>
            </div>
            <div className="mt-5 flex justify-end gap-2">
              <button
                type="button"
                onClick={collapse}
                className="rounded-lg border border-border px-3.5 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-secondary"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => setWarningAcked(true)}
                className="inline-flex items-center gap-1.5 rounded-lg bg-amber-500 px-3.5 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-amber-600"
              >
                <ShieldAlert className="h-3.5 w-3.5" /> I understand, continue
              </button>
            </div>
          </div>
        </div>
      )}

      {open && warningAcked && (
        <div className="border-t border-border px-5 py-4">
          {isLoading || !data ? (
            <div className="flex items-center gap-2 py-4 text-xs text-ink-mute">
              <Loader2 className="h-4 w-4 animate-spin" /> Loading templates…
            </div>
          ) : (
            <>
              <p className="mb-3 text-[11px] text-ink-mute">
                Placeholders:{" "}
                {data.placeholders.map((p) => (
                  <code key={p} className="selectable mr-1.5 rounded bg-secondary px-1.5 py-0.5 text-[10px] text-foreground">
                    {p}
                  </code>
                ))}
                — the slot-picker placeholder is swapped for the real link on the draft-review
                screen. Edits apply to FUTURE drafts only; drafts already generated are untouched.
                {!isAdmin && " Editing is Admin-only."}
              </p>
              {notice && <p className="mb-2 text-[11px] font-medium text-emerald-600">{notice}</p>}
              <ul className="divide-y divide-border">
                {data.templates.map((t) => (
                  <li key={t.key} className="py-2.5">
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => (editingKey === t.key ? setEditingKey(null) : startEdit(t))}
                        className="flex min-w-0 flex-1 items-center gap-2 text-left"
                      >
                        <ChevronRight
                          className={cn(
                            "h-3.5 w-3.5 shrink-0 text-ink-mute transition-transform",
                            editingKey === t.key && "rotate-90"
                          )}
                        />
                        <span className="truncate text-xs font-medium text-ink">{t.label}</span>
                        {t.is_customized && (
                          <span className="shrink-0 rounded-full border border-sky-500/30 bg-sky-500/10 px-1.5 py-px text-[9px] font-semibold text-sky-600">
                            customized
                          </span>
                        )}
                      </button>
                      <span className="hidden max-w-[40%] truncate text-[11px] text-ink-mute sm:block">
                        {t.subject}
                      </span>
                    </div>

                    {editingKey === t.key && (
                      <div className="mt-2.5 space-y-2 rounded-lg border border-border bg-secondary/30 p-3">
                        <div className="space-y-1">
                          <label className="text-[10px] font-semibold uppercase tracking-wide text-ink-mute">
                            Subject
                          </label>
                          <input
                            value={subject}
                            onChange={(e) => setSubject(e.target.value)}
                            disabled={!isAdmin}
                            className="w-full rounded-lg border border-border bg-background px-2.5 py-1.5 text-xs text-foreground outline-none focus:border-primary/50 disabled:opacity-60"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-semibold uppercase tracking-wide text-ink-mute">
                            Body
                          </label>
                          <textarea
                            value={body}
                            onChange={(e) => setBody(e.target.value)}
                            rows={8}
                            disabled={!isAdmin}
                            className="selectable w-full resize-y rounded-lg border border-border bg-background px-2.5 py-1.5 text-xs leading-relaxed text-foreground outline-none focus:border-primary/50 disabled:opacity-60"
                          />
                        </div>
                        {error && <p className="text-[11px] font-medium text-rose-500">{error}</p>}
                        {isAdmin && (
                          <div className="flex items-center justify-end gap-2">
                            <button
                              type="button"
                              onClick={() => save.mutate({ key: t.key, subject: "", body: "" })}
                              disabled={save.isPending || !t.is_customized}
                              title={
                                t.is_customized
                                  ? "Discard the customization and go back to the shipped default"
                                  : "Already the shipped default"
                              }
                              className="inline-flex items-center gap-1 rounded-lg border border-border px-2.5 py-1.5 text-[11px] font-semibold text-ink-mute transition-colors hover:text-ink disabled:cursor-not-allowed disabled:opacity-40"
                            >
                              <RotateCcw className="h-3 w-3" /> Reset to default
                            </button>
                            <button
                              type="button"
                              onClick={() => save.mutate({ key: t.key, subject, body })}
                              disabled={save.isPending || !subject.trim() || !body.trim()}
                              className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3 py-1.5 text-[11px] font-semibold text-white transition-colors hover:bg-primary/90 disabled:opacity-40"
                            >
                              {save.isPending ? (
                                <Loader2 className="h-3 w-3 animate-spin" />
                              ) : (
                                <Save className="h-3 w-3" />
                              )}
                              Save template
                            </button>
                          </div>
                        )}
                      </div>
                    )}
                  </li>
                ))}
              </ul>
            </>
          )}
        </div>
      )}
    </div>
  );
}
