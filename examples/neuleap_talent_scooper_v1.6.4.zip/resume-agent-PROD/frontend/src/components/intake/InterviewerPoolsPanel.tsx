// Mailbox → "Interviewer Timeslot Pools" — proactively blocks
// [PLACEHOLDER for NLi <round> pool-<id>] events on rostered interviewers'
// calendars (Settings → Interviewer Access → Round Interviewers) so
// candidates in that round can pick from a pre-reserved slot instead of a
// live per-candidate Graph lookup. See app.services.interview_pools.
import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  CalendarClock,
  CalendarPlus,
  Check,
  ChevronDown,
  ChevronRight,
  Copy,
  ExternalLink,
  Info,
  Plus,
  RefreshCw,
  Gauge,
  Trash2,
  Pencil,
  Loader2,
  Users2,
  X,
} from "lucide-react";
import {
  interviewPoolsService,
  type InterviewPool,
  type DayRule,
  type GatherResult,
  type SyncResult,
  type PoolDefaults,
  type RoundRuleOverride,
} from "@/services/interviewPools";
import { batchArchiveService } from "@/services/batchArchive";
import { ROUND_PRESETS } from "@/constants";
import { useConfirm } from "@/components/common/ConfirmProvider";
import { cn, apiErrorMessage } from "@/lib/utils";
import { useSampleDataFilter } from "@/lib/source";
import ConfirmDialog from "@/components/common/ConfirmDialog";

const NO_SOURCE_LABEL = "No source";

// The pool gathers TODAY's slots starting at NOW rounded UP to the next half hour
// (:00/:30) — mirror that in the form so the operator sees the effective start time
// when the range starts today. Returns null when the start date isn't today.
function nextHalfHour(): Date {
  const d = new Date();
  d.setSeconds(0, 0);
  const m = d.getMinutes();
  if (m === 0 || m === 30) return d;
  if (m < 30) { d.setMinutes(30); return d; }
  d.setMinutes(0);
  d.setHours(d.getHours() + 1);
  return d;
}
function startTimeHint(rangeStart: string): string | null {
  const todayStr = new Date().toISOString().split("T")[0];
  if (rangeStart !== todayStr) return null;
  return nextHalfHour().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}
const DAY_KEYS: { key: string; label: string }[] = [
  { key: "mon", label: "Mon" }, { key: "tue", label: "Tue" }, { key: "wed", label: "Wed" },
  { key: "thu", label: "Thu" }, { key: "fri", label: "Fri" }, { key: "sat", label: "Sat" },
  { key: "sun", label: "Sun" },
];
const DAY_RULE_LABEL: Record<DayRule, string> = {
  full: "Full day",
  full_extended: "Full day extended (8-21)",
  early_morning: "Early morning (8-10)",
  first_half: "AM (10-14)",
  second_half: "PM (14-18)",
  late_evening: "Late evening (18-21)",
  none: "None",
};

function fmtDate(s: string): string {
  const d = new Date(s);
  return Number.isNaN(d.getTime()) ? s : d.toLocaleDateString(undefined, { day: "2-digit", month: "short", year: "numeric" });
}

function fmtDateTime(s: string): string {
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return s;
  return `${d.toLocaleDateString(undefined, { day: "2-digit", month: "short" })}, ${d.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" })}`;
}

const SLOT_STATUS_CLS: Record<string, string> = {
  open: "border-emerald-500/30 bg-emerald-500/10 text-emerald-600",
  booked: "border-primary/30 bg-primary/10 text-primary",
  removed_by_interviewer: "border-amber-500/30 bg-amber-500/10 text-amber-600",
  cancelled: "border-border bg-secondary/40 text-muted-foreground",
};
const SLOT_STATUS_LABEL: Record<string, string> = {
  open: "Open", booked: "Booked", removed_by_interviewer: "Removed", cancelled: "Cancelled",
};

export default function InterviewerPoolsPanel() {
  const [open, setOpen] = useState(false);
  const [infoAcked, setInfoAcked] = useState(false);

  const expand = () => setOpen(true);
  const collapse = () => {
    setOpen(false);
    setInfoAcked(false);
  };

  return (
    <div className="surface overflow-hidden">
      <button
        type="button"
        onClick={() => (open ? collapse() : expand())}
        className="flex w-full items-center gap-2.5 px-5 py-3 text-left transition-colors hover:bg-secondary/30"
      >
        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-sky-500/10">
          <CalendarClock className="h-4 w-4 text-sky-500" />
        </div>
        <div className="min-w-0 flex-1">
          <h2 className="text-sm font-semibold text-ink">Interviewer Timeslot Pools</h2>
          <p className="text-[11px] text-ink-mute">
            Pre-reserve interview slots on interviewers' calendars for a campaign, sized to candidate volume.
          </p>
        </div>
        {open ? (
          <ChevronDown className="h-4 w-4 shrink-0 text-ink-mute" />
        ) : (
          <ChevronRight className="h-4 w-4 shrink-0 text-ink-mute" />
        )}
      </button>

      {open && !infoAcked && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/40 p-4 backdrop-blur-sm"
          onClick={collapse}
        >
          <div
            className="w-full max-w-md rounded-2xl border border-border bg-card p-5 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start gap-3">
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-sky-500/10 text-sky-600">
                <Info className="h-4.5 w-4.5" />
              </span>
              <div className="min-w-0">
                <h3 className="text-sm font-bold text-foreground">What this section does</h3>
                <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                  A <span className="font-semibold text-foreground">pool</span> is a capacity plan for one
                  campaign source + interview round over a date range. "Make placeholders" blocks new
                  placeholder events on the rostered interviewers' calendars — at least a 15-minute gap after
                  their real meetings, never more than a quarter of their day, on only the days/half-days you
                  allow. "Refresh slots available" doesn't create anything — it just pulls the latest status
                  of placeholders already blocked (did an interviewer delete or move one directly on their
                  own calendar?); this also happens automatically every 2 hours. Candidates in that round then
                  pick from these pre-reserved slots instead of a live calendar lookup. Interviewers can
                  review and adjust their own placeholders from their own
                  portal — nothing here books a candidate without their say.
                </p>
              </div>
            </div>
            <div className="mt-5 flex justify-end gap-2">
              <button
                type="button"
                onClick={collapse}
                className="rounded-lg border border-border px-3.5 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-secondary"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => setInfoAcked(true)}
                className="inline-flex items-center gap-1.5 rounded-lg bg-sky-500 px-3.5 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-sky-600"
              >
                Got it
              </button>
            </div>
          </div>
        </div>
      )}

      {open && infoAcked && (
        <div className="border-t border-border">
          <DefaultRulesSection />
          <PoolsList />
        </div>
      )}
    </div>
  );
}

// ── Default allocation rules ─────────────────────────────────────────────────

function DefaultRulesSection() {
  const [open, setOpen] = useState(false);
  const queryClient = useQueryClient();
  const confirm = useConfirm();
  const { data: defaults } = useQuery({
    queryKey: ["interview-pool-defaults"],
    queryFn: async () => (await interviewPoolsService.getDefaults()).data,
  });
  const save = useMutation({
    mutationFn: interviewPoolsService.saveDefaults,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["interview-pool-defaults"] }),
  });
  const revert = useMutation({
    mutationFn: interviewPoolsService.revertDefaults,
    onSuccess: ({ data }) => {
      queryClient.setQueryData(["interview-pool-defaults"], data);
      queryClient.invalidateQueries({ queryKey: ["interview-pool-defaults"] });
    },
  });
  const resetToDefault = async () => {
    if (
      await confirm({
        title: "Reset calculation controls?",
        message:
          "Discard your customizations and restore the shipped default gap, slot length, max-day %, weekly day windows, and funnel cuts?",
        confirmLabel: "Reset to defaults",
        danger: true,
      })
    ) {
      revert.mutate();
    }
  };

  if (!defaults) return null;

  const setDay = (key: string, value: DayRule) => {
    save.mutate({ ...defaults, days_allowed: { ...defaults.days_allowed, [key]: value } });
  };
  return (
    <div className="border-b border-border px-5 py-3">
      <button onClick={() => setOpen((v) => !v)} className="flex w-full items-center gap-2 text-left text-xs font-semibold text-ink">
        <ChevronDown className={cn("h-3.5 w-3.5 shrink-0 transition-transform", !open && "-rotate-90")} />
        Pool Calculation Controls
        <span className="ml-auto font-normal text-ink-mute">
          {defaults.gap_minutes}min gap · max {Math.round(defaults.max_day_fraction * 100)}% of day
        </span>
      </button>
      {open && (
        <div className="mt-3 space-y-3 pl-5">
          <div className="flex items-center justify-end">
            <button
              type="button"
              onClick={resetToDefault}
              disabled={revert.isPending || save.isPending}
              title="Discard customizations and restore the shipped default calculation rules"
              className="inline-flex items-center gap-1 rounded-lg border border-border/70 px-2 py-1 text-[11px] font-medium text-ink-mute transition-colors hover:border-primary/40 hover:text-primary disabled:opacity-50"
            >
              {revert.isPending ? <Loader2 className="h-3 w-3 animate-spin" /> : <RefreshCw className="h-3 w-3" />}
              Reset to defaults
            </button>
          </div>
          <div className="flex flex-wrap items-center gap-4">
            <label className="flex items-center gap-1.5 text-[11px] text-ink-mute">
              Gap after meetings (min)
              <input
                type="number"
                min={0}
                max={240}
                value={defaults.gap_minutes}
                onChange={(e) => save.mutate({ ...defaults, gap_minutes: Number(e.target.value) })}
                className="w-16 rounded-lg border border-border bg-secondary px-2 py-1 text-xs text-foreground"
              />
            </label>
            <label className="flex items-center gap-1.5 text-[11px] text-ink-mute">
              Max % of day locked
              <input
                type="number"
                min={5}
                max={100}
                value={Math.round(defaults.max_day_fraction * 100)}
                onChange={(e) => save.mutate({ ...defaults, max_day_fraction: Number(e.target.value) / 100 })}
                className="w-16 rounded-lg border border-border bg-secondary px-2 py-1 text-xs text-foreground"
              />
            </label>
            <label className="flex items-center gap-1.5 text-[11px] text-ink-mute">
              Slot length (min)
              <input
                type="number"
                min={10}
                max={240}
                step={5}
                value={defaults.slot_minutes}
                onChange={(e) => save.mutate({ ...defaults, slot_minutes: Number(e.target.value) })}
                className="w-16 rounded-lg border border-border bg-secondary px-2 py-1 text-xs text-foreground"
              />
            </label>
          </div>
          <div className="flex flex-wrap gap-2">
            {DAY_KEYS.map(({ key, label }) => (
              <div key={key} className="flex flex-col items-center gap-1">
                <span className="text-[10px] font-semibold uppercase tracking-wide text-ink-mute">{label}</span>
                <select
                  value={defaults.days_allowed[key] ?? "none"}
                  onChange={(e) => setDay(key, e.target.value as DayRule)}
                  className="rounded-lg border border-border bg-secondary px-1.5 py-1 text-[10px] text-foreground"
                >
                  {(Object.keys(DAY_RULE_LABEL) as DayRule[]).map((r) => (
                    <option key={r} value={r}>{DAY_RULE_LABEL[r]}</option>
                  ))}
                </select>
              </div>
            ))}
          </div>
          <FunnelSliders
            defaults={defaults}
            onSaveDefaults={(d) => save.mutate(d)}
            saving={save.isPending}
          />
        </div>
      )}
    </div>
  );
}

// The inline per-round override editor — rendered UNDER a funnel round row when
// that round's left-side toggle is expanded. Same controls as the global
// defaults (slot length, gap, day cap, day rules), pre-filled from the global
// values (or the round's own override), with Reset to default.
function RoundOverridePanel({
  round,
  defaults,
  onSave,
}: {
  round: string;
  defaults: PoolDefaults;
  onSave: (d: PoolDefaults) => void;
}) {
  const overrides = defaults.round_overrides ?? {};
  const ov = overrides[round] ?? {};
  const hasOv = Object.keys(ov).length > 0;
  const e = {
    slot_minutes: ov.slot_minutes ?? defaults.slot_minutes,
    gap_minutes: ov.gap_minutes ?? defaults.gap_minutes,
    max_day_fraction: ov.max_day_fraction ?? defaults.max_day_fraction,
    days_allowed: { ...defaults.days_allowed, ...(ov.days_allowed ?? {}) },
  };
  const setOverride = (patch: Partial<RoundRuleOverride>) =>
    onSave({ ...defaults, round_overrides: { ...overrides, [round]: { ...ov, ...patch } } });
  const setOverrideDay = (dayKey: string, value: DayRule) =>
    onSave({
      ...defaults,
      round_overrides: {
        ...overrides,
        [round]: { ...ov, days_allowed: { ...(ov.days_allowed ?? {}), [dayKey]: value } },
      },
    });
  const resetRound = () => {
    const next = { ...overrides };
    delete next[round];
    onSave({ ...defaults, round_overrides: next });
  };

  return (
    <div className="ml-8 space-y-3 rounded-lg border border-border/60 bg-secondary/20 px-3 py-2.5">
      <div className="flex flex-wrap items-center gap-3">
        <label className="flex items-center gap-1.5 text-[11px] text-ink-mute">
          Gap (min)
          <input
            type="number"
            min={0}
            max={240}
            value={e.gap_minutes}
            onChange={(ev) => setOverride({ gap_minutes: Number(ev.target.value) })}
            className="w-16 rounded-lg border border-border bg-secondary px-2 py-1 text-xs text-foreground"
          />
        </label>
        <label className="flex items-center gap-1.5 text-[11px] text-ink-mute">
          Max % of day
          <input
            type="number"
            min={5}
            max={100}
            value={Math.round(e.max_day_fraction * 100)}
            onChange={(ev) => setOverride({ max_day_fraction: Number(ev.target.value) / 100 })}
            className="w-16 rounded-lg border border-border bg-secondary px-2 py-1 text-xs text-foreground"
          />
        </label>
        <label className="flex items-center gap-1.5 text-[11px] text-ink-mute">
          Slot (min)
          <input
            type="number"
            min={10}
            max={240}
            step={5}
            value={e.slot_minutes}
            onChange={(ev) => setOverride({ slot_minutes: Number(ev.target.value) })}
            className="w-16 rounded-lg border border-border bg-secondary px-2 py-1 text-xs text-foreground"
          />
        </label>
      </div>
      <div className="flex flex-wrap gap-2">
        {DAY_KEYS.map(({ key, label }) => (
          <div key={key} className="flex flex-col items-center gap-1">
            <span className="text-[10px] font-semibold uppercase tracking-wide text-ink-mute">{label}</span>
            <select
              value={e.days_allowed[key] ?? "none"}
              onChange={(ev) => setOverrideDay(key, ev.target.value as DayRule)}
              className="rounded-lg border border-border bg-secondary px-1.5 py-1 text-[10px] text-foreground"
            >
              {(Object.keys(DAY_RULE_LABEL) as DayRule[]).map((r) => (
                <option key={r} value={r}>{DAY_RULE_LABEL[r]}</option>
              ))}
            </select>
          </div>
        ))}
      </div>
      <div className="flex items-center justify-between">
        <span className="text-[10px] text-muted-foreground">
          {hasOv ? "This round overrides the defaults above." : "This round follows the defaults above."}
        </span>
        <button
          type="button"
          onClick={resetRound}
          disabled={!hasOv}
          className="inline-flex items-center gap-1.5 rounded-lg border border-border px-2.5 py-1 text-[10px] font-semibold text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground disabled:opacity-40"
        >
          <RefreshCw className="h-3 w-3" /> Reset to default
        </button>
      </div>
    </div>
  );
}

// Simple funnel editor: one slider per round ("% filtered out here"), a live
// funnel of bars for 100 inbound candidates, and a Calculate & save button
// that persists the sliders and re-targets every pool.
const FUNNEL_STAGE_COLOR: Record<string, string> = {
  Screening: "#8b5cf6",
  "Round 1": "#0ea5e9",
  "Round 2": "#f59e0b",
  "Round 3": "#f97316",
  Final: "#10b981",
};

// hex + alpha → rgba, same helper the Process Flow page uses for its glassy
// stage skins, so the funnel bars read as the same frosted material.
function funnelHexA(hex: string, alpha: number): string {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${alpha})`;
}

function FunnelSliders({
  defaults,
  onSaveDefaults,
  saving,
}: {
  defaults: PoolDefaults;
  onSaveDefaults: (d: PoolDefaults) => void;
  saving: boolean;
}) {
  const saved = defaults.funnel_filter_pct;
  const [draft, setDraft] = useState<Record<string, number>>(() => ({ ...saved }));
  const [dirty, setDirty] = useState(false);
  // Which round's per-round override editor is expanded (left-side toggle).
  const [openRound, setOpenRound] = useState<string | null>(null);
  useEffect(() => {
    if (!dirty) setDraft({ ...saved });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [JSON.stringify(saved)]);

  const overrides = defaults.round_overrides ?? {};
  const START = 100;
  let remaining = START;
  const rows: { label: string; value: number; pct: number | null; color: string }[] = [];
  for (const r of ROUND_PRESETS) {
    const pct = draft[r] ?? 0;
    rows.push({ label: r, value: Math.ceil(remaining), pct, color: FUNNEL_STAGE_COLOR[r] ?? "#64748b" });
    remaining = remaining * (1 - pct / 100);
  }
  rows.push({ label: "Clear Final", value: Math.ceil(remaining), pct: null, color: "#2563eb" });

  return (
    <div>
      <span className="mb-1.5 block text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
        Funnel — slide each round's cut, then Calculate · toggle a round to override its allocation rules
      </span>
      <div className="rounded-2xl border border-border/50 bg-card/40 px-3 py-3 backdrop-blur-md dark:bg-card/30">
        <div className="space-y-2">
          {rows.map((row) => {
            const isRound = row.pct != null; // "Clear Final" has no override toggle
            const hasOv = isRound && !!overrides[row.label] && Object.keys(overrides[row.label]).length > 0;
            const open = openRound === row.label;
            return (
              <div key={row.label}>
                <div className="flex items-center gap-2">
                  {/* Left-side per-round override toggle (blank spacer for Clear Final). */}
                  {isRound ? (
                    <button
                      type="button"
                      onClick={() => setOpenRound(open ? null : row.label)}
                      title={`${open ? "Hide" : "Show"} ${row.label} allocation-rule override`}
                      className={cn(
                        "flex h-5 w-5 shrink-0 items-center justify-center rounded-md border transition-colors",
                        hasOv
                          ? "border-primary/50 bg-primary/10 text-primary"
                          : "border-border/60 text-muted-foreground hover:bg-secondary",
                      )}
                    >
                      <ChevronDown className={cn("h-3.5 w-3.5 transition-transform", open && "rotate-180")} />
                    </button>
                  ) : (
                    <span className="h-5 w-5 shrink-0" />
                  )}
                  <span className="w-20 shrink-0 truncate text-right text-[10px] font-medium text-ink-mute">
                    {row.label}
                    {hasOv && <span className="ml-1 text-primary" title="Overridden">•</span>}
                  </span>
                  <div className="flex w-44 flex-1 justify-center sm:w-56">
                    <div
                      className="flex h-6 items-center justify-center rounded-full border backdrop-blur-md transition-all duration-300"
                      style={{
                        width: `${Math.max(10, (row.value / START) * 100)}%`,
                        backgroundImage: `linear-gradient(155deg, ${funnelHexA(row.color, 0.34)}, ${funnelHexA(row.color, 0.12)})`,
                        borderColor: funnelHexA(row.color, 0.55),
                      }}
                      title={`${row.label}: ${row.value} of ${START}`}
                    >
                      <span className="text-[10px] font-extrabold tabular-nums text-ink">{row.value}</span>
                    </div>
                  </div>
                  {row.pct == null ? (
                    <span className="w-40 shrink-0 text-[10px] font-semibold" style={{ color: FUNNEL_STAGE_COLOR.Final }}>
                      make it through everything
                    </span>
                  ) : (
                    <label className="flex w-40 shrink-0 items-center gap-1.5 text-[10px] text-ink-mute">
                      <input
                        type="range"
                        min={0}
                        max={100}
                        step={5}
                        value={row.pct}
                        onChange={(e) => {
                          setDirty(true);
                          setDraft((d) => ({ ...d, [row.label]: Number(e.target.value) }));
                        }}
                        className="h-1.5 w-24 cursor-pointer"
                        style={{ accentColor: row.color }}
                      />
                      <span className="tnum w-12 tabular-nums">cut {row.pct}%</span>
                    </label>
                  )}
                </div>
                {isRound && open && (
                  <div className="mt-1.5">
                    <RoundOverridePanel round={row.label} defaults={defaults} onSave={onSaveDefaults} />
                  </div>
                )}
              </div>
            );
          })}
        </div>
        <div className="mt-3 flex items-center justify-between gap-2 border-t border-border/40 pt-2.5">
          <p className="text-[10px] text-ink-mute/80">
            Bars show 100 inbound candidates flowing through. Fast-tracked candidates are added on
            top when a real pool computes its targets.
          </p>
          <button
            type="button"
            onClick={() => {
              onSaveDefaults({ ...defaults, funnel_filter_pct: draft });
              setDirty(false);
            }}
            disabled={saving || !dirty}
            className="inline-flex shrink-0 items-center gap-1.5 rounded-full bg-primary px-3.5 py-1.5 text-[11px] font-semibold text-primary-foreground shadow-sm transition-all hover:bg-primary/90 hover:shadow-md disabled:opacity-40 disabled:shadow-none"
          >
            {saving ? <Loader2 className="h-3 w-3 animate-spin" /> : <Gauge className="h-3 w-3" />}
            Calculate &amp; save
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Pool list + create form ─────────────────────────────────────────────────

function PoolsList() {
  const queryClient = useQueryClient();
  const { data: pools = [], isLoading } = useQuery({
    queryKey: ["interview-pools"],
    queryFn: async () => (await interviewPoolsService.list()).data,
  });
  const { data: liveBatches = [] } = useQuery({
    queryKey: ["batches-live"],
    queryFn: async () => (await batchArchiveService.listLive()).data.batches,
  });
  const sampleDataFilter = useSampleDataFilter();
  const [showCreate, setShowCreate] = useState(false);
  const [confirmFor, setConfirmFor] = useState<InterviewPool | null>(null);

  const sources = liveBatches
    .map((b) => b.source)
    .filter((s) => sampleDataFilter.visible || s !== sampleDataFilter.label);

  const archive = useMutation({
    mutationFn: (id: number) => interviewPoolsService.archive(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["interview-pools"] });
      setConfirmFor(null);
    },
  });

  return (
    <div className="px-5 py-4">
      <div className="mb-3 flex items-center justify-between">
        <span className="text-xs font-semibold text-ink-mute">
          {pools.length} pool{pools.length === 1 ? "" : "s"}
        </span>
        <button
          onClick={() => setShowCreate((v) => !v)}
          className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-card px-2.5 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-secondary"
        >
          <Plus className="h-3.5 w-3.5" /> New pool
        </button>
      </div>

      {showCreate && (
        <CreatePoolForm
          sources={sources}
          existingPools={pools}
          onCreated={() => {
            setShowCreate(false);
            queryClient.invalidateQueries({ queryKey: ["interview-pools"] });
          }}
        />
      )}

      {isLoading ? (
        <div className="flex items-center gap-2 py-6 text-xs text-ink-mute">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading pools…
        </div>
      ) : pools.length === 0 ? (
        <p className="py-6 text-center text-xs text-ink-mute">No pools yet — create one above.</p>
      ) : (
        <div className="space-y-3">
          {pools.map((p) => (
            <PoolCard key={p.id} pool={p} sources={sources} onArchive={() => setConfirmFor(p)} />
          ))}
        </div>
      )}

      <ConfirmDialog
        open={!!confirmFor}
        tone="destructive"
        title="Delete this pool?"
        message={
          confirmFor && (
            <>
              <span className="font-semibold text-foreground">{confirmFor.label}</span> will be removed from
              this list. Every still-open placeholder this pool has blocked on interviewers' calendars will be
              cancelled and deleted — slots a candidate has already booked are left alone.
            </>
          )
        }
        confirmLabel="Delete pool"
        pendingLabel="Deleting…"
        pending={archive.isPending}
        onCancel={() => setConfirmFor(null)}
        onConfirm={() => confirmFor && archive.mutate(confirmFor.id)}
      />
    </div>
  );
}

function CreatePoolForm({
  sources,
  existingPools,
  onCreated,
}: {
  sources: (string | null)[];
  // Live (non-archived) pools — ONE pool per source tag, so a source that
  // already has one can't get a second; the form flags it up front.
  existingPools: InterviewPool[];
  onCreated: () => void;
}) {
  const [sourceLabel, setSourceLabel] = useState<string>("");
  const [roundNames, setRoundNames] = useState<Set<string>>(new Set([ROUND_PRESETS[0]]));
  const [label, setLabel] = useState("");
  const [rangeStart, setRangeStart] = useState("");
  const [rangeEnd, setRangeEnd] = useState("");
  const [error, setError] = useState<string | null>(null);

  const toggleRound = (r: string) =>
    setRoundNames((prev) => {
      const next = new Set(prev);
      if (next.has(r)) next.delete(r);
      else next.add(r);
      return next;
    });

  const roundList = [...roundNames];
  const create = useMutation({
    mutationFn: () =>
      interviewPoolsService.create({
        source_label: sourceLabel || null,
        round_names: roundList,
        label: label.trim() || `${roundList.join(" + ")} — ${sourceLabel || NO_SOURCE_LABEL}`,
        range_start: rangeStart,
        range_end: rangeEnd,
      }),
    onSuccess: onCreated,
    onError: (e) =>
      setError(apiErrorMessage(e, "Couldn't create the pool — check the rounds/dates and try again.")),
  });

  // One live pool per source tag — surface the clash BEFORE the server 422s.
  const duplicatePool = existingPools.find((p) => (p.source_label ?? "") === sourceLabel);
  const canCreate =
    roundNames.size > 0 && rangeStart && rangeEnd && rangeEnd >= rangeStart && !duplicatePool;
  // A pool only ever gathers slots going forward — no point letting an admin
  // pick a start (or end) date that's already in the past.
  const todayStr = new Date().toISOString().split("T")[0];

  return (
    <div className="mb-4 rounded-xl border border-border bg-secondary/20 p-3">
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
        <select
          value={sourceLabel}
          onChange={(e) => setSourceLabel(e.target.value)}
          className="rounded-lg border border-border bg-secondary px-2 py-1.5 text-xs text-foreground"
        >
          <option value="">{NO_SOURCE_LABEL}</option>
          {sources.filter((s): s is string => !!s).map((s) => (
            <option key={s} value={s}>{s}</option>
          ))}
        </select>
        <input
          type="date"
          value={rangeStart}
          min={todayStr}
          onChange={(e) => {
            setRangeStart(e.target.value);
            if (rangeEnd && rangeEnd < e.target.value) setRangeEnd(e.target.value);
          }}
          className="rounded-lg border border-border bg-secondary px-2 py-1.5 text-xs text-foreground"
        />
        <input
          type="date"
          value={rangeEnd}
          min={rangeStart || todayStr}
          onChange={(e) => setRangeEnd(e.target.value)}
          className="rounded-lg border border-border bg-secondary px-2 py-1.5 text-xs text-foreground"
        />
      </div>

      <div className="mt-2">
        <span className="mb-1 block text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
          Rounds (each gathers its own slots within this pool)
        </span>
        <div className="flex flex-wrap gap-1.5">
          {ROUND_PRESETS.map((r) => {
            const active = roundNames.has(r);
            return (
              <button
                key={r}
                type="button"
                onClick={() => toggleRound(r)}
                className={cn(
                  "rounded-full border px-2.5 py-1 text-[11px] font-medium transition-colors",
                  active
                    ? "border-primary bg-primary/10 text-primary"
                    : "border-border text-muted-foreground hover:text-foreground"
                )}
              >
                {r}
              </button>
            );
          })}
        </div>
      </div>

      <input
        value={label}
        onChange={(e) => setLabel(e.target.value)}
        placeholder="Label (optional — auto-generated if left blank)"
        className="mt-2 w-full rounded-lg border border-border bg-secondary px-2 py-1.5 text-xs text-foreground placeholder:text-muted-foreground"
      />
      {duplicatePool && (
        <p className="mt-2 text-[10px] font-medium text-amber-600">
          "{sourceLabel || NO_SOURCE_LABEL}" already has a pool ("{duplicatePool.label}") — one pool
          per source tag. Edit that pool's rounds/dates, or archive it first.
        </p>
      )}
      {error && <p className="mt-2 text-[10px] text-red-400">{error}</p>}
      <button
        onClick={() => { setError(null); create.mutate(); }}
        disabled={!canCreate || create.isPending}
        className="mt-2 inline-flex items-center gap-1.5 rounded-lg bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground transition-colors hover:bg-primary/90 disabled:opacity-50"
      >
        {create.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Plus className="h-3.5 w-3.5" />}
        Create pool
      </button>
    </div>
  );
}

function EditPoolForm({
  pool,
  sources,
  onSaved,
  onCancel,
}: {
  pool: InterviewPool;
  sources: (string | null)[];
  onSaved: () => void;
  onCancel: () => void;
}) {
  const [sourceLabel, setSourceLabel] = useState<string>(pool.source_label ?? "");
  const [roundNames, setRoundNames] = useState<Set<string>>(new Set(pool.round_names));
  const [label, setLabel] = useState(pool.label);
  const [rangeStart, setRangeStart] = useState(pool.range_start);
  const [rangeEnd, setRangeEnd] = useState(pool.range_end);
  const [error, setError] = useState<string | null>(null);

  // Rounds already on this pool might include custom round types not in the
  // preset list (e.g. HR/Onboarding) — keep them selectable so editing other
  // fields never silently drops a round this pool already covers.
  const roundChips = Array.from(new Set([...ROUND_PRESETS, ...pool.round_names]));

  const toggleRound = (r: string) =>
    setRoundNames((prev) => {
      const next = new Set(prev);
      if (next.has(r)) next.delete(r);
      else next.add(r);
      return next;
    });

  const roundList = [...roundNames];
  const save = useMutation({
    mutationFn: () =>
      interviewPoolsService.update(pool.id, {
        source_label: sourceLabel || null,
        round_names: roundList,
        label: label.trim() || `${roundList.join(" + ")} — ${sourceLabel || NO_SOURCE_LABEL}`,
        range_start: rangeStart,
        range_end: rangeEnd,
      }),
    onSuccess: onSaved,
    onError: () => setError("Couldn't save changes — check the rounds/dates and try again."),
  });

  const droppedRounds = pool.round_names.filter((r) => !roundNames.has(r));
  const rangeShrunk = rangeStart > pool.range_start || rangeEnd < pool.range_end;
  const canSave = roundNames.size > 0 && rangeStart && rangeEnd && rangeEnd >= rangeStart;
  const todayStr = new Date().toISOString().split("T")[0];

  return (
    <div className="mt-3 space-y-3">
    <div className="rounded-xl border border-primary/30 bg-primary/5 p-3">
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
        <select
          value={sourceLabel}
          onChange={(e) => setSourceLabel(e.target.value)}
          className="rounded-lg border border-border bg-secondary px-2 py-1.5 text-xs text-foreground"
        >
          <option value="">{NO_SOURCE_LABEL}</option>
          {sources.filter((s): s is string => !!s).map((s) => (
            <option key={s} value={s}>{s}</option>
          ))}
        </select>
        <input
          type="date"
          value={rangeStart}
          min={todayStr}
          onChange={(e) => {
            setRangeStart(e.target.value);
            if (rangeEnd && rangeEnd < e.target.value) setRangeEnd(e.target.value);
          }}
          className="rounded-lg border border-border bg-secondary px-2 py-1.5 text-xs text-foreground"
        />
        <input
          type="date"
          value={rangeEnd}
          min={rangeStart || todayStr}
          onChange={(e) => setRangeEnd(e.target.value)}
          className="rounded-lg border border-border bg-secondary px-2 py-1.5 text-xs text-foreground"
        />
      </div>
      {startTimeHint(rangeStart) && (
        <p className="mt-1.5 text-right text-[10px] text-muted-foreground">
          Today's slots start from <b className="text-foreground">{startTimeHint(rangeStart)}</b> — click{" "}
          <b className="text-foreground">Make placeholders</b> to remove the older placeholders and refresh to new slots upward from now.
        </p>
      )}

      <div className="mt-2">
        <span className="mb-1 block text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
          Rounds (each gathers its own slots within this pool)
        </span>
        <div className="flex flex-wrap gap-1.5">
          {roundChips.map((r) => {
            const active = roundNames.has(r);
            return (
              <button
                key={r}
                type="button"
                onClick={() => toggleRound(r)}
                className={cn(
                  "rounded-full border px-2.5 py-1 text-[11px] font-medium transition-colors",
                  active
                    ? "border-primary bg-primary/10 text-primary"
                    : "border-border text-muted-foreground hover:text-foreground"
                )}
              >
                {r}
              </button>
            );
          })}
        </div>
      </div>

      <input
        value={label}
        onChange={(e) => setLabel(e.target.value)}
        placeholder="Label (optional — auto-generated if left blank)"
        className="mt-2 w-full rounded-lg border border-border bg-secondary px-2 py-1.5 text-xs text-foreground placeholder:text-muted-foreground"
      />

      {(droppedRounds.length > 0 || rangeShrunk) && (
        <p className="mt-2 text-[10px] text-amber-600">
          Still-open placeholders {droppedRounds.length > 0 && <>for {droppedRounds.join(", ")} </>}
          {droppedRounds.length > 0 && rangeShrunk && "and "}
          {rangeShrunk && "outside the new date range "}
          will be cancelled and removed from interviewers' calendars — already-booked slots are left alone.
        </p>
      )}
      {error && <p className="mt-2 text-[10px] text-red-400">{error}</p>}

      <div className="mt-2 flex items-center gap-2">
        <button
          onClick={() => { setError(null); save.mutate(); }}
          disabled={!canSave || save.isPending}
          className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground transition-colors hover:bg-primary/90 disabled:opacity-50"
        >
          {save.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Pencil className="h-3.5 w-3.5" />}
          Save changes
        </button>
        <button
          onClick={onCancel}
          disabled={save.isPending}
          className="rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-secondary disabled:opacity-50"
        >
          Cancel
        </button>
      </div>
    </div>

    <PoolSizeSection pool={pool} />
    </div>
  );
}

// ── Pool size (velocity) — persisted per pool, editable, viewable whenever the
// pool is expanded into edit mode. The candidate-velocity table itself is always
// computed live (existing/gap reflect real-time slot counts), but the projected-
// candidates figure it's judged against is now a durable override on the pool
// row, not a value that only ever lived in this component's local state.
function PoolSizeSection({ pool }: { pool: InterviewPool }) {
  const queryClient = useQueryClient();
  const [draft, setDraft] = useState<string>(pool.manual_projected_candidates?.toString() ?? "");
  const [draftTouched, setDraftTouched] = useState(false);
  const [gatherResult, setGatherResult] = useState<GatherResult | null>(null);
  const [syncResult, setSyncResult] = useState<SyncResult | null>(null);
  const [showSlots, setShowSlots] = useState(false);

  const { data: velocity, isFetching, refetch } = useQuery({
    queryKey: ["pool-velocity", pool.id],
    queryFn: async () => (await interviewPoolsService.velocity(pool.id)).data,
  });
  const { data: slots, isFetching: slotsFetching, refetch: refetchSlots } = useQuery({
    queryKey: ["pool-slots", pool.id],
    queryFn: async () => (await interviewPoolsService.slots(pool.id)).data,
    enabled: showSlots,
  });
  // Per-round slot-picker links (sample-candidate backed) for the table below.
  const { data: pickerLinks } = useQuery({
    queryKey: ["pool-picker-links", pool.id],
    queryFn: async () => (await interviewPoolsService.pickerLinks(pool.id)).data.links,
  });
  const [copiedRound, setCopiedRound] = useState<string | null>(null);
  const copyPickerLink = async (roundName: string, urlPath: string) => {
    try {
      await navigator.clipboard.writeText(`${window.location.origin}${urlPath}`);
      setCopiedRound(roundName);
      setTimeout(() => setCopiedRound(null), 1500);
    } catch {
      /* clipboard denied — the Open link still works */
    }
  };

  const applyOverride = useMutation({
    mutationFn: (value: number | null) =>
      interviewPoolsService.update(pool.id, { manual_projected_candidates: value }),
    onSuccess: () => {
      setDraftTouched(false);
      queryClient.invalidateQueries({ queryKey: ["interview-pools"] });
      queryClient.invalidateQueries({ queryKey: ["pool-velocity", pool.id] });
    },
  });
  // Refresh — collects the latest status of EXISTING placeholders (did the
  // interviewer delete or move one directly on their calendar?). Creates
  // nothing. Also runs automatically every 2h for every pool — this is the
  // same check, just scoped here and on demand.
  const sync = useMutation({
    mutationFn: () => interviewPoolsService.sync(pool.id),
    onSuccess: ({ data }) => {
      setSyncResult(data);
      refetch();
      queryClient.invalidateQueries({ queryKey: ["pool-slots", pool.id] });
    },
  });
  // Make placeholders — allocates NEW slots per this pool's configured rules,
  // capped to the funnel-aware per-round target computed just above.
  const gather = useMutation({
    mutationFn: () => interviewPoolsService.gather(pool.id),
    onSuccess: ({ data }) => {
      setGatherResult(data);
      refetch();
      queryClient.invalidateQueries({ queryKey: ["pool-slots", pool.id] });
    },
  });

  const effectiveDraft = draftTouched ? draft : pool.manual_projected_candidates?.toString() ?? draft;
  const draftNumber = effectiveDraft.trim() === "" ? null : Number(effectiveDraft);
  const draftValid = effectiveDraft.trim() === "" || (Number.isFinite(draftNumber) && (draftNumber as number) >= 0);

  return (
    <div className="rounded-xl border border-border/60 bg-background/60 p-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="flex items-center gap-1.5 text-xs font-semibold text-foreground">
          <Gauge className="h-3.5 w-3.5 text-muted-foreground" />
          Pool size
        </span>
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            onClick={() => refetch()}
            disabled={isFetching}
            title="Recalculate the pool-size estimate from the latest candidate velocity and slot counts"
            className="inline-flex items-center gap-1.5 rounded-lg border border-border px-2 py-1 text-[11px] font-semibold text-muted-foreground transition-colors hover:bg-secondary disabled:opacity-50"
          >
            {isFetching ? <Loader2 className="h-3 w-3 animate-spin" /> : <RefreshCw className="h-3 w-3" />}
            Recalculate
          </button>
          <button
            onClick={() => sync.mutate()}
            disabled={sync.isPending}
            title="Collect the latest status of this pool's existing placeholders from interviewers' calendars — creates nothing (also runs automatically every 2h)"
            className="inline-flex items-center gap-1.5 rounded-lg border border-border px-2 py-1 text-[11px] font-semibold text-muted-foreground transition-colors hover:bg-secondary disabled:opacity-50"
          >
            {sync.isPending ? <Loader2 className="h-3 w-3 animate-spin" /> : <RefreshCw className="h-3 w-3" />}
            Refresh slots available
          </button>
          <button
            onClick={() => gather.mutate()}
            disabled={gather.isPending}
            title="Allocate new placeholder slots on rostered interviewers' calendars, per this pool's configured rules and funnel-aware per-round targets"
            className="inline-flex items-center gap-1.5 rounded-lg border border-primary/30 bg-primary/5 px-2 py-1 text-[11px] font-semibold text-primary transition-colors hover:bg-primary/10 disabled:opacity-50"
          >
            {gather.isPending ? <Loader2 className="h-3 w-3 animate-spin" /> : <CalendarPlus className="h-3 w-3" />}
            Make placeholders
          </button>
        </div>
      </div>

      {!velocity ? (
        <p className="mt-2 text-[11px] text-muted-foreground">
          {isFetching ? "Calculating…" : "Couldn't load the pool-size estimate."}
        </p>
      ) : (
        <div className="mt-2 space-y-2">
          <div className="grid grid-cols-2 gap-2 rounded-lg bg-secondary/30 p-2.5 text-[11px] sm:grid-cols-4">
            <div><span className="text-muted-foreground">Source velocity</span><div className="font-semibold text-foreground">{Math.ceil(velocity.velocity_per_day)}/day</div></div>
            <div>
              <span className="text-muted-foreground">Auto projected</span>
              <div className="font-semibold text-foreground">{Math.ceil(velocity.auto_projected_candidates)}</div>
            </div>
            <div>
              <span className="text-muted-foreground">Effective projected</span>
              <div className="font-semibold text-foreground">
                {Math.ceil(velocity.projected_candidates)}
                {velocity.manual_override && <span className="ml-1 rounded-full bg-primary/10 px-1.5 py-0.5 text-[9px] font-semibold text-primary">override</span>}
              </div>
            </div>
            <div><span className="text-muted-foreground">Screening-level need</span><div className="font-semibold text-foreground">{velocity.needed_pool_size}</div></div>
          </div>

          <div className="flex flex-wrap items-end gap-2 rounded-lg border border-dashed border-border/70 p-2.5">
            <label className="flex flex-col gap-1 text-[11px] text-muted-foreground">
              Expected candidates (override)
              <input
                type="number"
                min={0}
                placeholder={`auto: ${Math.ceil(velocity.auto_projected_candidates)}`}
                value={effectiveDraft}
                onChange={(e) => { setDraft(e.target.value); setDraftTouched(true); }}
                className="w-40 rounded-lg border border-border bg-secondary px-2 py-1 text-xs text-foreground"
              />
            </label>
            <button
              onClick={() => applyOverride.mutate(draftNumber)}
              disabled={!draftValid || applyOverride.isPending}
              className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-2.5 py-1.5 text-[11px] font-semibold text-primary-foreground transition-colors hover:bg-primary/90 disabled:opacity-50"
            >
              {applyOverride.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Gauge className="h-3.5 w-3.5" />}
              Save &amp; recalculate
            </button>
            {pool.manual_projected_candidates != null && (
              <button
                onClick={() => { setDraft(""); setDraftTouched(false); applyOverride.mutate(null); }}
                disabled={applyOverride.isPending}
                className="rounded-lg border border-border px-2.5 py-1.5 text-[11px] font-semibold text-muted-foreground transition-colors hover:bg-secondary disabled:opacity-50"
              >
                Reset to auto
              </button>
            )}
          </div>
          {!draftValid && (
            <p className="text-[10px] text-red-400">Enter a non-negative number, or clear it to use the auto estimate.</p>
          )}

          <div className="overflow-hidden rounded-lg border border-border/60">
            <table className="w-full text-[11px]">
              <thead>
                <tr className="bg-secondary/40 text-left text-muted-foreground">
                  <th className="px-2.5 py-1.5 font-medium">Round</th>
                  <th className="px-2.5 py-1.5 font-medium">Target</th>
                  <th className="px-2.5 py-1.5 font-medium">Existing</th>
                  <th className="px-2.5 py-1.5 font-medium">Gap</th>
                  <th className="px-2.5 py-1.5 font-medium">Time-slot picker URL</th>
                </tr>
              </thead>
              <tbody>
                {velocity.per_round.map((r) => {
                  const link = pickerLinks?.[r.round_name] ?? null;
                  return (
                  <tr key={r.round_name} className="border-t border-border/40">
                    <td className="px-2.5 py-1.5 text-foreground">{r.round_name}</td>
                    <td className="px-2.5 py-1.5 text-foreground">{r.target}</td>
                    <td className="px-2.5 py-1.5 text-foreground">{r.existing_strength}</td>
                    <td className={cn("px-2.5 py-1.5 font-semibold", r.gap > 0 ? "text-amber-600" : "text-emerald-600")}>
                      {r.gap > 0 ? r.gap : "None"}
                    </td>
                    <td className="px-2.5 py-1.5">
                      {link ? (
                        <span className="flex items-center gap-1.5">
                          {/* ?staff=1 unlocks the "verify with Admin/SysAdmin
                              credentials" option on the picker page — only
                              links opened from HERE carry it; the URLs mailed
                              to candidates never do. */}
                          <a
                            href={`${link}?staff=1`}
                            target="_blank"
                            rel="noreferrer"
                            title={`Open this round's slot picker (sample-candidate test invite, scoped to this pool — offers staff-credential access): ${window.location.origin}${link}`}
                            className="inline-flex items-center gap-1 font-medium text-primary hover:underline"
                          >
                            <ExternalLink className="h-3 w-3" /> Open
                          </a>
                          <button
                            type="button"
                            onClick={() => copyPickerLink(r.round_name, link)}
                            title="Copy the full URL"
                            className="inline-flex items-center gap-1 text-muted-foreground transition-colors hover:text-foreground"
                          >
                            {copiedRound === r.round_name ? (
                              <Check className="h-3 w-3 text-emerald-500" />
                            ) : (
                              <Copy className="h-3 w-3" />
                            )}
                          </button>
                        </span>
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </td>
                  </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <p className="text-[10px] text-muted-foreground">
            Each round's target already accounts for Predicted-NBA fast-tracking (candidates
            who skip earlier rounds) and the funnel filter % configured above — "Make
            placeholders" allocates up to these figures, filling every round's early tranches
            before any round's later ones.
          </p>

          {syncResult && (
            <div className="flex items-start gap-1.5 text-[11px] text-muted-foreground">
              <RefreshCw className="mt-0.5 h-3 w-3 shrink-0" />
              <div>
                {syncResult.checked} placeholder{syncResult.checked === 1 ? "" : "s"} checked
                {syncResult.removed > 0 && <>, {syncResult.removed} removed (deleted directly on the interviewer's calendar)</>}
                {syncResult.rescheduled > 0 && <>, {syncResult.rescheduled} moved to a new time</>}
              </div>
            </div>
          )}

          {gatherResult && (
            <div className="flex items-start gap-1.5 text-[11px] text-muted-foreground">
              <Users2 className="mt-0.5 h-3 w-3 shrink-0" />
              <div>
                {gatherResult.created} slot{gatherResult.created === 1 ? "" : "s"} created, {gatherResult.skipped} skipped
                {gatherResult.warnings.length > 0 && (
                  <div className="mt-0.5 text-amber-600">{gatherResult.warnings[0]}{gatherResult.warnings.length > 1 ? ` (+${gatherResult.warnings.length - 1} more)` : ""}</div>
                )}
              </div>
            </div>
          )}

          <div className="border-t border-border/60 pt-2">
            <div className="flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => setShowSlots((v) => !v)}
                className="flex items-center gap-1.5 text-[11px] font-semibold text-foreground"
              >
                <ChevronDown className={cn("h-3.5 w-3.5 transition-transform", !showSlots && "-rotate-90")} />
                Slot names {slots ? `(${slots.length})` : ""}
              </button>
              {showSlots && (
                <button
                  type="button"
                  onClick={() => refetchSlots()}
                  disabled={slotsFetching}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-border px-2 py-1 text-[11px] font-semibold text-muted-foreground transition-colors hover:bg-secondary disabled:opacity-50"
                >
                  {slotsFetching ? <Loader2 className="h-3 w-3 animate-spin" /> : <RefreshCw className="h-3 w-3" />}
                  Refresh
                </button>
              )}
            </div>
            {showSlots && (
              !slots ? (
                <p className="mt-2 text-[11px] text-muted-foreground">{slotsFetching ? "Loading…" : "Couldn't load slots."}</p>
              ) : slots.length === 0 ? (
                <p className="mt-2 text-[11px] text-muted-foreground">No slots gathered yet.</p>
              ) : (
                <div className="mt-2 max-h-64 overflow-y-auto rounded-lg border border-border/60">
                  <table className="w-full text-[11px]">
                    <thead className="sticky top-0 bg-secondary/60">
                      <tr className="text-left text-muted-foreground">
                        <th className="px-2.5 py-1.5 font-medium">Slot name</th>
                        <th className="px-2.5 py-1.5 font-medium">Round</th>
                        <th className="px-2.5 py-1.5 font-medium">Interviewer</th>
                        <th className="px-2.5 py-1.5 font-medium">When</th>
                        <th className="px-2.5 py-1.5 font-medium">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {slots.map((s) => (
                        <tr key={s.id} className="border-t border-border/40">
                          <td className="px-2.5 py-1.5 font-semibold text-foreground">{s.slot_name ?? "—"}</td>
                          <td className="px-2.5 py-1.5 text-foreground">{s.round_name}</td>
                          <td className="px-2.5 py-1.5 text-muted-foreground">{s.interviewer_name || s.interviewer_email}</td>
                          <td className="px-2.5 py-1.5 tnum text-muted-foreground">{fmtDateTime(s.slot_start)}</td>
                          <td className="px-2.5 py-1.5">
                            <span className={cn("rounded-full border px-1.5 py-0.5 text-[10px] font-semibold", SLOT_STATUS_CLS[s.status])}>
                              {SLOT_STATUS_LABEL[s.status] ?? s.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function PoolCard({
  pool,
  sources,
  onArchive,
}: {
  pool: InterviewPool;
  sources: (string | null)[];
  onArchive: () => void;
}) {
  const queryClient = useQueryClient();
  const [editing, setEditing] = useState(false);

  return (
    <div className="rounded-xl border border-border/60 bg-secondary/10 p-3.5">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="min-w-0">
          <div className="text-sm font-semibold text-foreground">{pool.label}</div>
          <div className="text-[11px] text-muted-foreground">
            {pool.round_names.join(", ")} · {pool.source_label ?? NO_SOURCE_LABEL} · {fmtDate(pool.range_start)} – {fmtDate(pool.range_end)}
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-1.5">
          <button
            onClick={() => setEditing((v) => !v)}
            title="Edit this pool's details and pool size"
            className={cn(
              "rounded-lg p-1.5 transition-colors",
              editing ? "bg-primary/10 text-primary" : "text-muted-foreground hover:bg-secondary hover:text-foreground",
            )}
          >
            {editing ? <X className="h-3.5 w-3.5" /> : <Pencil className="h-3.5 w-3.5" />}
          </button>
          <button
            onClick={onArchive}
            title="Delete this pool — cancels its open placeholders too"
            className="rounded-lg p-1.5 text-muted-foreground hover:bg-red-500/10 hover:text-red-400 transition-colors"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {editing ? (
        <EditPoolForm
          pool={pool}
          sources={sources}
          onSaved={() => {
            setEditing(false);
            queryClient.invalidateQueries({ queryKey: ["interview-pools"] });
          }}
          onCancel={() => setEditing(false)}
        />
      ) : (
        <button
          onClick={() => setEditing(true)}
          className="mt-2 text-[11px] font-medium text-primary hover:underline"
        >
          View / edit pool size →
        </button>
      )}
    </div>
  );
}
