import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import {
  Mail, Paperclip, Clock, AlertTriangle, Timer, RefreshCw, Trash2, History, Undo2, X,
} from "lucide-react";
import { graphService, type GraphQueueItem, type DiscardedMailItem, type DiscardResult } from "@/services/graph";
import { useConfirm } from "@/components/common/ConfirmProvider";
import { apiErrorMessage } from "@/lib/utils";

// Poll cadence for the live Outlook queue (matches the backend Graph poll, 60s).
const POLL_MS = 60_000;

// Fallback target when the backend can't report a scheduled run (e.g. scheduler
// not started): the next local midnight, matching the default 00:00 cron.
function nextMidnight(): Date {
  const d = new Date();
  d.setHours(24, 0, 0, 0);
  return d;
}

// Live countdown (ms remaining) to `target`, re-rendering every second.
function useCountdown(target: Date | null): number {
  const [remaining, setRemaining] = useState(() =>
    target ? target.getTime() - Date.now() : 0,
  );
  const stamp = target?.getTime();
  useEffect(() => {
    if (!target) return;
    const tick = () => setRemaining(target.getTime() - Date.now());
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [stamp]); // eslint-disable-line react-hooks/exhaustive-deps
  return remaining;
}

function formatHMS(ms: number): string {
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${pad(h)}:${pad(m)}:${pad(s)}`;
}

function fmtWhen(iso: string | null): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "—";
  return d.toLocaleString("en-IN", {
    day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit",
    hour12: false, timeZone: "Asia/Kolkata",
  });
}

export default function OutlookIntakePanel() {
  const queryClient = useQueryClient();
  const confirm = useConfirm();
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [showSetAside, setShowSetAside] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);

  const { data: status } = useQuery({
    queryKey: ["graph-status"],
    queryFn: async () => (await graphService.status()).data,
    refetchInterval: POLL_MS,
  });

  const { data: queue, isLoading } = useQuery({
    queryKey: ["graph-queue"],
    queryFn: async () => (await graphService.queue()).data,
    refetchInterval: POLL_MS,
  });

  // Mail an Admin/System Admin has set aside — restorable back into the queue.
  const { data: setAside = [], isLoading: setAsideLoading } = useQuery({
    queryKey: ["graph-discarded"],
    queryFn: async () => (await graphService.discarded()).data,
    refetchInterval: POLL_MS,
    enabled: showSetAside,
  });

  const pollNow = useMutation({
    mutationFn: () => graphService.pollNow(),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["graph-queue"] });
      queryClient.invalidateQueries({ queryKey: ["graph-status"] });
    },
  });

  const invalidateAll = () => {
    queryClient.invalidateQueries({ queryKey: ["graph-queue"] });
    queryClient.invalidateQueries({ queryKey: ["graph-status"] });
    queryClient.invalidateQueries({ queryKey: ["graph-discarded"] });
  };

  const handleDiscardResult = (res: { data: DiscardResult }) => {
    setSelected(new Set());
    invalidateAll();
    const { discarded, failed } = res.data;
    setActionError(
      failed > 0
        ? `${discarded} discarded, ${failed} couldn't be moved (Outlook error) — ${failed === 1 ? "it stays" : "they stay"} in the queue.`
        : null,
    );
  };
  const handleActionError = (e: unknown) => setActionError(apiErrorMessage(e, "That action failed."));

  const discardMutation = useMutation({
    mutationFn: (ids: string[]) => graphService.discard(ids, false),
    onSuccess: handleDiscardResult,
    onError: handleActionError,
  });

  const discardAllMutation = useMutation({
    mutationFn: () => graphService.discard([], true),
    onSuccess: handleDiscardResult,
    onError: handleActionError,
  });

  const restoreMutation = useMutation({
    mutationFn: (id: number) => graphService.restoreDiscarded(id),
    onSuccess: () => {
      setActionError(null);
      invalidateAll();
    },
    onError: handleActionError,
  });

  // Countdown to the next pipeline run. Hooks must run unconditionally, so this
  // sits above the early return below. Prefer the scheduler's reported next_run;
  // fall back to the next local midnight (the default 00:00 cron).
  const target = useMemo(
    () => (status?.next_run ? new Date(status.next_run) : nextMidnight()),
    [status?.next_run],
  );
  const remaining = useCountdown(target);

  // Only surface the panel when Outlook/Graph is configured.
  if (!status?.configured) return null;

  const items = queue?.items ?? [];
  const polled = status?.polled_at ?? queue?.polled_at;
  const openSetAside = setAside.filter((d) => d.state === "discarded");

  const toggleOne = (id: string) =>
    setSelected((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });

  const toggleAll = () =>
    setSelected((prev) => (prev.size === items.length ? new Set() : new Set(items.map((it) => it.id))));

  const discardSelected = async () => {
    if (selected.size === 0) return;
    const ok = await confirm({
      title: `Discard ${selected.size} email${selected.size === 1 ? "" : "s"}?`,
      message: "These are removed from the next pipeline run. You can bring them back later from \"Set aside\".",
      confirmLabel: "Discard",
      danger: true,
    });
    if (ok) discardMutation.mutate([...selected]);
  };

  const discardAll = async () => {
    if (items.length === 0) return;
    const ok = await confirm({
      title: `Discard all ${items.length} incoming emails?`,
      message: "These are removed from the next pipeline run. You can bring them back later from \"Set aside\".",
      confirmLabel: "Discard all",
      danger: true,
    });
    if (ok) discardAllMutation.mutate();
  };

  return (
    <div className="flex items-start gap-4">
    <div className="surface flex-1 min-w-0 p-4 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-accent">
            <Mail className="h-4 w-4 text-primary" />
          </div>
          <div>
            <div className="text-sm font-medium text-ink">Incoming Email Queue</div>
          </div>
        </div>
        <div className="flex flex-col items-end gap-1">
          {/* Live countdown to the next pipeline run (drains the queue). */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowSetAside((v) => !v)}
              title="Emails discarded from this queue, restorable for a later run"
              className={`flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-medium transition-colors ${
                showSetAside
                  ? "border-primary/40 bg-accent text-brand-deep"
                  : "border-border bg-secondary text-ink-mute hover:text-ink"
              }`}
            >
              <History className="h-3 w-3" />
              Set aside{openSetAside.length > 0 ? ` (${openSetAside.length})` : ""}
            </button>
            <button
              onClick={() => pollNow.mutate()}
              disabled={pollNow.isPending}
              title="Check for new emails now"
              className="flex items-center gap-1.5 rounded-full border border-border bg-secondary px-2.5 py-1 text-[11px] font-medium text-ink-mute hover:text-ink disabled:opacity-50"
            >
              <RefreshCw className={`h-3 w-3 ${pollNow.isPending ? "animate-spin" : ""}`} />
              Refresh
            </button>
            <span
              className="flex items-center gap-1.5 rounded-full bg-accent px-2.5 py-1 text-[11px] font-medium text-brand-deep tabular-nums"
              title={`Next pipeline run: ${target.toLocaleString()}`}
            >
              <Timer className="h-3.5 w-3.5" />
              Next run in {formatHMS(remaining)}
            </span>
          </div>
          {polled && (
            <span className="text-[11px] text-ink-mute flex items-center gap-1 tnum">
              <Clock className="h-3 w-3" /> checked {new Date(polled).toLocaleTimeString()}
            </span>
          )}
        </div>
      </div>

      {status.error && status.error !== "not_configured" && (
        <div className="flex items-center gap-2 rounded-lg border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-xs text-amber-600">
          <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
          <span className="truncate">Email connection: {status.error}</span>
        </div>
      )}

      {actionError && (
        <div className="flex items-center gap-2 rounded-lg border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-xs text-amber-600">
          <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
          <span className="truncate flex-1">{actionError}</span>
          <button onClick={() => setActionError(null)} className="shrink-0 hover:text-amber-800">
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      )}

      {/* Live queue */}
      <div className="rounded-lg border border-border overflow-hidden">
        <div className="px-4 py-2 border-b border-border bg-secondary flex items-center justify-between gap-2 flex-wrap">
          <span className="text-xs font-medium text-ink">
            Incoming ({items.length}) — resumes waiting for the next pipeline run
          </span>
          <div className="flex items-center gap-2">
            {(status.rejected ?? 0) > 0 && (
              <span className="text-[10px] text-ink-mute tnum">
                {status.rejected} non-resume filtered out
              </span>
            )}
            {selected.size > 0 && (
              <button
                onClick={discardSelected}
                disabled={discardMutation.isPending}
                className="flex items-center gap-1.5 rounded-full border border-red-500/30 bg-red-500/10 px-2.5 py-1 text-[11px] font-medium text-red-600 hover:bg-red-500/20 disabled:opacity-50"
              >
                <Trash2 className="h-3 w-3" /> Discard ({selected.size})
              </button>
            )}
            {items.length > 0 && (
              <button
                onClick={discardAll}
                disabled={discardAllMutation.isPending}
                title="Discard every email currently in the queue"
                className="flex items-center gap-1.5 rounded-full border border-border bg-secondary px-2.5 py-1 text-[11px] font-medium text-ink-mute hover:text-red-600 disabled:opacity-50"
              >
                <Trash2 className="h-3 w-3" /> Discard all
              </button>
            )}
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                <th className="w-9 px-3 py-2">
                  {items.length > 0 && (
                    <input
                      type="checkbox"
                      checked={selected.size === items.length}
                      ref={(el) => {
                        if (el) el.indeterminate = selected.size > 0 && selected.size < items.length;
                      }}
                      onChange={toggleAll}
                      aria-label="Select all"
                      className="h-3.5 w-3.5 cursor-pointer accent-primary"
                    />
                  )}
                </th>
                {["Sender", "Subject", "Received", "Attach", ""].map((h) => (
                  <th key={h} className="px-3 py-2 text-left text-[11px] font-medium uppercase tracking-wide text-ink-mute">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {items.map((it: GraphQueueItem) => (
                <tr key={it.id} className="border-b border-border hover:bg-secondary transition-colors">
                  <td className="px-3 py-2">
                    <input
                      type="checkbox"
                      checked={selected.has(it.id)}
                      onChange={() => toggleOne(it.id)}
                      aria-label={`Select ${it.subject}`}
                      className="h-3.5 w-3.5 cursor-pointer accent-primary"
                    />
                  </td>
                  <td className="px-3 py-2 text-xs text-ink-mute max-w-[180px] truncate">
                    {it.sender}
                  </td>
                  <td className="px-3 py-2 text-xs text-ink max-w-[280px] truncate">
                    {it.subject}
                  </td>
                  <td className="px-3 py-2 text-xs text-ink-mute whitespace-nowrap tnum">
                    {fmtWhen(it.received_date)}
                  </td>
                  <td className="px-3 py-2 text-xs text-ink-mute">
                    {it.has_attachments ? <Paperclip className="h-3.5 w-3.5 text-primary" /> : "—"}
                  </td>
                  <td className="px-3 py-2 text-right">
                    <button
                      onClick={() => discardMutation.mutate([it.id])}
                      disabled={discardMutation.isPending}
                      title="Discard this email"
                      className="text-ink-mute hover:text-red-600 disabled:opacity-50"
                    >
                      <X className="h-3.5 w-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
              {items.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-3 py-6 text-center text-xs text-ink-mute">
                    {isLoading
                      ? "Loading…"
                      : "No resumes waiting — new emails appear here automatically."}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>

    {/* Set aside — compact side panel, mail excluded from the next pipeline run and
        restorable for a later/on-demand one. Appears beside the queue (not stacked
        below it) so it reads as a companion list, not another full-width table. */}
    {showSetAside && (
      <div className="surface w-full max-w-xs shrink-0 overflow-hidden self-start">
        <div className="px-3 py-2.5 border-b border-border bg-secondary flex items-center justify-between gap-2">
          <span className="text-xs font-medium text-ink">
            Set aside <span className="text-ink-mute font-normal">({openSetAside.length})</span>
          </span>
          <button onClick={() => setShowSetAside(false)} className="text-ink-mute hover:text-ink" title="Close">
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
        <div className="max-h-[420px] overflow-y-auto divide-y divide-border">
          {openSetAside.map((d: DiscardedMailItem) => (
            <div key={d.id} className="px-3 py-2 hover:bg-secondary transition-colors">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="text-xs text-ink truncate" title={d.subject || "(no subject)"}>
                    {d.subject || "(no subject)"}
                  </div>
                  <div className="text-[11px] text-ink-mute truncate">{d.sender_mail_id || "—"}</div>
                </div>
                <button
                  onClick={() => restoreMutation.mutate(d.id)}
                  disabled={restoreMutation.isPending}
                  title="Bring back into the queue for a future or on-demand run"
                  className="shrink-0 flex items-center gap-1 rounded-full border border-primary/30 bg-primary/5 px-2 py-0.5 text-[11px] font-medium text-primary hover:bg-primary/10 disabled:opacity-50"
                >
                  <Undo2 className="h-3 w-3" /> Restore
                </button>
              </div>
              <div className="mt-1 text-[10px] text-ink-mute">
                Discarded by {d.discarded_by_name || d.discarded_by_email || "—"} · {fmtWhen(d.discarded_at)}
              </div>
            </div>
          ))}
          {openSetAside.length === 0 && (
            <div className="px-3 py-6 text-center text-xs text-ink-mute">
              {setAsideLoading ? "Loading…" : "Nothing set aside."}
            </div>
          )}
        </div>
      </div>
    )}
    </div>
  );
}
