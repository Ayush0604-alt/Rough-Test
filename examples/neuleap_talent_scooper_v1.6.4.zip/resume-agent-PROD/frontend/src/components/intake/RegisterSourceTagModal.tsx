// "Register recent social post as a source tag" — Mailbox page. Registering a
// tag just adds it to the list below; the recruiter separately picks which
// ONE tag is ACTIVE (via the radio button on its row) — every new Graph-mail
// resume staged while a tag is active gets that tag's label auto-stamped as
// its intake source (replies to that post get tagged without the recruiter
// tagging each email by hand).
import { useEffect, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { X, Circle, Tag, Loader2, Trash2, CheckCircle2, ChevronDown, ChevronUp, Search, Pencil, Save, Filter } from "lucide-react";
import SourceFunnelHealthModal from "@/components/intake/SourceFunnelHealthModal";
import { sourceTagsService, type SourceTag } from "@/services/sourceTags";
import { batchArchiveService } from "@/services/batchArchive";
import { settingsService } from "@/services/settings";
import { cn } from "@/lib/utils";
import { useAuth } from "@/context/AuthContext";
import Toggle from "@/components/common/Toggle";
import ConfirmDialog from "@/components/common/ConfirmDialog";

const PLATFORMS = ["LinkedIn", "X / Twitter", "Facebook", "Instagram", "Naukri", "Indeed", "Other"];

interface Props {
  open: boolean;
  tags: SourceTag[];
  activeId: string | null;
  onClose: () => void;
  onChanged: () => void;
}

export default function RegisterSourceTagModal({ open, tags, activeId, onClose, onChanged }: Props) {
  // Switching or clearing the ACTIVE tag is Admin-only (enforced server-side
  // too, PUT /source-tags/active) — Sysadmin can still register new sources
  // and pick one when uploading, just not change what's live for auto-tagging.
  const { isAdmin } = useAuth();
  const [platform, setPlatform] = useState(PLATFORMS[0]);
  const [label, setLabel] = useState("");
  const [postUrl, setPostUrl] = useState("");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState<string | null>(null); // "register" | tag_id being (de)activated/removed
  const [error, setError] = useState<string | null>(null);
  // Separate from `error` (that one lives inside the register/edit form) —
  // this surfaces failures from activating/clearing/deleting a tag in the
  // list below (e.g. "Only an Admin can..." or "already in use, can't delete").
  const [listError, setListError] = useState<string | null>(null);
  const [formOpen, setFormOpen] = useState(true);
  const [tagSearch, setTagSearch] = useState("");
  // Set while editing an existing tag (by id) instead of registering a new
  // one — reuses the same form fields, just routes submit to `update`. Not
  // offered for "Sample Data", which isn't a registered tag at all (it's a
  // separate fixture-visibility toggle rendered below the list).
  const [editingId, setEditingId] = useState<string | null>(null);

  const queryClient = useQueryClient();
  // Per-tag "Recruiters can apply predicted NBA" — keyed by the tag's LABEL
  // (the exact string stamped onto candidate_master.source), same config as
  // Mailbox → Batch Archive's per-source toggle — see app.services.recruiter_apply_config.
  const { data: recruiterApply } = useQuery({
    queryKey: ["recruiter-apply-nba"],
    queryFn: async () => (await batchArchiveService.getRecruiterApplyNba()).data,
  });
  const setRecruiterApply = useMutation({
    mutationFn: ({ source, enabled }: { source: string; enabled: boolean }) =>
      batchArchiveService.saveRecruiterApplyNba(source, enabled),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["recruiter-apply-nba"] }),
  });

  // A source whose candidate batch has been archived (Mailbox → Batch Archive)
  // is hidden from the "previously registered" list below until that batch is
  // restored — an archived, retired source shouldn't clutter the active-source
  // picker. "Archived" here means the source's candidates are ALL in the
  // archive: its label shows up under archived batches and NOT under live ones
  // (new intake arriving after an archive re-lists it as live, so it reappears
  // on its own). Both queries only run while the modal is open.
  const { data: liveBatches } = useQuery({
    queryKey: ["batches-live"],
    queryFn: async () => (await batchArchiveService.listLive()).data.batches,
    enabled: open,
  });
  const { data: archivedBatches } = useQuery({
    queryKey: ["batches-archived"],
    queryFn: async () => (await batchArchiveService.listArchived()).data.batches,
    enabled: open,
  });
  const archivedOnlyLabels = useMemo(() => {
    const live = new Set(
      (liveBatches ?? []).map((b) => b.source).filter((s): s is string => !!s),
    );
    const archived = new Set<string>();
    for (const b of archivedBatches ?? []) {
      if (b.source && !live.has(b.source)) archived.add(b.source);
    }
    return archived;
  }, [liveBatches, archivedBatches]);
  // Turning this ON is the consequential direction (a Recruiter can then move
  // candidates from this source forward with no Admin review) — confirm
  // first. Turning it back off is always free, no confirmation needed.
  const [confirmEnableFor, setConfirmEnableFor] = useState<string | null>(null);

  // Clearing the active tag stops auto-tagging new email resumes entirely
  // (they'll show as "No Source tagged") — confirm before actually doing it.
  const [confirmClearActive, setConfirmClearActive] = useState(false);

  // Which tag's process-health funnel popup is open (the tag's LABEL — the
  // string stamped onto candidate_master.source); null = closed.
  const [funnelFor, setFunnelFor] = useState<string | null>(null);

  // Picking a radio (or "Clear active tag") only stages the choice locally —
  // `undefined` means "no pending change, show the server's activeId as-is".
  // The actual PUT /source-tags/active call only fires from "Save changes"
  // below; "Cancel" just discards this and reverts to the server's value.
  const [pendingActiveId, setPendingActiveId] = useState<string | null | undefined>(undefined);
  const displayActiveId = pendingActiveId !== undefined ? pendingActiveId : activeId;
  const hasPendingActiveChange = pendingActiveId !== undefined && pendingActiveId !== activeId;

  // Per-tag "only check duplicates within this source" — lives directly on
  // the tag (app.services.source_tags), not a separate keyed config, since
  // it's a property of the tag itself. Default false = system-wide dup check.
  const setDupCheckScope = useMutation({
    mutationFn: ({ tagId, scoped }: { tagId: string; scoped: boolean }) =>
      sourceTagsService.setDupCheckScope(tagId, scoped),
    onSuccess: onChanged,
  });

  // Whether the "Sample Data" fixture source shows up in source-tag pickers
  // app-wide (Dashboard, Screening, Interviewer Timeslot Pools). Always
  // hidden in production regardless of this toggle — see
  // app.services.sample_data_visibility. `toggle_shown` is false in
  // production, so this control renders nothing there.
  const [sampleDataCfg, setSampleDataCfg] = useState<{ visible: boolean; toggle_shown: boolean } | null>(null);
  const [sampleDataSaving, setSampleDataSaving] = useState(false);
  useEffect(() => {
    if (open) settingsService.getSampleDataVisibility().then(({ data }) => setSampleDataCfg(data)).catch(() => {});
  }, [open]);
  const toggleSampleData = async (v: boolean) => {
    if (!sampleDataCfg) return;
    setSampleDataCfg({ ...sampleDataCfg, visible: v });
    setSampleDataSaving(true);
    try {
      const { data } = await settingsService.saveSampleDataVisibility(v);
      setSampleDataCfg(data);
      // Dashboard/Screening/Pools read this via useSampleDataFilter's
      // ["app-meta"] query (60s staleTime) — invalidate so they pick up the
      // new visibility immediately instead of waiting for it to go stale.
      queryClient.invalidateQueries({ queryKey: ["app-meta"] });
    } finally {
      setSampleDataSaving(false);
    }
  };

  // Reset the form each time the modal opens (not on every re-render). Open
  // the registration form by default only when there's nothing to browse yet.
  useEffect(() => {
    if (open) {
      setPlatform(PLATFORMS[0]);
      setLabel("");
      setPostUrl("");
      setNote("");
      setError(null);
      setListError(null);
      setFormOpen(tags.length === 0);
      setTagSearch("");
      setEditingId(null);
      setPendingActiveId(undefined);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  // Tags shown in the list: everything except archived-batch sources. The
  // currently active tag is always kept visible (it's live for auto-tagging,
  // so hiding it would be confusing even in the rare case its old batch was
  // archived before any new intake arrived).
  const visibleTags = useMemo(
    () => tags.filter((t) => t.id === activeId || !archivedOnlyLabels.has(t.label)),
    [tags, activeId, archivedOnlyLabels],
  );

  const filteredTags = useMemo(() => {
    const q = tagSearch.trim().toLowerCase();
    if (!q) return visibleTags;
    return visibleTags.filter(
      (t) =>
        t.label.toLowerCase().includes(q) ||
        t.platform.toLowerCase().includes(q) ||
        (t.note ?? "").toLowerCase().includes(q),
    );
  }, [visibleTags, tagSearch]);

  if (!open) return null;

  const resetForm = () => {
    setEditingId(null);
    setPlatform(PLATFORMS[0]);
    setLabel("");
    setPostUrl("");
    setNote("");
    setError(null);
  };

  const startEdit = (t: SourceTag) => {
    setEditingId(t.id);
    setPlatform(t.platform);
    setLabel(t.label);
    setPostUrl(t.post_url ?? "");
    setNote(t.note ?? "");
    setError(null);
    setFormOpen(true);
  };

  const submitForm = async () => {
    const trimmed = label.trim();
    if (!trimmed) {
      setError("Enter a label — this is what's stamped onto matching candidates.");
      return;
    }
    const busyKey = editingId ? "save" : "register";
    setBusy(busyKey);
    setError(null);
    try {
      const body = {
        platform,
        label: trimmed,
        post_url: postUrl.trim() || undefined,
        note: note.trim() || undefined,
      };
      if (editingId) {
        await sourceTagsService.update(editingId, body);
      } else {
        await sourceTagsService.register(body);
      }
      onChanged();
      resetForm();
      setTagSearch("");
      setFormOpen(false);
    } catch (e: unknown) {
      const detail = (e as { response?: { data?: { detail?: string } } })?.response?.data?.detail;
      setError(detail ?? (editingId ? "Couldn't save changes to this source tag." : "Couldn't register this source tag."));
    } finally {
      setBusy(null);
    }
  };

  const activate = async (tagId: string | null): Promise<boolean> => {
    setBusy(tagId ?? "clear");
    setListError(null);
    try {
      await sourceTagsService.setActive(tagId);
      onChanged();
      return true;
    } catch (e: unknown) {
      const detail = (e as { response?: { data?: { detail?: string } } })?.response?.data?.detail;
      setListError(detail ?? "Couldn't change the active source tag.");
      return false;
    } finally {
      setBusy(null);
    }
  };

  // "Save changes" for the active-tag picker below — clearing still goes
  // through the confirm dialog (it stops auto-tagging entirely); switching to
  // a different tag applies directly, same as before this pending-select flow.
  const saveActiveChange = () => {
    if (pendingActiveId === null) {
      setConfirmClearActive(true);
    } else if (pendingActiveId !== undefined) {
      activate(pendingActiveId).then((ok) => { if (ok) setPendingActiveId(undefined); });
    }
  };
  const cancelActiveChange = () => setPendingActiveId(undefined);

  const remove = async (tagId: string) => {
    setBusy(tagId);
    setListError(null);
    try {
      await sourceTagsService.remove(tagId);
      onChanged();
      if (editingId === tagId) resetForm();
    } catch (e: unknown) {
      const detail = (e as { response?: { data?: { detail?: string } } })?.response?.data?.detail;
      setListError(detail ?? "Couldn't delete this source tag.");
    } finally {
      setBusy(null);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/40 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="flex max-h-[85vh] w-full max-w-5xl flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3 border-b border-border px-5 py-3.5">
          <div className="min-w-0">
            <h2 className="truncate text-sm font-bold text-foreground">Register a Social Post as a Source</h2>
            <p className="text-[11px] text-muted-foreground">
              The active tag is auto-attached to new resumes arriving by email
            </p>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="flex min-h-0 flex-1 flex-col gap-3 px-5 py-4">
          <div className="shrink-0 rounded-xl border border-border bg-secondary/30">
            <button
              type="button"
              onClick={() => setFormOpen((v) => !v)}
              className="flex w-full items-center justify-between gap-2 px-3.5 py-2.5 text-left"
            >
              <span className="text-xs font-semibold text-foreground">
                {editingId ? "Edit source" : "Register a new source"}
              </span>
              {formOpen ? (
                <ChevronUp className="h-4 w-4 shrink-0 text-muted-foreground" />
              ) : (
                <ChevronDown className="h-4 w-4 shrink-0 text-muted-foreground" />
              )}
            </button>
            {formOpen && (
              <div className="space-y-3 border-t border-border px-3.5 pb-3.5 pt-3">
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                      Platform
                    </label>
                    <select
                      value={platform}
                      onChange={(e) => setPlatform(e.target.value)}
                      className="w-full rounded-lg border border-border bg-background px-2.5 py-1.5 text-xs text-foreground outline-none focus:border-primary/50"
                    >
                      {PLATFORMS.map((p) => (
                        <option key={p} value={p}>{p}</option>
                      ))}
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                      Post URL (optional)
                    </label>
                    <input
                      type="url"
                      value={postUrl}
                      onChange={(e) => setPostUrl(e.target.value)}
                      placeholder="https://…"
                      className="w-full rounded-lg border border-border bg-background px-2.5 py-1.5 text-xs text-foreground outline-none focus:border-primary/50"
                    />
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                    Label — stamped as the candidate source
                  </label>
                  <input
                    type="text"
                    value={label}
                    onChange={(e) => setLabel(e.target.value)}
                    placeholder="e.g. LinkedIn - Senior GenAI Engineer post"
                    className="w-full rounded-lg border border-border bg-background px-2.5 py-1.5 text-xs text-foreground outline-none focus:border-primary/50"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                    Note (optional)
                  </label>
                  <input
                    type="text"
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                    placeholder="Anything worth remembering about this post"
                    className="w-full rounded-lg border border-border bg-background px-2.5 py-1.5 text-xs text-foreground outline-none focus:border-primary/50"
                  />
                </div>
                {error && <p className="text-[11px] text-red-400">{error}</p>}
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={submitForm}
                    disabled={busy === "register" || busy === "save"}
                    className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-primary px-3 py-1.5 text-xs font-semibold text-white transition-opacity disabled:opacity-40"
                  >
                    {busy === "register" || busy === "save" ? (
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    ) : editingId ? (
                      <Save className="h-3.5 w-3.5" />
                    ) : (
                      <Tag className="h-3.5 w-3.5" />
                    )}
                    {editingId ? "Save changes" : "Register"}
                  </button>
                  {editingId && (
                    <button
                      type="button"
                      onClick={resetForm}
                      className="shrink-0 rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
                    >
                      Cancel
                    </button>
                  )}
                </div>
                {!editingId && (
                  <p className="text-[10px] text-muted-foreground">
                    Registering just adds it to the list below — pick which tag is active separately.
                  </p>
                )}
              </div>
            )}
          </div>

          <div className="flex min-h-0 flex-1 flex-col gap-1.5">
            <div className="flex shrink-0 items-center justify-between gap-2">
              <label className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                Previously registered
              </label>
              <span className="text-[10px] text-muted-foreground">
                {visibleTags.length} tag{visibleTags.length === 1 ? "" : "s"}
              </span>
            </div>

            {visibleTags.length > 0 && (
              <div className="relative shrink-0">
                <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="text"
                  value={tagSearch}
                  onChange={(e) => setTagSearch(e.target.value)}
                  placeholder="Search registered sources…"
                  className="w-full rounded-lg border border-border bg-background py-1.5 pl-8 pr-2.5 text-xs text-foreground outline-none focus:border-primary/50"
                />
              </div>
            )}

            <div className="min-h-0 flex-1 space-y-1.5 overflow-y-auto pr-0.5">
              {filteredTags.length === 0 ? (
                <p className="py-6 text-center text-[11px] text-muted-foreground">
                  {visibleTags.length === 0 ? "No sources registered yet." : "No sources match your search."}
                </p>
              ) : (
                filteredTags.map((t) => {
                  const isActive = t.id === displayActiveId;
                  const isPendingPick = isActive && t.id !== activeId;
                  return (
                    <div
                      key={t.id}
                      className={cn(
                        "flex items-center gap-2 rounded-lg border px-2.5 py-2",
                        isPendingPick
                          ? "border-amber-400/50 bg-amber-400/5"
                          : isActive ? "border-primary/40 bg-primary/5" : "border-border",
                        t.id === editingId && "ring-2 ring-amber-400/60",
                      )}
                    >
                      <button
                        type="button"
                        onClick={() => !isActive && isAdmin && setPendingActiveId(t.id)}
                        disabled={busy === t.id || !isAdmin}
                        title={
                          isActive
                            ? isPendingPick
                              ? "Selected — click \"Save changes\" below to make this the active source"
                              : "Currently active — new email resumes are being tagged with this source"
                            : isAdmin
                              ? "Click to select this as the active source, then Save changes"
                              : "Only an Admin can change the active source"
                        }
                        className={cn("group shrink-0", !isAdmin && !isActive && "cursor-not-allowed opacity-50")}
                      >
                        {isActive ? (
                          <CheckCircle2 className={cn("h-4 w-4", isPendingPick ? "text-amber-500" : "text-primary")} />
                        ) : (
                          <Circle className={cn("h-4 w-4 text-muted-foreground transition-colors", isAdmin && "group-hover:text-primary")} />
                        )}
                      </button>
                      <div className="min-w-[20rem] flex-1">
                        <div className="truncate text-xs font-medium text-foreground">{t.label}</div>
                        <div className="truncate text-[10px] text-muted-foreground">
                          {t.platform}
                          {t.note ? ` · ${t.note}` : ""}
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => setFunnelFor(t.label)}
                        title="Process health — funnel of actual candidates through every stage for this source, with in-flight counts and the oldest pending at each stage"
                        className="shrink-0 rounded-full border border-primary/25 bg-primary/5 p-1.5 text-primary/80 transition-colors hover:bg-primary/15 hover:text-primary"
                      >
                        <Filter className="h-3.5 w-3.5" />
                      </button>
                      <div
                        className="flex shrink-0 items-center gap-2 rounded-lg border border-border/60 bg-secondary/30 py-1 pl-2.5 pr-1.5"
                        title="Whether a Recruiter can apply a predicted NBA (or schedule a round) for a still-New candidate from this source without Admin review first"
                      >
                        <span className="text-right text-[9px] font-normal leading-snug text-muted-foreground/70">
                          Recruiter can apply the
                          <br />
                          predicted NBA
                        </span>
                        <Toggle
                          value={recruiterApply?.sources[t.label] ?? false}
                          onChange={(v) => (v ? setConfirmEnableFor(t.label) : setRecruiterApply.mutate({ source: t.label, enabled: false }))}
                          disabled={setRecruiterApply.isPending}
                        />
                      </div>
                      <div
                        className="flex shrink-0 items-center gap-2 rounded-lg border border-border/60 bg-secondary/30 py-1 pl-2.5 pr-1.5"
                        title="Whether the duplicate-resume check for this source's candidates only compares against candidates from this same source, instead of the default system-wide check across all data"
                      >
                        <span className="text-right text-[9px] font-normal leading-snug text-muted-foreground/70">
                          Dup check within
                          <br />
                          this source only
                        </span>
                        <Toggle
                          value={t.dup_check_scoped}
                          onChange={(v) => setDupCheckScope.mutate({ tagId: t.id, scoped: v })}
                          disabled={setDupCheckScope.isPending}
                        />
                      </div>
                      <button
                        type="button"
                        onClick={() => startEdit(t)}
                        disabled={busy === t.id}
                        title="Edit this tag"
                        className="shrink-0 rounded-lg p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
                      >
                        <Pencil className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => remove(t.id)}
                        disabled={busy === t.id}
                        title="Remove this tag"
                        className="shrink-0 rounded-lg p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-red-500"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  );
                })
              )}
            </div>

            {listError && <p className="shrink-0 text-[11px] text-red-400">{listError}</p>}

            {displayActiveId && isAdmin && (
              <button
                type="button"
                onClick={() => setPendingActiveId(null)}
                disabled={busy === "clear"}
                className="shrink-0 text-[11px] font-medium text-muted-foreground transition-colors hover:text-foreground"
              >
                Clear active tag — stop auto-tagging new email resumes
              </button>
            )}
            {activeId && !isAdmin && (
              <p className="shrink-0 text-[11px] text-muted-foreground">
                Only an Admin can change or clear the active source tag.
              </p>
            )}

            {hasPendingActiveChange && (
              <div className="shrink-0 flex items-center gap-2 rounded-lg border border-amber-400/40 bg-amber-400/5 px-2.5 py-2">
                <p className="min-w-0 flex-1 text-[11px] text-foreground">
                  {pendingActiveId === null ? (
                    <>Ready to clear the active tag — new resumes will show as "No Source tagged" until saved.</>
                  ) : (
                    <>
                      Ready to make{" "}
                      <span className="font-semibold">{tags.find((t) => t.id === pendingActiveId)?.label}</span>{" "}
                      the active tag — nothing changes until you save.
                    </>
                  )}
                </p>
                <button
                  type="button"
                  onClick={saveActiveChange}
                  disabled={busy === "clear" || busy === pendingActiveId}
                  className="inline-flex shrink-0 items-center gap-1.5 rounded-lg bg-primary px-2.5 py-1.5 text-[11px] font-semibold text-primary-foreground transition-colors hover:bg-primary/90 disabled:opacity-50"
                >
                  {busy === "clear" || busy === pendingActiveId ? (
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  ) : (
                    <Save className="h-3.5 w-3.5" />
                  )}
                  Save changes
                </button>
                <button
                  type="button"
                  onClick={cancelActiveChange}
                  disabled={busy === "clear" || busy === pendingActiveId}
                  className="shrink-0 rounded-lg border border-border px-2.5 py-1.5 text-[11px] font-semibold text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground disabled:opacity-50"
                >
                  Cancel
                </button>
              </div>
            )}
          </div>

          {sampleDataCfg?.toggle_shown && (
            <div className="flex shrink-0 items-center gap-2 rounded-lg border border-border/60 bg-secondary/30 px-2.5 py-2">
              <div className="min-w-0 flex-1">
                <div className="text-xs font-medium text-foreground">Show "Sample Data" in source filters</div>
                <div className="truncate text-[10px] text-muted-foreground">
                  The demo candidate's source tag, in Dashboard/Screening/Pool pickers — always hidden in production
                </div>
              </div>
              <div className="flex shrink-0 items-center gap-2">
                <Toggle value={sampleDataCfg.visible} onChange={toggleSampleData} disabled={sampleDataSaving} />
                {sampleDataSaving && <Loader2 className="h-3.5 w-3.5 animate-spin text-muted-foreground" />}
              </div>
            </div>
          )}
        </div>

        <div className="flex items-center justify-end border-t border-border px-5 py-3">
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-secondary"
          >
            Done
          </button>
        </div>
      </div>

      <SourceFunnelHealthModal sourceLabel={funnelFor} onClose={() => setFunnelFor(null)} />

      <ConfirmDialog
        open={!!confirmEnableFor}
        title="Let Recruiters apply the predicted NBA for this source?"
        message={
          <>
            Recruiters will be able to apply the predicted Next Best Action — and directly schedule
            rounds — for any candidate tagged{" "}
            <span className="font-semibold text-foreground">{confirmEnableFor}</span>, without an
            Admin reviewing them first. This applies only to candidates from this source.
          </>
        }
        confirmLabel="Enable"
        pending={setRecruiterApply.isPending}
        onCancel={() => setConfirmEnableFor(null)}
        onConfirm={() => {
          if (confirmEnableFor) setRecruiterApply.mutate({ source: confirmEnableFor, enabled: true });
          setConfirmEnableFor(null);
        }}
      />

      <ConfirmDialog
        open={confirmClearActive}
        tone="destructive"
        title="Clear the active source tag?"
        message={
          <>
            New email resumes will stop being auto-tagged with{" "}
            <span className="font-semibold text-foreground">
              {tags.find((t) => t.id === activeId)?.label ?? "the active tag"}
            </span>
            . Until another tag is made active, they'll show as{" "}
            <span className="font-semibold text-foreground">"No Source tagged"</span>.
          </>
        }
        confirmLabel="Clear active tag"
        pendingLabel="Clearing…"
        pending={busy === "clear"}
        onCancel={() => { setConfirmClearActive(false); setPendingActiveId(undefined); }}
        onConfirm={async () => {
          setConfirmClearActive(false);
          const ok = await activate(null);
          if (ok) setPendingActiveId(undefined);
        }}
      />
    </div>
  );
}
