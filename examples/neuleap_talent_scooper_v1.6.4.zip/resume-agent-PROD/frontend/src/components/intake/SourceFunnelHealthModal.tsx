// Per-source-tag "process health" funnel — opened from the funnel icon on a
// source row in Register Source. Shows, for THIS tag only, the actual number
// of candidates that flowed through every recruitment stage till date, who is
// being processed right now, and the OLDEST candidate still waiting at each
// stage — then continues through the post-hire Hiring/Onboarding progression.
// A retired/completed source (nobody in flight anywhere) reads as one clean
// green banner. All computed client-side from the same ["candidates"] +
// ["analytics","rounds"] queries the Dashboard/Process Flow pages use.
import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { X, Filter, CheckCircle2, XCircle, PauseCircle, Clock3, Loader2 } from "lucide-react";
import { candidatesService } from "@/services/candidates";
import { analyticsService } from "@/services/analytics";
import { sourceOf } from "@/lib/source";
import { cn } from "@/lib/utils";
import {
  bucketOf,
  agingDaysFor,
  BUCKET_COLOR,
  type RoundBucket,
} from "@/lib/rounds";
import {
  ONBOARDING_STAGE_ORDER,
  ONBOARDING_STAGE_LABELS,
  ONBOARDING_STAGE_COLOR,
  onboardingStageOf,
} from "@/lib/onboarding";
import type { CandidateMaster } from "@/types/candidate";

// hex + alpha → rgba — same glassy-material recipe as the Process Flow skins.
function hexA(hex: string, alpha: number): string {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${alpha})`;
}

// Interview-round sequence and how each recruitment bucket maps onto it —
// mirrors the Process Flow page ("Round 2" bucket also holds the optional
// Round 3). "Reached till date" = the candidate's furthest position is at or
// past the bucket's first stage (Hired counts beyond Final).
const STAGE_SEQ = ["Screening", "Round 1", "Round 2", "Round 3", "Final"];
const FUNNEL_BUCKETS: { bucket: RoundBucket; firstIdx: number; lastIdx: number }[] = [
  { bucket: "Screening", firstIdx: 0, lastIdx: 0 },
  { bucket: "Round 1", firstIdx: 1, lastIdx: 1 },
  { bucket: "Round 2", firstIdx: 2, lastIdx: 3 },
  { bucket: "Final", firstIdx: 4, lastIdx: 4 },
];
function reachedIdx(c: CandidateMaster): number {
  if (c.status === "Hired") return STAGE_SEQ.length;
  return STAGE_SEQ.indexOf((c.roundname ?? "").trim());
}

interface StageRow {
  key: string;
  label: string;
  color: string;
  reached: number; // processed through till date (ever got here)
  inFlight: number; // sitting here right now
  rejectedHere: number;
  oldest: { name: string; days: number } | null; // oldest still waiting here
}

function OldestChip({ oldest }: { oldest: { name: string; days: number } | null }) {
  if (!oldest) return null;
  const tone =
    oldest.days > 30
      ? "border-rose-500/30 bg-rose-500/10 text-rose-600"
      : oldest.days > 15
        ? "border-amber-500/30 bg-amber-500/10 text-amber-600"
        : "border-border bg-card/60 text-muted-foreground";
  return (
    <span
      title={`Oldest still waiting at this stage: ${oldest.name} — ${oldest.days} day${oldest.days === 1 ? "" : "s"}`}
      className={cn("inline-flex w-max items-center gap-1 rounded-full border px-2 py-0.5 text-[9px] font-semibold", tone)}
    >
      <Clock3 className="h-2.5 w-2.5" />
      oldest {oldest.days}d · {oldest.name}
    </span>
  );
}

// One glassy funnel row: centered bar sized by "reached till date", flanked by
// the live in-flight story on the right.
function FunnelRow({ row, max }: { row: StageRow; max: number }) {
  return (
    <div className="flex items-center gap-2.5">
      <span className="w-24 shrink-0 truncate text-right text-[10px] font-medium text-muted-foreground">
        {row.label}
      </span>
      <div className="flex min-w-0 flex-1 justify-center">
        <div
          className="flex h-7 items-center justify-center rounded-full border backdrop-blur-md transition-all duration-300"
          style={{
            width: `${max > 0 ? Math.max(12, (row.reached / max) * 100) : 12}%`,
            backgroundImage: `linear-gradient(155deg, ${hexA(row.color, row.reached > 0 ? 0.34 : 0.1)}, ${hexA(row.color, row.reached > 0 ? 0.12 : 0.04)})`,
            borderColor: hexA(row.color, row.reached > 0 ? 0.55 : 0.2),
          }}
          title={`${row.reached} candidate${row.reached === 1 ? "" : "s"} processed through ${row.label} till date`}
        >
          <span className={cn("text-[11px] font-extrabold tabular-nums", row.reached > 0 ? "text-ink" : "text-ink-mute")}>
            {row.reached}
          </span>
        </div>
      </div>
      <div className="flex w-48 shrink-0 flex-col items-start gap-1">
        {row.inFlight > 0 ? (
          <span
            title={`${row.inFlight} candidate${row.inFlight === 1 ? "" : "s"} being processed at this stage right now`}
            className="inline-flex w-max items-center gap-1 rounded-full border px-2 py-0.5 text-[9px] font-semibold"
            style={{
              borderColor: hexA(row.color, 0.4),
              backgroundColor: hexA(row.color, 0.12),
              color: row.color,
            }}
          >
            <Loader2 className="h-2.5 w-2.5" /> {row.inFlight} in progress
          </span>
        ) : (
          <span className="inline-flex w-max items-center gap-1 rounded-full border border-emerald-500/25 bg-emerald-500/5 px-2 py-0.5 text-[9px] font-semibold text-emerald-600/80">
            <CheckCircle2 className="h-2.5 w-2.5" /> clear
          </span>
        )}
        <OldestChip oldest={row.oldest} />
        {row.rejectedHere > 0 && (
          <span
            title={`${row.rejectedHere} rejected at this stage`}
            className="inline-flex w-max items-center gap-1 rounded-full border border-rose-500/25 bg-rose-500/5 px-2 py-0.5 text-[9px] font-semibold text-rose-600/90"
          >
            <XCircle className="h-2.5 w-2.5" /> {row.rejectedHere} rejected here
          </span>
        )}
      </div>
    </div>
  );
}

export default function SourceFunnelHealthModal({
  sourceLabel,
  onClose,
}: {
  sourceLabel: string | null;
  onClose: () => void;
}) {
  const open = sourceLabel != null;
  const { data: allCandidates = [], isLoading } = useQuery({
    queryKey: ["candidates"],
    queryFn: async () => (await candidatesService.list()).data,
    enabled: open,
  });
  const { data: analytics } = useQuery({
    queryKey: ["analytics", "rounds"],
    queryFn: async () => (await analyticsService.rounds()).data,
    enabled: open,
  });
  const agingByCandidate = useMemo(() => {
    const m = new Map<string, number>();
    (analytics?.candidates ?? []).forEach((c) => m.set(c.candidate_id, c.aging_days));
    return m;
  }, [analytics]);

  const cands = useMemo(
    () => allCandidates.filter((c) => sourceOf(c) === sourceLabel),
    [allCandidates, sourceLabel],
  );

  const model = useMemo(() => {
    if (!open) return null;
    const total = cands.length;
    const hiredList = cands.filter((c) => c.status === "Hired");

    const oldestOf = (list: CandidateMaster[]): { name: string; days: number } | null => {
      let best: { name: string; days: number } | null = null;
      for (const c of list) {
        const days = agingDaysFor(c, agingByCandidate);
        if (days == null) continue;
        if (!best || days > best.days) best = { name: c.name || c.candidate_id, days };
      }
      return best;
    };

    // Intake row first (everything that arrived), then the interview rounds.
    const newInFlight = cands.filter((c) => bucketOf(c) === "New");
    const hasRound3 = cands.some((c) => (c.roundname ?? "").trim() === "Round 3");
    const rows: StageRow[] = [
      {
        key: "New",
        label: "Received (New)",
        color: BUCKET_COLOR.New,
        reached: total,
        inFlight: newInFlight.length,
        rejectedHere: 0,
        oldest: oldestOf(newInFlight),
      },
      ...FUNNEL_BUCKETS.map(({ bucket, firstIdx, lastIdx }) => {
        const inFlight = cands.filter((c) => bucketOf(c) === bucket);
        return {
          key: bucket,
          label: bucket === "Round 2" && hasRound3 ? "Round 2 / 3" : bucket,
          color: BUCKET_COLOR[bucket],
          reached: cands.filter((c) => reachedIdx(c) >= firstIdx).length,
          inFlight: inFlight.length,
          rejectedHere: cands.filter((c) => {
            if (bucketOf(c) !== "Reject") return false;
            const i = STAGE_SEQ.indexOf((c.roundname ?? "").trim());
            return i >= firstIdx && i <= lastIdx;
          }).length,
          oldest: oldestOf(inFlight),
        };
      }),
    ];

    // Post-hire progression — counts among Hired candidates; a candidate at
    // stage i has "reached" every earlier stage too.
    const onboardingRows = ONBOARDING_STAGE_ORDER.map((stage, idx) => {
      const atStage = hiredList.filter(
        (c) => ONBOARDING_STAGE_ORDER.indexOf(onboardingStageOf(c.onboarding_stage)) === idx,
      );
      return {
        stage,
        label: ONBOARDING_STAGE_LABELS[stage],
        color: ONBOARDING_STAGE_COLOR[stage],
        reached: hiredList.filter(
          (c) => ONBOARDING_STAGE_ORDER.indexOf(onboardingStageOf(c.onboarding_stage)) >= idx,
        ).length,
        atNow: atStage.length,
        isTerminal: stage === "onboarding_complete",
      };
    });

    const rejected = cands.filter((c) => bucketOf(c) === "Reject").length;
    const undecided = cands.filter((c) => bucketOf(c) === "Undecided").length;
    const recruitingInFlight = rows.reduce((s, r) => s + r.inFlight, 0);
    const onboardingInFlight = hiredList.filter(
      (c) => onboardingStageOf(c.onboarding_stage) !== "onboarding_complete",
    ).length;
    return {
      total,
      hired: hiredList.length,
      rejected,
      undecided,
      rows,
      onboardingRows,
      recruitingInFlight,
      onboardingInFlight,
      clean: recruitingInFlight === 0 && onboardingInFlight === 0,
    };
  }, [open, cands, agingByCandidate]);

  if (!open || !model) return null;
  const maxReached = Math.max(1, ...model.rows.map((r) => r.reached));
  const maxOnb = Math.max(1, ...model.onboardingRows.map((r) => r.reached));

  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center bg-foreground/40 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="flex max-h-[88vh] w-full max-w-3xl flex-col overflow-hidden rounded-2xl border border-border/60 bg-card/80 shadow-xl backdrop-blur-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3 border-b border-border/60 px-5 py-3.5">
          <div className="flex min-w-0 items-start gap-2.5">
            <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-primary/30 bg-primary/10 text-primary">
              <Filter className="h-3.5 w-3.5" />
            </span>
            <div className="min-w-0">
              <h2 className="truncate text-sm font-bold text-foreground">
                Process health — {sourceLabel}
              </h2>
              <p className="text-[11px] text-muted-foreground">
                Actual candidates processed till date, who's in flight now, and the oldest one
                waiting at each stage
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="min-h-0 flex-1 space-y-4 overflow-y-auto px-5 py-4">
          {isLoading ? (
            <div className="flex items-center justify-center gap-2 py-10 text-xs text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" /> Loading candidates…
            </div>
          ) : model.total === 0 ? (
            <p className="py-10 text-center text-xs text-muted-foreground">
              No candidates have arrived under this source tag yet.
            </p>
          ) : (
            <>
              {/* Health banner — a finished/retired source reads as one clean line. */}
              {model.clean ? (
                <div className="flex items-center gap-2 rounded-xl border border-emerald-500/30 bg-emerald-500/10 px-3 py-2.5">
                  <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-600" />
                  <p className="text-[11px] font-medium text-emerald-700 dark:text-emerald-400">
                    Clean — nothing is being processed for this source. All {model.total} candidate
                    {model.total === 1 ? "" : "s"} reached a final state
                    {model.hired > 0 &&
                      ` (${model.hired} hired${model.onboardingRows[model.onboardingRows.length - 1].atNow > 0 ? `, ${model.onboardingRows[model.onboardingRows.length - 1].atNow} fully onboarded` : ""})`}
                    .
                  </p>
                </div>
              ) : (
                <div className="flex items-center gap-2 rounded-xl border border-sky-500/30 bg-sky-500/10 px-3 py-2.5">
                  <Loader2 className="h-4 w-4 shrink-0 text-sky-600" />
                  <p className="text-[11px] font-medium text-sky-700 dark:text-sky-400">
                    {model.recruitingInFlight > 0 &&
                      `${model.recruitingInFlight} candidate${model.recruitingInFlight === 1 ? "" : "s"} in the recruitment funnel`}
                    {model.recruitingInFlight > 0 && model.onboardingInFlight > 0 && " · "}
                    {model.onboardingInFlight > 0 &&
                      `${model.onboardingInFlight} hired candidate${model.onboardingInFlight === 1 ? "" : "s"} still in hiring/onboarding`}
                    .
                  </p>
                </div>
              )}

              {/* Recruitment funnel — bar width = candidates processed through till date. */}
              <div>
                <span className="mb-2 block text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                  Recruitment funnel — processed till date
                </span>
                <div className="space-y-2 rounded-2xl border border-border/50 bg-card/40 px-3 py-3 backdrop-blur-md dark:bg-card/30">
                  {model.rows.map((row) => (
                    <FunnelRow key={row.key} row={row} max={maxReached} />
                  ))}
                  {/* Terminal outcomes for the whole source */}
                  <div className="flex flex-wrap items-center justify-center gap-2 border-t border-border/40 pt-2.5">
                    <span className="inline-flex items-center gap-1 rounded-full border border-blue-500/30 bg-blue-500/10 px-2.5 py-1 text-[10px] font-bold text-blue-600">
                      <CheckCircle2 className="h-3 w-3" /> Hired {model.hired}
                    </span>
                    <span className="inline-flex items-center gap-1 rounded-full border border-rose-500/30 bg-rose-500/10 px-2.5 py-1 text-[10px] font-bold text-rose-600">
                      <XCircle className="h-3 w-3" /> Rejected {model.rejected}
                    </span>
                    <span className="inline-flex items-center gap-1 rounded-full border border-amber-500/30 bg-amber-500/10 px-2.5 py-1 text-[10px] font-bold text-amber-600">
                      <PauseCircle className="h-3 w-3" /> Undecided {model.undecided}
                    </span>
                  </div>
                </div>
              </div>

              {/* Hiring & Onboarding — only when someone was actually hired. */}
              {model.hired > 0 && (
                <div>
                  <span className="mb-2 block text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                    Hiring &amp; onboarding — {model.hired} hired
                  </span>
                  <div className="space-y-1.5 rounded-2xl border border-border/50 bg-card/40 px-3 py-3 backdrop-blur-md dark:bg-card/30">
                    {model.onboardingRows.map((r) => (
                      <div key={r.stage} className="flex items-center gap-2.5">
                        <span className="w-40 shrink-0 truncate text-right text-[10px] font-medium text-muted-foreground">
                          {r.label}
                        </span>
                        <div className="flex min-w-0 flex-1 justify-center">
                          <div
                            className="flex h-5 items-center justify-center rounded-full border backdrop-blur-md transition-all duration-300"
                            style={{
                              width: `${Math.max(12, (r.reached / maxOnb) * 100)}%`,
                              backgroundImage: `linear-gradient(155deg, ${hexA(r.color, r.reached > 0 ? 0.34 : 0.1)}, ${hexA(r.color, r.reached > 0 ? 0.12 : 0.04)})`,
                              borderColor: hexA(r.color, r.reached > 0 ? 0.55 : 0.2),
                            }}
                            title={`${r.reached} of the hired candidates reached "${r.label}"`}
                          >
                            <span className={cn("text-[10px] font-extrabold tabular-nums", r.reached > 0 ? "text-ink" : "text-ink-mute")}>
                              {r.reached}
                            </span>
                          </div>
                        </div>
                        <span className="w-28 shrink-0 text-[9px] font-semibold">
                          {r.atNow > 0 ? (
                            <span
                              className="inline-flex items-center gap-1 rounded-full border px-2 py-0.5"
                              style={{
                                borderColor: hexA(r.color, 0.4),
                                backgroundColor: hexA(r.color, 0.12),
                                color: r.color,
                              }}
                            >
                              {r.isTerminal ? <CheckCircle2 className="h-2.5 w-2.5" /> : <Loader2 className="h-2.5 w-2.5" />}
                              {r.atNow} {r.isTerminal ? "complete" : "here now"}
                            </span>
                          ) : (
                            <span className="text-muted-foreground/50">—</span>
                          )}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        <div className="flex items-center justify-end border-t border-border/60 px-5 py-3">
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-secondary"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
