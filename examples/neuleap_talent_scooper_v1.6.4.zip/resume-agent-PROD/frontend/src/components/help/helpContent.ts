import type { UserRole } from "@/services/auth";

// ── In-app User Manual content ───────────────────────────────────────────────
// Mirrors the shared "Talents Scooper — User Manual" deck, filtered per role:
// every section/card/step declares which roles it applies to (omitted = all
// three login roles), so a Recruitment Manager isn't shown Mailbox/Settings
// chapters they can't open, and a System Admin isn't shown recruiting-only
// workflow they don't have.

export type HelpTone = "brand" | "emerald" | "amber" | "rose" | "sky" | "violet";

export interface HelpCard {
  heading: string;
  tone: HelpTone;
  bullets: string[];
  roles?: UserRole[];
}

export interface HelpStep {
  heading: string;
  detail: string;
  roles?: UserRole[];
}

export interface HelpSection {
  id: string;
  title: string;
  roles?: UserRole[];
  intro?: string;
  cards?: HelpCard[];
  steps?: HelpStep[];
  qa?: { q: string; a: string; roles?: UserRole[] }[];
}

export const HELP_SECTIONS: HelpSection[] = [
  {
    id: "getting-started",
    title: "Getting started & accounts",
    cards: [
      {
        heading: "Sign in",
        tone: "brand",
        bullets: [
          "New accounts arrive by EMAIL — click the link in your invite to set your OWN password, then sign in.",
          "No admin ever types your password, so your account is always tied to a real, working email.",
          "Change it anytime later: avatar (top-right) → Change password.",
        ],
      },
      {
        heading: "Forgot / compromised password",
        tone: "amber",
        bullets: [
          "Self-service: click \"Forgot password?\" on the sign-in page — a reset link is emailed to you (valid 1 hour, single-use).",
          "You set your own new password from the link — nothing to memorise from anyone.",
          "No email arriving? An Admin can still reset it: Settings → User Management → key icon (a value shown once).",
        ],
      },
      {
        heading: "Know your role",
        tone: "emerald",
        bullets: [
          "The avatar menu shows your role chip: Admin · Recruitment Manager · System Admin.",
          "Recruitment Managers: recruiting pages only (no Settings/Mailbox).",
          "System Admins: back-office only (no NBA overrides).",
        ],
      },
      {
        heading: "Environment awareness",
        tone: "sky",
        bullets: [
          "The clay badge next to the bell reads QA / PROD / DEV.",
          "QA = all candidate email is redirected to the test inbox; PROD = real sends.",
          "Admins: click the badge for the safety briefing and PRD switch steps.",
          "Every page's hero bar has a Refresh button — pulls the latest data in-app without a browser reload.",
          "QA only: click the Version pill (sidebar footer) for this build's changelog — features, fixes and watch-outs, with previous versions under More.",
        ],
      },
      {
        heading: "Report a bug / request a feature",
        tone: "violet",
        bullets: [
          "Sidebar → \"Report a bug / request a feature\" (available to every role).",
          "Pick Bug or Feature, add a title + details, then set two dimensions: a priority P1 (critical) – P5 (nice to have) for URGENCY, and a MoSCoW class (Must / Should / Could / Won't have) for IMPORTANCE.",
          "Your name + email are attached automatically, so the team knows who to follow up with.",
          "Admins review everything under Settings → Feedback and can export it to Excel.",
        ],
      },
    ],
  },
  {
    id: "happy-path",
    title: "Your first campaign — the happy path",
    intro:
      "The eight steps a campaign takes from job post to hire. Steps outside your role are handled by a colleague — they're shown greyed for context where relevant.",
    steps: [
      {
        heading: "Register the source tag",
        detail:
          'Mailbox → "Register recent social post as a source tag" → save → make it ACTIVE (Admin). Replies now auto-tag.',
        roles: ["admin", "sysadmin"],
      },
      {
        heading: "Run the pipeline",
        detail: "Mailbox → Run pipeline (or wait for the schedule). Watch Processed / Needs Review counts fill in.",
        roles: ["admin", "sysadmin"],
      },
      {
        heading: "Size the interview pool",
        detail:
          "Gear drawer → Interview Time-slot Pools → create a pool for the source + rounds → Make placeholders.",
        roles: ["admin", "sysadmin"],
      },
      {
        heading: "Triage on the Dashboard",
        detail: "Open New Potential Candidates, read the predicted NBA reasoning, click Apply (or bulk apply).",
        roles: ["admin", "recruiter"],
      },
      {
        heading: "Send the invite",
        detail:
          "Draft badge → review → Insert link for [ Interview time-slots picking ] → Mark ready → Send.",
        roles: ["admin", "recruiter"],
      },
      {
        heading: "Let the loop run",
        detail:
          'Candidate books (Teams meeting auto-created) or gets Reminder 1..Y, then auto-reject. Watch for the red "!" help requests.',
      },
      {
        heading: "Interview & verdict",
        detail:
          "Mint the interviewer link from the candidate row; the interviewer submits feedback, a score and a verdict.",
        roles: ["admin", "recruiter"],
      },
      {
        heading: "Track to hire",
        detail:
          "Process Flow shows the funnel per source; verdicts advance candidates until Hire → onboarding stages.",
      },
    ],
  },
  {
    id: "mailbox",
    title: "Mailbox — intake & processing",
    roles: ["admin", "sysadmin"],
    cards: [
      {
        heading: "Daily loop",
        tone: "brand",
        bullets: [
          "Status card: Idle/Running · Needs Review · Resolved · mini stats donut (click to expand; defaults to the active source).",
          "Run pipeline processes everything staged + new mail.",
          "Emails/Uploads table: search + source filter live in the tabs row; per-file pass/fail badges; Audit link per row.",
        ],
      },
      {
        heading: "Source tags",
        tone: "emerald",
        bullets: [
          "ONE tag is active at a time — it auto-stamps every email resume.",
          "Changing/clearing the active tag: Admin only, and only on Save.",
          "Tags already carrying data can never be deleted; uploads always type their own source.",
          "Funnel icon on a tag's row → process-health popup: actual candidates through every stage till date, live in-flight counts, and the oldest one waiting per stage (clean green banner once a source is done).",
        ],
      },
      {
        heading: "Gear drawer (hero bar)",
        tone: "violet",
        bullets: [
          "Interview Time-slot Pools — sizing table (Target/Existing/Gap) + per-round picker URLs + Make placeholders.",
          "Batch Archive — archive/restore per source; Admin: prune + System Cleanup (QA).",
          "Email Base Templates — edit what every draft starts from (warning-gated; per-template Reset).",
          "Mailbox Account — the scanned inbox, its encrypted credentials and per-outcome folders (SysAdmin edits, own-password confirmed).",
        ],
      },
      {
        heading: "Needs Review",
        tone: "amber",
        bullets: [
          "Every file the pipeline couldn't auto-process, with its reason (duplicate, not-a-resume, corrupt…).",
          "Approve or discard each; resolved items move to the Resolved tab.",
        ],
      },
    ],
  },
  {
    id: "dashboard",
    title: "Dashboard & Candidates — triage to action",
    roles: ["admin", "recruiter"],
    cards: [
      {
        heading: "Dashboard panels",
        tone: "brand",
        bullets: [
          "New Potential Candidates — ALWAYS ranked highest-NLRS-first (resets to that on every page load); Apply the predicted NBA (single or bulk).",
          "Columns include Certificates, CGPA and Passout Year. The raw ATS & NLRS score columns are opt-in — turn them on in Settings → Legacy Features (hiding them never changes the ranking).",
          "Candidates being Processed — slots shared · reminders · reminder drafts to review · scheduled · Final.",
          "Hire / Rejected / Undecided — outcomes panel; filters for source, year, month + name search.",
        ],
      },
      {
        heading: 'Red "!" — help requests',
        tone: "rose",
        bullets: [
          'A pulsing red "!" next to a stage chip = the candidate sent a Need-help message from the slot picker.',
          "Click it → read the message → take the right action → Mark handled.",
          "The message stays permanently in the candidate's Actions Audit Log.",
        ],
      },
      {
        heading: "NBA & drafts",
        tone: "emerald",
        bullets: [
          '"Why this prediction" now gives the fuller read for EVERY prediction: a numbered list of reasons plus Strengths / Concerns, grounded in the candidate\'s Analysis Report (fast-tracked candidates keep their distinct "skip ahead" framing).',
          "Admin Change offers only FORWARD stages; emailing NBAs generate a draft.",
          "Every Apply / Change asks for a comment (popup with Cancel/Apply) — it's recorded in the Actions Audit Log; bulk applies stamp the same comment on all affected candidates, marked (bulk-apply).",
          "Draft review: edit text, insert the slot-picker link (round pre-selected), Mark ready, Send.",
        ],
      },
      {
        heading: "Candidates (Screening) page",
        tone: "violet",
        bullets: [
          "Configurable columns (17+ extracted fields), bulk filters, certificate/keyword search.",
          "Excel-sourced intakes keep EVERY sheet column on the candidate as a selectable \"…(sheet)\" column — turn on the ones you want via the Columns picker (off by default so the table isn't flooded). Existing candidates backfill only when their Excel source is re-processed.",
          "If the sheet has a CGPA column, it's the source of truth (CGPA also weighs 30% in NLRS); the resume-extracted value is kept alongside as \"CGPA (resume)\".",
          "Match JD (Admin only — token-intensive): paste/upload a job description to score everyone your filters show. Shortlist with filters FIRST — cost grows with the candidate count. Click any score for the WHY: dimension breakdown, what meets the JD, what's missing.",
          "Rounds drawer per candidate; Round History shows merged Fast-tracked cards with the recorded reason.",
        ],
      },
    ],
  },
  {
    id: "scheduling",
    title: "Scheduling & interviewing",
    cards: [
      {
        heading: "Pools → placeholders",
        tone: "emerald",
        roles: ["admin", "sysadmin"],
        bullets: [
          "Create a pool per campaign: source + rounds + date range + allowed days/hours.",
          "Per-day windows: Full day, Early morning (8–10), AM (10–14), PM (14–18), Late evening (18–21), Full day extended (8–21), or None. A \"Reset to defaults\" button restores the shipped rules any time.",
          "The Final round defaults to a scarcer pattern — Tue/Wed/Thu afternoons only, at most 20% of the day.",
          "Review the per-round Target/Existing/Gap table (funnel- and NBA-aware; override the projection if needed).",
          "Default rules: one slider per round with a live 100-candidate funnel preview — Calculate & save re-targets every pool.",
          "Make placeholders books codename holds (Batman, HeMan…) on interviewers' calendars; verify any round via its picker URL.",
          "Adding more interviewers to a round adds PARALLEL capacity at each time — several candidates can book the same slot.",
        ],
      },
      {
        heading: "Candidate side",
        tone: "sky",
        bullets: [
          "Invite email → /schedule page → email one-time code → pick a slot.",
          "When several interviewers cover a time, the picker shows how many are still open (\"N left\") and books each candidate with a free one — no more \"that slot was just taken\" while capacity remains.",
          "Booking converts the hold into a real Teams meeting; confirmations go to both sides.",
          "No pick → Reminder X of Y on your cadence → auto-reject when the window closes (all audited).",
        ],
      },
      {
        heading: "Interviewer side",
        tone: "violet",
        roles: ["admin", "recruiter"],
        bullets: [
          "Mint links from the candidate row (or automatic after booking).",
          "Questions kit: regenerate, difficulty/effort/focus, Add to feedback sheet; emoji score 0–10.",
          "Verdicts: Move to Round N+1 … Final · Can be Hired · Reject — skipping a round requires a written reason.",
          "Submitting a verdict tees up the next email automatically: a Pass / advance drafts the next round's slot-share; a Fail drafts a polite decline — sent on your action, or auto if auto-send is configured.",
          "Question-bank leaderboard: the (i) on a candidate opens their full response sheet (each question, their answer, mark, model answer + explanation), with the interviewer's name, round and slot.",
        ],
      },
      {
        heading: "Testing shortcuts",
        tone: "amber",
        roles: ["admin", "sysadmin"],
        bullets: [
          "Settings → Interviewer Access → sample links for every round (Screening/R1/R2/Final), each resettable.",
          "QA only: set reminder interval & auto-reject window in MINUTES to rehearse the full cycle live.",
          "Checking a picker URL from the pool table? Open it and pick \"Checking this link as staff?\" — verify with your Admin/SysAdmin credentials instead of the candidate's emailed code (audited).",
        ],
      },
    ],
  },
  {
    id: "settings",
    title: "Settings & administration",
    roles: ["admin", "sysadmin"],
    cards: [
      {
        heading: "User Management",
        tone: "brand",
        bullets: [
          "Invite users by email: enter their email + role → they get an emailed link to set their OWN password (no admin-typed password), so every account is tied to a valid, reachable email.",
          "If outbound email isn't configured, the invite link is shown for you to relay manually.",
          "Key icon (Admin) resets a password to a generated value shown once; the last Admin can never be deleted.",
        ],
      },
      {
        heading: "Feedback — bug reports & requests",
        tone: "sky",
        bullets: [
          "Settings → Feedback: every in-app bug report + feature request users have filed, with the reporter, a P1–P5 priority AND a MoSCoW class (Must / Should / Could / Won't have).",
          "Triage each one's status (Open · In progress · Resolved · Closed), delete, or Export to Excel (priority + MoSCoW included).",
        ],
      },
      {
        heading: "Interview Scheduling",
        tone: "emerald",
        bullets: [
          "Slot duration (minutes) · Reminders before auto-reject (emails).",
          "Reminder interval (hours — or minutes in QA) · Auto-reject after (days — or minutes in QA).",
          "QA calendar email doubles as the availability calendar AND the QA redirect target.",
        ],
      },
      {
        heading: "Email Send Controls",
        tone: "amber",
        bullets: [
          "Auto-send + draft-review-required govern every generated email, reminders included.",
          "Turning draft review OFF requires re-entering your own password (real emails leave unattended).",
        ],
      },
      {
        heading: "Token Usage (left nav)",
        tone: "sky",
        roles: ["admin"],
        bullets: [
          "Tokenomics for every LLM call: totals + estimated cost, daily prompt-vs-completion chart.",
          "Consumption trend & 7-day forecast — overall + per-module lines with a dashed projection and a module multiselect.",
          "Optimization hints at the bottom — data-derived advice on cutting spend (shortlisting, cheaper per-module models, trimming inputs), recomputed for whatever source/time slice you're viewing.",
          "Breakdowns by module (extraction, analysis, questions, JD match, chatbot), source tag and model.",
          "Hero bar filters: source tag + time range (presets or custom dates). Costs are estimates, not a bill.",
        ],
      },
      {
        heading: "LLM Model Keys",
        tone: "rose",
        bullets: [
          "Settings → LLM Model Keys: endpoint, API key, API version, default + fallback deployment.",
          "Per-module overrides — give e.g. the chatbot a cheaper deployment or its own key; blank inherits global.",
          "Keys are encrypted at rest and never shown again; edits are SysAdmin-only with own-password confirmation and are audit-logged.",
        ],
      },
      {
        heading: "Other admin surfaces",
        tone: "violet",
        bullets: [
          "Extraction & Analysis / NLRS weights & bands — CGPA is now a component weighted 30% (second to the Analysis Report); a candidate with no CGPA is not penalised (its weight rescales). All weights stay tunable here.",
          "Legacy Features flags (temporary — now also gate the ATS & NLRS score columns on the dashboard) · table column layouts · candidate page sections · Interviewer Access domains · notifications.",
          "System Upgrade: applying a bundle first auto-saves a signed \"revert\" copy of the current version into the install drop folder, so you can always reinstall the version you left.",
          "Chatbot toggle: enabling asks for confirmation — every question spends tokens on TWO LLM calls, for every user; spend shows under Chatbot in Token Usage.",
          "Activity Log for the full cross-candidate audit trail.",
        ],
      },
    ],
  },
  {
    id: "external",
    title: "External users — candidates & interviewers",
    cards: [
      {
        heading: "What the CANDIDATE sees (/schedule/link)",
        tone: "sky",
        bullets: [
          "Opens the link from their invite email — no account needed; verifies their email with a mailed one-time code.",
          "Picks from real, live slots; booking instantly creates the Teams meeting and emails joining details.",
          '"Remind me again" opts into further nudges.',
          '"Need help?" (small link near the confirm button) sends a message straight to the team — it flags their row with a red "!".',
          "If the response window lapses: a polite expiry notice; the team sees the auto-reject in the audit log.",
        ],
      },
      {
        heading: "What the INTERVIEWER sees (/interview/link)",
        tone: "violet",
        bullets: [
          "Opens the link — verifies a company-domain email with a one-time code (remember-me optional).",
          "Reads a deliberately narrow candidate profile: skills, projects, scores, analysis — never compensation.",
          "Round history identical to the internal view, including Fast-tracked cards with promotion reasons.",
          "Generates a tailored questions kit; saves picked questions into the feedback sheet (the button disappears once the verdict is submitted).",
          "Records answers, overall comments, an emoji score (0–10).",
          "Submits a verdict: Move to Round N+1…Final · Can be Hired · Reject — leapfrogs require a written reason.",
          "Their verdict automatically advances the candidate and drafts the right next email for the team (next round's slot-share on a pass, a decline on a reject).",
        ],
      },
    ],
  },
  {
    id: "quick-answers",
    title: "Quick answers",
    qa: [
      {
        q: "A candidate says the slots don't work for them",
        a: "Their Need-help message is on their row (red !). Read it, extend the pool dates or add slots, resend the picker link, Mark handled.",
        roles: ["admin", "recruiter"],
      },
      {
        q: "Nothing got tagged with my campaign",
        a: "Check the Mailbox hero pill — is YOUR tag the ACTIVE one? Only one tag stamps email resumes at a time (uploads always ask).",
        roles: ["admin", "sysadmin"],
      },
      {
        q: "An email went out I didn't expect",
        a: "Settings → Email Send Controls: with draft review ON, nothing sends without a human click. Check the candidate's Audit Log for who/when.",
      },
      {
        q: "I need to test the whole reminder cycle quickly",
        a: "QA only: set reminder interval + auto-reject window to minutes, invite a QA-owned resume, watch the full loop run.",
        roles: ["admin", "sysadmin"],
      },
      {
        q: "The interviewer wants to skip a round",
        a: "They can — the verdict picker offers every later stage, and the popup records their justification into Round History.",
      },
      {
        q: "We hired someone — now what?",
        a: "The Hired candidate enters the Hiring Procedure (offer stages) then Onboarding; track both rows on the Process Flow page.",
      },
      {
        q: "Where do I see what the AI features cost us?",
        a: "Token Usage (left nav, Admin): every LLM call by module, source tag, day and model, with estimated cost. Metering starts from v1.2.0.",
        roles: ["admin"],
      },
      {
        q: "How do I point the app at a different AI model or key?",
        a: "Settings → LLM Model Keys. Set the global connection or a per-module override; a SysAdmin confirms with their own password. Environment variables stay as the fallback.",
        roles: ["admin", "sysadmin"],
      },
      {
        q: "How do I check a slot-picker link without the candidate's inbox?",
        a: "Open it from the pool table's Time-slot picker URL column and choose \"Checking this link as staff?\" — your Admin/SysAdmin credentials open it, and the visit is audit-logged.",
        roles: ["admin", "sysadmin"],
      },
      {
        q: "Why can't I see the Match JD button?",
        a: "It's Admin-only — one click sends every filtered candidate to the AI in a single large (token-intensive) call, so an Admin owns that spend. Ask an Admin to run it for your shortlist.",
        roles: ["recruiter"],
      },
      {
        q: "Does using the chatbot cost anything?",
        a: "Each question spends AI tokens on two LLM calls (query building + answer narration), metered under Chatbot on the Token Usage page. Keep questions specific; answers are read-only and AI-generated.",
      },
      {
        q: "I forgot my password",
        a: "Click \"Forgot password?\" on the sign-in page — a single-use reset link is emailed to you (valid 1 hour). No email arriving? Any Admin can still reset it from Settings → User Management (generated value, shown once). The system always keeps at least one Admin.",
      },
      {
        q: "How do I add a new user?",
        a: "Settings → User Management → enter their email + role → Invite. They receive an emailed link to set their own password; the account activates once they do. If email isn't configured, the link is shown for you to relay.",
        roles: ["admin", "sysadmin"],
      },
      {
        q: "How do I report a bug or ask for a feature?",
        a: "Sidebar → \"Report a bug / request a feature\": choose Bug or Feature, add details, then set a P1–P5 priority (urgency) and a MoSCoW class — Must / Should / Could / Won't have (importance). Your name/email are attached automatically. Admins review + export these under Settings → Feedback.",
      },
      {
        q: "My Excel sheet had extra columns / a CGPA — where did they go?",
        a: "Excel intakes now keep every sheet column on the candidate as a \"…(sheet)\" column — enable the ones you want via Candidates → Columns. A CGPA column becomes the source of truth (the resume value is kept as \"CGPA (resume)\"). Candidates imported before this build backfill only when their Excel source is re-processed.",
        roles: ["admin", "recruiter"],
      },
      {
        q: "The ATS / NLRS score columns disappeared from the dashboard",
        a: "They're now opt-in: Settings → Legacy Features → turn on the ATS / NLRS score columns. Hiding them never changes the ranking — candidates still sort highest-NLRS-first.",
        roles: ["admin", "sysadmin"],
      },
    ],
  },
];

const appliesTo = (roles: UserRole[] | undefined, role: UserRole) =>
  !roles || roles.includes(role);

/** The manual, narrowed to what THIS role can actually see and do. */
export function helpSectionsFor(role: UserRole): HelpSection[] {
  return HELP_SECTIONS.filter((s) => appliesTo(s.roles, role))
    .map((s) => ({
      ...s,
      cards: s.cards?.filter((c) => appliesTo(c.roles, role)),
      steps: s.steps?.filter((st) => appliesTo(st.roles, role)),
      qa: s.qa?.filter((q) => appliesTo(q.roles, role)),
    }))
    .filter((s) => (s.cards?.length ?? 0) + (s.steps?.length ?? 0) + (s.qa?.length ?? 0) > 0);
}
