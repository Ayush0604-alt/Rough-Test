import { useMemo, useState } from "react";
import { BookOpen, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/context/AuthContext";
import { helpSectionsFor, type HelpTone } from "./helpContent";

const ROLE_LABEL: Record<string, string> = {
  admin: "Admin",
  recruiter: "Recruitment Manager",
  sysadmin: "System Admin",
};

const TONE_CLS: Record<HelpTone, string> = {
  brand: "text-primary",
  emerald: "text-emerald-600",
  amber: "text-amber-600",
  rose: "text-rose-600",
  sky: "text-sky-600",
  violet: "text-violet-600",
};

/**
 * In-app User Manual — avatar menu → Help. Renders the shared manual content
 * (helpContent.ts) filtered to the signed-in role: a Recruitment Manager only
 * sees the chapters they can actually open, a System Admin skips the
 * recruiting-only workflow, an Admin sees everything.
 */
export default function HelpModal({ onClose }: { onClose: () => void }) {
  const { user } = useAuth();
  const role = user?.role ?? "recruiter";
  const sections = useMemo(() => helpSectionsFor(role), [role]);
  const [activeId, setActiveId] = useState(sections[0]?.id ?? "");
  const active = sections.find((s) => s.id === activeId) ?? sections[0];

  if (!active) return null;

  return (
    <div
      className="fixed inset-0 z-[70] flex items-center justify-center bg-foreground/50 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="flex h-[85vh] w-full max-w-4xl flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex shrink-0 items-start justify-between gap-3 border-b border-border px-5 py-3.5">
          <div className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
              <BookOpen className="h-4.5 w-4.5" />
            </span>
            <div>
              <h2 className="text-sm font-bold text-foreground">Help — User Manual</h2>
              <p className="text-[11px] text-muted-foreground">
                Showing the sections that apply to your role: {ROLE_LABEL[role] ?? role}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="flex min-h-0 flex-1">
          {/* chapter nav */}
          <nav className="w-56 shrink-0 space-y-0.5 overflow-y-auto border-r border-border p-2.5">
            {sections.map((s) => (
              <button
                key={s.id}
                type="button"
                onClick={() => setActiveId(s.id)}
                className={cn(
                  "block w-full rounded-lg px-2.5 py-2 text-left text-xs font-medium transition-colors",
                  s.id === active.id
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                )}
              >
                {s.title}
              </button>
            ))}
          </nav>

          {/* chapter body */}
          <div className="min-w-0 flex-1 overflow-y-auto p-5">
            <h3 className="mb-1 text-base font-bold text-foreground">{active.title}</h3>
            {active.intro && (
              <p className="mb-3 text-xs leading-relaxed text-muted-foreground">{active.intro}</p>
            )}

            {active.steps && (
              <ol className="mb-4 space-y-2.5">
                {active.steps.map((st, i) => (
                  <li key={st.heading} className="flex items-start gap-2.5">
                    <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary text-[11px] font-bold text-white">
                      {i + 1}
                    </span>
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-foreground">{st.heading}</p>
                      <p className="text-[11px] leading-relaxed text-muted-foreground">{st.detail}</p>
                    </div>
                  </li>
                ))}
              </ol>
            )}

            {active.cards && (
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                {active.cards.map((c) => (
                  <div key={c.heading} className="rounded-xl border border-border bg-secondary/30 p-3">
                    <h4 className={cn("mb-1.5 text-xs font-bold", TONE_CLS[c.tone])}>{c.heading}</h4>
                    <ul className="space-y-1 pl-4 text-[11px] leading-relaxed text-muted-foreground [list-style-type:disc]">
                      {c.bullets.map((b) => (
                        <li key={b}>{b}</li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            )}

            {active.qa && (
              <div className="space-y-3">
                {active.qa.map((item) => (
                  <div key={item.q} className="rounded-xl border border-border bg-secondary/30 p-3">
                    <p className="text-xs font-bold text-foreground">"{item.q}"</p>
                    <p className="mt-1 text-[11px] leading-relaxed text-muted-foreground">{item.a}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
