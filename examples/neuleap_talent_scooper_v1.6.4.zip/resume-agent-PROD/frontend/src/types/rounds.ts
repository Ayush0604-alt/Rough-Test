// Canonical interview-stage vocabulary (see constants/CANDIDATE_STAGES).
// candidate_master.roundname and rounds.round_name both use these names so the
// Rounds board and Screening page never disagree on a candidate's stage.
export type RoundName =
  | "New"
  | "Screening"
  | "Round 1"
  | "Round 2"
  | "Round 3"
  | "Final";

export type RoundOutcome = "Pass" | "Fail" | "Hold" | "Pending";

export interface Round {
  round_id: number;
  candidate_id: string;
  round_name: RoundName;
  domain: string;
  interviewer: string;
  current_ctc: number | null;
  expected_ctc: number | null;
  notice_period: number | null; // days; captured on the Screening round only
  relocation: boolean | null;
  scheduled_on: string | null;
  feedback: string | null;
  score: number | null;
  outcome: RoundOutcome | null;
  // Live Workflow email/acceptance sub-steps for THIS round (every round type).
  invite_sent_at?: string | null;
  reminder_count?: number; // capped at 2
  candidate_accepted_slot?: boolean | null;
}
