import type { ReviewKind, ReviewState } from "@/constants/status";

export type { ReviewKind, ReviewState };

// The email header a review item belongs to (joined from email_master).
export interface ReviewEmail {
  sender_mail_id: string | null;
  subject: string | null;
  received_date: string | null;
}

// A file or row the pipeline could not auto-process — surfaced in Screening so
// nothing is ever silently lost. One first-class `review_queue` row.
export interface ReviewItem {
  review_id: number;
  e_id: string | null;
  candidate_id: string | null;
  stage: string | null; // L1 | L2 | L3
  kind: ReviewKind;
  filename: string | null;
  raw_s3_key: string | null;
  reason: string | null;
  // Structured per-kind payload (e.g. excel row: {row_number,name,email,row_cells,…}).
  details: Record<string, unknown> | null;
  state: ReviewState;
  // For duplicates: the candidate_id this resume matched.
  duplicate_of: string | null;
  email: ReviewEmail | null;
  created_at: string;
  resolved_by: string | null;
  resolved_at: string | null;
}

// Review items grouped into one container per email (e_id).
export interface ReviewGroup {
  e_id: string;
  email: ReviewEmail | null;
  items: ReviewItem[];
}

export type ReviewAction = "resolve" | "discard";
