export type AuditLayer = "L1" | "L2" | "L3";

export type AuditStatus = "Success" | "Failed" | "Retry" | "Exhausted";

export interface AuditLog {
  log_id: number;
  batch_id: string | null;
  E_id: string;
  candidate_id: string | null;
  layer: AuditLayer;
  step: number;
  fail_reason: string | null;
  status: AuditStatus;
  fail_count: number;
  created_at: string;
}
