// Mirrors app/services/notifications.py :: _item().
export type NotificationSeverity = "action" | "health" | "info";

export interface AppNotification {
  id: string;                    // stable content key (e.g. candidate_hired:C1042)
  type: string;                  // manual_review | run_summary | new_p1 | …
  severity: NotificationSeverity;
  title: string;
  body: string | null;
  link: string | null;          // frontend route to deep-link to
  created_at: string | null;    // ISO; null sorts last
  read_at: string | null;       // ISO when read, else null (server-side read state)
}
