export type EmailAttachmentType =
  | "pdf"
  | "docx"
  | "image"
  | "excel"
  | "zip"
  | "link"
  | "mixed";

export type ExtractedStatus =
  | "Success"
  | `Success(${string})`
  | `Partial(${string})`
  | `Fail(${string})`
  | "Fail";

export type ProcessStatus = "Passed" | "Failed" | "Discarded";

// True downstream outcome (L2/L3), derived server-side from candidate_master +
// audit_log — not just L1's file-validation verdict.
export type FinalStatus =
  | "Processed"
  | "Queued"
  | "Duplicate"
  | "Not a Resume"
  | "Failed"
  | "Exhausted"
  | "Discarded"
  | "Rejected"
  | "Closed";

export interface EmailMaster {
  E_id: string;
  sender_mail_id: string;
  subject: string;
  received_date: string;
  attachment_names: string;
  extracted_status: ExtractedStatus;
  process_status: ProcessStatus;
  processed?: boolean;
  final_status?: FinalStatus | string;
  final_detail?: string;
  // The intake source stamped on this mail (recruiter-typed on manual upload,
  // or auto-stamped from the active Source Tag on Graph mail — see
  // app.services.source_tags). Null/blank for legacy rows or untagged intake.
  source?: string | null;
  // Count of resumes WITHIN this mail that failed L2/L3 (a Mixed/ZIP mail can pass
  // L1 yet carry files that fail downstream). 0 when the whole mail processed cleanly.
  // Append-only audit history — never decreases once a file has failed.
  failed_files?: number;
  // The actual reason behind failed_files — kept separate from final_detail,
  // which reports the arbitrary first candidate's status once ANY resume in
  // a multi-file mail succeeds, silently dropping the real failure reason for
  // the ones that didn't. Null when failed_files is 0.
  failed_reason?: string | null;
  // Open review_queue items still tied to this mail — the LIVE "needs a human"
  // signal that drops to 0 as a recruiter resolves them. Keeps an otherwise-processed
  // mail flagged as needing review until they're cleared.
  open_reviews?: number;
  // LLM token usage for this mail, aggregated server-side over every candidate
  // sharing this e_id (one mail → N resumes → N L3 extraction calls).
  total_tokens?: number; // total tokens for the whole mail
  avg_tokens?: number; // average tokens per candidate in this mail
  candidate_count?: number; // number of candidates/resumes produced by this mail
  // Mail aging (derived server-side, never stored): time since received_date.
  age_hours?: number | null;
  age_days?: number | null;
  aging_bucket?: AgingBucket | null;
  is_pending?: boolean; // arrived but not yet terminal — the backlog the report watches
}

// Hours-since-received buckets; thresholds mirror app/api/reads.py.
export type AgingBucket = "fresh" | "aging" | "stale" | "critical";
