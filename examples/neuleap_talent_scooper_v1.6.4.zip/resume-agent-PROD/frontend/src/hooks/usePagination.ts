import { useEffect, useMemo, useState } from "react";

export interface Pagination<T> {
  /** 1-based current page (clamped to the valid range). */
  page: number;
  setPage: (p: number) => void;
  /** Items belonging to the current page. */
  pageItems: T[];
  /** Total number of pages (>= 1). */
  pageCount: number;
  /** Total number of items across all pages. */
  total: number;
  pageSize: number;
  /** Zero-based index of the first item on the current page (for "Showing X–Y"). */
  startIndex: number;
}

/**
 * Client-side pagination over an in-memory list. The current page auto-clamps
 * when the list shrinks (e.g. after a filter change), so callers don't need to
 * reset the page themselves.
 */
export function usePagination<T>(items: T[], pageSize = 20): Pagination<T> {
  const [page, setPage] = useState(1);

  const total = items.length;
  // Jump back to the first page whenever the result size changes — e.g. after a
  // filter, tab switch, or search narrows the list.
  useEffect(() => {
    setPage(1);
  }, [total]);

  const pageCount = Math.max(1, Math.ceil(total / pageSize));
  const current = Math.min(Math.max(1, page), pageCount);
  const startIndex = (current - 1) * pageSize;

  const pageItems = useMemo(
    () => items.slice(startIndex, startIndex + pageSize),
    [items, startIndex, pageSize]
  );

  return { page: current, setPage, pageItems, pageCount, total, pageSize, startIndex };
}
