import { useCallback } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { notificationsService } from "@/services/notifications";
import type { AppNotification } from "@/types/notification";

/**
 * Polls the persisted notification feed and tracks read/unread on the SERVER:
 * an item is "unread" while its `read_at` is null. "Mark all read" calls the API,
 * which stamps `read_at`; read notifications are purged 24h later. No localStorage,
 * no client-only read marker — read state is shared across devices and refreshes.
 */
export function useNotifications() {
  const queryClient = useQueryClient();

  const { data: items = [], isLoading } = useQuery({
    queryKey: ["notifications"],
    queryFn: async () => (await notificationsService.list()).data,
    refetchInterval: 120_000,         // poll the bell every 2 min
    refetchOnWindowFocus: true,
  });

  const isUnread = useCallback((n: AppNotification) => n.read_at == null, []);

  const unreadCount = items.filter(isUnread).length;
  const hasUnreadAction = items.some((n) => isUnread(n) && n.severity === "action");

  const markAllReadMutation = useMutation({
    mutationFn: () => notificationsService.markAllRead(),
    // Optimistically flip every item to read so the badge clears instantly.
    onMutate: async () => {
      await queryClient.cancelQueries({ queryKey: ["notifications"] });
      const prev = queryClient.getQueryData<AppNotification[]>(["notifications"]);
      const now = new Date().toISOString();
      queryClient.setQueryData<AppNotification[]>(["notifications"], (old) =>
        (old ?? []).map((n) => (n.read_at ? n : { ...n, read_at: now })),
      );
      return { prev };
    },
    onError: (_e, _v, ctx) => {
      if (ctx?.prev) queryClient.setQueryData(["notifications"], ctx.prev);
    },
    onSettled: () => queryClient.invalidateQueries({ queryKey: ["notifications"] }),
  });

  const markAllRead = useCallback(() => {
    if (unreadCount > 0) markAllReadMutation.mutate();
  }, [unreadCount, markAllReadMutation]);

  return { items, isLoading, unreadCount, hasUnreadAction, isUnread, markAllRead };
}
