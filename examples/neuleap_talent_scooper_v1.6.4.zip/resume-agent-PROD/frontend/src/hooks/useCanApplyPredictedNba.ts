import { useQuery } from "@tanstack/react-query";
import { batchArchiveService, NO_SOURCE_KEY } from "@/services/batchArchive";
import { useAuth } from "@/context/AuthContext";

// Whether the current user can click "Apply" on a candidate's predicted Next
// Best Action (Dashboard/Screening/Candidate → Analysis Report popup), and
// whether a Recruiter can directly schedule a round for a still-"New"
// candidate instead. Admin can always apply; a Recruiter is gated PER
// CAMPAIGN SOURCE by Mailbox → Batch Archive → "Recruiters can apply
// predicted NBA" (default off — shows "Admin review pending…" instead).
export function useRecruiterApplyPermission(): {
  canApplyFor: (source: string | null | undefined) => boolean;
} {
  const { isAdmin } = useAuth();
  const { data } = useQuery({
    queryKey: ["recruiter-apply-nba"],
    queryFn: async () => (await batchArchiveService.getRecruiterApplyNba()).data,
    staleTime: 60_000,
  });
  const sources = data?.sources ?? {};

  const canApplyFor = (source: string | null | undefined): boolean => {
    if (isAdmin) return true;
    const key = source && source.trim() ? source : NO_SOURCE_KEY;
    return sources[key] === true;
  };

  return { canApplyFor };
}
