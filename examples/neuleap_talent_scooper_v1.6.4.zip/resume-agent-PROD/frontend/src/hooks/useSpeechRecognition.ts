import { useCallback, useEffect, useRef, useState } from "react";

// The Web Speech API's SpeechRecognition isn't in TS's DOM lib in a stable,
// cross-browser way (Chrome/Edge/Safari ship it prefixed as
// webkitSpeechRecognition; Firefox doesn't ship it at all) — minimal local
// shape for just what this hook uses, named with a `Like` suffix so it can't
// collide with whatever partial/draft global type a given TS/lib version does
// or doesn't declare.
interface SpeechRecognitionResultLike {
  readonly isFinal: boolean;
  [index: number]: { transcript: string };
}
interface SpeechRecognitionEventLike extends Event {
  resultIndex: number;
  results: { length: number; [index: number]: SpeechRecognitionResultLike };
}
interface SpeechRecognitionErrorEventLike extends Event {
  error: string;
}
interface SpeechRecognitionLike extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start(): void;
  stop(): void;
  onresult: ((event: SpeechRecognitionEventLike) => void) | null;
  onerror: ((event: SpeechRecognitionErrorEventLike) => void) | null;
  onend: (() => void) | null;
}
type SpeechRecognitionCtor = new () => SpeechRecognitionLike;

function getSpeechRecognitionCtor(): SpeechRecognitionCtor | null {
  const w = window as unknown as {
    SpeechRecognition?: SpeechRecognitionCtor;
    webkitSpeechRecognition?: SpeechRecognitionCtor;
  };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

const ERROR_MESSAGES: Record<string, string> = {
  "not-allowed": "Microphone access was denied.",
  "service-not-allowed": "Microphone access was denied.",
  "no-speech": "Didn't catch that — try again.",
  "audio-capture": "No microphone found.",
  network: "Network error during voice input.",
};

/**
 * Thin wrapper over the browser's Web Speech API — live "type as you speak"
 * dictation. `supported` is false in browsers without it (notably Firefox);
 * callers should hide the mic entirely there rather than show a button that
 * silently does nothing.
 */
export function useSpeechRecognition({
  onResult,
}: {
  // `text` is the FULL transcript accumulated since the current start() call
  // (finalized + in-progress interim segments) — NOT just the newest chunk.
  // Callers that want "append to whatever was already in the box" should
  // snapshot their own base text right before calling start().
  onResult: (text: string) => void;
}): {
  supported: boolean;
  listening: boolean;
  error: string | null;
  start: () => void;
  stop: () => void;
} {
  const [listening, setListening] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const recognitionRef = useRef<SpeechRecognitionLike | null>(null);
  const supportedRef = useRef(!!getSpeechRecognitionCtor());
  // Kept in a ref so `start` doesn't need `onResult` in its dependency array
  // (callers typically pass an inline closure that's a new reference every
  // render — putting it in deps would tear down/recreate `start` constantly).
  const onResultRef = useRef(onResult);
  onResultRef.current = onResult;

  const stop = useCallback(() => {
    recognitionRef.current?.stop();
  }, []);

  const start = useCallback(() => {
    const Ctor = getSpeechRecognitionCtor();
    if (!Ctor) return;
    setError(null);
    const recognition = new Ctor();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = navigator.language || "en-US";
    let finalText = "";
    recognition.onresult = (event) => {
      let interim = "";
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const chunk = event.results[i][0].transcript;
        if (event.results[i].isFinal) finalText += chunk;
        else interim += chunk;
      }
      onResultRef.current((finalText + interim).trim());
    };
    recognition.onerror = (event) => {
      setError(ERROR_MESSAGES[event.error] ?? "Voice input error.");
      setListening(false);
    };
    recognition.onend = () => setListening(false);
    recognitionRef.current = recognition;
    recognition.start();
    setListening(true);
  }, []);

  // A session left running after the composer unmounts (chat panel closed
  // mid-dictation) would keep the browser's mic indicator lit for no reason.
  useEffect(() => {
    return () => {
      recognitionRef.current?.stop();
    };
  }, []);

  return { supported: supportedRef.current, listening, error, start, stop };
}
