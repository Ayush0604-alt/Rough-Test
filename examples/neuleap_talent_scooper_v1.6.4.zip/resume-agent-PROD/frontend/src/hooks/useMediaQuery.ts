import { useEffect, useState } from "react";

/**
 * Live-updating match for a CSS media query — for layout decisions that need
 * more than a plain width breakpoint (e.g. min-width AND min-height, which
 * Tailwind's `lg:`-style prefixes can't express), so a landscape phone/small
 * tablet that happens to cross a width threshold doesn't get treated as a
 * full desktop viewport.
 */
export function useMediaQuery(query: string): boolean {
  const [matches, setMatches] = useState(() =>
    typeof window !== "undefined" && window.matchMedia ? window.matchMedia(query).matches : false,
  );

  useEffect(() => {
    if (typeof window === "undefined" || !window.matchMedia) return;
    const mql = window.matchMedia(query);
    const onChange = () => setMatches(mql.matches);
    onChange();
    mql.addEventListener("change", onChange);
    return () => mql.removeEventListener("change", onChange);
  }, [query]);

  return matches;
}
