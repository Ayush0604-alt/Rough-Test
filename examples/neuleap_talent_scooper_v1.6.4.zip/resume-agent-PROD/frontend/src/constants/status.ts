// Canonical review vocabularies — mirror of app/constants/status.py.
// Keep the string values identical on both sides.

export const REVIEW_KIND = {
  INVALID_FILE: "invalid_file",
  EXCEL_ROW: "excel_row",
  LINK_FETCH: "link_fetch",
  CORRUPT: "corrupt",
  NOT_RESUME: "not_resume",
  DUPLICATE: "duplicate",
  DUPLICATE_HIRED: "duplicate_hired",
  REAPPLICATION: "reapplication",
  EXTRACTION_FAIL: "extraction_fail",
  FAILED: "failed",
  EXHAUSTED: "exhausted",
  // SYNTHETIC — surfaced in the review queue for candidates stuck at status
  // 'Pending Extraction'. Never a persisted review_queue.kind (see review_queue.py).
  PENDING_EXTRACTION: "pending_extraction",
} as const;

export type ReviewKind = (typeof REVIEW_KIND)[keyof typeof REVIEW_KIND];

export const REVIEW_STATE = {
  OPEN: "open",
  RESOLVED: "resolved",
  DISCARDED: "discarded",
  APPROVED: "approved",
} as const;

export type ReviewState = (typeof REVIEW_STATE)[keyof typeof REVIEW_STATE];
