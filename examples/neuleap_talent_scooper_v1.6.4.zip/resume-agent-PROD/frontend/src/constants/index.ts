export const STREAMS = ["GenAI", "Data Eng", "Not Relevant"] as const;

export const CANDIDATE_STATUSES = [
  "Pending Extraction",
  "Pending Resume",
  "Active",
  "Hired",
  "Rejected",
  "Closed",
] as const;

// Canonical interview-stage vocabulary — the SINGLE source of truth for stage
// names, shared by the Rounds board, the Screening page, and the backend
// (app/api/rounds.py VALID_STAGES). candidate_master.roundname always holds one
// of these. "Offer" is the board's terminal column and maps to status = Hired.
// Board columns. "New" is the implicit start; the interview rounds run Screening →
// Round 1 → Round 2 → Round 3 (optional) → Final; "Hired" is the terminal column
// (passing Final = Hired). Round 3 only appears for candidates whose plan includes it.
export const CANDIDATE_STAGES = [
  "New",
  "Screening",
  "Round 1",
  "Round 2",
  "Round 3",
  "Final",
  "Hired",
] as const;

// Stages a recruiter can schedule a round into. "New" is the implicit start and
// "Hired" is a status, so neither is a manual round preset.
export const ROUND_PRESETS = ["Screening", "Round 1", "Round 2", "Round 3", "Final"] as const;

export const ROUND_NAMES = CANDIDATE_STAGES;

export const AUDIT_LAYERS = ["L1", "L2", "L3"] as const;

export const AUDIT_STATUSES = [
  "Success",
  "Failed",
  "Retry",
  "Exhausted",
] as const;

export const MAX_RETRY_COUNT = 3;

export const PIPELINE_SCHEDULE = "3:30 AM daily";

export const ARCHIVE_AFTER_DAYS = 30;

export const DEDUP_FUZZY_THRESHOLD = 85;
