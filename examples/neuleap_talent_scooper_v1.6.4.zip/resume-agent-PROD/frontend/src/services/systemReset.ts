import { api } from "./api";

export interface WipeInfo {
  allowed: boolean;
  // The exact phrase the recruiter must retype to confirm — see
  // app.services.system_reset.required_confirmation() (the configured
  // Postgres database name). Shown, not secret — the point is making the
  // person read and type it, the same pattern GitHub uses for repo deletion.
  confirm_phrase: string;
}

export interface WipeResult {
  wiped: boolean;
  tables_truncated: number;
  object_store_files_removed: number;
}

export const systemResetService = {
  info: () => api.get<WipeInfo>("/system/wipe-info"),
  wipe: (confirm: string) => api.post<WipeResult>("/system/wipe", { confirm }),
};
