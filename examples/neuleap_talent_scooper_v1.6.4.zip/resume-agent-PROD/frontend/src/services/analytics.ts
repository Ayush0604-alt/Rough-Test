import { api } from "./api";

// One active-in-round candidate with their aging in the current round.
// aging_days = today − round.created_at (when the candidate ENTERED the round),
// clamped at 0 — so it resets to 0 on each round advance and counts up from there.
// Tiers (strict): 🟡 watch > 15d, 🔴 stalled > 30d.
export interface AnalyticsCandidate {
  candidate_id: string;
  name: string | null;
  stage: string | null;
  interviewer: string | null;
  outcome: string | null;
  scheduled_on: string | null;
  aging_days: number;
}

// Per-stage rollup used to render the round tiles (count · avg-aging · badge).
export interface AnalyticsTile {
  stage: string;
  count: number;
  avg_aging: number;
  warn_count: number;  // 15 < aging ≤ 30
  alert_count: number; // aging > 30
}

export interface AnalyticsRounds {
  tiles: AnalyticsTile[];
  candidates: AnalyticsCandidate[];
  // candidate_id → current round's scheduled date. Covers Active AND Hired
  // candidates (the latter aren't in `candidates`, which is Active-only for aging),
  // so the Screening SCHEDULED column can show a date for hired candidates too.
  scheduled: Record<string, string | null>;
  watch_count: number;   // total 15 < aging ≤ 30
  stalled_count: number; // total aging > 30
}

export const analyticsService = {
  rounds: () => api.get<AnalyticsRounds>("/analytics/rounds"),
};

// Shared aging-tier thresholds + helpers, so the Analytics page and the
// Screening filter agree on the exact same boundaries (strict > comparisons).
export const AGING_WATCH = 15;
export const AGING_ALERT = 30;

export type AgingTier = "ok" | "watch" | "stalled";

export function agingTier(days: number): AgingTier {
  if (days > AGING_ALERT) return "stalled";
  if (days > AGING_WATCH) return "watch";
  return "ok";
}
