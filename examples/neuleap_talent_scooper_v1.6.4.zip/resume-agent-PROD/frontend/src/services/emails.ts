import { api } from "./api";
import type { EmailMaster } from "@/types";

export const emailsService = {
  list: (params?: Record<string, string>) =>
    api.get<EmailMaster[]>("/emails", { params }),

  get: (eId: string) =>
    api.get<EmailMaster>(`/emails/${eId}`),

  getRunSummary: () =>
    api.get<{
      last_run: string;
      next_run: string;
      total: number;
      processed: number;
      queued: number;
      needs_review: number;
      resolved: number;
      failed_files: number;
      // Mail-aging report over pending (arrived, not-yet-terminal) mail.
      aging: {
        pending_total: number;
        oldest_pending_days: number;
        avg_pending_days: number;
        buckets: { fresh: number; aging: number; stale: number; critical: number };
      };
      // Back-compat aliases.
      issues: number;
      passed: number;
      partial: number;
      failed: number;
      discarded: number;
    }>("/emails/run-summary"),
};
