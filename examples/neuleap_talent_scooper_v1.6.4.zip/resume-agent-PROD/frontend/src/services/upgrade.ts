import { api } from "./api";

export interface UpgradeImage {
  service: string;
  image: string;
  sha256?: string;
}

export interface UpgradeManifest {
  bundle_id: string;
  version: string;
  created_at?: string;
  project?: string;
  features?: string[];
  images?: UpgradeImage[];
  size_bytes?: number;
  uploaded_filename?: string;
  signed?: boolean;
  signature_verified?: boolean;
  has_env_additions?: boolean;
  has_compose_overlay?: boolean;
}

export interface UpgradeConfig {
  public_key: string;
  require_signature: boolean;
}

export interface UpgradeStatus {
  state: "idle" | "queued" | "running" | "success" | "rolled_back" | "failed" | string;
  phase?: string;
  message?: string;
  updated_at?: string;
  version?: string;
  features?: string[];
  pre_backup_id?: string;
  bundle_id?: string;
  updater_alive?: boolean;
}

export const upgradeService = {
  uploadBundle: (file: File, onUploadProgress?: (e: { loaded: number; total?: number }) => void) => {
    const fd = new FormData();
    fd.append("file", file);
    return api.post<{ manifest: UpgradeManifest }>("/upgrade/bundle", fd, {
      headers: { "Content-Type": "multipart/form-data" },
      onUploadProgress,
      timeout: 0, // large bundle uploads must not time out
    });
  },
  listDrop: () => api.get<{ files: { filename: string; size_bytes: number }[] }>("/upgrade/drop"),
  loadDrop: (filename: string) =>
    api.post<{ manifest: UpgradeManifest }>("/upgrade/drop/load", { filename }),
  listBundles: () => api.get<{ bundles: UpgradeManifest[] }>("/upgrade/bundles"),
  start: (bundle_id: string) =>
    api.post<{ started: boolean; pre_backup_id: string; bundle_id: string }>("/upgrade/start", { bundle_id }),
  status: () => api.get<UpgradeStatus>("/upgrade/status"),
  getConfig: () => api.get<UpgradeConfig>("/upgrade/config"),
  saveConfig: (cfg: UpgradeConfig) => api.put<UpgradeConfig>("/upgrade/config", cfg),
};
