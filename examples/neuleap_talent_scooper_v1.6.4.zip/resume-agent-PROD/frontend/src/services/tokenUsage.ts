import { api } from "./api";

// Admin "Token Usage" dashboard — aggregates over the llm_token_usage ledger
// (one row per LLM call). Costs are ESTIMATES from a static price map.
export interface ModuleUsage {
  module: string;
  calls: number;
  prompt_tokens: number;
  completion_tokens: number;
  total_tokens: number;
  est_cost_usd: number;
}

export interface ModelUsage {
  model: string;
  calls: number;
  total_tokens: number;
  est_cost_usd: number;
}

export interface SourceUsage {
  source: string;
  calls: number;
  total_tokens: number;
}

export interface DayUsage {
  day: string; // YYYY-MM-DD
  prompt_tokens: number;
  completion_tokens: number;
  total_tokens: number;
  calls: number;
}

export interface DayModuleUsage {
  day: string;
  module: string;
  total_tokens: number;
}

export interface TokenUsageSummary {
  totals: {
    calls: number;
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
    est_cost_usd: number;
  };
  by_module: ModuleUsage[];
  by_model: ModelUsage[];
  by_source: SourceUsage[];
  timeline: DayUsage[];
  timeline_by_module: DayModuleUsage[];
  sources: string[];
}

export const tokenUsageService = {
  summary: (params: { date_from?: string; date_to?: string; source?: string }) =>
    api.get<TokenUsageSummary>("/token-usage", { params }),
};
