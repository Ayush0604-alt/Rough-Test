import { api } from "./api";
import type { Round } from "@/types";

export const roundsService = {
  listForCandidate: (candidateId: string) =>
    api.get<Round[]>(`/candidates/${candidateId}/rounds`),

  create: (data: Omit<Round, "round_id">) =>
    api.post<Round>("/rounds", data),

  // Extra (non-column) fields sent with a round update:
  //   advance_to       — skip target on a Pass (e.g. Round 2 → Final, skip Round 3)
  //   next_interviewer — Round 1 interviewer to assign when passing Screening
  //   include_round3   — whether the optional Round 3 runs (set once on Screening)
  update: (
    roundId: number,
    data: Partial<Round> & { advance_to?: string; next_interviewer?: string; include_round3?: boolean },
  ) => api.patch<Round>(`/rounds/${roundId}`, data),

  // Log a reminder email sent for this round — increments reminder_count,
  // capped at 2 ("1/2" → "2/2").
  sendReminder: (roundId: number) => api.post<Round>(`/rounds/${roundId}/send-reminder`),
};
