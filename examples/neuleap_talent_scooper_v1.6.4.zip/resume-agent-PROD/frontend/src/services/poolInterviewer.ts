/// <reference types="vite/client" />
import type { PoolSlot } from "./interviewPools";

// Deliberately NOT the shared `api` axios instance — same reasoning as
// services/interviewer.ts / candidateSlots.ts: a missing/expired session
// here is a routine 401 (just means "show the code challenge"), not a dead
// admin login.
const BASE = `${import.meta.env.VITE_API_URL ?? "http://localhost:8000/api/v1"}/pool-interviewer`;

export class PoolInterviewerApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

async function publicRequest<T>(path: string, options: RequestInit = {}): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers ?? {}) },
  });
  if (!res.ok) {
    let detail = res.statusText || `Request failed (${res.status})`;
    try {
      const body = await res.json();
      if (body?.detail) detail = body.detail;
    } catch {
      // non-JSON error body — keep the status text
    }
    throw new PoolInterviewerApiError(res.status, detail);
  }
  if (res.status === 204) return undefined as T;
  return res.json() as Promise<T>;
}

const sessionHeader = (sessionToken: string | null): Record<string, string> =>
  sessionToken ? { "X-Pool-Session": sessionToken } : {};

export interface PoolInterviewerMe {
  email: string;
  name: string | null;
  round_names: string[];
}

export const poolInterviewerService = {
  requestCode: (email: string) =>
    publicRequest<{ sent: boolean }>("/request-code", { method: "POST", body: JSON.stringify({ email }) }),

  verifyCode: (email: string, code: string, remember: boolean) =>
    publicRequest<{ session_token: string; name: string; round_names: string[] }>("/verify-code", {
      method: "POST",
      body: JSON.stringify({ email, code, remember }),
    }),

  me: (sessionToken: string) =>
    publicRequest<PoolInterviewerMe>("/me", { headers: sessionHeader(sessionToken) }),

  mySlots: (sessionToken: string) =>
    publicRequest<PoolSlot[]>("/my-slots", { headers: sessionHeader(sessionToken) }),

  removeSlot: (sessionToken: string, slotId: number) =>
    publicRequest<PoolSlot>(`/slots/${slotId}/remove`, { method: "POST", headers: sessionHeader(sessionToken) }),

  proposeTime: (sessionToken: string, slotId: number, start: string, end: string) =>
    publicRequest<PoolSlot>(`/slots/${slotId}/propose`, {
      method: "POST",
      headers: sessionHeader(sessionToken),
      body: JSON.stringify({ start, end }),
    }),
};

const sessionKey = "neuleap-pool-interviewer-session";

export const poolInterviewerSession = {
  get: () => localStorage.getItem(sessionKey),
  set: (sessionToken: string) => localStorage.setItem(sessionKey, sessionToken),
  clear: () => localStorage.removeItem(sessionKey),
};
