import { api } from "./api";
import type { CandidateMaster, EmailDraft } from "@/types";

// Dropdown facets for filtering the candidate list by the batch that produced them
// or by the source email (E_ID) their resume arrived in. Emails are keyed by E_ID —
// not grouped by sender — so a placeholder sender like "direct" stays separable. Each
// row carries its candidate_ids so the list can be filtered client-side, no extra fetch.
export interface BatchFacet {
  batch_id: string;
  last_run: string | null;
  candidate_ids: string[];
}
export interface EmailFacet {
  e_id: string;
  sender_mail_id: string | null;
  subject: string | null;
  candidate_ids: string[];
}
export interface CandidateFacets {
  batches: BatchFacet[];
  emails: EmailFacet[];
}

// One audit_log row for a candidate — spans the whole pipeline: L1 (mail intake),
// L2 (resume intake), L3 (extraction), L4 (recruiter actions). "Info" status rows
// carry a human-readable summary in fail_reason (despite the pipeline-era name);
// pipeline Success/Failed rows may have fail_reason only on failure.
export interface CandidateAuditEntry {
  log_id: number;
  layer: string;
  step: string;
  status: string;
  fail_reason: string | null;
  // Pipeline/round bucket this event belongs to (New/Screening/Round 1/Round 2/
  // Final/Hired/Reject/Closed) — null for pre-L4 pipeline rows or an
  // unattributed action; the UI groups those under "New".
  stage: string | null;
  // The email_drafts row this event is about (generated/marked ready/sent) —
  // null for every non-email-lifecycle row, and for rows written before this
  // field existed. Backs the log's "view email" button.
  draft_id: number | null;
  created_at: string;
}

export const candidatesService = {
  list: (params?: Record<string, string>) =>
    api.get<CandidateMaster[]>("/candidates", { params }),

  facets: () => api.get<CandidateFacets>("/candidates/facets"),

  get: (candidateId: string) =>
    api.get<CandidateMaster>(`/candidates/${candidateId}`),

  // Direct URL to stream the stored resume inline (open in a new tab).
  // which="pending" streams the re-application's new file instead of the live one.
  resumeUrl: (candidateId: string, which: "current" | "pending" = "current") =>
    `${api.defaults.baseURL}/candidates/${candidateId}/resume?which=${which}`,

  // Fetch the resume bytes as a blob (for the in-app viewer; surfaces errors).
  fetchResume: (candidateId: string, which: "current" | "pending" = "current") =>
    api.get<Blob>(`/candidates/${candidateId}/resume`, {
      params: { which },
      responseType: "blob",
    }),

  updateStatus: (candidateId: string, status: CandidateMaster["status"]) =>
    api.patch(`/candidates/${candidateId}/status`, { status }),

  updatePriority: (candidateId: string, priority: CandidateMaster["priority"]) =>
    api.patch(`/candidates/${candidateId}/priority`, { priority }),

  // Recruiter override of the "Next Best Action" suggestion. Pass key: null to clear
  // the override and revert to the ATS-derived suggestion.
  updateNextAction: (
    candidateId: string,
    body: {
      key:
        | "call_now"
        | "reject"
        | "undecided"
        | "office_interview"
        | "final_round"
        | "share_round3"
        | "share_round2"
        | "share_round1"
        | "hire"
        | "custom"
        | null;
      text?: string | null;
      // Reason typed in the comment popup — logged to the Actions Audit Log.
      comment?: string | null;
    }
  ) => api.patch<CandidateMaster>(`/candidates/${candidateId}/next-action`, body),

  // Stick a note on the candidate — becomes latest_note (sticky on their page
  // + yellow badge next to their name) and is written to the Actions Audit Log.
  addNote: (candidateId: string, text: string) =>
    api.post<{ note: { text: string; author: string; created_at: string } }>(
      `/candidates/${candidateId}/note`,
      { text }
    ),

  // Delete the latest note — clears the sticky + badge; the deletion (with
  // the old text) is recorded in the Actions Audit Log.
  deleteNote: (candidateId: string) =>
    api.delete<{ deleted: boolean }>(`/candidates/${candidateId}/note`),

  // Set/edit the remark (blue, interviewer-visible). Empty text clears it.
  setRemark: (candidateId: string, text: string) =>
    api.post<{ remark: { text: string; author: string; created_at: string } | null }>(
      `/candidates/${candidateId}/remark`,
      { text }
    ),

  // Bulk-apply the SAME note or remark to several candidates (kind: note|remark).
  bulkNote: (candidateIds: string[], text: string, kind: "note" | "remark") =>
    api.post<{ results: { candidate_id: string; applied: boolean }[]; kind: string }>(
      `/candidates/notes/bulk`,
      { candidate_ids: candidateIds, text, kind }
    ),

  // Mark a candidate's "Need help" message (slot-picker page) as handled —
  // clears the red "!" from status tracking.
  resolveHelpRequest: (candidateId: string) =>
    api.post<{ ok: boolean }>(`/candidates/${candidateId}/help-request/resolve`),

  // "Reset this round" on an active help request — back to the round's initial
  // stage: old picker link disabled, sub-steps cleared, a fresh slot-invite
  // draft generated for review/send, and the help flag marked handled.
  resetHelpRound: (candidateId: string) =>
    api.post<{ ok: boolean; round_name: string; draft_generated: boolean }>(
      `/candidates/${candidateId}/help-request/reset-round`
    ),

  // Apply the system-predicted (NLRS-based) Next Best Action — the key is always
  // computed server-side, never sent from here, so this can never be used to set
  // an arbitrary NBA. Available to both Admin and Recruiter (unlike the manual
  // override above). Only valid while the candidate is still in the New stage.
  applyPredictedNba: (candidateId: string, comment?: string) =>
    api.post<CandidateMaster>(`/candidates/${candidateId}/apply-predicted-nba`, {
      comment: comment ?? "",
    }),

  // The one comment is recorded on EVERY affected candidate, marked (bulk-apply).
  applyPredictedNbaBulk: (candidateIds: string[], comment?: string) =>
    api.post<{ results: { candidate_id: string; applied: boolean; reason?: string; key?: string }[] }>(
      `/candidates/apply-predicted-nba/bulk`,
      { candidate_ids: candidateIds, comment: comment ?? "" }
    ),

  // Full processing + recruiter-action audit trail for this candidate — L1 (mail
  // intake) through L4 (recruiter actions). Shown as the "Actions Audit Log" on
  // the profile, grouped by stage. Newest first.
  auditLog: (candidateId: string) =>
    api.get<CandidateAuditEntry[]>(`/candidates/${candidateId}/audit-log`),

  // This candidate's email drafts (newest first) — generated by an email-sending
  // NBA selection (call_now/undecided/office_interview/final_round).
  emailDrafts: (candidateId: string) =>
    api.get<EmailDraft[]>(`/candidates/${candidateId}/email-drafts`),

  // Screening-call fields the recruiter fills (currentlocation, relocation).
  updateScreening: (
    candidateId: string,
    fields: { currentlocation?: string; relocation?: boolean }
  ) => api.patch<CandidateMaster>(`/candidates/${candidateId}`, fields),

  // Post-hire onboarding pipeline (Live Workflow) — advance the stage, set a
  // date, or toggle one checklist item. Only valid for a Hired candidate (409
  // otherwise). Pass only the field(s) you want to change.
  updateOnboarding: (
    candidateId: string,
    body: {
      stage?: string;
      expected_join_date?: string;
      onboarding_date?: string;
      checklist_item?: string;
    }
  ) => api.patch<CandidateMaster>(`/candidates/${candidateId}/onboarding`, body),

  // ── Step-20 entry branches ──
  reapplicationQueue: () =>
    api.get<CandidateMaster[]>("/candidates/reapplications"),

  // Upload/link a resume for a Pending Resume candidate → re-runs L2/L3.
  // Returns 200 even if L3 extraction fails (the file IS saved); `extraction_ok`
  // flags whether extraction completed so the UI can warn instead of erroring.
  attachResume: (candidateId: string, file: File) => {
    const form = new FormData();
    form.append("file", file);
    return api.post<{
      candidate_id: string;
      s3_file_path: string;
      extraction_ok: boolean;
      extraction: Record<string, unknown>;
    }>(`/candidates/${candidateId}/resume`, form, {
      headers: { "Content-Type": "multipart/form-data" },
    });
  },

  resolveReapplication: (candidateId: string, action: "accept" | "ignore") =>
    api.post(`/candidates/${candidateId}/reapplication`, { action }),

  // Manual archive (e.g. a Hired candidate after onboarding).
  archive: (candidateId: string) =>
    api.post(`/candidates/${candidateId}/archive`),
};

export interface SendPreview {
  recipient: string | null;
  qa_redirected: boolean;
  candidate_email: string | null;
}

export interface SendResult {
  sent: boolean;
  recipient: string | null;
  qa_redirected: boolean;
  warning: string | null;
  draft: EmailDraft;
}

// Review/edit an email draft, mark it "ready to send", and actually send it
// (see app/api/rounds.py — send-preview/send).
export const emailDraftsService = {
  update: (
    draftId: number,
    body: { subject?: string; body?: string; status?: "draft" | "ready" }
  ) => api.patch<EmailDraft>(`/email-drafts/${draftId}`, body),

  // Calls the externally-configured interview-slot-picker API (Settings →
  // Interview Slot Picker) with the chosen round + this draft's candidate,
  // and returns the link it hands back — for embedding into the draft body.
  interviewSlotLink: (draftId: number, round: string) =>
    api.post<{ link: string }>(`/email-drafts/${draftId}/interview-slot-link`, { round }),

  // The native counterpart — mints a /schedule/{token} link sourced from a
  // matching interviewer timeslot pool (Mailbox → Interviewer Timeslot
  // Pools) instead of calling an external API.
  poolSlotLink: (draftId: number, round: string) =>
    api.post<{ url_path: string }>(`/email-drafts/${draftId}/pool-slot-link`, { round }),

  sendPreview: (draftId: number) => api.get<SendPreview>(`/email-drafts/${draftId}/send-preview`),

  send: (draftId: number) => api.post<SendResult>(`/email-drafts/${draftId}/send`, { confirm: true }),
};
