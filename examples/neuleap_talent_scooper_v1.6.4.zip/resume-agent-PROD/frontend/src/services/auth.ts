import { api } from "./api";

export type UserRole = "admin" | "recruiter" | "sysadmin";

export interface AuthUser {
  email: string;
  name: string;
  role: UserRole;
  // First-login / post-admin-reset gate — the app is blocked behind a forced
  // change-password dialog while true (see AuthProvider / ChangePasswordModal).
  must_change_password?: boolean;
}

interface LoginResponse {
  access_token: string;
  token_type: string;
  user: AuthUser;
}

// A managed login account (Settings → User Management, Admin only).
export interface ManagedUser {
  id: number;
  email: string;
  name: string;
  role: UserRole;
  is_active: boolean;
  must_change_password?: boolean;
  created_at: string | null;
}

// createUser response — the managed user plus (invite path only) whether the
// set-password email sent and a fallback link to relay if it didn't.
export interface CreatedUser extends ManagedUser {
  invited?: boolean;
  invite_sent?: boolean;
  invite_link?: string | null;
}

export const TOKEN_KEY = "neuleap-auth-token";
export const USER_KEY = "neuleap-auth-user";

export function getStoredToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function getStoredUser(): AuthUser | null {
  const raw = localStorage.getItem(USER_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as AuthUser;
  } catch {
    return null;
  }
}

export function storeSession(token: string, user: AuthUser): void {
  localStorage.setItem(TOKEN_KEY, token);
  localStorage.setItem(USER_KEY, JSON.stringify(user));
}

export function clearSession(): void {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
}

// Update just the cached user (e.g. must_change_password cleared after a
// successful change) without touching the token.
export function updateStoredUser(user: AuthUser): void {
  localStorage.setItem(USER_KEY, JSON.stringify(user));
}

export const authService = {
  async login(email: string, password: string): Promise<LoginResponse> {
    const { data } = await api.post<LoginResponse>("/auth/login", {
      email,
      password,
    });
    storeSession(data.access_token, data.user);
    return data;
  },

  async me(): Promise<AuthUser> {
    const { data } = await api.get<AuthUser>("/auth/me");
    return data;
  },

  // ── User management (Admin only) ──────────────────────────────────────────
  async listUsers(): Promise<ManagedUser[]> {
    const { data } = await api.get<ManagedUser[]>("/auth/users");
    return data;
  },

  // Create a login account. Omit `password` to email the member a link to set
  // their own initial password (the default). The response carries invite status
  // + a fallback link if email delivery isn't configured.
  async createUser(
    email: string,
    role: UserRole,
    password?: string
  ): Promise<CreatedUser> {
    const { data } = await api.post<CreatedUser>("/auth/users", {
      email,
      role,
      ...(password ? { password } : {}),
    });
    return data;
  },

  // ── Public: forgot password + set/reset password via emailed token ─────────
  async forgotPassword(email: string): Promise<{ ok: boolean; message: string }> {
    const { data } = await api.post<{ ok: boolean; message: string }>("/auth/forgot-password", {
      email,
    });
    return data;
  },

  async checkResetToken(token: string): Promise<{ valid: boolean; purpose: string | null }> {
    const { data } = await api.get<{ valid: boolean; purpose: string | null }>(
      `/auth/reset-token/${encodeURIComponent(token)}`
    );
    return data;
  },

  async resetPassword(token: string, newPassword: string): Promise<{ ok: boolean; message: string }> {
    const { data } = await api.post<{ ok: boolean; message: string }>("/auth/reset-password", {
      token,
      new_password: newPassword,
    });
    return data;
  },

  async deleteUser(id: number): Promise<void> {
    await api.delete(`/auth/users/${id}`);
  },

  // Self-service password change (all roles) — also the required step behind
  // the first-login forced change.
  async changePassword(currentPassword: string, newPassword: string): Promise<void> {
    await api.post("/auth/change-password", {
      current_password: currentPassword,
      new_password: newPassword,
    });
  },

  // Admin-only: reset a user's password to a freshly generated value. The
  // plain password is returned exactly once for the Admin to hand over.
  async resetUserPassword(id: number): Promise<{ email: string; password: string }> {
    const { data } = await api.post<{ email: string; password: string }>(
      `/auth/users/${id}/reset-password`
    );
    return data;
  },
};
