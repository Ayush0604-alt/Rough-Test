import { api } from "./api";
import type { AuditLog } from "@/types";

export const auditService = {
  list: (params?: Record<string, string>) =>
    api.get<AuditLog[]>("/audit-logs", { params }),

  getByEmail: (eId: string) =>
    api.get<AuditLog[]>(`/audit-logs`, { params: { E_id: eId } }),

  /** Direct download URL for the audit-log Excel export (server applies the filters). */
  exportExcelUrl: (params?: Record<string, string>) => {
    const qs = new URLSearchParams(params ?? {}).toString();
    return `${api.defaults.baseURL}/audit-logs/export.xlsx${qs ? `?${qs}` : ""}`;
  },
};
