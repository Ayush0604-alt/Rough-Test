import { api } from "./api";

export interface NotificationSettings {
  email: string | null;
  run_summary: boolean;
  manual_review: boolean;
  exhausted: boolean;
  new_p1: boolean;
  graph_configured?: boolean;
}

export interface PipelineSettings {
  run_time: string;
  timezone?: string | null;
  max_retries: number;
  archive_after_days: number;
  archive_ats_threshold: number;
  dedup_threshold: number;
}

export interface ScoringSettings {
  // P1/P2/P3 minimum atsscore thresholds (0–100, descending). P4 is the rest.
  ats_bands: { P1: number; P2: number; P3: number };
  // Per-stream classification keyword lists (injected into the L3 prompt).
  stream_keywords: Record<string, string[]>;
  // Certificate filter tags shown as checkboxes in the Resume Library cert filter.
  cert_tags: string[];
}

// One configurable Candidates-table column (the Column Config panel + the table both
// read these). `visible` is the saved/default on/off state.
export interface ColumnSetting {
  key: string;
  label: string;
  visible: boolean;
}
export interface ColumnSettings {
  columns: ColumnSetting[];
}

// Whether the floating chat launcher ("Neuleap Buddy") is shown at all, for
// every user — a single shared on/off toggle, not a per-user preference.
export interface ChatbotWidgetSettings {
  visible: boolean;
}

// The external API that returns an interview-slot-picker link, embedded into
// an "Interview slots shared" (Screening round) email draft. `param_*` are
// the request key names THAT API expects — configurable since the vocabulary
// belongs to whatever service is wired in, not this app. `override_email`
// lets QA point every call at a test inbox instead of the real candidate.
export interface InterviewSlotSettings {
  api_url: string;
  param_round: string;
  param_name: string;
  param_email: string;
  override_email: string;
}

// Which optional sections render on the Candidate profile page — a single
// shared toggle set (not a per-user preference), read by Candidate/index.tsx.
export interface CandidateSectionsSettings {
  quick_signals: boolean;
  thinking_summary: boolean;
  ats_breakdown: boolean;
  nlrs_breakdown: boolean;
  skills: boolean;
  certificates: boolean;
  career_timeline: boolean;
  round_history: boolean;
}

// TEMP — Settings → "Legacy Features" (Admin only). Individual legacy UI
// affordances an Admin can flip on/off during the transition to their
// replacements; remove each flag here once its old code is deleted.
// Intake mailbox account & folder routing (Settings → Mailbox Account).
// The password never travels back from the server — only has_password.
export interface MailboxAccountSettings {
  email: string;
  has_password: boolean;
  scan_folder: string;
  folder_processing: string;
  folder_processed: string;
  folder_failed: string;
  folder_non_resume: string;
  updated_at: string | null;
  updated_by: string | null;
}

// LLM provider connection (Settings -> LLM Model Keys). Keys never travel
// back to the browser - only whether one is stored, globally and per module.
export interface LlmModuleConfig {
  endpoint: string;
  deployment: string;
  has_api_key: boolean;
}

export interface LlmConfigSettings {
  endpoint: string;
  has_api_key: boolean;
  env_key_present: boolean;
  api_version: string;
  deployment: string;
  fallback_deployment: string;
  modules: Record<string, LlmModuleConfig>;
  module_names: string[];
  updated_at: string | null;
  updated_by: string | null;
}

// One editable email base template (Mailbox → Archives & Interview Slots →
// Email Base Templates) — the subject/body a generated draft starts from.
export interface EmailBaseTemplate {
  key: string;
  label: string;
  subject: string;
  body: string;
  is_customized: boolean;
}

export interface LegacyFeaturesSettings {
  interview_round_button: boolean;
  external_slot_link_button: boolean;
  qb_enrich_button: boolean;
  qb_duplicate_button: boolean;
  ats_column: boolean;
  nlrs_column: boolean;
  predicted_nba_status: boolean;
}

// Interviewer Access — email-domain allow-list + remember-me session duration
// for the external, no-login interviewer surface (see app.api.interviewer).
export interface InterviewerDomainEntry {
  domain: string;
  allowed: boolean;
}
export interface InterviewerAccessSettings {
  domains: InterviewerDomainEntry[];
  remember_days: number;
}

// A stable, always-clickable interview link against a fully-mocked demo
// candidate (see app/services/sample_interview.py) — the same URL every time,
// safe to bookmark. "Reset" clears any verdict left over from a prior test.
export interface SampleInterviewLink {
  url_path: string;
  candidate_id: string;
  round_id: number;
}

// One entry per verdict-picker scenario — Screening (legacy Pass/Fail),
// Round 1 / Round 2 (round-aware "Move to X / Reject" + Admin bypass), and
// Final (Hire/Reject). Keyed by round name.
export type SampleInterviewLinks = Record<string, SampleInterviewLink>;

// Whether the "Sample Data" source tag (SAMPLE-DEMO fixture candidate) shows
// up in source-tag pickers app-wide. `toggle_shown` is false outside a QA/
// non-production environment — there's nothing to toggle in prod, since it's
// always hidden there regardless.
export interface SampleDataVisibility {
  visible: boolean;
  toggle_shown: boolean;
}

// Per-round-type interviewer roster — used to source Graph calendar
// availability for the candidate slot-selection flow (see
// InterviewSchedulingSettings below). The 7 standard stages always exist;
// `custom: true` marks admin-added extra round types (removable in the UI).
export interface RoundInterviewerEntry {
  name: string;
  email: string;
}
export interface RoundTypeEntry {
  key: string;
  label: string;
  custom: boolean;
  interviewers: RoundInterviewerEntry[];
}
export interface RoundInterviewersSettings {
  round_types: RoundTypeEntry[];
}

// Native candidate interview slot-picker — governs which calendar is
// checked (currently always the QA stand-in mailbox), slot length, and the
// reminder/auto-reject cadence for candidates who don't book.
// `auto_invite_enabled` defaults OFF — a safety gate so this feature doesn't
// silently start emailing real in-flight candidates until an Admin opts in.
export interface InterviewSchedulingSettings {
  qa_calendar_email: string;
  slot_duration_minutes: number;
  reminder_max_count: number;
  // The NUMBER for each interval lives in these two fields regardless of
  // unit — when the matching unit is "minutes" (QA-only), the same number is
  // simply read as minutes.
  reminder_interval_hours: number;
  auto_reject_after_days: number;
  reminder_interval_unit: "hours" | "minutes";
  auto_reject_after_unit: "days" | "minutes";
  auto_invite_enabled: boolean;
  // Computed by the GET (never persisted): whether this environment (QA)
  // offers the minute-based units at all.
  minutes_allowed?: boolean;
}

// Email draft send controls — auto_send_enabled (Settings section below) and
// draft_review_required (can only be turned off via the separate re-auth
// endpoint — see disableDraftReview).
export interface EmailSendSettings {
  auto_send_enabled: boolean;
  draft_review_required: boolean;
}

// Extraction & Analysis (Admin-only — see app/api/extraction_settings.py).

export interface SkillOverrideStatus {
  overridden: boolean;
  active_text: string;
  default_text: string;
}

export interface AnalysisPromptStatus {
  overridden: boolean;
  active_prompt: string;
  default_prompt: string;
}

export interface NlrsRule {
  id: string;
  label: string;
  field: string;
  op: string;
  value: number;
  points: number;
}

export interface NlrsConfig {
  weights: { analysis_report: number; cgpa: number; certificates: number; experience: number; ats: number };
  nba_bands: {
    call_now: number;
    undecided: number;
    // Fast-track bands, above call_now — see app.services.nlrs_config.
    share_round1: number;
    share_round2: number;
    final_round: number;
  };
  rules: NlrsRule[];
  allowed_rule_fields?: string[];
  allowed_rule_ops?: string[];
}

export interface BatchRunResult {
  total: number;
  succeeded: number;
  failed: number;
  errors?: { candidate_id: string; error: string }[];
}

export interface NlrsPreviewCandidate {
  candidate_id: string;
  name: string | null;
  score: number;
  components: { label: string; weight: number; subscore: number; weighted: number }[];
  adjustments: { label: string; points: number }[];
}

export interface NlrsPreviewResult {
  summary: { count: number; avg_score: number | null; min_score: number | null; max_score: number | null };
  candidates: NlrsPreviewCandidate[];
  truncated: boolean;
}

export interface GraphConfigSettings {
  tenant_id: string;
  client_id: string;
  has_client_secret: boolean;
  env_secret_present: boolean;
  env_tenant_present: boolean;
  env_client_present: boolean;
  updated_at: string | null;
  updated_by: string | null;
}

export interface ReferralEntry {
  value: string;
  message: string;
  // Optional subject style with a <Sender> placeholder — when set, the referrer
  // is extracted from the email subject instead of using the sender address.
  subject_pattern: string;
}
export interface ReferralConfig {
  emails: ReferralEntry[];
  domains: ReferralEntry[];
}

export const settingsService = {
  getSkillOverride: () => api.get<SkillOverrideStatus>("/settings/skill-override"),
  saveSkillOverride: (text: string) => api.put<SkillOverrideStatus>("/settings/skill-override", { text }),
  revertSkillOverride: () => api.post<SkillOverrideStatus>("/settings/skill-override/revert"),
  rerunSkillOverride: (source: string | null) =>
    api.post<BatchRunResult>("/settings/skill-override/rerun", { source }),

  getAnalysisPrompt: () => api.get<AnalysisPromptStatus>("/settings/analysis-prompt"),
  saveAnalysisPrompt: (text: string) => api.put<AnalysisPromptStatus>("/settings/analysis-prompt", { text }),
  revertAnalysisPrompt: () => api.post<AnalysisPromptStatus>("/settings/analysis-prompt/revert"),
  rerunAnalysisPrompt: (source: string | null) =>
    api.post<BatchRunResult>("/settings/analysis-prompt/rerun", { source }),

  getNlrsConfig: () => api.get<NlrsConfig>("/settings/nlrs-config"),
  saveNlrsConfig: (body: NlrsConfig) => api.put<NlrsConfig>("/settings/nlrs-config", body),
  revertNlrsConfig: () => api.post<NlrsConfig>("/settings/nlrs-config/revert"),
  previewNlrsConfig: (source: string | null) =>
    api.post<NlrsPreviewResult>("/settings/nlrs-config/preview", { source }),


  getChatbotWidget: () => api.get<ChatbotWidgetSettings>("/settings/chatbot-widget"),
  saveChatbotWidget: (visible: boolean) =>
    api.put<ChatbotWidgetSettings>("/settings/chatbot-widget", { visible }),
  getInterviewSlotSettings: () =>
    api.get<InterviewSlotSettings>("/settings/interview-slot-picker"),
  saveInterviewSlotSettings: (body: InterviewSlotSettings) =>
    api.put<InterviewSlotSettings>("/settings/interview-slot-picker", body),
  getCandidateSections: () =>
    api.get<CandidateSectionsSettings>("/settings/candidate-sections"),
  saveCandidateSections: (body: CandidateSectionsSettings) =>
    api.put<CandidateSectionsSettings>("/settings/candidate-sections", body),
  // Intake mailbox account & folder routing. Saving requires the acting
  // System Admin's own credentials (username/password) alongside the config.
  getMailboxAccount: () => api.get<MailboxAccountSettings>("/settings/mailbox-account"),
  saveMailboxAccount: (
    body: Omit<MailboxAccountSettings, "has_password" | "updated_at" | "updated_by"> & {
      mailbox_password?: string;
      username: string;
      password: string;
    }
  ) => api.put<MailboxAccountSettings>("/settings/mailbox-account", body),

  // LLM model keys - provider connection + per-module overrides. Keys never
  // come back from the server (only has_api_key); saving requires the acting
  // System Admin's own credentials, same friction as the mailbox account.
  // Reminder/auto-reject cadence — read-only, any role; drives the
  // Dashboard's "Reminder x of y" rows and the auto-reject label.
  getSchedulingCadence: () =>
    api.get<{
      max_reminders: number;
      reminder_interval: number;
      reminder_interval_unit: string;
      auto_reject_after: number;
      auto_reject_after_unit: string;
    }>("/scheduling-cadence"),

  // Referrals — emails/domains that classify a candidate as a referral. Each
  // entry carries its OWN optional message, shown on the candidate-page clip.
  getReferralConfig: () =>
    api.get<ReferralConfig>("/settings/referral-config"),
  saveReferralConfig: (body: ReferralConfig) =>
    api.put<ReferralConfig>("/settings/referral-config", body),

  // Graph API — Azure app-registration credentials (tenant/client/secret) for
  // the mail + calendar integration. The secret never comes back from the
  // server (only has_client_secret); saving requires the acting System Admin's
  // own credentials, same friction as the mailbox account / LLM keys.
  getGraphConfig: () => api.get<GraphConfigSettings>("/settings/graph-config"),
  saveGraphConfig: (body: {
    tenant_id: string;
    client_id: string;
    client_secret?: string; // blank keeps stored; "-" clears
    username: string;
    password: string;
  }) => api.put<GraphConfigSettings>("/settings/graph-config", body),

  getLlmConfig: () => api.get<LlmConfigSettings>("/settings/llm-config"),
  saveLlmConfig: (body: {
    endpoint: string;
    api_key?: string; // blank keeps stored; "-" clears
    api_version: string;
    deployment: string;
    fallback_deployment: string;
    modules: Record<string, { endpoint: string; deployment: string; api_key: string }>;
    username: string;
    password: string;
  }) => api.put<LlmConfigSettings>("/settings/llm-config", body),

  // Email base templates — the per-NBA-key subject/body every generated
  // draft starts from (editable; empty save = revert to shipped default).
  getEmailTemplates: () =>
    api.get<{ templates: EmailBaseTemplate[]; placeholders: string[] }>("/settings/email-templates"),
  saveEmailTemplate: (body: { key: string; subject: string; body: string }) =>
    api.put<EmailBaseTemplate>("/settings/email-templates", body),
  getLegacyFeatures: () =>
    api.get<LegacyFeaturesSettings>("/settings/legacy-features"),
  saveLegacyFeatures: (body: LegacyFeaturesSettings) =>
    api.put<LegacyFeaturesSettings>("/settings/legacy-features", body),
  getNotifications: () => api.get<NotificationSettings>("/settings/notifications"),
  saveNotifications: (body: Omit<NotificationSettings, "graph_configured">) =>
    api.put<NotificationSettings>("/settings/notifications", body),
  testNotification: () =>
    api.post<{ sent: boolean; error: string | null }>("/settings/notifications/test"),
  getPipeline: () => api.get<PipelineSettings>("/settings/pipeline"),
  savePipeline: (body: PipelineSettings) =>
    api.put<PipelineSettings>("/settings/pipeline", body),
  getScoring: () => api.get<ScoringSettings>("/settings/scoring"),
  saveScoring: (body: ScoringSettings) =>
    api.put<ScoringSettings>("/settings/scoring", body),
  getInterviewerAccess: () => api.get<InterviewerAccessSettings>("/settings/interviewer-access"),
  saveInterviewerAccess: (body: InterviewerAccessSettings) =>
    api.put<InterviewerAccessSettings>("/settings/interviewer-access", body),
  revokeInterviewerDomain: (domain: string) =>
    api.post<{ domain: string; sessions_revoked: number }>("/settings/interviewer-access/revoke", { domain }),
  getSampleInterviewLink: () =>
    api.get<SampleInterviewLink>("/settings/interviewer-access/sample-link"),
  resetSampleInterviewLink: () =>
    api.post<SampleInterviewLink>("/settings/interviewer-access/sample-link/reset"),
  getSampleInterviewLinks: () =>
    api.get<SampleInterviewLinks>("/settings/interviewer-access/sample-links"),
  resetSampleInterviewScenario: (roundName: string) =>
    api.post<SampleInterviewLink>(
      `/settings/interviewer-access/sample-links/${encodeURIComponent(roundName)}/reset`
    ),
  getSampleDataVisibility: () =>
    api.get<SampleDataVisibility>("/settings/sample-data-visibility"),
  saveSampleDataVisibility: (visible: boolean) =>
    api.put<SampleDataVisibility>("/settings/sample-data-visibility", { visible }),
  getRoundInterviewers: () =>
    api.get<RoundInterviewersSettings>("/settings/round-interviewers"),
  saveRoundInterviewers: (body: RoundInterviewersSettings) =>
    api.put<RoundInterviewersSettings>("/settings/round-interviewers", body),
  getInterviewScheduling: () =>
    api.get<InterviewSchedulingSettings>("/settings/interview-scheduling"),
  saveInterviewScheduling: (body: InterviewSchedulingSettings) =>
    api.put<InterviewSchedulingSettings>("/settings/interview-scheduling", body),
  revertInterviewScheduling: () =>
    api.post<InterviewSchedulingSettings>("/settings/interview-scheduling/revert"),
  getEmailSendConfig: () => api.get<EmailSendSettings>("/settings/email-send-config"),
  saveEmailSendConfig: (body: EmailSendSettings) =>
    api.put<EmailSendSettings>("/settings/email-send-config", body),
  disableDraftReview: (username: string, password: string) =>
    api.post<EmailSendSettings>("/settings/email-send-config/disable-draft-review", { username, password }),
  enableAutoSend: (username: string, password: string) =>
    api.post<EmailSendSettings>("/settings/email-send-config/enable-auto-send", { username, password }),
  getColumns: () => api.get<ColumnSettings>("/settings/columns"),
  // Ordered [{key, visible}] — list order = left-to-right display order.
  saveColumns: (columns: { key: string; visible: boolean }[]) =>
    api.put<ColumnSettings>("/settings/columns", { columns }),
  reloadFromEnv: () =>
    api.post<{
      reloaded: boolean;
      rescheduled: boolean;
      pipeline: PipelineSettings;
      notifications: NotificationSettings;
      schedule: string;
      next_run: string | null;
    }>("/settings/reload"),
};
