/// <reference types="vite/client" />
import { api } from "./api";
import type { CandidateMaster } from "@/types";
import type { InterviewKit, InterviewOptions, InterviewModeConfig } from "./interview";

// Deliberately NOT the shared `api` axios instance for the public endpoints
// below — its response interceptor bounces ANY 401 to /login and clears the
// admin session (see api.ts). A missing/expired interviewer session is an
// expected, routine 401 here (it just means "show the code challenge"), not
// a dead admin login — so this talks to the backend with plain fetch.
const BASE = `${import.meta.env.VITE_API_URL ?? "http://localhost:8000/api/v1"}/interview`;

export class InterviewerApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

async function publicRequest<T>(path: string, options: RequestInit = {}): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers ?? {}) },
  });
  if (!res.ok) {
    let detail = res.statusText || `Request failed (${res.status})`;
    try {
      const body = await res.json();
      if (body?.detail) detail = body.detail;
    } catch {
      // non-JSON error body — keep the status text
    }
    throw new InterviewerApiError(res.status, detail);
  }
  if (res.status === 204) return undefined as T;
  return res.json() as Promise<T>;
}

const sessionHeader = (sessionToken: string | null): Record<string, string> =>
  sessionToken ? { "X-Interviewer-Session": sessionToken } : {};

// ── Payload shapes (mirror app/api/interviewer.py) ───────────────────────────
// Reuses CandidateMaster's own field types via Pick — the interviewer payload
// is a narrower FIELD SET of the same candidate_master row (see
// _INTERVIEWER_FIELDS in app/api/interviewer.py), never a differently-shaped
// one, so this stays correct automatically as those field types evolve.
export type InterviewerCandidate = Pick<
  CandidateMaster,
  | "candidate_id" | "name" | "stream" | "fresher_or_lateral" | "yearofexp"
  | "currentcompany" | "currentlocation" | "clg" | "highest_coursecompleted"
  | "education_status" | "passoutyr" | "cgpa" | "domain" | "atsscore"
  | "score_breakdown" | "score_penalties" | "certification_bonus"
  | "analysis_report" | "certificates" | "primary_skills" | "job_roles"
  | "projects" | "role_context" | "nlrs" | "latest_remark"
> & {
  has_resume: boolean;
};

export type InterviewerRoundOutcome = "Pass" | "Fail" | "Hold" | "Pending" | null;

export interface InterviewerRound {
  round_id: number;
  round_name: string;
  domain: string | null;
  interviewer: string | null;
  scheduled_on: string | null;
  feedback: string | null;
  score: number | null;
  outcome: InterviewerRoundOutcome;
}

export interface InterviewerContextResponse {
  candidate: InterviewerCandidate;
  round_id: number | null;
  rounds: InterviewerRound[];
}

export interface InterviewerQuestion {
  bucket: string;
  question: string;
  mandatory: boolean;
}

export interface QuestionAnswer extends InterviewerQuestion {
  answer: string;
}

export interface QBResponsePayload {
  index: number;
  bucket: string;
  question: string;
  response_text: string;
  observation: string;
  ai_mark: number | null;
  ai_rationale: string;
  final_mark: number | null;
  max_mark: number;
}

export interface SubmitFeedbackBody {
  answers: QuestionAnswer[];
  overall_feedback: string;
  score: number | null;
  outcome: "Pass" | "Fail";
  // Round 1+ (never Screening) — which stage a "Pass" advances to, when the
  // round allows more than one target (e.g. Round 2 -> Round 3 or Final).
  advance_to?: string | null;
  // Admin-only bypass (re-verified server-side) — jump straight to
  // Hired/Rejected from any round, skipping whatever rounds remain.
  direct_status?: "Hired" | "Rejected" | null;
  // When the round used an allocated question bank.
  qb_allocation_id?: number | null;
  qb_responses?: QBResponsePayload[];
}

// One gated question served to the interviewer. The model answer / hints / rubric
// (answer_points) appear only once answers are locked; the explanation only once
// marks are locked (so the fields are `?` — absent until revealed).
export interface QBGatedQuestion {
  index: number;
  bucket: string;
  question: string;
  why: string;
  difficulty: string;
  follow_up: string | null;
  max_mark: number;
  // Per-question lock state — drives the reveal below.
  answer_locked?: boolean;
  mark_locked?: boolean;
  strong_answer?: string;
  hints?: string[];
  answer_points?: { point: string; marks: number }[];
  explanation?: string;
}

export interface QBGatedBucket {
  name: string;
  questions: QBGatedQuestion[];
}

// A persisted per-question response row (returned so the UI can resume state).
export interface QBSavedResponse {
  question_index: number;
  bucket: string | null;
  question: string;
  response_text: string | null;
  observation: string | null;
  ai_mark: number | null;
  ai_rationale: string | null;
  final_mark: number | null;
  max_mark: number;
  awarded_points: number[];
}

// The question bank (if any) assigned to this interview's round.
export interface AllocatedQuestionBank {
  allocation: {
    allocation_id: number;
    qb_id: number;
    bank_name: string;
    question_count: number;
    status: string;
  } | null;
  buckets: QBGatedBucket[];
  responses?: QBSavedResponse[];
}

// Returned by the per-question lock endpoints — the re-gated buckets + saved rows
// (so the UI updates exactly the just-locked question).
export interface QBLockResult {
  buckets: QBGatedBucket[];
  responses: QBSavedResponse[];
}

export interface QBMarkResult {
  index: number;
  mark: number;
  max: number;
  rationale: string;
}

// Round-aware verdict choices for the CURRENT round — Screening keeps the
// plain Pass/Fail picker (legacy_pass_fail=true); every later round gets
// these instead. See app/api/interviewer.py's get_verdict_options.
export interface VerdictOption {
  key: "advance" | "hire" | "reject" | "direct_hire" | "direct_reject";
  target: string | null;
  label: string;
}

export interface VerdictOptionsResponse {
  round_name: string;
  legacy_pass_fail: boolean;
  is_admin: boolean;
  options: VerdictOption[];
}

export const interviewerService = {
  requestCode: (token: string, email: string) =>
    publicRequest<{ sent: boolean }>(`/${token}/request-code`, {
      method: "POST",
      body: JSON.stringify({ email }),
    }),

  verifyCode: (token: string, email: string, code: string, remember: boolean) =>
    publicRequest<{
      session_token: string | null;
      candidate: InterviewerCandidate;
      round_id: number | null;
      rounds: InterviewerRound[];
    }>(`/${token}/verify-code`, {
      method: "POST",
      body: JSON.stringify({ email, code, remember }),
    }),

  getContext: (token: string, sessionToken: string) =>
    publicRequest<InterviewerContextResponse>(`/${token}/candidate`, {
      headers: sessionHeader(sessionToken),
    }),

  getQuestions: (token: string, sessionToken: string) =>
    publicRequest<{ questions: InterviewerQuestion[] }>(`/${token}/questions`, {
      headers: sessionHeader(sessionToken),
    }),

  // The full, rich interview kit (same generator as the recruiter's "Generate
  // Interview Questions" panel — regenerate/difficulty/focus/aptitude modes).
  generateQuestions: (token: string, sessionToken: string, opts: InterviewOptions = {}) =>
    publicRequest<InterviewKit>(`/${token}/interview-questions`, {
      method: "POST",
      headers: sessionHeader(sessionToken),
      body: JSON.stringify(opts),
    }),

  // The question bank assigned to this round (allocation:null if none — then the
  // interviewer generates a kit as usual).
  getQuestionBank: (token: string, sessionToken: string) =>
    publicRequest<AllocatedQuestionBank>(`/${token}/question-bank`, {
      headers: sessionHeader(sessionToken),
    }),

  // AI-suggest a mark per recorded response (interviewer can override).
  markQuestionBank: (
    token: string,
    sessionToken: string,
    responses: { index: number; bucket: string; question: string; ideal_answer: string; response: string }[]
  ) =>
    publicRequest<{ marks: QBMarkResult[] }>(`/${token}/question-bank/mark`, {
      method: "POST",
      headers: sessionHeader(sessionToken),
      body: JSON.stringify({ responses }),
    }),

  // PER-QUESTION: freeze ONE question's response → reveals that question's model
  // answer + hints + rubric.
  lockQBAnswer: (
    token: string,
    sessionToken: string,
    allocation_id: number,
    r: { index: number; bucket: string; question: string; response_text: string; observation: string }
  ) =>
    publicRequest<QBLockResult>(`/${token}/question-bank/lock-answer`, {
      method: "POST",
      headers: sessionHeader(sessionToken),
      body: JSON.stringify({ allocation_id, ...r }),
    }),

  // PER-QUESTION: freeze ONE question's mark → reveals that question's explanation.
  // final_mark wins; else it's the sum of the ticked rubric point indices.
  lockQBMark: (
    token: string,
    sessionToken: string,
    allocation_id: number,
    m: { index: number; final_mark: number | null; awarded_points: number[]; ai_mark: number | null; ai_rationale: string }
  ) =>
    publicRequest<QBLockResult>(`/${token}/question-bank/lock-mark`, {
      method: "POST",
      headers: sessionHeader(sessionToken),
      body: JSON.stringify({ allocation_id, ...m }),
    }),

  // The config-driven question modes (incl. CUSTOM ones added in Settings →
  // Interview Question Generation). The /interview-modes endpoint is public, so
  // this token-only page can fetch it directly (not the static built-in list).
  getInterviewModes: async (): Promise<InterviewModeConfig[]> => {
    try {
      const base = import.meta.env.VITE_API_URL ?? "http://localhost:8000/api/v1";
      const res = await fetch(`${base}/interview-modes`);
      return res.ok ? ((await res.json()) as InterviewModeConfig[]) : [];
    } catch {
      return [];
    }
  },

  getVerdictOptions: (token: string, sessionToken: string) =>
    publicRequest<VerdictOptionsResponse>(`/${token}/verdict-options`, {
      headers: sessionHeader(sessionToken),
    }),

  submitFeedback: (token: string, sessionToken: string, body: SubmitFeedbackBody) =>
    publicRequest<{ ok: boolean; round: InterviewerRound }>(`/${token}/feedback`, {
      method: "POST",
      headers: sessionHeader(sessionToken),
      body: JSON.stringify(body),
    }),

  // The resume streams as bytes behind a custom auth header, so it can't be a
  // plain <a href>/<iframe src> — fetch it as a blob and hand back an object
  // URL the caller can open in a new tab or an <iframe>.
  fetchResumeBlobUrl: async (token: string, sessionToken: string): Promise<string> => {
    const res = await fetch(`${BASE}/${token}/resume`, { headers: sessionHeader(sessionToken) });
    if (!res.ok) throw new InterviewerApiError(res.status, "Couldn't load the resume.");
    const blob = await res.blob();
    return URL.createObjectURL(blob);
  },

  // Admin/Recruiter-only — mints a shareable link for one candidate, optionally
  // scoped to a specific interview round. Uses the normal authenticated client.
  createLink: (candidateId: string, roundId?: number) =>
    api.post<{ url_path: string }>(
      `/candidates/${candidateId}/interview-link`,
      null,
      roundId != null ? { params: { round_id: roundId } } : undefined
    ),
};

// ── Remembered-session storage (localStorage, keyed per link token — this
// app has no cookies anywhere, see api.ts) ──────────────────────────────────

const sessionKey = (token: string) => `neuleap-interviewer-session:${token}`;

export const interviewerSession = {
  get: (token: string) => localStorage.getItem(sessionKey(token)),
  set: (token: string, sessionToken: string) => localStorage.setItem(sessionKey(token), sessionToken),
  clear: (token: string) => localStorage.removeItem(sessionKey(token)),
};
