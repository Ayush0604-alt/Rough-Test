import { api } from "./api";

// One group of candidates/emails sharing a `source` tag — `source: null` is
// the "no source" bucket, a real selectable batch, not "nothing selected".
// See app.services.batch_archive.
export interface LiveBatch {
  source: string | null;
  candidate_count: number;
  oldest: string | null;
  newest: string | null;
}

export interface ArchivedBatch {
  source: string | null;
  candidate_count: number;
  archived_from: string;
  archived_to: string;
}

export interface ArchiveResult {
  source: string | null;
  candidates_archived: number;
  emails_archived: number;
}

export interface RestoreResult {
  source: string | null;
  candidates_restored: number;
  emails_restored: number;
}

export interface PruneResult {
  source: string | null;
  candidates_pruned: number;
  emails_pruned: number;
  resume_files_deleted: number;
}

// Per-source "Recruiters can apply predicted NBA" — default off for every
// source until explicitly turned on here. Keyed by the source label, with
// "__none__" standing in for the "no source" bucket. See
// app.services.recruiter_apply_config for exactly what this gates.
export interface RecruiterApplyNbaSettings {
  sources: Record<string, boolean>;
}

export const NO_SOURCE_KEY = "__none__";

export const batchArchiveService = {
  listLive: () => api.get<{ batches: LiveBatch[] }>("/batches"),
  listArchived: () => api.get<{ batches: ArchivedBatch[] }>("/batches/archived"),
  archive: (source: string | null) =>
    api.post<ArchiveResult>("/batches/archive", { source }),
  restore: (source: string | null) =>
    api.post<RestoreResult>("/batches/restore", { source }),
  prune: (source: string | null) =>
    api.post<PruneResult>("/batches/prune", { source }),
  getRecruiterApplyNba: () =>
    api.get<RecruiterApplyNbaSettings>("/batches/recruiter-apply-nba"),
  saveRecruiterApplyNba: (source: string | null, enabled: boolean) =>
    api.put<RecruiterApplyNbaSettings>("/batches/recruiter-apply-nba", { source, enabled }),
};
