import { api } from "./api";

// Response of L1 POST /api/v1/intake/upload (app/api/mail.py :: upload).
export interface StageUploadResponse {
  staged: boolean;
  e_id: string;
  attachments: string[];
  links: string[];
}

// File types the L1 mail-intake accepts (mail.py :: ACCEPTED_UPLOAD_EXT).
export const ACCEPTED_UPLOAD_EXT = ".pdf,.docx,.doc,.zip,.xlsx";

// One staged item waiting for the next pipeline run (GET /intake/pending).
export interface PendingItem {
  e_id: string;
  source: string;
  // Recruiter-typed intake source tag (e.g. "LinkedIn", "Naukri") — distinct from
  // `source` above, which is just the pipeline origin ("upload"/"graph"). null for
  // Graph-mail items staged before a source tag was registered/active.
  candidate_source: string | null;
  subject: string;
  received_date: string | null;
  attachments: string[];
  last_status: string;
}

export const intakeService = {
  /**
   * Stage an uploaded file (pdf/docx/doc/zip/xlsx) as a single "direct" mail.
   * Goes through the L1 mail-intake path → appears in Email_Master after a run.
   * `candidateSource` (mandatory — recruiter-typed, e.g. "LinkedIn", "Naukri",
   * "Referral - Jane") is attached to every candidate this batch produces and
   * becomes filterable on the Dashboard.
   */
  stageUpload: (file: File, candidateSource: string) => {
    const form = new FormData();
    form.append("file", file);
    form.append("candidate_source", candidateSource);
    return api.post<StageUploadResponse>("/intake/upload", form, {
      headers: { "Content-Type": "multipart/form-data" },
    });
  },

  /** Files staged (manually uploaded) and waiting for the next pipeline run. */
  listPending: () =>
    api.get<{ count: number; items: PendingItem[] }>("/intake/pending"),

  /** Remove a staged item from the queue before it's processed. */
  discardPending: (eId: string) =>
    api.delete<{ discarded: boolean; e_id: string; removed: number }>(
      `/intake/pending/${eId}`,
    ),
};
