import { api } from "./api";

export interface GraphQueueItem {
  id: string;
  subject: string;
  sender: string;
  received_date: string | null;
  has_attachments: boolean;
}

export interface GraphStatus {
  configured: boolean;
  poll_enabled: boolean;
  poll_interval_seconds: number;
  count: number;
  rejected: number;
  polled_at: string | null;
  error: string | null;
  next_run: string | null;
  schedule: string;
}

export interface GraphQueue {
  count: number;
  rejected: number;
  items: GraphQueueItem[];
  polled_at: string | null;
  error: string | null;
}

export interface DiscardedMailItem {
  id: number;
  message_id: string | null;
  sender_mail_id: string | null;
  subject: string | null;
  received_date: string | null;
  state: "discarded" | "restored";
  discarded_by_email: string | null;
  discarded_by_name: string | null;
  discarded_at: string;
  restored_by_email: string | null;
  restored_by_name: string | null;
  restored_at: string | null;
}

export interface DiscardResult {
  discarded: number;
  discarded_ids: number[];
  failed: number;
  count: number;
  items: GraphQueueItem[];
}

export interface GraphFolderCountMap {
  inbox?: number | null;
  processing?: number | null;
  processed?: number | null;
  failed?: number | null;
  non_resume?: number | null;
}

export interface GraphFolderCounts {
  configured: boolean;
  // `counts` is the unread badge shown next to each Outlook folder; `totals` is the
  // full item count per folder (for reference).
  counts: GraphFolderCountMap;
  totals?: GraphFolderCountMap;
  error: string | null;
}

export const graphService = {
  status: () => api.get<GraphStatus>("/graph/status"),
  queue: () => api.get<GraphQueue>("/graph/queue"),
  pollNow: () => api.post<GraphQueue>("/graph/poll", {}),
  folderCounts: () => api.get<GraphFolderCounts>("/graph/folder-counts"),
  // Set aside selected (or every) queued mail — excludes it from the next pipeline run.
  discard: (ids: string[], all = false) =>
    api.post<DiscardResult>("/graph/discard", { ids, all }),
  // Open (restorable) set-aside items by default; history=true for the full report.
  discarded: (history = false) =>
    api.get<DiscardedMailItem[]>(`/graph/discarded${history ? "?history=true" : ""}`),
  restoreDiscarded: (id: number) =>
    api.post<{ ok: boolean; id: number }>(`/graph/discarded/${id}/restore`, {}),
};
