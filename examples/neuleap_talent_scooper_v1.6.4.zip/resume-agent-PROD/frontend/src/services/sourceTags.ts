import { api } from "./api";

// A registered "social post" source tag (Mailbox → "Register recent social
// post as a source tag"). The active one is auto-stamped as the intake source
// onto every new Graph-mail resume while it's active — see app.services.source_tags.
export interface SourceTag {
  id: string;
  platform: string;
  label: string;
  post_url: string | null;
  note: string | null;
  // Duplicate-resume check scope for this tag's candidates — false (default)
  // = system-wide compare against every candidate regardless of source; true
  // = only compare against candidates sharing this exact source label.
  dup_check_scoped: boolean;
  created_at: string;
}

export interface SourceTagsResponse {
  tags: SourceTag[]; // newest first
  active_id: string | null;
}

export const sourceTagsService = {
  list: () => api.get<SourceTagsResponse>("/source-tags"),

  // Registers a new tag. Not automatically active — call setActive separately.
  register: (body: { platform: string; label: string; post_url?: string; note?: string }) =>
    api.post<SourceTagsResponse>("/source-tags", body),

  // Edits an existing tag's platform/label/URL/note in place (by id) —
  // candidates already stamped with the old label are unaffected.
  update: (tagId: string, body: { platform: string; label: string; post_url?: string; note?: string }) =>
    api.put<SourceTagsResponse>(`/source-tags/${tagId}`, body),

  // Pass null to clear (no tag active — new Graph mail gets no auto source).
  setActive: (tagId: string | null) =>
    api.put<SourceTagsResponse>("/source-tags/active", { tag_id: tagId }),

  // Scope the L2 duplicate-resume check to just this source (default off).
  setDupCheckScope: (tagId: string, scoped: boolean) =>
    api.put<SourceTagsResponse>(`/source-tags/${tagId}/dup-check-scope`, { scoped }),

  remove: (tagId: string) => api.delete<SourceTagsResponse>(`/source-tags/${tagId}`),
};
