import { api } from "./api";

export type DayRule =
  | "full"
  | "full_extended"
  | "early_morning"
  | "first_half"
  | "second_half"
  | "late_evening"
  | "none";

// A per-round override of the allocation rules — only the fields present
// override the global defaults; the rest fall through.
export interface RoundRuleOverride {
  slot_minutes?: number;
  gap_minutes?: number;
  max_day_fraction?: number;
  days_allowed?: Record<string, DayRule>;
}

export interface PoolDefaults {
  slot_minutes: number;
  gap_minutes: number;
  max_day_fraction: number;
  days_allowed: Record<string, DayRule>;
  // % of candidates who DON'T advance out of each round (e.g. Screening: 40 means
  // 40% filtered out there) — feeds compute_velocity's per-round funnel targets.
  funnel_filter_pct: Record<string, number>;
  // Per-round overrides of the allocation rules (keyed by round name).
  round_overrides: Record<string, RoundRuleOverride>;
}

export interface InterviewPool {
  id: number;
  source_label: string | null;
  // A pool covers one or more rounds at once — each gathers its own slots
  // against its own roster, but shares this pool's rules/date range and the
  // same source-tag candidate pipeline.
  round_names: string[];
  label: string;
  range_start: string;
  range_end: string;
  slot_minutes: number;
  gap_minutes: number;
  max_day_fraction: number;
  days_allowed: Record<string, DayRule>;
  // Recruiter-editable override for the pool-size (velocity) estimate — NULL
  // means "use the trailing-14-day candidate velocity" (the default).
  manual_projected_candidates: number | null;
  archived: boolean;
  created_at: string;
  updated_at: string;
}

export interface PoolSlot {
  id: number;
  pool_id: number;
  round_name: string;
  interviewer_email: string;
  interviewer_name: string | null;
  slot_start: string;
  slot_end: string;
  graph_event_id: string | null;
  // Short codename (Batman, ChotaBheem, ...) — same string appended to the
  // placeholder's calendar event subject. Cosmetic only, null on old rows.
  slot_name: string | null;
  status: "open" | "booked" | "removed_by_interviewer" | "cancelled";
  booked_candidate_id: string | null;
  booked_round_id: number | null;
  created_at: string;
  updated_at: string;
}

export interface PoolRoundVelocity {
  round_name: string;
  // This round's own target — already cascaded through Predicted-NBA entry
  // fractions (fast-tracked candidates skip earlier rounds) and the funnel
  // filter % configured above, not just the raw top-of-funnel figure.
  target: number;
  existing_strength: number;
  strength_breakdown: Record<string, number>;
  gap: number;
}

export interface PoolVelocity {
  velocity_per_day: number;
  range_days: number;
  // What the raw trailing-14-day velocity math projects, regardless of override —
  // shown alongside the effective figure so a recruiter can see what they're overriding.
  auto_projected_candidates: number;
  projected_candidates: number;
  manual_override: boolean;
  needed_pool_size: number;
  existing_strength: number;
  gap: number;
  per_round: PoolRoundVelocity[];
}

export interface GatherResult {
  created: number;
  skipped: number;
  warnings: string[];
  // This round's own target, keyed by round name — see PoolRoundVelocity.target.
  target_per_round?: Record<string, number>;
}

export interface SyncResult {
  checked: number;
  removed: number;
  rescheduled: number;
}

export interface PoolCreatePayload {
  source_label: string | null;
  round_names: string[];
  label: string;
  range_start: string;
  range_end: string;
  slot_minutes?: number;
  gap_minutes?: number;
  max_day_fraction?: number;
  days_allowed?: Record<string, DayRule>;
}

export const interviewPoolsService = {
  list: () => api.get<InterviewPool[]>("/interview-pools"),
  getDefaults: () => api.get<PoolDefaults>("/interview-pools/defaults"),
  saveDefaults: (body: PoolDefaults) => api.put<PoolDefaults>("/interview-pools/defaults", body),
  // Discard any customization and restore the shipped default calculation rules.
  revertDefaults: () => api.post<PoolDefaults>("/interview-pools/defaults/revert"),
  create: (body: PoolCreatePayload) => api.post<InterviewPool>("/interview-pools", body),
  update: (
    poolId: number,
    body: Partial<PoolCreatePayload> & { manual_projected_candidates?: number | null }
  ) => api.patch<InterviewPool>(`/interview-pools/${poolId}`, body),
  archive: (poolId: number) => api.post<InterviewPool>(`/interview-pools/${poolId}/archive`),
  slots: (poolId: number) => api.get<PoolSlot[]>(`/interview-pools/${poolId}/slots`),
  velocity: (poolId: number) => api.get<PoolVelocity>(`/interview-pools/${poolId}/velocity`),
  // Per-round candidate slot-picker links for this pool — sample-candidate
  // backed test invites (/schedule/{token}); null for rounds with no sample
  // scenario (Round 3).
  pickerLinks: (poolId: number) =>
    api.get<{ links: Record<string, string | null> }>(`/interview-pools/${poolId}/picker-links`),
  // Refresh — pulls the latest status of EXISTING placeholders from Graph
  // (deleted/moved directly on the interviewer's calendar?). Creates nothing.
  sync: (poolId: number) => api.post<SyncResult>(`/interview-pools/${poolId}/sync`),
  // Make placeholders — allocates NEW slots per the pool's configured rules.
  gather: (poolId: number) => api.post<GatherResult>(`/interview-pools/${poolId}/gather`),
};
