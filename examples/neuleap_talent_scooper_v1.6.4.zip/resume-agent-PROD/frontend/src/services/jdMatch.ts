import { api } from "./api";

export interface JdMatchResult {
  candidate_id: string;
  // null when the model didn't return a usable entry for this candidate.
  score: number | null;
  note: string | null;
}

export interface JdDimension {
  name: string;
  score: number | null;
  reason: string;
}

// Detailed "why this score" breakdown for ONE candidate — fetched on demand
// when the recruiter clicks the score in the JD Match column.
export interface JdMatchExplanation {
  candidate_id: string;
  score: number | null;
  summary: string;
  dimensions: JdDimension[];
  strengths: string[];
  gaps: string[];
}

export const jdMatchService = {
  // Extracts plain text from an uploaded JD file (.pdf/.docx/.doc/.txt) —
  // used to fill the paste box, not sent straight to scoring, so the
  // recruiter can review/edit the extracted text first.
  extractText: (file: File) => {
    const form = new FormData();
    form.append("file", file);
    return api.post<{ text: string }>("/jd-match/extract-text", form, {
      headers: { "Content-Type": "multipart/form-data" },
    });
  },
  // Scores the given candidates (typically the Screening page's currently
  // filtered/visible list) against a job description in ONE batched call.
  score: (jdText: string, candidateIds: string[]) =>
    api.post<{ results: JdMatchResult[] }>("/jd-match", {
      jd_text: jdText,
      candidate_ids: candidateIds,
    }),
  // Detailed per-candidate breakdown behind a batch score. prior score/note
  // keep the explanation consistent with the number the user clicked.
  explain: (jdText: string, candidateId: string, priorScore: number | null, priorNote: string | null) =>
    api.post<JdMatchExplanation>("/jd-match/explain", {
      jd_text: jdText,
      candidate_id: candidateId,
      prior_score: priorScore,
      prior_note: priorNote,
    }),
};
