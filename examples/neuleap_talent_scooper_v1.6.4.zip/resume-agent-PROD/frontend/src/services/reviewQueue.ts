import { api } from "./api";
import type { ReviewItem, ReviewAction } from "@/types/review";

export const reviewQueueService = {
  list: () => api.get<ReviewItem[]>("/review-queue"),

  count: () => api.get<{ open: number }>("/review-queue/count"),

  /** Discarded items — kept for restore / permanent deletion. */
  listDiscarded: () => api.get<ReviewItem[]>("/review-queue/discarded"),

  resolve: (reviewId: number, action: ReviewAction) =>
    api.post(`/review-queue/${reviewId}/resolve`, { action }),

  /** Re-open a discarded item (undo a discard). */
  restore: (reviewId: number) =>
    api.post(`/review-queue/${reviewId}/restore`),

  /** Permanently delete a discarded item — removes its S3 file AND the row. */
  deletePermanent: (reviewId: number) =>
    api.delete<{ ok: boolean; review_id: number; deleted: boolean; file_deleted: boolean }>(
      `/review-queue/${reviewId}`,
    ),

  /** Permanently delete EVERY discarded item — removes all their S3 files AND rows. */
  deleteAllDiscarded: () =>
    api.delete<{ ok: boolean; deleted: number; file_deleted: number }>(
      `/review-queue/discarded`,
    ),

  /** Override a not-a-resume/failed verdict → force the file through to a candidate. */
  approve: (reviewId: number) =>
    api.post<{ ok: boolean; review_id: number; candidate_id: string }>(
      `/review-queue/${reviewId}/approve`,
    ),

  /** Upload the missing resume for an excel-row / failed-link item → creates a candidate. */
  upload: (reviewId: number, file: File) => {
    const form = new FormData();
    form.append("file", file);
    return api.post<{ ok: boolean; review_id: number; candidate_id: string }>(
      `/review-queue/${reviewId}/upload`,
      form,
      { headers: { "Content-Type": "multipart/form-data" } },
    );
  },

  /** Run (or re-run) L3 extraction for a candidate stuck at 'Pending Extraction'.
   *  Reuses the standalone extraction endpoint; a clean run flips the candidate to
   *  Active and it drops off this queue. */
  runExtraction: (candidateId: string) =>
    api.post<{ status: string; candidate_id: string }>(
      `/candidates/${candidateId}/process`,
    ),

  /** Inline URL for a dropped file (PDF/DOCX/image) — opens in a new tab. */
  fileUrl: (reviewId: number) =>
    `${api.defaults.baseURL}/review-queue/${reviewId}/file`,

  /** Fetch the dropped file as a blob for the in-app viewer (surfaces errors). */
  fetchFile: (reviewId: number) =>
    api.get<Blob>(`/review-queue/${reviewId}/file`, { responseType: "blob" }),
};
