/// <reference types="vite/client" />
import { api } from "./api";

// Deliberately NOT the shared `api` axios instance for the public endpoints
// below — same reasoning as services/interviewer.ts: a missing/expired
// session here is an expected 401 (just means "show the code challenge"),
// not a dead admin login, so this talks to the backend with plain fetch.
const BASE = `${import.meta.env.VITE_API_URL ?? "http://localhost:8000/api/v1"}/schedule`;

export class CandidateSlotApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

async function publicRequest<T>(path: string, options: RequestInit = {}): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers ?? {}) },
  });
  if (!res.ok) {
    let detail = res.statusText || `Request failed (${res.status})`;
    try {
      const body = await res.json();
      if (body?.detail) detail = body.detail;
    } catch {
      // non-JSON error body — keep the status text
    }
    throw new CandidateSlotApiError(res.status, detail);
  }
  if (res.status === 204) return undefined as T;
  return res.json() as Promise<T>;
}

const sessionHeader = (sessionToken: string | null): Record<string, string> =>
  sessionToken ? { "X-Slot-Session": sessionToken } : {};

export interface SlotStatus {
  candidate_name: string | null;
  // True for pool-table check links (SAMPLE-DEMO fixture) — the page shows a
  // "test invite" label instead of greeting with the fixture's dummy name.
  is_sample?: boolean;
  round_name: string;
  booked: boolean;
  rejected: boolean;
  slot_start: string | null;
  slot_end: string | null;
  remind_me_again: boolean;
}

export interface AvailableSlot {
  start: string;
  end: string;
  // Set only when the invite is pool-scoped (app.services.interview_pools) —
  // booking targets a placeholder at this time; the backend claims whichever
  // parallel interviewer placeholder is still free.
  slot_id?: number;
  // Pool slots only — how many parallel interviewer placeholders remain open at
  // this time. Multiple interviewers on a round share a time, so one button can
  // still seat several candidates. Absent/1 for single-capacity or Graph slots.
  remaining?: number;
}

export const candidateSlotsService = {
  requestCode: (token: string, email: string) =>
    publicRequest<{ sent: boolean }>(`/${token}/request-code`, {
      method: "POST",
      body: JSON.stringify({ email }),
    }),

  verifyCode: (token: string, email: string, code: string, remember: boolean) =>
    publicRequest<{ session_token: string | null; status: SlotStatus }>(`/${token}/verify-code`, {
      method: "POST",
      body: JSON.stringify({ email, code, remember }),
    }),

  // Staff (Admin/SysAdmin) alternative to the emailed code — verify with app
  // credentials to CHECK a picker link without access to the candidate's inbox.
  staffAccess: (token: string, username: string, password: string) =>
    publicRequest<{ session_token: string | null; status: SlotStatus }>(`/${token}/staff-access`, {
      method: "POST",
      body: JSON.stringify({ username, password }),
    }),

  getStatus: (token: string, sessionToken: string) =>
    publicRequest<SlotStatus>(`/${token}/status`, { headers: sessionHeader(sessionToken) }),

  getSlots: (token: string, sessionToken: string) =>
    publicRequest<{ slots: AvailableSlot[] }>(`/${token}/slots`, { headers: sessionHeader(sessionToken) }),

  bookSlot: (token: string, sessionToken: string, start: string, end: string, slotId?: number) =>
    publicRequest<SlotStatus>(`/${token}/book`, {
      method: "POST",
      headers: sessionHeader(sessionToken),
      body: JSON.stringify({ start, end, slot_id: slotId ?? null }),
    }),

  setRemindMeAgain: (token: string, sessionToken: string, value: boolean) =>
    publicRequest<{ remind_me_again: boolean }>(`/${token}/remind-me-again`, {
      method: "POST",
      headers: sessionHeader(sessionToken),
      body: JSON.stringify({ value }),
    }),

  // "Need help?" — the candidate's message lands on their row in status
  // tracking as a red "!" until a recruiter reads it and marks it handled.
  sendHelp: (token: string, sessionToken: string, message: string) =>
    publicRequest<{ ok: boolean }>(`/${token}/help`, {
      method: "POST",
      headers: sessionHeader(sessionToken),
      body: JSON.stringify({ message }),
    }),

  // Admin/Recruiter-only — mints (or re-fetches) a shareable slot-selection
  // link for one candidate's round, and emails the invite immediately
  // regardless of the "Auto-send invites" setting (this is an explicit,
  // recruiter-initiated action, not the automatic stage-advance hook).
  createInvite: (candidateId: string, roundId: number) =>
    api.post<{ url_path: string }>(
      `/candidates/${candidateId}/slot-invite`,
      null,
      { params: { round_id: roundId } }
    ),
};

// ── Remembered-session storage (localStorage, keyed per link token) ────────

const sessionKey = (token: string) => `neuleap-slot-session:${token}`;

export const candidateSlotSession = {
  get: (token: string) => localStorage.getItem(sessionKey(token)),
  set: (token: string, sessionToken: string) => localStorage.setItem(sessionKey(token), sessionToken),
  clear: (token: string) => localStorage.removeItem(sessionKey(token)),
};
