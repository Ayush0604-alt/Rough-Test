import { api } from "./api";

export type FeedbackKind = "bug" | "feature";
export type FeedbackPriority = "P1" | "P2" | "P3" | "P4" | "P5";
export type FeedbackMoscow = "must" | "should" | "could" | "wont";
export type FeedbackStatus = "open" | "in_progress" | "resolved" | "closed";

export interface FeedbackReport {
  id: number;
  kind: FeedbackKind;
  title: string;
  description: string;
  priority: FeedbackPriority;
  moscow: FeedbackMoscow | null;
  reporter_email: string;
  reporter_name: string;
  reporter_role: string | null;
  status: FeedbackStatus;
  created_at: string | null;
  updated_at: string | null;
}

export interface FeedbackInput {
  kind: FeedbackKind;
  title: string;
  description: string;
  priority: FeedbackPriority;
  moscow: FeedbackMoscow;
}

export const feedbackService = {
  // Any signed-in user files this; the reporter is stamped server-side.
  submit: (body: FeedbackInput) => api.post<FeedbackReport>("/feedback", body),

  // Admin / System Admin only.
  list: () => api.get<FeedbackReport[]>("/feedback"),
  updateStatus: (id: number, status: FeedbackStatus) =>
    api.patch<FeedbackReport>(`/feedback/${id}`, { status }),
  remove: (id: number) => api.delete(`/feedback/${id}`),

  downloadXlsx: async () => {
    const res = await api.get("/feedback.xlsx", { responseType: "blob" });
    const url = URL.createObjectURL(res.data as Blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "feedback_reports.xlsx";
    a.click();
    URL.revokeObjectURL(url);
  },
};
