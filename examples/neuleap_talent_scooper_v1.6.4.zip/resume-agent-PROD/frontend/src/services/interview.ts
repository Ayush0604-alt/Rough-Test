import { api } from "./api";

export type Difficulty = "Easy" | "Medium" | "Hard" | "Very Hard";

/** A rubric point: a credit-bearing thing a good answer covers, worth `marks`.
 *  The points' marks sum to the question's max (out of 10). */
export interface AnswerPoint {
  point: string;
  marks: number;
}

export interface InterviewQuestion {
  question: string;
  why: string;
  difficulty: Difficulty | string;
  strong_answer: string;
  follow_up: string | null;
  /** Interviewer cues — revealed with the model answer after answers are locked. */
  hints?: string[];
  /** Scoring rubric (partial credit) — revealed after answers are locked. */
  answer_points?: AnswerPoint[];
  /** Fuller correct-answer writeup — revealed after marks are locked. */
  explanation?: string;
}

export interface InterviewBucket {
  name: string;
  questions: InterviewQuestion[];
}

export interface WebSource {
  section: string;
  title: string;
  url: string;
  snippet: string;
}

export interface InterviewKit {
  summary: {
    name: string;
    stream: string | null;
    atsscore: number | null;
    experience_type: string;
    difficulty: string;
  };
  buckets: InterviewBucket[];
  generated_by?: "llm" | "fallback";
  // Web sources the kit was grounded in (present only when Search web found hits).
  sources?: WebSource[];
}

// Opt-in aptitude buckets layered on top of the standard kit — selected via the
// "Generate Interview Questions" dropdown on the candidate page. Multi-select:
// picking several combines all of them into one kit alongside the base questions.
export type InterviewMode =
  | "sql_aptitude"
  | "logical_reasoning"
  | "dsa_aptitude"
  | "python_libraries_aptitude"
  | "data_eng_dwh_aptitude"
  | "prompt_writing"
  | "operations_research"
  | "analytical_reasoning";

// The bucket NAME the backend gives each mode — used to key composition weights.
export const MODE_BUCKET_LABEL: Record<InterviewMode, string> = {
  sql_aptitude: "SQL Aptitude",
  logical_reasoning: "Logical Thinking Ability Evaluation",
  dsa_aptitude: "DSA (Data Structures & Algorithms) Aptitude",
  python_libraries_aptitude: "Python Libraries Aptitude (GenAI, Data Engineering & FastAPI)",
  data_eng_dwh_aptitude: "Data Engineering & Data Warehousing Aptitude",
  prompt_writing: "Prompt Writing",
  operations_research: "Operations Research",
  analytical_reasoning: "Analytical Thinking & Logical Reasoning",
};

export const INTERVIEW_MODE_OPTIONS: { key: InterviewMode; label: string }[] = [
  { key: "sql_aptitude", label: "SQL Aptitude Questions" },
  { key: "logical_reasoning", label: "Logical Thinking Ability Evaluation Questions" },
  { key: "dsa_aptitude", label: "DSA (Data Structures & Algorithms) Aptitude Questions" },
  {
    key: "python_libraries_aptitude",
    label: "Aptitude Questions against Python Libraries across GenAI, Data Engineering & FastAPI",
  },
  { key: "data_eng_dwh_aptitude", label: "Data Engineering & Data Warehousing Aptitude Questions" },
  { key: "prompt_writing", label: "Prompt Writing" },
  { key: "operations_research", label: "Operations Research type Questions" },
  { key: "analytical_reasoning", label: "Analytical Thinking & Logical Reasoning (estimation & puzzles)" },
];

// Independent of difficulty_bias (conceptual depth): how much hands-on WORK a
// question demands during the interview itself — see app/api/interview.py's
// InterviewRequest.effort. "lighter" is today's default quick-question style.
export type InterviewEffort = "lighter" | "medium" | "harder";

export interface InterviewOptions {
  focus?: "projects" | "experience" | "system_design";
  difficulty_bias?: "easier" | "harder";
  // Bumped on each Regenerate so the backend returns a fresh kit for the same options.
  variant?: number;
  // Extra aptitude modes to combine with the standard, profile-grounded kit.
  modes?: InterviewMode[];
  effort?: InterviewEffort;
  // Composition rider — section (bucket) name → relative weight, controlling
  // roughly what share of the total questions each section contributes.
  mode_weights?: Record<string, number>;
  // Ground the selected modes in a fresh web search of popular resources.
  search_web?: boolean;
  // Generate generic, cohort-uniform questions (not personalized to this
  // candidate) — the basis for a reusable question bank / placement drive.
  avoid_personalization?: boolean;
  // Approximate total number of questions across all sections.
  total_questions?: number;
  // Section (bucket) names to omit entirely from the kit.
  exclude_sections?: string[];
  // Per-section difficulty level — section (bucket) name → "B" (Beginner) |
  // "I" (Intermediate) | "E" (Expert) | "A" (Advanced). Steers the generator to
  // pitch each section's questions at that level.
  section_levels?: Record<string, "B" | "I" | "E" | "A">;
  // General (candidate-less) generation only — the stream/domain to target and
  // the base difficulty (difficulty_bias still nudges it).
  stream?: string | null;
  difficulty?: string | null;
}

// A saved, reusable question bank (generic questions for a cohort).
export interface QuestionBank {
  qb_id: number;
  name: string;
  stream: string | null;
  difficulty: string | null;
  modes: string[];
  question_count: number;
  buckets: InterviewBucket[];
  summary: InterviewKit["summary"] | null;
  sources: WebSource[];
  // The full generation options this bank was built with (composition mix, total,
  // excludes, effort, focus, difficulty) — Customize restores these verbatim.
  options?: InterviewOptions | null;
  // Ever assigned to a candidate (leaderboard was active) — deleting then needs
  // the discard + heightened 2-password flow, even after a discard.
  had_allocations?: boolean;
  created_by: string | null;
  status: string;
  created_at: string;
}

export interface QuestionBankInput {
  name: string;
  stream?: string | null;
  difficulty?: string | null;
  modes?: string[];
  buckets: InterviewBucket[];
  summary?: InterviewKit["summary"] | null;
  sources?: WebSource[];
  options?: InterviewOptions | null;
}

// A question bank ASSIGNED to a candidate's interview round.
export interface QuestionBankAllocation {
  allocation_id: number;
  qb_id: number;
  candidate_id: string;
  round_id: number | null;
  round_name: string | null;
  interviewer: string | null;
  slot_start: string | null;
  slot_end: string | null;
  status: string;
  source_tag: string | null;
  assigned_by: string | null;
  created_at: string;
  bank_name: string | null;
  question_count: number;
}

export interface AllocationInput {
  qb_id: number;
  round_id?: number | null;
  round_name?: string | null;
  interviewer?: string | null;
  source_tag?: string | null;
}

export interface LeaderboardRow {
  allocation_id: number;
  candidate_id: string;
  candidate_name: string;
  status: string;
  round_name: string | null;
  interviewer: string | null;
  slot_start: string | null;
  slot_end: string | null;
  questions_total: number;
  answered: number;
  total_mark: number;
  max_mark: number;
  scored: boolean;
  rank: number | null;
  // Set once this candidate is unassigned from the leaderboard — a soft delete,
  // so the row (and any recorded responses/marks) stays for the record.
  removed_at: string | null;
  removed_by: string | null;
}

export interface Leaderboard {
  bank: { qb_id: number; name: string; question_count: number };
  summary: { total: number; assigned: number; in_progress: number; scored: number; removed: number };
  rows: LeaderboardRow[];
}

// The leaderboard drill-down (i): the candidate's full response sheet — every
// bank question with their answer + marks, model answer, rubric, explanation.
export interface ResponseSheetItem {
  index: number;
  bucket: string;
  question: string;
  why: string;
  difficulty: string;
  hints: string[];
  strong_answer: string;
  answer_points: AnswerPoint[];
  explanation: string;
  response_text: string;
  observation: string;
  ai_mark: number | null;
  ai_rationale: string;
  final_mark: number | null;
  awarded_points: number[];
  max_mark: number;
  answered: boolean;
  answer_locked: boolean;
  mark_locked: boolean;
}

export interface ResponseSheet {
  allocation_id: number;
  candidate_id: string;
  candidate_name: string;
  status: string;
  round_name: string | null;
  interviewer: string | null;
  slot_start: string | null;
  slot_end: string | null;
  questions_total: number;
  answered: number;
  total_mark: number;
  max_mark: number;
  items: ResponseSheetItem[];
}

export interface BulkCandidate {
  candidate_id: string;
  name: string | null;
  assigned_qb_id: number | null;
  assigned_to_this: boolean;
}

export interface AllocationScopeEntry {
  source_tag: string | null;
  round_name: string | null;
  n: number;
}

export type AllocationSummary = Record<
  string,
  {
    assigned: number;
    in_progress: number;
    scored: number;
    collected: number;
    removed?: number;
    total: number;
    scope: AllocationScopeEntry[];
    avg_score_pct: number | null;
  }
>;

// A question-generation MODE as configured in Settings (defaults + custom).
export interface InterviewModeConfig {
  key: string;
  label: string;
  bucket_name: string;
  topic: string;
  guidance: string;
}

export interface InterviewPromptConfig {
  prompt: string;
  default: string;
  is_custom: boolean;
}

export const interviewService = {
  /** POST /candidates/{id}/interview-questions — context-aware interview kit. */
  generate: (candidateId: string, opts: InterviewOptions = {}) =>
    api.post<InterviewKit>(`/candidates/${candidateId}/interview-questions`, opts),

  // The active question-mode list (drives the dropdown). Any authenticated role.
  getModes: () => api.get<InterviewModeConfig[]>("/interview-modes"),
  // Admin: replace the mode list / reset to default.
  saveModes: (modes: InterviewModeConfig[]) => api.put<InterviewModeConfig[]>("/interview-modes", modes),
  revertModes: () => api.post<InterviewModeConfig[]>("/interview-modes/revert"),

  // The editable generation prompt (SKILL). Admin edits / resets.
  getPrompt: () => api.get<InterviewPromptConfig>("/interview-prompt"),
  savePrompt: (prompt: string) => api.put<InterviewPromptConfig>("/interview-prompt", { prompt }),
  revertPrompt: () => api.post<InterviewPromptConfig>("/interview-prompt/revert"),

  // ── Question banks (saved generic kits) ──
  // The suggested name is FITTED to the bank's character (difficulty + modes +
  // stream) — an analytical bank leans scientist, a prompt bank leans writer, etc.
  suggestBankName: (ctx?: { difficulty?: string | null; stream?: string | null; modes?: string[] }) =>
    api.get<{ name: string }>("/question-banks/suggest-name", {
      params: {
        ...(ctx?.difficulty ? { difficulty: ctx.difficulty } : {}),
        ...(ctx?.stream ? { stream: ctx.stream } : {}),
        ...(ctx?.modes && ctx.modes.length ? { modes: ctx.modes.join(",") } : {}),
      },
    }),
  listBanks: (includeArchived = false) =>
    api.get<QuestionBank[]>("/question-banks", { params: { include_archived: includeArchived } }),
  saveBank: (bank: QuestionBankInput) => api.post<QuestionBank>("/question-banks", bank),
  // Duplicate a bank as the next Roman-numeral version (name sticks + " II"/"III"…).
  duplicateBank: (qbId: number) => api.post<QuestionBank>(`/question-banks/${qbId}/duplicate`),
  deleteBank: (
    qbId: number,
    body?: { sysadmin_email?: string; sysadmin_password?: string; user_password?: string }
  ) => api.delete<{ deleted: boolean }>(`/question-banks/${qbId}`, body ? { data: body } : undefined),
  // Clear & discard a bank's leaderboard (assignments + responses) — irreversible;
  // requires the caller's password.
  discardLeaderboard: (qbId: number, password: string) =>
    api.post<{ discarded: number }>(`/question-banks/${qbId}/discard-leaderboard`, { password }),
  // Restore the built-in sample banks (only creates ones whose name is missing).
  reseedBanks: () => api.post<{ restored: number; samples: string[] }>("/question-banks/reseed"),
  // AI-backfill hints + rubric + explanation for a bank's questions that lack them
  // (so older banks become markable with the gated interviewer flow).
  enrichBank: (qbId: number) =>
    api.post<{ enriched: number; bank: QuestionBank }>(`/question-banks/${qbId}/enrich`, {}),
  // Next Roman-numeral version name for a base (used when customising a bank).
  nextVersionName: (base: string) =>
    api.get<{ name: string }>("/question-banks/next-version", { params: { base } }),
  // Generate a generic, candidate-less kit (the "General" generator on the QB page).
  generateGeneral: (opts: InterviewOptions = {}) =>
    api.post<InterviewKit>("/question-banks/generate-general", opts),

  // ── Allocating a bank to a candidate's interview ──
  getCandidateAllocation: (candidateId: string, roundId?: number | null) =>
    api.get<{ allocation: QuestionBankAllocation | null }>(
      `/candidates/${candidateId}/question-bank-allocation`,
      { params: roundId != null ? { round_id: roundId } : {} }
    ),
  assignBank: (candidateId: string, body: AllocationInput) =>
    api.put<{ allocation: QuestionBankAllocation }>(
      `/candidates/${candidateId}/question-bank-allocation`,
      body
    ),
  removeAllocation: (candidateId: string, roundId?: number | null) =>
    api.delete<{ allocation: null }>(`/candidates/${candidateId}/question-bank-allocation`, {
      params: roundId != null ? { round_id: roundId } : {},
    }),

  // ── Bulk-assign by source tag + leaderboard + export (Question Banks page) ──
  allocationSummary: () =>
    api.get<{ summary: AllocationSummary }>("/question-banks-allocation-summary"),
  bankCandidates: (qbId: number, sourceTag?: string | null, roundNames?: string[]) =>
    api.get<{ candidates: BulkCandidate[] }>(`/question-banks/${qbId}/candidates`, {
      params: {
        ...(sourceTag != null ? { source_tag: sourceTag } : {}),
        ...(roundNames && roundNames.length ? { round_names: roundNames.join(",") } : {}),
      },
    }),
  bulkAllocate: (qbId: number, body: { source_tag?: string | null; candidate_ids?: string[]; round_names?: string[] }) =>
    api.post<{ allocated: number }>(`/question-banks/${qbId}/bulk-allocate`, body),
  leaderboard: (qbId: number) => api.get<Leaderboard>(`/question-banks/${qbId}/leaderboard`),
  // Unassign one candidate from a bank's leaderboard (responses cascade).
  removeAllocationRow: (qbId: number, allocationId: number) =>
    api.delete<{ removed: boolean }>(`/question-banks/${qbId}/allocations/${allocationId}`),
  // Full response sheet for one candidate's allocation (leaderboard drill-down).
  allocationResponses: (qbId: number, allocationId: number) =>
    api.get<ResponseSheet>(`/question-banks/${qbId}/allocations/${allocationId}/responses`),
  downloadLeaderboardXlsx: async (qbId: number, name: string) => {
    const res = await api.get(`/question-banks/${qbId}/leaderboard.xlsx`, { responseType: "blob" });
    const url = URL.createObjectURL(res.data as Blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `leaderboard_${name.replace(/[^A-Za-z0-9]+/g, "_")}.xlsx`;
    a.click();
    URL.revokeObjectURL(url);
  },
};
