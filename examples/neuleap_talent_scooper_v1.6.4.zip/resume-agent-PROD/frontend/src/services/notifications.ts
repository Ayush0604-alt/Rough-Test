import { api } from "./api";
import type { AppNotification } from "@/types/notification";

export const notificationsService = {
  /** GET /api/v1/notifications — persisted feed, newest first (carries read_at). */
  list: () => api.get<AppNotification[]>("/notifications"),
  /** POST /api/v1/notifications/mark-all-read — stamp every unread as read. */
  markAllRead: () => api.post<{ marked: number }>("/notifications/mark-all-read"),
  /** POST /api/v1/notifications/:id/read — mark a single notification read. */
  markRead: (id: string) =>
    api.post<{ updated: boolean }>(`/notifications/${encodeURIComponent(id)}/read`),
};
