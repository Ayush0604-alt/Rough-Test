import { api } from "./api";

// Mirrors app/api/orchestrator.py :: _phase2_downstream result rows.
export interface PipelineMailResult {
  e_id: string;
  total_files?: number;
  passed?: number;
  failed?: number;
  extractions?: number;
  error?: string;
}

// Mirrors orchestrator.run_all() return shape.
export interface PipelineRunResult {
  batch_id: string | null;
  mail_count: number;
  processed: number;
  results: PipelineMailResult[];
  skipped?: boolean;   // true when the run was skipped (mail queue empty)
  reason?: string;
}

// Mirrors audit.last_run_summary() — the persisted last run from the audit ledger.
export interface LastRunSummary {
  batch_id: string;
  mail_count: number;
  processed: number;
  failed: number;
  started_at: string | null;
  finished_at: string | null;
}

// Mirrors audit.list_batches() — one row per batch run for the history table.
export interface BatchSummary {
  batch_id: string;
  mail_count: number;
  processed: number;
  failed: number;
  candidates: number;
  started_at: string | null;
  finished_at: string | null;
}

// Mirrors audit.batch_failures() — one row per failed resume in a batch.
export interface BatchFailure {
  e_id: string | null;
  candidate_id: string | null;
  layer: string;
  reason: string;        // "<filename>: <reason>" when a filename was captured
  status: string;        // Failed | Exhausted
  created_at: string | null;
}

export const pipelineService = {
  /**
   * POST /api/v1/pipeline/run-all — STARTS one full L1→L2→L3 batch and
   * returns immediately (a batch can run many minutes, longer than most
   * reverse-proxy read timeouts would tolerate on a held-open request) — poll
   * `status()` for progress; its `result` field carries the finished run's
   * per-mail results once done.
   */
  runAll: () => api.post<{ started: boolean }>("/pipeline/run-all"),

  /** GET /api/v1/pipeline/status — running flag + live progress for the bar. */
  status: () =>
    api.get<{
      running: boolean;
      phase: string;
      total: number;   // mails phase 2 will process (0 = not counted yet)
      done: number;    // mails finished so far
      batch_id: string | null;
      // The last-finished run's full result (None while running, or before
      // any run this server process's lifetime) — in-memory only, same
      // lifetime as the old React-state-only value it replaces.
      result: PipelineRunResult | null;
    }>("/pipeline/status"),

  /** GET /api/v1/pipeline/last-run — most recent batch, from the audit ledger. */
  lastRun: () => api.get<{ last_run: LastRunSummary | null }>("/pipeline/last-run"),

  /** GET /api/v1/pipeline/batches — history of every batch run. */
  batches: () => api.get<{ batches: BatchSummary[] }>("/pipeline/batches"),

  /** GET /api/v1/pipeline/batches/{id}/failures — per-file failures in a batch. */
  failures: (batchId: string) =>
    api.get<{ batch_id: string; failures: BatchFailure[] }>(
      `/pipeline/batches/${encodeURIComponent(batchId)}/failures`,
    ),

  /** Direct download URL for a batch's candidate Excel workbook (attachment). */
  batchExcelUrl: (batchId: string) =>
    `${api.defaults.baseURL}/pipeline/batches/${encodeURIComponent(batchId)}/candidates.xlsx`,
};
