import { api } from "./api";

export interface ChatResult {
  question: string;
  type?: "sql" | "info";
  sql: string;
  row_count: number;
  /** Real number of matches; larger than row_count when the list is capped by LIMIT. */
  total_count?: number;
  rows: Record<string, unknown>[];
  answer?: string;
  retried?: boolean;
}

// One prior turn replayed to the backend so a short follow-up ("skills", "5+")
// is understood as a continuation of the earlier request.
export interface ChatTurn {
  role: "user" | "assistant";
  content: string;
}

export const chatbotService = {
  // `pageContext` — a short human-readable description of whatever page/
  // candidate the recruiter is currently looking at (see
  // @/lib/pageContext), sent fresh on every call so a follow-up question
  // reflects wherever they've navigated to since the chat opened.
  query: (question: string, history: ChatTurn[] = [], pageContext?: string) =>
    api.post<ChatResult>("/chatbot/query", { question, history, page_context: pageContext }),
  // Whether the floating launcher should render at all — read by every role
  // (not just Admin/System Admin), so this hits the chatbot router's own open
  // endpoint rather than the backoffice-gated /settings/chatbot-widget the
  // Settings page saves through.
  getWidgetConfig: () => api.get<{ visible: boolean }>("/chatbot/widget-config"),
};
