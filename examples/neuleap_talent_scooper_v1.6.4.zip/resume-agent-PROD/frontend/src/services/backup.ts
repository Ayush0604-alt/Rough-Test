import { api } from "./api";

export interface BackupManifest {
  id: string;
  kind: "full" | "incremental" | string;
  reason?: string;
  created_at: string;
  status: string;
  total_bytes?: number;
  files?: Record<string, { bytes?: number; objects?: number }>;
  targets?: Record<string, { status: string; path?: string; detail?: string }>;
  schema_ok?: boolean;
  error?: string;
}

export interface BackupHealth {
  generated_at: string;
  app_version?: string;
  database: { ok: boolean; version?: string; schema_ready?: boolean; error?: string };
  storage: { ok: boolean; raw_objects?: number; resume_objects?: number; error?: string };
  disk: { ok: boolean; total_bytes?: number; used_bytes?: number; free_bytes?: number; error?: string };
  backups: {
    enabled: boolean;
    full_sets: number;
    incrementals: number;
    last_full: BackupManifest | null;
    last_incremental: BackupManifest | null;
    secondary_configured: boolean;
    cloud_configured: boolean;
    retention_full_sets: number;
  };
}

export interface CloudConfig {
  enabled: boolean;
  endpoint: string;
  region: string;
  bucket: string;
  prefix: string;
  access_key: string;
  secret_key: string;
  has_secret?: boolean;
}

export interface BackupConfig {
  enabled: boolean;
  incremental_interval_hours: number;
  full_weekly_day: number; // 0=Mon .. 6=Sun
  full_weekly_hour: number;
  retention_full_sets: number;
  retention_incrementals: number;
  notify_on_failure: boolean;
  notify_emails: string;
  secondary_dir: string;
  cloud: CloudConfig;
}

export const backupService = {
  health: () => api.get<BackupHealth>("/backup/health"),
  list: () => api.get<{ backups: BackupManifest[] }>("/backup/list"),
  getConfig: () => api.get<BackupConfig>("/backup/config"),
  saveConfig: (cfg: BackupConfig) => api.put<BackupConfig>("/backup/config", cfg),
  revertConfig: () => api.post<BackupConfig>("/backup/config/revert"),
  run: (kind: "full" | "incremental") =>
    api.post<BackupManifest>("/backup/run", null, { params: { kind } }),
  restore: (id: string) =>
    api.post<{
      restored: boolean;
      // After restoring a possibly-older dump, the additive schema migrations are
      // re-applied so the data matches the running code; integrity confirms it.
      schema_migrated?: boolean;
      integrity?: { ok: boolean; missing?: string[] };
    }>(`/backup/restore/${id}`),
};

export function fmtBytes(n?: number): string {
  if (!n || n <= 0) return "0 B";
  const u = ["B", "KB", "MB", "GB", "TB"];
  const i = Math.min(u.length - 1, Math.floor(Math.log(n) / Math.log(1024)));
  return `${(n / Math.pow(1024, i)).toFixed(i ? 1 : 0)} ${u[i]}`;
}
