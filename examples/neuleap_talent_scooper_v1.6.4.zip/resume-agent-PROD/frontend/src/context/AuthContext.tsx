import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import {
  authService,
  clearSession,
  getStoredToken,
  getStoredUser,
  updateStoredUser,
  TOKEN_KEY,
  type AuthUser,
} from "@/services/auth";

// ── Auth context ────────────────────────────────────────────────────────────
// JWT session backed by the FastAPI /api/v1/auth endpoints. The token is stored
// in localStorage (attached to every request by the axios interceptor) and the
// session persists across reloads until the user logs out. On boot we trust the
// stored user optimistically, then validate the token against /auth/me.

interface AuthContextValue {
  user: AuthUser | null;
  isAuthenticated: boolean;
  // True only for the Admin login. Gates the manual "change NBA" UI — the
  // backend enforces the same restriction (403s a Recruiter's/System Admin's
  // attempt), this just keeps the control from appearing at all for those roles.
  isAdmin: boolean;
  // True for Admin OR System Admin. Gates every back-office area — Settings
  // (incl. User Management), Mailbox, and Activity Log — Recruiter has none
  // of these; the backend enforces the same restriction on every route
  // (require_backoffice_access), this just hides the entry points.
  canAccessBackoffice: boolean;
  // True for Admin OR Recruiter. Gates the recruiting workflow — Dashboard and
  // Candidates (incl. the candidate profile page) — System Admin has neither;
  // it's a pure back-office role. Frontend-only: unlike the restrictions above,
  // there's no dedicated backend surface to gate here (Dashboard/Candidates
  // both read the same /candidates data Process Flow also needs, which stays
  // open to System Admin), so this is route/nav-level scoping, not a security
  // boundary.
  canAccessRecruiting: boolean;
  // First-login / post-admin-reset gate — while true, the app is blocked
  // behind a forced change-password dialog (AppLayout renders it).
  mustChangePassword: boolean;
  // Called by ChangePasswordModal after a successful change — clears the
  // forced-change flag on the in-memory + cached user without a re-login.
  markPasswordChanged: () => void;
  loading: boolean;
  login: (email: string, password: string) => Promise<AuthUser>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(() => getStoredUser());
  const [loading, setLoading] = useState<boolean>(() => !!getStoredToken());

  // Validate a stored token on boot. If it's expired/invalid, /auth/me 401s and
  // the axios interceptor clears the session — we just drop the user here too.
  useEffect(() => {
    if (!getStoredToken()) {
      setLoading(false);
      return;
    }
    let active = true;
    authService
      .me()
      .then((u) => {
        if (active) setUser(u);
      })
      .catch(() => {
        if (active) setUser(null);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  // Keep tabs in sync — logging out in one tab logs out the others.
  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (e.key === TOKEN_KEY) setUser(getStoredToken() ? getStoredUser() : null);
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  const login = useCallback(async (email: string, password: string) => {
    const { user: nextUser } = await authService.login(email, password);
    setUser(nextUser);
    return nextUser;
  }, []);

  const logout = useCallback(() => {
    clearSession();
    setUser(null);
  }, []);

  const markPasswordChanged = useCallback(() => {
    setUser((u) => {
      if (!u) return u;
      const next = { ...u, must_change_password: false };
      updateStoredUser(next);
      return next;
    });
  }, []);

  const value = useMemo<AuthContextValue>(
    () => ({
      user,
      isAuthenticated: !!user,
      isAdmin: user?.role === "admin",
      canAccessBackoffice: user?.role === "admin" || user?.role === "sysadmin",
      canAccessRecruiting: user?.role === "admin" || user?.role === "recruiter",
      mustChangePassword: !!user?.must_change_password,
      markPasswordChanged,
      loading,
      login,
      logout,
    }),
    [user, loading, login, logout, markPasswordChanged]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within an AuthProvider");
  return ctx;
}
