"""Explicit, centralized logging setup.

Layer 1 logs every meaningful decision. Keeping configuration here means tests
and the runner share one consistent format.
"""

from __future__ import annotations

import logging
import os

_CONFIGURED = False


def configure_logging(level: int | str | None = None) -> None:
    """Configure root logging once. Idempotent."""
    global _CONFIGURED
    if _CONFIGURED:
        return
    resolved = level or os.environ.get("NEULEAP_LOG_LEVEL", "INFO")
    logging.basicConfig(
        level=resolved,
        format="%(asctime)s | %(levelname)-7s | %(name)s | %(message)s",
        datefmt="%H:%M:%S",
    )
    _CONFIGURED = True


def get_logger(name: str) -> logging.Logger:
    """Return a module logger, ensuring logging is configured."""
    configure_logging()
    return logging.getLogger(name)
