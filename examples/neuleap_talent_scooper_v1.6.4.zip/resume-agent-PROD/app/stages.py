"""Canonical interview-stage vocabulary — the single source of truth, backend side.

candidate_master.roundname / rounds.round_name always hold one of STAGE_ORDER.
Both the API layer (validation) and the repository (auto-advance on Pass) import
from here, so there is exactly one ordered definition of the pipeline and no
api↔repo import cycle. Mirrors the SPA's constants/CANDIDATE_STAGES.
"""
from __future__ import annotations

from typing import Optional

# Ordered interview pipeline. "New" is the implicit start (no round yet); "Final"
# is the last round — passing it maps the candidate to status = Hired.
# Round 3 is OPTIONAL; whether it runs is decided per-candidate on the Screening
# round (candidate_master.include_round3) — see app.services.interview_plan.
STAGE_ORDER = ["New", "Screening", "Round 1", "Round 2", "Round 3", "Final"]
VALID_STAGES = set(STAGE_ORDER)

# Recruiter-facing bucket vocabulary — mirrors the SPA's ROUND_BUCKETS
# (frontend/src/lib/rounds.ts): Round 3 collapses into "Round 2", and the two
# terminal verdicts join the pipeline stages. Drives the Actions Audit Log's
# stage grouping/coloring so backend-written entries agree with the SPA's badges.
BUCKET_ORDER = ["New", "Screening", "Round 1", "Round 2", "Final", "Hired", "Reject", "Closed", "Undecided"]

# Recruiter lifecycle states past which a candidate's rounds are frozen. "Undecided"
# is reversible (like Closed) — set via the "Undecided for now" NBA to park a
# candidate without rejecting them; a recruiter can reactivate them into any stage.
TERMINAL_STATUSES = {"Hired", "Rejected", "Closed", "Undecided"}


# Post-hire onboarding pipeline (Live Workflow) — tracked in PARALLEL to `status`
# ('Hired' stays as-is; this is a separate progression that only applies once a
# candidate is Hired). Shown as the continuation of the flow after the Hired bubble.
ONBOARDING_STAGE_ORDER = [
    "ready_to_hire",
    "offer_review",
    "offer_sent",
    "candidate_responded",
    "expected_join_date",
    "joined",
    "onboarding_date_set",
    "allocation_checklist",
    "onboarding_complete",
]
ONBOARDING_STAGE_LABELS = {
    "ready_to_hire": "Ready to Hire",
    "offer_review": "Offer Review",
    "offer_sent": "Offer Sent",
    "candidate_responded": "Candidate Responded",
    "expected_join_date": "Expected Join Date Set",
    "joined": "Joined",
    "onboarding_date_set": "Onboarding Date Set",
    "allocation_checklist": "Allocation Checklist",
    "onboarding_complete": "Onboarding Complete",
}
VALID_ONBOARDING_STAGES = set(ONBOARDING_STAGE_ORDER)

# Fixed standard allocation checklist — every Hired candidate gets this same set of
# tasks (structured/reportable), each independently markable done/pending.
DEFAULT_ONBOARDING_CHECKLIST = [
    {"key": "offer_letter_signed", "label": "Offer letter signed", "done": False},
    {"key": "background_verification", "label": "Background verification", "done": False},
    {"key": "it_asset_allocated", "label": "IT asset allocated (laptop/ID/email)", "done": False},
    {"key": "buddy_assigned", "label": "Buddy/mentor assigned", "done": False},
    {"key": "induction_scheduled", "label": "Induction scheduled", "done": False},
]


def next_onboarding_stage(current: Optional[str]) -> Optional[str]:
    """The onboarding stage after ``current``, or None if it's the last one/unknown."""
    name = (current or "ready_to_hire").strip()
    if name not in VALID_ONBOARDING_STAGES:
        return None
    i = ONBOARDING_STAGE_ORDER.index(name)
    return ONBOARDING_STAGE_ORDER[i + 1] if i < len(ONBOARDING_STAGE_ORDER) - 1 else None


class RoundLockedError(Exception):
    """Raised when editing a round that is locked — i.e. the candidate has already
    advanced past it (it is no longer their active round) or has reached a terminal
    state. A passed round must never be re-opened and flipped to Fail. The API maps
    this to HTTP 409."""


def next_stage(current: Optional[str]) -> Optional[str]:
    """The stage after ``current`` in the pipeline, or None if it's terminal/unknown."""
    name = (current or "New").strip()
    if name not in VALID_STAGES:
        return None
    i = STAGE_ORDER.index(name)
    return STAGE_ORDER[i + 1] if i < len(STAGE_ORDER) - 1 else None


def candidate_stage_bucket(row: dict) -> str:
    """Collapse a candidate_master-shaped dict onto ONE of BUCKET_ORDER.

    Accepts either a full candidate row (status/round_status/roundname) or a
    minimal ``{"roundname": ...}`` dict (e.g. a round's own round_name) — every
    key is read with ``.get()`` so missing ones just fall through to the pipeline
    branch. Mirrors the SPA's roundStageBucket() so entries this writes agree with
    the frontend's own stage badges/colors.
    """
    status = row.get("status")
    if status == "Hired":
        return "Hired"
    if status == "Rejected":
        return "Reject"
    if status == "Closed":
        return "Closed"
    if status == "Undecided":
        return "Undecided"
    if row.get("round_status") == "Rejected":
        return "Reject"
    r = (row.get("roundname") or "").strip()
    if r == "Screening":
        return "Screening"
    if r == "Round 1":
        return "Round 1"
    if r in ("Round 2", "Round 3"):
        return "Round 2"
    if r == "Final":
        return "Final"
    return "New"
