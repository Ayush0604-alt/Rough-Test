"""Merged NeuLeap app — L1 mail intake + L2 intake + L3 extraction, one process.

One FastAPI app on :8000, one PostgreSQL (psycopg2), one MinIO (two buckets).
A single batch trigger (/api/v1/pipeline/run-all) runs L1 atomically then walks
each Passed mail through L2 (+ fused L3). Startup wiring lives in the lifespan.
"""
from __future__ import annotations

import logging
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api import (
    auth,
    backup,
    upgrade as upgrade_api,
    batch_archive,
    branches,
    candidate_slots,
    chatbot,
    extraction,
    extraction_settings,
    feedback,
    intake,
    interview,
    interview_pools,
    interviewer,
    jd_match,
    notifications,
    orchestrator,
    reads,
    review,
    rounds,
    source_tags,
    system_reset,
    token_usage,
)
from app.api.graph_intake import router as graph_router
from app.api.mail import router as mail_router
from app.api.settings import router as settings_router
from app.config import settings

logging.basicConfig(
    level=getattr(logging, settings.log_level.upper(), logging.INFO),
    format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    # 1) Schema: one init_db() creates ALL tables (email_master, eid_seq,
    #    audit_log, candidate_master, candidate_seq) via the unified schema.sql.
    from app.db import init_db
    try:
        init_db()
        logger.info("PostgreSQL schema ready (email_master + candidate_master + audit_log)")
    except Exception as exc:  # noqa: BLE001
        logger.warning("init_db failed at startup: %s", exc)

    # 1b) Seed the sample question banks once per deployment (idempotent).
    try:
        from app.api.interview import seed_sample_question_banks
        seed_sample_question_banks()
    except Exception as exc:  # noqa: BLE001
        logger.warning("question-bank seeding failed at startup: %s", exc)

    # 2) MinIO: ensure BOTH buckets (raw + resume) exist.
    from app.services.s3 import ensure_buckets
    try:
        ensure_buckets()
    except Exception as exc:  # noqa: BLE001
        logger.warning("ensure_buckets failed at startup: %s", exc)

    # 3) MinIO warm-up (Layer 1's only durable store — staging + clean files).
    from app.api import mail as mail_api
    from app.services import mail_storage
    mail_settings = mail_api.settings()
    try:
        if mail_storage.is_enabled():
            mail_storage._get_client()
    except Exception as exc:  # noqa: BLE001
        logger.warning("mail storage warm-up failed: %s", exc)

    # 4) Compile both LangGraphs so the first request isn't slow.
    from app.pipeline.graph import get_graph
    get_graph()
    from app.pipeline.mail.graph import build_graph
    build_graph(mail_settings)

    # 5) D12: cron → orchestrator.run_all (run-lock guards vs manual).
    # Load persisted settings (notifications + pipeline config) from secrets/*.env
    # BEFORE the scheduler starts, so a saved SCHEDULE_CRON/TZ override takes effect.
    from app.services import notify_config, pipeline_config, scheduler, scoring_config
    pipeline_config.load()
    notify_config.load()
    scoring_config.load()

    def _cron_job() -> None:
        try:
            orchestrator.run_all()
        except Exception as exc:  # noqa: BLE001 — 409 when manual run holds the lock
            logger.info("scheduled run skipped/failed: %s", exc)

    def _archive_job() -> None:
        try:
            from app.repositories import repo
            result = repo().archive_eligible()
            logger.info("nightly archival: moved %d candidate(s)", result["archived"])
        except Exception as exc:  # noqa: BLE001
            logger.warning("scheduled archival failed: %s", exc)

    def _slot_reminder_job() -> None:
        try:
            from app.services import slot_reminder_job
            result = slot_reminder_job.run_once()
            if result["reminded"] or result["rejected"]:
                logger.info(
                    "candidate slot scan: reminded=%d rejected=%d",
                    result["reminded"], result["rejected"],
                )
        except Exception as exc:  # noqa: BLE001
            logger.warning("scheduled slot reminder scan failed: %s", exc)

    def _pool_sync_job() -> None:
        try:
            from app.services import pool_sync_job
            result = pool_sync_job.run_once()
            if result["removed"] or result["rescheduled"]:
                logger.info(
                    "interviewer pool sync: checked=%d removed=%d rescheduled=%d",
                    result["checked"], result["removed"], result["rescheduled"],
                )
        except Exception as exc:  # noqa: BLE001
            logger.warning("scheduled interviewer pool sync failed: %s", exc)

    scheduler.start(
        mail_settings, job=_cron_job, archive_job=_archive_job,
        slot_reminder_job=_slot_reminder_job, pool_sync_job=_pool_sync_job,
    )

    # 6) Outlook (Graph) intake poller — refresh the Intake queue every N seconds.
    #    Read-only preview of Inbox mail by date; processing stays on the pipeline run.
    from app.services import graph_poller
    try:
        graph_poller.start()
    except Exception as exc:  # noqa: BLE001 — the poller must never block startup
        logger.warning("graph poller start failed: %s", exc)

    logger.info(
        "Merged app ready  s3=%s  auto_extract=%s  workers=%s",
        settings.s3_backend, settings.auto_extract, settings.extract_workers,
    )
    yield

    scheduler.shutdown()
    from app.services import graph_poller
    graph_poller.shutdown()


app = FastAPI(
    title="NeuLeap — Mail Intake (L1) + Resume Intake (L2) + Extraction (L3)",
    description=(
        "One app: L1 mail intake → L2 validate/dedup/store → L3 LLM extraction. "
        "PostgreSQL + MinIO."
    ),
    version="3.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Flat router mount (D6): one unified /docs.
# Mail (L1) routes are kept at their original unprefixed paths for back-compat
# AND mirrored under /api/v1 so the SPA can talk to one base URL.
app.include_router(mail_router)
app.include_router(mail_router, prefix="/api/v1")
# Outlook (Graph) intake queue — mirrored under /api/v1 for the SPA.
app.include_router(graph_router)
app.include_router(graph_router, prefix="/api/v1")
# Settings (notification preferences) — SPA talks to /api/v1.
app.include_router(settings_router)
app.include_router(settings_router, prefix="/api/v1")
app.include_router(auth.router)
app.include_router(intake.router)
app.include_router(extraction.router)
app.include_router(orchestrator.router)
# branches before rounds: its static /candidates/manual-review & /candidates/reapplications
# must win over rounds' /candidates/{candidate_id} dynamic match.
app.include_router(branches.router)
app.include_router(interview.router)
app.include_router(rounds.router)
app.include_router(reads.router)
app.include_router(chatbot.router)
app.include_router(review.router)
app.include_router(notifications.router)
app.include_router(jd_match.router)
app.include_router(token_usage.router)
app.include_router(source_tags.router)
app.include_router(backup.router)
app.include_router(upgrade_api.router)
app.include_router(batch_archive.router)
app.include_router(system_reset.router)
app.include_router(feedback.router)
app.include_router(interviewer.router)
app.include_router(interviewer.admin_router)
app.include_router(candidate_slots.router)
app.include_router(candidate_slots.admin_router)
app.include_router(interview_pools.router)
app.include_router(interview_pools.portal_router)
app.include_router(extraction_settings.router)


@app.get("/api/v1/meta", tags=["health"])
def meta() -> dict:
    """Non-sensitive deploy metadata the SPA shows in its top bar (env label) —
    unauthenticated on purpose, mounted under /api/v1 (unlike /health) so
    nginx's `location /api/` proxy reaches it from the built frontend."""
    from app.services import sample_data_visibility, sample_interview

    return {
        "app_env": settings.app_env,
        "sample_data_source_label": sample_interview.SAMPLE_SOURCE_LABEL,
        "sample_data_visible": sample_data_visibility.is_visible(),
    }


@app.get("/health", tags=["health"])
def health() -> dict:
    # Postgres reachability.
    pg_ok = False
    try:
        from app.db import get_conn
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1")
        pg_ok = True
    except Exception:  # noqa: BLE001
        pg_ok = False

    from app.services import graph_client
    return {
        "status": "ok",
        "postgres": pg_ok,
        "s3_backend": settings.s3_backend,
        "buckets": {"raw": settings.minio_raw_bucket, "resume": settings.minio_resume_bucket},
        "auto_extract": settings.auto_extract,
        "extract_workers": settings.extract_workers,
        "graph_configured": graph_client.is_configured(),
        "azure_configured": bool(os.environ.get("AZURE_OPENAI_KEY")),
        "batch_running": orchestrator.is_running(),
    }
