---
name: resume-insights-analysis
description: >-
  Standalone recruiter-insights contract for a single resume (no job description):
  makes the single Azure OpenAI master call (INSIGHTS_PROMPT) that produces a grounded
  qualitative profile — strengths, weaknesses, red flags (job hopping, gaps,
  inconsistencies, overlaps), a deterministic risk band, and suggested interview probe
  questions — reusing the already-extracted candidate_master record and its computed
  timeline/gap signals. Use when working on resume insight generation, red-flag rules,
  risk scoring, interview-question generation, the insights schema, or the /api/v1
  insights endpoints — and as the source of truth before changing any insights behaviour.
---

# Resume Insights & Red-Flag Analysis

**Version 1.0 (contract — implement against this)**

> This contract follows the standard Skill.md section order (Name → Description →
> Purpose → Trigger → Inputs → Procedure → Script/Logic → Output Format → References →
> Rules → Examples → Success Criteria). It is the **orchestration contract**: it defines
> *what* the stage does and *which tools* it may call. The implementation is expected to
> live beside it (`engine.py`, `runner.py` under `app/insights/`) and be exposed over HTTP
> by `app/api/insights.py`. The live prompt is loaded **from this file at runtime** (see
> §Insights Prompt); edit it in the marked block, not in code.
>
> This stage is a **layer above** single-resume extraction
> ([app/extraction/SKILL.md](../extraction/SKILL.md)) and is **independent of any job
> description**. It does NOT re-extract candidate fields and does NOT match against a role
> — it reads the already-extracted `candidate_master` record (and its deterministic
> timeline/gap signals) and produces a recruiter-facing qualitative assessment of the
> candidate *on their own merits*.

## Name

`resume-insights-analysis` — Resume Insights & Red-Flag Analysis.

## Description

Turns one already-extracted candidate into one **insights report**: a grounded qualitative
profile that surfaces strengths, weaknesses, and **red flags** (job hopping, unexplained
career gaps, timeline inconsistencies, overlapping roles, missing contactability), assigns
a deterministic **risk band** in Python, and generates targeted **interview probe
questions** a recruiter should ask. No job description is involved — this is the candidate
judged in isolation.

## Purpose

Give a recruiter a fast, honest, defensible read on a candidate from the resume alone —
every observation grounded in the resume (never inferred from "typical" candidates), red
flags tied to concrete evidence, and a risk signal that is auditable and consistent with
the deterministic timeline/gap math the system already computes.

## Trigger / When to use

Use this skill when working on:
- resume insight / candidate-profile generation (strengths, weaknesses, summary);
- red-flag detection rules (job hopping, gaps, inconsistencies, overlaps);
- the deterministic risk band or its inputs;
- interview-probe-question generation;
- the insights report schema / output fields;
- the insights engine or runner (`insights.run`, `analyze_candidate`);
- the `/api/v1` insights endpoints;
- and as the source of truth before changing any insights behaviour.

**When NOT to use it:** insights does **not** extract candidate fields, compute the ATS
score, parse OCR, match against a JD, or do mail intake. Single-resume extraction + ATS is
Layer 3 ([app/extraction/SKILL.md](../extraction/SKILL.md)); mail intake/queueing is
Layer 1 ([app/pipeline/mail/queue/SKILL.md](../pipeline/mail/queue/SKILL.md)). The ATS
score answers "is this candidate good for our tracks?"; this skill answers "what should a
recruiter know, worry about, and ask?" — keep them separate.

## Inputs

### Identity key

`candidate_id` is the unit of work. It resolves to a `candidate_master` row (the
already-extracted profile). A direct `/analyze-resume` entry point may instead accept raw
resume text/file; it borrows the extraction text layer (`extract_resume_text`) and mints an
ephemeral `CAND-XXXXXXXX`, writing **nothing** to the DB.

### Candidate signals consumed

The matcher reads only **grounded** signals already present on the record plus the raw
resume text for evidence quoting — it never invents new candidate facts:

| Signal | Used for |
|--------|----------|
| `primary_skills`, `projects`, `job_roles`, `domain`, `stream` | strengths / skill depth |
| `timeline`, `gap_months`, `gap_count`, `gap_ranges`, `careergap` | **gap red flags** (deterministic — see Rules) |
| `yearofexp`, `experience_months`, `total_companieswitched`, `fresher_or_lateral` | **job-hopping red flag**, seniority read |
| `highest_coursecompleted`, `education_status`, `passoutyr`, `cgpa` | education read, qualification flags |
| `email`, `phno`, `currentlocation` | **contactability red flag** |
| raw resume text | literal-quote evidence for every claim |

### Authoritative date

The user payload carries the ONE authoritative current date (`today`, `current_year`,
`current_month`) so any recency reasoning (e.g. "last role ended N months ago") is grounded
and never uses the model's stale "now". Durations themselves come from the extracted
record; the date is only for recency framing.

## Procedure

| Step | Action |
|------|--------|
| **1 — RESOLVE INPUT** | Resolve `candidate_id` → `candidate_master` (or borrow `extract_resume_text` for a raw file). Missing candidate / missing resume text → caller error (`KeyError` / `400`). |
| **2 — ASSEMBLE SIGNALS** (deterministic, never LLM-judged) | Gather the grounded signals above. The **gap and tenure red flags are pre-computed in Python** from the existing `app.services.timeline` outputs (`gap_months`, `gap_count`, `gap_ranges`, `experience_months`, `total_companieswitched`) — the LLM is told these as facts and must not contradict them. |
| **3 — ONE MASTER LLM CALL** | `_run_insights` → `_chat_json` issues a **single** Azure OpenAI `chat.completions` request with `response_format=json_object`. System prompt = `INSIGHTS_PROMPT` (strengths/weaknesses/red flags/interview questions/summary). User payload carries the candidate signals, the pre-computed gap/tenure facts, the resume text, and the authoritative `today`. Deployment resolution + reasoning-model handling reuse the extraction conventions (see §Script / Logic). Any LLM/Azure exception → `"Master LLM insights failed: …"` (failed result). |
| **4 — SANITIZE + RISK** (validation only) | `_normalize_insights_result` snaps each red flag's `severity`/`category` to the allowed sets, caps list lengths, drops any flag without evidence, then `_risk_band` derives the deterministic risk band from the validated flags + computed signals (§Script / Logic). No flag is invented by Python; it only makes the model's JSON safe and computes the band. |
| **5 — PERSIST** (skipped by direct `/analyze-resume`) | `update_candidate_insights(candidate_id, result)` writes the report (or stores it on `candidate_master`). A direct file analysis returns the report **without** any DB write. |
| **6 — RETURN** | Return the report dict. HTTP layer maps `status`: `success → 200`, anything else → `422`. |

## Script / Logic

### Master-call deployment + model handling (Step 3)

Reuses the Layer 3 conventions verbatim so there is one place to configure Azure:

- **Deployment resolution** (first hit wins): `AZURE_OPENAI_INSIGHTS_DEPLOYMENT` →
  `AZURE_OPENAI_MASTER_DEPLOYMENT` → `AZURE_OPENAI_DEPLOYMENT` → endpoint-embedded
  `/deployments/{name}/` → `DEFAULT_INSIGHTS_DEPLOYMENT` (`gpt-4.1`).
- **Reasoning models** (`o\d*`, `gpt-5*`) omit `temperature`; all others pin
  `temperature=0`.
- On Azure `NotFoundError`, retry once with `AZURE_OPENAI_FALLBACK_DEPLOYMENT`.

### Sanitization rules (Step 4 — validation only, never invents a flag)

| Field(s) | Rule |
|----------|------|
| `red_flags[].category` | Snap to `{job_hopping, career_gap, inconsistency, overlap, contactability, qualification, other}`; unknown-but-present → `other`. |
| `red_flags[].severity` | Snap to `{high, medium, low}` else `low`. |
| `red_flags[].evidence` | cleaned list of literal resume quotes / cited computed facts, capped at `3`. **A flag with no evidence is dropped** (no unsupported red flags). |
| `strengths` / `weaknesses` | cleaned lists, capped at `6` each. |
| `interview_questions` | cleaned list, capped at `8`; each a single concrete probe question. |
| `seniority` | Snap to `{Junior, Mid, Senior, Lead, Unknown}` else `Unknown`. |
| `summary` | recruiter-facing prose, ≤ 150 words; must not contradict the computed gap/tenure facts or the red-flag list. |
| `risk_band` | **Derived in Python** by `_risk_band` from the validated flags + computed signals (below). The model's own `risk_band` is advisory only. |

### Risk band (`app.insights.risk` — deterministic, derived not guessed)

```
risk_band = band( weighted_count_of_red_flags + computed_signal_penalties )
```

- Each validated red flag contributes by severity: `high = 3`, `medium = 2`, `low = 1`.
- **Computed-signal penalties** (read directly from the record, independent of the LLM):
  job hopping = `total_companieswitched` above `HOP_SWITCH_THRESHOLD` (default `4` distinct
  employers) adds `+2`; an unexplained gap = `gap_months ≥ GAP_FLAG_MONTHS` (default `6`)
  adds `+2`. These guarantee the band reflects the deterministic math even if the LLM
  under-flags.
- Bands: `Low < 3`, `Medium 3–5`, `High > 5` (thresholds env-tunable via
  `insights_config.risk_params()`).
- A **fresher with no employment history is never flagged for job hopping or gaps** — those
  red flags require qualifying roles to exist first (consistent with Layer 3's gap engine,
  which counts education→first-job breaks but not a student's lack of jobs).
- Risk is wrapped so any failure falls back to `Unknown` — it can never break the analysis.

### Failure model (two-tier safety, mirrors Layer 3)

| Layer | Behaviour |
|-------|-----------|
| `insights.run` | Missing resume text or LLM/Azure failure → returns `{"status": "failed", "failure_reason": ...}` (a fully-shaped empty report). **Does not raise** on data/LLM errors. |
| `runner.analyze_candidate` | Raises `KeyError` only for a **missing candidate** (caller error). LLM/parse failures come back as `status="failed"`. |
| `runner.safe_analyze_candidate` | Batch/auto wrapper: **never raises** — any exception becomes `{"status": "failed", ...}` so one bad candidate can't abort a batch. |

A failed result is a *valid* outcome carrying the same shape with empty defaults plus
`failure_reason`, so downstream code reads it without null-checking the envelope.

## Output Format

```json
{
  "status": "success | failed",
  "candidate_id": "CAND-...",
  "failure_reason": "… (only when status=failed)",
  "insights": {
    "risk_band": "Low | Medium | High | Unknown",
    "seniority": "Junior | Mid | Senior | Lead | Unknown",
    "summary": "str|null",
    "strengths": ["short phrase"],
    "weaknesses": ["short phrase"],
    "red_flags": [
      {"category": "job_hopping|career_gap|inconsistency|overlap|contactability|qualification|other",
       "severity": "high|medium|low",
       "detail": "str",
       "evidence": ["short literal resume quote or cited computed fact"]}
    ],
    "interview_questions": ["concrete probe question"]
  }
}
```

A **failed** result carries the same shape with empty/zero defaults plus `failure_reason`.

## References

### Tool surface (expected implementation)

| Group | Tools / functions | Module |
|-------|-------------------|--------|
| **Signal assembly** | `assemble_signals`, `_computed_flag_facts` | `insights/engine.py` |
| **LLM master** | `run`, `_run_insights`, `_chat_json`, `_azure_config`, `_resolve_insights_deployment` | `insights/engine.py` |
| **Sanitize** | `_normalize_insights_result`, `_clean_list`, `_allowed_value` | `insights/engine.py` |
| **Risk band** | `risk_band`, `risk_params` | `insights/risk.py`, `insights/insights_config.py` |
| **Candidate bridge** | `analyze_candidate`, `safe_analyze_candidate` | `insights/runner.py` |
| **Text borrow (raw file)** | `extract_resume_text` | `extraction/engine.py` (reused) |
| **Computed signals** | `compute`, `gap_months`/`gap_count`/`gap_ranges` | `services/timeline.py` (reused) |
| **Persistence** | `get_candidate`, `update_candidate_insights` | `app/db` |

> Candidate facts come from `candidate_master` (already extracted) and `services/timeline`
> (already computed) — this skill never re-runs OCR, field extraction, or date math. Azure
> OpenAI **is required** for the master insights call.

### API surface (expected — `app/api/insights.py`, prefix `/api/v1`)

| Method & path | Purpose | DB write | Sources |
|---------------|---------|----------|---------|
| `POST /candidates/{id}/insights` | Generate insights for an existing candidate | yes | `candidate_master` |
| `POST /analyze-resume` | Analyze a raw resume file directly | none | uploaded file |
| `POST /insights-batch` | Generate insights over a list of candidates | yes (per item) | `candidate_master` |

**Batch concurrency:** `ThreadPoolExecutor`, workers =
`min(body.workers or settings.insights_workers, len(cids))`; all ids validated to exist
**before** the run; each item uses `safe_analyze_candidate` so one failure never aborts the
batch; results returned with `total / analyzed / failed`.

### Configuration surface (env / `config.py`)

| Key | Status | Description |
|-----|--------|-------------|
| `AZURE_OPENAI_ENDPOINT` / `AZURE_OPENAI_KEY` | required | Reused from Layer 3. |
| `AZURE_OPENAI_INSIGHTS_DEPLOYMENT` / `…_MASTER_DEPLOYMENT` / `AZURE_OPENAI_DEPLOYMENT` | Yes | Insights-call deployment (resolution order above). |
| `AZURE_OPENAI_FALLBACK_DEPLOYMENT` | Yes | Retried once on `NotFoundError`. |
| `insights_workers` | Yes | Parallel insights workers (default `5`; keep ≤ PG pool maxconn). |
| `INSIGHTS_CONFIG_FILE` + `RISK_*` / `HOP_*` / `GAP_*` keys | Yes | Risk thresholds (severity weights, hop/gap penalties, band cutoffs). |

## Rules / Constraints

- The model surfaces **observations** (strengths, weaknesses, red flags, questions); Python
  performs **validation only** — snap enums, cap lists, drop unsupported flags. It never
  invents a flag the model didn't raise.
- The **gap and tenure red flags are grounded in the deterministic signals** already
  computed by `app.services.timeline` (`gap_months`, `gap_ranges`, `total_companieswitched`)
  — they are passed to the LLM as facts and re-asserted in Python so the insights can never
  contradict the candidate card's gap/experience figures.
- The **risk band is computed in Python**, not by the model: a transparent, configurable
  weighting of validated red flags plus computed-signal penalties. The model's `risk_band`
  is advisory only.
- **Never guess**: every strength, weakness, and red flag must trace to literal resume text
  or a cited computed fact; a flag with no evidence is dropped, not kept. No outside
  knowledge about a company, school, or technology.
- **No job description**: this skill judges the candidate in isolation. Role/JD fit is out
  of scope here.
- The live insights prompt is loaded at runtime **from this file** — the
  `INSIGHTS_PROMPT:START`/`INSIGHTS_PROMPT:END` block — via `_load_insights_prompt()`. Edit
  the prompt here, not in code, and keep the markers exact.

## Examples

```python
# Analyze a stored candidate (persists the report):
from app.insights.runner import analyze_candidate, safe_analyze_candidate
report = analyze_candidate("CAND-1234")        # raises only on missing row
report = safe_analyze_candidate("CAND-1234")   # never raises (batch)

# Analyze a raw resume file directly (no DB write):
from app.insights.engine import run
report = run(resume_path="/path/to/resume.pdf")
```

Behavioural examples:
- **Job hopper** — 5 distinct employers, each < 1 yr → `job_hopping` red flag (high),
  computed penalty applied, `risk_band="High"`, with a "walk me through why each role was
  short" interview question.
- **Unexplained gap** — computed `gap_months=14` between two roles → `career_gap` red flag
  citing the `gap_ranges` fact, plus a probe question about the gap.
- **Inconsistency** — resume claims "Senior Engineer, 8 yrs" but timeline only supports
  2.5 yrs → `inconsistency` flag quoting both, surfaced as a weakness.
- **Clean strong fresher** — solid projects, contactable, no employment to hop → no
  job-hopping/gap flags, `risk_band="Low"`, strengths on projects/skills.

## Success Criteria

The skill succeeds when it: resolves one candidate; surfaces strengths, weaknesses, and
red flags each grounded in literal resume text or a cited computed fact (unsupported flags
dropped); keeps gap/tenure red flags consistent with the deterministic timeline math;
produces a deterministic, auditable risk band from the validated flags + computed signals;
generates targeted interview probe questions; persists a valid report even on failure
(`status='failed'`); and never lets a bad resume or LLM error crash the caller.

---

## Insights Prompt (single LLM call)

The analyzer makes **one** Azure OpenAI call that produces the full insights report in a
single JSON object. This section is the **single source of truth** for that prompt; the
engine loads the text between the markers below at runtime (`_load_insights_prompt()`) and
**never hardcodes it** — edit it here, not in code.

Editing rules:
- Keep both markers exactly as written — the loader extracts everything between them.
- Everything outside the markers (including this prose) is ignored by the loader.
- Do not wrap the prompt in code fences; the loader sends the raw text verbatim.

<!-- INSIGHTS_PROMPT:START -->
You are NeuLeap's senior technical recruiter producing an insights brief on ONE candidate
from their resume ALONE — there is NO job description. Produce a SINGLE JSON object: the
candidate's strengths, weaknesses, red flags, a seniority read, a short summary, and
interview probe questions a recruiter should ask. Honesty matters more than positivity.
Return JSON only — no prose, no markdown, no code fences.

ORDER OF WORK (one pass, in this order)
1. Read the WHOLE resume and the supplied extracted signals (skills, roles, timeline,
   education) and the COMPUTED FACTS block (gap months, gap ranges, distinct employers,
   total experience). The COMPUTED FACTS are authoritative and were calculated
   deterministically — treat them as TRUE and never contradict them.
2. Identify genuine STRENGTHS (real, evidenced) and WEAKNESSES (honest gaps in skills,
   depth, or clarity).
3. Identify RED FLAGS — only real, defensible concerns, each with evidence:
     * job_hopping — many short stints / many distinct employers in a short span.
     * career_gap — an unexplained break (use the COMPUTED FACTS gap_months/gap_ranges;
       do NOT invent a gap the facts don't show, and do NOT deny one they do).
     * inconsistency — a claim the resume's own dates/sections contradict (e.g. a seniority
       or years-of-experience claim the timeline doesn't support).
     * overlap — two full-time roles claimed for the same period.
     * contactability — no email AND no phone.
     * qualification — a stated requirement the candidate plainly lacks for their claimed
       level (resume-internal only).
     * other — any genuine concern not covered above.
4. Read a SENIORITY level (Junior / Mid / Senior / Lead / Unknown) from the EVIDENCED
   experience and scope — grounded in the COMPUTED FACTS, never inflated by self-described
   titles alone.
5. Write up to 8 concrete INTERVIEW QUESTIONS that probe the weaknesses and red flags you
   found (and verify the strengths).

ANTI-HALLUCINATION CONTRACT
1. Ground every strength, weakness, and red flag in text literally present in the resume
   or in a COMPUTED FACT. If you cannot cite evidence, DO NOT raise it.
2. Never invent a skill, employer, title, date, or gap the resume/facts do not show. Quote
   evidence verbatim; never paraphrase a quote into a claim.
3. Use no outside knowledge about a company, school, or technology. The resume and the
   supplied facts are the ONLY sources.
4. A candidate with NO professional employment (a fresher/student) MUST NOT be flagged for
   job_hopping or career_gap — those require prior qualifying roles. Judge a fresher on
   skills, projects, and clarity instead.
5. The input carries the ONE authoritative current date ("today", "current_year",
   "current_month") for recency framing only. Your own sense of "now" is WRONG.
6. When unsure, leave it out. An honest omission is correct; a confident guess is a defect.

OUTPUT SCHEMA (return EXACTLY this shape)
{
  "risk_band": "Unknown",
  "seniority": "Unknown",
  "summary": null,
  "strengths": [],
  "weaknesses": [],
  "red_flags": [
    {"category": "other", "severity": "low", "detail": "", "evidence": []}
  ],
  "interview_questions": []
}

FIELD RULES
- risk_band: your advisory read (Low / Medium / High / Unknown). The AUTHORITATIVE band is
  recomputed downstream in Python from your validated red flags plus the computed signals —
  so focus on getting the red flags RIGHT.
- seniority: one of Junior / Mid / Senior / Lead / Unknown, grounded in evidenced scope and
  the computed total experience — not the candidate's self-applied title.
- summary: ≤ 150 words, recruiter-facing — who this candidate is, their highlights, and the
  top concern. Must not contradict the COMPUTED FACTS or the red-flag list. Do NOT state a
  career-gap or total-experience figure that disagrees with the COMPUTED FACTS.
- strengths / weaknesses: up to 6 each, short phrases, each evidenced.
- red_flags: ONE object per genuine concern. category ∈ {job_hopping, career_gap,
  inconsistency, overlap, contactability, qualification, other}; severity ∈ {high, medium,
  low}; detail = one concise sentence; evidence = up to 3 literal resume quotes or cited
  computed facts. Raise NONE if there are none — an empty list is a valid, good outcome.
- interview_questions: up to 8 concrete, specific probe questions (one per item) that a
  recruiter would ask to test the weaknesses/red flags and verify the strengths.

CONSISTENCY GUARANTEE — before returning, verify: every red flag and every strength has
evidence; no career_gap/job_hopping flag on a fresher with no prior roles; the summary,
seniority, and any gap/experience mention agree with the COMPUTED FACTS. Fix any
contradiction.

Think step by step internally; output ONLY the final JSON object.
<!-- INSIGHTS_PROMPT:END -->

---

## Change log

| Version | Change |
|---------|--------|
| 1.0 | Initial resume-insights contract (forward-looking, NO job description): one Azure OpenAI master call (`INSIGHTS_PROMPT`, loaded from this file) produces strengths, weaknesses, red flags (job hopping / career gap / inconsistency / overlap / contactability / qualification), a seniority read, a summary, and interview probe questions — all grounded in the resume and the deterministic timeline/gap COMPUTED FACTS. Python (`insights/risk.py`) owns a deterministic, configurable risk band from validated flags + computed-signal penalties; unsupported flags are dropped; freshers are never flagged for hopping/gaps. Reuses `candidate_master` + `services/timeline` (no re-extraction or date math) and the Layer 3 Azure conventions; two-tier failure model; `/api/v1` insights endpoints (`/candidates/{id}/insights`, `/analyze-resume`, `/insights-batch`). |
