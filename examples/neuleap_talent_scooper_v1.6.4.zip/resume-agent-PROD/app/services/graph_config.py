"""Microsoft Graph API connection — Settings → Graph API.

Stores the Azure app-registration credentials the mail-intake + calendar
integration authenticates with (tenant id, client id, client secret) with the
CLIENT SECRET encrypted at rest (same Fernet scheme/posture as
app.services.llm_config / mailbox_account). The mailbox address itself lives in
app.services.mailbox_account (Settings → Mailbox Account); this module is just
the OAuth app credentials.

Resolution for any Graph call: DB config → env vars (GRAPH_TENANT_ID /
GRAPH_CLIENT_ID / GRAPH_CLIENT_SECRET). Each field falls back independently, so
saving only a new secret keeps the env tenant/client. Best-effort: any
DB/decrypt failure returns the env-derived values so a broken row can never
take mail intake down.

Security posture (mirrors llm_config):
  * The client secret NEVER leaves the server — the API returns only
    ``has_client_secret``.
  * Saving requires the acting System Admin to re-enter their OWN password.
  * Every save is audit-logged (who + what changed, never the secret).
"""
from __future__ import annotations

import base64
import hashlib
import os
from typing import Any, Dict, Optional

import psycopg2.extras
from cryptography.fernet import Fernet, InvalidToken

from app.config import settings
from app.db import get_conn
from app.logging_config import get_logger

log = get_logger(__name__)

_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS graph_api_config (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    tenant_id TEXT,
    client_id TEXT,
    client_secret_enc TEXT,
    updated_by TEXT,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
"""

_table_ready = False


def _ensure_table() -> None:
    global _table_ready
    if _table_ready:
        return
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(_TABLE_SQL)
    _table_ready = True


def _fernet() -> Fernet:
    secret = os.environ.get("GRAPH_ENC_KEY") or os.environ.get("MAILBOX_ENC_KEY") or settings.jwt_secret
    key = base64.urlsafe_b64encode(hashlib.sha256(secret.encode("utf-8")).digest())
    return Fernet(key)


def _encrypt(value: str) -> str:
    return _fernet().encrypt(value.encode("utf-8")).decode("ascii")


def _decrypt(value: Optional[str]) -> Optional[str]:
    if not value:
        return None
    try:
        return _fernet().decrypt(value.encode("ascii")).decode("utf-8")
    except (InvalidToken, ValueError):
        log.warning("graph_config: stored client secret failed to decrypt (enc key rotated?) — ignoring")
        return None


def _row() -> Optional[dict]:
    _ensure_table()
    with get_conn() as conn:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute("SELECT * FROM graph_api_config WHERE id = 1")
            r = cur.fetchone()
            return dict(r) if r else None


def get_public() -> Dict[str, Any]:
    """Config as the API may expose it — the client secret never leaves the
    server, only whether one is stored."""
    r = _row()
    return {
        "tenant_id": (r or {}).get("tenant_id") or os.environ.get("GRAPH_TENANT_ID", ""),
        "client_id": (r or {}).get("client_id") or os.environ.get("GRAPH_CLIENT_ID", ""),
        "has_client_secret": bool((r or {}).get("client_secret_enc")),
        "env_secret_present": bool(os.environ.get("GRAPH_CLIENT_SECRET")),
        "env_tenant_present": bool(os.environ.get("GRAPH_TENANT_ID")),
        "env_client_present": bool(os.environ.get("GRAPH_CLIENT_ID")),
        "updated_at": r["updated_at"].isoformat() if r and r.get("updated_at") else None,
        "updated_by": (r or {}).get("updated_by"),
    }


def save(
    *,
    tenant_id: str,
    client_id: str,
    client_secret: Optional[str],
    updated_by: str,
) -> Dict[str, Any]:
    """Persist the Graph app credentials. A blank client_secret KEEPS the
    already-stored one; the literal ``"-"`` clears it."""
    existing = _row()

    if client_secret == "-":
        secret_enc = None
    elif client_secret:
        secret_enc = _encrypt(client_secret)
    else:
        secret_enc = (existing or {}).get("client_secret_enc")

    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO graph_api_config (id, tenant_id, client_id, client_secret_enc, updated_by, updated_at)
                VALUES (1, %s, %s, %s, %s, CURRENT_TIMESTAMP)
                ON CONFLICT (id) DO UPDATE SET
                    tenant_id = EXCLUDED.tenant_id,
                    client_id = EXCLUDED.client_id,
                    client_secret_enc = EXCLUDED.client_secret_enc,
                    updated_by = EXCLUDED.updated_by,
                    updated_at = CURRENT_TIMESTAMP
                """,
                (
                    (tenant_id or "").strip() or None,
                    (client_id or "").strip() or None,
                    secret_enc,
                    updated_by,
                ),
            )
    # The MSAL app caches the credentials it was built with — force a rebuild
    # so the next Graph call uses the new ones.
    try:
        from app.services import graph_client

        graph_client.reset_auth_cache()
    except Exception as exc:  # noqa: BLE001 — best-effort
        log.warning("graph_config: could not reset graph auth cache: %s", exc)
    try:
        from app.services import audit

        audit.write_event(
            layer="SYSTEM", step="graph_config_changed", status="Info",
            fail_reason=(
                f"Graph API config saved by {updated_by}: tenant "
                f"{'set' if tenant_id else 'env-default'}, client "
                f"{'set' if client_id else 'env-default'}, secret "
                f"{'updated' if client_secret and client_secret != '-' else ('cleared' if client_secret == '-' else 'kept')}"
            ),
        )
    except Exception as exc:  # noqa: BLE001
        log.warning("graph_config: audit write failed: %s", exc)
    return get_public()


def resolve() -> Dict[str, Optional[str]]:
    """Effective Graph credentials — DB row → env. Best-effort: any failure
    returns just the env values so mail intake can never be blocked by a bad
    row."""
    out: Dict[str, Optional[str]] = {
        "tenant_id": os.environ.get("GRAPH_TENANT_ID"),
        "client_id": os.environ.get("GRAPH_CLIENT_ID"),
        "client_secret": os.environ.get("GRAPH_CLIENT_SECRET"),
    }
    try:
        r = _row()
        if r:
            if r.get("tenant_id"):
                out["tenant_id"] = r["tenant_id"]
            if r.get("client_id"):
                out["client_id"] = r["client_id"]
            secret = _decrypt(r.get("client_secret_enc"))
            if secret:
                out["client_secret"] = secret
    except Exception as exc:  # noqa: BLE001 — env fallback keeps intake alive
        log.warning("graph_config.resolve failed — using env: %s", exc)
    return out


def is_configured() -> bool:
    """True when tenant + client + secret all resolve (DB or env)."""
    c = resolve()
    return bool(c.get("tenant_id") and c.get("client_id") and c.get("client_secret"))
