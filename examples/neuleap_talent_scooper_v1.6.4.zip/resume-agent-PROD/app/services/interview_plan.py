"""Hardcoded interview workflow — the per-candidate round flow.

The plan is fixed in code (no Settings/DB config). The recruiter decides, once on the
Screening round, WHETHER the optional Round 3 runs. Interviewers are NOT pinned in
code — every round's interviewer is entered manually per candidate, so no names
appear anywhere in the app.

    Screening → Round 1 → Round 2 → [Round 3] → Final → Hired
      Round 3 is optional — included only when include_round3 is set.
      Passing Final = Hired.
"""
from __future__ import annotations

from typing import Optional

# Ordered interview rounds (excludes "New"). Round 3 is conditional on include_round3.
FLOW = ["Screening", "Round 1", "Round 2", "Round 3", "Final"]


def round1_options(domain: Optional[str]) -> list[str]:
    """No preset Round 1 interviewers — the recruiter types the name manually."""
    return []


def next_planned_stage(current: Optional[str], include_round3: bool) -> Optional[str]:
    """The next round after ``current`` in this candidate's plan, or None after Final.

    Skips the optional Round 3 unless ``include_round3`` is set.
    """
    name = (current or "New").strip()
    if name == "New":
        return "Screening"
    if name not in FLOW:
        return None
    nxt = FLOW[FLOW.index(name) + 1] if FLOW.index(name) + 1 < len(FLOW) else None
    if nxt == "Round 3" and not include_round3:
        nxt = "Final"
    return nxt


# Display tiers for an ACTIONABLE step (schedule/advance), keyed by the candidate's
# ATS priority band (P1 best → P4). The tone is a UI hint, not a colour.
_PRIORITY_TIERS = {
    1: ("act_now", "Act now", "urgent"),
    2: ("high", "High priority", "high"),
    3: ("medium", "Medium priority", "medium"),
    4: ("low", "Low priority", "low"),
}


def _action_priority(action: str, band: Optional[str]) -> dict:
    """Model B triage signal: actionability FIRST, then ATS band.

    A step you can take now (schedule/advance) always outranks one you're only
    waiting on (await), and within each group the candidate's ATS band (P1>P2>P3>P4)
    breaks the tie. ``rank`` is the sort key (lower = act sooner) the profile chip and a
    future worklist share; ``tier``/``tone`` drive the chip styling.
    """
    b = (band or "").strip().upper()
    bandnum = int(b[1]) if len(b) == 2 and b[0] == "P" and b[1].isdigit() else 4
    if action in ("schedule", "advance"):
        tier, label, tone = _PRIORITY_TIERS[bandnum]
        return {"priority_tier": tier, "priority_label": label, "priority_tone": tone,
                "priority_band": b or None, "priority_rank": bandnum}
    if action == "await":
        # Ball is in the interviewer's court — ranked below every actionable step.
        return {"priority_tier": "waiting", "priority_label": "Waiting on interview",
                "priority_tone": "muted", "priority_band": b or None,
                "priority_rank": 10 + bandnum}
    # Terminal (rejected/hired/none) — nothing to prioritise.
    return {"priority_tier": "none", "priority_label": "No action needed",
            "priority_tone": "muted", "priority_band": b or None, "priority_rank": 99}


def next_best_action(
    current: Optional[str],
    round_status: Optional[str],
    include_round3: bool,
    priority: Optional[str] = None,
) -> dict:
    """Recruiter-facing "next best action" for the profile, derived from the round flow.

    Deterministic (no LLM): the suggestion is a pure function of the candidate's current
    round (``current`` = candidate_master.roundname) and its latest verdict
    (``round_status``, derived from the active round's outcome). ``priority`` is the
    candidate's ATS band (P1–P4); it adds the triage signal (Model B) so the recruiter
    can tell which candidate to act on first. Returns a payload the UI renders directly:

        {"stage": <next round or None>, "action": <verb>, "label": <full sentence>,
         "priority_tier": ..., "priority_label": ..., "priority_tone": ...,
         "priority_band": ..., "priority_rank": <sort key, lower = act sooner>}

    Terminal verdicts short-circuit: a Rejected candidate has no next round; a Hired one
    is done. While a round is still In Progress / Hold we suggest waiting for its outcome
    rather than jumping ahead.
    """
    status = (round_status or "").strip().lower()
    name = (current or "New").strip()

    if status == "rejected":
        base = {"stage": None, "action": "none",
                "label": f"Rejected at {name} — no further rounds."}
    elif status == "hired" or (name == "Final" and status == "cleared"):
        base = {"stage": None, "action": "none",
                "label": "Hired — interview process complete."}
    else:
        nxt = next_planned_stage(name, include_round3)
        if not nxt:
            base = {"stage": None, "action": "none",
                    "label": "No further rounds planned."}
        # Current round still open → wait for its verdict before advancing.
        elif name != "New" and status in {"in progress", "hold", ""}:
            base = {"stage": nxt, "action": "await",
                    "label": f"Awaiting {name} outcome — next would be {nxt}."}
        else:
            verb = "Schedule" if name == "New" else "Advance to"
            base = {"stage": nxt, "action": "schedule", "label": f"{verb} {nxt}."}

    base.update(_action_priority(base["action"], priority))
    return base


def interviewer_for(
    stage: str, domain: Optional[str] = None, round1_choice: Optional[str] = None
) -> Optional[str]:
    """The interviewer to prefill when a round for ``stage`` is auto-created.

    No interviewer is auto-assigned to any stage — all are entered manually — so the
    only value ever returned is an explicit Round 1 choice the recruiter typed in.
    """
    if stage == "Round 1" and round1_choice:
        return round1_choice
    return None


def allowed_advance(current: Optional[str], include_round3: bool) -> list[str]:
    """Stages a Pass on ``current`` may advance to: the planned next, plus the option
    to skip the optional Round 3 (Round 2 → Final) when it's included."""
    name = (current or "New").strip()
    if name == "Round 2" and include_round3:
        return ["Round 3", "Final"]
    nxt = next_planned_stage(name, include_round3)
    return [nxt] if nxt else []


def forward_stages(current: Optional[str], include_round3: bool) -> list[str]:
    """EVERY stage after ``current`` in flow order (Round 3 only when included) —
    the interviewer verdict picker offers all of them, so a standout candidate
    can leapfrog straight to Final from Round 1 instead of only ever moving one
    round at a time."""
    name = (current or "New").strip()
    if name == "New":
        idx = -1
    elif name in FLOW:
        idx = FLOW.index(name)
    else:
        return []
    return [s for s in FLOW[idx + 1:] if s != "Round 3" or include_round3]


def is_valid_advance(current: Optional[str], target: Optional[str], include_round3: bool) -> bool:
    return bool(target) and target in allowed_advance(current, include_round3)
