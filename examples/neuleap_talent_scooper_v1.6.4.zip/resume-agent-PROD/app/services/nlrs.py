"""NLRS (Neuleap Resume Score) — a weighted 0–100 composite, computed live (never
stored) from signals the pipeline has already produced, so it always reflects the
latest scoring formula with no extraction re-run needed:

    NLRS = 45% Analysis Report + 30% CGPA + 12% Certificates + 8% Experience + 5% ATS
    (weights are Admin-configurable — Settings → Extraction & Analysis → NLRS,
    see app.services.nlrs_config; the 45/30/12/8/5 split above is just the default)

Component sourcing (each normalized to 0–100 first):
  * Analysis Report — reuses the ATS score_breakdown's "LLM track fit" subscore:
    it's the LLM's holistic read of the candidate against the track, grounded in
    the same narrative as the Analysis Report card, MINUS the certifications
    angle (that's scored separately below, so it isn't double-counted).
  * CGPA — the candidate's CGPA on its native 0–10 scale, ×10 to 0–100. When a
    candidate has NO CGPA on record it is EXCLUDED and the other components
    renormalize, so a missing CGPA neither helps nor hurts (a real 0 counts).
  * Certificates — the ATS certification_bonus (points earned / cap), already a
    capped, track-relevant credit for the candidate's certs.
  * Years of experience — yearofexp linearly scaled against a 10-year ceiling
    (10y+ = 100). A Fresher/unset value scores 0 on this component by design —
    this weight is specifically rewarding tenure.
  * ATS — the existing deterministic 0–100 atsscore, taken as-is.

On top of the weighted sum, any Admin-defined custom rules (nlrs_config) apply a
flat point adjustment when a numeric candidate field crosses a threshold (e.g.
"total_companieswitched >= 4" -> -5), before the final 0–100 clamp.

Also predicts an initial Next Best Action from the NLRS band — thresholds are
Admin-configurable too (Settings → Extraction & Analysis → NLRS; default
mirrors NextActionOverride.tsx's suggestedNba() ATS thresholds below 70, so
the recruiter-facing language stays consistent app-wide). Above the 70
baseline, three narrow high bands fast-track a genuinely exceptional
candidate straight past rounds a merely-good one still clears one at a time:
    NLRS >= final_round band   -> final_round     ("Share interview slots for Final round")
    NLRS >= share_round2 band  -> share_round2     ("Share interview slots for Round 2")
    NLRS >= share_round1 band  -> share_round1     ("Share interview slots for Round 1")
    NLRS >= call_now band      -> call_now         ("Share interview slots for Screening")
    NLRS >= undecided band     -> undecided        ("Undecided for now")
    else                       -> reject           ("Straight Reject")
"""
from __future__ import annotations

from typing import Any, Dict, Optional

from app.services import nlrs_config

_LABELS = {
    "analysis_report": "Analysis Report",
    "cgpa": "CGPA",
    "certificates": "Certificates",
    "experience": "Years of experience",
    "ats": "ATS",
}


def _clamp(v: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, v))


_OPS = {
    ">": lambda a, b: a > b,
    ">=": lambda a, b: a >= b,
    "<": lambda a, b: a < b,
    "<=": lambda a, b: a <= b,
    "==": lambda a, b: a == b,
    "!=": lambda a, b: a != b,
}


def compute_nlrs(candidate: Dict[str, Any]) -> Dict[str, Any]:
    """Returns {"score", "components": [...], "adjustments": [...]}."""
    cfg = nlrs_config.get()
    weights = cfg["weights"]

    breakdown = candidate.get("score_breakdown") or []
    llm_fit = next(
        (b.get("subscore") for b in breakdown if b.get("component") == "LLM track fit"),
        None,
    )
    analysis_score = _clamp(float(llm_fit)) if llm_fit is not None else 0.0

    cert = candidate.get("certification_bonus") or {}
    cap = float(cert.get("cap") or 0)
    points = float(cert.get("points") or 0)
    cert_score = _clamp((points / cap) * 100.0) if cap > 0 else 0.0

    yoe = candidate.get("yearofexp")
    years_score = _clamp((float(yoe) / 10.0) * 100.0) if yoe else 0.0

    ats_score = _clamp(float(candidate.get("atsscore") or 0))

    # CGPA — native 0–10 scale → 0–100. UNKNOWN (no CGPA in the sheet or resume)
    # is different from a real 0: it's EXCLUDED from the mix and the remaining
    # components renormalize (below), so a missing CGPA neither helps nor hurts.
    # A recorded 0 is treated as a genuine score. (Values >10, e.g. a percentage
    # that slipped through, are clamped at 100.)
    cgpa_raw = candidate.get("cgpa")
    cgpa_known = cgpa_raw is not None
    cgpa_score = _clamp((float(cgpa_raw) / 10.0) * 100.0) if cgpa_known else 0.0

    subscores = {
        "analysis_report": analysis_score,
        "cgpa": cgpa_score,
        "certificates": cert_score,
        "experience": years_score,
        "ats": ats_score,
    }
    # Only components that apply to THIS candidate carry weight; CGPA drops out
    # when unknown. Renormalizing the present weights to sum to 1.0 keeps the
    # score a true 0–100 weighted average and makes a missing CGPA neutral
    # (also self-heals if the Admin's configured weights don't sum to exactly 1).
    order = ("analysis_report", "cgpa", "certificates", "experience", "ats")
    present = [k for k in order if k != "cgpa" or cgpa_known]
    total_weight = sum(weights.get(k, 0.0) for k in present) or 1.0
    weighted = [
        {
            "label": _LABELS[key],
            "weight": round(weights.get(key, 0.0) / total_weight, 4),
            "subscore": round(subscores[key], 1),
        }
        for key in present
    ]
    total = 0.0
    for c in weighted:
        c["weighted"] = round(c["weight"] * c["subscore"], 2)
        total += c["weighted"]

    adjustments: list[Dict[str, Any]] = []
    for rule in cfg["rules"]:
        raw = candidate.get(rule["field"])
        if raw is None:
            continue
        try:
            actual = float(raw)
        except (TypeError, ValueError):
            continue
        if _OPS[rule["op"]](actual, rule["value"]):
            total += rule["points"]
            adjustments.append({"label": rule["label"], "points": rule["points"]})

    return {
        "score": round(_clamp(total), 1),
        "components": weighted,
        "adjustments": adjustments,
    }


def predicted_nba_key(nlrs_score: float) -> str:
    """The system-suggested initial NBA key for a "New" (not-yet-screened)
    candidate, banded off their NLRS against the configured (or default)
    thresholds — mirrors suggestedNba()'s ATS thresholds by default.

    Above the long-standing "call_now" (Screening) baseline, three narrow,
    high bands fast-track a genuinely exceptional candidate straight to a
    later round — reducing needless interview cycles for the very promising
    minority without touching anything below 70. Checked highest-first so a
    candidate clearing final_round's bar doesn't also match the lower ones."""
    bands = nlrs_config.get()["nba_bands"]
    if nlrs_score >= bands["final_round"]:
        return "final_round"
    if nlrs_score >= bands["share_round2"]:
        return "share_round2"
    if nlrs_score >= bands["share_round1"]:
        return "share_round1"
    if nlrs_score >= bands["call_now"]:
        return "call_now"
    if nlrs_score >= bands["undecided"]:
        return "undecided"
    return "reject"


def enrich_with_nlrs(row: Dict[str, Any]) -> Dict[str, Any]:
    """Adds `nlrs` (score + components) to a candidate row, and — only while the
    candidate is still in the "New" bucket with no recruiter override yet —
    `predicted_nba` (key + whether it's actionable). Mutates and returns `row`."""
    nlrs = compute_nlrs(row)
    row["nlrs"] = nlrs

    is_new = (
        row.get("status") == "Active"
        and not row.get("roundid")
        and not row.get("next_action_override")
    )
    row["predicted_nba"] = predicted_nba_key(nlrs["score"]) if is_new else None
    return row
