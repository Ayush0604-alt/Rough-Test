"""Per-round-type interviewer rosters — Settings → Interviewer Access.

Each round type (the 7 standard stages, plus any admin-added custom ones)
holds a list of {name, email} interviewer entries. This roster is what the
candidate slot-selection flow reads to know whose Graph calendar to check for
availability at each stage (see app.services.graph_client / the interview
scheduling config in app.services.interview_scheduling_config) — for now
every lookup is redirected to a single QA stand-in mailbox regardless of
which interviewer is actually configured here, but the roster itself is
already stage-accurate so the redirect can be lifted later without a UI
change. JSON-file-backed, same runtime-file philosophy as interviewer_domains.
"""
from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

from app.logging_config import get_logger

log = get_logger(__name__)

# Fixed default stages, in display order. Admins may append further custom
# round types beyond these — those are marked "custom": True so the UI can
# offer to remove them (the 7 defaults cannot be removed, only re-rostered).
DEFAULT_ROUND_TYPES = (
    "Screening", "Round 1", "Round 2", "Final", "HR", "Joining FollowUp", "Onboarding",
)


def _slugify(label: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "_", label.strip().lower()).strip("_")
    return slug or "round"


def _path() -> Path:
    return Path(os.environ.get("ROUND_INTERVIEWERS_FILE", "secrets/round_interviewers.json"))


def _default_data() -> Dict[str, Any]:
    return {
        "round_types": [
            {"key": _slugify(name), "label": name, "custom": False, "interviewers": []}
            for name in DEFAULT_ROUND_TYPES
        ]
    }


def _valid_interviewer(e: Any) -> bool:
    return (
        isinstance(e, dict)
        and isinstance(e.get("name"), str) and bool(e["name"].strip())
        and isinstance(e.get("email"), str) and "@" in e["email"]
    )


def get() -> Dict[str, Any]:
    """Merges saved rosters onto the shipped default stage list — never
    raises; a missing/corrupt file just reads as "no rosters set yet"."""
    data = _default_data()
    try:
        raw = json.loads(_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return data
    if not isinstance(raw.get("round_types"), list):
        return data

    by_key = {rt["key"]: rt for rt in data["round_types"]}
    order = [rt["key"] for rt in data["round_types"]]
    for rt in raw["round_types"]:
        if not isinstance(rt, dict):
            continue
        key = str(rt.get("key") or _slugify(str(rt.get("label", ""))))
        label = str(rt.get("label") or key).strip()
        if not label:
            continue
        interviewers = [
            {"name": e["name"].strip(), "email": e["email"].strip()}
            for e in (rt.get("interviewers") or [])
            if _valid_interviewer(e)
        ]
        if key in by_key:
            by_key[key] = {"key": key, "label": label, "custom": by_key[key]["custom"], "interviewers": interviewers}
        else:
            by_key[key] = {"key": key, "label": label, "custom": True, "interviewers": interviewers}
            order.append(key)
    data["round_types"] = [by_key[k] for k in order if k in by_key]
    return data


def save(round_types: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Whole-list replace (mirrors nlrs_config/scoring_config): the caller
    sends the full roster set — including any custom types it wants kept —
    and this becomes the new saved state. Blank/invalid rows are dropped
    rather than rejected outright, since a mistyped interviewer row shouldn't
    block saving the rest of the roster."""
    defaults_by_key = {_slugify(name): name for name in DEFAULT_ROUND_TYPES}
    seen: Dict[str, Dict[str, Any]] = {}
    order: List[str] = []
    for rt in round_types:
        if not isinstance(rt, dict):
            continue
        label = str(rt.get("label", "")).strip()
        if not label:
            continue
        key = str(rt.get("key") or "").strip() or _slugify(label)
        interviewers = [
            {"name": e["name"].strip(), "email": e["email"].strip().lower()}
            for e in (rt.get("interviewers") or [])
            if _valid_interviewer(e)
        ]
        is_custom = key not in defaults_by_key
        if key not in seen:
            order.append(key)
        seen[key] = {"key": key, "label": label, "custom": is_custom, "interviewers": interviewers}

    # Any default stage the caller omitted entirely is kept (empty roster),
    # never silently dropped — the 7 standard stages always exist.
    for key, label in defaults_by_key.items():
        if key not in seen:
            seen[key] = {"key": key, "label": label, "custom": False, "interviewers": []}
            order.insert(list(defaults_by_key).index(key), key)

    data = {"round_types": [seen[k] for k in order]}
    path = _path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        log.info("round_interviewers_config: saved %d round type(s)", len(data["round_types"]))
    except OSError as exc:  # noqa: BLE001 — a write failure must not break the request
        log.warning("round_interviewers_config: could not write %s: %s", path, exc)
    return get()


def interviewers_for(round_label: str) -> List[Dict[str, str]]:
    """Roster for a round matched by label (case-insensitive) — [] if the
    round type isn't found or has no interviewers configured yet."""
    target = round_label.strip().lower()
    for rt in get()["round_types"]:
        if rt["label"].strip().lower() == target:
            return rt["interviewers"]
    return []


def find_interviewer(email: str) -> Optional[Dict[str, Any]]:
    """The configured interviewer entry for this email (case-insensitive),
    across every round type — powers the interviewer timeslot pool
    self-service portal's login check (app.services.pool_interviewer_auth).
    Returns ``{"name": ..., "email": ..., "round_names": [...]}`` (every round
    this person is rostered for) or None if the email isn't configured
    anywhere."""
    target = email.strip().lower()
    name: Optional[str] = None
    round_names: List[str] = []
    for rt in get()["round_types"]:
        for iv in rt["interviewers"]:
            if iv["email"].strip().lower() == target:
                name = iv["name"]
                round_names.append(rt["label"])
    if name is None:
        return None
    return {"name": name, "email": target, "round_names": round_names}
