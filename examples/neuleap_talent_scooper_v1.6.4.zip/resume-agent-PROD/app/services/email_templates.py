"""Email draft templates for the "Agent action" side of an NBA selection.

No real template-library integration exists yet — these are simple, hardcoded
subject/body generators, one per NBA key whose "Agent action" sends an ack-email
(frontend/src/components/candidate/NextActionOverride.tsx's NBA_OPTIONS). Picking
one of these keys creates a draft (status='draft') for recruiter review; nothing
is dispatched — see app.api.rounds.patch_next_action_override.
"""
from __future__ import annotations

from typing import Callable, Optional

_SLOT_LINK_PLACEHOLDER = "[interview-slot-picker-link]"
# Public alias — the auto-send path checks a draft body for this to know it's a
# slot-invite email that MUST have a real link inserted before it can go out.
SLOT_LINK_PLACEHOLDER = _SLOT_LINK_PLACEHOLDER


def _greeting(name: Optional[str]) -> str:
    first = (name or "").strip().split(" ")[0] or "there"
    return f"Hi {first},"


def _call_now(name: Optional[str]) -> tuple[str, str]:
    subject = "Let's schedule your interview"
    body = (
        f"{_greeting(name)}\n\n"
        "Thanks for applying — we'd like to move ahead and schedule an interview with you "
        "at the earliest.\n\n"
        f"Please pick a slot that works for you here: {_SLOT_LINK_PLACEHOLDER}\n\n"
        "Looking forward to speaking with you.\n\n"
        "Best,\nThe Hiring Team"
    )
    return subject, body


def _undecided(name: Optional[str]) -> tuple[str, str]:
    subject = "Thanks for applying"
    body = (
        f"{_greeting(name)}\n\n"
        "Thank you for taking the time to apply. We've reviewed your profile and, while we "
        "don't have a matching opportunity open right now, we'll keep your application on "
        "file and reach out as soon as one comes up.\n\n"
        "Best,\nThe Hiring Team"
    )
    return subject, body


def _office_interview(name: Optional[str]) -> tuple[str, str]:
    subject = "Please schedule your in-office interview"
    body = (
        f"{_greeting(name)}\n\n"
        "We'd like to invite you for an in-office interview.\n\n"
        f"Please pick a slot that works for you here: {_SLOT_LINK_PLACEHOLDER}\n\n"
        "We look forward to meeting you in person.\n\n"
        "Our office Location is at:\n\n"
        "Office No. 503, Ascent Avenue, Amanora Park Town Main Rd, Amanora Park Town, "
        "Hadapsar, Pune, Maharashtra 411028\n\n"
        "https://maps.app.goo.gl/BbH848dBAG8z7yVX7\n\n"
        "Best,\nThe Hiring Team"
    )
    return subject, body


def _final_round(name: Optional[str]) -> tuple[str, str]:
    subject = "Final round — please pick an interview slot"
    body = (
        f"{_greeting(name)}\n\n"
        "Good job on making it to the final round! Just the last mile before the final "
        "decision.\n\n"
        "We'd like to schedule this interview with you.\n\n"
        f"Please pick a slot that works for you here: {_SLOT_LINK_PLACEHOLDER}\n\n"
        "Good Luck,\nThe Hiring Team"
    )
    return subject, body


def _share_round2(name: Optional[str]) -> tuple[str, str]:
    subject = "Round 2 — please pick an interview slot"
    body = (
        f"{_greeting(name)}\n\n"
        "Thanks for applying — your profile stood out, so we'd like to move you straight "
        "to Round 2.\n\n"
        f"Please pick a slot that works for you here: {_SLOT_LINK_PLACEHOLDER}\n\n"
        "Looking forward to speaking with you.\n\n"
        "Best,\nThe Hiring Team"
    )
    return subject, body


def _share_round3(name: Optional[str]) -> tuple[str, str]:
    subject = "Round 3 — please pick an interview slot"
    body = (
        f"{_greeting(name)}\n\n"
        "Great progress so far — we'd like to move you ahead to Round 3.\n\n"
        f"Please pick a slot that works for you here: {_SLOT_LINK_PLACEHOLDER}\n\n"
        "Looking forward to speaking with you.\n\n"
        "Best,\nThe Hiring Team"
    )
    return subject, body


def _share_round1(name: Optional[str]) -> tuple[str, str]:
    subject = "Round 1 — please pick an interview slot"
    body = (
        f"{_greeting(name)}\n\n"
        "Thanks for applying — your profile stood out, so we'd like to move you straight "
        "to Round 1.\n\n"
        f"Please pick a slot that works for you here: {_SLOT_LINK_PLACEHOLDER}\n\n"
        "Looking forward to speaking with you.\n\n"
        "Best,\nThe Hiring Team"
    )
    return subject, body


def _reject_email(name: Optional[str]) -> tuple[str, str]:
    """Post-interview decline — no slot link. Drafted (never silently sent) when
    an interview verdict is Fail/Reject, so the recruiter can review the wording
    and send it (or let auto-send ship it if that's configured)."""
    subject = "Update on your application"
    body = (
        f"{_greeting(name)}\n\n"
        "Thank you for taking the time to interview with us and for your interest in the "
        "role. After careful consideration, we've decided not to move forward with your "
        "application at this time.\n\n"
        "This was a competitive process and the decision wasn't an easy one. We genuinely "
        "appreciate the effort you put in, and we'd be glad to stay in touch should a more "
        "suitable opportunity come up in the future.\n\n"
        "We wish you all the very best in your search.\n\n"
        "Best,\nThe Hiring Team"
    )
    return subject, body


# NBA keys that send an email — every other key (reject/hire/custom) never
# generates a draft. "reject_email" is the post-interview decline; the plain
# "reject" (resume-triage straight reject) still sends nothing.
_TEMPLATES: dict[str, Callable[[Optional[str]], tuple[str, str]]] = {
    "call_now": _call_now,
    "undecided": _undecided,
    "office_interview": _office_interview,
    "final_round": _final_round,
    "share_round2": _share_round2,
    "share_round3": _share_round3,
    "share_round1": _share_round1,
    "reject_email": _reject_email,
}


# The round each draft-generating NBA key invites the candidate to — lets an
# override use a literal {round_name} placeholder even in the ack templates.
_NBA_KEY_ROUND = {
    "call_now": "Screening",
    "share_round1": "Round 1",
    "share_round2": "Round 2",
    "share_round3": "Round 3",
    "final_round": "Final",
    "office_interview": "Final",
    "undecided": "",
}


def _override_for(key: str) -> Optional[dict]:
    try:
        from app.services import email_template_overrides

        ov = email_template_overrides.get().get(key)
    except Exception:  # noqa: BLE001 — a config hiccup must never block email generation
        return None
    return ov if ov and ov.get("subject") and ov.get("body") else None


def _substitute(text: str, substitutions: dict[str, str]) -> str:
    for ph, val in substitutions.items():
        text = text.replace(ph, val)
    return text


def render_draft(nba_key: str, candidate_name: Optional[str]) -> Optional[tuple[str, str]]:
    """(subject, body) for this NBA key, or None if this key doesn't send an email.

    An admin-edited BASE template (app.services.email_template_overrides —
    Mailbox → Archives & Interview Slots → Email Base Templates) replaces the
    shipped default here, with ``{first_name}``/``{round_name}`` substituted."""
    fn = _TEMPLATES.get(nba_key)
    if fn is None:
        return None
    ov = _override_for(nba_key)
    if ov:
        subs = {
            "{first_name}": (candidate_name or "").strip().split(" ")[0] or "there",
            "{round_name}": _NBA_KEY_ROUND.get(nba_key, ""),
        }
        return _substitute(ov["subject"], subs), _substitute(ov["body"], subs)
    return fn(candidate_name)


# ── Candidate interview slot-selection — sent directly (fire-and-forget via
# graph_client.send_mail), not through the draft-review indirection above:
# these are triggered automatically when a round becomes the candidate's new
# active round (see app.api.rounds' auto-invite hook), not a recruiter-picked
# NBA action. Keyed by ROUND NAME (Screening/Round 1/.../Onboarding), a
# different vocabulary from the NBA keys above — see app.services.interview_plan
# / ROUND_PRESETS — so these live in their own functions rather than sharing
# `_TEMPLATES`'s key namespace.

def render_slot_invite(round_name: str, candidate_name: Optional[str], link_url: str) -> tuple[str, str]:
    subject = f"Pick your {round_name} interview slot"
    body = (
        f"{_greeting(candidate_name)}\n\n"
        f"You've moved forward to the {round_name} stage — please pick a time that works "
        f"for you within the next two weeks:\n\n{link_url}\n\n"
        "You'll be asked to confirm your email with a one-time code before picking a slot.\n\n"
        "Best,\nThe Hiring Team"
    )
    return subject, body


# ── App-user (staff) account emails — password reset + new-account invite ────
def render_password_reset(name: Optional[str], link_url: str) -> tuple[str, str]:
    subject = "Reset your NeuLeap password"
    body = (
        f"{_greeting(name)}\n\n"
        "We received a request to reset the password for your NeuLeap account. "
        "Use the link below to choose a new password:\n\n"
        f"{link_url}\n\n"
        "This link expires in 1 hour and can be used once. If you didn't request a "
        "reset, you can safely ignore this email — your password won't change.\n\n"
        "Best,\nThe NeuLeap Team"
    )
    return subject, body


def render_account_invite(name: Optional[str], link_url: str) -> tuple[str, str]:
    subject = "Set up your NeuLeap account"
    body = (
        f"{_greeting(name)}\n\n"
        "An account has been created for you on NeuLeap — Talents Scooper. Set your "
        "password using the link below to activate it and sign in:\n\n"
        f"{link_url}\n\n"
        "This link expires in 3 days and can be used once. If you weren't expecting "
        "this, you can ignore this email.\n\n"
        "Best,\nThe NeuLeap Team"
    )
    return subject, body


def slot_reminder_default(
    round_name: str, first: str, link_url: str, reminder_number: str, reminder_total: str
) -> tuple[str, str]:
    """The SHIPPED reminder template — kept separate from render_slot_reminder
    so the Email Base Templates editor can show/reset to this exact text with
    literal placeholders. ``reminder_number``/``reminder_total`` carry the
    "Reminder X of Y" position in the nudge cycle."""
    subject = f"Reminder {reminder_number} of {reminder_total} — pick your {round_name} interview slot"
    body = (
        f"Hi {first},\n\n"
        f"This is reminder {reminder_number} of {reminder_total} — we still don't have an "
        f"interview slot selected for your {round_name} round. "
        f"Please pick a time that works for you here:\n\n{link_url}\n\n"
        "{auto_reject_notice}"
        "Best,\nThe Hiring Team"
    )
    return subject, body


def _auto_reject_notice(
    reminder_number: int, reminder_total: int, reject_window_text: Optional[str]
) -> str:
    """The {auto_reject_notice} substitution — a real warning ONLY on the
    FINAL reminder (the candidate must know the clock is now running), an
    empty string on earlier ones so the template collapses cleanly."""
    if reminder_number < reminder_total:
        return (
            f"You will receive up to {reminder_total} reminders in total.\n\n"
            if reminder_total > 1
            else ""
        )
    window = reject_window_text or "the configured response window"
    return (
        f"⚠ Please note: this is the FINAL reminder. If a slot isn't booked within "
        f"{window} of this email, this application will be automatically marked as "
        "not proceeding.\n\n"
    )


def render_slot_reminder(
    round_name: str,
    candidate_name: Optional[str],
    link_url: str,
    reminder_number: int = 1,
    reminder_total: int = 2,
    reject_window_text: Optional[str] = None,
) -> tuple[str, str]:
    first = (candidate_name or "").strip().split(" ")[0] or "there"
    notice = _auto_reject_notice(reminder_number, reminder_total, reject_window_text)
    ov = _override_for("slot_reminder")
    if ov:
        subs = {
            "{first_name}": first,
            "{round_name}": round_name,
            "{reminder_number}": str(reminder_number),
            "{reminder_total}": str(reminder_total),
            "{auto_reject_notice}": notice,
            _SLOT_LINK_PLACEHOLDER: link_url,
        }
        return _substitute(ov["subject"], subs), _substitute(ov["body"], subs)
    subject, body = slot_reminder_default(
        round_name, first, link_url, str(reminder_number), str(reminder_total)
    )
    return subject, body.replace("{auto_reject_notice}", notice)


def _fmt_when(slot_start, slot_end) -> str:  # noqa: ANN001 — datetime, kept untyped to avoid an import just for a hint
    day = slot_start.strftime("%a, %d %b %Y")
    return f"{day} · {slot_start.strftime('%I:%M %p')}–{slot_end.strftime('%I:%M %p')}"


def render_slot_confirmation(
    round_name: str, candidate_name: Optional[str], slot_start, slot_end, join_url: Optional[str]  # noqa: ANN001
) -> tuple[str, str]:
    """Sent to the CANDIDATE right after they book a pool-scoped slot — a
    backup confirmation alongside Exchange's own meeting-invite email (sent
    automatically once they're added as an attendee on the interviewer's
    event, see app.services.graph_calendar.convert_to_teams_meeting)."""
    subject = f"Confirmed — your {round_name} interview"
    join_line = f"\n\nJoin online (Microsoft Teams): {join_url}\n" if join_url else "\n"
    body = (
        f"{_greeting(candidate_name)}\n\n"
        f"Your {round_name} interview is confirmed for {_fmt_when(slot_start, slot_end)}."
        f"{join_line}\n"
        "You'll also receive a separate calendar invite with the full joining details — please "
        "check your inbox/calendar. There's no reminder call, so please be on time.\n\n"
        "Best,\nThe Hiring Team"
    )
    return subject, body


def render_interviewer_meeting_confirmation(
    round_name: str,
    candidate_name: Optional[str],
    interviewer_name: Optional[str],
    slot_start,  # noqa: ANN001
    slot_end,  # noqa: ANN001
    join_url: Optional[str],
    candidate_link_url: Optional[str],
) -> tuple[str, str]:
    """Sent to the INTERVIEWER right after a candidate books their pool slot —
    the placeholder on their calendar has just been converted into the real
    Teams meeting (they're still the organizer); this mirrors that meeting's
    joining details and adds a direct link to the candidate for prep/feedback."""
    subject = f"{round_name} interview scheduled — {candidate_name or 'candidate'}"
    join_line = f"\n\nJoin online (Microsoft Teams): {join_url}\n" if join_url else "\n"
    link_line = f"\nCandidate details / feedback: {candidate_link_url}\n" if candidate_link_url else ""
    body = (
        f"{_greeting(interviewer_name)}\n\n"
        f"{candidate_name or 'A candidate'} has booked their {round_name} interview for "
        f"{_fmt_when(slot_start, slot_end)}. This has replaced the placeholder hold on your "
        f"calendar — you're the organizer of the Teams meeting."
        f"{join_line}{link_line}\n"
        "Best,\nThe Hiring Team"
    )
    return subject, body


def slot_auto_reject_default(round_name: str, first: str) -> tuple[str, str]:
    """The SHIPPED expiry template — separate for the same editor/reset reason
    as slot_reminder_default above."""
    subject = f"Your {round_name} interview invite has expired"
    body = (
        f"Hi {first},\n\n"
        f"We didn't receive a slot selection for your {round_name} round within the "
        "response window, so we've closed out this invite for now.\n\n"
        "If you'd still like to be considered, please reach out and we'll be happy to "
        "arrange a new time.\n\n"
        "Best,\nThe Hiring Team"
    )
    return subject, body


def render_slot_auto_reject(round_name: str, candidate_name: Optional[str]) -> tuple[str, str]:
    first = (candidate_name or "").strip().split(" ")[0] or "there"
    ov = _override_for("slot_auto_reject")
    if ov:
        subs = {"{first_name}": first, "{round_name}": round_name}
        return _substitute(ov["subject"], subs), _substitute(ov["body"], subs)
    return slot_auto_reject_default(round_name, first)
