"""In-app notification feed — DERIVED at the source, PERSISTED in one table.

Every event the bell surfaces is derived from an existing table:

* pipeline runs / failures   → ``audit_log``        (via :mod:`app.services.audit`)
* manual-review backlog      → ``review_queue``     (open rows)
* new P1 / hired candidates  → ``candidate_master``
* mailbox health             → ``graph_client.is_configured()``

But unlike the old purely-ephemeral feed, each derived item is now upserted into a
single ``notifications`` table keyed by a STABLE, content-derived ``id`` (see
schema.sql). That gives the bell REAL notifications:

* read/unread lives server-side in ``read_at`` (not the browser), so it is shared
  across devices and survives a refresh;
* :func:`sync` re-derives + upserts on every read, keeping ``read_at`` intact, so a
  notification stays read once you read it;
* :func:`cleanup` deletes a notification 24h AFTER it is read — the table self-cleans
  and never grows unbounded. Unread notifications are never auto-deleted.

Each item is gated by the same per-event toggle the email digest uses
(:mod:`app.services.notify_config`), so the bell and the email stay in lockstep.

All reads are best-effort: a notification feed must never raise into a page load.
"""
from __future__ import annotations

from typing import Any, Optional

from app.logging_config import get_logger

log = get_logger(__name__)

# Failure-rate above which the last run earns a 🟡 health warning (see §8 open
# questions — fixed for now, could become a Settings slider later).
FAILURE_SPIKE_RATIO = 0.20

# A read notification is purged this many hours after it was read.
READ_RETENTION_HOURS = 24

# "Singleton" notification types describe a LIVE condition rather than a one-off
# event (the manual-review backlog, a disconnected mailbox). They use a fixed id and
# are deleted by :func:`sync` the moment the condition clears.
SINGLETON_TYPES = ("manual_review", "mailbox_unhealthy")


def _iso(value: Any) -> Optional[str]:
    return value.isoformat() if hasattr(value, "isoformat") else value


def _item(
    *,
    type_: str,
    severity: str,
    title: str,
    body: Optional[str],
    link: Optional[str],
    created_at: Any,
    key: Optional[str] = None,
) -> dict[str, Any]:
    # ``id`` is a stable, content-derived key so re-deriving the same logical event
    # upserts the SAME row (preserving its read_at). Callers pass an explicit ``key``
    # scoped to the thing that makes the event unique (batch id, candidate id, or a
    # fixed string for singletons); we fall back to type:timestamp otherwise.
    return {
        "id": key or f"{type_}:{_iso(created_at) or ''}",
        "type": type_,
        "severity": severity,   # action | health | info
        "title": title,
        "body": body,
        "link": link,
        "created_at": _iso(created_at),
    }


def _run_items(cfg: dict[str, Any]) -> list[dict[str, Any]]:
    """Pipeline run summary / failure / failure-spike — derived from the last batch."""
    if not cfg.get("run_summary"):
        return []
    from app.services import audit

    last = audit.last_run_summary()
    if not last:
        return []

    mail_count = last.get("mail_count") or 0
    processed = last.get("processed") or 0
    failed = last.get("failed") or 0
    ts = last.get("finished_at") or last.get("started_at")
    batch_id = last.get("batch_id")
    items: list[dict[str, Any]] = []

    body = f"{batch_id} · {mail_count} mails · {processed} processed"
    if failed:
        body += f" · {failed} failed"
    items.append(_item(
        type_="run_failed" if failed else "run_summary",
        severity="action" if failed else "info",
        title="Pipeline run finished" if not failed else "Pipeline run finished with errors",
        body=body, link="/pipeline", created_at=ts,
        key=f"run:{batch_id}",  # one notification per batch
    ))

    # Health: a high failure ratio on the last run.
    if mail_count and failed / mail_count > FAILURE_SPIKE_RATIO:
        pct = round(100 * failed / mail_count)
        items.append(_item(
            type_="failure_spike", severity="health",
            title=f"Failure rate high ({pct}%)",
            body=f"{failed} of {mail_count} mails failed in the last run",
            link="/audit-logs", created_at=ts,
            key=f"failure_spike:{batch_id}",
        ))
    return items


def _review_item(cfg: dict[str, Any]) -> list[dict[str, Any]]:
    """Manual-review backlog — derived from open review_queue rows."""
    if not cfg.get("manual_review"):
        return []
    from app.db import get_conn

    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT COUNT(*), MAX(created_at) FROM review_queue WHERE state = 'open'"
                )
                count, latest = cur.fetchone()
    except Exception as exc:  # noqa: BLE001 — feed must never raise
        log.warning("notifications: review backlog query failed: %s", exc)
        return []

    count = int(count or 0)
    if not count:
        return []
    return [_item(
        type_="manual_review", severity="action",
        title="Items need review",
        body=f"{count} resume{'s' if count != 1 else ''} couldn't be auto-processed",
        link="/screening", created_at=latest,
        key="manual_review",  # singleton: one live backlog notification
    )]


def _candidate_items(cfg: dict[str, Any]) -> list[dict[str, Any]]:
    """New P1 (last batch) + recently hired — derived from candidate_master."""
    from app.db import get_conn

    items: list[dict[str, Any]] = []
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                # New P1 candidates from the most recent batch.
                if cfg.get("new_p1"):
                    cur.execute(
                        "SELECT batch_id FROM audit_log "
                        "WHERE layer = 'BATCH' AND step = 'run' "
                        "ORDER BY log_id DESC LIMIT 1"
                    )
                    row = cur.fetchone()
                    last_batch_id = row[0] if row else None
                    cur.execute(
                        """
                        SELECT name, created_at FROM candidate_master
                        WHERE UPPER(COALESCE(priority, '')) = 'P1'
                          AND candidate_id IN (
                            SELECT DISTINCT candidate_id FROM audit_log
                            WHERE candidate_id IS NOT NULL AND batch_id = %s
                          )
                        ORDER BY created_at DESC LIMIT 10
                        """,
                        (last_batch_id,),
                    )
                    p1 = cur.fetchall() if last_batch_id else []
                    if p1:
                        names = ", ".join(n or "Unnamed" for n, _ in p1[:3])
                        more = f" +{len(p1) - 3} more" if len(p1) > 3 else ""
                        items.append(_item(
                            type_="new_p1", severity="info",
                            title=f"{len(p1)} new P1 candidate{'s' if len(p1) != 1 else ''}",
                            body=names + more, link="/resumes",
                            created_at=p1[0][1],
                            key=f"new_p1:{last_batch_id}",
                        ))

                # Recently hired candidates (last 7 days). Bounding the window means a
                # hired notification that was read + purged won't re-alert forever — it
                # simply ages out of the feed instead.
                cur.execute(
                    """
                    SELECT name, candidate_id, COALESCE(closed_at, updated_at) AS ts
                    FROM candidate_master
                    WHERE status = 'Hired'
                      AND COALESCE(closed_at, updated_at) > CURRENT_TIMESTAMP - INTERVAL '7 days'
                    ORDER BY ts DESC LIMIT 5
                    """
                )
                for name, candidate_id, ts in cur.fetchall():
                    items.append(_item(
                        type_="candidate_hired", severity="info",
                        title=f"{name or candidate_id} marked Hired",
                        body=None, link=f"/candidates/{candidate_id}",
                        created_at=ts,
                        key=f"candidate_hired:{candidate_id}",
                    ))
    except Exception as exc:  # noqa: BLE001 — feed must never raise
        log.warning("notifications: candidate query failed: %s", exc)
    return items


def _mailbox_item() -> list[dict[str, Any]]:
    """Mailbox health — derived from the Graph client configuration probe."""
    from app.services import clock, graph_client

    if graph_client.is_configured():
        return []
    return [_item(
        type_="mailbox_unhealthy", severity="health",
        title="Mailbox not connected",
        body="Microsoft Graph isn't configured — new mail won't be polled",
        link="/settings", created_at=clock.now_iso(),
        key="mailbox_unhealthy",  # singleton: clears when the mailbox reconnects
    )]


# ── Derive → persist → serve ─────────────────────────────────────────────────


def _derive() -> list[dict[str, Any]]:
    """Recompute the current notification items from their source tables.

    Best-effort and gated by :mod:`app.services.notify_config`, exactly as before —
    this is the same logic; :func:`sync` is what makes it durable.
    """
    from app.services import notify_config

    cfg = notify_config.get()
    items: list[dict[str, Any]] = []
    items += _run_items(cfg)
    items += _review_item(cfg)
    items += _candidate_items(cfg)
    items += _mailbox_item()
    return items


def cleanup(retention_hours: int = READ_RETENTION_HOURS) -> int:
    """Delete notifications read more than ``retention_hours`` ago. Returns the count."""
    from app.db import get_conn

    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "DELETE FROM notifications "
                    "WHERE read_at IS NOT NULL "
                    "  AND read_at < CURRENT_TIMESTAMP - make_interval(hours => %s)",
                    (retention_hours,),
                )
                return cur.rowcount or 0
    except Exception as exc:  # noqa: BLE001 — cleanup must never raise into a read
        log.warning("notifications: cleanup failed: %s", exc)
        return 0


def sync() -> None:
    """Re-derive the feed and reconcile it with the ``notifications`` table.

    * Upsert every derived item by its stable id — NEW events insert as unread;
      existing ones refresh their text but KEEP ``read_at`` and ``created_at``.
    * Drop singleton notifications (manual_review / mailbox_unhealthy) whose live
      condition no longer holds.
    * Purge notifications read more than 24h ago.

    Best-effort: any failure is logged and swallowed so the bell still renders.
    """
    from app.db import get_conn

    derived = _derive()
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                for n in derived:
                    cur.execute(
                        """
                        INSERT INTO notifications
                            (id, type, severity, title, body, link, created_at)
                        VALUES (%s, %s, %s, %s, %s, %s, COALESCE(%s::timestamptz, CURRENT_TIMESTAMP))
                        ON CONFLICT (id) DO UPDATE SET
                            type     = EXCLUDED.type,
                            severity = EXCLUDED.severity,
                            title    = EXCLUDED.title,
                            body     = EXCLUDED.body,
                            link     = EXCLUDED.link
                        """,
                        (n["id"], n["type"], n["severity"], n["title"],
                         n["body"], n["link"], n["created_at"]),
                    )

                # Singletons describe a live condition — remove any whose id wasn't
                # re-derived this pass (backlog cleared, mailbox reconnected).
                present = [n["id"] for n in derived if n["type"] in SINGLETON_TYPES]
                cur.execute(
                    "DELETE FROM notifications "
                    "WHERE type = ANY(%s) AND NOT (id = ANY(%s))",
                    (list(SINGLETON_TYPES), present),
                )
    except Exception as exc:  # noqa: BLE001 — sync must never raise into a read
        log.warning("notifications: sync failed: %s", exc)

    cleanup()


def feed(limit: int = 50) -> list[dict[str, Any]]:
    """The persisted notification feed, newest first. Best-effort; never raises.

    Syncs the table from source data first, then serves the stored rows (which carry
    the durable ``read_at`` state).
    """
    from app.db import get_conn

    sync()
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT id, type, severity, title, body, link, created_at, read_at
                    FROM notifications
                    ORDER BY created_at DESC NULLS LAST
                    LIMIT %s
                    """,
                    (limit,),
                )
                rows = cur.fetchall()
    except Exception as exc:  # noqa: BLE001 — feed must never raise
        log.warning("notifications: feed query failed: %s", exc)
        return []

    return [
        {
            "id": r[0], "type": r[1], "severity": r[2], "title": r[3],
            "body": r[4], "link": r[5],
            "created_at": _iso(r[6]), "read_at": _iso(r[7]),
        }
        for r in rows
    ]


def mark_all_read() -> int:
    """Stamp every unread notification as read now. Returns the count marked."""
    from app.db import get_conn

    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "UPDATE notifications SET read_at = CURRENT_TIMESTAMP "
                    "WHERE read_at IS NULL"
                )
                return cur.rowcount or 0
    except Exception as exc:  # noqa: BLE001
        log.warning("notifications: mark_all_read failed: %s", exc)
        return 0


def mark_read(notification_id: str) -> bool:
    """Mark a single notification read. Returns True if a row was updated."""
    from app.db import get_conn

    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "UPDATE notifications SET read_at = CURRENT_TIMESTAMP "
                    "WHERE id = %s AND read_at IS NULL",
                    (notification_id,),
                )
                return bool(cur.rowcount)
    except Exception as exc:  # noqa: BLE001
        log.warning("notifications: mark_read failed: %s", exc)
        return False
