"""Azure OpenAI (gpt-4o-mini) wiring for the agentic test runner.

Reads ``neuleap_layer1/env`` and builds an :class:`AzureChatOpenAI` client. The
provided endpoint is a full chat-completions URL; we split it into the base
endpoint, deployment name, and api-version that the SDK expects.
"""

from __future__ import annotations

import os
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from dotenv import dotenv_values

from app.logging_config import get_logger

log = get_logger(__name__)

_ENV_PATH = Path(__file__).resolve().parent / "env"


def load_env(path: Path | str = _ENV_PATH) -> dict[str, str]:
    """Load the env file into ``os.environ`` (without overwriting real env)."""
    values = {k: v for k, v in dotenv_values(str(path)).items() if v is not None}
    for key, val in values.items():
        os.environ.setdefault(key, val)
    return values


def _parse_azure_endpoint(full_url: str) -> tuple[str, str, str]:
    """Split a full Azure chat-completions URL into (base, deployment, version).

    Example input::
        https://x.openai.azure.com/openai/deployments/gpt-4o-mini/chat/completions?api-version=2025-01-01-preview
    -> ("https://x.openai.azure.com", "gpt-4o-mini", "2025-01-01-preview")
    """
    parsed = urlparse(full_url)
    base = f"{parsed.scheme}://{parsed.netloc}"
    parts = parsed.path.strip("/").split("/")
    deployment = ""
    if "deployments" in parts:
        deployment = parts[parts.index("deployments") + 1]
    version = parse_qs(parsed.query).get("api-version", ["2025-01-01-preview"])[0]
    return base, deployment, version


def build_azure_llm(temperature: float = 0.0):
    """Construct an AzureChatOpenAI client from the env file."""
    from langchain_openai import AzureChatOpenAI

    cfg = load_env()
    endpoint = cfg.get("AZURE_OPENAI_ENDPOINT") or os.environ["AZURE_OPENAI_ENDPOINT"]
    api_key = cfg.get("AZURE_OPENAI_KEY") or os.environ["AZURE_OPENAI_KEY"]
    base, deployment, version = _parse_azure_endpoint(endpoint)
    log.info("Azure LLM: deployment=%s api_version=%s", deployment, version)
    return AzureChatOpenAI(
        azure_endpoint=base,
        azure_deployment=deployment or "gpt-4o-mini",
        api_version=version,
        api_key=api_key,
        temperature=temperature,
        timeout=60,
        max_retries=2,
    )
