"""Email draft send controls — Settings → Email Send Controls.

``auto_send_enabled`` (default OFF): when on, marking a draft "ready" prompts
a send-confirmation (recipient shown, QA-restricted if applicable) instead of
just changing status.

``draft_review_required`` (default ON): when off, a draft is sent the moment
it's created — no recruiter review step at all; the full subject/body/
recipient still lands in the audit trail for later inspection. Can ONLY be
False when auto_send_enabled is True (there's no such thing as "skip review"
without also having sending itself turned on). Flipping it to False is
gated behind a SEPARATE re-authentication endpoint
(app.api.settings.disable_draft_review) requiring the acting System Admin's
own password — see that endpoint's docstring for why.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict

from app.logging_config import get_logger

log = get_logger(__name__)

DEFAULTS: Dict[str, Any] = {
    "auto_send_enabled": False,
    "draft_review_required": True,
}


def _path() -> Path:
    return Path(os.environ.get("EMAIL_SEND_CONFIG_FILE", "secrets/email_send_config.json"))


def get() -> Dict[str, Any]:
    out = dict(DEFAULTS)
    try:
        raw = json.loads(_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return out
    if isinstance(raw, dict):
        for k in DEFAULTS:
            if k in raw:
                out[k] = bool(raw[k])
    return out


def save(payload: Dict[str, Any]) -> Dict[str, Any]:
    auto_send_enabled = bool(payload.get("auto_send_enabled", False))
    draft_review_required = bool(payload.get("draft_review_required", True))
    if not draft_review_required and not auto_send_enabled:
        raise ValueError("draft_review_required can only be turned off when auto_send_enabled is on.")
    data = {"auto_send_enabled": auto_send_enabled, "draft_review_required": draft_review_required}
    path = _path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        log.info("email_send_config: saved %s", data)
    except OSError as exc:  # noqa: BLE001
        log.warning("email_send_config: could not write %s: %s", path, exc)
    return get()
