"""In-app bug reports + feature requests (``feedback_reports`` table).

Any signed-in user can file one from the app; the reporter (email/name/role) is
stamped from their authenticated session by the API, never trusted from the
client. Admins/System Admins review + export them from Settings → Feedback.
"""
from __future__ import annotations

import logging
from typing import Any, Optional

import psycopg2.extras

from app.db import get_conn

logger = logging.getLogger(__name__)

KINDS = ("bug", "feature")
PRIORITIES = ("P1", "P2", "P3", "P4", "P5")
# MoSCoW requirement classification, complementing the P1–P5 urgency scale.
MOSCOW = ("must", "should", "could", "wont")
STATUSES = ("open", "in_progress", "resolved", "closed")


def create(
    *,
    kind: str,
    title: str,
    description: str,
    priority: str,
    moscow: Optional[str] = None,
    reporter_email: str,
    reporter_name: str,
    reporter_role: Optional[str] = None,
) -> dict[str, Any]:
    kind = kind if kind in KINDS else "bug"
    priority = priority if priority in PRIORITIES else "P3"
    moscow = moscow if moscow in MOSCOW else None
    with get_conn() as conn:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(
                "INSERT INTO feedback_reports "
                "(kind, title, description, priority, moscow, reporter_email, reporter_name, reporter_role) "
                "VALUES (%s, %s, %s, %s, %s, %s, %s, %s) RETURNING *",
                (kind, title.strip(), (description or "").strip(), priority, moscow,
                 reporter_email, reporter_name, reporter_role),
            )
            row = dict(cur.fetchone())
    logger.info("feedback: %s '%s' filed by %s (%s)", kind, title[:60], reporter_email, priority)
    return row


def list_all() -> list[dict[str, Any]]:
    with get_conn() as conn:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            # Newest first, but open/high-priority float up within that.
            cur.execute(
                "SELECT * FROM feedback_reports "
                "ORDER BY (status IN ('resolved','closed')) ASC, priority ASC, created_at DESC"
            )
            return [dict(r) for r in cur.fetchall()]


def update_status(report_id: int, status: str) -> Optional[dict[str, Any]]:
    if status not in STATUSES:
        return None
    with get_conn() as conn:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(
                "UPDATE feedback_reports SET status = %s, updated_at = CURRENT_TIMESTAMP "
                "WHERE id = %s RETURNING *",
                (status, report_id),
            )
            row = cur.fetchone()
    return dict(row) if row else None


def delete(report_id: int) -> bool:
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("DELETE FROM feedback_reports WHERE id = %s", (report_id,))
            return cur.rowcount > 0
