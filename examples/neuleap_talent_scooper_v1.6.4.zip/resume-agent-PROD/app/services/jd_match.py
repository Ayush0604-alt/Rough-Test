"""JD (Job Description) vs. candidate fit scoring — on-demand, not persisted.

Backs the Screening page's "JD Match" column: a recruiter pastes/uploads a JD,
the frontend sends it plus the CURRENTLY filtered/visible candidate_ids in one
batch, and this scores all of them in a SINGLE LLM call (one prompt, one round
trip) rather than one call per candidate. Results live only in the browser
session — nothing here is written back to candidate_master.

No resume-vs-JD embeddings/vector-similarity infrastructure exists elsewhere in
this app, and the original resume text isn't persisted (only s3_file_path) — so
this leans on the already-extracted structured fields + the LLM's own analysis
narrative as the "resume content" proxy, rather than re-parsing files from S3.

The Azure OpenAI client setup mirrors app.extraction.engine's (_azure_config /
_chat_json) — duplicated rather than imported, since those are engine-private
helpers and this is a genuinely separate call (a batch of many candidates
against one JD, not one candidate against a fixed extraction schema).
"""
from __future__ import annotations

import json
import os
import re
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import parse_qs, urlparse

from openai import AzureOpenAI, NotFoundError

from app.logging_config import get_logger

log = get_logger(__name__)

# Hard cap on one scoring call — keeps prompt size/cost/latency bounded. The
# Screening page only ever sends its currently filtered/visible candidates
# (typically dozens), so this should never bind in normal use; if it does, the
# caller is told to narrow filters rather than silently truncating the list.
MAX_CANDIDATES = 100

DEFAULT_MASTER_DEPLOYMENT = "gpt-4o-mini"


def _azure_config(module: str = "jd_match") -> Tuple[AzureOpenAI, Optional[str]]:
    # Settings -> LLM Model Keys (app.services.llm_config): DB config (global
    # or per-module) wins over env; env remains the fallback.
    from app.services import llm_config

    _cfg = llm_config.resolve(module)
    raw_endpoint = _cfg.get("endpoint")
    api_key = _cfg.get("api_key")
    deployment = _cfg.get("deployment")
    api_version = _cfg.get("api_version") or "2025-01-01-preview"
    _db_deployment = _cfg.get("deployment") if _cfg.get("deployment_from_db") else None

    if not raw_endpoint or not api_key:
        raise RuntimeError("AZURE_OPENAI_ENDPOINT and AZURE_OPENAI_KEY are required")

    endpoint = raw_endpoint.rstrip("/")
    parsed = urlparse(endpoint)
    deployment_match = re.search(r"/deployments/([^/]+)/", parsed.path)
    if deployment_match:
        deployment = deployment or deployment_match.group(1)
        endpoint = f"{parsed.scheme}://{parsed.netloc}"
        query_version = parse_qs(parsed.query).get("api-version")
        if query_version:
            api_version = query_version[0]

    if not deployment:
        deployment = os.getenv("AZURE_OPENAI_MODEL")

    client = AzureOpenAI(api_key=api_key, azure_endpoint=endpoint, api_version=api_version)
    return client, (_db_deployment or deployment)


def _resolve_deployment(default_deployment: Optional[str], module: str = "jd_match") -> str:
    try:
        from app.services import llm_config

        _cfg = llm_config.resolve(module)
        if _cfg.get("deployment_from_db") and _cfg.get("deployment"):
            return _cfg["deployment"]
    except Exception:  # noqa: BLE001
        pass
    deployment = (
        os.getenv("AZURE_OPENAI_MASTER_DEPLOYMENT")
        or os.getenv("AZURE_OPENAI_EXTRACT_DEPLOYMENT")
        or os.getenv("AZURE_OPENAI_DEPLOYMENT")
        or default_deployment
        or DEFAULT_MASTER_DEPLOYMENT
    )
    if not deployment:
        raise RuntimeError("A master deployment is required (set AZURE_OPENAI_DEPLOYMENT).")
    return deployment


def _is_reasoning_deployment(deployment: str) -> bool:
    d = deployment.lower()
    return bool(re.match(r"^o\d", d)) or bool(re.match(r"^gpt-5", d))


def _parse_json_object(content: str) -> Dict[str, Any]:
    content = content.strip()
    if content.startswith("```"):
        content = re.sub(r"^```(?:json)?", "", content, flags=re.IGNORECASE).strip()
        content = re.sub(r"```$", "", content).strip()
    try:
        return json.loads(content)
    except json.JSONDecodeError:
        start = content.find("{")
        end = content.rfind("}")
        if start == -1 or end == -1 or end <= start:
            raise
        return json.loads(content[start : end + 1])


def _candidate_profile(c: Dict[str, Any]) -> Dict[str, Any]:
    """Compact per-candidate summary sent to the LLM."""
    return {
        "candidate_id": c.get("candidate_id"),
        "domain": c.get("domain"),
        "stream": c.get("stream"),
        "fresher_or_lateral": c.get("fresher_or_lateral"),
        "experience_years": c.get("yearofexp"),
        "highest_degree": c.get("highest_coursecompleted"),
        "current_company": c.get("currentcompany"),
        "primary_skills": c.get("primary_skills"),
        "job_roles": c.get("job_roles"),
        "certificates": c.get("certificates"),
        "one_line_summary": c.get("role_context"),
        # Capped — bounds prompt size when scoring dozens of candidates at once.
        "analysis_summary": (c.get("analysis") or "")[:500],
    }


_SYSTEM_PROMPT = """You score how well each candidate fits a job description (JD).
For EVERY candidate in the input list, return an integer fit score from 0-100 \
(100 = perfect fit) and a short rationale (<=140 characters) grounded in the \
candidate's skills/domain/experience versus the JD's requirements. Differentiate \
honestly across candidates - do not give every candidate the same or a \
near-identical score.
Return strict JSON: {"results": [{"candidate_id": "...", "score": 0-100, \
"note": "..."}, ...]} with exactly one entry per candidate_id given, in any order."""


def score_candidates(jd_text: str, candidates: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Score every candidate in ``candidates`` (each a candidate_master row) against
    ``jd_text`` in ONE LLM call. Returns ``[{candidate_id, score, note}, ...]`` —
    ``score``/``note`` are ``None`` for any candidate_id the model didn't return
    a usable entry for."""
    if not candidates:
        return []
    if len(candidates) > MAX_CANDIDATES:
        raise ValueError(
            f"Too many candidates ({len(candidates)}) — narrow your filters to "
            f"{MAX_CANDIDATES} or fewer and try again."
        )

    profiles = [_candidate_profile(c) for c in candidates]
    client, default_deployment = _azure_config("jd_match")
    deployment = _resolve_deployment(default_deployment, "jd_match")

    request: Dict[str, Any] = {
        "model": deployment,
        "messages": [
            {"role": "system", "content": _SYSTEM_PROMPT},
            {
                "role": "user",
                "content": json.dumps(
                    {"job_description": jd_text, "candidates": profiles}, ensure_ascii=False
                ),
            },
        ],
        "response_format": {"type": "json_object"},
    }
    if not _is_reasoning_deployment(deployment):
        request["temperature"] = 0

    try:
        response = client.chat.completions.create(**request)
    except NotFoundError:
        from app.services import llm_config as _llm_cfg

        fallback = _llm_cfg.resolve().get("fallback_deployment")
        if not fallback or fallback == deployment:
            raise
        request["model"] = fallback
        if _is_reasoning_deployment(fallback):
            request.pop("temperature", None)
        response = client.chat.completions.create(**request)

    from app.services import token_usage

    _u = getattr(response, "usage", None)
    token_usage.record(
        module="jd_match",
        model=request["model"],
        prompt_tokens=getattr(_u, "prompt_tokens", None),
        completion_tokens=getattr(_u, "completion_tokens", None),
        total_tokens=getattr(_u, "total_tokens", None),
    )
    content = response.choices[0].message.content or "{}"
    parsed = _parse_json_object(content)
    raw_results = parsed.get("results") if isinstance(parsed, dict) else None
    if not isinstance(raw_results, list):
        log.warning("jd_match: model response had no usable 'results' list")
        raw_results = []

    by_id: Dict[str, Dict[str, Any]] = {}
    for entry in raw_results:
        if not isinstance(entry, dict):
            continue
        cid = entry.get("candidate_id")
        if not cid:
            continue
        score = entry.get("score")
        try:
            score = max(0, min(100, round(float(score))))
        except (TypeError, ValueError):
            score = None
        by_id[cid] = {"candidate_id": cid, "score": score, "note": entry.get("note") or None}

    # Every requested candidate gets a row back, even if the model dropped it.
    return [
        by_id.get(c["candidate_id"], {"candidate_id": c["candidate_id"], "score": None, "note": None})
        for c in candidates
    ]


_EXPLAIN_SYSTEM_PROMPT = """You explain WHY one candidate received their fit score against a job description (JD). Analyse the single candidate given versus the JD's actual requirements and return strict JSON:
{"score": 0-100,
 "summary": "2-3 plain-language sentences: the overall verdict and the main reason for it",
 "dimensions": [{"name": "Skills", "score": 0-100, "reason": "<=120 chars"},
                {"name": "Experience", "score": 0-100, "reason": "<=120 chars"},
                {"name": "Domain fit", "score": 0-100, "reason": "<=120 chars"},
                {"name": "Education & certs", "score": 0-100, "reason": "<=120 chars"},
                {"name": "Role alignment", "score": 0-100, "reason": "<=120 chars"}],
 "strengths": ["JD requirement the candidate clearly MEETS, citing their evidence", ...],
 "gaps": ["JD requirement that is MISSING or unclear from the candidate's profile", ...]}
2-5 strengths, 0-5 gaps. Ground every point in what the JD really asks for versus what the candidate's profile shows - never invent skills or requirements. Be honest about gaps.
If a prior batch score is provided, stay consistent with it (within a few points) unless the profile clearly contradicts it."""


def explain_candidate(
    jd_text: str,
    candidate: Dict[str, Any],
    prior_score: Optional[int] = None,
    prior_note: Optional[str] = None,
) -> Dict[str, Any]:
    """Detailed WHY behind one candidate's JD-match score - called on demand
    when the recruiter clicks the score in the JD Match column, so the richer
    (slower, costlier) per-candidate breakdown is only paid for when asked.
    Returns {score, summary, dimensions: [{name, score, reason}], strengths,
    gaps}. Not persisted, mirroring score_candidates."""
    profile = _candidate_profile(candidate)
    # Single candidate -> afford the full analysis narrative, not the 500-char
    # batch cap, so the explanation can cite real evidence.
    profile["analysis_summary"] = (candidate.get("analysis") or "")[:2500]

    payload: Dict[str, Any] = {"job_description": jd_text, "candidate": profile}
    if prior_score is not None:
        payload["prior_batch_score"] = prior_score
    if prior_note:
        payload["prior_batch_note"] = prior_note

    client, default_deployment = _azure_config("jd_match_explain")
    deployment = _resolve_deployment(default_deployment, "jd_match_explain")
    request: Dict[str, Any] = {
        "model": deployment,
        "messages": [
            {"role": "system", "content": _EXPLAIN_SYSTEM_PROMPT},
            {"role": "user", "content": json.dumps(payload, ensure_ascii=False)},
        ],
        "response_format": {"type": "json_object"},
    }
    if not _is_reasoning_deployment(deployment):
        request["temperature"] = 0

    try:
        response = client.chat.completions.create(**request)
    except NotFoundError:
        from app.services import llm_config as _llm_cfg

        fallback = _llm_cfg.resolve().get("fallback_deployment")
        if not fallback or fallback == deployment:
            raise
        request["model"] = fallback
        if _is_reasoning_deployment(fallback):
            request.pop("temperature", None)
        response = client.chat.completions.create(**request)

    from app.services import token_usage

    _u = getattr(response, "usage", None)
    token_usage.record(
        module="jd_match_explain",
        model=request["model"],
        prompt_tokens=getattr(_u, "prompt_tokens", None),
        completion_tokens=getattr(_u, "completion_tokens", None),
        total_tokens=getattr(_u, "total_tokens", None),
        candidate_id=candidate.get("candidate_id"),
    )
    parsed = _parse_json_object(response.choices[0].message.content or "{}")

    def _clamp(v: Any) -> Optional[int]:
        try:
            return max(0, min(100, round(float(v))))
        except (TypeError, ValueError):
            return None

    dimensions = []
    for d in parsed.get("dimensions") or []:
        if isinstance(d, dict) and d.get("name"):
            dimensions.append(
                {"name": str(d["name"]), "score": _clamp(d.get("score")), "reason": str(d.get("reason") or "")}
            )
    return {
        "candidate_id": candidate.get("candidate_id"),
        "score": _clamp(parsed.get("score")) if parsed.get("score") is not None else prior_score,
        "summary": str(parsed.get("summary") or ""),
        "dimensions": dimensions,
        "strengths": [str(s) for s in (parsed.get("strengths") or []) if s],
        "gaps": [str(g) for g in (parsed.get("gaps") or []) if g],
    }
