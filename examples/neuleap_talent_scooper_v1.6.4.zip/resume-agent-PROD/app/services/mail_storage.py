"""MinIO (S3-compatible) object storage for Layer 1.

Bucket layout (two-stage, per the Layer-1 architecture spec)::

    raw/temp/{E_id}/...                 ← raw downloads land here (pre-validation)
    raw/temp/{E_id}/links/...           ← link downloads
    raw/{YYYY}/{MM}/{DD}/{E_id}/...     ← final clean files (.pdf .docx .jpg .png)

``temp/{E_id}`` is purged once an email's clean files are stored.

Everything is gated on ``NEULEAP_USE_MINIO``. When disabled (e.g. offline unit
tests) every function is a no-op that returns the local path unchanged, so the
LangGraph pipeline still runs fully against the local filesystem.
"""

from __future__ import annotations

import io
import os
from pathlib import Path

from app.logging_config import get_logger
from app.mail_config import _day_from, _month_from, _parse_date

log = get_logger(__name__)

_client = None


def is_enabled() -> bool:
    return os.environ.get("NEULEAP_USE_MINIO", "0") == "1"


def bucket() -> str:
    return os.environ.get("MINIO_BUCKET", "raw")


def _get_client():
    """Lazily build (and cache) the MinIO client; ensure the bucket exists."""
    global _client
    if _client is not None:
        return _client
    from minio import Minio

    # The minio SDK wants host:port (no scheme); boto3 (L2/L3) wants a full URL.
    # Prefer L1's own var, else strip the scheme off the shared MINIO_ENDPOINT.
    endpoint = os.environ.get("NEULEAP_MINIO_ENDPOINT") or os.environ.get(
        "MINIO_ENDPOINT", "minio:9000"
    )
    secure = endpoint.startswith("https://") or os.environ.get("MINIO_SECURE", "0") == "1"
    if "://" in endpoint:
        endpoint = endpoint.split("://", 1)[1]
    _client = Minio(
        endpoint,
        access_key=os.environ.get("MINIO_ACCESS_KEY", "minioadmin"),
        secret_key=os.environ.get("MINIO_SECRET_KEY", "minioadmin"),
        secure=secure,
    )
    if not _client.bucket_exists(bucket()):
        _client.make_bucket(bucket())
        log.info("created MinIO bucket %r", bucket())
    return _client


# --------------------------------------------------------------------------- #
# Key builders
# --------------------------------------------------------------------------- #

def temp_key(e_id: str, filename: str, *, is_link: bool = False) -> str:
    sub = "links/" if is_link else ""
    return f"temp/{e_id}/{sub}{Path(filename).name}"


def dated_key(e_id: str, received_date: str | None, filename: str) -> str:
    """raw/{YYYY}/{MM}/{DD}/{E_id}/filename."""
    dt = _parse_date(received_date)
    yyyy = f"{dt.year:04d}"
    return (
        f"{yyyy}/{_month_from(received_date)}/{_day_from(received_date)}/"
        f"{e_id}/{Path(filename).name}"
    )


# --------------------------------------------------------------------------- #
# Operations
# --------------------------------------------------------------------------- #

def put_file(local_path: str, key: str, content_type: str | None = None) -> str | None:
    """Upload a local file to ``bucket/key``. Returns ``s3://bucket/key`` or None."""
    if not is_enabled():
        return None
    return put_bytes(Path(local_path).read_bytes(), key, content_type)


def put_bytes(data: bytes, key: str, content_type: str | None = None) -> str | None:
    """Upload raw bytes to ``bucket/key``. Returns ``s3://bucket/key`` or None."""
    if not is_enabled():
        return None
    client = _get_client()
    client.put_object(
        bucket(), key, io.BytesIO(data), length=len(data),
        content_type=content_type or "application/octet-stream",
    )
    uri = f"s3://{bucket()}/{key}"
    log.info("minio put %s (%d bytes)", uri, len(data))
    return uri


def put_temp(local_path: str, e_id: str, *, is_link: bool = False) -> str | None:
    """Mirror a freshly-downloaded file into raw/temp/{E_id}/ (pre-validation)."""
    return put_file(local_path, temp_key(e_id, Path(local_path).name, is_link=is_link))


def put_final(local_path: str, e_id: str, received_date: str | None,
              stored_name: str) -> str | None:
    """Upload a validated file into raw/{YYYY}/{MM}/{DD}/{E_id}/."""
    return put_file(local_path, dated_key(e_id, received_date, stored_name))


# --------------------------------------------------------------------------- #
# Staging queue (MinIO is the only durable store for pending intake items)
#
# An incoming email is staged under raw/temp/{E_id}/ — its attachments plus a
# {E_id}.json manifest. The LangGraph pipeline lists/reads this queue from MinIO
# and downloads each item into an ephemeral local temp dir for processing. Once
# clean files are stored at raw/{YYYY}/{MM}/{DD}/{E_id}/, the temp/ staging entry
# is purged. No durable local filesystem is involved.
# --------------------------------------------------------------------------- #

def _require_enabled() -> None:
    if not is_enabled():
        raise RuntimeError(
            "MinIO is required for Layer 1 staging but is disabled "
            "(set NEULEAP_USE_MINIO=1 and the MINIO_* / NEULEAP_MINIO_ENDPOINT vars)."
        )


def staging_manifest_key(e_id: str) -> str:
    return f"temp/{e_id}/{e_id}.json"


def put_staging_file(e_id: str, filename: str, data: bytes) -> str:
    """Upload one staged attachment to raw/temp/{E_id}/{filename}."""
    _require_enabled()
    return put_bytes(data, temp_key(e_id, filename))  # type: ignore[return-value]


def put_staging_manifest(e_id: str, manifest: dict) -> str:
    """Write the {E_id}.json manifest into raw/temp/{E_id}/."""
    _require_enabled()
    import json
    return put_bytes(  # type: ignore[return-value]
        json.dumps(manifest, indent=2).encode("utf-8"),
        staging_manifest_key(e_id),
        content_type="application/json",
    )


def get_staging_manifest(e_id: str) -> dict | None:
    """Read and parse the staged {E_id}.json manifest, or None if absent."""
    if not is_enabled():
        return None
    import json
    client = _get_client()
    try:
        resp = client.get_object(bucket(), staging_manifest_key(e_id))
        try:
            return json.loads(resp.read().decode("utf-8"))
        finally:
            resp.close()
            resp.release_conn()
    except Exception as exc:  # noqa: BLE001 — missing object / parse failure
        log.warning("staging manifest read failed for %s: %s", e_id, exc)
        return None


def list_staged_eids() -> list[str]:
    """List E_ids that have a staged manifest under raw/temp/{E_id}/{E_id}.json."""
    if not is_enabled():
        return []
    client = _get_client()
    eids: list[str] = []
    for obj in client.list_objects(bucket(), prefix="temp/", recursive=True):
        name = obj.object_name  # e.g. temp/E100/E100.json
        parts = name.split("/")
        if len(parts) == 3 and parts[2] == f"{parts[1]}.json":
            eids.append(parts[1])
    return sorted(set(eids))


def download_staging(e_id: str, dest_dir: str) -> list[str]:
    """Download an item's staged attachments (not the manifest) into dest_dir.

    Returns the list of downloaded filenames. dest_dir is an ephemeral temp dir.
    """
    _require_enabled()
    client = _get_client()
    dest = Path(dest_dir)
    dest.mkdir(parents=True, exist_ok=True)
    manifest_name = f"{e_id}.json"
    names: list[str] = []
    for obj in client.list_objects(bucket(), prefix=f"temp/{e_id}/", recursive=True):
        key = obj.object_name
        base = Path(key).name
        # Skip the manifest and any nested link-download subkeys.
        if base == manifest_name or key.rstrip("/").endswith("/"):
            continue
        if key != f"temp/{e_id}/{base}":  # only top-level attachments
            continue
        resp = client.get_object(bucket(), key)
        try:
            (dest / base).write_bytes(resp.read())
        finally:
            resp.close()
            resp.release_conn()
        names.append(base)
    return sorted(names)


def purge_temp(e_id: str) -> int:
    """Delete every object under raw/temp/{E_id}/. Returns count removed."""
    if not is_enabled():
        return 0
    from minio.deleteobjects import DeleteObject

    client = _get_client()
    prefix = f"temp/{e_id}/"
    names = [o.object_name for o in client.list_objects(bucket(), prefix=prefix, recursive=True)]
    if not names:
        return 0
    errors = list(client.remove_objects(bucket(), (DeleteObject(n) for n in names)))
    for e in errors:
        log.warning("minio purge error: %s", e)
    log.info("minio purged temp/%s/ (%d objects)", e_id, len(names))
    return len(names)
