"""OCR helpers for scanned PDFs and image resumes (Tesseract + Poppler).

Both binaries ship in the app image (see Dockerfile: tesseract-ocr, poppler-utils).
Every function degrades gracefully: if a dependency or binary is missing, it
returns an empty string instead of raising, so a missing OCR stack never crashes
the pipeline — the caller decides what to do with empty text.
"""
from __future__ import annotations

import logging
from pathlib import Path

logger = logging.getLogger(__name__)

# Below this many characters of embedded text, a PDF is treated as scanned and
# sent through OCR. Matches the L3 engine's threshold so both layers agree.
OCR_TEXT_THRESHOLD = 200


def ocr_available() -> bool:
    try:
        import pytesseract  # noqa: F401
        from pdf2image import convert_from_path  # noqa: F401
    except ImportError:
        return False
    return True


def ocr_pdf(path: str | Path, dpi: int = 300, max_pages: int | None = None) -> str:
    """Rasterize a PDF and OCR its pages. Empty string on any failure.

    ``max_pages`` caps how many leading pages are OCR'd (e.g. ``1`` for first-page-only,
    used by L2 where the contact block on page 1 is enough for identity + dedup).
    """
    try:
        import pytesseract
        from pdf2image import convert_from_path
    except ImportError:
        logger.warning("OCR deps missing (pytesseract / pdf2image) — skipping PDF OCR")
        return ""
    try:
        last_page = max_pages if (max_pages and max_pages > 0) else None
        pages = convert_from_path(str(path), dpi=dpi, first_page=1, last_page=last_page)
        return "\n".join(pytesseract.image_to_string(page) for page in pages)
    except Exception as exc:  # noqa: BLE001 — OCR is best-effort
        logger.warning("PDF OCR failed for %s: %s", path, exc)
        return ""


def ocr_image(path: str | Path) -> str:
    """OCR a single image file. Empty string on any failure."""
    try:
        import pytesseract
        from PIL import Image
    except ImportError:
        logger.warning("OCR deps missing (pytesseract / Pillow) — skipping image OCR")
        return ""
    try:
        with Image.open(str(path)) as image:
            return pytesseract.image_to_string(image)
    except Exception as exc:  # noqa: BLE001
        logger.warning("image OCR failed for %s: %s", path, exc)
        return ""
