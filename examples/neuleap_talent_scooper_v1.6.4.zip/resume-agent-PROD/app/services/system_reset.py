"""Full-database reset — Mailbox "System Cleanup" section, QA use only.

Wipes every table holding candidate/pipeline DATA (email/candidate/round
history, both archive tables, audit log, review queue, notifications) so a QA
environment can reload fresh test data. Deliberately preserves:
  * app_users        — login accounts; wiping them would lock everyone out.
  * every settings/*.json file under secrets/ (source tags, column config,
    pipeline/scoring/notification config, …) — configuration, not data.

Triple-gated given how destructive this is:
  1. settings.app_env must be a non-empty value that isn't a production alias
     ("production"/"prod"/"prd") — checked here AND at the route — belt and
     braces, since this function is also the one thing standing between a
     stray call and a production database. Any other truthy label (qa, dev,
     staging, test, uat, …) enables it; unset/blank never does.
  2. Admin role only (enforced at the route via require_admin).
  3. The caller must submit the exact configured Postgres database name as a
     typed confirmation phrase (mirrors GitHub's "type the repo name to
     confirm" pattern) — see `wipe()`'s `confirm` parameter. This is
     deliberately not a random/session-bound token: it needs no server-side
     state, and typing the real database name is itself a moment of pause
     that a generic "yes/DELETE" button doesn't provide.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from app.config import settings
from app.db import get_conn
from app.logging_config import get_logger
from app.services.s3 import s3

log = get_logger(__name__)

# Any of these (case-insensitive) disables the wipe, same as an unset/blank
# app_env — every other non-empty label (qa, dev, staging, uat, test, …)
# enables it. Deny-list rather than an allow-list of just "qa" so a QA stack
# relabeled "staging" or "uat" doesn't need a code change to keep working.
_PRODUCTION_ALIASES = {"production", "prod", "prd"}

# Every table holding candidate/pipeline/interview DATA — NOT the config or
# account tables (app_users login accounts, llm_api_config, mailbox_account_config
# all survive a reset; they're settings, not candidate data). Truncated together
# with CASCADE so foreign keys across the set (rounds->candidate_master,
# interview_pool_slots->interview_pools, the slot/session/OTP tables) are all
# satisfied regardless of order. CASCADE only reaches tables that reference the
# truncated set — the surviving config/account tables have no FK INTO these, so
# they are never touched.
_DATA_TABLES = [
    # Candidate + pipeline
    "rounds_archive",
    "rounds",
    "candidate_master_archive",
    "candidate_master",
    "email_master_archive",
    "email_master",
    "candidate_email_dupes_archive",
    "rounds_email_dupes_archive",
    "email_drafts",
    "review_queue",
    "audit_log",
    "notifications",
    # Interview scheduling — invites/bookings, pools, and the code/session
    # tables. Missing before: a wiped environment kept its slot bookings, so
    # the candidate slot-picker still showed "Your interview is booked".
    "round_slot_invites",
    "candidate_slot_sessions",
    "candidate_slot_otp",
    "interview_pool_slots",
    "interview_pools",
    "interviewer_links",
    "interviewer_sessions",
    "interviewer_otp",
    "pool_interviewer_sessions",
    "pool_interviewer_otp",
    # LLM token-usage ledger (Admin → Token Usage) — campaign metering data.
    "llm_token_usage",
]

# File-based CAMPAIGN data that lives in secrets/ (not the DB) — reset alongside
# the DB wipe so a cleanup gives a truly fresh campaign slate, not one still
# carrying the previous deployment's source tags. Pure SETTINGS files
# (templates, scheduling, scoring, columns, mailbox/LLM keys) are deliberately
# NOT reset — those are configuration a fresh environment keeps.
_CAMPAIGN_FILES = ["source_tags.json"]


class WipeNotAllowed(Exception):
    """Raised when a wipe is attempted outside a QA environment."""


def is_wipe_allowed() -> bool:
    env = settings.app_env.strip().lower()
    return bool(env) and env not in _PRODUCTION_ALIASES


def required_confirmation() -> str:
    """The exact phrase the caller must type — the configured database name,
    so it's obviously environment-specific and not something copy-pasteable
    out of documentation without thinking about which database it hits."""
    return settings.pg_database


def wipe(confirm: str, *, clear_object_store: bool = True) -> dict[str, Any]:
    """Truncate every data table and reset the E-id/candidate-id sequences.

    Raises WipeNotAllowed outside QA, or ValueError if `confirm` doesn't
    exactly match required_confirmation() — the API route maps both to a 4xx.
    """
    if not is_wipe_allowed():
        raise WipeNotAllowed(
            f"System wipe is disabled in this environment (APP_ENV={settings.app_env!r})."
        )
    if confirm != required_confirmation():
        raise ValueError("Confirmation phrase did not match — nothing was wiped.")

    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(f"TRUNCATE TABLE {', '.join(_DATA_TABLES)} RESTART IDENTITY CASCADE;")
            # eid_seq/candidate_seq back their TEXT ids (E100, C1001, …) generated
            # in application code, not a TRUNCATE-owned identity column — reset
            # them explicitly to the same starting points as a fresh database.
            cur.execute("ALTER SEQUENCE eid_seq RESTART WITH 100;")
            cur.execute("ALTER SEQUENCE candidate_seq RESTART WITH 1001;")

    # File-based campaign data (source tags) lives outside the DB in secrets/ —
    # clear it too so a wiped environment doesn't keep the previous deployment's
    # tags. source_tags reads the file fresh on each call, so removing the file
    # is enough (its next read returns the empty default).
    cleared_files = 0
    secrets_dir = Path(os.environ.get("SECRETS_DIR", "secrets"))
    for fname in _CAMPAIGN_FILES:
        try:
            fpath = secrets_dir / fname
            if fpath.exists():
                fpath.unlink()
                cleared_files += 1
        except OSError as exc:  # noqa: BLE001 — best-effort; DB wipe already committed
            log.warning("system_reset: could not clear campaign file %s: %s", fname, exc)

    cleared_objects = 0
    if clear_object_store:
        for raw in (True, False):
            bucket = "raw" if raw else "resume"
            try:
                for key in s3().list_keys("", raw=raw):
                    s3().delete(key, raw=raw)
                    cleared_objects += 1
            except Exception as exc:  # noqa: BLE001 — best-effort; the DB wipe already committed
                log.warning("system_reset: could not clear %s bucket: %s", bucket, exc)

    log.warning(
        "system_reset: FULL WIPE executed (app_env=%s) — %d tables truncated, "
        "%d object-store files removed",
        settings.app_env, len(_DATA_TABLES), cleared_objects,
    )
    return {
        "wiped": True,
        "tables_truncated": len(_DATA_TABLES),
        "object_store_files_removed": cleared_objects,
        "campaign_files_cleared": cleared_files,
    }
