"""Interviewer email-code challenge + "remember this device" sessions.

Flow: an interviewer opens a candidate's interview link (see
app.services.interviewer_link) → types their email → request_code() mails a
6-character code (XXX-XXX, A-Z + 0-9) if the domain is allow-listed →
verify_code() checks it and, if they opted to be remembered, mints a session
token the browser stores in localStorage (this app has no cookie/CORS-
credentials setup — see app.main CORS config) and sends back on later visits
via the X-Interviewer-Session header, so validate_session() can skip the
challenge next time.

Every check re-reads the domain allow-list at ACCESS time, not just at
request/verify time — so revoking a domain in Settings invalidates its
already-remembered sessions immediately (see invalidate_domain_sessions and
validate_session's own domain re-check), not just future code requests.
"""
from __future__ import annotations

import random
import string
import uuid
from datetime import datetime, timedelta, timezone

import hashlib

from app.db import get_conn
from app.logging_config import get_logger
from app.services import graph_client, interviewer_domains

log = get_logger(__name__)

_CODE_TTL_MINUTES = 10
_ALPHABET = string.ascii_uppercase + string.digits  # no lowercase — easy to read/type back


class DomainNotAllowed(Exception):
    """The email's domain isn't on the allow-list — request_code() refuses to
    send a code at all (avoids spamming/probing arbitrary inboxes)."""


class InvalidCode(Exception):
    """The submitted code is wrong, expired, or already used."""


def _gen_code() -> str:
    raw = "".join(random.choices(_ALPHABET, k=6))
    return f"{raw[:3]}-{raw[3:]}"


def _digest(value: str) -> str:
    """Codes and session tokens are stored as SHA-256 digests, never plaintext
    — a DB leak must not hand out live credentials. Both are high-entropy and
    short-lived, so an unsalted fast hash is appropriate here (unlike user
    passwords, which use salted PBKDF2 in app.services.users)."""
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def request_code(email: str, candidate_id: str | None) -> None:
    email = email.strip().lower()
    if not interviewer_domains.is_email_allowed(email):
        raise DomainNotAllowed(f"{email.split('@')[-1] if '@' in email else email} isn't an approved domain.")

    code = _gen_code()
    expires_at = datetime.now(timezone.utc) + timedelta(minutes=_CODE_TTL_MINUTES)
    with get_conn() as conn:
        with conn.cursor() as cur:
            # Burn any still-live codes for this email first — only the newest
            # one should ever be valid, so a stale earlier email can't be used.
            cur.execute(
                "UPDATE interviewer_otp SET consumed_at = CURRENT_TIMESTAMP "
                "WHERE email = %s AND consumed_at IS NULL",
                (email,),
            )
            cur.execute(
                "INSERT INTO interviewer_otp (email, code, candidate_id, expires_at) "
                "VALUES (%s, %s, %s, %s)",
                (email, _digest(code), candidate_id, expires_at),
            )

    result = graph_client.send_mail(
        email,
        "Your NeuLeap access code",
        "<p>Your access code is:</p>"
        f"<p style=\"text-align:center;\"><strong style=\"font-size:24px; letter-spacing:3px;\">{code}</strong></p>"
        f"<p>It expires in {_CODE_TTL_MINUTES} minutes. If you didn't request this, ignore this email.</p>",
    )
    if not result["sent"]:
        # Don't fail the request over a delivery hiccup the interviewer can't fix —
        # log it loudly for an admin to notice/investigate instead.
        log.warning("interviewer_auth: code email to %s not sent: %s", email, result.get("error"))


_UNREMEMBERED_SESSION_HOURS = 12


def verify_code(email: str, code: str, *, remember: bool) -> str:
    """Always returns a session token — every subsequent call in this feature
    (resume, questions, feedback) authenticates via this token, so one must
    exist regardless of "remember". ``remember`` only controls how long the
    token stays valid (and whether the BROWSER persists it to localStorage
    for future visits, decided client-side) — an unremembered session still
    lives long enough to finish the current visit, it just isn't kept past
    it. Raises InvalidCode."""
    email = email.strip().lower()
    code = code.strip().upper()
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT id FROM interviewer_otp WHERE email = %s AND code = %s "
                "AND consumed_at IS NULL AND expires_at > CURRENT_TIMESTAMP",
                (email, _digest(code)),
            )
            row = cur.fetchone()
            if not row:
                raise InvalidCode("That code is incorrect or has expired.")
            cur.execute(
                "UPDATE interviewer_otp SET consumed_at = CURRENT_TIMESTAMP WHERE id = %s",
                (row[0],),
            )
            token = uuid.uuid4().hex
            expires_at = datetime.now(timezone.utc) + (
                timedelta(days=interviewer_domains.remember_days())
                if remember
                else timedelta(hours=_UNREMEMBERED_SESSION_HOURS)
            )
            cur.execute(
                "INSERT INTO interviewer_sessions (session_token, email, expires_at) "
                "VALUES (%s, %s, %s)",
                (_digest(token), email, expires_at),
            )
    return token


def validate_session(token: str | None) -> str | None:
    """The remembered email, or None if there's no session, it expired, or its
    domain is no longer allowed (a domain revoke takes effect immediately even
    for sessions minted before the revoke)."""
    if not token:
        return None
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT email FROM interviewer_sessions "
                "WHERE session_token = %s AND expires_at > CURRENT_TIMESTAMP",
                (_digest(token),),
            )
            row = cur.fetchone()
    if not row:
        return None
    email = row[0]
    return email if interviewer_domains.is_email_allowed(email) else None


def invalidate_domain_sessions(domain: str) -> int:
    """Forces every remembered device for `domain` to redo the code challenge
    — Settings → Interviewer Access → "Revoke sessions"."""
    domain = domain.strip().lower().lstrip("@")
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "DELETE FROM interviewer_sessions WHERE lower(split_part(email, '@', 2)) = %s",
                (domain,),
            )
            return cur.rowcount
