"""Scoring configuration — ATS priority bands + stream-classification keywords.

Backs the Settings page's "ATS Scoring Bands" and "Stream Definitions" sections.
Like :mod:`app.services.pipeline_config`, values live in an ``.env``-style file in
the bind-mounted ``secrets/`` directory and are mirrored into ``os.environ`` so the
rest of the app reads them at use-time (a Save applies on the next extraction, no
restart needed).

  * ATS bands   → :func:`priority_for` maps a 0–100 atsscore to its P-band; L3 uses
                  this when deriving ``priority`` (replaces the hardcoded 85/70/55).
  * Stream keywords → :func:`prompt_hint` is appended to the L3 master prompt as
                  stream-classification signals.

File (default ``secrets/scoring.env``, override with ``SCORING_CONFIG_FILE``)::

    ATS_P1_MIN=85
    ATS_P2_MIN=70
    ATS_P3_MIN=55
    STREAM_KW_GENAI=LLM,GPT,RAG,machine learning,PyTorch,...
    STREAM_KW_DATA_ENG=Spark,Kafka,Airflow,...
    STREAM_KW_NOT_RELEVANT=
    ATS_W_LLM_FIT=0.40   # deterministic-formula component weights
    ATS_CERT_BONUS_MAX=10.0
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from app.logging_config import get_logger

log = get_logger(__name__)

# Must stay in sync with engine.STREAM_VALUES and the Settings page. Two real hiring
# tracks (GenAI, Data Eng) plus the catch-all. AI-ML was merged into GenAI, so ML/DL/
# CV/NLP/data-science signals now live under the GenAI track.
_STREAMS = ("GenAI", "Data Eng", "Not Relevant")

# Defaults mirror the previously-hardcoded behaviour. GenAI absorbs the former AI-ML
# keywords so machine/deep-learning resumes still match a real track.
_DEFAULT_BANDS = {"P1": 85.0, "P2": 70.0, "P3": 55.0}
_DEFAULT_KEYWORDS: dict[str, list[str]] = {
    "GenAI": [
        "LLM", "GPT", "RAG", "LangChain", "fine-tune", "prompt", "generative", "agentic", "AutoGen",
        "machine learning", "deep learning", "PyTorch", "TensorFlow", "scikit-learn",
        "neural network", "classification", "computer vision", "NLP", "data science",
    ],
    "Data Eng": ["Spark", "Kafka", "Airflow", "dbt", "ETL", "pipeline", "Snowflake", "Redshift", "BigQuery"],
    "Not Relevant": [],
}

# Deterministic ATS scoring formula — relative component weights (normalized at
# use-time) and absolute params (points / targets). Recruiter-tunable via the env file.
# Mirrors app.services.ats_scoring.DEFAULT_WEIGHTS / DEFAULT_PARAMS.
_DEFAULT_WEIGHTS = {
    "llm_fit": 0.30,
    "skills": 0.15,
    "experience": 0.35,
    "education": 0.10,
    "format": 0.10,
}
_DEFAULT_PARAMS = {
    "cert_bonus_per": 4.0,
    "cert_bonus_max": 10.0,
    "exp_target_years": 5.0,
    "skills_match_target": 4.0,
    "penalty_offtrack": 15.0,
    "penalty_missing_contact": 5.0,
    # Career-gap penalty — a SEPARATE ATS signal from experience. Opt-in: 0.0 keeps
    # existing scores unchanged. When > 0 and gap_months exceeds the threshold, the
    # penalty is deducted WITHOUT touching the experience subscore.
    "penalty_long_gap": 0.0,
    "gap_penalty_threshold_months": 12.0,
}

# Career-gap / experience timeline computation (app.services.timeline). Independent of
# the ATS formula above; tunable without code change. Flags are read as truthy (>0).
_DEFAULT_TIMELINE = {
    # 1 ⇒ education activities take part in gap detection, so the education-end →
    # first-job/internship break counts as a career gap (and study-time is covered,
    # never itself a gap). 0 ⇒ education ignored for gaps entirely.
    "gap_include_education": 1.0,
    # 1 ⇒ internships count toward experience. 0 ⇒ only professional roles do.
    "experience_include_internships": 0.0,
    # A break is only reported as a gap when it is at least this many months.
    "gap_min_months": 3.0,
    # A continuous-employment run qualifies as experience only when STRICTLY longer than
    # this many months. 0 ⇒ every dated company/role counts (no minimum-tenure floor).
    "qualifying_min_months": 0.0,
}
_TIMELINE_ENV = {k: "TIMELINE_" + k.upper() for k in _DEFAULT_TIMELINE}
# env key suffix per weight/param, e.g. ATS_W_LLM_FIT, ATS_CERT_BONUS_PER.
_WEIGHT_ENV = {k: "ATS_W_" + k.upper() for k in _DEFAULT_WEIGHTS}
_PARAM_ENV = {k: "ATS_" + k.upper() for k in _DEFAULT_PARAMS}

# Certificate filter tags — the checkboxes shown in the Resume Library cert filter.
# Recruiter-editable on the Settings page; client-side filtering only (no scoring use).
_DEFAULT_CERT_TAGS = ["AWS", "Google", "Microsoft", "Databricks", "Snowflake", "Coursera"]


def _stream_env(name: str) -> str:
    """Stream display name → env-safe key (e.g. 'Data Eng' → 'STREAM_KW_DATA_ENG')."""
    return "STREAM_KW_" + name.upper().replace("-", "_").replace(" ", "_")


def _path() -> Path:
    return Path(os.environ.get("SCORING_CONFIG_FILE", "secrets/scoring.env"))


# ── typed accessors used by the backend at run-time ─────────────────────────────

def ats_bands() -> dict[str, float]:
    out: dict[str, float] = {}
    for band, dflt in _DEFAULT_BANDS.items():
        try:
            out[band] = float(os.environ.get(f"ATS_{band}_MIN", dflt))
        except (TypeError, ValueError):
            out[band] = dflt
    return out


def stream_keywords() -> dict[str, list[str]]:
    out: dict[str, list[str]] = {}
    for name in _STREAMS:
        raw = os.environ.get(_stream_env(name))
        if raw is None:
            out[name] = list(_DEFAULT_KEYWORDS[name])
        else:
            out[name] = [k.strip() for k in raw.split(",") if k.strip()]
    return out


def cert_tags() -> list[str]:
    """Recruiter-editable certificate filter tags (Resume Library checkboxes)."""
    raw = os.environ.get("CERT_FILTER_TAGS")
    if raw is None:
        return list(_DEFAULT_CERT_TAGS)
    return [t.strip() for t in raw.split(",") if t.strip()]


def _float_env(key: str, default: float) -> float:
    try:
        return float(os.environ.get(key, default))
    except (TypeError, ValueError):
        return default


def scoring_weights() -> dict[str, float]:
    """Relative component weights for the deterministic ATS formula (ats_scoring)."""
    return {k: _float_env(_WEIGHT_ENV[k], dflt) for k, dflt in _DEFAULT_WEIGHTS.items()}


def scoring_params() -> dict[str, float]:
    """Absolute params (cert bonus, targets, penalties) for the ATS formula."""
    return {k: _float_env(_PARAM_ENV[k], dflt) for k, dflt in _DEFAULT_PARAMS.items()}


def timeline_config() -> dict[str, float]:
    """Gap / experience computation knobs for :mod:`app.services.timeline`.

    Env-backed (TIMELINE_*), with defaults: education counts toward gaps, internships
    excluded from experience, 3-month gap floor, >6-month qualifying-role rule.
    """
    return {k: _float_env(_TIMELINE_ENV[k], dflt) for k, dflt in _DEFAULT_TIMELINE.items()}


def priority_for(score: float) -> str:
    """Map a 0–100 atsscore to its configurable P-band (descending thresholds)."""
    b = ats_bands()
    if score >= b["P1"]:
        return "P1"
    if score >= b["P2"]:
        return "P2"
    if score >= b["P3"]:
        return "P3"
    return "P4"


def prompt_hint() -> str:
    """Stream-classification hints appended to the L3 master prompt (empty if none)."""
    kws = stream_keywords()
    lines = [f"- {name}: {', '.join(words)}" for name, words in kws.items() if words]
    if not lines:
        return ""
    return (
        "\n\nStream classification hints — signals typical of each stream (use "
        "judgement; these are indicative, not exhaustive, and must not override "
        "clear evidence):\n" + "\n".join(lines)
    )


# ── persistence ─────────────────────────────────────────────────────────────────

def load() -> None:
    """Load the env file into ``os.environ`` (startup + reload). Never raises."""
    path = _path()
    try:
        if not path.exists():
            return
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, val = line.partition("=")
            os.environ[key.strip()] = val.strip()
        log.info("scoring_config: loaded %s", path)
    except OSError as exc:  # noqa: BLE001
        log.warning("scoring_config: could not load %s: %s", path, exc)


def get() -> dict[str, Any]:
    """Current scoring settings in the shape the Settings page renders."""
    return {
        "ats_bands": ats_bands(),
        "stream_keywords": stream_keywords(),
        "cert_tags": cert_tags(),
        "scoring_weights": scoring_weights(),
        "scoring_params": scoring_params(),
        "timeline_config": timeline_config(),
    }


def save(settings: dict[str, Any]) -> dict[str, Any]:
    """Persist ATS bands + stream keywords to the env file + ``os.environ``."""
    bands = settings.get("ats_bands") or {}
    for band in _DEFAULT_BANDS:
        if band in bands:
            try:
                os.environ[f"ATS_{band}_MIN"] = str(float(bands[band]))
            except (TypeError, ValueError):
                pass

    kws = settings.get("stream_keywords")
    if isinstance(kws, dict):
        for name in _STREAMS:
            words = kws.get(name)
            if isinstance(words, list):
                cleaned = [str(k).strip() for k in words if str(k).strip()]
                os.environ[_stream_env(name)] = ",".join(cleaned)

    tags = settings.get("cert_tags")
    if isinstance(tags, list):
        os.environ["CERT_FILTER_TAGS"] = ",".join(
            str(t).strip() for t in tags if str(t).strip()
        )

    weights = settings.get("scoring_weights")
    if isinstance(weights, dict):
        for key in _DEFAULT_WEIGHTS:
            if key in weights:
                try:
                    os.environ[_WEIGHT_ENV[key]] = str(float(weights[key]))
                except (TypeError, ValueError):
                    pass

    params = settings.get("scoring_params")
    if isinstance(params, dict):
        for key in _DEFAULT_PARAMS:
            if key in params:
                try:
                    os.environ[_PARAM_ENV[key]] = str(float(params[key]))
                except (TypeError, ValueError):
                    pass

    tcfg = settings.get("timeline_config")
    if isinstance(tcfg, dict):
        for key in _DEFAULT_TIMELINE:
            if key in tcfg:
                try:
                    os.environ[_TIMELINE_ENV[key]] = str(float(tcfg[key]))
                except (TypeError, ValueError):
                    pass

    path = _path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        b, kw = ats_bands(), stream_keywords()
        sw, sp = scoring_weights(), scoring_params()
        tc = timeline_config()
        lines = ["# NeuLeap scoring configuration (managed by the Settings page)."]
        lines += [f"ATS_{band}_MIN={b[band]}" for band in _DEFAULT_BANDS]
        lines += [f"{_stream_env(name)}={','.join(kw[name])}" for name in _STREAMS]
        lines.append(f"CERT_FILTER_TAGS={','.join(cert_tags())}")
        lines.append("# Deterministic ATS scoring formula (ats_scoring).")
        lines += [f"{_WEIGHT_ENV[k]}={sw[k]}" for k in _DEFAULT_WEIGHTS]
        lines += [f"{_PARAM_ENV[k]}={sp[k]}" for k in _DEFAULT_PARAMS]
        lines.append("# Career-gap / experience timeline computation (timeline.py).")
        lines += [f"{_TIMELINE_ENV[k]}={tc[k]}" for k in _DEFAULT_TIMELINE]
        lines.append("")
        path.write_text("\n".join(lines), encoding="utf-8")
        log.info("scoring_config: saved %s", path)
    except OSError as exc:  # noqa: BLE001
        log.warning("scoring_config: could not write %s: %s", path, exc)
    return get()
