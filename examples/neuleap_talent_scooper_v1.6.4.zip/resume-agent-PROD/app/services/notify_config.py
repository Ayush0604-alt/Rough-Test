"""Notification settings — persisted to a small env file (no database).

The recipient address and the per-event toggles the Settings page edits live in an
``.env``-style file inside the bind-mounted ``secrets/`` directory (so they survive
container restarts without a DB). Values are also mirrored into ``os.environ`` so the
rest of the app can read them with a plain ``os.environ.get``.

File (default ``secrets/notifications.env``, override with ``NOTIFY_CONFIG_FILE``)::

    NOTIFY_EMAIL=hr@neuleap.ai
    NOTIFY_RUN_SUMMARY=1
    NOTIFY_MANUAL_REVIEW=1
    NOTIFY_EXHAUSTED=1
    NOTIFY_NEW_P1=1
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from app.logging_config import get_logger

log = get_logger(__name__)

# Logical setting key -> (env var, kind). "bool" persists as 1/0; "str" verbatim.
_FIELDS: dict[str, tuple[str, str]] = {
    "email": ("NOTIFY_EMAIL", "str"),
    "run_summary": ("NOTIFY_RUN_SUMMARY", "bool"),
    "manual_review": ("NOTIFY_MANUAL_REVIEW", "bool"),
    "exhausted": ("NOTIFY_EXHAUSTED", "bool"),
    "new_p1": ("NOTIFY_NEW_P1", "bool"),
}
_BOOL_DEFAULTS = {"run_summary": True, "manual_review": True, "exhausted": True, "new_p1": True}


def _path() -> Path:
    return Path(os.environ.get("NOTIFY_CONFIG_FILE", "secrets/notifications.env"))


def _truthy(value: str | None) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes", "on"}


def load() -> None:
    """Load the env file into ``os.environ`` (call once at startup). Never raises."""
    path = _path()
    try:
        if not path.exists():
            return
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, val = line.partition("=")
            # UI-managed keys override .env/docker-compose so a saved value wins.
            os.environ[key.strip()] = val.strip()
        log.info("notify_config: loaded %s", path)
    except OSError as exc:  # noqa: BLE001 — missing/locked file must not block startup
        log.warning("notify_config: could not load %s: %s", path, exc)


def get() -> dict[str, Any]:
    """Current notification settings as a JSON-friendly dict."""
    out: dict[str, Any] = {}
    for key, (env, kind) in _FIELDS.items():
        raw = os.environ.get(env)
        if kind == "bool":
            out[key] = _truthy(raw) if raw is not None else _BOOL_DEFAULTS[key]
        else:
            out[key] = (raw or "").strip() or None
    return out


def save(settings: dict[str, Any]) -> dict[str, Any]:
    """Persist settings to the env file and mirror into ``os.environ``. Returns get()."""
    for key, (env, kind) in _FIELDS.items():
        if key not in settings:
            continue
        if kind == "bool":
            os.environ[env] = "1" if settings.get(key) else "0"
        else:
            os.environ[env] = str(settings.get(key) or "").strip()

    path = _path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        lines = [
            "# NeuLeap notification settings (managed by the Settings page).",
            *(f"{env}={os.environ.get(env, '')}" for env, _ in _FIELDS.values()),
            "",
        ]
        path.write_text("\n".join(lines), encoding="utf-8")
        log.info("notify_config: saved %s", path)
    except OSError as exc:  # noqa: BLE001 — a write failure must not 500 the request
        log.warning("notify_config: could not write %s: %s", path, exc)
    return get()


def recipient() -> str | None:
    """The notification recipient address, or None if unset."""
    return (os.environ.get("NOTIFY_EMAIL") or "").strip() or None
