"""Shared audit ledger (D11) — one Postgres ``audit_log`` table for all layers.

L1's flat-file ledger is promoted here: every stage (L1/L2/L3) and the per-run
batch row land in the same table, queryable by ``batch_id``. ``fail_count`` is
cumulative per E_id and drives the retry-exhaustion gate (default threshold 3).

All writes are best-effort — auditing must never break the pipeline.
"""
from __future__ import annotations

import logging
from typing import Any, Optional

logger = logging.getLogger(__name__)

EXHAUSTION_THRESHOLD = 3  # default; runtime value comes from MAX_RETRIES (Settings)
_FAIL_STATUSES = {"Failed", "Retry"}


def _exhaustion_threshold() -> int:
    """Retry budget per e_id — env MAX_RETRIES (Settings page), default 3."""
    import os

    try:
        return max(1, int(float(os.environ.get("MAX_RETRIES", EXHAUSTION_THRESHOLD))))
    except (TypeError, ValueError):
        return EXHAUSTION_THRESHOLD


def _conn():
    from app.db import get_conn
    return get_conn()


def prior_fail_count(e_id: Optional[str]) -> int:
    """Cumulative fail/retry count for this E_id across the whole ledger."""
    if not e_id:
        return 0
    try:
        with _conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT COUNT(*) FROM audit_log "
                    "WHERE e_id = %s AND status IN ('Failed', 'Retry')",
                    (e_id,),
                )
                return int(cur.fetchone()[0])
    except Exception as exc:  # noqa: BLE001
        logger.warning("audit prior_fail_count(%s) failed: %s", e_id, exc)
        return 0


def is_exhausted(e_id: Optional[str], threshold: Optional[int] = None) -> bool:
    """True when this E_id has failed >= threshold times (poison-mail gate).

    ``threshold`` defaults to the runtime MAX_RETRIES (Settings page), not the constant.
    """
    if threshold is None:
        threshold = _exhaustion_threshold()
    return prior_fail_count(e_id) >= threshold


def write_event(
    *,
    batch_id: Optional[str] = None,
    run_id: Optional[str] = None,
    e_id: Optional[str] = None,
    candidate_id: Optional[str] = None,
    layer: str,
    step: str = "",
    status: str = "Info",
    fail_reason: str = "",
    stage: Optional[str] = None,
    draft_id: Optional[int] = None,
) -> None:
    """Append one ledger row. ``fail_count`` is cumulative per E_id.

    ``run_id`` is accepted for back-compat but the audit_log.run_id column was
    dropped (it always equalled batch_id in L1); it is folded into ``batch_id``.

    ``stage`` is the candidate's pipeline/round bucket (app.stages.BUCKET_ORDER —
    New/Screening/Round 1/Round 2/Final/Hired/Reject/Closed) this event belongs to;
    recruiter (L4) call sites pass it via app.stages.candidate_stage_bucket(). Pipeline
    (L1-L3) rows leave it unset — the SPA groups those under "New" (no round exists yet).

    ``draft_id`` links an email-lifecycle event (generated/marked ready/sent) to
    the exact email_drafts row it's about, so the Actions Audit Log can offer a
    "view email" button that opens that specific draft.
    """
    batch_id = batch_id or run_id
    base = prior_fail_count(e_id) if e_id else 0
    fail_count = base + 1 if status in _FAIL_STATUSES else base
    try:
        with _conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """INSERT INTO audit_log
                       (batch_id, e_id, candidate_id, layer, step,
                        fail_reason, status, fail_count, stage, draft_id)
                       VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
                    (batch_id, e_id, candidate_id, layer, step,
                     fail_reason or None, status, fail_count, stage, draft_id),
                )
    except Exception as exc:  # noqa: BLE001
        logger.warning("audit write_event(%s/%s) failed: %s", e_id, status, exc)


def last_run_summary() -> Optional[dict]:
    """The most recent batch run, reconstructed from the audit ledger.

    Returns batch id, when it started/finished, how many mails it covered, and how
    many downstream (L2/L3) steps succeeded vs failed — so the Pipeline page can show
    the last run even after a reload (no separate run-history table needed).
    """
    try:
        with _conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT batch_id, fail_count, created_at FROM audit_log "
                    "WHERE layer = 'BATCH' AND step = 'run' "
                    "ORDER BY log_id DESC LIMIT 1"
                )
                row = cur.fetchone()
                if not row:
                    return None
                batch_id, mail_count, started_at = row

                # Per-file outcome lives on L2 (one row per resume + the
                # exhaustion gate). Counting L2 only keeps "processed"/"failed"
                # accurate now that L3 also writes Success rows for parsing.
                cur.execute(
                    "SELECT status, COUNT(*) FROM audit_log "
                    "WHERE batch_id = %s AND layer = 'L2' GROUP BY status",
                    (batch_id,),
                )
                counts = {s: int(n) for s, n in cur.fetchall()}

                cur.execute(
                    "SELECT MAX(created_at) FROM audit_log WHERE batch_id = %s",
                    (batch_id,),
                )
                finished_at = cur.fetchone()[0]

        processed = counts.get("Success", 0)
        failed = counts.get("Failed", 0) + counts.get("Exhausted", 0)
        return {
            "batch_id": batch_id,
            "mail_count": int(mail_count or 0),
            "processed": processed,
            "failed": failed,
            "started_at": started_at.isoformat() if started_at else None,
            "finished_at": finished_at.isoformat() if finished_at else None,
        }
    except Exception as exc:  # noqa: BLE001
        logger.warning("audit last_run_summary failed: %s", exc)
        return None


def list_batches(limit: int = 100) -> list[dict]:
    """Every batch run (newest first), reconstructed from the audit ledger.

    One summary per BATCH/run row: mail count, downstream processed/failed step
    counts, distinct candidates generated, and start/finish timestamps. Powers
    the Pipeline page's batch history without a dedicated run-history table.
    """
    try:
        with _conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT batch_id, fail_count, created_at FROM audit_log "
                    "WHERE layer = 'BATCH' AND step = 'run' "
                    "ORDER BY log_id DESC LIMIT %s",
                    (limit,),
                )
                rows = cur.fetchall()
                if not rows:
                    return []
                batch_ids = [r[0] for r in rows]

                # L2 only — per-file outcome + exhaustion gate. (L3 now writes
                # Success rows for parsing; counting it here would double the
                # "processed" tally.)
                cur.execute(
                    "SELECT batch_id, status, COUNT(*) FROM audit_log "
                    "WHERE batch_id = ANY(%s) AND layer = 'L2' "
                    "GROUP BY batch_id, status",
                    (batch_ids,),
                )
                counts: dict[str, dict[str, int]] = {}
                for bid, st, n in cur.fetchall():
                    counts.setdefault(bid, {})[st] = int(n)

                cur.execute(
                    "SELECT batch_id, MAX(created_at) FROM audit_log "
                    "WHERE batch_id = ANY(%s) GROUP BY batch_id",
                    (batch_ids,),
                )
                finished = dict(cur.fetchall())

                cur.execute(
                    "SELECT batch_id, COUNT(DISTINCT candidate_id) FROM audit_log "
                    "WHERE batch_id = ANY(%s) AND candidate_id IS NOT NULL "
                    "GROUP BY batch_id",
                    (batch_ids,),
                )
                cand_counts = {bid: int(n) for bid, n in cur.fetchall()}
    except Exception as exc:  # noqa: BLE001
        logger.warning("audit list_batches failed: %s", exc)
        return []

    out: list[dict] = []
    for batch_id, mail_count, started_at in rows:
        c = counts.get(batch_id, {})
        fin = finished.get(batch_id)
        out.append({
            "batch_id": batch_id,
            "mail_count": int(mail_count or 0),
            "processed": c.get("Success", 0),
            "failed": c.get("Failed", 0) + c.get("Exhausted", 0),
            "candidates": cand_counts.get(batch_id, 0),
            "started_at": started_at.isoformat() if started_at else None,
            "finished_at": fin.isoformat() if fin else None,
        })
    return out


def batch_failures(batch_id: str, limit: int = 500) -> list[dict]:
    """Every per-file L2/L3 failure in a batch — which resume failed and why.

    One row per failed/exhausted file (newest first), carrying the source e_id, the
    candidate_id (if one was assigned before the failure), the offending filename +
    reason (folded into ``reason``), and when it happened. Powers the Pipeline page's
    "which 17 failed?" drill-down without a dedicated table.
    """
    try:
        with _conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT e_id, candidate_id, layer, fail_reason, status, created_at "
                    "FROM audit_log "
                    "WHERE batch_id = %s AND layer IN ('L2', 'L3') "
                    "AND status IN ('Failed', 'Exhausted') "
                    "ORDER BY log_id DESC LIMIT %s",
                    (batch_id, limit),
                )
                rows = cur.fetchall()
    except Exception as exc:  # noqa: BLE001
        logger.warning("audit batch_failures(%s) failed: %s", batch_id, exc)
        return []

    return [
        {
            "e_id": r[0],
            "candidate_id": r[1],
            "layer": r[2],
            "reason": r[3] or r[4],
            "status": r[4],
            "created_at": r[5].isoformat() if hasattr(r[5], "isoformat") else r[5],
        }
        for r in rows
    ]


def write_batch_row(batch_id: str, mail_count: int) -> None:
    """One row per run: batch id + how many mails L1 produced (fail_count=count)."""
    try:
        with _conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """INSERT INTO audit_log
                       (batch_id, layer, step, status, fail_count)
                       VALUES (%s, 'BATCH', 'run', 'Started', %s)""",
                    (batch_id, mail_count),
                )
    except Exception as exc:  # noqa: BLE001
        logger.warning("audit write_batch_row(%s) failed: %s", batch_id, exc)


def write_failure(batch_id: str, e_id: str, *, layer: str, reason: str) -> None:
    write_event(batch_id=batch_id, e_id=e_id, layer=layer,
                step="error", status="Failed", fail_reason=reason)


# L2 drop status (FileResult.status) → review_queue kind. Structured, not parsed
# from free text — drop.py emits these exact statuses.
_L2_DROP_KIND = {
    "CORRUPT": "corrupt",
    "NOT_RESUME": "not_resume",
    "DUP": "duplicate",
    "DUP_HIRED": "duplicate_hired",
}


def write_stage_events(batch_id: str, e_id: str, result: Any) -> None:
    """Summarize an L2 ProcessEmailResponse into per-file audit rows AND review items.

    The audit write is unchanged (history + retry gate). For each dropped file we
    ALSO enqueue a structured review_queue row keyed off ``FileResult.status`` —
    no string parsing — carrying the exact raw S3 key for View / Approve.
    """
    from app.constants import ReviewKind
    from app.services import review_queue

    file_results = getattr(result, "file_results", None) or []
    for fr in file_results:
        status = getattr(fr, "status", "") or ""
        cid = getattr(fr, "candidate_id", None)
        reason = getattr(fr, "fail_reason", None)
        filename = getattr(fr, "filename", None)
        ok = status in ("PASS", "REAPPLICATION")
        detail = reason or status
        if filename:
            detail = f"{filename}: {detail}" if detail else filename
        # Audit history — UNCHANGED (drives the retry-exhaustion gate).
        write_event(
            batch_id=batch_id, e_id=e_id, candidate_id=cid,
            layer="L2", step="process",
            status="Success" if ok else "Failed",
            fail_reason="" if ok else detail,
        )
        # Review queue — structured row for every dropped file (corrupt / not-resume
        # / duplicate / generic failure).
        if not ok:
            kind = _L2_DROP_KIND.get(status, ReviewKind.FAILED.value)
            review_queue.enqueue(
                e_id=e_id, candidate_id=cid, batch_id=batch_id, layer="L2",
                kind=kind, filename=filename,
                raw_s3_key=getattr(fr, "s3_key", None),
                reason=reason or status,
                details={"reason_code": reason or status},
            )
        # Re-applications stay a candidate-level flag (previously_seen, with the
        # candidate kept Active) AND get a queue row so they surface in the
        # Needs-Review list alongside everything else — nothing is lost.
        elif status == "REAPPLICATION":
            review_queue.enqueue(
                e_id=e_id, candidate_id=cid, batch_id=batch_id, layer="L2",
                kind=ReviewKind.REAPPLICATION, filename=filename,
                raw_s3_key=getattr(fr, "s3_key", None),
                reason=reason or "Re-application — known candidate, different resume",
                details={"reason_code": "REAPPLICATION"},
            )

    # ── L3 (resume parsing / extraction) audit rows ──────────────────────────
    # L2 auto-chains L3 in-process, so the extraction result rides back on the
    # same response. Without these rows the Activity Log shows a resume clearing
    # L2 but stays silent on Layer 3 — recruiters can't tell parsing happened.
    # One row per parsed candidate: Success when the extractor returned cleanly,
    # else Failed with the reason. NOTE: batch summaries count Success/Failed on
    # L2 only (see last_run_summary / list_batches), so these rows enrich the
    # ledger without double-counting "processed" resumes.
    extractions = getattr(result, "extractions", None) or []
    for ex in extractions:
        if not isinstance(ex, dict):
            continue
        ok = ex.get("status") == "success"
        write_event(
            batch_id=batch_id, e_id=e_id, candidate_id=ex.get("candidate_id"),
            layer="L3", step="extract",
            status="Success" if ok else "Failed",
            fail_reason="" if ok else (ex.get("failure_reason") or "extraction failed"),
        )
