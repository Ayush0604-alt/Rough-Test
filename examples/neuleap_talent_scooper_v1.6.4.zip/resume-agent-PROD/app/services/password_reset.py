"""Password-reset + account-invite tokens (``password_reset_tokens`` table).

One opaque, URL-safe token is emailed to a user for either flow:

* ``reset``  — self-service "forgot password": the user requests a link, sets a
  new password.
* ``invite`` — a newly-created member sets their INITIAL password via an emailed
  link (so an account can't exist without a reachable, verified email).

Only the token's SHA-256 digest is stored (never the plaintext); tokens are
single-use (``consumed_at``) and time-limited (``expires_at``). Verifying a token
proves the holder controls the account's email, which is why
:func:`app.services.users.set_password` can then change the password without the
old one.
"""
from __future__ import annotations

import hashlib
import logging
import secrets
from datetime import datetime, timedelta, timezone
from typing import Optional

import psycopg2.extras

from app.db import get_conn

logger = logging.getLogger(__name__)

RESET_TTL_MINUTES = 60          # forgot-password link — short-lived
INVITE_TTL_MINUTES = 72 * 60    # set-initial-password link — 3 days


def _gen_token() -> str:
    # ~256 bits, URL-safe; travels only in an emailed link, never typed.
    return secrets.token_urlsafe(32)


def _digest(token: str) -> str:
    return hashlib.sha256(token.strip().encode("utf-8")).hexdigest()


def create_token(email: str, purpose: str = "reset", ttl_minutes: Optional[int] = None) -> str:
    """Mint a token for ``email`` and return the RAW token (to embed in the link).
    Any prior unused tokens for this email+purpose are invalidated first, so a
    fresh request supersedes an older link."""
    if ttl_minutes is None:
        ttl_minutes = INVITE_TTL_MINUTES if purpose == "invite" else RESET_TTL_MINUTES
    token = _gen_token()
    expires_at = datetime.now(timezone.utc) + timedelta(minutes=ttl_minutes)
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE password_reset_tokens SET consumed_at = CURRENT_TIMESTAMP "
                "WHERE lower(btrim(email)) = lower(btrim(%s)) AND purpose = %s AND consumed_at IS NULL",
                (email, purpose),
            )
            cur.execute(
                "INSERT INTO password_reset_tokens (email, token_hash, purpose, expires_at) "
                "VALUES (%s, %s, %s, %s)",
                (email.strip(), _digest(token), purpose, expires_at),
            )
    logger.info("password_reset: %s token minted for %s", purpose, email)
    return token


def verify_token(token: str) -> Optional[dict]:
    """Return ``{email, purpose}`` for a valid (unconsumed, unexpired) token, else
    None. Does NOT consume it — the page validates first, then submits."""
    if not token:
        return None
    with get_conn() as conn:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(
                "SELECT email, purpose FROM password_reset_tokens "
                "WHERE token_hash = %s AND consumed_at IS NULL AND expires_at > CURRENT_TIMESTAMP "
                "ORDER BY id DESC LIMIT 1",
                (_digest(token),),
            )
            row = cur.fetchone()
    return dict(row) if row else None


def consume_token(token: str) -> Optional[dict]:
    """Atomically mark a valid token used and return ``{email, purpose}`` — the
    single-use guard for the actual password set. None if already used/expired."""
    if not token:
        return None
    with get_conn() as conn:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(
                "UPDATE password_reset_tokens SET consumed_at = CURRENT_TIMESTAMP "
                "WHERE token_hash = %s AND consumed_at IS NULL AND expires_at > CURRENT_TIMESTAMP "
                "RETURNING email, purpose",
                (_digest(token),),
            )
            row = cur.fetchone()
    return dict(row) if row else None
