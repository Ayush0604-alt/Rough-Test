"""Editable interview-question generation prompt (SKILL) — Settings →
Interview Question Generation. The default lives in app.api.interview.PROMPT;
this module stores an OPTIONAL override so an Admin can tune the generation
logic (how web-search results are used, what "challenging at a level" means,
etc.) without a code change. Reset removes the override → back to the default.

Stored as a markdown/text file in the bind-mounted ``secrets/`` dir.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

from app.logging_config import get_logger

log = get_logger(__name__)


def _path() -> Path:
    return Path(os.environ.get("INTERVIEW_PROMPT_FILE", "secrets/interview_prompt.md"))


def override() -> Optional[str]:
    """The stored override prompt, or None when using the built-in default."""
    try:
        text = _path().read_text(encoding="utf-8").strip()
        return text or None
    except OSError:
        return None


def is_custom() -> bool:
    return override() is not None


def save(text: str) -> None:
    """Persist an override. Empty text reverts to the default (removes the file)."""
    text = (text or "").strip()
    if not text:
        revert_to_default()
        return
    path = _path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
        log.info("interview_prompt_config: saved override (%d chars)", len(text))
    except OSError as exc:  # noqa: BLE001
        log.warning("interview_prompt_config: could not write %s: %s", path, exc)


def revert_to_default() -> None:
    try:
        p = _path()
        if p.exists():
            p.unlink()
            log.info("interview_prompt_config: reverted to default")
    except OSError as exc:  # noqa: BLE001
        log.warning("interview_prompt_config: could not remove override: %s", exc)


def active(default_prompt: str) -> str:
    """The effective prompt — the override if set, else the given default."""
    return override() or default_prompt
