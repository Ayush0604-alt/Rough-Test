"""Audit log — written to a flat ``.log`` file (no database table).

The cross-run failure/retry/discard ledger from the architecture spec lives in
``{base_dir}/local/audit.log`` as one JSON object per line, so it is greppable
and append-only without needing a DB table. Only ``email_master`` is persisted
to PostgreSQL.

Each line carries the 10 spec fields:
    log_id, run_id, E_id, candidate_id(null at L1), layer, step,
    fail_reason, status, fail_count(cumulative per E_id), created_at
"""

from __future__ import annotations

import json
import threading
from pathlib import Path
from typing import Any

from app.mail_config import Settings
from app.services import clock

_LOCK = threading.Lock()

# Statuses that increment the cumulative per-E_id failure counter.
_FAIL_STATUSES = {"Failed", "Retry"}


def _audit_path(settings: Settings) -> Path:
    settings.local_dir.mkdir(parents=True, exist_ok=True)
    return settings.local_dir / "audit.log"


def _prior_fail_count(path: Path, e_id: str | None) -> int:
    """Cumulative fail_count for this E_id across all prior log lines."""
    if not e_id or not path.exists():
        return 0
    count = 0
    try:
        for line in path.read_text(encoding="utf-8").splitlines():
            try:
                rec = json.loads(line)
            except json.JSONDecodeError:
                continue
            if rec.get("E_id") == e_id and rec.get("status") in _FAIL_STATUSES:
                count += 1
    except OSError:
        return 0
    return count


def log_event(
    settings: Settings,
    run_id: str,
    e_id: str | None,
    *,
    node: str,
    status: str,
    reason: str = "",
    step: int | None = None,
) -> dict[str, Any]:
    """Append one audit line. ``fail_count`` is cumulative per E_id."""
    path = _audit_path(settings)
    with _LOCK:
        base = _prior_fail_count(path, e_id)
        fail_count = base + 1 if status in _FAIL_STATUSES else base
        record = {
            "log_id": f"{run_id}:{e_id or '-'}:{clock.now().timestamp():.6f}",
            "run_id": run_id,
            "E_id": e_id,
            "candidate_id": None,        # always null at Layer 1
            "layer": "L1",
            "step": step,
            "node": node,
            "fail_reason": reason,
            # Success|Failed|Retry|Exhausted|Discarded|ManualReview|Info
            "status": status,
            "fail_count": fail_count,
            "created_at": clock.now_iso(),
        }
        with path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(record) + "\n")
    # D11: mirror to the shared Postgres ledger (best-effort; run_id == batch_id).
    try:
        from app.services import audit as shared_audit
        shared_audit.write_event(
            batch_id=run_id, run_id=run_id, e_id=e_id,
            layer="L1", step=node, status=status, fail_reason=reason,
        )
    except Exception:  # noqa: BLE001 — never fail a run on an audit hiccup
        pass
    return record
