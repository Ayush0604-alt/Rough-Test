"""Lightweight, key-less web search — used to ground interview-question
generation in popular online resources ("Search web" option).

Hits DuckDuckGo's HTML endpoint (no API key) and regex-parses the result
titles / links / snippets. Strictly best-effort: any failure returns an empty
list so the caller degrades gracefully (the LLM still generates from its own
knowledge). No external dependency beyond ``requests``.
"""
from __future__ import annotations

import html
import re
from typing import Any, Dict, List
from urllib.parse import parse_qs, unquote, urlparse

from app.logging_config import get_logger

log = get_logger(__name__)

_ENDPOINT = "https://html.duckduckgo.com/html/"
_UA = "Mozilla/5.0 (NeuLeap question research)"

# One result block: an anchor with class result__a (title + href) followed by a
# result__snippet. Tolerant of attribute order / extra classes.
_RESULT_RE = re.compile(
    r'<a[^>]*class="[^"]*result__a[^"]*"[^>]*href="(?P<href>[^"]+)"[^>]*>(?P<title>.*?)</a>'
    r'.*?(?:<a[^>]*class="[^"]*result__snippet[^"]*"[^>]*>(?P<snippet>.*?)</a>)?',
    re.IGNORECASE | re.DOTALL,
)
_TAG_RE = re.compile(r"<[^>]+>")


def _clean(text: str) -> str:
    return html.unescape(_TAG_RE.sub("", text or "")).strip()


def _real_url(href: str) -> str:
    """DDG wraps result links as /l/?uddg=<encoded>. Unwrap to the real URL."""
    try:
        if href.startswith("//"):
            href = "https:" + href
        parsed = urlparse(href)
        if parsed.path.startswith("/l/"):
            target = parse_qs(parsed.query).get("uddg", [""])[0]
            if target:
                return unquote(target)
    except Exception:  # noqa: BLE001
        pass
    return href


def search(query: str, limit: int = 5) -> List[Dict[str, Any]]:
    """Top results for ``query`` as ``[{title, url, snippet}]`` — empty on any
    failure. Bounded by ``limit``."""
    import requests

    try:
        resp = requests.post(
            _ENDPOINT, data={"q": query}, headers={"User-Agent": _UA}, timeout=15
        )
        if resp.status_code != 200 or not resp.text:
            return []
    except Exception as exc:  # noqa: BLE001 — best-effort; never raise
        log.info("web_search: '%s' failed: %s", query[:60], exc)
        return []

    out: List[Dict[str, Any]] = []
    seen: set[str] = set()
    for m in _RESULT_RE.finditer(resp.text):
        url = _real_url(m.group("href"))
        title = _clean(m.group("title"))
        if not url or not title or url in seen:
            continue
        seen.add(url)
        out.append({"title": title, "url": url, "snippet": _clean(m.group("snippet") or "")})
        if len(out) >= limit:
            break
    return out
