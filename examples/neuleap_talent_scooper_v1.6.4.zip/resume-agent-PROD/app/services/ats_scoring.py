"""Deterministic, configurable ATS scoring.

Computes a candidate's 0–100 ATS score from already-extracted resume signals using a
transparent weighted formula, so recruiters can see *why* a candidate scored what they
did. The LLM's track-fit judgement is folded in as ONE weighted component — it is the
only signal that reads the resume holistically — while every other component is computed
deterministically in Python from grounded fields.

    ATS = clamp_0_100( weighted_positive_signals + certification_bonus − penalties )

    weighted_positive_signals = Σ (normalized_weight_i · subscore_i)   # each 0–100

Design rules (mirrors the task contract):
  * Configurable: weights, the certificate-bonus cap, and penalty amounts all come from
    :mod:`app.services.scoring_config` (env-backed), so admins can tune the formula with
    no code change.
  * Bounded: the final score is floored at 0 and capped at 100.
  * Explainable: returns a per-component breakdown, the certificate-bonus detail, the
    penalties applied, and a human-readable explanation for the analysis field.
  * Honest about missing data: an absent signal makes that component score 0 — it is
    treated as *unavailable*, never guessed.
  * Certificate bonus is additive and capped so it can lift but never dominate a score.

This module never reads the resume text or invents signals; it only combines the
validated fields the extraction engine already produced.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from app.logging_config import get_logger

log = get_logger(__name__)

# Degree level → education subscore (0–100). Missing degree → 0 (unavailable).
_EDUCATION_SUBSCORE = {"PhD": 100.0, "Master": 85.0, "Bachelor": 70.0, "Diploma": 50.0}

# Recognised cloud / platform providers whose certs carry full relevance weight even
# when their name doesn't literally contain a track keyword. Kept lowercase.
_MAJOR_CERT_PROVIDERS = (
    "aws", "amazon", "google", "gcp", "microsoft", "azure", "databricks",
    "snowflake", "coursera", "oracle", "ibm",
)

# Off-track / unclassified buckets that should not earn track-specific credit.
_OFF_TRACK = {None, "", "Not Relevant"}


def _clamp(value: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, value))


def _text_blob(*parts: Any) -> str:
    """Lower-cased haystack built from string / list-of-string / list-of-dict fields."""
    chunks: List[str] = []
    for part in parts:
        if part is None:
            continue
        if isinstance(part, str):
            chunks.append(part)
        elif isinstance(part, list):
            for item in part:
                if isinstance(item, str):
                    chunks.append(item)
                elif isinstance(item, dict):
                    chunks.extend(str(v) for v in item.values() if isinstance(v, str))
    return " ".join(chunks).lower()


def _track_for(candidate: Dict[str, Any], ats: Dict[str, Any]) -> Optional[str]:
    """The hiring track to score relevance against (recommendation == stream by design)."""
    return ats.get("recommendation") or candidate.get("stream")


# ── component subscores (each 0–100) ────────────────────────────────────────────

def _skills_subscore(candidate: Dict[str, Any], track: Optional[str], target: int) -> float:
    """Keyword/skill overlap of the candidate's skills, projects and domain against the
    recommended track's configured keywords. Off-track or unconfigured → 0."""
    if track in _OFF_TRACK or target <= 0:
        return 0.0
    try:
        from app.services import scoring_config
        keywords = scoring_config.stream_keywords().get(track, [])
    except Exception:  # noqa: BLE001 — config hiccup must not break scoring
        keywords = []
    if not keywords:
        return 0.0
    haystack = _text_blob(
        candidate.get("primary_skills"),
        candidate.get("projects"),
        candidate.get("domain"),
        candidate.get("job_roles"),
    )
    matches = sum(1 for kw in keywords if kw and kw.lower() in haystack)
    return _clamp(matches / target * 100.0)


def _experience_subscore(candidate: Dict[str, Any], target_years: float) -> float:
    """Years of qualifying experience scaled to a target. Freshers score 0 here — they
    are not *penalised*; experience simply carries a small weight so on-track freshers
    still score well via skills + LLM fit (fresher fairness)."""
    years = candidate.get("yearofexp")
    if not years or target_years <= 0:
        return 0.0
    try:
        return _clamp(float(years) / target_years * 100.0)
    except (TypeError, ValueError):
        return 0.0


def _education_subscore(candidate: Dict[str, Any]) -> float:
    return _EDUCATION_SUBSCORE.get(candidate.get("highest_coursecompleted") or "", 0.0)


def _format_subscore(candidate: Dict[str, Any]) -> float:
    """Completeness of the parsed profile — a proxy for a clean, well-formed resume.
    Each present signal contributes equally; missing ones simply don't count."""
    checks = [
        bool(candidate.get("name")),
        bool(candidate.get("email") or candidate.get("phno")),
        bool(candidate.get("clg")),
        bool(candidate.get("primary_skills")),
        bool(candidate.get("projects")),
        bool(candidate.get("job_roles") or candidate.get("fresher_or_lateral") == "Fresher"),
    ]
    return _clamp(sum(checks) / len(checks) * 100.0)


# ── certificate bonus + penalties ───────────────────────────────────────────────

def _certificate_bonus(
    candidate: Dict[str, Any], track: Optional[str], per: float, cap: float
) -> Dict[str, Any]:
    """Additive, capped bonus for certificates relevant to the target track or issued by
    a major recognised provider. Bounded by ``cap`` so it can never dominate the score."""
    certs = candidate.get("certificates") or []
    if not isinstance(certs, list) or per <= 0 or cap <= 0:
        return {"points": 0.0, "cap": cap, "certs": []}

    track_keywords: List[str] = []
    if track not in _OFF_TRACK:
        try:
            from app.services import scoring_config
            track_keywords = [k.lower() for k in scoring_config.stream_keywords().get(track, [])]
        except Exception:  # noqa: BLE001
            track_keywords = []

    credited: List[str] = []
    for cert in certs:
        if not isinstance(cert, dict):
            continue
        name = cert.get("name") or ""
        text = f"{name} {cert.get('issuer') or ''}".lower()
        if not text.strip():
            continue
        relevant = any(p in text for p in _MAJOR_CERT_PROVIDERS) or any(
            kw and kw in text for kw in track_keywords
        )
        if relevant:
            credited.append(name)

    points = _clamp(len(credited) * per, 0.0, cap)
    return {"points": round(points, 2), "cap": cap, "certs": credited}


def _penalties(
    candidate: Dict[str, Any], track: Optional[str], params: Dict[str, float]
) -> List[Dict[str, Any]]:
    """Conservative, configurable deductions that mirror behaviour the app already has:
    off-track resumes already score low, and uncontactable candidates are weaker leads.
    Each penalty is named so recruiters can audit it."""
    out: List[Dict[str, Any]] = []
    off = params.get("penalty_offtrack", 0.0)
    if track in _OFF_TRACK and off > 0:
        out.append({"reason": "Off-track for GenAI / Data Engineering", "points": off})
    missing = params.get("penalty_missing_contact", 0.0)
    if not candidate.get("email") and not candidate.get("phno") and missing > 0:
        out.append({"reason": "No email or phone (uncontactable)", "points": missing})
    # Career-gap penalty — a SEPARATE signal from experience. It reads ``gap_months``
    # ONLY; it never reads or mutates the experience subscore, so deducting it can never
    # change the candidate's underlying experience value (task contract). Opt-in:
    # disabled while penalty_long_gap == 0 so existing scores are unchanged.
    gap_pen = params.get("penalty_long_gap", 0.0)
    gap_threshold = params.get("gap_penalty_threshold_months", 12.0)
    gap_months = candidate.get("gap_months")
    if gap_pen > 0 and isinstance(gap_months, (int, float)) and gap_months > gap_threshold:
        out.append({
            "reason": f"Career gap of {int(gap_months)} months (> {int(gap_threshold)})",
            "points": gap_pen,
        })
    return out


# ── public API ──────────────────────────────────────────────────────────────────

def compute_score(
    candidate: Dict[str, Any],
    ats: Dict[str, Any],
    llm_fit: float,
) -> Dict[str, Any]:
    """Compute the deterministic ATS score from extracted signals.

    ``llm_fit`` is the model's 0–100 track-fit judgement, folded in as one weighted
    component. Returns ``{score, breakdown, certification_bonus, penalties, explanation}``.
    """
    try:
        from app.services import scoring_config
        weights = scoring_config.scoring_weights()
        params = scoring_config.scoring_params()
    except Exception:  # noqa: BLE001 — fall back to defaults if config is unavailable
        weights = dict(DEFAULT_WEIGHTS)
        params = dict(DEFAULT_PARAMS)

    track = _track_for(candidate, ats)

    subscores = {
        "llm_fit": _clamp(llm_fit),
        "skills": _skills_subscore(candidate, track, int(params.get("skills_match_target", 4))),
        "experience": _experience_subscore(candidate, params.get("exp_target_years", 5.0)),
        "education": _education_subscore(candidate),
        "format": _format_subscore(candidate),
    }

    labels = {
        "llm_fit": "LLM track fit",
        "skills": "Skill / keyword match",
        "experience": "Experience match",
        "education": "Education match",
        "format": "Resume format / completeness",
    }

    # Normalize weights so the weighted positive signals stay on a 0–100 scale even if
    # the configured weights don't sum to exactly 1.0.
    total_weight = sum(max(0.0, w) for w in weights.values()) or 1.0
    breakdown: List[Dict[str, Any]] = []
    weighted_positive = 0.0
    for key, sub in subscores.items():
        w = max(0.0, weights.get(key, 0.0)) / total_weight
        weighted = w * sub
        weighted_positive += weighted
        breakdown.append({
            "component": labels[key],
            "weight": round(w, 4),
            "subscore": round(sub, 2),
            "weighted": round(weighted, 2),
        })

    cert = _certificate_bonus(
        candidate, track,
        params.get("cert_bonus_per", 4.0),
        params.get("cert_bonus_max", 10.0),
    )
    penalties = _penalties(candidate, track, params)
    penalty_total = sum(p["points"] for p in penalties)

    raw = weighted_positive + cert["points"] - penalty_total
    score = round(_clamp(raw), 2)

    explanation = _build_explanation(score, breakdown, cert, penalties)
    return {
        "score": score,
        "breakdown": breakdown,
        "certification_bonus": cert,
        "penalties": penalties,
        "explanation": explanation,
    }


# Canonical component order + labels, shared with the LLM-scored path so the breakdown
# rows read identically whether subscores are computed in Python or supplied by the model.
# Must stay in sync with the labels emitted by compute_score above and the frontend's
# SCORE_COMPONENT_LABEL map.
_COMPONENT_LABELS: Dict[str, str] = {
    "llm_fit": "LLM track fit",
    "skills": "Skill / keyword match",
    "experience": "Experience match",
    "education": "Education match",
    "format": "Resume format / completeness",
}


def _num(value: Any, default: float = 0.0) -> float:
    """Best-effort float coercion — model JSON occasionally hands back strings/None."""
    try:
        if value is None:
            return default
        return float(value)
    except (TypeError, ValueError):
        return default


def _sanitize_penalties(penalties: Any) -> List[Dict[str, Any]]:
    """Coerce LLM penalties to ``[{reason, points≥0}]``, dropping empty/zero entries."""
    out: List[Dict[str, Any]] = []
    if not isinstance(penalties, list):
        return out
    for p in penalties:
        if not isinstance(p, dict):
            continue
        reason = str(p.get("reason") or "").strip()
        points = max(0.0, _num(p.get("points"), 0.0))
        if reason and points > 0:
            out.append({"reason": reason, "points": round(points, 2)})
    return out


def _sanitize_cert(cert: Any, cap: float) -> Dict[str, Any]:
    """Coerce the LLM certificate bonus, clamping points to ``[0, cap]``."""
    cap = max(0.0, _num(cap, 10.0))
    if not isinstance(cert, dict):
        return {"points": 0.0, "cap": round(cap, 2), "certs": []}
    points = _clamp(_num(cert.get("points"), 0.0), 0.0, cap)
    certs_raw = cert.get("certs")
    certs = (
        [str(x).strip() for x in certs_raw if str(x).strip()]
        if isinstance(certs_raw, list) else []
    )
    return {"points": round(points, 2), "cap": round(cap, 2), "certs": certs}


def score_from_llm(
    components: Any,
    penalties: Any = None,
    cert: Any = None,
) -> Dict[str, Any]:
    """Assemble the ATS score from LLM-supplied component subscores, penalties, and the
    certificate bonus.

    Python still OWNS the (recruiter-configurable) weights, the final arithmetic, and the
    safety clamps — the model owns only the judgement (each 0–100 subscore, the penalties,
    the bonus). Returns the SAME payload shape as :func:`compute_score`
    (``{score, breakdown, certification_bonus, penalties, explanation}``) so the engine and
    frontend are unchanged.

        ATS = clamp_0_100( Σ normalized_weightᵢ · subscoreᵢ + cert_bonus − penalties )
    """
    if not isinstance(components, dict):
        components = {}
    try:
        from app.services import scoring_config
        weights = scoring_config.scoring_weights()
        params = scoring_config.scoring_params()
    except Exception:  # noqa: BLE001 — fall back to defaults if config is unavailable
        weights = dict(DEFAULT_WEIGHTS)
        params = dict(DEFAULT_PARAMS)

    total_weight = sum(max(0.0, w) for w in weights.values()) or 1.0
    breakdown: List[Dict[str, Any]] = []
    weighted_positive = 0.0
    for key, label in _COMPONENT_LABELS.items():
        sub = _clamp(_num(components.get(key), 0.0))
        w = max(0.0, weights.get(key, 0.0)) / total_weight
        weighted = w * sub
        weighted_positive += weighted
        breakdown.append({
            "component": label,
            "weight": round(w, 4),
            "subscore": round(sub, 2),
            "weighted": round(weighted, 2),
        })

    cert_out = _sanitize_cert(cert, params.get("cert_bonus_max", 10.0))
    pens_out = _sanitize_penalties(penalties)
    penalty_total = sum(p["points"] for p in pens_out)

    raw = weighted_positive + cert_out["points"] - penalty_total
    score = round(_clamp(raw), 2)

    explanation = _build_explanation(score, breakdown, cert_out, pens_out)
    return {
        "score": score,
        "breakdown": breakdown,
        "certification_bonus": cert_out,
        "penalties": pens_out,
        "explanation": explanation,
    }


def _build_explanation(
    score: float,
    breakdown: List[Dict[str, Any]],
    cert: Dict[str, Any],
    penalties: List[Dict[str, Any]],
) -> str:
    """A short, recruiter-facing summary of how the score was assembled."""
    parts = [f"ATS {score:.0f}/100 (scored)."]
    contribs = ", ".join(
        f"{b['component']} {b['subscore']:.0f}→{b['weighted']:.1f}" for b in breakdown
    )
    parts.append(f"Components: {contribs}.")
    if cert["points"] > 0:
        names = ", ".join(cert["certs"][:5]) if cert["certs"] else ""
        suffix = f" ({names})" if names else ""
        parts.append(f"Certificate bonus +{cert['points']:.0f} (cap {cert['cap']:.0f}){suffix}.")
    if penalties:
        pens = ", ".join(f"−{p['points']:.0f} {p['reason']}" for p in penalties)
        parts.append(f"Penalties: {pens}.")
    return " ".join(parts)


def merge_explanation(analysis: Optional[str], explanation: str) -> str:
    """Append the scoring explanation to the LLM analysis without clobbering it."""
    base = (analysis or "").strip()
    if not explanation:
        return base
    return f"{base}\n\n{explanation}" if base else explanation


# Defaults exposed for scoring_config to reuse and for tests / fallbacks. Weights are
# relative (normalized at use-time); params are absolute points / targets.
DEFAULT_WEIGHTS: Dict[str, float] = {
    "llm_fit": 0.30,
    "skills": 0.15,
    "experience": 0.35,
    "education": 0.10,
    "format": 0.10,
}
DEFAULT_PARAMS: Dict[str, float] = {
    "cert_bonus_per": 4.0,
    "cert_bonus_max": 10.0,
    "exp_target_years": 5.0,
    "skills_match_target": 4.0,
    "penalty_offtrack": 15.0,
    "penalty_missing_contact": 5.0,
    # Career-gap penalty (separate from experience). Opt-in: 0.0 = disabled.
    "penalty_long_gap": 0.0,
    "gap_penalty_threshold_months": 12.0,
}
