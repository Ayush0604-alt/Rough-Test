"""Scheduled scan over open candidate slot invites — sends reminders (capped
at Settings → Interview Scheduling → "Reminders before auto-reject") on the
configured interval, then auto-rejects the round after the configured
response window with no booking. Registered as a periodic job alongside the
existing pipeline/archival jobs — see app.services.scheduler.

Mirrors the existing manual "Send reminder" action
(app.repositories.pg_repo.send_round_reminder / POST /rounds/{id}/send-reminder)
but fully automatic, and additionally emails the candidate (the manual action
only bumps the counter; this job is what candidates actually see).
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any

from app.db import get_conn
from app.logging_config import get_logger
from app.services import (
    candidate_slot,
    email_send,
    email_send_config,
    email_templates,
    graph_client,
    interview_scheduling_config,
)

log = get_logger(__name__)


def _audit(candidate_id: str, step: str, detail: str, round_name: str | None) -> None:
    """Best-effort Action-Log entry — the reminder/auto-reject cycle must be
    traceable per candidate, but an audit hiccup must never stop the scan."""
    try:
        from app.services import audit
        from app.stages import candidate_stage_bucket

        audit.write_event(
            candidate_id=candidate_id, layer="L4", step=step, status="Info",
            fail_reason=detail, stage=candidate_stage_bucket({"roundname": round_name}),
        )
    except Exception as exc:  # noqa: BLE001
        log.warning("slot_reminder_job: audit write failed (%s/%s): %s", candidate_id, step, exc)


def _has_pending_reminder_draft(candidate_id: str) -> bool:
    """True when a 'slot_reminder' draft is already sitting unsent for this
    candidate — the scan must not stack a second one on top each pass."""
    from app.repositories import repo

    return any(
        d.get("nba_key") == "slot_reminder" and d.get("status") != "sent"
        for d in repo().list_candidate_email_drafts(candidate_id)
    )


def _open_invites() -> list[dict[str, Any]]:
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT token, candidate_id, round_id, candidate_email, sent_at, "
                "reminder_count, last_reminder_at "
                "FROM round_slot_invites WHERE booked_at IS NULL AND rejected_at IS NULL"
            )
            cols = [d[0] for d in cur.description]
            return [dict(zip(cols, row)) for row in cur.fetchall()]


def _mark_reminded(token: str, reminder_count: int) -> None:
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE round_slot_invites SET reminder_count = %s, last_reminder_at = CURRENT_TIMESTAMP "
                "WHERE token = %s",
                (reminder_count, token),
            )


def _mark_rejected(token: str) -> None:
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE round_slot_invites SET rejected_at = CURRENT_TIMESTAMP WHERE token = %s",
                (token,),
            )


def run_once() -> dict[str, int]:
    """One scan pass. Returns {reminded, rejected} counts — safe to call from
    both the periodic job and an ad-hoc test/ops trigger."""
    from app.repositories import repo

    cfg = interview_scheduling_config.get()
    max_reminders = cfg["reminder_max_count"]
    # Units are hours/days in production; a QA environment may flip either to
    # "minutes" (Settings → Interview Scheduling) so the whole remind→reject
    # cycle can be exercised without waiting days. The NUMBER lives in the
    # same config field either way.
    interval_n = cfg["reminder_interval_hours"]
    reject_n = cfg["auto_reject_after_days"]
    interval = (
        timedelta(minutes=interval_n)
        if cfg.get("reminder_interval_unit") == "minutes"
        else timedelta(hours=interval_n)
    )
    reject_after = (
        timedelta(minutes=reject_n)
        if cfg.get("auto_reject_after_unit") == "minutes"
        else timedelta(days=reject_n)
    )
    reject_window_txt = f"{reject_n}-minute" if cfg.get("auto_reject_after_unit") == "minutes" else f"{reject_n}-day"
    now = datetime.now(timezone.utc)

    reminded = 0
    rejected = 0
    for inv in _open_invites():
        sent_at = inv["sent_at"]
        if sent_at.tzinfo is None:
            sent_at = sent_at.replace(tzinfo=timezone.utc)
        last = inv["last_reminder_at"]
        if last is not None and last.tzinfo is None:
            last = last.replace(tzinfo=timezone.utc)
        elapsed_since_sent = now - sent_at

        candidate_id = inv["candidate_id"]
        round_id = inv["round_id"]
        candidate = repo().get_candidate(candidate_id)
        candidate_name = candidate.get("name") if candidate else None

        if elapsed_since_sent >= reject_after:
            round_row = None
            for r in repo().list_rounds(candidate_id):
                if r.get("round_id") == round_id:
                    round_row = r
                    break
            round_name = (round_row or {}).get("round_name") or "your"
            repo().update_round(round_id, {
                "outcome": "Fail",
                "feedback": (
                    f"Auto-rejected — no interview slot was selected within the "
                    f"configured {reject_window_txt} response window."
                ),
            })
            _mark_rejected(inv["token"])
            if candidate and candidate.get("email"):
                recipient, _qa_redirected = email_send.resolve_recipient(candidate["email"])
                if recipient:
                    subject, body = email_templates.render_slot_auto_reject(round_name, candidate_name)
                    graph_client.send_mail(recipient, subject, graph_client.plain_text_to_html(body))
            _audit(
                candidate_id, "slot_auto_rejected",
                f"Auto-rejected at {round_name} — no interview slot selected within the "
                f"{reject_window_txt} response window "
                f"(after {inv['reminder_count']} reminder(s)).",
                round_name if round_name != "your" else None,
            )
            rejected += 1
            log.info("slot_reminder_job: auto-rejected round %s (candidate %s)", round_id, candidate_id)
            continue

        reference = last or sent_at
        if inv["reminder_count"] < max_reminders and (now - reference) >= interval:
            round_row = None
            for r in repo().list_rounds(candidate_id):
                if r.get("round_id") == round_id:
                    round_row = r
                    break
            round_name = (round_row or {}).get("round_name") or "your"
            link_url = candidate_slot.public_schedule_url(inv["token"])
            next_count = inv["reminder_count"] + 1
            recipient, _qa_redirected = email_send.resolve_recipient(inv["candidate_email"])

            # Settings → Email Send Controls: when draft review is required (or
            # auto-send is off entirely), the reminder becomes an email DRAFT
            # for the recruiter to review + mark ready + send — same workflow
            # as every NBA ack-email — instead of leaving directly. The
            # reminder counter still advances either way, so the auto-reject
            # clock keeps its meaning.
            send_cfg = email_send_config.get()
            review_first = not send_cfg["auto_send_enabled"] or send_cfg["draft_review_required"]

            if not link_url:
                if inv["candidate_email"]:
                    log.warning(
                        "slot_reminder_job: APP_PUBLIC_URL isn't configured — reminder to %s not sent",
                        inv["candidate_email"],
                    )
            elif review_first:
                if _has_pending_reminder_draft(candidate_id):
                    continue  # last reminder draft still awaiting review — don't stack another
                subject, body = email_templates.render_slot_reminder(
                    round_name, candidate_name, link_url,
                    reminder_number=next_count, reminder_total=max_reminders,
                    reject_window_text=reject_window_txt,
                )
                draft = repo().create_email_draft(candidate_id, "slot_reminder", subject, body)
                _audit(
                    candidate_id, "email_draft_generated",
                    f'Slot-pick reminder #{next_count} for {round_name} drafted for review: "{subject}"',
                    round_name if round_name != "your" else None,
                )
                log.info(
                    "slot_reminder_job: reminder #%d for round %s drafted for review (draft %s)",
                    next_count, round_id, draft["draft_id"],
                )
            elif recipient:
                subject, body = email_templates.render_slot_reminder(
                    round_name, candidate_name, link_url,
                    reminder_number=next_count, reminder_total=max_reminders,
                    reject_window_text=reject_window_txt,
                )
                graph_client.send_mail(recipient, subject, graph_client.plain_text_to_html(body))
                _audit(
                    candidate_id, "slot_reminder_sent",
                    f"Slot-pick reminder #{next_count} of {max_reminders} sent for {round_name} "
                    f"(auto-reject after the {reject_window_txt} window without a booking).",
                    round_name if round_name != "your" else None,
                )
            _mark_reminded(inv["token"], next_count)
            # Mirror the counter onto the ROUND (and candidate_master via
            # update_round's active-round step mirror) — the Dashboard's
            # "Reminder x of y" rows read the candidate row, NOT the invite
            # table, which is why sent reminders previously showed as 0 there.
            try:
                repo().update_round(round_id, {"reminder_count": next_count})
            except Exception as exc:  # noqa: BLE001 — display mirror only
                log.warning("slot_reminder_job: round mirror failed for %s: %s", round_id, exc)
            reminded += 1
            log.info(
                "slot_reminder_job: reminder #%d recorded for round %s (candidate %s)",
                next_count, round_id, candidate_id,
            )

    return {"reminded": reminded, "rejected": rejected}
