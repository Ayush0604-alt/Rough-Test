"""Floating chatbot launcher visibility — a single shared on/off toggle.

Backs the Settings page's "Chatbot" section: whether the floating "Neuleap
Buddy" launcher (and its chat panel) appears at all, for every user. Persisted
as JSON in the bind-mounted ``secrets/`` dir (default
``secrets/chatbot_widget.json``, override with ``CHATBOT_WIDGET_CONFIG_FILE``)
— the same runtime-file philosophy as column_config/scoring_config/notify_config.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict

from app.logging_config import get_logger

log = get_logger(__name__)

_DEFAULT_VISIBLE = True


def _path() -> Path:
    return Path(os.environ.get("CHATBOT_WIDGET_CONFIG_FILE", "secrets/chatbot_widget.json"))


def get() -> Dict[str, Any]:
    try:
        raw = json.loads(_path().read_text(encoding="utf-8"))
        if isinstance(raw, dict) and "visible" in raw:
            return {"visible": bool(raw["visible"])}
    except (OSError, ValueError):
        pass
    return {"visible": _DEFAULT_VISIBLE}


def save(visible: bool) -> Dict[str, Any]:
    """Persist the toggle. Writing never raises — a disk hiccup just keeps the
    old value in effect rather than breaking the save request."""
    path = _path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps({"visible": bool(visible)}, indent=2), encoding="utf-8")
        log.info("chatbot_widget_config: saved %s", path)
    except OSError as exc:  # noqa: BLE001
        log.warning("chatbot_widget_config: could not write %s: %s", path, exc)
    return get()
