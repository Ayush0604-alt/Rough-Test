"""The interviewer "promise-hash" — a short, opaque link token that carries
ONE candidate's id (and, when minted for a specific interview round, that
round's id too).

A recruiter/admin mints this from the round they're managing ("Share with
Interviewer"); the resulting URL (``/interview/{token}``) is what actually
gets emailed/shared to the interviewer. Backed by one row in
``interviewer_links`` (token -> candidate_id/round_id) — unlike the rest of
this feature's stateless-JWT origins, a short (~10-char) URL needs a
server-side lookup table rather than a self-contained encoded payload, which
would run to 150+ characters. The row is permanent (no expiry): access is
still gated by the OTP challenge + the domain allow-list at open time, and a
compromised domain can be shut off in Settings (which also revokes every
remembered session for it) without touching the links themselves.
"""
from __future__ import annotations

import secrets
from typing import Optional, TypedDict

import psycopg2

from app.db import get_conn

# Unambiguous URL-safe alphabet — no padding/escaping needed in a path segment.
# 10 chars over 62 symbols is ~59 bits of entropy, plenty for an unguessable
# token that also isn't tied to any per-candidate/round pattern.
_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
_TOKEN_LEN = 10
_MAX_ATTEMPTS = 5


class LinkContext(TypedDict):
    candidate_id: str
    round_id: Optional[int]


def _gen_token() -> str:
    return "".join(secrets.choice(_ALPHABET) for _ in range(_TOKEN_LEN))


def generate_link_token(candidate_id: str, round_id: Optional[int] = None) -> str:
    """``round_id`` scopes the link to one interview round — that's the round
    the interviewer will be asked to leave feedback and a verdict on. Omit it
    for a candidate-only link (read access, no feedback capability)."""
    for _ in range(_MAX_ATTEMPTS):
        token = _gen_token()
        try:
            with get_conn() as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        "INSERT INTO interviewer_links (token, candidate_id, round_id) "
                        "VALUES (%s, %s, %s)",
                        (token, candidate_id, round_id),
                    )
            return token
        except psycopg2.IntegrityError:
            continue  # token collision (astronomically rare) — try a new one
    raise RuntimeError("Could not generate a unique interview link token.")


def decode_link_token(token: str) -> Optional[LinkContext]:
    """The {candidate_id, round_id} the token carries, or None if it doesn't
    exist (malformed, mistyped, or never minted)."""
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT candidate_id, round_id FROM interviewer_links WHERE token = %s",
                (token,),
            )
            row = cur.fetchone()
    if not row:
        return None
    return {"candidate_id": row[0], "round_id": row[1]}
