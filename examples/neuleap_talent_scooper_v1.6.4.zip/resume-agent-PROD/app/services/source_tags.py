"""Registered "social post" source tags — the Mailbox page's "Register recent
social post as a source tag" button.

A recruiter posts a job on LinkedIn/Naukri/etc. and registers that post here;
the ONE currently-active tag's label is auto-stamped as the intake `source`
onto every new Graph-mail resume staged while it's active (see
app.services.mail_intake._stage_one_graph_message) — so replies to that post
carry the right source without the recruiter tagging each email by hand. The
manual "Add to Intake queue" upload is unaffected: it always asks for its own
per-upload source explicitly (UploadResumeModal), regardless of what's active
here.

JSON-file-backed, like chatbot_widget_config/candidate_sections_config — same
runtime-file philosophy: shared across users, survives restarts.
"""
from __future__ import annotations

import json
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from app.db import get_conn
from app.logging_config import get_logger

log = get_logger(__name__)


def _path() -> Path:
    return Path(os.environ.get("SOURCE_TAGS_FILE", "secrets/source_tags.json"))


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _load() -> Dict[str, Any]:
    try:
        raw = json.loads(_path().read_text(encoding="utf-8"))
        if isinstance(raw, dict) and isinstance(raw.get("tags"), list):
            tags = raw["tags"]
            # Backfill for tags registered before dup_check_scoped existed —
            # keeps the API contract (always a bool) consistent regardless of
            # when a tag was created.
            for t in tags:
                t.setdefault("dup_check_scoped", False)
            return {"tags": tags, "active_id": raw.get("active_id")}
    except (OSError, ValueError):
        pass
    return {"tags": [], "active_id": None}


def _save(data: Dict[str, Any]) -> None:
    path = _path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    except OSError as exc:  # noqa: BLE001 — a write failure must not break the request
        log.warning("source_tags: could not write %s: %s", path, exc)


def list_tags() -> Dict[str, Any]:
    """Every registered tag (newest first) + which one (if any) is active."""
    data = _load()
    tags: List[Dict[str, Any]] = sorted(
        data["tags"], key=lambda t: t.get("created_at", ""), reverse=True
    )
    return {"tags": tags, "active_id": data.get("active_id")}


def active_label() -> Optional[str]:
    """The currently active tag's label, or None when no tag is active — read
    by Graph-mail staging on every new message."""
    data = _load()
    active_id = data.get("active_id")
    if not active_id:
        return None
    for t in data["tags"]:
        if t["id"] == active_id:
            return t["label"]
    return None


def register(
    *, platform: str, label: str, post_url: Optional[str] = None, note: Optional[str] = None
) -> Dict[str, Any]:
    """Register a new source tag. Does NOT make it active — the recruiter
    picks which tag is active as a separate, explicit step (set_active).
    ``dup_check_scoped`` defaults to False (system-wide duplicate check,
    today's existing behavior) — see set_dup_check_scope."""
    data = _load()
    tag = {
        "id": uuid.uuid4().hex[:12],
        "platform": platform,
        "label": label,
        "post_url": post_url,
        "note": note,
        "dup_check_scoped": False,
        "created_at": _now_iso(),
    }
    data["tags"].append(tag)
    _save(data)
    log.info("source_tags: registered %s (%r, %s)", tag["id"], label, platform)
    return list_tags()


def update(
    tag_id: str, *, platform: str, label: str, post_url: Optional[str] = None, note: Optional[str] = None
) -> Dict[str, Any]:
    """Edit a registered tag's platform/label/URL/note in place — the tag's
    id (and any config keyed off it, like recruiter_apply_config, which keys
    off the label string) is otherwise unaffected. Candidates already stamped
    with the OLD label keep that value; only NEW intake stamped after this
    edit gets the new label."""
    data = _load()
    for t in data["tags"]:
        if t["id"] == tag_id:
            t["platform"] = platform
            t["label"] = label
            t["post_url"] = post_url
            t["note"] = note
            _save(data)
            log.info("source_tags: updated %s (%r, %s)", tag_id, label, platform)
            return list_tags()
    raise ValueError(f"unknown source tag id {tag_id!r}")


def set_active(tag_id: Optional[str]) -> Dict[str, Any]:
    """Switch the active tag, or clear it entirely with tag_id=None. Logged to
    the audit trail (not candidate-scoped) so "was a tag active when this mail
    arrived?" is always answerable later — this has no other timestamped
    record anywhere."""
    from app.services import audit

    data = _load()
    if tag_id is not None and not any(t["id"] == tag_id for t in data["tags"]):
        raise ValueError(f"unknown source tag id {tag_id!r}")
    previous_id = data.get("active_id")
    data["active_id"] = tag_id
    _save(data)
    if previous_id != tag_id:
        new_label = next((t["label"] for t in data["tags"] if t["id"] == tag_id), None)
        old_label = next((t["label"] for t in data["tags"] if t["id"] == previous_id), None)
        audit.write_event(
            layer="SYSTEM",
            step="source_tag_active_changed",
            status="Info",
            fail_reason=(
                f"Active source tag changed: {old_label!r} -> {new_label!r}"
                if tag_id else f"Active source tag cleared (was {old_label!r})"
            ),
        )
    return list_tags()


def set_dup_check_scope(tag_id: str, scoped: bool) -> Dict[str, Any]:
    """Whether the L2 duplicate-resume check (app.pipeline.nodes.dedup) for
    this tag's candidates is scoped to just THIS source, instead of the
    default system-wide compare against every candidate regardless of
    source."""
    data = _load()
    for t in data["tags"]:
        if t["id"] == tag_id:
            t["dup_check_scoped"] = bool(scoped)
            _save(data)
            log.info("source_tags: dup_check_scoped for %s set to %s", tag_id, scoped)
            return list_tags()
    raise ValueError(f"unknown source tag id {tag_id!r}")


def dup_check_scoped_for(source: Optional[str]) -> bool:
    """True if `source` matches a registered tag's label AND that tag has
    opted into source-scoped duplicate checking. False (system-wide check,
    the pre-existing default) for "no source", an unregistered/legacy source
    string, or a registered tag that hasn't opted in."""
    label = (source or "").strip()
    if not label:
        return False
    data = _load()
    for t in data["tags"]:
        if t.get("label") == label:
            return bool(t.get("dup_check_scoped"))
    return False


def _association_count(label: str) -> int:
    """How many candidates or emails already carry this tag's label as their
    source — used to block deleting a tag that's actually in use (deleting it
    wouldn't touch that historical data, but would orphan the label: it could
    no longer be edited/re-activated/scoped as a unit, and a recruiter
    filtering by source would lose the tag from every picker)."""
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT "
                "(SELECT count(*) FROM candidate_master WHERE source = %s) + "
                "(SELECT count(*) FROM email_master WHERE source = %s)",
                (label, label),
            )
            return cur.fetchone()[0]


def delete(tag_id: str) -> Dict[str, Any]:
    """Remove a registered tag — refused (ValueError) if any candidate or
    email already carries its label, EVEN for an Admin: this isn't a
    permission rule, it's a data-integrity one. Clearing it as the active tag
    first (if it is one) and simply no longer using it for new intake is the
    correct way to retire a tag that's already in use."""
    data = _load()
    tag = next((t for t in data["tags"] if t["id"] == tag_id), None)
    if not tag:
        raise ValueError(f"unknown source tag id {tag_id!r}")
    count = _association_count(tag["label"])
    if count > 0:
        raise ValueError(
            f"Can't delete {tag['label']!r} — it's already the source on {count} "
            f"candidate/email record(s). Clear it as the active tag instead; the "
            f"tag stays available for reference but stops being used for new intake."
        )
    data["tags"] = [t for t in data["tags"] if t["id"] != tag_id]
    if data.get("active_id") == tag_id:
        data["active_id"] = None
    _save(data)
    return list_tags()
