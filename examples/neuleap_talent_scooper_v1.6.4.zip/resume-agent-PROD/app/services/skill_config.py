"""SKILL.md prompt sourcing — the single place `app.extraction.engine` reads its
master/timeline/analysis-report prompts from, and the backing for Settings →
"Extraction & Analysis" (whole-file override + a narrower Analysis Report
prompt-only override, each independently revertible to the shipped default).

Two independent override layers, both optional:
  * A FULL SKILL.md override (``secrets/skill_override.md``) — replaces the
    entire file the master/timeline prompts are extracted from.
  * An Analysis-Report-PROMPT-only override (``secrets/analysis_prompt_override.md``)
    — replaces just that one section, regardless of whether a full-file
    override is also active. This is the "simple view" the Settings page
    offers for quickly testing a tweak to the Analysis Report wording without
    touching the rest of the (much longer) master prompt.

Unlike the purely-cosmetic JSON config modules elsewhere (chatbot widget
visibility, column order, …), a save here feeds directly into a live LLM
extraction pipeline — so validation failures are RAISED (ValueError), not
silently swallowed. A disk write failure still only logs a warning; the
`secrets/` dir is created on first save.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from app.logging_config import get_logger

log = get_logger(__name__)

_DEFAULT_SKILL_PATH = Path(__file__).resolve().parent.parent / "extraction" / "SKILL.md"

_MASTER_MARKERS = ("<!-- MASTER_PROMPT:START -->", "<!-- MASTER_PROMPT:END -->")
_TIMELINE_MARKERS = ("<!-- TIMELINE_PROMPT:START -->", "<!-- TIMELINE_PROMPT:END -->")
_ANALYSIS_MARKERS = ("<!-- ANALYSIS_REPORT_PROMPT:START -->", "<!-- ANALYSIS_REPORT_PROMPT:END -->")

# Every override must contain at least these two sections — a master prompt
# with no analysis-report instruction would silently drop the candidate page's
# Analysis Report card, which is worse than rejecting the upload outright.
_REQUIRED_MARKERS = (_MASTER_MARKERS, _ANALYSIS_MARKERS)


def _skill_override_path() -> Path:
    return Path(os.environ.get("SKILL_OVERRIDE_FILE", "secrets/skill_override.md"))


def _analysis_override_path() -> Path:
    return Path(os.environ.get("ANALYSIS_PROMPT_OVERRIDE_FILE", "secrets/analysis_prompt_override.md"))


def _extract(text: str, start: str, end: str) -> str:
    s = text.find(start)
    e = text.find(end)
    if s == -1 or e == -1 or e <= s:
        raise ValueError(f"Missing or malformed {start} … {end} markers.")
    prompt = text[s + len(start):e].strip()
    if not prompt:
        raise ValueError(f"The {start} … {end} section is empty.")
    return prompt


def _read(path: Path) -> str | None:
    """The file's text if it exists and is non-blank, else None. Never raises —
    a read error just falls through to the default, same as every other
    JSON/env config module in this codebase."""
    try:
        if not path.exists():
            return None
        text = path.read_text(encoding="utf-8")
        return text if text.strip() else None
    except OSError as exc:  # noqa: BLE001
        log.warning("skill_config: could not read %s: %s", path, exc)
        return None


def default_skill_text() -> str:
    return _DEFAULT_SKILL_PATH.read_text(encoding="utf-8")


def is_skill_overridden() -> bool:
    return _read(_skill_override_path()) is not None


def active_skill_text() -> str:
    """The SKILL.md content actually in effect — the override file if one is
    saved, else the shipped default. This is what engine.py's master/timeline
    prompts are extracted from."""
    return _read(_skill_override_path()) or default_skill_text()


def master_prompt() -> str:
    return _extract(active_skill_text(), *_MASTER_MARKERS)


def timeline_prompt() -> str:
    return _extract(active_skill_text(), *_TIMELINE_MARKERS)


def default_analysis_prompt() -> str:
    return _extract(default_skill_text(), *_ANALYSIS_MARKERS)


def is_analysis_prompt_overridden() -> bool:
    return _read(_analysis_override_path()) is not None


def active_analysis_prompt() -> str:
    """The Analysis Report prompt actually in effect: the dedicated override
    if present, else whatever's in the (possibly separately overridden)
    active SKILL.md, else the shipped default."""
    override = _read(_analysis_override_path())
    if override is not None:
        return override
    try:
        return _extract(active_skill_text(), *_ANALYSIS_MARKERS)
    except ValueError:
        return default_analysis_prompt()


def save_skill_override(text: str) -> dict[str, Any]:
    """Replaces the whole active SKILL.md. Raises ValueError if the required
    markers are missing/malformed/empty — never accepts a file that would
    silently break extraction for every candidate afterward."""
    for start, end in _REQUIRED_MARKERS:
        _extract(text, start, end)  # raises with a clear message on failure

    path = _skill_override_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    log.info("skill_config: saved SKILL.md override to %s", path)
    return get_status()


def revert_skill_to_default() -> dict[str, Any]:
    path = _skill_override_path()
    try:
        if path.exists():
            path.unlink()
            log.info("skill_config: reverted SKILL.md override (%s removed)", path)
    except OSError as exc:  # noqa: BLE001
        log.warning("skill_config: could not remove %s: %s", path, exc)
    return get_status()


def save_analysis_prompt(text: str) -> dict[str, Any]:
    if not text.strip():
        raise ValueError("The Analysis Report prompt can't be empty.")
    path = _analysis_override_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    log.info("skill_config: saved Analysis Report prompt override to %s", path)
    return get_status()


def revert_analysis_prompt_to_default() -> dict[str, Any]:
    path = _analysis_override_path()
    try:
        if path.exists():
            path.unlink()
            log.info("skill_config: reverted Analysis Report prompt override (%s removed)", path)
    except OSError as exc:  # noqa: BLE001
        log.warning("skill_config: could not remove %s: %s", path, exc)
    return get_status()


def get_status() -> dict[str, Any]:
    """Everything the Settings page needs to render both the full-file editor
    and the "simple view" Analysis Report prompt editor."""
    return {
        "skill_overridden": is_skill_overridden(),
        "skill_active_text": active_skill_text(),
        "skill_default_text": default_skill_text(),
        "analysis_overridden": is_analysis_prompt_overridden(),
        "analysis_active_prompt": active_analysis_prompt(),
        "analysis_default_prompt": default_analysis_prompt(),
    }
