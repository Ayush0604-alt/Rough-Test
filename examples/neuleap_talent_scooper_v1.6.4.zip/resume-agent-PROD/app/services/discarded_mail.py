"""Ledger of Incoming Email Queue items an Admin/System Admin discarded.

These messages live in the Outlook "Discarded" folder while set aside (no e_id /
email_master row exists yet — the pipeline hasn't staged them), so this can't
live in the shared ``audit_log`` ledger keyed by e_id. One row per discarded
message, capturing who set it aside and when, plus (once brought back) who
restored it and when — so the Mailbox report shows "Discarded by <admin>" /
"Restored by <admin>" for every action taken here.

Rows are never deleted: restoring an item flips its state to 'restored' and
fills in the restored_by/at columns, keeping full history for the report.

Best-effort like the rest of the audit ledger: a write failure here must
never block the actual Graph folder move.
"""
from __future__ import annotations

import logging
from typing import Any, Optional

import psycopg2.extras

from app.db import get_conn

logger = logging.getLogger(__name__)


def record_discard(
    *,
    message_id: Optional[str],
    sender_mail_id: Optional[str],
    subject: Optional[str],
    received_date: Optional[str],
    discarded_by_email: str,
    discarded_by_name: str,
) -> Optional[int]:
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """INSERT INTO discarded_incoming_mail
                       (message_id, sender_mail_id, subject, received_date,
                        state, discarded_by_email, discarded_by_name)
                       VALUES (%s, %s, %s, %s, 'discarded', %s, %s)
                       RETURNING id""",
                    (message_id, sender_mail_id, subject, received_date,
                     discarded_by_email, discarded_by_name),
                )
                row = cur.fetchone()
                return int(row[0]) if row else None
    except Exception as exc:  # noqa: BLE001 — never fail the discard on a ledger hiccup
        logger.warning("discarded_mail.record_discard failed: %s", exc)
        return None


def get(item_id: int) -> Optional[dict[str, Any]]:
    try:
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute("SELECT * FROM discarded_incoming_mail WHERE id = %s", (item_id,))
                row = cur.fetchone()
                return dict(row) if row else None
    except Exception as exc:  # noqa: BLE001
        logger.warning("discarded_mail.get(%s) failed: %s", item_id, exc)
        return None


def record_restore(
    item_id: int, *, new_message_id: Optional[str], restored_by_email: str, restored_by_name: str
) -> bool:
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """UPDATE discarded_incoming_mail
                       SET state = 'restored', message_id = COALESCE(%s, message_id),
                           restored_by_email = %s, restored_by_name = %s,
                           restored_at = CURRENT_TIMESTAMP
                       WHERE id = %s AND state = 'discarded'""",
                    (new_message_id, restored_by_email, restored_by_name, item_id),
                )
                return cur.rowcount > 0
    except Exception as exc:  # noqa: BLE001
        logger.warning("discarded_mail.record_restore(%s) failed: %s", item_id, exc)
        return False


def list_open(limit: int = 200) -> list[dict[str, Any]]:
    """Items currently sitting in the Discarded folder — restorable."""
    return _list(state="discarded", limit=limit)


def list_history(limit: int = 500) -> list[dict[str, Any]]:
    """Every discard/restore action, newest first — powers the report."""
    return _list(state=None, limit=limit)


def _list(*, state: Optional[str], limit: int) -> list[dict[str, Any]]:
    try:
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                if state:
                    cur.execute(
                        "SELECT * FROM discarded_incoming_mail WHERE state = %s "
                        "ORDER BY id DESC LIMIT %s",
                        (state, limit),
                    )
                else:
                    cur.execute(
                        "SELECT * FROM discarded_incoming_mail ORDER BY id DESC LIMIT %s",
                        (limit,),
                    )
                return [dict(r) for r in cur.fetchall()]
    except Exception as exc:  # noqa: BLE001
        logger.warning("discarded_mail.list failed: %s", exc)
        return []
