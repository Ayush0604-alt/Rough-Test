"""In-app upgrade orchestration (app side).

Validates an uploaded version **bundle** (image tarballs + manifest), takes a
full pre-upgrade backup, then hands off to the updater sidecar via a file-based
request. The sidecar performs the data-safe image swap + checks + rollback and
writes ``status.json``, which the UI polls (see app/services/upgrade — protocol
mirrors updater/entrypoint.sh).
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import tarfile
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

from app.logging_config import get_logger

log = get_logger(__name__)


def _upgrade_dir() -> Path:
    d = Path(os.environ.get("BACKUP_PRIMARY_DIR", "/app/backups")) / "upgrade"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _incoming_dir() -> Path:
    d = _upgrade_dir() / "incoming"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _drop_dir() -> Path:
    """Server-side drop folder — copy a bundle .tar here (host: backups/upgrade/
    drop/) to install it WITHOUT a browser upload. This sidesteps upload-size
    limits (Cloudflare/nginx) that block big bundles over a tunnel."""
    d = _upgrade_dir() / "drop"
    d.mkdir(parents=True, exist_ok=True)
    return d


def list_drop_files() -> List[dict]:
    out = []
    for p in _drop_dir().glob("*.tar"):
        try:
            out.append({"filename": p.name, "size_bytes": p.stat().st_size})
        except OSError:
            continue
    out.sort(key=lambda x: x["filename"], reverse=True)
    return out


def load_drop_bundle(filename: str) -> Dict[str, Any]:
    """Validate + stage a bundle already sitting in the drop folder (no upload)."""
    name = os.path.basename(filename)  # never escape the drop dir
    f = _drop_dir() / name
    if not f.exists():
        raise ValueError(f"'{name}' not found in the server drop folder.")
    with f.open("rb") as fh:
        return save_bundle(fh, name)


def _stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _verify_signature(payload: bytes, sig_b64: str, public_key_pem: str) -> bool:
    """Verify an Ed25519 signature (base64) over ``payload`` with a PEM public key."""
    import base64
    from cryptography.hazmat.primitives.serialization import load_pem_public_key

    try:
        pub = load_pem_public_key(public_key_pem.encode("utf-8"))
        pub.verify(base64.b64decode(sig_b64), payload)  # raises InvalidSignature on mismatch
        return True
    except Exception as exc:  # noqa: BLE001 — any failure = untrusted
        log.warning("bundle signature verification failed: %s", exc)
        return False


def save_bundle(fileobj, filename: str) -> Dict[str, Any]:
    """Stream + extract an uploaded bundle tar, validate its manifest and image
    checksums, and stage it under incoming/<bundle_id>/. Returns the manifest +
    bundle_id. Raises ValueError on a malformed/untrusted bundle."""
    bundle_id = "bundle_" + _stamp()
    dest = _incoming_dir() / bundle_id
    dest.mkdir(parents=True, exist_ok=True)

    # Stream the upload to a temp file, then extract members we expect.
    with tempfile.NamedTemporaryFile(delete=False, suffix=".tar") as tmp:
        tmp_path = Path(tmp.name)
        shutil.copyfileobj(fileobj, tmp, length=1 << 20)
    try:
        with tarfile.open(tmp_path, "r:*") as tar:
            for member in tar.getmembers():
                # Flatten: only allow plain files with safe basenames.
                name = os.path.basename(member.name)
                allowed = {"manifest.json", "app.tar", "frontend.tar", "manifest.sig",
                           "env.additions", "overlay.compose.yml"}
                if not member.isfile() or name not in allowed:
                    continue
                src = tar.extractfile(member)
                if src is None:
                    continue
                with (dest / name).open("wb") as out:
                    shutil.copyfileobj(src, out, length=1 << 20)
    finally:
        tmp_path.unlink(missing_ok=True)

    mpath = dest / "manifest.json"
    if not mpath.exists():
        shutil.rmtree(dest, ignore_errors=True)
        raise ValueError("Bundle is missing manifest.json.")
    manifest = json.loads(mpath.read_text(encoding="utf-8"))

    # ── Signature verification ──
    # The manifest binds the image checksums, so a valid signature over
    # manifest.json (+ the checksum check below) means the bundle is trusted.
    from app.services import upgrade_config
    ucfg = upgrade_config.get()
    pubkey = (ucfg.get("public_key") or "").strip()
    sig_path = dest / "manifest.sig"
    signed = sig_path.exists()
    verified = False
    if pubkey:
        if not signed:
            shutil.rmtree(dest, ignore_errors=True)
            raise ValueError("Bundle is unsigned, but a signing key is configured — refusing to install.")
        verified = _verify_signature(mpath.read_bytes(), sig_path.read_text(encoding="utf-8").strip(), pubkey)
        if not verified:
            shutil.rmtree(dest, ignore_errors=True)
            raise ValueError("Bundle signature is INVALID — refusing to install.")
    elif ucfg.get("require_signature"):
        shutil.rmtree(dest, ignore_errors=True)
        raise ValueError("Signed bundles are required but no signing public key is configured (Settings → System Upgrade).")
    manifest["signed"] = signed
    manifest["signature_verified"] = verified
    manifest["has_env_additions"] = (dest / "env.additions").exists()
    manifest["has_compose_overlay"] = (dest / "overlay.compose.yml").exists()

    # Validate the image tarballs exist + match their declared checksums.
    for img in manifest.get("images", []):
        tarfile_name = img.get("tarfile")
        f = dest / (tarfile_name or "")
        if not tarfile_name or not f.exists():
            shutil.rmtree(dest, ignore_errors=True)
            raise ValueError(f"Bundle is missing image tarball '{tarfile_name}'.")
        want = (img.get("sha256") or "").strip()
        if want and _sha256(f) != want:
            shutil.rmtree(dest, ignore_errors=True)
            raise ValueError(f"Checksum mismatch for '{tarfile_name}' — bundle may be corrupt.")

    # Extra files (env additions / compose overlay) are covered by the signed
    # manifest via their checksums, so tampering is caught even though they sit
    # outside the image list.
    for extra_name, key in (("env.additions", "env_sha256"), ("overlay.compose.yml", "overlay_sha256")):
        want = (manifest.get(key) or "").strip()
        if want:
            f = dest / extra_name
            if not f.exists() or _sha256(f) != want:
                shutil.rmtree(dest, ignore_errors=True)
                raise ValueError(f"Checksum mismatch for '{extra_name}' — bundle may be tampered.")

    manifest["bundle_id"] = bundle_id
    manifest["uploaded_filename"] = filename
    manifest["size_bytes"] = sum(p.stat().st_size for p in dest.iterdir() if p.is_file())
    (dest / "validated.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def list_bundles() -> List[dict]:
    out: List[dict] = []
    for d in _incoming_dir().iterdir():
        if not d.is_dir():
            continue
        # Prefer validated.json (carries signed/signature_verified/size); fall
        # back to the raw manifest.json.
        src = d / "validated.json"
        if not src.exists():
            src = d / "manifest.json"
        if not src.exists():
            continue
        try:
            m = json.loads(src.read_text(encoding="utf-8"))
            m["bundle_id"] = d.name
            out.append(m)
        except (OSError, ValueError):
            continue
    out.sort(key=lambda m: m.get("bundle_id", ""), reverse=True)
    return out


def start_upgrade(bundle_id: str, requested_by: str = "") -> Dict[str, Any]:
    """Take a full pre-upgrade backup, then write the request the sidecar picks
    up. Returns the pre-backup id + the initial status."""
    inc = _incoming_dir() / bundle_id
    if not (inc / "manifest.json").exists():
        raise ValueError("Bundle not found — upload it again.")

    from app.services import backup
    pre = backup.run_backup(kind="full", reason="pre-upgrade")
    pre_id = pre.get("id", "")
    if pre.get("status") != "ok":
        raise ValueError(f"Pre-upgrade backup failed: {pre.get('error')}. Upgrade aborted.")

    ud = _upgrade_dir()
    (ud / "status.json").write_text(json.dumps({
        "state": "queued", "phase": "queued",
        "message": "Pre-upgrade backup done; waiting for the updater to start the swap.",
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "pre_backup_id": pre_id, "bundle_id": bundle_id,
    }, indent=2), encoding="utf-8")
    (ud / "request.json").write_text(json.dumps({
        "bundle_id": bundle_id, "pre_backup_id": pre_id,
        "requested_by": requested_by,
        "requested_at": datetime.now(timezone.utc).isoformat(),
    }, indent=2), encoding="utf-8")
    return {"started": True, "pre_backup_id": pre_id, "bundle_id": bundle_id}


def updater_alive() -> bool:
    """True when the updater sidecar heartbeat is fresh (< 30s old). The sidecar
    is opt-in (compose profile), so the UI uses this to tell the operator to
    start it before an upgrade."""
    import time
    f = _upgrade_dir() / "updater.alive"
    try:
        return f.exists() and (time.time() - f.stat().st_mtime) < 30
    except OSError:
        return False


def get_status() -> Dict[str, Any]:
    alive = updater_alive()
    f = _upgrade_dir() / "status.json"
    if not f.exists():
        return {"state": "idle", "updater_alive": alive}
    try:
        data = json.loads(f.read_text(encoding="utf-8"))
        data["updater_alive"] = alive
        return data
    except (OSError, ValueError):
        return {"state": "idle", "updater_alive": alive}
