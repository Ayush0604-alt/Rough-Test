"""Pipeline configuration — persisted to a small env file (no database).

Backs the Settings page's "Pipeline Configuration" section. Like
:mod:`app.services.notify_config`, values live in an ``.env``-style file in the
bind-mounted ``secrets/`` directory and are mirrored into ``os.environ`` so the rest
of the app reads them with plain ``os.environ.get`` at use-time (so a Save takes
effect on the next run without a restart — the daily-run-time change also reschedules
the cron live).

File (default ``secrets/pipeline.env``, override with ``PIPELINE_CONFIG_FILE``)::

    SCHEDULE_CRON=0 0 * * *
    SCHEDULE_TZ=Asia/Kolkata
    MAX_RETRIES=3
    ARCHIVE_AFTER_DAYS=30
    ARCHIVE_ATS_THRESHOLD=30
    FUZZY_THRESHOLD=85
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from app.logging_config import get_logger

log = get_logger(__name__)

# The env keys this module owns (written to the file verbatim).
_ENV_KEYS = (
    "SCHEDULE_CRON", "SCHEDULE_TZ", "MAX_RETRIES",
    "ARCHIVE_AFTER_DAYS", "ARCHIVE_ATS_THRESHOLD", "FUZZY_THRESHOLD",
)

# Defaults mirror the previously-hardcoded behaviour.
_DEFAULTS = {
    "SCHEDULE_CRON": "0 0 * * *", "SCHEDULE_TZ": "Asia/Kolkata", "MAX_RETRIES": "3",
    "ARCHIVE_AFTER_DAYS": "30", "ARCHIVE_ATS_THRESHOLD": "30", "FUZZY_THRESHOLD": "85",
}


def _path() -> Path:
    return Path(os.environ.get("PIPELINE_CONFIG_FILE", "secrets/pipeline.env"))


def _int(env: str) -> int:
    try:
        return int(float(os.environ.get(env, _DEFAULTS[env])))
    except (TypeError, ValueError):
        return int(_DEFAULTS[env])


def _float(env: str) -> float:
    try:
        return float(os.environ.get(env, _DEFAULTS[env]))
    except (TypeError, ValueError):
        return float(_DEFAULTS[env])


# ── time <-> cron (a daily "HH:MM" run time ⇔ "M H * * *") ──────────────────────

def cron_to_time(cron: str) -> str:
    parts = (cron or "").split()
    if len(parts) >= 2 and parts[0].isdigit() and parts[1].isdigit():
        return f"{int(parts[1]):02d}:{int(parts[0]):02d}"
    return "00:00"


def time_to_cron(hhmm: str) -> str:
    try:
        h, m = hhmm.split(":")
        return f"{int(m)} {int(h)} * * *"
    except (ValueError, AttributeError):
        return _DEFAULTS["SCHEDULE_CRON"]


# ── typed accessors used by the backend at run-time ────────────────────────────

def max_retries() -> int:
    return max(1, _int("MAX_RETRIES"))


def archive_after_days() -> int:
    return max(1, _int("ARCHIVE_AFTER_DAYS"))


def archive_ats_threshold() -> float:
    return _float("ARCHIVE_ATS_THRESHOLD")


def dedup_threshold() -> int:
    return _int("FUZZY_THRESHOLD")


# ── persistence ────────────────────────────────────────────────────────────────

def load() -> None:
    """Load the env file into ``os.environ`` (startup + reload). Never raises.

    These UI-managed keys **override** any value injected from ``.env`` /
    docker-compose, so a saved setting wins (and survives a restart).
    """
    path = _path()
    try:
        if not path.exists():
            return
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, val = line.partition("=")
            os.environ[key.strip()] = val.strip()
        log.info("pipeline_config: loaded %s", path)
    except OSError as exc:  # noqa: BLE001
        log.warning("pipeline_config: could not load %s: %s", path, exc)


def get() -> dict[str, Any]:
    """Current pipeline settings in the shape the Settings page renders."""
    return {
        "run_time": cron_to_time(os.environ.get("SCHEDULE_CRON", _DEFAULTS["SCHEDULE_CRON"])),
        "timezone": os.environ.get("SCHEDULE_TZ", _DEFAULTS["SCHEDULE_TZ"]),
        "max_retries": max_retries(),
        "archive_after_days": archive_after_days(),
        "archive_ats_threshold": archive_ats_threshold(),
        "dedup_threshold": dedup_threshold(),
    }


def save(settings: dict[str, Any]) -> dict[str, Any]:
    """Persist settings to the env file + ``os.environ``; reschedule the cron live."""
    if "run_time" in settings:
        os.environ["SCHEDULE_CRON"] = time_to_cron(str(settings["run_time"]))
    if settings.get("timezone"):
        os.environ["SCHEDULE_TZ"] = str(settings["timezone"]).strip()
    if "max_retries" in settings:
        os.environ["MAX_RETRIES"] = str(int(settings["max_retries"]))
    if "archive_after_days" in settings:
        os.environ["ARCHIVE_AFTER_DAYS"] = str(int(settings["archive_after_days"]))
    if "archive_ats_threshold" in settings:
        os.environ["ARCHIVE_ATS_THRESHOLD"] = str(float(settings["archive_ats_threshold"]))
    if "dedup_threshold" in settings:
        os.environ["FUZZY_THRESHOLD"] = str(int(settings["dedup_threshold"]))

    path = _path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        lines = [
            "# NeuLeap pipeline configuration (managed by the Settings page).",
            *(f"{k}={os.environ.get(k, _DEFAULTS[k])}" for k in _ENV_KEYS),
            "",
        ]
        path.write_text("\n".join(lines), encoding="utf-8")
        log.info("pipeline_config: saved %s", path)
    except OSError as exc:  # noqa: BLE001
        log.warning("pipeline_config: could not write %s: %s", path, exc)

    # Apply the new daily-run-time to the live scheduler (best-effort).
    try:
        from app.services import scheduler
        scheduler.reschedule()
    except Exception as exc:  # noqa: BLE001
        log.warning("pipeline_config: reschedule failed: %s", exc)
    return get()
