"""Deterministic career-gap and year-of-experience computation.

Two INDEPENDENT signals are produced from an LLM-extracted structured timeline. The
model only extracts dated activities VERBATIM (type, org, title, start/end, is_current);
this module does ALL the date math. Career gap and experience are computed by two
separate functions over their own view of the timeline, so neither can infer, inflate,
or overwrite the other.

  * Career gap  = breaks between consecutive dated activities (≥ ``gap_min_months``).
  * Experience  = sum of verified qualifying work durations (> ``qualifying_min_months``),
    with overlapping periods MERGED so nothing is double-counted.

Contract (mirrors the task requirements):
  * Never guess a missing date. A boundary with a missing/unclear bounding date is
    *unknown* — never counted as a gap, never coerced to zero, never assumed absent.
  * Open-ended / ``is_current`` activities end at ``today``.
  * Education is excluded from experience; it takes part in gap detection only when
    ``gap_include_education`` is set (then the education→first-job break is a gap and the
    study period itself is covered, never a gap).
  * Internships are excluded from experience unless ``experience_include_internships``.

The output is deterministic and explainable: ``gap_ranges`` lists every counted break and
the breakdown of method/confidence records when dates were partial or missing.
"""
from __future__ import annotations

import re
from datetime import date
from typing import Any, Dict, List, Optional, Tuple

# activity_type buckets (lower-cased). The LLM emits these in the timeline.
_WORK_TYPES = {"job", "freelance", "contract"}
_INTERNSHIP_TYPES = {"internship", "apprenticeship", "trainee", "traineeship", "articleship"}
_EDUCATION_TYPES = {"education"}
# "Ongoing"-style end markers that mean "ends at today". "Present"/"Current"/"Now" are
# NEVER literals in any computation — :func:`is_open_ended` detects them and every module
# resolves them to :func:`current_date` so experience, gaps, and the narrative agree.
_PRESENT_MARKERS = {
    "present", "current", "now", "till date", "todate", "to date", "ongoing",
    "till now", "currently", "date", "—", "-",
}


def current_date() -> date:
    """The ONE runtime "today" for all timeline math — the business clock (IST default).

    Anchoring every open-ended ("Present") resolution to this single function is what
    keeps experience, gap, and analysis from disagreeing, and avoids a stale hardcoded
    year. Falls back to the system date only if the clock module is unavailable.
    """
    try:
        from app.services import clock
        return clock.now().date()
    except Exception:  # noqa: BLE001 — clock hiccup must never break extraction
        return date.today()


def is_open_ended(value: Any) -> bool:
    """True when a resume end-date means "ongoing" (Present / Current / Now / …).

    The SINGLE place that decides what counts as open-ended, so no two modules can
    classify "Present" differently.
    """
    if value is None:
        return False
    return str(value).strip().lower() in _PRESENT_MARKERS


def annotate_resolved(entries: List[Dict[str, Any]], today: Optional[date] = None) -> List[Dict[str, Any]]:
    """Stamp each open-ended entry with ``end_date_resolved`` (the runtime date) while
    keeping its raw ``end_date`` for display. Lets the UI still show "Present" while every
    computed/persisted value carries the concrete resolved date. Non-mutating."""
    today = today or current_date()
    iso = f"{today.year:04d}-{today.month:02d}"
    out: List[Dict[str, Any]] = []
    for entry in entries or []:
        if not isinstance(entry, dict):
            continue
        item = dict(entry)
        if bool(item.get("is_current")) or is_open_ended(item.get("end_date")):
            item["is_current"] = True
            item["end_date_resolved"] = iso
        out.append(item)
    return out


def default_config() -> Dict[str, float]:
    """Computation knobs, sourced from scoring_config when available."""
    try:
        from app.services import scoring_config
        return scoring_config.timeline_config()
    except Exception:  # noqa: BLE001 — config hiccup must never break extraction
        return {
            "gap_include_education": 1.0,
            "experience_include_internships": 0.0,
            "gap_min_months": 3.0,
            "qualifying_min_months": 0.0,
        }


# ── date parsing ─────────────────────────────────────────────────────────────────

def _to_month_index(value: Any, *, is_end: bool) -> Tuple[Optional[int], bool]:
    """Parse a resume date into an absolute month index, plus a ``partial`` flag.

    Returns ``(index, partial)`` where ``index = year*12 + (month-1)`` or ``None`` when
    the date is truly absent/unparseable. ``"YYYY-MM"`` is exact; a bare ``"YYYY"`` is
    *partial* (we anchor a start to January and an end to December of that year — flagged
    so confidence drops; we never fabricate a precise month into a verified count).
    """
    if value is None:
        return None, False
    text = str(value).strip().lower()
    if not text or text in {"null", "n/a", "na", "none", "unknown"}:
        return None, False
    if text in _PRESENT_MARKERS:
        return None, False  # caller resolves present → today

    # YYYY-MM or YYYY/MM or YYYY.MM
    m = re.match(r"^(\d{4})[-/.](\d{1,2})$", text)
    if m:
        year, month = int(m.group(1)), int(m.group(2))
        if 1 <= month <= 12 and 1900 <= year <= 2100:
            return year * 12 + (month - 1), False
    # Bare YYYY → partial.
    m = re.match(r"^(\d{4})$", text)
    if m:
        year = int(m.group(1))
        if 1900 <= year <= 2100:
            return year * 12 + (11 if is_end else 0), True
    return None, False


def _today_index(today: date) -> int:
    return today.year * 12 + (today.month - 1)


def _normalize_type(value: Any) -> str:
    return str(value or "").strip().lower()


def _interval(entry: Dict[str, Any], today_idx: int) -> Optional[Dict[str, Any]]:
    """Resolve one timeline entry to a numeric ``[start, end)`` month interval.

    Returns ``None`` when the entry cannot be placed on the timeline (no usable start, or
    no usable end and not current). ``partial`` is True when either bound was year-only.
    """
    start_idx, start_partial = _to_month_index(entry.get("start_date"), is_end=False)
    if start_idx is None:
        return None

    # Open-ended roles ("Present"/"Current"/"Now" or is_current) resolve to the runtime
    # date (today_idx) — never treated as a literal, never as a missing value.
    if bool(entry.get("is_current")) or is_open_ended(entry.get("end_date")):
        end_idx, end_partial = today_idx, False
    else:
        end_idx, end_partial = _to_month_index(entry.get("end_date"), is_end=True)
        if end_idx is None:
            return None

    if end_idx < start_idx:  # impossible range — drop from math, flag via caller
        return None
    return {
        "start": start_idx,
        "end": end_idx,
        "partial": start_partial or end_partial,
        "type": _normalize_type(entry.get("activity_type")),
    }


def _merge(intervals: List[Dict[str, Any]]) -> List[Tuple[int, int]]:
    """Merge overlapping/adjacent month ranges into a minimal covering set."""
    spans = sorted((iv["start"], iv["end"]) for iv in intervals)
    merged: List[Tuple[int, int]] = []
    for start, end in spans:
        if merged and start <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], end))
        else:
            merged.append((start, end))
    return merged


def _month_to_iso(idx: int) -> str:
    return f"{idx // 12:04d}-{(idx % 12) + 1:02d}"


# ── continuous-employment runs (shared by experience and company history) ─────────

def _work_runs(
    entries: List[Dict[str, Any]], today_idx: int, config: Dict[str, float]
) -> Tuple[List[Dict[str, Any]], int]:
    """Group placeable work entries into continuous employment RUNS.

    A run merges roles that overlap OR sit in consecutive months (no counted break
    between them) — so back-to-back roles at one employer, or two adjacent jobs, form a
    single continuous span instead of being judged in isolation. A run is ``qualifying``
    when its MERGED duration exceeds ``qualifying_min_months``: a short role that is part
    of a continuous run still counts, while a truly standalone short stint does not. This
    is the SINGLE source both :func:`compute_experience` and :func:`work_roles` read, so
    the experience total and the displayed company history can never disagree.

    Returns ``(runs, dropped)`` where each run is
    ``{start, end, partial, qualifying, members:[(interval, entry)]}`` ordered by start,
    and ``dropped`` counts work entries that could not be placed (missing/unclear dates).
    """
    include_intern = config.get("experience_include_internships", 0.0) > 0
    qualifying_min = int(config.get("qualifying_min_months", 6.0))

    work_types = set(_WORK_TYPES)
    if include_intern:
        work_types |= _INTERNSHIP_TYPES

    placed: List[Tuple[Dict[str, Any], Dict[str, Any]]] = []
    dropped = 0           # work entries we could not place (missing dates) — unknown
    for e in entries:
        if _normalize_type(e.get("activity_type")) not in work_types:
            continue
        iv = _interval(e, today_idx)
        if iv is None:
            dropped += 1
            continue
        placed.append((iv, e))

    placed.sort(key=lambda p: p[0]["start"])
    runs: List[Dict[str, Any]] = []
    for iv, e in placed:
        # ``+ 1`` treats consecutive months (one role ends the month before the next
        # begins) as continuous — the same no-break semantics :func:`compute_gap` uses,
        # so a role change with no real gap never splits a continuous tenure.
        if runs and iv["start"] <= runs[-1]["end"] + 1:
            runs[-1]["end"] = max(runs[-1]["end"], iv["end"])
            runs[-1]["partial"] = runs[-1]["partial"] or iv["partial"]
            runs[-1]["members"].append((iv, e))
        else:
            runs.append({
                "start": iv["start"],
                "end": iv["end"],
                "partial": iv["partial"],
                "members": [(iv, e)],
            })
    for run in runs:
        run["qualifying"] = (run["end"] - run["start"]) > qualifying_min
    return runs, dropped


# ── experience (independent of gap) ──────────────────────────────────────────────

def compute_experience(
    entries: List[Dict[str, Any]], today_idx: int, config: Dict[str, float]
) -> Dict[str, Any]:
    """Total verified qualifying work experience. Internships/education excluded unless
    configured. Continuous runs merged so nothing is double-counted and no short role
    inside a continuous tenure is dropped. Never guesses missing dates."""
    include_intern = config.get("experience_include_internships", 0.0) > 0
    work_types = set(_WORK_TYPES)
    if include_intern:
        work_types |= _INTERNSHIP_TYPES
    work_entries = [e for e in entries if _normalize_type(e.get("activity_type")) in work_types]

    runs, dropped = _work_runs(entries, today_idx, config)
    qualifying = [r for r in runs if r["qualifying"]]
    months = sum(r["end"] - r["start"] for r in qualifying)
    any_partial = any(r["partial"] for r in qualifying)

    if not work_entries:
        method, confidence = "computed", "high"
    elif not qualifying and dropped:
        method, confidence = "unknown", "low"
    elif dropped or any_partial:
        method, confidence = "partial", "medium"
    else:
        method, confidence = "computed", "high"

    return {
        "experience_months": months,
        "yearofexp": round(months / 12.0, 1),
        "experience_method": method,
        "experience_confidence": confidence,
        "_has_work_entries": bool(work_entries),
    }


# ── company history (the SAME runs experience is counted from) ───────────────────

def work_roles(
    entries: List[Dict[str, Any]], today_idx: int, config: Dict[str, float]
) -> List[Dict[str, Any]]:
    """Company-history rows for every role inside a qualifying continuous run.

    Returns ``[{role, company, months}]`` most-recent-first. Because it reads the SAME
    :func:`_work_runs` output the experience total is built from, a short role that is
    part of a continuous tenure (e.g. a 5-month stint immediately before a longer role at
    the same employer) is shown here too — it is no longer dropped just for being under
    the standalone-qualifying floor. Entries with unplaceable dates are dropped, exactly
    as they are from the experience total.
    """
    runs, _ = _work_runs(entries, today_idx, config)

    rows: List[Dict[str, Any]] = []
    for run in runs:
        if not run["qualifying"]:
            continue
        for iv, e in run["members"]:
            role = (str(e.get("title") or "").strip()) or None
            company = (str(e.get("organization") or "").strip()) or None
            if not role and not company:
                continue
            rows.append({
                "role": role,
                "company": company,
                "months": iv["end"] - iv["start"],
                "_start": iv["start"],
            })

    # Most recent first; drop the internal sort key before returning.
    rows.sort(key=lambda r: r["_start"], reverse=True)
    return [{"role": r["role"], "company": r["company"], "months": r["months"]} for r in rows]


# ── career gap (independent of experience) ───────────────────────────────────────

def compute_gap(
    entries: List[Dict[str, Any]], today_idx: int, config: Dict[str, float]
) -> Dict[str, Any]:
    """Career gap = breaks between consecutive dated activities, AFTER studies end.

    Education participates only when configured (enabling the education→first-job gap).
    A break that closes at or before the candidate finished their highest education is a
    normal study-phase transition — school→college, a term between degrees, or an
    internship taken mid-degree — NOT a career gap; only breaks after studies (the classic
    education→first-job gap and any later inter-job gap) count. Unknown-date boundaries are
    never counted as a gap and never assumed to be no-gap.
    """
    include_education = config.get("gap_include_education", 1.0) > 0
    gap_min = int(config.get("gap_min_months", 3.0))

    relevant: List[Dict[str, Any]] = []
    unknown_boundaries = 0
    # The latest month the candidate was still studying. Taken from education END dates
    # alone (a degree with a missing start still tells us when studies ended), and from a
    # 'pursuing'/open-ended degree it resolves to today — so study-phase breaks are
    # suppressed even when the full education interval can't be placed on the timeline.
    last_education_end: Optional[int] = None
    for e in entries:
        atype = _normalize_type(e.get("activity_type"))
        is_education = atype in _EDUCATION_TYPES
        if is_education:
            if bool(e.get("is_current")) or is_open_ended(e.get("end_date")):
                edu_end: Optional[int] = today_idx
            else:
                edu_end, _ = _to_month_index(e.get("end_date"), is_end=True)
            if edu_end is not None:
                last_education_end = (
                    edu_end if last_education_end is None else max(last_education_end, edu_end)
                )
        if is_education and not include_education:
            continue
        iv = _interval(e, today_idx)
        if iv is None:
            # A dated activity we could not place: its surrounding breaks are unknown.
            if e.get("start_date") or e.get("end_date"):
                unknown_boundaries += 1
            continue
        relevant.append(iv)

    merged = _merge(relevant)
    ranges: List[Dict[str, Any]] = []
    for prev, nxt in zip(merged, merged[1:]):
        gap = nxt[0] - prev[1]
        # Skip study-phase breaks: a gap that ends (the next activity begins) at or before
        # the candidate's highest-education completion is a normal student transition.
        if last_education_end is not None and nxt[0] <= last_education_end:
            continue
        if gap >= gap_min:
            ranges.append({
                "from": _month_to_iso(prev[1]),
                "to": _month_to_iso(nxt[0]),
                "months": gap,
            })

    total = sum(r["months"] for r in ranges)
    return {
        "gap_months": total,
        "gap_count": len(ranges),
        "gap_ranges": ranges,
        "careergap": _gap_label(total, len(ranges)),
        # 'partial' when an activity could not be placed (missing/unclear date) so a break
        # around it is unknown — the narrative must say gap detection is partial, not "none".
        "gap_method": "partial" if unknown_boundaries else "computed",
        "_unknown_boundaries": unknown_boundaries,
    }


def _gap_label(total_months: int, count: int) -> str:
    """Compact human-facing career-gap string (the legacy ``careergap`` column)."""
    if count == 0:
        return "None"
    if total_months >= 12:
        duration = f"{total_months / 12.0:.1f} years"
    else:
        duration = f"{total_months} month{'s' if total_months != 1 else ''}"
    return f"{count} gaps · {duration}" if count > 1 else duration


# ── public entry point ───────────────────────────────────────────────────────────

def compute(
    timeline_entries: Any,
    today: Optional[date] = None,
    config: Optional[Dict[str, float]] = None,
) -> Dict[str, Any]:
    """Compute gap and experience INDEPENDENTLY from a structured timeline.

    ``timeline_entries`` is the list of LLM-extracted dated activities. Returns a flat
    dict carrying both result sets plus ``fresher_or_lateral`` (None when experience is
    indeterminate, so the caller can keep the model's value). The two halves are computed
    by separate functions over copies of the list — they never read each other's output.
    """
    today = today or current_date()
    config = config or default_config()
    entries = [e for e in (timeline_entries or []) if isinstance(e, dict)]
    today_idx = _today_index(today)

    exp = compute_experience(list(entries), today_idx, config)
    gap = compute_gap(list(entries), today_idx, config)
    roles = work_roles(list(entries), today_idx, config)

    # fresher/lateral derives ONLY from the (independent) experience result; left None
    # when experience is indeterminate so the caller keeps the LLM's classification.
    if exp["experience_months"] > 0:
        fresher_or_lateral: Optional[str] = "Lateral"
    elif not exp["_has_work_entries"]:
        fresher_or_lateral = "Fresher"
    else:
        fresher_or_lateral = None  # work entries but 0/unknown — don't overwrite

    out: Dict[str, Any] = {
        "experience_months": exp["experience_months"],
        "yearofexp": exp["yearofexp"],
        "experience_method": exp["experience_method"],
        "experience_confidence": exp["experience_confidence"],
        "gap_months": gap["gap_months"],
        "gap_count": gap["gap_count"],
        "gap_ranges": gap["gap_ranges"],
        "gap_method": gap["gap_method"],
        "careergap": gap["careergap"],
        "fresher_or_lateral": fresher_or_lateral,
        # Company history derived from the SAME qualifying work entries the experience
        # total is built from — so the displayed roles always reconcile with yearofexp.
        "work_roles": roles,
    }
    return out


# ── narrative reconciliation (the analysis text can never contradict the signals) ──
#
# The AI analysis is produced by the LLM, but the computed gap/experience signals are the
# source of truth. ``reconcile_analysis`` drops any sentence in the narrative that
# contradicts the computed facts and appends an authoritative, deterministic statement —
# so a card can never read "no career gaps" while the engine reports a gap.

_NO_GAP_PHRASES = (
    "no career gap", "no employment gap", "no gaps", "no gap ", "no significant gap",
    "without gaps", "without any gap", "no break in employment", "continuous employment",
    "uninterrupted employment", "no career break", "no notable gap", "gap-free",
    "no evident gap", "no apparent gap", "no employment break", "shows no gap",
)
_HAS_GAP_PHRASES = (
    "career gap", "employment gap", "gap in employment", "career break",
    "break in employment", "gap of", "employment break", "gap between",
)
_EXP_RE = re.compile(r"(\d+(?:\.\d+)?)\s*\+?\s*years?")


def _split_sentences(text: str) -> List[str]:
    return [s for s in re.split(r"(?<=[.!?])\s+", text.strip()) if s.strip()]


def _contradicts(sentence: str, signals: Dict[str, Any]) -> bool:
    """True when a narrative sentence conflicts with the computed gap/experience facts."""
    low = sentence.lower()
    gap_count = signals.get("gap_count") or 0
    if gap_count > 0 and any(p in low for p in _NO_GAP_PHRASES):
        return True
    if gap_count == 0 and any(p in low for p in _HAS_GAP_PHRASES):
        return True
    # Years-of-experience figure that disagrees with the computed total (only when the
    # sentence is actually about experience and the computation is determinate).
    method = signals.get("experience_method")
    if "experien" in low and method in ("computed", "partial"):
        m = _EXP_RE.search(low)
        if m:
            try:
                claimed = float(m.group(1))
            except ValueError:
                claimed = None
            computed = signals.get("yearofexp")
            if claimed is not None and computed is not None and abs(claimed - computed) > 0.75:
                return True
    return False


def signal_statement(signals: Dict[str, Any]) -> str:
    """An authoritative, deterministic sentence pair stating the computed gap + experience.

    Follows the narrative contract: mention the gap when one exists, say no verified gap
    when none, and flag partial/inferred dates explicitly.
    """
    parts: List[str] = []

    gap_count = signals.get("gap_count") or 0
    gap_months = signals.get("gap_months") or 0
    gap_partial = signals.get("gap_method") == "partial"
    if gap_count > 0:
        s = (
            f"Verified timeline shows {gap_count} career gap"
            f"{'s' if gap_count != 1 else ''} totaling {gap_months} month"
            f"{'s' if gap_months != 1 else ''}"
        )
        # Only append the compact label when it carries extra detail (multi-gap form
        # "N gaps · X"); for a single gap it would just repeat the month count.
        label = signals.get("careergap")
        if gap_count > 1 and label:
            s += f" ({label})"
        s += "."
        if gap_partial:
            s += " Some activity dates were missing, so gap detection is partial."
        parts.append(s)
    else:
        if gap_partial:
            parts.append(
                "No verified career gap was detected, though some dates were missing so "
                "this is partial."
            )
        else:
            parts.append("No verified career gap is present in the dated timeline.")

    method = signals.get("experience_method")
    years = signals.get("yearofexp")
    months = signals.get("experience_months")
    if method == "unknown" or years is None:
        parts.append("Total work experience could not be verified from the available dates.")
    else:
        s = f"Verified experience: {years} years ({months} months) from work durations only."
        if method == "partial":
            s += " Based partly on year-only or incomplete dates."
        parts.append(s)

    return " ".join(parts)


def reconcile_analysis(analysis: Optional[str], signals: Dict[str, Any]) -> str:
    """Make the narrative consistent with the computed signals.

    Drops sentences that contradict the computed gap/experience facts and appends the
    authoritative :func:`signal_statement`. Paragraph breaks are preserved. Idempotent
    enough for one-shot extraction; returns the statement alone if the analysis is empty.
    """
    statement = signal_statement(signals)
    base = (analysis or "").strip()
    if not base:
        return statement

    out_paragraphs: List[str] = []
    for paragraph in base.split("\n\n"):
        kept = [s for s in _split_sentences(paragraph) if not _contradicts(s, signals)]
        cleaned = " ".join(kept).strip()
        if cleaned:
            out_paragraphs.append(cleaned)
    out_paragraphs.append(statement)
    return "\n\n".join(out_paragraphs)
