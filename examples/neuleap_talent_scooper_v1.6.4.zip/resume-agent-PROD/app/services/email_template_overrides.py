"""Editable BASE templates for the NBA ack-email drafts — Mailbox → Archives &
Interview Slots → "Email Base Templates".

The shipped defaults stay in code (app.services.email_templates._TEMPLATES);
this module holds recruiter-edited overrides per NBA key, JSON-file-backed
like every other runtime config. An override replaces the default subject/
body when a draft is generated (email_templates.render_draft); reverting is
just deleting the override.

Placeholders available in an override body:
  * ``{first_name}``                  — the candidate's first name ("there" when unknown)
  * ``[interview-slot-picker-link]``  — replaced with the real slot-picker link
                                        on the draft-review screen (same literal
                                        the shipped templates use)
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict

from app.logging_config import get_logger

log = get_logger(__name__)

# Human labels per template key — mirrors the NBA vocabulary used app-wide.
TEMPLATE_LABELS: Dict[str, str] = {
    "call_now": "Screening — share interview slots",
    "share_round1": "Round 1 — share interview slots",
    "share_round2": "Round 2 — share interview slots",
    "share_round3": "Round 3 — share interview slots",
    "final_round": "Final round (online) — share interview slots",
    "office_interview": "Final round (in-office) — share interview slots",
    "undecided": "Undecided — keep-on-file acknowledgement",
    # Reminder-cycle emails (sent per ROUND by the automatic reminder job —
    # {round_name} resolves to whichever round the reminder is for).
    "slot_reminder": "Reminder — slot-pick nudge (any round)",
    "slot_auto_reject": "Auto-reject — response window expired (any round)",
}

PLACEHOLDERS = [
    "{first_name}",
    "{round_name}",
    "{reminder_number}",
    "{reminder_total}",
    "{auto_reject_notice}",
    "[interview-slot-picker-link]",
]


def _path() -> Path:
    return Path(os.environ.get("EMAIL_TEMPLATE_OVERRIDES_FILE", "secrets/email_templates.json"))


def get() -> Dict[str, Dict[str, str]]:
    """Raw overrides: {nba_key: {"subject": ..., "body": ...}} — only the keys
    an admin actually customized appear here."""
    try:
        raw = json.loads(_path().read_text(encoding="utf-8"))
        if isinstance(raw, dict):
            return {
                k: {"subject": str(v.get("subject") or ""), "body": str(v.get("body") or "")}
                for k, v in raw.items()
                if k in TEMPLATE_LABELS and isinstance(v, dict)
            }
    except (OSError, ValueError):
        pass
    return {}


def defaults() -> Dict[str, Dict[str, str]]:
    """The shipped template text per key, with the literal ``{first_name}`` /
    ``{round_name}`` placeholders in place of real values — what the editor
    shows before any customization, and what "revert" goes back to."""
    from app.services import email_templates as et  # noqa: PLC0415 — avoid import cycle at module load

    out: Dict[str, Dict[str, str]] = {}
    for key in TEMPLATE_LABELS:
        if key == "slot_reminder":
            subject, body = et.slot_reminder_default(
                "{round_name}", "{first_name}", "[interview-slot-picker-link]",
                "{reminder_number}", "{reminder_total}",
            )
        elif key == "slot_auto_reject":
            subject, body = et.slot_auto_reject_default("{round_name}", "{first_name}")
        else:
            fn = et._TEMPLATES.get(key)  # noqa: SLF001 — same package, deliberate
            if not fn:
                continue
            subject, body = fn("{first_name}")
        out[key] = {"subject": subject, "body": body}
    return out


def save(key: str, subject: str, body: str) -> Dict[str, Any]:
    """Store (or clear) ONE template's override. Empty subject AND body →
    revert to the shipped default (the override is deleted)."""
    if key not in TEMPLATE_LABELS:
        raise ValueError(f"unknown template key {key!r}")
    subject = (subject or "").strip()
    body = (body or "").strip()
    data = get()
    base = defaults().get(key, {})
    # Saving text identical to the default is the same as reverting.
    if (not subject and not body) or (
        subject == base.get("subject", "").strip() and body == base.get("body", "").strip()
    ):
        data.pop(key, None)
    else:
        if not subject or not body:
            raise ValueError("Both subject and body are required (or clear both to revert to the default).")
        data[key] = {"subject": subject, "body": body}
    path = _path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        log.info("email_template_overrides: saved %s (%s)", key, "customized" if key in data else "reverted")
    except OSError as exc:  # noqa: BLE001
        log.warning("email_template_overrides: could not write %s: %s", path, exc)
    return effective_for(key)


def effective_for(key: str) -> Dict[str, Any]:
    ov = get().get(key)
    base = defaults().get(key, {"subject": "", "body": ""})
    return {
        "key": key,
        "label": TEMPLATE_LABELS[key],
        "subject": (ov or base)["subject"],
        "body": (ov or base)["body"],
        "is_customized": ov is not None,
    }


def list_effective() -> list[Dict[str, Any]]:
    """Every template in a stable, flow-ordered list — default text merged
    with any override, flagged so the UI can show a "customized" badge."""
    return [effective_for(k) for k in TEMPLATE_LABELS]
