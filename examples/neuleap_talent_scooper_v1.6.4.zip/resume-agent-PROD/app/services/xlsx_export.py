"""Shared Excel (.xlsx) export builder with type-aware cell guarding.

One place that turns a list of dict rows into a styled, correctly-typed workbook so
every export in the app (batch candidates, audit logs, …) reads cleanly in Excel:

  * ``text``     — forced to Excel TEXT (number_format ``@``). Use for email, phone,
                   and IDs so Excel never sci-notations a long number, drops a leading
                   ``+``/``0``, or reinterprets the value. Stored as a string cell, so
                   it is also immune to CSV-style formula injection.
  * ``int`` /
    ``float``    — real numeric cells (right-aligned, sortable, summable).
  * ``date`` /
    ``datetime`` — real Excel date cells with a date number format (parsed from a
                   ``datetime``/``date`` object or an ISO-8601 string).
  * ``json``     — dict/list serialized to compact JSON text (job_roles, certificates…).
  * ``auto``     — passthrough: numbers stay numbers, everything else becomes ``str``.

Returns the workbook as ``bytes`` ready to stream in a FastAPI ``Response``.
"""
from __future__ import annotations

import io
import json
from datetime import date, datetime
from typing import Any, Iterable, Literal, NamedTuple, Sequence

from openpyxl import Workbook
from openpyxl.formatting.rule import ColorScaleRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

ColumnKind = Literal[
    "text", "int", "float", "date", "datetime", "json", "list", "auto"
]

_DATE_FMT = "yyyy-mm-dd"
_DATETIME_FMT = "yyyy-mm-dd hh:mm:ss"
_TEXT_FMT = "@"
_HEADER_FILL = PatternFill("solid", fgColor="1F2937")  # slate-800
_HEADER_FONT = Font(bold=True, color="FFFFFF")
_MAX_WIDTH = 60  # cap auto-sized column width so a JSON blob can't blow out the sheet

# ── Visual polish ─────────────────────────────────────────────────────────────
_THIN = Side(style="thin", color="D1D5DB")  # gray-300
_BORDER = Border(left=_THIN, right=_THIN, top=_THIN, bottom=_THIN)
_ZEBRA_FILL = PatternFill("solid", fgColor="F8FAFC")  # slate-50 — alternating rows
_TOP_ALIGN = Alignment(vertical="top")
_HEADER_ALIGN = Alignment(vertical="center")

# Recruiter status → row-cell tint, so a Hired/Rejected verdict is scannable.
_STATUS_FILLS = {
    "hired": PatternFill("solid", fgColor="D1FAE5"),              # emerald-100
    "rejected": PatternFill("solid", fgColor="FEE2E2"),           # red-100
    "closed": PatternFill("solid", fgColor="FEE2E2"),
    "active": PatternFill("solid", fgColor="DBEAFE"),             # blue-100
    "screened": PatternFill("solid", fgColor="DBEAFE"),
    "pending extraction": PatternFill("solid", fgColor="FEF3C7"), # amber-100
    "manual review": PatternFill("solid", fgColor="FEF3C7"),
}

# A 0→100 red-amber-green wash for a score column (e.g. ATS score).
_SCORE_RULE = ColorScaleRule(
    start_type="num", start_value=0, start_color="FCA5A5",   # red-300
    mid_type="num", mid_value=50, mid_color="FDE68A",        # amber-200
    end_type="num", end_value=100, end_color="86EFAC",       # green-300
)


class Column(NamedTuple):
    """One export column: the dict key to read, the header text, its cell kind, and
    whether long values should wrap (for free-text columns like Analysis)."""

    field: str
    header: str
    kind: ColumnKind = "auto"
    wrap: bool = False


def _coerce_date(value: Any) -> Any:
    """Return a date/datetime for a real Excel date cell, or the original on failure."""
    if isinstance(value, (datetime, date)):
        return value
    if isinstance(value, str) and value.strip():
        text = value.strip().replace("Z", "+00:00")
        try:
            return datetime.fromisoformat(text)
        except ValueError:
            return value
    return None


def _render_dict(item: dict[str, Any]) -> str:
    """One dict → a compact readable entry, dropping empty values.

    e.g. {role:'Data Engineer', company:'Acme', months:18} → 'Data Engineer · Acme · 18 mo'
         {name:'AWS SA', issuer:'Amazon', year:2022}       → 'AWS SA · Amazon · 2022'
    Unknown shapes fall back to 'value · value' over their non-empty fields.
    """
    parts: list[str] = []
    for v in item.values():
        if v is None or v == "":
            continue
        parts.append(str(v))
    return " · ".join(parts)


def _render_list(value: Any) -> Any:
    """Flatten a list into readable text; non-list values pass through unchanged."""
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        out: list[str] = []
        for item in value:
            if item is None or item == "":
                continue
            if isinstance(item, dict):
                rendered = _render_dict(item)
                if rendered:
                    out.append(rendered)
            else:
                out.append(str(item))
        # Join on a single line so rows stay one line tall (no wrap / no newlines):
        # dict entries are separated with " | ", flat values with ", ".
        sep = " | " if any(isinstance(i, dict) for i in value) else ", "
        return sep.join(out) if out else None
    if isinstance(value, dict):
        return _render_dict(value) or None
    return str(value)


def _apply(cell: Any, value: Any, kind: ColumnKind) -> None:
    """Write ``value`` into ``cell`` honouring its column kind (type + guarding)."""
    if value is None or value == "":
        cell.value = None
        return

    if kind == "text":
        cell.value = str(value)
        cell.number_format = _TEXT_FMT
        return

    if kind in ("date", "datetime"):
        coerced = _coerce_date(value)
        if isinstance(coerced, (datetime, date)):
            cell.value = coerced
            cell.number_format = _DATETIME_FMT if kind == "datetime" else _DATE_FMT
        else:
            cell.value = str(value)  # unparseable → keep the raw text, don't lie
        return

    if kind == "int":
        try:
            cell.value = int(float(value))
        except (TypeError, ValueError):
            cell.value = str(value)
        return

    if kind == "float":
        try:
            cell.value = float(value)
        except (TypeError, ValueError):
            cell.value = str(value)
        return

    if kind == "json":
        if isinstance(value, (dict, list)):
            cell.value = json.dumps(value, ensure_ascii=False, default=str)
        else:
            cell.value = str(value)
        return

    if kind == "list":
        # Human-readable rendering of a list: scalars joined by ", ", and a list of
        # dicts rendered one "key: value · …" entry per line. Plain strings pass
        # through. Falls back to JSON only for shapes it can't flatten.
        cell.value = _render_list(value)
        return

    # auto: keep native numbers/bools as-is, JSON-ify containers, else stringify.
    if isinstance(value, (int, float, bool)):
        cell.value = value
    elif isinstance(value, (dict, list)):
        cell.value = json.dumps(value, ensure_ascii=False, default=str)
    else:
        cell.value = str(value)


def _col_display_width(value: Any) -> int:
    """Longest single line of a cell value — so a wrapped multi-line cell sizes to its
    widest line, not the sum of all lines."""
    return max((len(part) for part in str(value).split("\n")), default=0)


def _write_sheet(
    ws: Any,
    columns: Sequence[Column],
    rows: Iterable[dict[str, Any]],
    *,
    zebra: bool = True,
    status_field: str | None = None,
    score_field: str | None = None,
) -> None:
    """Render header + type-guarded rows onto ``ws`` (styled, frozen, autofiltered).

    Visual polish: thin cell borders, alternating zebra row tint, single-line cells
    (no wrap, so rows stay one line tall), a recruiter-status colour tint on
    ``status_field``, and a 0→100 red-amber-green colour scale on ``score_field``.
    """
    # Header row: bold, filled, frozen, bordered, with an autofilter.
    for col_idx, column in enumerate(columns, start=1):
        cell = ws.cell(row=1, column=col_idx, value=column.header)
        cell.font = _HEADER_FONT
        cell.fill = _HEADER_FILL
        cell.alignment = _HEADER_ALIGN
        cell.border = _BORDER

    widths = [len(c.header) for c in columns]
    last_row = 1
    for row_idx, record in enumerate(rows, start=2):
        last_row = row_idx
        zebra_row = zebra and row_idx % 2 == 0
        for col_idx, column in enumerate(columns, start=1):
            cell = ws.cell(row=row_idx, column=col_idx)
            _apply(cell, record.get(column.field), column.kind)
            cell.border = _BORDER
            cell.alignment = _TOP_ALIGN
            # Status tint wins over the zebra tint on the status cell.
            fill = None
            if status_field and column.field == status_field and cell.value is not None:
                fill = _STATUS_FILLS.get(str(cell.value).strip().lower())
            if fill is None and zebra_row:
                fill = _ZEBRA_FILL
            if fill is not None:
                cell.fill = fill
            if cell.value is not None:
                widths[col_idx - 1] = max(widths[col_idx - 1], _col_display_width(cell.value))

    for col_idx, width in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(col_idx)].width = min(width + 2, _MAX_WIDTH)

    # 0→100 colour scale on the score column (only when there are data rows).
    if score_field and last_row >= 2:
        for col_idx, column in enumerate(columns, start=1):
            if column.field == score_field:
                letter = get_column_letter(col_idx)
                ws.conditional_formatting.add(f"{letter}2:{letter}{last_row}", _SCORE_RULE)
                break

    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(columns))}{last_row}"


class Sheet(NamedTuple):
    """One worksheet in a multi-sheet workbook: tab name, columns, rows, and optional
    presentation hints (status-tinted column, colour-scaled score column)."""

    name: str
    columns: Sequence[Column]
    rows: Sequence[dict[str, Any]]
    status_field: str | None = None
    score_field: str | None = None


def build_xlsx(
    columns: Sequence[Column],
    rows: Iterable[dict[str, Any]],
    *,
    sheet_name: str = "Export",
) -> bytes:
    """Build a styled, type-guarded single-sheet workbook and return it as ``bytes``."""
    wb = Workbook()
    ws = wb.active
    ws.title = sheet_name[:31] or "Export"  # Excel caps sheet names at 31 chars
    _write_sheet(ws, columns, rows)

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def build_xlsx_multi(sheets: Sequence[Sheet]) -> bytes:
    """Build a workbook with one tab per :class:`Sheet`, returned as ``bytes``.

    Each sheet is independently styled/typed. An empty ``sheets`` (or sheets with no
    rows) still produces a valid workbook with just the header rows.
    """
    wb = Workbook()
    for i, sheet in enumerate(sheets):
        ws = wb.active if i == 0 else wb.create_sheet()
        ws.title = (sheet.name[:31] or f"Sheet{i + 1}")  # Excel caps tab names at 31
        _write_sheet(
            ws, sheet.columns, sheet.rows,
            status_field=sheet.status_field, score_field=sheet.score_field,
        )

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


XLSX_MEDIA_TYPE = (
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
)
