"""Referral classification — Settings → Referrals.

A candidate is a REFERRAL when the resume arrived from a sender address on the
configured allow-list: either an exact email, or any address under a configured
domain. The "referred by" is normally that sender address
(email_master.sender_mail_id, surfaced on the candidate detail as
``source_mail_id``).

Each entry (email OR domain) carries:
  * ``message``        — the clip message shown on the candidate page (may be "").
  * ``subject_pattern`` — OPTIONAL. When set, the actual referrer is extracted
    from the email SUBJECT instead of using the sender address. The pattern is
    the subject STYLE with a ``<Sender>`` placeholder marking where the
    referrer's name sits, e.g. "Referral by <Sender>" or
    "<Sender> referred this candidate". If the subject matches, ``referred_by``
    becomes the extracted name; otherwise it falls back to the sender address.

An exact-email entry wins over a domain entry.

Stored as a JSON file in the bind-mounted ``secrets/`` dir. Config, not
candidate data.

Config shape::

    {"emails":  [{"value": "hr@acme.com", "message": "...", "subject_pattern": "Referral by <Sender>"}, ...],
     "domains": [{"value": "acme.com",    "message": "...", "subject_pattern": ""}, ...]}
"""
from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

from app.logging_config import get_logger

log = get_logger(__name__)

# The placeholder that marks the referrer's position in a subject pattern.
_SENDER_TOKEN = re.compile(r"<\s*sender\s*>", re.IGNORECASE)


def _path() -> Path:
    return Path(os.environ.get("REFERRAL_CONFIG_FILE", "secrets/referral_config.json"))


def _norm_email(v: str) -> str:
    return (v or "").strip().lower()


def _norm_domain(v: str) -> str:
    # Accept "@acme.com", "acme.com", "ACME.com " → "acme.com".
    return (v or "").strip().lower().lstrip("@")


def _clean_entries(raw: Any, norm, *, legacy_message: str = "") -> List[Dict[str, str]]:
    """Normalize a list of entries to ``[{value, message, subject_pattern}]``,
    de-duped by value. Accepts the legacy shapes: a list of plain strings, or
    entries without ``subject_pattern`` — each keeps/adopts sensible defaults."""
    out: Dict[str, Dict[str, str]] = {}
    for item in raw or []:
        if isinstance(item, str):
            value, message, pattern = norm(item), legacy_message, ""
        elif isinstance(item, dict):
            value = norm(item.get("value", ""))
            message = str(item.get("message") or "").strip()[:500]
            pattern = str(item.get("subject_pattern") or "").strip()[:200]
        else:
            continue
        if value:
            out[value] = {"value": value, "message": message, "subject_pattern": pattern}
    return [out[v] for v in sorted(out)]


def get() -> Dict[str, Any]:
    out: Dict[str, Any] = {"emails": [], "domains": []}
    try:
        raw = json.loads(_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return out
    if isinstance(raw, dict):
        legacy_msg = str(raw.get("message") or "").strip()[:500]
        out["emails"] = _clean_entries(raw.get("emails"), _norm_email, legacy_message=legacy_msg)
        out["domains"] = _clean_entries(raw.get("domains"), _norm_domain, legacy_message=legacy_msg)
    return out


def save(payload: Dict[str, Any]) -> Dict[str, Any]:
    emails = _clean_entries(payload.get("emails"), _norm_email)
    domains = _clean_entries(payload.get("domains"), _norm_domain)
    bad_email = next((e["value"] for e in emails if "@" not in e["value"]), None)
    if bad_email:
        raise ValueError(f"'{bad_email}' isn't a valid email address.")
    bad_domain = next((d["value"] for d in domains if "." not in d["value"] or "@" in d["value"]), None)
    if bad_domain:
        raise ValueError(f"'{bad_domain}' isn't a valid domain (e.g. neuleap.ai).")
    # A subject pattern must contain the <Sender> placeholder to be useful.
    bad_pat = next(
        (e["value"] for e in [*emails, *domains]
         if e["subject_pattern"] and not _SENDER_TOKEN.search(e["subject_pattern"])),
        None,
    )
    if bad_pat:
        raise ValueError(
            f"The subject pattern for '{bad_pat}' must include a <Sender> placeholder "
            "(e.g. \"Referral by <Sender>\")."
        )
    data = {"emails": emails, "domains": domains}
    path = _path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        log.info("referral_config: saved %s (%d emails, %d domains)", path, len(emails), len(domains))
    except OSError as exc:  # noqa: BLE001
        log.warning("referral_config: could not write %s: %s", path, exc)
    return get()


def _extract_referrer(pattern: str, subject: Optional[str]) -> Optional[str]:
    """Pull the referrer name out of ``subject`` per ``pattern`` — the subject
    style with a ``<Sender>`` placeholder. Returns the trimmed capture, or None
    when the pattern has no placeholder or the subject doesn't match."""
    subj = (subject or "").strip()
    if not subj or not pattern or not _SENDER_TOKEN.search(pattern):
        return None
    left, right = _SENDER_TOKEN.split(pattern, maxsplit=1)
    left, right = left.strip(), right.strip()
    if right:
        rx = re.escape(left) + r"\s*(.+?)\s*" + re.escape(right)
    else:
        rx = re.escape(left) + r"\s*(.+?)\s*$"
    m = re.search(rx, subj, re.IGNORECASE)
    if not m:
        return None
    name = m.group(1).strip(" \t-–—:;,")
    return name or None


def classify(
    sender_email: Optional[str],
    subject: Optional[str] = None,
    cfg: Optional[Dict[str, Any]] = None,
) -> Optional[Dict[str, Any]]:
    """Referral info for a candidate whose resume came from ``sender_email``
    with email ``subject``. Returns ``{"referred_by", "message", "from_subject"}``
    when the sender qualifies, else ``None``.

    A ``subject_pattern`` on an entry acts as a GATE: when it's set, the sender
    only counts as a referral if the subject matches it — and ``referred_by``
    becomes the name extracted from the subject (``from_subject`` True). When an
    entry has no pattern, the sender match alone qualifies and ``referred_by``
    is the sender address. Entries are tried in precedence order (exact email,
    then domain); a specific entry whose subject gate fails falls through to a
    less-specific one that qualifies (e.g. an email rule requiring a subject
    format falls through to an ungated domain rule)."""
    email = _norm_email(sender_email or "")
    if not email or "@" not in email:
        return None
    c = cfg if cfg is not None else get()

    def _qualify(entry: Dict[str, str]) -> Optional[Dict[str, Any]]:
        pattern = entry.get("subject_pattern", "")
        if pattern:
            extracted = _extract_referrer(pattern, subject)
            if not extracted:
                return None  # gated: subject didn't match → not a referral via this entry
            return {"referred_by": extracted, "message": entry.get("message") or "", "from_subject": True}
        return {"referred_by": sender_email, "message": entry.get("message") or "", "from_subject": False}

    for entry in c.get("emails", []):
        if entry["value"] == email:
            r = _qualify(entry)
            if r:
                return r
            break  # the exact-email rule matched the sender but its gate failed
    domain = email.split("@", 1)[1]
    for entry in c.get("domains", []):
        if entry["value"] == domain:
            r = _qualify(entry)
            if r:
                return r
            break
    return None
