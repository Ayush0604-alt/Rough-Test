"""Upgrade trust config — the Ed25519 PUBLIC key used to verify uploaded bundles,
and whether an unsigned bundle is allowed. Set in Settings → System Upgrade
(System Admin). The private signing key never touches the server — it lives on
the build machine and is used by scripts/sign_bundle.py.

Stored as JSON in the bind-mounted ``secrets/`` dir. The public key is not a
secret, so it's returned as-is.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict

from app.logging_config import get_logger

log = get_logger(__name__)

DEFAULT: Dict[str, Any] = {
    "public_key": "",          # Ed25519 public key in PEM
    "require_signature": False, # reject unsigned bundles even if no key is set
}


def _path() -> Path:
    return Path(os.environ.get("UPGRADE_CONFIG_FILE", "secrets/upgrade_config.json"))


def get() -> Dict[str, Any]:
    try:
        saved = json.loads(_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        saved = {}
    return {**DEFAULT, **saved}


def save(cfg: Dict[str, Any]) -> Dict[str, Any]:
    merged = {**get(), **(cfg or {})}
    merged["public_key"] = (merged.get("public_key") or "").strip()
    merged["require_signature"] = bool(merged.get("require_signature"))
    path = _path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(merged, indent=2), encoding="utf-8")
    except OSError as exc:  # noqa: BLE001
        log.warning("upgrade_config: could not write %s: %s", path, exc)
    return merged
