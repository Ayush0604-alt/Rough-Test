"""Interview-slot-picker link API — settings for the external service that
returns a scheduling link for a candidate + round, embedded into the "Let's
schedule your interview" email draft.

JSON-file-backed, like chatbot_widget_config, so an Admin can point this at a
real endpoint (and override the recipient email for QA testing) from Settings
without a redeploy. `param_round`/`param_name`/`param_email` are the request
key names the external API expects — configurable since that vocabulary is up
to whatever service is wired in, not something this app controls.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict

from app.logging_config import get_logger

log = get_logger(__name__)

_DEFAULTS: Dict[str, Any] = {
    "api_url": "",
    "param_round": "round",
    "param_name": "candidate_name",
    "param_email": "email",
    # QA override — when set, sent as the email param instead of the
    # candidate's real address (so a test run never emails a real candidate).
    "override_email": "",
}


def _path() -> Path:
    return Path(os.environ.get("INTERVIEW_SLOT_CONFIG_FILE", "secrets/interview_slot_config.json"))


def get() -> Dict[str, Any]:
    try:
        raw = json.loads(_path().read_text(encoding="utf-8"))
        if isinstance(raw, dict):
            return {**_DEFAULTS, **{k: raw[k] for k in _DEFAULTS if k in raw}}
    except (OSError, ValueError):
        pass
    return dict(_DEFAULTS)


def save(data: Dict[str, Any]) -> Dict[str, Any]:
    """Persist the config. Writing never raises — a disk hiccup just keeps the
    old value in effect rather than breaking the save request."""
    merged = {**_DEFAULTS, **{k: data[k] for k in _DEFAULTS if k in data}}
    path = _path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(merged, indent=2), encoding="utf-8")
        log.info("interview_slot_config: saved %s", path)
    except OSError as exc:  # noqa: BLE001
        log.warning("interview_slot_config: could not write %s: %s", path, exc)
    return get()
