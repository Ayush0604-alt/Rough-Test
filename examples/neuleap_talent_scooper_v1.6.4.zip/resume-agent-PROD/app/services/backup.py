"""Backup & Disaster-Recovery engine.

A **full** backup = a compressed logical dump of PostgreSQL (``pg_dump -Fc``) PLUS
a snapshot of both MinIO buckets (raw + resume) PLUS the system CONFIGURATION
(the whole ``secrets/`` dir — all UI settings, keys, config JSON/env), so a full
set restores the WHOLE system, not just data. An **incremental** = the DB dump
only (small + frequent; files + config change far less often and are captured by
the weekly full). Each set is written to the primary dir, then copied to the optional
mounted/NAS secondary and pushed to the optional S3-compatible cloud target, so
there are always ≥2 full sets in different places. Retention prunes old sets.

Layout under the primary dir::

    backups/full/full_<UTCstamp>/{db.dump, minio_raw.tar.gz, minio_resume.tar.gz, config.tar.gz, manifest.json}
    backups/incremental/incr_<UTCstamp>/{db.dump, manifest.json}

Everything is best-effort and heavily logged; a copy/cloud failure never loses
the primary backup — it's recorded in the manifest's ``targets`` status instead.
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import shutil
import subprocess
import tarfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from app.logging_config import get_logger
from app.services import backup_config

log = get_logger(__name__)

APP_VERSION = os.environ.get("APP_VERSION", "")  # stamped into manifests when set


# ── paths ────────────────────────────────────────────────────────────────────
def _primary_dir() -> Path:
    return Path(os.environ.get("BACKUP_PRIMARY_DIR", "/app/backups"))


def _stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def _kind_dir(base: Path, kind: str) -> Path:
    d = base / ("full" if kind == "full" else "incremental")
    d.mkdir(parents=True, exist_ok=True)
    return d


# ── postgres dump / restore ──────────────────────────────────────────────────
def _pg_env() -> dict:
    env = dict(os.environ)
    env["PGPASSWORD"] = os.environ.get("PG_PASSWORD", "")
    return env


def _pg_args() -> list[str]:
    return [
        "-h", os.environ.get("PG_HOST", "postgres"),
        "-p", os.environ.get("PG_PORT", "5432"),
        "-U", os.environ.get("PG_USER", "resume_user"),
        "-d", os.environ.get("PG_DATABASE", "resume_db"),
    ]


def _pg_dump(dest: Path) -> int:
    """Write a custom-format dump to ``dest``. Returns the file size in bytes."""
    subprocess.run(
        ["pg_dump", *_pg_args(), "-Fc", "--no-owner", "--no-privileges", "-f", str(dest)],
        env=_pg_env(), check=True, capture_output=True, timeout=1800,
    )
    return dest.stat().st_size


def _pg_restore(dump: Path) -> None:
    subprocess.run(
        ["pg_restore", *_pg_args(), "--clean", "--if-exists", "--no-owner",
         "--no-privileges", str(dump)],
        env=_pg_env(), check=False, capture_output=True, timeout=1800,
    )


# ── minio snapshot / restore ─────────────────────────────────────────────────
def _snapshot_bucket(raw: bool, out_tar: Path) -> int:
    """Tar every object in a bucket, member name == object key. Streams one
    object at a time to bound memory. Returns the object count."""
    from app.services.s3 import s3

    svc = s3()
    keys = svc.list_keys("", raw=raw)
    with tarfile.open(out_tar, "w:gz") as tar:
        for key in keys:
            data = svc.get_bytes(key, raw=raw)
            info = tarfile.TarInfo(name=key)
            info.size = len(data)
            tar.addfile(info, io.BytesIO(data))
    return len(keys)


def _restore_bucket(raw: bool, tar_path: Path) -> int:
    from app.services.s3 import s3

    if not tar_path.exists():
        return 0
    svc = s3()
    n = 0
    with tarfile.open(tar_path, "r:gz") as tar:
        for member in tar.getmembers():
            if not member.isfile():
                continue
            f = tar.extractfile(member)
            if f is None:
                continue
            svc.put_bytes(member.name, f.read(), raw=raw)
            n += 1
    return n


# ── configuration snapshot / restore ─────────────────────────────────────────
def _config_dir() -> Path:
    # All UI-managed configuration (columns, pipeline/scoring/notification env,
    # upgrade + backup config, interview settings, keys) lives under secrets/.
    return Path(os.environ.get("SECRETS_DIR", "secrets"))


def _snapshot_config(out_tar: Path) -> dict:
    """Tar the whole secrets/ dir so a FULL backup captures system CONFIGURATION,
    not just data + files — restored by _restore_config. Returns {files, bytes}."""
    src = _config_dir()
    n = 0
    with tarfile.open(out_tar, "w:gz") as tar:
        if src.exists():
            for p in sorted(src.rglob("*")):
                if p.is_file():
                    tar.add(p, arcname=str(p.relative_to(src)))
                    n += 1
    return {"files": n, "bytes": out_tar.stat().st_size}


def _restore_config(tar_path: Path) -> int:
    """Restore secrets/ (all configuration) from a full backup's config.tar.gz,
    overwriting config files in place. Returns the file count restored."""
    if not tar_path.exists():
        return 0
    dest = _config_dir()
    dest.mkdir(parents=True, exist_ok=True)
    n = 0
    with tarfile.open(tar_path, "r:gz") as tar:
        for m in tar.getmembers():
            if not m.isfile():
                continue
            name = os.path.normpath(m.name).replace("\\", "/")
            if name.startswith("/") or name.startswith("../") or ".." in name.split("/"):
                continue  # never escape secrets/
            f = tar.extractfile(m)
            if f is None:
                continue
            target = dest / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(f.read())
            n += 1
    return n


def _reload_config_into_app() -> None:
    """Re-read the restored config files into the running process so a restore
    takes effect live (mirrors POST /settings/reload)."""
    try:
        from app.services import notify_config, pipeline_config, scoring_config

        for mod in (pipeline_config, notify_config, scoring_config):
            try:
                mod.load()
            except Exception:  # noqa: BLE001 — best-effort live reload
                pass
    except Exception:  # noqa: BLE001
        pass


# ── helpers ──────────────────────────────────────────────────────────────────
def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _dir_size(path: Path) -> int:
    return sum(p.stat().st_size for p in path.rglob("*") if p.is_file())


def _copy_to_secondary(cfg: dict, src: Path, kind: str, backup_id: str) -> dict:
    dest_base = (cfg.get("secondary_dir") or "").strip()
    if not dest_base:
        return {"status": "skipped", "detail": "no secondary path configured"}
    try:
        dest = Path(dest_base) / ("full" if kind == "full" else "incremental") / backup_id
        if dest.exists():
            shutil.rmtree(dest)
        shutil.copytree(src, dest)
        return {"status": "ok", "path": str(dest)}
    except Exception as exc:  # noqa: BLE001
        log.warning("backup: secondary copy failed: %s", exc)
        return {"status": "failed", "detail": str(exc)}


def _cloud_client(cloud: dict):
    import boto3

    kwargs: dict = {
        "aws_access_key_id": cloud.get("access_key"),
        "aws_secret_access_key": cloud.get("secret_key"),
    }
    if cloud.get("region"):
        kwargs["region_name"] = cloud["region"]
    if (cloud.get("endpoint") or "").strip():
        kwargs["endpoint_url"] = cloud["endpoint"].strip()
    return boto3.client("s3", **kwargs)


def _upload_to_cloud(cfg: dict, src: Path, kind: str, backup_id: str) -> dict:
    cloud = cfg.get("cloud") or {}
    if not cloud.get("enabled") or not cloud.get("bucket"):
        return {"status": "skipped", "detail": "cloud target not enabled"}
    try:
        client = _cloud_client(cloud)
        prefix = (cloud.get("prefix") or "").strip("/")
        base_key = "/".join(filter(None, [prefix, "full" if kind == "full" else "incremental", backup_id]))
        for f in src.iterdir():
            if f.is_file():
                client.upload_file(str(f), cloud["bucket"], f"{base_key}/{f.name}")
        return {"status": "ok", "path": f"s3://{cloud['bucket']}/{base_key}"}
    except Exception as exc:  # noqa: BLE001
        log.warning("backup: cloud upload failed: %s", exc)
        return {"status": "failed", "detail": str(exc)}


def _notify_recipients(cfg: dict) -> list[str]:
    raw = (cfg.get("notify_emails") or "").strip()
    if raw:
        return [e.strip() for e in raw.split(",") if e.strip()]
    try:
        from app.services import notify_config
        r = notify_config.recipient()
        return [r] if r else []
    except Exception:  # noqa: BLE001
        return []


def _notify_failure(cfg: dict, kind: str, manifest: dict) -> None:
    """Best-effort email when a backup fails (Settings → Backup → notify on failure)."""
    if not cfg.get("notify_on_failure"):
        return
    recipients = _notify_recipients(cfg)
    if not recipients:
        return
    try:
        from app.services import graph_client
        subject = f"[NeuLeap] {kind.capitalize()} backup FAILED"
        body = (
            f"A {kind} backup did not complete.\n\n"
            f"When: {manifest.get('created_at')}\n"
            f"Backup id: {manifest.get('id')}\n"
            f"Error: {manifest.get('error') or 'unknown'}\n\n"
            "Open Settings → Backup & Disaster Recovery to investigate."
        )
        html = graph_client.plain_text_to_html(body)
        for to in recipients:
            graph_client.send_mail(to, subject, html)
        log.info("backup failure notification sent to %s", ", ".join(recipients))
    except Exception as exc:  # noqa: BLE001 — notification must never mask the backup result
        log.warning("backup failure notification failed: %s", exc)


def _schema_ok() -> bool:
    try:
        from app.db import get_conn

        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT to_regclass('public.candidate_master')")
                return cur.fetchone()[0] is not None
    except Exception:  # noqa: BLE001
        return False


# ── run a backup ─────────────────────────────────────────────────────────────
def run_backup(kind: str = "full", reason: str = "manual") -> Dict[str, Any]:
    """Create a backup set (kind = "full" | "incremental") and fan it out to the
    secondary + cloud targets. Returns the manifest."""
    cfg = backup_config.get()
    base = _primary_dir()
    backup_id = ("full_" if kind == "full" else "incr_") + _stamp()
    out_dir = _kind_dir(base, kind) / backup_id
    out_dir.mkdir(parents=True, exist_ok=True)

    manifest: Dict[str, Any] = {
        "id": backup_id, "kind": kind, "reason": reason,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "app_version": APP_VERSION, "status": "running", "files": {}, "targets": {},
    }
    try:
        db_path = out_dir / "db.dump"
        manifest["files"]["db.dump"] = {"bytes": _pg_dump(db_path), "sha256": _sha256(db_path)}

        if kind == "full":
            raw_tar = out_dir / "minio_raw.tar.gz"
            res_tar = out_dir / "minio_resume.tar.gz"
            raw_n = _snapshot_bucket(True, raw_tar)
            res_n = _snapshot_bucket(False, res_tar)
            manifest["files"]["minio_raw.tar.gz"] = {"objects": raw_n, "bytes": raw_tar.stat().st_size}
            manifest["files"]["minio_resume.tar.gz"] = {"objects": res_n, "bytes": res_tar.stat().st_size}

            # System CONFIGURATION (secrets/ — all UI settings, keys, config JSON/
            # env) so a full backup is a whole-system snapshot, not just data.
            cfg_tar = out_dir / "config.tar.gz"
            manifest["files"]["config.tar.gz"] = _snapshot_config(cfg_tar)

        manifest["schema_ok"] = _schema_ok()
        manifest["total_bytes"] = _dir_size(out_dir)
        manifest["status"] = "ok"
    except subprocess.CalledProcessError as exc:
        manifest["status"] = "failed"
        manifest["error"] = (exc.stderr or b"").decode("utf-8", "ignore")[:500] or str(exc)
        log.warning("backup %s failed: %s", backup_id, manifest["error"])
    except Exception as exc:  # noqa: BLE001
        manifest["status"] = "failed"
        manifest["error"] = str(exc)
        log.warning("backup %s failed: %s", backup_id, exc)

    # Write the manifest BEFORE fan-out so it's captured in the copies too.
    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    if manifest["status"] == "ok":
        manifest["targets"]["secondary"] = _copy_to_secondary(cfg, out_dir, kind, backup_id)
        manifest["targets"]["cloud"] = _upload_to_cloud(cfg, out_dir, kind, backup_id)
        # Re-write with the target results included.
        (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
        _prune(cfg)
    else:
        _notify_failure(cfg, kind, manifest)
    return manifest


# ── list / prune / restore ───────────────────────────────────────────────────
def _read_manifest(d: Path) -> Optional[dict]:
    try:
        return json.loads((d / "manifest.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def list_backups() -> List[dict]:
    base = _primary_dir()
    out: List[dict] = []
    for kind in ("full", "incremental"):
        kdir = base / kind
        if not kdir.exists():
            continue
        for d in kdir.iterdir():
            if d.is_dir():
                m = _read_manifest(d)
                if m:
                    out.append(m)
    out.sort(key=lambda m: m.get("created_at", ""), reverse=True)
    return out


def _prune(cfg: dict) -> None:
    base = _primary_dir()
    keep_full = max(2, int(cfg.get("retention_full_sets") or 2))
    keep_incr = max(1, int(cfg.get("retention_incrementals") or 14))
    for kind, keep in (("full", keep_full), ("incremental", keep_incr)):
        kdir = base / kind
        if not kdir.exists():
            continue
        dirs = sorted((d for d in kdir.iterdir() if d.is_dir()), key=lambda p: p.name, reverse=True)
        for stale in dirs[keep:]:
            try:
                shutil.rmtree(stale)
            except OSError as exc:  # noqa: BLE001
                log.warning("backup prune: could not remove %s: %s", stale, exc)


# Columns the CURRENT code depends on — a restore of an OLDER dump must end with
# these present (re-added by the additive migrations) or the upgraded app breaks.
# Not exhaustive; a representative set spanning the features added over time so the
# post-restore integrity check catches a schema that's behind the running code.
_REQUIRED_COLUMNS: Dict[str, List[str]] = {
    "candidate_master": ["source", "score_breakdown", "help_request", "latest_remark"],
    "question_banks": ["options"],
    "question_bank_allocations": ["answers_locked_at", "marks_locked_at"],
    "question_bank_responses": ["awarded_points"],
    "app_users": ["must_change_password"],
    "interview_pools": ["round_names"],
}


def _integrity_report() -> Dict[str, Any]:
    """Confirm the restored + re-migrated DB carries the columns the running code
    needs. Returns {ok, missing:[table.col,...]} — ok=False means the schema is
    still behind the code (restore should be treated as needing attention)."""
    from app.db import get_conn

    missing: List[str] = []
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                for table, cols in _REQUIRED_COLUMNS.items():
                    cur.execute(
                        "SELECT column_name FROM information_schema.columns WHERE table_name = %s",
                        (table,),
                    )
                    have = {r[0] for r in cur.fetchall()}
                    if not have:
                        continue  # table absent in this (older) dump — CREATE handles it
                    missing.extend(f"{table}.{c}" for c in cols if c not in have)
        return {"ok": not missing, "missing": missing}
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "error": str(exc)}


def restore_backup(backup_id: str) -> Dict[str, Any]:
    """Restore the DB (and, for a full, the MinIO buckets + config) from a backup
    set. DESTRUCTIVE — replaces current data. Gated to System Admin at the API.

    CRITICAL for upgrade↔backup safety: pg_restore --clean recreates the tables AS
    THEY WERE in the dump, so restoring a PRE-upgrade backup would strip columns/
    tables the current (upgraded) code needs. So right after the DB restore we
    re-run the additive schema migrations (idempotent) to bring the restored data
    UP to the current schema, then verify integrity — this keeps the upgraded
    system stable even when the restored backup predates its new features."""
    base = _primary_dir()
    kind = "full" if backup_id.startswith("full_") else "incremental"
    src = base / kind / backup_id
    if not src.exists():
        return {"restored": False, "error": f"backup {backup_id} not found"}
    result: Dict[str, Any] = {"restored": False, "id": backup_id, "kind": kind}
    try:
        _pg_restore(src / "db.dump")
        result["db"] = "restored"

        # Reconcile the restored (possibly older) schema with the running code:
        # re-apply additive migrations (ADD COLUMN/CREATE ... IF NOT EXISTS). New
        # columns come back with their defaults; existing data is untouched.
        try:
            from app.db import init_db

            init_db()
            result["schema_migrated"] = True
        except Exception as exc:  # noqa: BLE001 — surface, don't abort the restore
            result["schema_migrated"] = False
            result["schema_error"] = str(exc)
            log.warning("post-restore schema migration failed: %s", exc)
        result["integrity"] = _integrity_report()

        if kind == "full":
            result["minio_raw"] = _restore_bucket(True, src / "minio_raw.tar.gz")
            result["minio_resume"] = _restore_bucket(False, src / "minio_resume.tar.gz")
            # Restore configuration (secrets/) too, then reload it live so the
            # running app reflects the reverted settings without a restart. Config
            # is forward-compatible: services merge saved values over current
            # DEFAULTS, so new keys absent from an old backup fall back to defaults.
            result["config"] = _restore_config(src / "config.tar.gz")
            _reload_config_into_app()
        result["restored"] = True
    except Exception as exc:  # noqa: BLE001
        result["error"] = str(exc)
        log.warning("restore %s failed: %s", backup_id, exc)
    return result


# ── health ───────────────────────────────────────────────────────────────────
def system_health() -> Dict[str, Any]:
    health: Dict[str, Any] = {"generated_at": datetime.now(timezone.utc).isoformat()}

    # Database
    try:
        from app.db import get_conn

        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT version()")
                ver = cur.fetchone()[0]
        health["database"] = {"ok": True, "version": ver.split(" on ")[0], "schema_ready": _schema_ok()}
    except Exception as exc:  # noqa: BLE001
        health["database"] = {"ok": False, "error": str(exc)}

    # Object storage
    try:
        from app.services.s3 import s3

        svc = s3()
        raw_n = len(svc.list_keys("", raw=True))
        res_n = len(svc.list_keys("", raw=False))
        health["storage"] = {"ok": True, "raw_objects": raw_n, "resume_objects": res_n}
    except Exception as exc:  # noqa: BLE001
        health["storage"] = {"ok": False, "error": str(exc)}

    # Disk on the primary backup path
    try:
        du = shutil.disk_usage(_primary_dir())
        health["disk"] = {
            "ok": du.free > 512 * 1024 * 1024,  # warn under 512 MB free
            "total_bytes": du.total, "used_bytes": du.used, "free_bytes": du.free,
        }
    except Exception as exc:  # noqa: BLE001
        health["disk"] = {"ok": False, "error": str(exc)}

    # Backups summary
    backups = list_backups()
    fulls = [b for b in backups if b.get("kind") == "full"]
    incrs = [b for b in backups if b.get("kind") == "incremental"]
    cfg = backup_config.get()
    health["backups"] = {
        "enabled": bool(cfg.get("enabled")),
        "full_sets": len(fulls),
        "incrementals": len(incrs),
        "last_full": fulls[0] if fulls else None,
        "last_incremental": incrs[0] if incrs else None,
        "secondary_configured": bool((cfg.get("secondary_dir") or "").strip()),
        "cloud_configured": bool((cfg.get("cloud") or {}).get("enabled") and (cfg.get("cloud") or {}).get("bucket")),
        "retention_full_sets": cfg.get("retention_full_sets"),
    }
    health["app_version"] = APP_VERSION
    return health
