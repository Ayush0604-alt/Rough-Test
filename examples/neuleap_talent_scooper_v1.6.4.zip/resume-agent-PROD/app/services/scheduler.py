"""Daily pipeline trigger (APScheduler).

Layer 1 runs two ways — both invoke the *same* work:

* **Manual trigger** — the Run Pipeline button (`POST /run-pipeline`).
* **Scheduled** — a cron job (default **03:00 daily**) that drains the mailbox
  into the queue and then runs the pipeline.

Config (env):
    SCHEDULE_ENABLED            1 to enable the job (default 1)
    SCHEDULE_CRON               crontab expression (default "0 0 * * *" = 00:00 daily)
    SCHEDULE_TZ                 timezone for the cron (default "Asia/Kolkata" / IST)
    SCHEDULE_INTERVAL_SECONDS   TESTING ONLY — when > 0, run every N seconds instead
                                of the cron (e.g. 60). Unset/0 ⇒ use the daily cron.

The scheduled job is intentionally a thin wrapper around the very functions the
HTTP endpoints call, so manual and scheduled runs are byte-for-byte identical.
"""

from __future__ import annotations

import os
from typing import Callable, Optional

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.interval import IntervalTrigger

from app.logging_config import get_logger
from app.mail_config import Settings
from app.services import graph_client
from app.services import mail_intake as intake

log = get_logger(__name__)

_scheduler: Optional[BackgroundScheduler] = None
JOB_ID = "layer1-daily"
ARCHIVE_JOB_ID = "candidate-archive-nightly"
SLOT_REMINDER_JOB_ID = "candidate-slot-reminder"
POOL_SYNC_JOB_ID = "interviewer-pool-sync"
BACKUP_INCR_JOB_ID = "backup-incremental"
BACKUP_FULL_JOB_ID = "backup-full"
_WEEKDAYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]  # 0=Mon .. 6=Sun


def is_enabled() -> bool:
    return os.environ.get("SCHEDULE_ENABLED", "1") == "1"


def cron_expr() -> str:
    return os.environ.get("SCHEDULE_CRON", "0 0 * * *")


def interval_seconds() -> int:
    """TESTING override: run every N seconds when > 0, else use the daily cron."""
    try:
        return max(0, int(os.environ.get("SCHEDULE_INTERVAL_SECONDS", "0")))
    except ValueError:
        return 0


def schedule_description() -> str:
    """Human-readable summary of the active schedule (for status/logs)."""
    n = interval_seconds()
    return f"every {n}s (testing)" if n > 0 else f"cron {cron_expr()!r} tz={_tz()}"


def archive_cron_expr() -> str:
    # Distinct from the pipeline cron (default 02:00) so they don't overlap.
    return os.environ.get("ARCHIVE_CRON", "0 2 * * *")


def _tz() -> str:
    # Default to Indian Standard Time so all batch/pipeline runs fire on IST
    # unless a deployment explicitly overrides SCHEDULE_TZ.
    from app.services.clock import tz_name

    return tz_name()


def run_daily(settings: Settings, run_pipeline: Callable[[], str]) -> dict:
    """The scheduled job: drain Graph mail into the queue, then run the pipeline.

    ``run_pipeline`` is injected by the API layer (it owns the run registry); it
    starts a pipeline run and returns its ``run_id``.
    """
    staged = 0
    if graph_client.is_configured():
        try:
            result = intake.stage_graph_messages(settings)   # all unread
            staged = result.get("staged_count", 0)
            log.info("scheduled intake: staged %d message(s) from Graph", staged)
        except Exception as exc:  # noqa: BLE001 — never let intake abort the run
            log.warning("scheduled Graph intake failed: %s", exc)
    else:
        log.info("scheduled run: Graph not configured — running queued items only")

    run_id = run_pipeline()
    log.info("scheduled run started: %s (graph_staged=%d)", run_id, staged)
    return {"run_id": run_id, "graph_staged": staged}


def start(
    settings: Settings,
    run_pipeline: Optional[Callable[[], str]] = None,
    *,
    job: Optional[Callable[[], object]] = None,
    archive_job: Optional[Callable[[], object]] = None,
    slot_reminder_job: Optional[Callable[[], object]] = None,
    pool_sync_job: Optional[Callable[[], object]] = None,
) -> Optional[BackgroundScheduler]:
    """Start the daily scheduler. Idempotent; returns the scheduler (or None).

    In the merged app pass ``job=`` directly (e.g. the orchestrator's run-all) so
    the cron drives the full L1→L2→L3 pipeline. If only ``run_pipeline`` is given,
    the legacy L1-only ``run_daily`` wrapper is scheduled instead.
    """
    global _scheduler
    if not is_enabled():
        log.info("scheduler disabled (SCHEDULE_ENABLED=0)")
        return None
    if _scheduler is not None:
        return _scheduler

    if job is not None:
        fire = job
    elif run_pipeline is not None:
        fire = lambda: run_daily(settings, run_pipeline)  # noqa: E731
    else:
        log.warning("scheduler.start called with no job — not starting")
        return None

    _scheduler = BackgroundScheduler(timezone=_tz())
    # Interval mode is a TESTING override (e.g. every 60s); production uses the cron.
    if interval_seconds() > 0:
        trigger = IntervalTrigger(seconds=interval_seconds(), timezone=_tz())
    else:
        trigger = CronTrigger.from_crontab(cron_expr(), timezone=_tz())
    _scheduler.add_job(
        fire,
        trigger=trigger,
        id=JOB_ID,
        replace_existing=True,
        misfire_grace_time=3600,   # still fire if the service was briefly down
        coalesce=True,             # collapse missed runs into one
    )
    if archive_job is not None:
        _scheduler.add_job(
            archive_job,
            trigger=CronTrigger.from_crontab(archive_cron_expr(), timezone=_tz()),
            id=ARCHIVE_JOB_ID,
            replace_existing=True,
            misfire_grace_time=3600,
            coalesce=True,
        )
        log.info("archival job scheduled: cron=%r tz=%s", archive_cron_expr(), _tz())

    if slot_reminder_job is not None:
        _scheduler.add_job(
            slot_reminder_job,
            trigger=IntervalTrigger(hours=1, timezone=_tz()),
            id=SLOT_REMINDER_JOB_ID,
            replace_existing=True,
            misfire_grace_time=3600,
            coalesce=True,
        )
        log.info("candidate slot reminder job scheduled: every 1h")

    if pool_sync_job is not None:
        _scheduler.add_job(
            pool_sync_job,
            trigger=IntervalTrigger(hours=2, timezone=_tz()),
            id=POOL_SYNC_JOB_ID,
            replace_existing=True,
            misfire_grace_time=3600,
            coalesce=True,
        )
        log.info("interviewer pool sync job scheduled: every 2h")

    _scheduler.start()
    reschedule_backups()
    log.info("scheduler started: %s", schedule_description())
    return _scheduler


def _run_incremental_backup() -> None:
    from app.services import backup
    backup.run_backup(kind="incremental", reason="scheduled")


def _run_full_backup() -> None:
    from app.services import backup
    backup.run_backup(kind="full", reason="scheduled")


def reschedule_backups() -> bool:
    """Apply the Backup & DR schedule (Settings) to the live scheduler: an
    incremental every N hours + a weekly full on the chosen day/hour. Removes
    both jobs when backups are disabled. Safe to call repeatedly."""
    if _scheduler is None:
        return False
    try:
        from app.services import backup_config

        cfg = backup_config.get()
        for jid in (BACKUP_INCR_JOB_ID, BACKUP_FULL_JOB_ID):
            if _scheduler.get_job(jid):
                _scheduler.remove_job(jid)
        if not cfg.get("enabled"):
            log.info("scheduled backups: disabled")
            return True
        _scheduler.add_job(
            _run_incremental_backup,
            trigger=IntervalTrigger(hours=max(1, int(cfg["incremental_interval_hours"])), timezone=_tz()),
            id=BACKUP_INCR_JOB_ID, replace_existing=True, misfire_grace_time=3600, coalesce=True,
        )
        day = _WEEKDAYS[max(0, min(6, int(cfg["full_weekly_day"])))]
        _scheduler.add_job(
            _run_full_backup,
            trigger=CronTrigger(day_of_week=day, hour=int(cfg["full_weekly_hour"]), minute=0, timezone=_tz()),
            id=BACKUP_FULL_JOB_ID, replace_existing=True, misfire_grace_time=3600, coalesce=True,
        )
        log.info("scheduled backups: incremental every %sh, full %s@%02d:00",
                 cfg["incremental_interval_hours"], day, int(cfg["full_weekly_hour"]))
        return True
    except Exception as exc:  # noqa: BLE001 — a reschedule failure must not break a save
        log.warning("reschedule_backups failed: %s", exc)
        return False


def reschedule() -> bool:
    """Re-apply the current SCHEDULE_CRON/TZ to the live pipeline job (after a Settings
    save). Returns True if the running job was rescheduled. No-op in interval mode."""
    if _scheduler is None or interval_seconds() > 0:
        return False
    try:
        _scheduler.reschedule_job(
            JOB_ID, trigger=CronTrigger.from_crontab(cron_expr(), timezone=_tz())
        )
        log.info("scheduler rescheduled: %s", schedule_description())
        return True
    except Exception as exc:  # noqa: BLE001 — a reschedule failure must not 500 a save
        log.warning("scheduler reschedule failed: %s", exc)
        return False


def next_run_time() -> Optional[str]:
    if _scheduler is None:
        return None
    job = _scheduler.get_job(JOB_ID)
    return job.next_run_time.isoformat() if job and job.next_run_time else None


def shutdown() -> None:
    global _scheduler
    if _scheduler is not None:
        _scheduler.shutdown(wait=False)
        _scheduler = None
