"""Interviewer timeslot pools — Mailbox → "Interviewer Timeslot Pools".

A pool is a (campaign source tag, date range) capacity plan covering ONE OR
MORE rounds at once (``round_names``) — every round in the list shares the
pool's rules/date range and the same source-tag candidate pipeline, but each
gathers its own slots against its own roster (a slot always records which
round it was gathered for). "Gather / Refresh" (``gather_pool``) blocks
``[PLACEHOLDER for NLi <round> pool-<id>]`` events on each round's rostered
interviewers' calendars (app.services.round_interviewers_config), so
candidates in that round can pick from a pre-reserved slot
(app.services.candidate_slot's pool-aware booking path) instead of a live
per-candidate Graph lookup.

All datetimes in this module are kept NAIVE, representing local business-tz
wall-clock time — this matches how they round-trip through Postgres TIMESTAMP
(no tz) columns, and Graph's calendar API accepts a tz-naive ``dateTime`` +
a separate ``timeZone`` field (see graph_calendar), so nothing is lost.

Allocation rules (checked in order, per interviewer per day):
  1. ``days_allowed[weekday]`` picks which part of the business-hours window
     is even eligible ("full"/"first_half"/"second_half"/"none").
  2. A candidate slot must sit at least ``gap_minutes`` clear of any existing
     meeting (real ones from Graph, or another pool's placeholder — every
     pool shares one interviewer-day budget, never double-books).
  3. Total placeholder minutes on that interviewer's calendar that day (across
     ALL pools) may never exceed ``max_day_fraction`` of the day's window.
"""
from __future__ import annotations

import json
import math
import random
from datetime import date, datetime, time, timedelta
from typing import Any, Optional

from app.db import get_conn
from app.logging_config import get_logger
from app.services import graph_calendar, interview_pool_config, nlrs, round_interviewers_config
from app.services.clock import business_tz
from app.services.interview_plan import FLOW as _ROUND_FLOW

log = get_logger(__name__)

# A short, memorable codename per slot — appended to the placeholder's Graph
# calendar event subject too, so "the Batman slot" beats reading out a
# timestamp. Purely cosmetic (never a unique key) — add more here any time.
_SLOT_CODENAMES = [
    "Batman", "HeMan", "SpiderMan", "SakthiMan", "ChotaBheem", "Thor", "AquaMan",
    "Hulk", "BahuBhali", "Chubby", "Shelke", "AbhayAnna", "Bochre", "SnowFlakeSoori",
    "IronMan", "CaptainAmerica", "BlackPanther", "WonderWoman", "Flash", "Krrish",
    "Doraemon", "Optimus", "Ninja", "Superman", "GreenLantern", "BlackAdam",
]


def _pick_slot_name(taken: set[str]) -> str:
    """Prefers a codename not already used elsewhere in the SAME gather call —
    falls back to any name (repeats are fine; this is cosmetic, not a key)
    once the round being gathered outgrows the list."""
    available = [n for n in _SLOT_CODENAMES if n not in taken]
    return random.choice(available or _SLOT_CODENAMES)

_WEEKDAY_KEYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]
# Which funnel round each Predicted NBA fast-track key routes a candidate INTO —
# a candidate predicted "share_round1" skips Screening entirely and is expected
# to need a Round 1 slot, not a Screening one. "reject" candidates need no slot
# at all; "undecided"/"call_now" both still need Screening (nothing routes them
# past it yet).
_NBA_ENTRY_ROUND = {
    "call_now": "Screening",
    "undecided": "Screening",
    "share_round1": "Round 1",
    "share_round2": "Round 2",
    "final_round": "Final",
}
_VELOCITY_TRAILING_DAYS = 14


def _rows(cur) -> list[dict[str, Any]]:
    cols = [d[0] for d in cur.description]
    return [dict(zip(cols, r)) for r in cur.fetchall()]


# ── Pool CRUD ────────────────────────────────────────────────────────────────

def list_pools() -> list[dict[str, Any]]:
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM interview_pools WHERE NOT archived ORDER BY created_at DESC")
            return _rows(cur)


def get_pool(pool_id: int) -> Optional[dict[str, Any]]:
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM interview_pools WHERE id = %s", (pool_id,))
            rows = _rows(cur)
    return rows[0] if rows else None


def create_pool(data: dict[str, Any]) -> dict[str, Any]:
    defaults = interview_pool_config.get()
    round_names = data.get("round_names") or []
    if not round_names:
        raise ValueError("A pool needs at least one round.")
    # ONE live pool per source tag — a second pool for the same campaign would
    # split its placeholder capacity and make the per-round targets and picker
    # links ambiguous. Archived pools don't count; edit or archive the
    # existing one instead.
    source_label = data.get("source_label")
    with get_conn() as conn:
        with conn.cursor() as cur:
            if source_label is None:
                cur.execute(
                    "SELECT label FROM interview_pools WHERE source_label IS NULL AND NOT archived LIMIT 1"
                )
            else:
                cur.execute(
                    "SELECT label FROM interview_pools WHERE source_label = %s AND NOT archived LIMIT 1",
                    (source_label,),
                )
            clash = cur.fetchone()
    if clash:
        who = source_label or "candidates with no source tag"
        raise ValueError(
            f"A pool for '{who}' already exists ('{clash[0]}'). One pool per source tag — "
            f"edit that pool (rounds/dates/rules) or archive it before creating a new one."
        )
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO interview_pools
                    (source_label, round_names, label, range_start, range_end,
                     slot_minutes, gap_minutes, max_day_fraction, days_allowed)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                RETURNING id
                """,
                (
                    data.get("source_label"),
                    json.dumps(round_names),
                    data["label"],
                    data["range_start"],
                    data["range_end"],
                    data.get("slot_minutes", defaults["slot_minutes"]),
                    data.get("gap_minutes", defaults["gap_minutes"]),
                    data.get("max_day_fraction", defaults["max_day_fraction"]),
                    json.dumps(data.get("days_allowed") or defaults["days_allowed"]),
                ),
            )
            pool_id = cur.fetchone()[0]
    return get_pool(pool_id)


def _cancel_open_slots(rows: list[tuple[Any, ...]]) -> None:
    """Shared by archive_pool and update_pool: given (slot_id, interviewer_email,
    graph_event_id) rows for OPEN slots, flip them to 'cancelled' in the DB and
    best-effort delete each one's Graph calendar event. Already-BOOKED slots
    are never passed in here — a candidate is relying on that specific time,
    and silently cancelling it would strand them with no notification; that
    needs its own reschedule/notify flow, not a side-effect of a pool edit."""
    if not rows:
        return
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE interview_pool_slots SET status = 'cancelled', updated_at = CURRENT_TIMESTAMP "
                "WHERE id = ANY(%s)",
                ([r[0] for r in rows],),
            )
    for _slot_id, email, event_id in rows:
        if not event_id:
            continue
        try:
            graph_calendar.delete_event(email, event_id)
        except Exception as exc:  # noqa: BLE001 — best-effort; the slot is already marked cancelled
            log.warning("interview_pools: could not delete graph event %s for %s: %s", event_id, email, exc)


def _cancel_slots_outside_scope(pool: dict[str, Any]) -> None:
    """After editing a pool's rounds or date range, cancel any still-OPEN
    placeholder that no longer fits the new scope (a round dropped from
    round_names, or a day now outside the range) — otherwise it keeps
    cluttering the interviewer's calendar and silently eating their
    cross-pool day-budget for a round/date this pool no longer covers (the
    exact stale-placeholder bug a deleted-but-not-cleaned-up pool caused)."""
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT id, round_name, interviewer_email, slot_start, graph_event_id "
                "FROM interview_pool_slots WHERE pool_id = %s AND status = 'open'",
                (pool["id"],),
            )
            open_slots = cur.fetchall()
    stale = [
        (row[0], row[2], row[4])
        for row in open_slots
        if row[1] not in pool["round_names"] or not (pool["range_start"] <= row[3].date() <= pool["range_end"])
    ]
    _cancel_open_slots(stale)


def update_pool(pool_id: int, data: dict[str, Any]) -> Optional[dict[str, Any]]:
    existing = get_pool(pool_id)
    if not existing:
        return None
    if existing.get("archived"):
        raise ValueError("This pool has been deleted — it can no longer be edited.")
    cols: list[str] = []
    vals: list[Any] = []
    for key in ("source_label", "label", "range_start", "range_end",
                "slot_minutes", "gap_minutes", "max_day_fraction",
                "manual_projected_candidates"):
        if key in data:
            cols.append(f"{key} = %s")
            vals.append(data[key])
    if "round_names" in data:
        if not data["round_names"]:
            raise ValueError("A pool needs at least one round.")
        cols.append("round_names = %s")
        vals.append(json.dumps(data["round_names"]))
    if "days_allowed" in data:
        cols.append("days_allowed = %s")
        vals.append(json.dumps(data["days_allowed"]))
    if not cols:
        return get_pool(pool_id)
    cols.append("updated_at = CURRENT_TIMESTAMP")
    vals.append(pool_id)
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(f"UPDATE interview_pools SET {', '.join(cols)} WHERE id = %s", vals)
    updated = get_pool(pool_id)
    if updated and ("round_names" in data or "range_start" in data or "range_end" in data):
        _cancel_slots_outside_scope(updated)
    return updated


def archive_pool(pool_id: int) -> Optional[dict[str, Any]]:
    """Archiving is the only "delete" a pool gets — it drops out of
    list_pools() and find_pool_for() immediately. Every still-OPEN
    placeholder (no candidate attached) is cancelled along with it: its Graph
    calendar event is deleted and its status flips to 'cancelled', so it
    stops cluttering the interviewer's calendar and can never be gathered or
    booked again. Already-BOOKED slots are left untouched — a candidate is
    relying on that specific time, and silently cancelling it would strand
    them with no notification; that needs its own reschedule/notify flow,
    not a side-effect of deleting the pool."""
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT id, interviewer_email, graph_event_id FROM interview_pool_slots "
                "WHERE pool_id = %s AND status = 'open'",
                (pool_id,),
            )
            open_slots = cur.fetchall()
            cur.execute(
                "UPDATE interview_pools SET archived = TRUE, updated_at = CURRENT_TIMESTAMP WHERE id = %s",
                (pool_id,),
            )
    _cancel_open_slots(open_slots)
    return get_pool(pool_id)


# ── Slots ────────────────────────────────────────────────────────────────────

def list_slots(pool_id: int) -> list[dict[str, Any]]:
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT * FROM interview_pool_slots WHERE pool_id = %s ORDER BY slot_start", (pool_id,)
            )
            return _rows(cur)


def get_slot(slot_id: int) -> Optional[dict[str, Any]]:
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM interview_pool_slots WHERE id = %s", (slot_id,))
            rows = _rows(cur)
    return rows[0] if rows else None


def pool_strength(pool_id: int, round_name: Optional[str] = None) -> dict[str, int]:
    out = {"open": 0, "booked": 0, "removed_by_interviewer": 0, "cancelled": 0}
    for s in list_slots(pool_id):
        if round_name is not None and s["round_name"] != round_name:
            continue
        out[s["status"]] = out.get(s["status"], 0) + 1
    return out


def _funnel_order(round_names: list[str]) -> list[str]:
    """Canonical pipeline order (app.services.interview_plan.FLOW) for the rounds
    this pool actually covers, with any custom round name (not part of the
    standard flow, e.g. "HR") appended afterwards in its original order."""
    flow_set = set(_ROUND_FLOW)
    ordered = [r for r in _ROUND_FLOW if r in round_names]
    ordered += [r for r in round_names if r not in flow_set]
    return ordered


def _predicted_nba_entry_fractions(source_label: Optional[str]) -> dict[str, float]:
    """What fraction of this source's recent candidates are predicted (by NLRS
    band) to enter the funnel AT each round — a candidate fast-tracked to
    "share_round1" needs a Round 1 slot, not a Screening one, so sizing every
    round off the same top-of-funnel count over-provisions Screening and
    under-provisions the later rounds for a source that's running hot. Falls
    back to "everyone enters at Screening" (the old, NBA-blind assumption)
    when there's no recent sample to judge from."""
    with get_conn() as conn:
        with conn.cursor() as cur:
            if source_label is None:
                cur.execute(
                    "SELECT score_breakdown, certification_bonus, yearofexp, atsscore FROM candidate_master "
                    "WHERE source IS NULL AND created_at >= NOW() - INTERVAL '14 days'"
                )
            else:
                cur.execute(
                    "SELECT score_breakdown, certification_bonus, yearofexp, atsscore FROM candidate_master "
                    "WHERE source = %s AND created_at >= NOW() - INTERVAL '14 days'",
                    (source_label,),
                )
            cols = [d[0] for d in cur.description]
            rows = [dict(zip(cols, r)) for r in cur.fetchall()]

    if not rows:
        return {"Screening": 1.0}

    counts: dict[str, int] = {}
    for row in rows:
        score = nlrs.compute_nlrs(row)["score"]
        key = nlrs.predicted_nba_key(score)
        entry_round = _NBA_ENTRY_ROUND.get(key)
        if entry_round is None:  # "reject" — filtered out, needs no round at all
            continue
        counts[entry_round] = counts.get(entry_round, 0) + 1

    total = len(rows)
    return {round_name: n / total for round_name, n in counts.items()}


# ── Velocity-based pool-size estimate ───────────────────────────────────────
# Heuristic, not a real conversion-rate model: candidates/day for this source
# over the trailing window, projected across the pool's date range, giving a
# top-of-funnel candidate count. That count is then split across the pool's
# rounds two ways at once: (1) Predicted-NBA entry fractions route each
# candidate to the round they're actually expected to FIRST need (a
# fast-tracked candidate skips the earlier rounds entirely), and (2) each
# round's configured "expected filtering %" (Settings — 0 by default) trims
# what carries forward to the next round. With no fast-track candidates and
# 0% filtering everywhere, this reproduces the old behaviour exactly: every
# round sized against the same top-of-funnel figure.

def compute_velocity(pool_id: int) -> dict[str, Any]:
    pool = get_pool(pool_id)
    if not pool:
        raise ValueError("pool not found")

    with get_conn() as conn:
        with conn.cursor() as cur:
            if pool["source_label"] is None:
                cur.execute(
                    "SELECT COUNT(*) FROM candidate_master "
                    "WHERE source IS NULL AND created_at >= NOW() - INTERVAL '14 days'"
                )
            else:
                cur.execute(
                    "SELECT COUNT(*) FROM candidate_master "
                    "WHERE source = %s AND created_at >= NOW() - INTERVAL '14 days'",
                    (pool["source_label"],),
                )
            recent_count = cur.fetchone()[0]

    velocity_per_day = recent_count / _VELOCITY_TRAILING_DAYS
    range_days = (pool["range_end"] - pool["range_start"]).days + 1
    auto_projected = velocity_per_day * range_days

    # A recruiter-entered override always wins once set — it's the whole point of
    # letting them correct a thin/noisy trailing-14-day sample. The auto figure is
    # still returned alongside it so the UI can show what the raw velocity math
    # would have said.
    override = pool.get("manual_projected_candidates")
    manual_override = override is not None
    projected_candidates = float(override) if manual_override else auto_projected
    needed = math.ceil(projected_candidates)

    entry_fractions = _predicted_nba_entry_fractions(pool["source_label"])
    filter_pct = interview_pool_config.get()["funnel_filter_pct"]

    # Flow the projected candidates down the FULL pipeline — not only the rounds
    # THIS pool covers — so candidates who enter at Screening/Round 1 still carry
    # over into a pool that provisions just the later rounds (e.g. Round 2 +
    # Final). Iterating the pool's own rounds alone dropped that carryover, so a
    # later-round-only pool showed every target as 0 unless someone was predicted
    # to enter DIRECTLY at those rounds. Custom (non-flow) rounds are appended in
    # their given order, receiving carryover from the end of the standard flow.
    custom_rounds = [r for r in pool["round_names"] if r not in set(_ROUND_FLOW)]
    full_order = list(_ROUND_FLOW) + custom_rounds
    round_targets: dict[str, int] = {}
    carryover = 0.0
    for round_name in full_order:
        direct_entries = entry_fractions.get(round_name, 0.0) * projected_candidates
        total_at_round = direct_entries + carryover
        round_targets[round_name] = math.ceil(total_at_round)
        pct_filtered = filter_pct.get(round_name, 0.0) / 100
        carryover = total_at_round * (1 - pct_filtered)

    per_round = []
    for round_name in pool["round_names"]:
        strength = pool_strength(pool_id, round_name)
        existing = strength["open"] + strength["booked"]
        target = round_targets.get(round_name, needed)
        per_round.append({
            "round_name": round_name,
            "target": target,
            "existing_strength": existing,
            "strength_breakdown": strength,
            "gap": max(0, target - existing),
        })

    return {
        "velocity_per_day": round(velocity_per_day, 2),
        "range_days": range_days,
        "auto_projected_candidates": round(auto_projected, 1),
        "projected_candidates": round(projected_candidates, 1),
        "manual_override": manual_override,
        "needed_pool_size": round_targets.get(full_order[0], needed) if full_order else needed,
        "existing_strength": sum(r["existing_strength"] for r in per_round),
        "gap": sum(r["gap"] for r in per_round),
        "per_round": per_round,
    }


# ── Gather / Refresh — the placeholder allocation algorithm ─────────────────

# Extended-hours bounds — the early-morning and late-evening windows sit OUTSIDE
# the 10–18 business day, for pools that need to offer interviews before/after it.
_EARLY_START_HOUR = 8   # early morning: 08:00 → business start (10:00)
_LATE_END_HOUR = 21     # late evening: business end (18:00) → 21:00

_HALF_OF = {
    "full": (graph_calendar.BUSINESS_START_HOUR, graph_calendar.BUSINESS_END_HOUR),
    # Full day extended — the whole early-morning-through-late-evening span.
    "full_extended": (_EARLY_START_HOUR, _LATE_END_HOUR),
    # Early morning — before the business day starts.
    "early_morning": (_EARLY_START_HOUR, graph_calendar.BUSINESS_START_HOUR),
    "first_half": (
        graph_calendar.BUSINESS_START_HOUR,
        (graph_calendar.BUSINESS_START_HOUR + graph_calendar.BUSINESS_END_HOUR) // 2,
    ),
    "second_half": (
        (graph_calendar.BUSINESS_START_HOUR + graph_calendar.BUSINESS_END_HOUR) // 2,
        graph_calendar.BUSINESS_END_HOUR,
    ),
    # Late evening — after the business day ends.
    "late_evening": (graph_calendar.BUSINESS_END_HOUR, _LATE_END_HOUR),
}


def _day_window(day: date, rule: str) -> Optional[tuple[datetime, datetime]]:
    if rule not in _HALF_OF:
        return None
    start_h, end_h = _HALF_OF[rule]
    return datetime.combine(day, time(hour=start_h)), datetime.combine(day, time(hour=end_h))


def _ceil_half_hour(dt: datetime) -> datetime:
    """Round a time UP to the next :00 / :30 boundary (dropping seconds). Used to
    floor 'today' slot gathering at NOW so a pool never offers past slots."""
    dt = dt.replace(second=0, microsecond=0)
    if dt.minute in (0, 30):
        return dt
    if dt.minute < 30:
        return dt.replace(minute=30)
    return dt.replace(minute=0) + timedelta(hours=1)


def _existing_pool_intervals_for_day(email: str, day: date) -> list[tuple[datetime, datetime]]:
    day_start = datetime.combine(day, time.min)
    day_end = day_start + timedelta(days=1)
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT s.slot_start, s.slot_end FROM interview_pool_slots s "
                "JOIN interview_pools p ON p.id = s.pool_id "
                "WHERE s.interviewer_email = %s AND s.status IN ('open','booked') AND NOT p.archived "
                "AND s.slot_start >= %s AND s.slot_start < %s",
                (email, day_start, day_end),
            )
            return [(r[0], r[1]) for r in cur.fetchall()]


def _fits(candidate_start: datetime, candidate_end: datetime, busy: list[tuple[datetime, datetime]], gap_minutes: int) -> bool:
    buffer = timedelta(minutes=gap_minutes)
    for b_start, b_end in busy:
        if candidate_start < b_end + buffer and b_start - buffer < candidate_end:
            return False
    return True


def _insert_slot(
    pool_id: int, round_name: str, email: str, name: Optional[str],
    start: datetime, end: datetime, event_id: Optional[str], slot_name: str,
) -> None:
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO interview_pool_slots "
                "(pool_id, round_name, interviewer_email, interviewer_name, slot_start, slot_end, graph_event_id, slot_name) "
                "VALUES (%s, %s, %s, %s, %s, %s, %s, %s)",
                (pool_id, round_name, email, name, start, end, event_id, slot_name),
            )


def _gather_round(pool: dict[str, Any], round_name: str, target: Optional[int] = None) -> dict[str, Any]:
    pool_id = pool["id"]
    roster = round_interviewers_config.interviewers_for(round_name)
    if not roster:
        return {"created": 0, "skipped": 0, "warnings": [f"No interviewers rostered for {round_name}."]}

    # `target` is the round's total needed pool size (existing + gap) from
    # compute_velocity — auto-computed or recruiter-overridden. Once the round
    # already holds that many open/booked slots, gather is a no-op for it; this
    # is what makes "Make placeholders" respect the pool-size calculation
    # instead of blindly filling every open calendar slot in the date range.
    remaining_to_create: Optional[int] = None
    if target is not None:
        strength = pool_strength(pool_id, round_name)
        existing = strength["open"] + strength["booked"]
        remaining_to_create = max(0, target - existing)
        if remaining_to_create == 0:
            return {
                "created": 0,
                "skipped": 0,
                "warnings": [f"Already at target ({existing}/{target}) — no new placeholders needed."],
            }

    # Per-round override of the pool's base rules (Interviewer Timeslot Pools →
    # Default allocation rules → per-round expander). Falls back to the pool's
    # own config when the round has no override.
    _base_rules = {
        "days_allowed": pool["days_allowed"],
        "slot_minutes": pool["slot_minutes"],
        "gap_minutes": pool["gap_minutes"],
        "max_day_fraction": pool["max_day_fraction"],
    }
    _eff = interview_pool_config.resolve_for_round(round_name or "", _base_rules)
    days_allowed = _eff["days_allowed"]
    slot_minutes = int(_eff["slot_minutes"])
    gap_minutes = int(_eff["gap_minutes"])
    max_fraction = float(_eff["max_day_fraction"])
    used_names: set[str] = set()

    created = 0
    skipped = 0
    warnings: list[str] = []

    def _target_met() -> bool:
        return remaining_to_create is not None and created >= remaining_to_create

    day = pool["range_start"]
    while day <= pool["range_end"] and not _target_met():
        rule = days_allowed.get(_WEEKDAY_KEYS[day.weekday()], "none")
        window = _day_window(day, rule)
        if window:
            window_start, window_end = window
            # On today's date, never gather slots in the past: start no earlier
            # than NOW rounded UP to the next half hour (:00/:30). If that leaves
            # no room today, the day yields nothing (empty roster below).
            _now = datetime.now()
            if day == _now.date():
                window_start = max(window_start, _ceil_half_hour(_now))
            window_minutes = (window_end - window_start).total_seconds() / 60
            max_minutes = window_minutes * max_fraction

            day_roster = roster if window_start < window_end else []
            for interviewer in day_roster:
                if _target_met():
                    break
                email = interviewer["email"]
                name = interviewer.get("name")

                # Budget/overlap is tracked across ALL of this interviewer's
                # placeholders that day — regardless of pool or round — so
                # the 25%-of-day cap is a true per-interviewer limit, never
                # per-round.
                own_pool_busy = _existing_pool_intervals_for_day(email, day)
                existing_minutes = sum((e - s).total_seconds() / 60 for s, e in own_pool_busy)
                remaining_budget = max_minutes - existing_minutes
                if remaining_budget < slot_minutes:
                    # Silent otherwise: this interviewer simply has no day-cap
                    # budget left on `day`, whether from THIS pool or another
                    # one sharing their calendar — without this, a recruiter
                    # sees 0 created/0 skipped with no clue why.
                    warnings.append(
                        f"{email}: no placeholder budget left on {day.isoformat()} "
                        f"({existing_minutes:.0f}/{max_minutes:.0f} min already blocked across pools)"
                    )
                    continue

                busy = list(own_pool_busy)
                try:
                    busy += graph_calendar.get_busy_intervals(email, window_start, window_end)
                except Exception as exc:  # noqa: BLE001 — degrade to "whole window free"
                    warnings.append(f"{email}: busy-time lookup failed ({exc}) — treated as free")

                slot_start = window_start
                while (
                    slot_start + timedelta(minutes=slot_minutes) <= window_end
                    and remaining_budget >= slot_minutes
                    and not _target_met()
                ):
                    slot_end = slot_start + timedelta(minutes=slot_minutes)
                    if _fits(slot_start, slot_end, busy, gap_minutes):
                        event_id = None
                        slot_name = _pick_slot_name(used_names)
                        used_names.add(slot_name)
                        subject = f"[PLACEHOLDER for NLi {round_name} pool-{pool_id} · {slot_name}]"
                        try:
                            event_id = graph_calendar.create_event(email, subject, slot_start, slot_end)
                        except Exception as exc:  # noqa: BLE001 — persist DB-only if Graph write fails
                            warnings.append(f"{email}: could not create calendar event ({exc}) — tracked DB-only")
                        _insert_slot(pool_id, round_name, email, name, slot_start, slot_end, event_id, slot_name)
                        created += 1
                        remaining_budget -= slot_minutes
                        busy.append((slot_start, slot_end))
                        slot_start = slot_end
                    else:
                        skipped += 1
                        slot_start = slot_start + timedelta(minutes=slot_minutes)
        day = day + timedelta(days=1)

    if target is not None and _target_met():
        warnings.append(f"Reached target of {target} for {round_name} — stopped early.")
    return {"created": created, "skipped": skipped, "warnings": warnings}


_GATHER_TRANCHE_STEP_PCT = 5


def _cancel_stale_open_slots(pool_id: int) -> int:
    """Cancel still-OPEN placeholders whose start is already before NOW rounded up
    to the next half hour — the 'remove the older placeholders' half of Make
    Placeholders, so a fresh gather rebuilds today's slots upward from now. Booked
    slots are untouched (a candidate is relying on them)."""
    cutoff = _ceil_half_hour(datetime.now())
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT id, interviewer_email, graph_event_id FROM interview_pool_slots "
                "WHERE pool_id = %s AND status = 'open' AND slot_start < %s",
                (pool_id, cutoff),
            )
            rows = cur.fetchall()
    _cancel_open_slots(rows)
    return len(rows)


def gather_pool(pool_id: int) -> dict[str, Any]:
    pool = get_pool(pool_id)
    if not pool:
        raise ValueError("pool not found")
    if pool.get("archived"):
        # Without this guard, a stale UI tab or a direct API call against an
        # already-deleted pool would happily create BRAND NEW placeholders on
        # it — calendar clutter that archive_pool's cancel-on-delete can never
        # clean up, because as far as the system's concerned this pool is
        # already gone and nothing will ever archive it a second time.
        raise ValueError("This pool has been deleted — it can no longer allocate new placeholders.")

    # Every gather is sized against each round's OWN calculated need (funnel +
    # Predicted-NBA cascaded velocity, or the recruiter's manual override) —
    # see compute_velocity — rather than blindly filling every eligible
    # calendar slot in the date range.
    # Remove stale open placeholders (already in the past) first, so the gather
    # below rebuilds today's slots upward from NOW rather than leaving expired
    # ones on interviewers' calendars (and eating their day-budget).
    removed = _cancel_stale_open_slots(pool_id)

    velocity = compute_velocity(pool_id)
    targets = {r["round_name"]: r["target"] for r in velocity["per_round"]}
    order = _funnel_order(pool["round_names"])

    created = 0
    skipped = 0
    seen_warnings: dict[str, None] = {}

    # "Vertical" allocation: raise every round's cap together, in rising
    # percentage tranches of ITS OWN target (5%, 10%, ..., 100%), funnel-order
    # within each tranche — rather than filling one round to 100% before
    # touching the next. Otherwise a large Screening target could exhaust a
    # shared interviewer's day-budget before Round 1/2/3/Final ever get a
    # placeholder, even though the funnel says they need far fewer anyway.
    pct = _GATHER_TRANCHE_STEP_PCT
    while pct <= 100:
        for round_name in order:
            tranche_target = math.ceil(targets.get(round_name, 0) * pct / 100)
            result = _gather_round(pool, round_name, target=tranche_target)
            created += result["created"]
            skipped += result["skipped"]
            for w in result["warnings"]:
                if w.startswith("Already at target") or w.startswith("Reached target"):
                    continue  # routine tranche bookkeeping, not actionable
                seen_warnings.setdefault(f"[{round_name}] {w}", None)
        pct += _GATHER_TRANCHE_STEP_PCT

    return {
        "created": created,
        "skipped": skipped,
        "removed": removed,
        "warnings": list(seen_warnings)[:20],
        "target_per_round": targets,
    }


# ── Interviewer self-service (view / remove / adjust their own placeholders) ─

def slots_for_interviewer(email: str) -> list[dict[str, Any]]:
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT s.*, p.label AS pool_label FROM interview_pool_slots s "
                "JOIN interview_pools p ON p.id = s.pool_id "
                "WHERE s.interviewer_email = %s AND s.status IN ('open','booked') "
                "ORDER BY s.slot_start",
                (email,),
            )
            return _rows(cur)


def remove_slot(slot_id: int, interviewer_email: str) -> Optional[dict[str, Any]]:
    """Only an OPEN placeholder can be removed — a booked one already has a
    candidate attached, so removing it here would silently strand them; that
    case needs a recruiter to re-coordinate instead."""
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT graph_event_id FROM interview_pool_slots "
                "WHERE id = %s AND interviewer_email = %s AND status = 'open'",
                (slot_id, interviewer_email),
            )
            row = cur.fetchone()
            if not row:
                return None
            cur.execute(
                "UPDATE interview_pool_slots SET status = 'removed_by_interviewer', "
                "updated_at = CURRENT_TIMESTAMP WHERE id = %s",
                (slot_id,),
            )
    if row[0]:
        try:
            graph_calendar.delete_event(interviewer_email, row[0])
        except Exception as exc:  # noqa: BLE001
            log.warning("interview_pools: could not delete graph event %s: %s", row[0], exc)
    return get_slot(slot_id)


def propose_new_time(slot_id: int, interviewer_email: str, new_start: datetime, new_end: datetime) -> Optional[dict[str, Any]]:
    """Directly reschedules an OPEN placeholder — the interviewer owns their
    own calendar, so this isn't a request/approval workflow, just a basic
    conflict check against their other placeholders (not a full re-run of the
    day/gap/cap rules)."""
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT graph_event_id FROM interview_pool_slots "
                "WHERE id = %s AND interviewer_email = %s AND status = 'open'",
                (slot_id, interviewer_email),
            )
            row = cur.fetchone()
            if not row:
                return None
            cur.execute(
                "SELECT 1 FROM interview_pool_slots WHERE interviewer_email = %s "
                "AND status IN ('open','booked') AND id <> %s "
                "AND slot_start < %s AND %s < slot_end",
                (interviewer_email, slot_id, new_end, new_start),
            )
            if cur.fetchone():
                raise ValueError("That time conflicts with another placeholder slot.")
            cur.execute(
                "UPDATE interview_pool_slots SET slot_start = %s, slot_end = %s, "
                "updated_at = CURRENT_TIMESTAMP WHERE id = %s",
                (new_start, new_end, slot_id),
            )
    if row[0]:
        try:
            graph_calendar.update_event(interviewer_email, row[0], start=new_start, end=new_end)
        except Exception as exc:  # noqa: BLE001
            log.warning("interview_pools: could not update graph event %s: %s", row[0], exc)
    return get_slot(slot_id)


# ── Candidate-facing booking (app.services.candidate_slot) ──────────────────

def open_slots_for_pool(pool_id: int, round_name: str) -> list[dict[str, Any]]:
    """Distinct open TIMES for this pool+round, each with `remaining` = how many
    parallel placeholders are still open at that time. Every rostered
    interviewer contributes its own placeholder row at the same half-hour, so
    adding interviewers WIDENS capacity at a time rather than creating a second
    identical button. The candidate picks a time; booking claims whichever
    sibling placeholder is still free (see book_pool_slot). `id` is a
    representative open row at that time (the one booking resolves against)."""
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT MIN(id) AS id, slot_start, slot_end, COUNT(*) AS remaining "
                "FROM interview_pool_slots "
                "WHERE pool_id = %s AND round_name = %s AND status = 'open' "
                "GROUP BY slot_start, slot_end ORDER BY slot_start",
                (pool_id, round_name),
            )
            return _rows(cur)


def book_pool_slot(slot_id: int, candidate_id: str, round_id: int) -> Optional[dict[str, Any]]:
    """Book the candidate into ANY open placeholder at the chosen slot's time.

    The picker collapses the parallel interviewer placeholders at one time into
    a single button, so the incoming slot_id is only a REPRESENTATIVE of that
    time. Claim whichever sibling is still open — atomic and concurrency-safe
    (``FOR UPDATE SKIP LOCKED``) so two candidates confirming the same time land
    on different interviewers instead of one hitting "just taken" while capacity
    remains. A stale/just-booked representative id also falls back to a free
    sibling this way. Returns None only when EVERY placeholder at that time is
    gone."""
    with get_conn() as conn:
        with conn.cursor() as cur:
            # The representative row still exists even if that exact id was
            # already booked — read its time/pool/round to find its siblings.
            cur.execute(
                "SELECT pool_id, round_name, slot_start, slot_end "
                "FROM interview_pool_slots WHERE id = %s",
                (slot_id,),
            )
            ref = cur.fetchone()
            if not ref:
                return None
            ref_pool_id, ref_round_name, ref_start, ref_end = ref
            cur.execute(
                "UPDATE interview_pool_slots SET status = 'booked', booked_candidate_id = %s, "
                "booked_round_id = %s, updated_at = CURRENT_TIMESTAMP "
                "WHERE id = ("
                "  SELECT id FROM interview_pool_slots "
                "  WHERE pool_id = %s AND round_name = %s AND slot_start = %s AND slot_end = %s "
                "    AND status = 'open' "
                "  ORDER BY id LIMIT 1 FOR UPDATE SKIP LOCKED"
                ") RETURNING id",
                (candidate_id, round_id, ref_pool_id, ref_round_name, ref_start, ref_end),
            )
            row = cur.fetchone()
    return get_slot(row[0]) if row else None


def prune_derostered_slots() -> dict[str, int]:
    """Cancel every still-OPEN pool placeholder whose (round, interviewer) is no
    longer on the round roster — call after Settings › Round Interviewers is
    edited so a removed interviewer's future slots stop being offered and stop
    cluttering their calendar / eating their day-budget. BOOKED slots are left
    untouched (a candidate is relying on that specific meeting)."""
    from app.services import round_interviewers_config

    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT s.id, s.interviewer_email, s.graph_event_id, s.round_name "
                "FROM interview_pool_slots s JOIN interview_pools p ON p.id = s.pool_id "
                "WHERE s.status = 'open' AND NOT p.archived"
            )
            rows = cur.fetchall()

    roster: dict[str, set[str]] = {}
    stale: list[tuple[Any, ...]] = []
    for slot_id, email, event_id, round_name in rows:
        emails = roster.get(round_name)
        if emails is None:
            emails = {
                (i.get("email") or "").strip().lower()
                for i in round_interviewers_config.interviewers_for(round_name)
            }
            roster[round_name] = emails
        if (email or "").strip().lower() not in emails:
            stale.append((slot_id, email, event_id))

    _cancel_open_slots(stale)
    if stale:
        log.info("interview_pools: pruned %d open slot(s) for de-rostered interviewers", len(stale))
    return {"cancelled": len(stale)}


def find_pool_for(source_label: Optional[str], round_name: str) -> Optional[dict[str, Any]]:
    """The pool matching this candidate's source + round (a pool may cover
    several rounds — this matches any pool whose round_names contains
    `round_name`) — prefers one whose date range covers today, else the most
    recently created match."""
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT * FROM interview_pools WHERE NOT archived AND round_names @> %s::jsonb "
                "AND (source_label = %s OR (source_label IS NULL AND %s IS NULL)) "
                "ORDER BY (CURRENT_DATE BETWEEN range_start AND range_end) DESC, created_at DESC "
                "LIMIT 1",
                (json.dumps([round_name]), source_label, source_label),
            )
            rows = _rows(cur)
    return rows[0] if rows else None
