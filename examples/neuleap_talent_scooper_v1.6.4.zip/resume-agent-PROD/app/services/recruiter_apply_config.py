"""Per-source-tag control over whether a Recruiter can move a candidate
forward while their predicted Next Best Action hasn't been applied yet —
configured per campaign source (Mailbox → Batch Archive → Live batches), not
globally. Each source (candidate_master.source; NULL/"" = "no source") gets
its own on/off flag; a source that's never been explicitly configured
defaults to OFF (admin review required).

Gates TWO things, both scoped to a candidate still in the "New" bucket
(unscreened, no NBA override yet — app.api.rounds._new_stage_eligible):
  1. The "Apply" button / apply-predicted-nba endpoint itself.
  2. Directly creating a round for that candidate (app.api.rounds.create_round)
     — otherwise a Recruiter could sidestep the Apply gate entirely by just
     scheduling "Round 1" by hand while admin review is still pending.

Once the NBA is applied (by whoever — Recruiter once allowed, or Admin
manually) the candidate leaves the New bucket and this gate no longer
applies to that candidate's later rounds.

Persisted as JSON in the bind-mounted ``secrets/`` dir, same runtime-file
philosophy as chatbot_widget_config.py.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, Optional

from app.logging_config import get_logger

log = get_logger(__name__)

_NO_SOURCE_KEY = "__none__"


def _path() -> Path:
    return Path(os.environ.get("RECRUITER_APPLY_CONFIG_FILE", "secrets/recruiter_apply_config.json"))


def _key_for(source: Optional[str]) -> str:
    source = (source or "").strip()
    return _NO_SOURCE_KEY if not source else source


def get() -> Dict[str, Any]:
    """``{"sources": {label_or_"__none__": bool}}`` — a source absent from
    this dict simply hasn't been configured yet (reads as disabled)."""
    try:
        raw = json.loads(_path().read_text(encoding="utf-8"))
        if isinstance(raw, dict) and isinstance(raw.get("sources"), dict):
            return {"sources": {str(k): bool(v) for k, v in raw["sources"].items() if isinstance(v, bool)}}
    except (OSError, ValueError):
        pass
    return {"sources": {}}


def is_enabled_for(source: Optional[str]) -> bool:
    return get()["sources"].get(_key_for(source), False)


def set_for_source(source: Optional[str], enabled: bool) -> Dict[str, Any]:
    cfg = get()
    cfg["sources"][_key_for(source)] = bool(enabled)
    path = _path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
        log.info("recruiter_apply_config: saved %s (source=%r enabled=%s)", path, source, enabled)
    except OSError as exc:  # noqa: BLE001
        log.warning("recruiter_apply_config: could not write %s: %s", path, exc)
    return get()
