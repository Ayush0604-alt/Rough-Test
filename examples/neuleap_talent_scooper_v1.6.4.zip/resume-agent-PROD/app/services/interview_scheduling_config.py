"""Candidate interview slot-selection settings — Settings → Interviewer
Access → "Interview Scheduling".

Governs the native candidate-facing slot picker: which calendar availability
is checked (for now always a single QA stand-in mailbox, regardless of which
real interviewer is rostered per round — see round_interviewers_config), how
long a slot is, and the reminder/auto-reject cadence for candidates who don't
book. JSON-file-backed, same runtime-file philosophy as nlrs_config.

``auto_invite_enabled`` defaults OFF: until an Admin explicitly turns it on,
advancing a candidate to a new round never sends them a real slot-invite
email — this is a deliberate safety gate so shipping this feature doesn't
silently start emailing in-flight candidates.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict

from app.logging_config import get_logger

log = get_logger(__name__)

DEFAULTS: Dict[str, Any] = {
    "qa_calendar_email": "sreesankar+candidate-test@neuleap.io",
    "slot_duration_minutes": 30,
    "reminder_max_count": 2,
    "reminder_interval_hours": 48,
    "auto_reject_after_days": 7,
    # Units for the two intervals above. "minutes" is a QA-environment-only
    # option (so a tester can exercise the full remind→remind→auto-reject
    # cycle in minutes instead of waiting hours/days); production stays on
    # hours/days. When the unit is "minutes", the NUMBER is read from the
    # same reminder_interval_hours / auto_reject_after_days fields — they're
    # just interpreted as minutes.
    "reminder_interval_unit": "hours",
    "auto_reject_after_unit": "days",
    "auto_invite_enabled": False,
}


def _path() -> Path:
    return Path(os.environ.get("INTERVIEW_SCHEDULING_FILE", "secrets/interview_scheduling.json"))


def get() -> Dict[str, Any]:
    out = dict(DEFAULTS)
    try:
        raw = json.loads(_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return out
    if isinstance(raw, dict):
        for k in DEFAULTS:
            if k in raw:
                out[k] = raw[k]
    return out


def save(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Validates then persists. Raises ValueError on an out-of-range value —
    a bad reminder/reject setting could leave candidates never reminded or
    rejected instantly, so it's rejected outright rather than swallowed."""
    email = str(payload.get("qa_calendar_email", "")).strip()
    if not email or "@" not in email:
        raise ValueError("QA calendar email must be a valid address.")

    def _int(key: str, lo: int, hi: int) -> int:
        v = payload.get(key)
        if not isinstance(v, (int, float)) or isinstance(v, bool) or not (lo <= v <= hi):
            raise ValueError(f"{key} must be a number between {lo} and {hi}.")
        return int(v)

    def _unit(key: str, default_unit: str) -> str:
        v = str(payload.get(key, default_unit) or default_unit)
        if v not in (default_unit, "minutes"):
            raise ValueError(f"{key} must be '{default_unit}' or 'minutes'.")
        if v == "minutes":
            from app.services import system_reset

            if not system_reset.is_wipe_allowed():
                raise ValueError("Minute-based intervals are only available in a QA environment.")
        return v

    interval_unit = _unit("reminder_interval_unit", "hours")
    reject_unit = _unit("auto_reject_after_unit", "days")
    data = {
        "qa_calendar_email": email,
        "slot_duration_minutes": _int("slot_duration_minutes", 10, 240),
        "reminder_max_count": _int("reminder_max_count", 0, 10),
        # When a unit is "minutes" the same number field simply reads as
        # minutes — allow a wider range so e.g. "90 minutes" fits.
        "reminder_interval_hours": _int(
            "reminder_interval_hours", 1, 10080 if interval_unit == "minutes" else 24 * 30
        ),
        "auto_reject_after_days": _int(
            "auto_reject_after_days", 1, 43200 if reject_unit == "minutes" else 90
        ),
        "reminder_interval_unit": interval_unit,
        "auto_reject_after_unit": reject_unit,
        "auto_invite_enabled": bool(payload.get("auto_invite_enabled", False)),
    }
    path = _path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        log.info("interview_scheduling_config: saved %s", path)
    except OSError as exc:  # noqa: BLE001
        log.warning("interview_scheduling_config: could not write %s: %s", path, exc)
    return get()


def revert_to_default() -> Dict[str, Any]:
    path = _path()
    try:
        if path.exists():
            path.unlink()
            log.info("interview_scheduling_config: reverted to default (%s removed)", path)
    except OSError as exc:  # noqa: BLE001
        log.warning("interview_scheduling_config: could not remove %s: %s", path, exc)
    return get()
