"""LLM provider keys & deployments — Settings → LLM Model Keys.

Stores the Azure OpenAI connection the app's LLM features use (endpoint, API
key, API version, default + fallback deployment) with the key ENCRYPTED at
rest (same Fernet scheme/posture as app.services.mailbox_account), plus
optional PER-MODULE overrides so e.g. the chatbot can run on a cheaper
deployment/key than resume extraction. Module keys mirror the llm_token_usage
ledger (Admin → Token Usage), so cost attribution and key routing speak the
same vocabulary.

Resolution order for any LLM call: module override → global DB config → env
vars (AZURE_OPENAI_*). Every field falls back independently, so a module
override that only sets `deployment` still inherits the global key/endpoint.

Security posture (mirrors mailbox_account):
  * API keys NEVER leave the server — the API returns only ``has_api_key``.
  * Saving requires the acting System Admin to re-enter their OWN password.
  * Every save is audit-logged (who + what changed, never the secret).
  * Resolution is best-effort: any DB/decrypt failure falls back to env so a
    misconfigured row can never take the pipeline down.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
from typing import Any, Dict, Optional

import psycopg2.extras
from cryptography.fernet import Fernet, InvalidToken

from app.config import settings
from app.db import get_conn
from app.logging_config import get_logger

log = get_logger(__name__)

# The modules that may carry their own key/deployment — same taxonomy as the
# token-usage ledger so the Token Usage page and this config line up 1:1.
MODULES = [
    "extraction",
    "analysis_report",
    "timeline",
    "interview_questions",
    "jd_match",
    "jd_match_explain",
    "chatbot_sql",
    "chatbot_narration",
]

# Which fields a module override may set (all optional; blank = inherit).
OVERRIDE_FIELDS = ["endpoint", "deployment", "api_key"]

_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS llm_api_config (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    endpoint TEXT,
    api_key_enc TEXT,
    api_version TEXT,
    deployment TEXT,
    fallback_deployment TEXT,
    module_overrides JSONB NOT NULL DEFAULT '{}'::jsonb,
    updated_by TEXT,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
"""

_table_ready = False


def _ensure_table() -> None:
    global _table_ready
    if _table_ready:
        return
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(_TABLE_SQL)
    _table_ready = True


def _fernet() -> Fernet:
    secret = os.environ.get("LLM_ENC_KEY") or os.environ.get("MAILBOX_ENC_KEY") or settings.jwt_secret
    key = base64.urlsafe_b64encode(hashlib.sha256(secret.encode("utf-8")).digest())
    return Fernet(key)


def _encrypt(value: str) -> str:
    return _fernet().encrypt(value.encode("utf-8")).decode("ascii")


def _decrypt(value: Optional[str]) -> Optional[str]:
    if not value:
        return None
    try:
        return _fernet().decrypt(value.encode("ascii")).decode("utf-8")
    except (InvalidToken, ValueError):
        log.warning("llm_config: stored key failed to decrypt (enc key rotated?) — ignoring")
        return None


def _row() -> Optional[dict]:
    _ensure_table()
    with get_conn() as conn:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute("SELECT * FROM llm_api_config WHERE id = 1")
            r = cur.fetchone()
            return dict(r) if r else None


def _overrides(r: Optional[dict]) -> Dict[str, Dict[str, str]]:
    raw = (r or {}).get("module_overrides") or {}
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except ValueError:
            raw = {}
    return raw if isinstance(raw, dict) else {}


def get_public() -> Dict[str, Any]:
    """Config as the API may expose it — keys never leave the server, only
    whether one is stored (globally and per module)."""
    r = _row()
    env_endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT", "")
    env_deployment = os.environ.get("AZURE_OPENAI_DEPLOYMENT", "")
    overrides = _overrides(r)
    modules_out = {}
    for m in MODULES:
        ov = overrides.get(m) or {}
        modules_out[m] = {
            "endpoint": ov.get("endpoint") or "",
            "deployment": ov.get("deployment") or "",
            "has_api_key": bool(ov.get("api_key_enc")),
        }
    return {
        "endpoint": (r or {}).get("endpoint") or env_endpoint,
        "has_api_key": bool((r or {}).get("api_key_enc")),
        "env_key_present": bool(os.environ.get("AZURE_OPENAI_KEY") or os.environ.get("AZURE_OPENAI_API_KEY")),
        "api_version": (r or {}).get("api_version") or os.environ.get("AZURE_OPENAI_API_VERSION", ""),
        "deployment": (r or {}).get("deployment") or env_deployment,
        "fallback_deployment": (r or {}).get("fallback_deployment")
        or os.environ.get("AZURE_OPENAI_FALLBACK_DEPLOYMENT", ""),
        "modules": modules_out,
        "updated_at": r["updated_at"].isoformat() if r and r.get("updated_at") else None,
        "updated_by": (r or {}).get("updated_by"),
    }


def save(
    *,
    endpoint: str,
    api_key: Optional[str],
    api_version: str,
    deployment: str,
    fallback_deployment: str,
    modules: Optional[Dict[str, Dict[str, str]]],
    updated_by: str,
) -> Dict[str, Any]:
    """Persist the global connection + per-module overrides. A blank api_key
    (global or per-module) KEEPS the already-stored one; the literal value
    ``"-"`` clears it (so a stored key can be removed without replacing it)."""
    endpoint = (endpoint or "").strip().rstrip("/")
    existing = _row()

    def _resolve_key(new_key: Optional[str], stored: Optional[str]) -> Optional[str]:
        if new_key == "-":
            return None
        if new_key:
            return _encrypt(new_key)
        return stored

    api_key_enc = _resolve_key(api_key, (existing or {}).get("api_key_enc"))

    stored_overrides = _overrides(existing)
    out_overrides: Dict[str, Dict[str, str]] = {}
    for m in MODULES:
        incoming = (modules or {}).get(m) or {}
        stored = stored_overrides.get(m) or {}
        ov: Dict[str, str] = {}
        ep = (incoming.get("endpoint") or "").strip().rstrip("/")
        dep = (incoming.get("deployment") or "").strip()
        key_enc = _resolve_key(incoming.get("api_key"), stored.get("api_key_enc"))
        if ep:
            ov["endpoint"] = ep
        if dep:
            ov["deployment"] = dep
        if key_enc:
            ov["api_key_enc"] = key_enc
        if ov:
            out_overrides[m] = ov

    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO llm_api_config
                    (id, endpoint, api_key_enc, api_version, deployment,
                     fallback_deployment, module_overrides, updated_by, updated_at)
                VALUES (1, %s, %s, %s, %s, %s, %s, %s, CURRENT_TIMESTAMP)
                ON CONFLICT (id) DO UPDATE SET
                    endpoint = EXCLUDED.endpoint,
                    api_key_enc = EXCLUDED.api_key_enc,
                    api_version = EXCLUDED.api_version,
                    deployment = EXCLUDED.deployment,
                    fallback_deployment = EXCLUDED.fallback_deployment,
                    module_overrides = EXCLUDED.module_overrides,
                    updated_by = EXCLUDED.updated_by,
                    updated_at = CURRENT_TIMESTAMP
                """,
                (
                    endpoint or None,
                    api_key_enc,
                    (api_version or "").strip() or None,
                    (deployment or "").strip() or None,
                    (fallback_deployment or "").strip() or None,
                    psycopg2.extras.Json(out_overrides),
                    updated_by,
                ),
            )
    try:
        from app.services import audit

        changed_modules = ", ".join(sorted(out_overrides)) or "none"
        audit.write_event(
            layer="SYSTEM", step="llm_config_changed", status="Info",
            fail_reason=(
                f"LLM model-key config saved by {updated_by}: endpoint "
                f"{'set' if endpoint else 'env-default'}, key "
                f"{'updated' if api_key and api_key != '-' else ('cleared' if api_key == '-' else 'kept')}, "
                f"deployment '{deployment or 'env-default'}', module overrides: {changed_modules}"
            ),
        )
    except Exception as exc:  # noqa: BLE001
        log.warning("llm_config: audit write failed: %s", exc)
    return get_public()


def resolve(module: Optional[str] = None) -> Dict[str, Optional[str]]:
    """Effective connection settings for one module's LLM call — module
    override → global DB row → env. Best-effort: any failure returns just the
    env-derived values so a broken row can never stop the pipeline."""
    out: Dict[str, Optional[str]] = {
        "endpoint": os.environ.get("AZURE_OPENAI_ENDPOINT"),
        "api_key": os.environ.get("AZURE_OPENAI_KEY") or os.environ.get("AZURE_OPENAI_API_KEY"),
        "api_version": os.environ.get("AZURE_OPENAI_API_VERSION"),
        "deployment": os.environ.get("AZURE_OPENAI_DEPLOYMENT"),
        "fallback_deployment": os.environ.get("AZURE_OPENAI_FALLBACK_DEPLOYMENT"),
        # True when `deployment` was set in Settings (globally or for this
        # module) — explicit admin intent, so callers let it beat the legacy
        # AZURE_OPENAI_MASTER/EXTRACT_DEPLOYMENT env-var chain.
        "deployment_from_db": False,
    }
    try:
        r = _row()
        if r:
            if r.get("endpoint"):
                out["endpoint"] = r["endpoint"]
            key = _decrypt(r.get("api_key_enc"))
            if key:
                out["api_key"] = key
            if r.get("api_version"):
                out["api_version"] = r["api_version"]
            if r.get("deployment"):
                out["deployment"] = r["deployment"]
                out["deployment_from_db"] = True
            if r.get("fallback_deployment"):
                out["fallback_deployment"] = r["fallback_deployment"]
            if module:
                ov = _overrides(r).get(module) or {}
                if ov.get("endpoint"):
                    out["endpoint"] = ov["endpoint"]
                if ov.get("deployment"):
                    out["deployment"] = ov["deployment"]
                    out["deployment_from_db"] = True
                mkey = _decrypt(ov.get("api_key_enc"))
                if mkey:
                    out["api_key"] = mkey
    except Exception as exc:  # noqa: BLE001 — env fallback keeps the pipeline alive
        log.warning("llm_config.resolve failed (module=%s) — using env: %s", module, exc)
    return out
