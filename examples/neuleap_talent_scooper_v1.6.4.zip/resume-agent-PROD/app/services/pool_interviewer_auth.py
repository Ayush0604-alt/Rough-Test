"""Interviewer timeslot-pool self-service portal login — email-code challenge
+ remembered session, mirroring app.services.interviewer_auth's exact shape,
but verified against the ROUND-INTERVIEWER ROSTER
(app.services.round_interviewers_config.find_interviewer) instead of an
allow-listed domain: only an email actually configured as an interviewer on
some round can request a code at all. Any configured interviewer can log in
here directly (no per-link token — this is a standing portal, not a
per-candidate share link), see every placeholder slot rostered to them across
every pool, and remove/adjust it (app.services.interview_pools).
"""
from __future__ import annotations

import random
import string
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

from app.db import get_conn
from app.logging_config import get_logger
from app.services import graph_client, round_interviewers_config

log = get_logger(__name__)

_CODE_TTL_MINUTES = 10
_UNREMEMBERED_SESSION_HOURS = 12
_REMEMBER_DAYS = 30


class NotAnInterviewer(Exception):
    """This email isn't configured as an interviewer on any round."""


class InvalidCode(Exception):
    """The submitted code is wrong, expired, or already used."""


def _gen_code() -> str:
    return "".join(random.choices(string.ascii_uppercase + string.digits, k=6))


def request_code(email: str) -> dict[str, Any]:
    email = email.strip().lower()
    interviewer = round_interviewers_config.find_interviewer(email)
    if not interviewer:
        raise NotAnInterviewer(f"{email} isn't configured as an interviewer.")

    code = _gen_code()
    expires_at = datetime.now(timezone.utc) + timedelta(minutes=_CODE_TTL_MINUTES)
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE pool_interviewer_otp SET consumed_at = CURRENT_TIMESTAMP "
                "WHERE email = %s AND consumed_at IS NULL",
                (email,),
            )
            cur.execute(
                "INSERT INTO pool_interviewer_otp (email, code, expires_at) VALUES (%s, %s, %s)",
                (email, code, expires_at),
            )

    result = graph_client.send_mail(
        email,
        "Your NeuLeap interviewer portal code",
        f"<p>Hi {interviewer['name']}, your access code is:</p>"
        f"<p style=\"text-align:center;\"><strong style=\"font-size:24px; letter-spacing:3px;\">{code}</strong></p>"
        f"<p>It expires in {_CODE_TTL_MINUTES} minutes.</p>",
    )
    if not result["sent"]:
        log.warning("pool_interviewer_auth: code email to %s not sent: %s", email, result.get("error"))
    return interviewer


def verify_code(email: str, code: str, *, remember: bool) -> str:
    email = email.strip().lower()
    code = code.strip().upper()
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT id FROM pool_interviewer_otp WHERE email = %s AND code = %s "
                "AND consumed_at IS NULL AND expires_at > CURRENT_TIMESTAMP",
                (email, code),
            )
            row = cur.fetchone()
            if not row:
                raise InvalidCode("That code is incorrect or has expired.")
            cur.execute(
                "UPDATE pool_interviewer_otp SET consumed_at = CURRENT_TIMESTAMP WHERE id = %s", (row[0],)
            )
            token = uuid.uuid4().hex
            expires_at = datetime.now(timezone.utc) + (
                timedelta(days=_REMEMBER_DAYS) if remember else timedelta(hours=_UNREMEMBERED_SESSION_HOURS)
            )
            cur.execute(
                "INSERT INTO pool_interviewer_sessions (session_token, email, expires_at) VALUES (%s, %s, %s)",
                (token, email, expires_at),
            )
    return token


def validate_session(token: Optional[str]) -> Optional[str]:
    if not token:
        return None
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT email FROM pool_interviewer_sessions "
                "WHERE session_token = %s AND expires_at > CURRENT_TIMESTAMP",
                (token,),
            )
            row = cur.fetchone()
    if not row:
        return None
    # Re-check roster membership every time (like interviewer_auth re-checks the
    # domain allow-list) — removing someone from the roster revokes access
    # immediately, not just for future code requests.
    return row[0] if round_interviewers_config.find_interviewer(row[0]) else None
