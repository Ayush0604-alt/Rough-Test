"""Microsoft Graph calendar availability — powers the candidate slot picker.

Checks ONE mailbox's calendar (for now, always the QA stand-in configured in
Settings → Interview Scheduling — see app.services.interview_scheduling_config
— regardless of which real interviewer is rostered per round; see
app.services.round_interviewers_config) via Graph's ``getSchedule`` action,
and turns the busy/free result into a flat list of bookable slots across
business hours for the current week through the next week.

Requires the **Calendars.Read** (or ReadWrite) Application permission to be
admin-consented in Azure AD in addition to the Mail.* permissions
app.services.graph_client already documents — that's a one-time portal change,
not a code change (the app-only ``.default`` scope picks up new consented
permissions automatically). Until that's granted, ``get_busy_intervals`` will
raise, and ``available_slots`` degrades gracefully: it logs a warning and
returns the full business-hours grid with nothing excluded, so the candidate
picker still works end-to-end (just without real busy-time awareness) rather
than hard-failing.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any, Optional

import requests

from app.logging_config import get_logger
from app.services import graph_client
from app.services.clock import business_tz

log = get_logger(__name__)

_BUSINESS_START_HOUR = 10
_BUSINESS_END_HOUR = 18
_WEEKDAYS_AHEAD = 14  # "current week to next week"
_INTERVAL_MINUTES = 30  # Graph availabilityView granularity

# Public aliases — app.services.interview_pools reuses the same business-hours
# definition when carving "first half"/"second half" day windows for pools.
BUSINESS_START_HOUR = _BUSINESS_START_HOUR
BUSINESS_END_HOUR = _BUSINESS_END_HOUR


def get_busy_intervals(email: str, start: datetime, end: datetime) -> list[tuple[datetime, datetime]]:
    """Busy blocks for `email` between start/end (both tz-aware), via Graph's
    getSchedule action. Raises if Graph isn't configured or the call fails —
    callers decide how to degrade (see available_slots).

    Returned as naive business_tz wall-clock datetimes, matching how every
    caller (available_slots, interview_pools' day-window/candidate-slot math)
    represents times. getSchedule's scheduleItems always come back in UTC —
    regardless of the timeZone requested in startTime/endTime — so without
    converting here, a genuinely busy block would silently fail to overlap a
    candidate slot compared in business_tz, and a placeholder would land
    right on top of a real (even un-accepted/tentative) meeting."""
    if not graph_client.is_configured():
        raise RuntimeError("graph_not_configured")

    tz = business_tz()
    body = {
        "schedules": [email],
        "startTime": {"dateTime": start.isoformat(), "timeZone": str(tz)},
        "endTime": {"dateTime": end.isoformat(), "timeZone": str(tz)},
        "availabilityViewInterval": _INTERVAL_MINUTES,
    }
    resp = requests.post(
        f"https://graph.microsoft.com/v1.0/users/{graph_client._mailbox()}/calendar/getSchedule",  # noqa: SLF001
        headers={**graph_client._headers(), "Content-Type": "application/json"},  # noqa: SLF001
        json=body,
        timeout=20,
    )
    resp.raise_for_status()
    data = resp.json()
    schedules = data.get("value") or []
    if not schedules:
        return []

    busy: list[tuple[datetime, datetime]] = []
    for item in schedules[0].get("scheduleItems") or []:
        # "free" is the only status that isn't a conflict — everything else
        # (busy, tentative — an invite the interviewer hasn't responded to
        # yet, oof, workingElsewhere) must block a placeholder from landing
        # there.
        if item.get("status") in (None, "free"):
            continue
        s = item.get("start", {}).get("dateTime")
        e = item.get("end", {}).get("dateTime")
        if not s or not e:
            continue
        busy_start = datetime.fromisoformat(s).replace(tzinfo=timezone.utc).astimezone(tz).replace(tzinfo=None)
        busy_end = datetime.fromisoformat(e).replace(tzinfo=timezone.utc).astimezone(tz).replace(tzinfo=None)
        busy.append((busy_start, busy_end))
    return busy


def _overlaps(a_start: datetime, a_end: datetime, busy: list[tuple[datetime, datetime]]) -> bool:
    for b_start, b_end in busy:
        if a_start < b_end and b_start < a_end:
            return True
    return False


def available_slots(
    calendar_email: str, duration_minutes: int, *, from_time: datetime | None = None
) -> list[dict[str, Any]]:
    """Bookable [{start, end}] (ISO, business-tz) slots across weekday business
    hours from now (or `from_time`) through _WEEKDAYS_AHEAD days out — with
    any Graph-reported busy time on `calendar_email` excluded, when available."""
    tz = business_tz()
    start_window = (from_time or datetime.now(tz)).astimezone(tz)
    end_window = start_window + timedelta(days=_WEEKDAYS_AHEAD)

    busy: list[tuple[datetime, datetime]] = []
    try:
        busy = get_busy_intervals(calendar_email, start_window, end_window)
    except Exception as exc:  # noqa: BLE001 — degrade to a plain grid, never hard-fail
        log.warning("graph_calendar: busy-time lookup failed, showing full grid: %s", exc)

    slots: list[dict[str, Any]] = []
    day = start_window.replace(hour=_BUSINESS_START_HOUR, minute=0, second=0, microsecond=0)
    if day < start_window:
        day += timedelta(days=1)
        day = day.replace(hour=_BUSINESS_START_HOUR, minute=0, second=0, microsecond=0)

    while day < end_window:
        if day.weekday() < 5:  # Mon-Fri only
            slot_start = day
            day_end = day.replace(hour=_BUSINESS_END_HOUR, minute=0)
            while slot_start + timedelta(minutes=duration_minutes) <= day_end:
                slot_end = slot_start + timedelta(minutes=duration_minutes)
                if slot_start > start_window and not _overlaps(slot_start, slot_end, busy):
                    slots.append({"start": slot_start.isoformat(), "end": slot_end.isoformat()})
                slot_start = slot_end
        day = (day + timedelta(days=1)).replace(hour=_BUSINESS_START_HOUR, minute=0, second=0, microsecond=0)

    return slots


# ── Placeholder-event management — powers the interviewer timeslot pools
# (app.services.interview_pools). Every call requires Calendars.ReadWrite in
# addition to Calendars.Read; all raise on failure — callers (interview_pools)
# decide whether a failure is fatal (gather/refresh) or just logged (the
# hourly sync job scanning many slots shouldn't abort on one bad call).

def create_event(email: str, subject: str, start: datetime, end: datetime) -> str:
    """Creates a calendar event on `email`'s calendar (the interviewer), showing
    as "Busy" so it blocks the slot like a real meeting would. Returns the
    Graph event id (needed later to update/delete it)."""
    if not graph_client.is_configured():
        raise RuntimeError("graph_not_configured")
    tz = business_tz()
    body = {
        "subject": subject,
        "start": {"dateTime": start.isoformat(), "timeZone": str(tz)},
        "end": {"dateTime": end.isoformat(), "timeZone": str(tz)},
        "showAs": "busy",
        "isReminderOn": False,
    }
    resp = requests.post(
        f"https://graph.microsoft.com/v1.0/users/{email}/events",
        headers={**graph_client._headers(), "Content-Type": "application/json"},  # noqa: SLF001
        json=body,
        timeout=20,
    )
    resp.raise_for_status()
    return resp.json()["id"]


def get_event(email: str, event_id: str) -> Optional[dict[str, Any]]:
    """The event's current {start, end} — naive datetimes in business_tz wall-
    clock, matching how create_event/update_event write them and how
    interview_pool_slots stores slot_start/slot_end — or None if it no longer
    exists (i.e. the interviewer deleted it from their calendar).

    Without the `Prefer: outlook.timezone` header, Graph returns start/end in
    the mailbox's own default timezone (typically UTC) regardless of what
    timezone the event was created in — comparing that directly against our
    business-tz-naive DB columns would misreport every event as "moved" by a
    fixed UTC offset, corrupting slot_start/slot_end on every sync."""
    if not graph_client.is_configured():
        raise RuntimeError("graph_not_configured")
    tz = business_tz()
    resp = requests.get(
        f"https://graph.microsoft.com/v1.0/users/{email}/events/{event_id}",
        headers={**graph_client._headers(), "Prefer": f'outlook.timezone="{tz}"'},  # noqa: SLF001
        params={"$select": "start,end"},
        timeout=20,
    )
    if resp.status_code == 404:
        return None
    resp.raise_for_status()
    data = resp.json()
    return {
        "start": datetime.fromisoformat(data["start"]["dateTime"]),
        "end": datetime.fromisoformat(data["end"]["dateTime"]),
    }


def update_event(email: str, event_id: str, *, start: datetime, end: datetime) -> None:
    if not graph_client.is_configured():
        raise RuntimeError("graph_not_configured")
    tz = business_tz()
    body = {
        "start": {"dateTime": start.isoformat(), "timeZone": str(tz)},
        "end": {"dateTime": end.isoformat(), "timeZone": str(tz)},
    }
    resp = requests.patch(
        f"https://graph.microsoft.com/v1.0/users/{email}/events/{event_id}",
        headers={**graph_client._headers(), "Content-Type": "application/json"},  # noqa: SLF001
        json=body,
        timeout=20,
    )
    resp.raise_for_status()


def convert_to_teams_meeting(
    email: str,
    event_id: str,
    *,
    subject: str,
    attendees: list[dict[str, Optional[str]]],
    body_html: str,
) -> Optional[str]:
    """Turns an existing event (e.g. a pool placeholder created by create_event)
    into a real Teams meeting, IN PLACE — `email` stays the organizer (it's
    their own calendar/event being patched), `attendees` are added so they get
    Exchange's own meeting-invite email with the Teams join link. Returns the
    generated onlineMeeting.joinUrl, or None if Graph didn't return one."""
    if not graph_client.is_configured():
        raise RuntimeError("graph_not_configured")
    body = {
        "subject": subject,
        "showAs": "busy",
        "isReminderOn": True,
        "isOnlineMeeting": True,
        "onlineMeetingProvider": "teamsForBusiness",
        "body": {"contentType": "HTML", "content": body_html},
        "attendees": [
            {
                "emailAddress": {"address": a["email"], "name": a.get("name") or a["email"]},
                "type": "required",
            }
            for a in attendees
            if a.get("email")
        ],
    }
    resp = requests.patch(
        f"https://graph.microsoft.com/v1.0/users/{email}/events/{event_id}",
        headers={**graph_client._headers(), "Content-Type": "application/json"},  # noqa: SLF001
        json=body,
        timeout=20,
    )
    resp.raise_for_status()
    return (resp.json().get("onlineMeeting") or {}).get("joinUrl")


def delete_event(email: str, event_id: str) -> None:
    if not graph_client.is_configured():
        raise RuntimeError("graph_not_configured")
    resp = requests.delete(
        f"https://graph.microsoft.com/v1.0/users/{email}/events/{event_id}",
        headers=graph_client._headers(),  # noqa: SLF001
        timeout=20,
    )
    if resp.status_code not in (204, 404):  # 404 = already gone, treat as success
        resp.raise_for_status()
