"""Draft email dispatch — the one place a draft's real send happens, so the
manual "Send" button (app.api.rounds.send_email_draft) and the auto-send-on-
create path (Settings → Email Send Controls → "draft_review_required" off,
wired in ``_apply_nba_key``) share identical QA-restriction and audit-trail
behavior.

QA restriction: in any non-production environment (reuses
app.services.system_reset.is_wipe_allowed()'s exact env-alias check — same
"is this a real production deploy" gate already used for the DB-wipe
feature), every draft is ALWAYS redirected to the configured QA test email
instead of the candidate's real address — reusing Settings → Interview
Scheduling → "QA calendar email" as that one already-configured QA inbox,
rather than adding a duplicate setting for the same purpose. If that's
blank, nothing is sent — the caller gets a clear warning either way.
"""
from __future__ import annotations

from typing import Any, Optional

from app.logging_config import get_logger
from app.services import audit, graph_client, interview_scheduling_config, system_reset

log = get_logger(__name__)


def resolve_recipient(candidate_email: Optional[str]) -> tuple[Optional[str], bool]:
    """(recipient, was_qa_redirected). A None recipient means "don't send"."""
    if system_reset.is_wipe_allowed():  # non-production env
        qa_email = (interview_scheduling_config.get().get("qa_calendar_email") or "").strip()
        return (qa_email or None), True
    return candidate_email, False


def send_draft(draft: dict[str, Any], candidate: dict[str, Any]) -> dict[str, Any]:
    """Sends `draft`'s subject/body via Graph mail, respecting the QA
    restriction. Always writes an audit event — including when it's blocked
    for a missing QA email — so the trail always shows what would have
    happened, whether or not a recruiter ever opened the draft."""
    recipient, qa_redirected = resolve_recipient(candidate.get("email"))
    if not recipient:
        audit.write_event(
            candidate_id=draft["candidate_id"], layer="L4", step="email_draft_send_blocked",
            status="Info",
            fail_reason=(
                f'Draft "{draft["subject"]}" NOT sent — this is a non-production environment '
                f"and no QA test email is configured (Settings → Interview Scheduling)."
            ),
        )
        return {
            "sent": False, "recipient": None, "qa_redirected": qa_redirected,
            "warning": "Not sent — the QA test email isn't configured.",
        }

    html_body = graph_client.plain_text_to_html(draft["body"])
    result = graph_client.send_mail(recipient, draft["subject"], html_body)
    audit.write_event(
        candidate_id=draft["candidate_id"], layer="L4", step="email_draft_sent",
        status="Info" if result["sent"] else "Failed",
        fail_reason=(
            f'Draft "{draft["subject"]}" sent to {recipient}'
            + (" (QA-redirected from the candidate's real address)" if qa_redirected else "")
            + (f" — Graph error: {result.get('error')}" if not result["sent"] else "")
        ),
        draft_id=draft["draft_id"],
    )
    return {
        "sent": result["sent"], "recipient": recipient, "qa_redirected": qa_redirected,
        "warning": None if result["sent"] else result.get("error"),
    }
