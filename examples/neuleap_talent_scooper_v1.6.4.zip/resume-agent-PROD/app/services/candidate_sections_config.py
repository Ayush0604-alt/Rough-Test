"""Candidate profile page — which optional sections are shown.

Backs the Settings page's "Candidate Page Sections" block: a flat
``{section_key: visible}`` toggle set, shared by every user. Persisted as JSON
in the bind-mounted ``secrets/`` dir (default ``secrets/candidate_sections.json``,
override with ``CANDIDATE_SECTIONS_CONFIG_FILE``) — the same runtime-file
philosophy as chatbot_widget_config/column_config.

Unlike column_config, there's no ordering here — the candidate page's layout
is fixed, only whether each section renders at all.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict

from app.logging_config import get_logger

log = get_logger(__name__)

# (key, default visible). Keys MUST match the frontend's gating in Candidate/index.tsx.
_DEFAULTS: Dict[str, bool] = {
    "quick_signals": False,
    "thinking_summary": False,
    "ats_breakdown": False,
    "nlrs_breakdown": True,
    "skills": False,
    "certificates": True,
    "career_timeline": False,
    # The "Round History" card — every round's interviewer/outcome/feedback.
    # Defaults ON since it was previously an unconditional section; hiding it
    # now would be a visible regression out of the box.
    "round_history": True,
}


def _path() -> Path:
    return Path(os.environ.get("CANDIDATE_SECTIONS_CONFIG_FILE", "secrets/candidate_sections.json"))


def get() -> Dict[str, Any]:
    try:
        raw = json.loads(_path().read_text(encoding="utf-8"))
        if isinstance(raw, dict):
            return {**_DEFAULTS, **{k: bool(raw[k]) for k in _DEFAULTS if k in raw}}
    except (OSError, ValueError):
        pass
    return dict(_DEFAULTS)


def save(data: Dict[str, Any]) -> Dict[str, Any]:
    """Persist the toggles. Writing never raises — a disk hiccup just keeps the
    old values in effect rather than breaking the save request."""
    merged = {**_DEFAULTS, **{k: bool(data[k]) for k in _DEFAULTS if k in data}}
    path = _path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(merged, indent=2), encoding="utf-8")
        log.info("candidate_sections_config: saved %s", path)
    except OSError as exc:  # noqa: BLE001
        log.warning("candidate_sections_config: could not write %s: %s", path, exc)
    return get()
