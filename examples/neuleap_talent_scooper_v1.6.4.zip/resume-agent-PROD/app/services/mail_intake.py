"""Intake staging — turn external sources into pipeline-ready items.

Both the Graph mail intake and the file-upload endpoint funnel through here.
Each staged email is given a Postgres-sequence ``E_id`` and written to the
**MinIO staging queue** at ``raw/temp/{E_id}/`` — its attachments plus a
``{E_id}.json`` manifest. The LangGraph pipeline discovers it from MinIO on the
next ``/run-pipeline`` (pending until ``email_master`` shows it Passed).

MinIO is the only durable store; no local filesystem is used for staging.
"""

from __future__ import annotations

import base64
import html
import os
import re
from pathlib import Path
from typing import Any, Optional

from app.db import email_master as db
from app.logging_config import get_logger
from app.mail_config import ACCEPTED_INPUT_TYPES, MAX_UPLOAD_ABSOLUTE_BYTES, Settings
from app.services import mail_storage as storage

_URL_RE = re.compile(r"https?://[^\s<>\"')]+", re.IGNORECASE)


def _extract_links(text: str) -> list[str]:
    """Pull http(s) URLs out of a mail body (for the resume-payload classifier)."""
    return _URL_RE.findall(text or "")


# ── Forwarded-mail sender recovery ───────────────────────────────────────────────
# When a resume is forwarded (FW:/FWD:) the envelope "from" is the FORWARDER (e.g. a
# recruiter mailbox), not the candidate. The real sender sits in the quoted header
# block inside the body ("From: Name <addr>"). Recover it so email_master.sender_mail_id
# — and the Screening "by email" filter — reflect the ORIGINAL sender, not the forwarder.
_FW_SUBJECT_RE = re.compile(r"^\s*(fw|fwd)\b", re.IGNORECASE)
_FW_BODY_MARKERS = ("forwarded message", "-----original message-----", "begin forwarded message")
_FROM_LABEL_RE = re.compile(r"from\s*:", re.IGNORECASE)
_NEXT_HEADER_RE = re.compile(r"\b(sent|date|to|subject|cc|reply-to)\s*:", re.IGNORECASE)
_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")
_TAG_RE = re.compile(r"<[^>]+>")


def _forward_from_windows(text: str) -> list[str]:
    """The text window after each quoted ``From:`` label (up to the next header label).

    Nested/multiply-forwarded mail stacks several ``From:`` blocks newest-on-top, so this
    returns them in reading order: the LAST window is the deepest forward — the ORIGINAL
    sender. Each window stops at the next header (Sent:/Date:/To:/…) so a recipient list
    below the From: line can never be mistaken for the sender.
    """
    windows: list[str] = []
    for label in _FROM_LABEL_RE.finditer(text):
        window = text[label.end(): label.end() + 300]
        nxt = _NEXT_HEADER_RE.search(window)
        if nxt:
            window = window[: nxt.start()]
        windows.append(window)
    return windows


def original_sender_from_forward(subject: str, body: str, fallback: str) -> str:
    """Return the ORIGINAL sender address for a forwarded mail, else ``fallback``.

    Acts only on mail that looks forwarded (FW/FWD subject prefix or a forwarded-header
    marker in the body). Walks EVERY quoted ``From:`` block and keeps the DEEPEST (last)
    one — so a chain forward (candidate → agency → recruiter, or ``FW: FW:``) resolves to
    the original candidate, not an intermediate forwarder. Tolerates HTML by unescaping
    entities and matching the address inside ``<...>`` or a ``mailto:`` link.
    """
    subj = subject or ""
    raw = html.unescape(body or "")
    is_forward = bool(_FW_SUBJECT_RE.match(subj)) or any(
        m in raw.lower() for m in _FW_BODY_MARKERS
    )
    if not is_forward:
        return fallback

    found = fallback
    for window in _forward_from_windows(raw):
        match = _EMAIL_RE.search(window)
        if match:
            found = match.group(0).strip().strip("<>").lower() or found
    return found or fallback


def original_sender_display_from_forward(subject: str, body: str, fallback: str) -> str:
    """Return the ORIGINAL sender's DISPLAY NAME for a forwarded mail, else ``fallback``.

    Companion to :func:`original_sender_from_forward` for the Intake queue *preview*:
    where that recovers the original sender's address (persisted to email_master), this
    recovers the human name ("Harsh Chhabda") from the quoted ``From:`` block so the queue
    shows who actually sent the resume, not the forwarding mailbox. Falls back to the
    recovered address, then ``fallback`` (usually the envelope sender's name/address).

    HTML tags are stripped FIRST (while ``&lt;addr&gt;`` is still entity-escaped, so the
    quoted address isn't mistaken for a tag); entities are unescaped afterwards.
    """
    subj = subject or ""
    text = html.unescape(_TAG_RE.sub(" ", body or ""))
    is_forward = bool(_FW_SUBJECT_RE.match(subj)) or any(
        m in text.lower() for m in _FW_BODY_MARKERS
    )
    if not is_forward:
        return fallback

    # Walk every quoted From: block; the DEEPEST (last) one is the original sender, so it
    # wins — matching the address recovered by original_sender_from_forward().
    result = fallback
    for window in _forward_from_windows(text):
        addr = _EMAIL_RE.search(window)
        # The display name is the text before the quoted address (or before the "<addr>").
        name = window[: addr.start()] if addr else window
        name = re.sub(r"\s+", " ", name.replace("<", " ").replace(">", " ")).strip().strip('"').strip()
        if name:
            result = name
        elif addr:
            result = addr.group(0).strip().strip("<>").lower()
    return result

# Staged items live in MinIO at raw/temp/{E_id}/{E_id}.json. They are "pending"
# until email_master shows them Passed — there is no intake_pending table.

log = get_logger(__name__)


def _write_item(
    settings: Settings,
    e_id: str,
    files: list[tuple[str, bytes]],
    *,
    source: str,
    sender_mail_id: str = "unknown",
    subject: str = "unknown",
    received_date: str | None = None,
    body: str = "",
    links: list[str] | None = None,
    candidate_source: str | None = None,
) -> dict[str, Any]:
    """Materialize one staged email into the MinIO staging queue (raw/temp/{E_id}/).

    ``source`` here is the internal intake-mechanism tag ("upload" vs "graph") —
    NOT the recruiter-typed intake source. ``candidate_source`` is that (e.g.
    "LinkedIn", "Naukri", "Referral - Jane"); it rides in the manifest so L1 can
    carry it onto email_master, then onto every candidate this batch produces.
    """
    stored_names: list[str] = []
    for name, data in files:
        safe = Path(name).name
        ext = Path(safe).suffix.lower()
        if ext not in ACCEPTED_INPUT_TYPES:
            log.warning("intake %s: skipping unsupported attachment %s", e_id, safe)
            continue
        storage.put_staging_file(e_id, safe, data)
        stored_names.append(safe)

    manifest = {
        "e_id": e_id,
        "source": source,
        "candidate_source": candidate_source,
        "sender_mail_id": sender_mail_id,
        "subject": subject,
        "received_date": received_date,
        "attachments": stored_names,
        "links": links or [],
        "body": body,
    }
    storage.put_staging_manifest(e_id, manifest)

    log.info("intake staged %s (%s) to MinIO: %d file(s)", e_id, source, len(stored_names))
    return {"e_id": e_id, "attachments": stored_names, "links": links or []}


# --------------------------------------------------------------------------- #
# Upload
# --------------------------------------------------------------------------- #

def stage_upload(
    settings: Settings,
    filename: str,
    data: bytes,
    *,
    candidate_source: str,
    sender_mail_id: str = "direct",
    subject: str | None = None,
) -> dict[str, Any]:
    """Stage a single uploaded file (pdf/docx/zip/xlsx) as a pending email.

    Direct uploads carry sender_mail_id="direct" and received_date=today, so they
    appear in Email_Master as a single mail received via the upload button.
    ``candidate_source`` is the recruiter-typed intake source — mandatory here
    (the API layer enforces non-empty) since it's attached to every candidate
    this batch produces.
    """
    e_id = db.next_eid()
    return _write_item(
        settings, e_id, [(filename, data)],
        source="upload",
        sender_mail_id=sender_mail_id,
        subject=subject or Path(filename).stem,
        received_date=db.now_iso()[:10],
        candidate_source=candidate_source,
    )


# --------------------------------------------------------------------------- #
# Graph mail intake
# --------------------------------------------------------------------------- #

def _route_rejected_graph(message_id: Optional[str]) -> None:
    """Move a non-resume / blocklisted mail to the Non-Resume folder (best-effort), so it
    leaves the Inbox and isn't re-evaluated on the next run."""
    if not message_id:
        return
    from app.services import graph_client

    try:
        if graph_client.move_enabled():
            graph_client.move_message(message_id, "non_resume")
        else:
            graph_client.mark_read(message_id)
    except Exception as exc:  # noqa: BLE001 — routing must never abort staging
        log.warning("graph intake: could not route rejected %s — %s", message_id, exc)


def _download_graph_attachments(msg: dict[str, Any]) -> list[tuple[str, bytes]]:
    """Decode a Graph message's file attachments into (name, bytes) pairs."""
    if not msg.get("hasAttachments"):
        return []
    from app.services import graph_client

    files: list[tuple[str, bytes]] = []
    for att in graph_client.fetch_attachments(msg["id"]):
        content_b64 = att.get("contentBytes")
        if not content_b64:
            continue
        raw = base64.b64decode(content_b64)
        # Anti-OOM ceiling. A file over its per-type cap but under this limit still
        # stages and surfaces as FAILED via the validators; only pathological sizes
        # are dropped here (logged, never silently lost from the run summary).
        if len(raw) > MAX_UPLOAD_ABSOLUTE_BYTES:
            log.warning(
                "intake: skipping oversized attachment %s (%.1f MB)",
                att.get("name"), len(raw) / (1024 * 1024),
            )
            continue
        files.append((att["name"], raw))
    return files


def _stage_one_graph_message(
    settings: Settings, msg: dict[str, Any], *, filter_on: bool
) -> Optional[dict[str, Any]]:
    """Stage ONE Graph message, or return None if it was rejected (and routed to Failed).

    Prefers the FULL HTML body — resume share links (SharePoint/OneDrive/Drive) are
    hyperlinks in the HTML, absent from the truncated bodyPreview. Rejected mail (block-
    listed sender or non-resume) is moved to Failed; an accepted mail is staged to MinIO
    and moved Inbox → Processing.
    """
    from app.pipeline.mail.queue import agent_classifier, resume_filter
    from app.services import graph_client

    subject = msg.get("subject") or ""
    body = (msg.get("body") or {}).get("content") or msg.get("bodyPreview") or ""
    links = _extract_links(body)
    sender = (msg.get("from") or {}).get("emailAddress", {}).get("address", "unknown")

    # Cheap first pass: blocklisted senders are rejected BEFORE downloading attachments.
    if filter_on and resume_filter.blocklisted_sender(sender):
        log.info("graph intake: rejected %s — %s → Failed",
                 sender, resume_filter.blocklisted_sender(sender))
        _route_rejected_graph(msg["id"])
        return None

    files = _download_graph_attachments(msg)

    # RESUME GATE: only mail carrying a resume payload is staged (before an E_id is minted).
    if filter_on:
        accept, reason = agent_classifier.classify_is_resume(
            subject, body, [n for n, _ in files], links, sender,
        )
        if not accept:
            log.info("graph intake: rejected %s — %s → Failed", subject[:60], reason)
            _route_rejected_graph(msg["id"])
            return None

    e_id = db.next_eid()
    # For forwarded resumes, persist the ORIGINAL sender (recovered from the body), not
    # the forwarder. The blocklist/resume gate above still ran on the envelope sender.
    sender_for_row = original_sender_from_forward(subject, body, sender or "unknown")
    # Auto-stamp the currently active "social post" source tag (Mailbox page →
    # "Register recent social post as a source tag"), if any is active — so
    # every reply to that post is tagged without the recruiter tagging each
    # email by hand. None when nothing's active; candidate_source stays unset.
    from app.services import source_tags

    item = _write_item(
        settings, e_id, files,
        source="graph",
        sender_mail_id=sender_for_row,
        subject=msg.get("subject") or "unknown",
        received_date=msg.get("receivedDateTime"),
        body=body,
        links=links,
        candidate_source=source_tags.active_label(),
    )
    item["message_id"] = msg["id"]
    # Route Inbox → Processing so it isn't re-fetched; keep the reassigned id (Graph
    # re-IDs on move) for the later Processed/Failed move.
    if graph_client.move_enabled():
        item["message_id"] = graph_client.move_message(msg["id"], "processing") or msg["id"]
    else:
        graph_client.mark_read(msg["id"])
    return item


def _parse_iso(value: str | None):
    """Parse a Graph receivedDateTime ('...Z') into an aware datetime, or None."""
    if not value:
        return None
    try:
        from datetime import datetime

        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        return None


def _processing_max_age_days() -> int:
    """How many calendar days old a resume may be and still be processed.

    Landing is a curated intake folder where mail legitimately WAITS (forwarded /
    dropped in over several days), so the queue must include "previous days" resumes —
    not age them out after 2 days like the old Inbox model did. Default is now **365**:
    effectively "process whatever's waiting", while still catching truly ancient or
    undateable mail (``_age_days`` returns 9999 for the latter → still moved to Failed).
    Override with ``GRAPH_PROCESSING_MAX_AGE_DAYS``.
    """
    try:
        return max(0, int(os.environ.get("GRAPH_PROCESSING_MAX_AGE_DAYS", "365")))
    except ValueError:
        return 365


def _age_days(received_date: str | None) -> int:
    """Calendar-day age of a Graph ``receivedDateTime`` in the business timezone.

    today → 0, yesterday → 1, … Undateable mail returns a large number so it is
    treated as expired (moved to Failed) rather than re-queued forever.
    """
    from app.services import clock

    received = _parse_iso(received_date)
    if received is None:
        return 9999
    received_local = received.astimezone(clock.business_tz()).date()
    return (clock.now().date() - received_local).days


def _restage_processing_message(
    settings: Settings, msg: dict[str, Any]
) -> Optional[dict[str, Any]]:
    """Stage one message from the Processing queue for the pipeline.

    It already passed the resume gate (that's how it reached Processing — via the 60s
    poller or a fallback Inbox drain), so we skip the filter and DON'T move it (it stays
    in Processing); phase 2 moves it Processed/Failed once its freshly-minted E_id
    finishes. Carries ``message_id`` so phase 2 can route it.
    """
    subject = msg.get("subject") or ""
    body = (msg.get("body") or {}).get("content") or msg.get("bodyPreview") or ""
    links = _extract_links(body)
    sender = (msg.get("from") or {}).get("emailAddress", {}).get("address", "unknown")

    files = _download_graph_attachments(msg)
    e_id = db.next_eid()
    # Forwarded resumes: persist the original sender recovered from the body.
    sender_for_row = original_sender_from_forward(subject, body, sender or "unknown")
    # Auto-stamp the currently active "social post" source tag, exactly as the Inbox
    # path (_stage_one_graph_message) does — this Processing-queue drain is the PRIMARY
    # graph path (60s poller auto-promotes Inbox→Processing), so without this every
    # poller-fed resume would land with no source. None when nothing's active.
    from app.services import source_tags

    item = _write_item(
        settings, e_id, files,
        source="graph-processing",
        sender_mail_id=sender_for_row,
        subject=subject or "unknown",
        received_date=msg.get("receivedDateTime"),
        body=body,
        links=links,
        candidate_source=source_tags.active_label(),
    )
    item["message_id"] = msg["id"]   # already in Processing → phase 2 moves to Processed
    return item


def drain_processing_queue(settings: Settings, max_age_days: int | None = None) -> dict[str, Any]:
    """Stage every resume in the **Processing** folder for the pipeline — the queue drain.

    The Processing folder IS the pipeline's queue (the 60s poller moves Landing resumes
    into it). For each message, by calendar-day age in the business timezone:
      * **≤ max_age_days** (default 365 — i.e. anything waiting, incl. previous days) →
        re-queue it so L1→L2→L3 runs; it stays in Processing until phase 2 routes it to
        Processed (success) or Failed (error);
      * **older / undateable** → move it to **Failed** — too stale to process.

    No-op unless Graph is configured AND folder moves are enabled. Returns the re-queued
    items (folded into the batch) plus how many were aged out to Failed.
    """
    from app.services import graph_client

    if not (graph_client.is_configured() and graph_client.move_enabled()):
        return {"requeued": [], "expired": 0}

    days = _processing_max_age_days() if max_age_days is None else max(0, max_age_days)

    # Bound how many Processing messages one run drains, so a large backlog can't stall
    # the synchronous batch before it reaches the manually-staged uploads. Leftovers are
    # picked up by the next run. Set GRAPH_DRAIN_BATCH (default 100).
    try:
        drain_cap = max(1, int(os.environ.get("GRAPH_DRAIN_BATCH", "100")))
    except ValueError:
        drain_cap = 100

    try:
        messages = graph_client.fetch_folder("processing", top=drain_cap)
    except Exception as exc:  # noqa: BLE001 — draining must never abort a run
        log.warning("processing queue: could not list Processing — %s", exc)
        return {"requeued": [], "expired": 0}

    requeued: list[dict[str, Any]] = []
    expired = 0
    for msg in messages:
        try:
            if _age_days(msg.get("receivedDateTime")) <= days:
                item = _restage_processing_message(settings, msg)
                if item is not None:
                    requeued.append(item)
            else:
                # 3+ days old (or undateable) — too stale to process → Failed.
                log.info("processing queue: %s aged out (>%dd) → Failed",
                         msg.get("id"), days)
                graph_client.move_message(msg["id"], "failed")
                expired += 1
        except Exception as exc:  # noqa: BLE001 — one bad mail must not abort the drain
            log.warning("processing queue: skipping %s — %s", msg.get("id"), exc)

    if requeued or expired:
        log.info("processing queue: re-queued %d, aged-out→Failed %d",
                 len(requeued), expired)
    return {"requeued": requeued, "expired": expired}


def stage_graph_messages(settings: Settings, top: int | None = None) -> dict[str, Any]:
    """Stage the Graph **Processing queue** for the pipeline (+ Inbox fallback).

    The pipeline's queue is the **Processing folder**: the 60s poller moves Landing
    resumes into it, and this drains it — re-queuing each resume ≤
    ``GRAPH_PROCESSING_MAX_AGE_DAYS`` (default 365) days old and aging only truly ancient
    / undateable mail out to **Failed**. Each re-queued mail keeps its Processing message
    id, so phase 2 moves it to Processed (success) or Failed (error).

    Fallback: when auto-promotion is OFF (``GRAPH_AUTO_PROMOTE=0``) nothing feeds the
    Processing folder, so we also drain the Inbox here (gate → stage → Inbox→Processing),
    preserving the old single-trigger behavior.
    """
    from app.services import graph_client, graph_poller

    if not graph_client.is_configured():
        raise RuntimeError(
            "Microsoft Graph is not configured — set GRAPH_TENANT_ID, "
            "GRAPH_CLIENT_ID, GRAPH_CLIENT_SECRET, GRAPH_MAILBOX."
        )

    # Primary: drain the Processing queue (what the poller fed into it).
    drained = drain_processing_queue(settings)
    staged: list[dict[str, Any]] = list(drained["requeued"])
    expired = drained["expired"]
    rejected = 0

    # Fallback: if the poller isn't promoting Inbox → Processing, drain the Inbox here
    # so mail is never stranded. (When auto-promote is on, the Inbox has already been
    # emptied into Processing and this loop is a no-op.)
    if not graph_poller.auto_promote_enabled():
        filter_on = os.environ.get("MAIL_RESUME_FILTER", "1") != "0"
        for msg in graph_client.fetch_inbox(top=top):
            try:
                item = _stage_one_graph_message(settings, msg, filter_on=filter_on)
            except Exception as exc:  # noqa: BLE001 — one bad mail must never abort staging
                log.warning("graph intake: skipping message %s — %s", msg.get("id"), exc)
                continue
            if item is not None:
                staged.append(item)
            else:
                rejected += 1

    return {
        "staged_count": len(staged),
        "rejected_count": rejected,
        "recovered_count": len(drained["requeued"]),
        "expired_count": expired,
        "items": staged,
    }


# --------------------------------------------------------------------------- #
# Pending (derived from staged manifests + email_master, no table)
# --------------------------------------------------------------------------- #

def list_staged(settings: Settings) -> list[dict[str, Any]]:
    """Every staged item in the MinIO queue (raw/temp/{E_id}/{E_id}.json)."""
    out: list[dict[str, Any]] = []
    for e_id in storage.list_staged_eids():
        raw = storage.get_staging_manifest(e_id)
        if not raw:
            continue
        out.append({
            "e_id": str(raw.get("e_id") or e_id),
            "source": raw.get("source", "unknown"),
            # Recruiter-typed intake source tag (e.g. "LinkedIn", "Naukri") — distinct
            # from `source` above, which is just the pipeline origin ("upload"/"graph").
            "candidate_source": raw.get("candidate_source"),
            "subject": raw.get("subject", "unknown"),
            "received_date": raw.get("received_date"),
            "attachments": [Path(a).name for a in (raw.get("attachments") or [])],
        })
    return out


def list_pending(settings: Settings) -> list[dict[str, Any]]:
    """Staged items not yet Passed in email_master.

    Pending = no email_master row yet, OR row exists with process_status=Failed
    (so failed emails are retried on the next /run-pipeline).
    """
    statuses = db.status_by_eid()  # {} when DB-less
    pending: list[dict[str, Any]] = []
    for item in list_staged(settings):
        status = statuses.get(item["e_id"])
        if status != "Passed":
            item["last_status"] = status or "unprocessed"
            pending.append(item)
    return pending


def discard_pending(settings: Settings, e_id: str) -> dict[str, Any]:
    """Remove a staged item from the queue before it's processed.

    Purges every staged object under temp/{e_id}/ (the manifest + attachments) so it
    won't be picked up by the next pipeline run. Best-effort: returns how many objects
    were removed. Idempotent — discarding an already-gone item is a no-op (removed=0).
    """
    removed = storage.purge_temp(e_id)
    log.info("intake discarded staged %s (%d object(s) removed)", e_id, removed)
    return {"e_id": e_id, "removed": removed}
