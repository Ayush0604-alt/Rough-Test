"""Legacy feature flags — Settings → "Legacy Features" (Admin only).

TEMP SECTION: this whole module exists to let an Admin flip individual legacy
UI affordances on/off during the transition to their replacements, without a
code deploy. Once a legacy feature's replacement is fully trusted and the old
one is deleted from the codebase, its flag should be removed from here too —
this file is not meant to accumulate permanently.

Current flags:
  * "interview_round_button" — the manual "Interview Round" button (Candidate
    page + Screening table) that navigates to the standalone /rounds/{id} page
    for hand-managing a candidate's rounds. It's being superseded by the
    interviewer-timeslot-pool + candidate-self-serve-booking + interviewer-
    verdict flow (app.services.interview_pools / candidate_slot /
    app.api.interviewer), so it defaults OFF.
  * "external_slot_link_button" — the "Get slot link" button on an email
    draft that calls the EXTERNAL scheduling API (Settings → Interview Slot
    Picker). Superseded by the native pool slot-picker link on the same
    draft, so it defaults OFF.

Persisted as JSON in secrets/ (default secrets/legacy_features.json, override
via LEGACY_FEATURES_CONFIG_FILE) — same runtime-file philosophy as
candidate_sections_config/chatbot_widget_config.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict

from app.logging_config import get_logger

log = get_logger(__name__)

# (key, default enabled). Keys MUST match the frontend's gating.
_DEFAULTS: Dict[str, bool] = {
    "interview_round_button": False,
    "external_slot_link_button": False,
    # AI "Enrich" on a Question Bank (backfill hints/rubric/explanation). Off by
    # default — newly generated banks already carry a rubric; this is only for
    # older banks, so it's an opt-in legacy/maintenance control.
    "qb_enrich_button": False,
    # "Duplicate" on a Question Bank (copy as the next version). Off by default —
    # superseded by Customize (which loads the bank verbatim and saves as new).
    "qb_duplicate_button": False,
    # ATS / NLRS score columns on the dashboard candidate tables. Off by default —
    # the ranking is driven by NLRS regardless (candidates always sort highest-
    # NLRS-first), so the raw score columns are an opt-in detail view.
    "ats_column": False,
    "nlrs_column": False,
    # The "Predicted: … / Applied: … / Overridden: …" status line under the Report
    # button on the dashboard candidate tables. Off by default — the prediction is
    # already actionable from the Report popover and the row's own Undecided
    # button, so the extra line per row is opt-in detail rather than triage signal.
    "predicted_nba_status": False,
}


def _path() -> Path:
    return Path(os.environ.get("LEGACY_FEATURES_CONFIG_FILE", "secrets/legacy_features.json"))


def get() -> Dict[str, Any]:
    try:
        raw = json.loads(_path().read_text(encoding="utf-8"))
        if isinstance(raw, dict):
            return {**_DEFAULTS, **{k: bool(raw[k]) for k in _DEFAULTS if k in raw}}
    except (OSError, ValueError):
        pass
    return dict(_DEFAULTS)


def save(data: Dict[str, Any]) -> Dict[str, Any]:
    """Persist the toggles. Writing never raises — a disk hiccup just keeps the
    old values in effect rather than breaking the save request."""
    merged = {**_DEFAULTS, **{k: bool(data[k]) for k in _DEFAULTS if k in data}}
    path = _path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(merged, indent=2), encoding="utf-8")
    except OSError as exc:  # noqa: BLE001
        log.warning("legacy_features_config: could not write %s: %s", path, exc)
    return get()
