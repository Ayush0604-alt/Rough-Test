"""Microsoft Graph mail client (live, app-only / client-credentials flow).

Reads messages (queued by date received, not read-status) + their file attachments
from a configured mailbox's **Landing** folder so the intake layer can stage them for
the pipeline, and moves each processed mail Landing → Processing → Processed/Failed,
where Processing/Processed/Failed/Non-Resume are SUBFOLDERS of Landing. Uses the OAuth2
client-credentials grant (no signed-in user), the right flow for a daily service job.

Folder layout (the mailbox the recruiter set up):
    Landing                      ← intake source (new mail lands here)
      ├─ Processing              ← in-flight on a run
      ├─ Processed               ← done
      ├─ Non-Resume              ← gate-rejected
      └─ Failed                  ← failed downstream
Landing is the ONLY intake source — there is no Inbox fallback.

Required app registration permissions (Application, admin-consented):
    Mail.ReadWrite   (read messages + attachments, mark read, and MOVE messages between
                      Landing → Processing → Processed/Failed folders). Drop to Mail.Read
                      only if both GRAPH_MARK_READ=0 and GRAPH_MOVE_MAIL=0.

Config (see .env.example):
    GRAPH_TENANT_ID, GRAPH_CLIENT_ID, GRAPH_CLIENT_SECRET, GRAPH_MAILBOX
    GRAPH_MOVE_MAIL=1            move processed mail into folders (default on)
    GRAPH_FOLDER_LANDING        intake folder display name (default "Landing")
    GRAPH_FOLDER_PROCESSING/PROCESSED/FAILED/NON_RESUME   subfolder names (defaults below)

If credentials are absent, :func:`is_configured` returns False and the intake
endpoint reports a clear error instead of attempting a call.
"""

from __future__ import annotations

import html
import os
import re
import threading
from typing import Any, Optional

import requests

from app.logging_config import get_logger

log = get_logger(__name__)

_GRAPH = "https://graph.microsoft.com/v1.0"
_AUTHORITY = "https://login.microsoftonline.com"
_SCOPE = ["https://graph.microsoft.com/.default"]


def is_configured() -> bool:
    # Graph app credentials (tenant/client/secret) may come from Settings →
    # Graph API (DB) or env; the mailbox from Settings → Mailbox Account (DB)
    # or env. Configured when both halves resolve.
    try:
        from app.services import graph_config

        creds_ok = graph_config.is_configured()
    except Exception:  # noqa: BLE001
        creds_ok = all(
            os.environ.get(k) for k in ("GRAPH_TENANT_ID", "GRAPH_CLIENT_ID", "GRAPH_CLIENT_SECRET")
        )
    mailbox_ok = False
    try:
        from app.services import mailbox_account

        mailbox_ok = bool(mailbox_account.configured_mailbox() or os.environ.get("GRAPH_MAILBOX"))
    except Exception:  # noqa: BLE001
        mailbox_ok = bool(os.environ.get("GRAPH_MAILBOX"))
    return bool(creds_ok and mailbox_ok)


def _mailbox() -> str:
    # DB-configured mailbox (Settings → Mailbox Account) wins; env is the
    # fallback so a fresh deployment works before anything is configured.
    try:
        from app.services import mailbox_account

        configured = mailbox_account.configured_mailbox()
        if configured:
            return configured
    except Exception:  # noqa: BLE001 — config-layer hiccups must not block mail flow
        pass
    return os.environ["GRAPH_MAILBOX"]


# Reuse ONE MSAL app (it owns the in-memory token cache) + an explicit token cache, so
# we don't do a fresh Azure AD round-trip on every Graph call. Building a new
# ConfidentialClientApplication per call (as before) discarded MSAL's cache and made
# every list/move/count pay a full OAuth handshake — stacking up into "(pending)" calls.
_msal_app: Any = None
_msal_lock = threading.Lock()
_token_value: Optional[str] = None
_token_expiry: float = 0.0  # epoch seconds


def _msal_application() -> Any:
    global _msal_app
    if _msal_app is None:
        import msal

        # Settings → Graph API (DB) wins over env; env is the fallback so a
        # fresh deployment works before anything is configured.
        try:
            from app.services import graph_config

            creds = graph_config.resolve()
        except Exception:  # noqa: BLE001
            creds = {}
        client_id = creds.get("client_id") or os.environ["GRAPH_CLIENT_ID"]
        client_secret = creds.get("client_secret") or os.environ["GRAPH_CLIENT_SECRET"]
        tenant_id = creds.get("tenant_id") or os.environ["GRAPH_TENANT_ID"]
        _msal_app = msal.ConfidentialClientApplication(
            client_id=client_id,
            client_credential=client_secret,
            authority=f"{_AUTHORITY}/{tenant_id}",
        )
    return _msal_app


def reset_auth_cache() -> None:
    """Drop the cached MSAL app + token so the next Graph call rebuilds with
    freshly-resolved credentials — called after Settings → Graph API saves."""
    global _msal_app, _token_value, _token_expiry
    with _msal_lock:
        _msal_app = None
        _token_value = None
        _token_expiry = 0.0


def _token() -> str:
    """Acquire an app-only access token (client credentials), cached until ~60s before
    it expires. Concurrent calls share one cached token."""
    import time

    global _token_value, _token_expiry
    with _msal_lock:
        now = time.time()
        if _token_value and now < _token_expiry:
            return _token_value
        result = _msal_application().acquire_token_for_client(scopes=_SCOPE)
        if "access_token" not in result:
            raise RuntimeError(
                f"Graph auth failed: {result.get('error')}: {result.get('error_description')}"
            )
        _token_value = result["access_token"]
        # Refresh a minute early; default to 50 min if expires_in is absent.
        _token_expiry = now + max(60, int(result.get("expires_in", 3000))) - 60
        return _token_value


def _headers() -> dict[str, str]:
    return {"Authorization": f"Bearer {_token()}"}


def _business_tz():
    """The timezone that defines 'today' for the intake window (default IST).

    Uses GRAPH_TZ if set, else SCHEDULE_TZ (the pipeline cron's tz), else the
    system default Asia/Kolkata — shared with the rest of the batch/pipeline.
    """
    from app.services.clock import business_tz

    return business_tz()


def _window_start_iso() -> str:
    """Start of the fetch window as UTC ISO (Graph stores receivedDateTime in UTC).

    Default (``GRAPH_TODAY_ONLY=1``): **midnight today** in the business timezone, so
    only mail received on the current calendar date is queued. Set
    ``GRAPH_TODAY_ONLY=0`` to use a rolling ``GRAPH_LOOKBACK_HOURS`` window instead.
    """
    from datetime import datetime, timedelta, timezone

    if os.environ.get("GRAPH_TODAY_ONLY", "1") != "0":
        now_local = datetime.now(_business_tz())
        start_local = now_local.replace(hour=0, minute=0, second=0, microsecond=0)
        return start_local.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    try:
        hours = int(os.environ.get("GRAPH_LOOKBACK_HOURS", "24"))
    except ValueError:
        hours = 24
    since = datetime.now(timezone.utc) - timedelta(hours=max(1, hours))
    return since.strftime("%Y-%m-%dT%H:%M:%SZ")


def fetch_inbox(top: int | None = None) -> list[dict[str, Any]]:
    """Return EVERY message currently in the Landing folder (oldest first).

    Landing is a dedicated intake folder that is drained by moves: once a message is
    handled it's moved out into a subfolder (Processing/Processed/Non-Resume/Failed), so
    anything still sitting in Landing is genuinely waiting — regardless of how old it is
    or whether a human has read it. Hence there is NO date window and NO read-status
    filter here (both were holdovers from the old "Inbox is the whole mailbox" model and
    would hide previous-day or already-opened resumes). ``GRAPH_TODAY_ONLY`` /
    ``GRAPH_LOOKBACK_HOURS`` no longer apply to intake.

    ``top=None`` (the default) pages through and returns **every** message in Landing.
    Pass a positive ``top`` to cap how many are pulled.
    """
    page = 100 if (top is None or top <= 0) else min(top, 100)
    # Landing is the only source — no Inbox fallback, no date filter (drained by moves).
    src = landing_folder_id()
    if not src:
        log.warning("graph: no Landing folder for %s — nothing to intake", _mailbox())
        return []
    url = (
        f"{_GRAPH}/users/{_mailbox()}/mailFolders/{src}/messages"
        f"?$top={page}"
        # Full ``body`` (HTML) is selected too: resume share links (SharePoint/OneDrive)
        # live as hyperlinks in the HTML body, not in the truncated bodyPreview.
        f"&$select=id,subject,from,receivedDateTime,bodyPreview,body,hasAttachments,isRead"
        f"&$orderby=receivedDateTime asc"
    )
    headers = _headers()
    messages: list[dict[str, Any]] = []
    while url:
        resp = requests.get(url, headers=headers, timeout=60)
        resp.raise_for_status()
        data = resp.json()
        messages.extend(data.get("value", []))
        # Stop early only when an explicit cap was requested.
        if top and top > 0 and len(messages) >= top:
            messages = messages[:top]
            break
        url = data.get("@odata.nextLink")
    log.info("graph: %d intake message(s) in window for %s", len(messages), _mailbox())
    return messages


def fetch_folder(folder_key: str, top: int | None = None) -> list[dict[str, Any]]:
    """Return every message in a logical folder (``processing`` | ``processed`` |
    ``failed``), oldest first. Used to recover mail orphaned in **Processing** by an
    interrupted run. No date filter — the caller inspects ``receivedDateTime`` to
    decide each message's fate. Empty list when the folder can't be resolved.
    """
    folder_id = ensure_folders().get(folder_key)
    if not folder_id:
        # ensure_folders only populates when move is enabled; resolve directly otherwise.
        try:
            folder_id = _find_folder_id(_folder_name(folder_key))
        except requests.RequestException as exc:  # noqa: BLE001
            log.warning("graph fetch_folder(%s): resolve failed: %s", folder_key, exc)
            folder_id = None
    if not folder_id:
        return []

    page = 100 if (top is None or top <= 0) else min(top, 100)
    url = (
        f"{_GRAPH}/users/{_mailbox()}/mailFolders/{folder_id}/messages"
        f"?$top={page}"
        f"&$select=id,subject,from,receivedDateTime,bodyPreview,body,hasAttachments"
        f"&$orderby=receivedDateTime asc"
    )
    headers = _headers()
    messages: list[dict[str, Any]] = []
    while url:
        resp = requests.get(url, headers=headers, timeout=60)
        resp.raise_for_status()
        data = resp.json()
        messages.extend(data.get("value", []))
        if top and top > 0 and len(messages) >= top:
            messages = messages[:top]
            break
        url = data.get("@odata.nextLink")
    log.info("graph: %d message(s) in %s folder for %s", len(messages), folder_key, _mailbox())
    return messages


def fetch_attachments(message_id: str) -> list[dict[str, Any]]:
    """Return file attachments for a message: [{name, contentBytes(base64), contentType}].

    No ``$select`` — Graph rejects ``@odata.type`` in a select (400), and we need the
    full objects anyway (``@odata.type`` to spot fileAttachments + ``contentBytes``).
    """
    url = f"{_GRAPH}/users/{_mailbox()}/messages/{message_id}/attachments"
    resp = requests.get(url, headers=_headers(), timeout=60)
    resp.raise_for_status()
    out: list[dict[str, Any]] = []
    for att in resp.json().get("value", []):
        if att.get("@odata.type") != "#microsoft.graph.fileAttachment":
            continue  # skip itemAttachment / reference attachments
        # Skip inline images (signature logos, the doc-link icon Outlook embeds, etc.) —
        # they are body decoration, never the candidate's resume. A real resume arrives
        # as a normal (non-inline) attachment OR as a share link in the body.
        if att.get("isInline"):
            continue
        out.append({
            "name": att.get("name"),
            "contentType": att.get("contentType"),
            "contentBytes": att.get("contentBytes"),  # base64
        })
    return out


def fetch_attachment_names(message_id: str) -> list[str]:
    """Return non-inline file-attachment names for a message — **no content download**.

    Cheap companion to :func:`fetch_attachments` for the resume gate, which only needs
    file names (not bytes) to decide acceptance. Selects ``name/contentType/isInline``
    only (Graph rejects ``@odata.type`` in a ``$select``), so inline images (signature
    logos, embedded doc-link icons) are filtered client-side. Best-effort: returns
    ``[]`` on any error so a poll tick never crashes.
    """
    url = (
        f"{_GRAPH}/users/{_mailbox()}/messages/{message_id}/attachments"
        f"?$select=name,contentType,isInline&$top=50"
    )
    try:
        resp = requests.get(url, headers=_headers(), timeout=30)
        resp.raise_for_status()
    except requests.RequestException as exc:  # noqa: BLE001 — gate must degrade, not crash
        log.warning("graph fetch_attachment_names(%s) failed: %s", message_id, exc)
        return []
    return [
        att["name"]
        for att in resp.json().get("value", [])
        if att.get("name") and not att.get("isInline")
    ]


_URL_RE = re.compile(r"https?://[^\s<]+")
_URL_TRAILING_PUNCT = ".,;:!?)]}'\""


def _linkify(escaped_text: str) -> str:
    """Wraps bare http(s) URLs in a visible, clickable <a> tag. Called on
    already-HTML-escaped text, so URLs (which don't contain &/</>/") are
    matched as-is. Trailing punctuation right after a URL (a period ending
    the sentence, a closing paren, ...) is kept outside the link."""
    def repl(m: re.Match[str]) -> str:
        url = m.group(0)
        trail = ""
        while url and url[-1] in _URL_TRAILING_PUNCT:
            trail = url[-1] + trail
            url = url[:-1]
        return f'<a href="{url}" style="color:#2563eb; text-decoration:underline;">{url}</a>{trail}'

    return _URL_RE.sub(repl, escaped_text)


def plain_text_to_html(body: str) -> str:
    """Turns a plain-text draft/notification body into a minimal HTML email:
    escapes it (so a candidate's name with a stray `&`/`<` can't break the
    markup), auto-links any bare URL (e.g. an interview-slot-picker link) so
    it renders as clickable instead of inert text, then converts newlines to
    <br> and wraps in a <p>."""
    return f"<p>{_linkify(html.escape(body))}</p>".replace("\n", "<br>")


def send_mail(to: str, subject: str, html_body: str) -> dict[str, Any]:
    """Send a notification email from the configured mailbox via Graph ``sendMail``.

    Requires the app registration to hold the **Mail.Send** Application permission
    (admin-consented). Returns ``{"sent": bool, "error": str|None}`` — never raises, so
    a notification failure can't break a pipeline run.
    """
    if not is_configured():
        return {"sent": False, "error": "graph_not_configured"}
    if not to:
        return {"sent": False, "error": "no_recipient"}
    url = f"{_GRAPH}/users/{_mailbox()}/sendMail"
    payload = {
        "message": {
            "subject": subject,
            "body": {"contentType": "HTML", "content": html_body},
            "toRecipients": [{"emailAddress": {"address": addr.strip()}}
                             for addr in to.split(",") if addr.strip()],
        },
        "saveToSentItems": True,
    }
    try:
        resp = requests.post(
            url, headers={**_headers(), "Content-Type": "application/json"},
            json=payload, timeout=30,
        )
        if resp.status_code in (200, 202):
            log.info("graph: notification sent to %s", to)
            return {"sent": True, "error": None}
        err = f"{resp.status_code}: {resp.text[:200]}"
        log.warning("graph send_mail failed: %s", err)
        return {"sent": False, "error": err}
    except requests.RequestException as exc:  # noqa: BLE001
        log.warning("graph send_mail error: %s", exc)
        return {"sent": False, "error": str(exc)[:200]}


def mark_read(message_id: str) -> None:
    """Mark a message as read (best-effort; requires Mail.ReadWrite)."""
    if os.environ.get("GRAPH_MARK_READ", "1") != "1":
        return
    url = f"{_GRAPH}/users/{_mailbox()}/messages/{message_id}"
    try:
        requests.patch(url, headers=_headers(), json={"isRead": True}, timeout=30)
    except requests.RequestException as exc:  # noqa: BLE001
        log.warning("graph mark_read failed for %s: %s", message_id, exc)


# --------------------------------------------------------------------------- #
# Folder routing — move mail Inbox → Processing → Processed | Failed
# --------------------------------------------------------------------------- #

# Logical folder key -> default display name (each overridable via env, e.g.
# GRAPH_FOLDER_NON_RESUME). "non_resume" holds gate-rejected mail (blocklisted senders /
# no resume payload) so it leaves the queue without polluting Failed.
_FOLDER_DEFAULTS = {
    "processing": "Processing",
    "processed": "Processed",
    "failed": "Failed",
    "non_resume": "Non-Resume",
    # Destination for mail an Admin/System Admin manually discarded from the
    # Incoming Email Queue before it was ever staged into email_master.
    "discarded": "Discarded",
}
# The mailbox now routes intake through a top-level "Landing" folder that holds the
# Processing/Processed/Failed/Non-Resume folders as SUBFOLDERS (it replaced the old
# flat Inbox + root-level folders). We resolve Landing first, then look the routing
# folders up as its children. If a mailbox has no Landing folder, everything falls
# back to the classic layout: read from Inbox, resolve folders at the mailbox root.
_FOLDER_LANDING_DEFAULT = "Landing"
# Cached display-name -> folder-id (per process, mailbox-scoped). ensure_folders
# fills it once; cheap to keep since the mailbox is fixed for a deployment.
_folder_cache: dict[str, str] = {}
# REENTRANT: ensure_folders() holds this and then calls landing_folder_id(), which
# re-acquires it on the SAME thread. A plain Lock would self-deadlock there (it did —
# that was the hung /graph/queue). RLock allows the same thread to re-enter.
_folder_lock = threading.RLock()
# Landing folder id — cached only once successfully resolved (None until then).
_landing_id: Optional[str] = None


def move_enabled() -> bool:
    """True when processed mail should be moved into folders (default on)."""
    return os.environ.get("GRAPH_MOVE_MAIL", "1") == "1"


def _db_folder(key: str) -> Optional[str]:
    """DB-configured folder name (Settings → Mailbox Account) — takes
    precedence over env vars/defaults. Best-effort: any config-layer hiccup
    falls back to the env/default names rather than blocking mail flow."""
    try:
        from app.services import mailbox_account

        return mailbox_account.configured_folder(key)
    except Exception:  # noqa: BLE001
        return None


def _folder_name(key: str) -> str:
    return _db_folder(key) or os.environ.get(f"GRAPH_FOLDER_{key.upper()}", _FOLDER_DEFAULTS[key])


def _landing_name() -> str:
    return _db_folder("landing") or os.environ.get("GRAPH_FOLDER_LANDING", _FOLDER_LANDING_DEFAULT)


def reset_folder_cache() -> None:
    """Drop the cached folder-name → id resolutions — called after the
    Mailbox Account settings change folder names/mailbox."""
    global _landing_id
    with _folder_lock:
        _folder_cache.clear()
        _landing_id = None


def _list_folders(parent_id: Optional[str] = None) -> list[dict[str, Any]]:
    """All folders directly under ``parent_id`` (or the mailbox ROOT when None).

    Paged ($top=100 + @odata.nextLink), so it returns EVERY folder, not just the first
    page. We list-and-match in Python instead of using ``$filter=displayName eq '…'``
    (which is brittle across Graph: paging, escaping, and case all bite). Returns a list
    of ``{id, displayName, totalItemCount, unreadItemCount}``.
    """
    if parent_id:
        base = f"{_GRAPH}/users/{_mailbox()}/mailFolders/{parent_id}/childFolders"
    else:
        base = f"{_GRAPH}/users/{_mailbox()}/mailFolders"
    url = f"{base}?$select=id,displayName,totalItemCount,unreadItemCount&$top=100"
    out: list[dict[str, Any]] = []
    headers = _headers()
    while url:
        resp = requests.get(url, headers=headers, timeout=30)
        resp.raise_for_status()
        data = resp.json()
        out.extend(data.get("value", []))
        url = data.get("@odata.nextLink")
    return out


def _match_folder(folders: list[dict[str, Any]], name: str) -> Optional[str]:
    """Folder id whose display name equals ``name`` (case-insensitive, trimmed)."""
    target = (name or "").strip().lower()
    for f in folders:
        if (f.get("displayName") or "").strip().lower() == target:
            return f.get("id")
    return None


def _find_root_folder_id(name: str) -> Optional[str]:
    """Resolve a folder by display name at the mailbox ROOT (top-level mailFolders)."""
    return _match_folder(_list_folders(None), name)


def _find_child_folder_id(parent_id: str, name: str) -> Optional[str]:
    """Resolve a folder by display name among a parent folder's CHILD folders."""
    return _match_folder(_list_folders(parent_id), name)


def _find_descendant_folder_id(parent_id: str, name: str, max_depth: int = 3) -> Optional[str]:
    """Find a folder by display name anywhere under ``parent_id`` (BFS, bounded depth).

    Direct children are checked first (the normal case: Processing is a child of
    Landing). If not found there, it descends a couple more levels — so an unexpectedly
    nested layout (Landing → X → Processing) still resolves instead of silently failing.
    """
    frontier: list[tuple[str, int]] = [(parent_id, 0)]
    while frontier:
        pid, depth = frontier.pop(0)
        children = _list_folders(pid)
        match = _match_folder(children, name)
        if match:
            return match
        if depth + 1 < max_depth:
            frontier.extend((f["id"], depth + 1) for f in children if f.get("id"))
    return None


def landing_folder_id() -> Optional[str]:
    """The 'Landing' folder id — the intake source and the parent of the routing
    subfolders (Processing/Processed/Failed/Non-Resume).

    Landing is the ONLY intake source: there is no Inbox fallback. Returns None when the
    mailbox has no Landing folder (intake/routing then become logged no-ops).

    Caches ONLY a successful (non-None) resolution. A miss or a transient Graph error is
    NOT cached, so the very next call retries — otherwise a single startup hiccup would
    strand the whole process with "no Landing folder" until a restart.
    """
    global _landing_id
    with _folder_lock:
        if _landing_id:
            return _landing_id
        try:
            resolved = _find_root_folder_id(_landing_name())
        except requests.RequestException as exc:  # noqa: BLE001 — retry next call
            log.warning("graph: resolving Landing folder failed (will retry): %s", exc)
            return None
        if resolved:
            _landing_id = resolved
            log.info("graph: using Landing folder '%s' as intake source", _landing_name())
        else:
            log.warning("graph: Landing folder '%s' not found in %s (will retry)",
                        _landing_name(), _mailbox())
        return resolved


def _find_folder_id(name: str) -> Optional[str]:
    """Resolve a routing folder by name anywhere under Landing (None if no Landing
    folder exists — no root-level fallback)."""
    landing = landing_folder_id()
    if not landing:
        return None
    return _find_descendant_folder_id(landing, name)


def _create_folder(name: str) -> str:
    """Create a routing folder as a CHILD of Landing. Raises when there's no Landing
    folder to nest it under (we never create routing folders at the mailbox root)."""
    landing = landing_folder_id()
    if not landing:
        raise RuntimeError(
            f"graph: cannot create folder {name!r} — Landing folder {_landing_name()!r} not found"
        )
    url = f"{_GRAPH}/users/{_mailbox()}/mailFolders/{landing}/childFolders"
    resp = requests.post(
        url, headers={**_headers(), "Content-Type": "application/json"},
        json={"displayName": name}, timeout=30,
    )
    resp.raise_for_status()
    return resp.json()["id"]


def ensure_folders() -> dict[str, str]:
    """Find-or-create the Processing/Processed/Failed folders; return key -> id.

    Cached after the first successful resolution. Best-effort: a folder that can't
    be resolved is simply omitted (its moves become no-ops with a warning).
    """
    if not move_enabled():
        return {}
    with _folder_lock:
        if len(_folder_cache) == len(_FOLDER_DEFAULTS):
            return dict(_folder_cache)
        for key in _FOLDER_DEFAULTS:
            if key in _folder_cache:
                continue
            name = _folder_name(key)
            try:
                _folder_cache[key] = _find_folder_id(name) or _create_folder(name)
            except requests.RequestException as exc:  # noqa: BLE001
                log.warning("graph ensure_folders(%s) failed: %s", name, exc)
        return dict(_folder_cache)


def resolve_debug() -> dict[str, Any]:
    """Diagnostic snapshot of folder resolution — what the backend actually sees.

    Returns the mailbox, the configured Landing name, the list of ROOT folders, the
    resolved Landing id, Landing's child folders (name/id/counts), and the logical
    key → resolved id map. Surfaced at GET /graph/folders so a mismatch (wrong mailbox,
    a stray root-level Processing, a name typo) is visible at a glance. Never raises.
    """
    if not is_configured():
        return {"configured": False}
    out: dict[str, Any] = {
        "configured": True,
        "mailbox": _mailbox(),
        "landing_name": _landing_name(),
        "move_enabled": move_enabled(),
    }
    try:
        roots = _list_folders(None)
        out["root_folders"] = [
            {"name": f.get("displayName"), "total": f.get("totalItemCount")} for f in roots
        ]
        landing = _match_folder(roots, _landing_name())
        out["landing_id"] = landing
        if landing:
            children = _list_folders(landing)
            out["landing_children"] = [
                {
                    "name": f.get("displayName"),
                    "id": f.get("id"),
                    "total": f.get("totalItemCount"),
                    "unread": f.get("unreadItemCount"),
                }
                for f in children
            ]
            out["resolved_routing"] = {
                key: _find_descendant_folder_id(landing, _folder_name(key))
                for key in _FOLDER_DEFAULTS
            }
    except Exception as exc:  # noqa: BLE001 — diagnostics must never raise
        out["error"] = str(exc)[:300]
    return out


def folder_counts() -> dict[str, Any]:
    """Live item counts per mail folder, straight from Graph.

    Returns ``{configured, counts, totals, error}`` where ``counts`` is the folder's
    **unread** item count — the bold badge Outlook shows next to each folder in the
    mail client (what a recruiter reads off the sidebar) — and ``totals`` is the full
    ``totalItemCount`` for reference. Each value is ``None`` when that folder can't be
    resolved. Best-effort: never raises — a transient Graph error yields ``error`` set
    and whatever counts were gathered.
    """
    if not is_configured():
        return {"configured": False, "counts": {}, "totals": {}, "error": "graph_not_configured"}

    headers = _headers()
    error: Optional[str] = None

    def _count(folder_ref: str) -> tuple[Optional[int], Optional[int]]:
        """(unreadItemCount, totalItemCount) for a folder ref (well-known name or id)."""
        nonlocal error
        url = (
            f"{_GRAPH}/users/{_mailbox()}/mailFolders/{folder_ref}"
            f"?$select=unreadItemCount,totalItemCount"
        )
        try:
            resp = requests.get(url, headers=headers, timeout=30)
            resp.raise_for_status()
            data = resp.json()
            return data.get("unreadItemCount"), data.get("totalItemCount")
        except requests.RequestException as exc:  # noqa: BLE001 — degrade, don't crash
            log.warning("graph folder_counts(%s) failed: %s", folder_ref, exc)
            error = str(exc)[:200]
            return None, None

    counts: dict[str, Optional[int]] = {}
    totals: dict[str, Optional[int]] = {}

    # The intake folder is Landing — counted under the "inbox" key for the UI. No Inbox
    # fallback: when there's no Landing folder its counts are None and an error is noted.
    landing = landing_folder_id()
    if landing:
        inbox_unread, inbox_total = _count(landing)
    else:
        inbox_unread, inbox_total = None, None
        error = error or "landing_folder_not_found"
    counts["inbox"], totals["inbox"] = inbox_unread, inbox_total

    for key in ("processing", "processed", "failed", "non_resume"):
        try:
            fid = ensure_folders().get(key) or _find_folder_id(_folder_name(key))
        except requests.RequestException as exc:  # noqa: BLE001
            log.warning("graph folder_counts resolve(%s) failed: %s", key, exc)
            error = str(exc)[:200]
            fid = None
        unread, total = _count(fid) if fid else (None, None)
        counts[key], totals[key] = unread, total

    return {"configured": True, "counts": counts, "totals": totals, "error": error}


def move_message(message_id: str, folder_key: str) -> Optional[str]:
    """Move a message to the Processing/Processed/Failed folder (best-effort).

    Returns the message's **new id** in the destination folder (Graph reassigns the
    id on move), or None on failure / when moving is disabled. Callers should keep
    the returned id to address the message in a later move.
    """
    if not move_enabled() or not message_id:
        return None
    dest = ensure_folders().get(folder_key)
    if not dest:
        log.warning("graph move_message: no folder for %r (move skipped)", folder_key)
        return None
    url = f"{_GRAPH}/users/{_mailbox()}/messages/{message_id}/move"
    try:
        resp = requests.post(
            url, headers={**_headers(), "Content-Type": "application/json"},
            json={"destinationId": dest}, timeout=30,
        )
        resp.raise_for_status()
        new_id = resp.json().get("id")
        log.info("graph: moved message -> %s folder", folder_key)
        return new_id or message_id
    except requests.RequestException as exc:  # noqa: BLE001
        log.warning("graph move_message(%s -> %s) failed: %s", message_id, folder_key, exc)
        return None
