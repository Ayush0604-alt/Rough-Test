"""LLM token-usage ledger — powers the Admin "Token Usage" page.

Every LLM call in the app (extraction, analysis report, timeline, interview
questions, JD match, chatbot) records one row here via :func:`record`, which is
strictly best-effort: telemetry must NEVER break the pipeline, so any failure
is swallowed and logged. Source-tag attribution happens at QUERY time by
joining candidate_id → candidate_master.source (not stamped at write time), so
usage rows follow late re-taggings and always agree with the rest of the app.

Cost figures are ESTIMATES from a static $/1M-token price map keyed by
deployment-name prefix — good enough to compare modules/campaigns, not a bill.
"""
from __future__ import annotations

from datetime import date, timedelta
from typing import Any, Dict, List, Optional

from app.db import get_conn
from app.logging_config import get_logger

log = get_logger(__name__)

_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS llm_token_usage (
    id BIGSERIAL PRIMARY KEY,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    module TEXT NOT NULL,
    model TEXT,
    candidate_id TEXT,
    prompt_tokens INTEGER NOT NULL DEFAULT 0,
    completion_tokens INTEGER NOT NULL DEFAULT 0,
    total_tokens INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_llm_token_usage_created ON llm_token_usage (created_at);
CREATE INDEX IF NOT EXISTS idx_llm_token_usage_module ON llm_token_usage (module);
"""

_table_ready = False


def _ensure_table() -> None:
    global _table_ready
    if _table_ready:
        return
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(_TABLE_SQL)
    _table_ready = True


# $ per 1M tokens (input, output) — longest-prefix match on the deployment
# name. Static estimates for comparison, deliberately conservative defaults.
_PRICE_PER_M: List[tuple[str, float, float]] = [
    ("gpt-4o-mini", 0.15, 0.60),
    ("gpt-4o", 2.50, 10.00),
    ("gpt-4.1-nano", 0.10, 0.40),
    ("gpt-4.1-mini", 0.40, 1.60),
    ("gpt-4.1", 2.00, 8.00),
    ("gpt-35-turbo", 0.50, 1.50),
    ("gpt-5-mini", 0.25, 2.00),
    ("gpt-5", 1.25, 10.00),
    ("o3-mini", 1.10, 4.40),
    ("o4-mini", 1.10, 4.40),
]
_DEFAULT_PRICE = (1.00, 4.00)


def _price_for(model: Optional[str]) -> tuple[float, float]:
    m = (model or "").strip().lower()
    best: Optional[tuple[str, float, float]] = None
    for prefix, inp, out in _PRICE_PER_M:
        if m.startswith(prefix) and (best is None or len(prefix) > len(best[0])):
            best = (prefix, inp, out)
    return (best[1], best[2]) if best else _DEFAULT_PRICE


def _cost(model: Optional[str], prompt: int, completion: int) -> float:
    inp, out = _price_for(model)
    return (prompt * inp + completion * out) / 1_000_000.0


def record(
    *,
    module: str,
    model: Optional[str],
    prompt_tokens: Optional[int],
    completion_tokens: Optional[int],
    total_tokens: Optional[int] = None,
    candidate_id: Optional[str] = None,
) -> None:
    """Best-effort append of one LLM call's usage — never raises."""
    try:
        p = int(prompt_tokens or 0)
        c = int(completion_tokens or 0)
        t = int(total_tokens or 0) or (p + c)
        _ensure_table()
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "INSERT INTO llm_token_usage "
                    "(module, model, candidate_id, prompt_tokens, completion_tokens, total_tokens) "
                    "VALUES (%s, %s, %s, %s, %s, %s)",
                    (module, model, candidate_id, p, c, t),
                )
    except Exception as exc:  # noqa: BLE001 — telemetry never blocks the pipeline
        log.debug("token_usage.record failed (module=%s): %s", module, exc)


NO_SOURCE = "No source"


def summary(
    date_from: Optional[date] = None,
    date_to: Optional[date] = None,
    source: Optional[str] = None,
) -> Dict[str, Any]:
    """Aggregates for the dashboard. ``source`` filters by the candidate's
    CURRENT source tag (query-time join); pass :data:`NO_SOURCE` for rows with
    no candidate/source attribution. Dates are inclusive calendar days."""
    _ensure_table()
    where = ["TRUE"]
    params: List[Any] = []
    if date_from:
        where.append("u.created_at >= %s")
        params.append(date_from)
    if date_to:
        where.append("u.created_at < %s")
        params.append(date_to + timedelta(days=1))
    if source == NO_SOURCE:
        where.append("cm.source IS NULL")
    elif source:
        where.append("cm.source = %s")
        params.append(source)
    where_sql = " AND ".join(where)
    base = (
        "FROM llm_token_usage u "
        "LEFT JOIN candidate_master cm ON cm.candidate_id = u.candidate_id "
        f"WHERE {where_sql}"
    )

    with get_conn() as conn:
        with conn.cursor() as cur:
            # Per module+model — the finest grain; totals/cost roll up from it.
            cur.execute(
                f"SELECT u.module, u.model, COUNT(*), COALESCE(SUM(u.prompt_tokens),0), "
                f"COALESCE(SUM(u.completion_tokens),0), COALESCE(SUM(u.total_tokens),0) "
                f"{base} GROUP BY u.module, u.model",
                params,
            )
            mm_rows = cur.fetchall()

            cur.execute(
                f"SELECT COALESCE(cm.source, %s), COUNT(*), COALESCE(SUM(u.total_tokens),0) "
                f"{base} GROUP BY COALESCE(cm.source, %s) ORDER BY 3 DESC",
                [NO_SOURCE, *params, NO_SOURCE],
            )
            source_rows = cur.fetchall()

            cur.execute(
                f"SELECT DATE(u.created_at), COALESCE(SUM(u.prompt_tokens),0), "
                f"COALESCE(SUM(u.completion_tokens),0), COALESCE(SUM(u.total_tokens),0), COUNT(*) "
                f"{base} GROUP BY DATE(u.created_at) ORDER BY 1",
                params,
            )
            day_rows = cur.fetchall()

            # Per-day PER-MODULE series — feeds the trend/forecast chart's
            # module multiselect (overall = client-side sum of the selection).
            cur.execute(
                f"SELECT DATE(u.created_at), u.module, COALESCE(SUM(u.total_tokens),0) "
                f"{base} GROUP BY DATE(u.created_at), u.module ORDER BY 1",
                params,
            )
            day_module_rows = cur.fetchall()

            # Filter options — every source tag known to the system (all of
            # candidate_master's tags, whether or not any usage is attributed
            # to them yet) plus the "No source" bucket. Listing only sources
            # WITH usage made the dropdown look broken right after shipping,
            # when the ledger was still nearly empty.
            cur.execute(
                "SELECT DISTINCT source FROM candidate_master WHERE source IS NOT NULL "
                "UNION SELECT DISTINCT cm.source FROM llm_token_usage u "
                "JOIN candidate_master cm ON cm.candidate_id = u.candidate_id "
                "WHERE cm.source IS NOT NULL"
            )
            all_sources = sorted((r[0] for r in cur.fetchall()), key=str.lower)
            all_sources.append(NO_SOURCE)

    by_module: Dict[str, Dict[str, Any]] = {}
    by_model: Dict[str, Dict[str, Any]] = {}
    totals = {"calls": 0, "prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0, "est_cost_usd": 0.0}
    for module, model, calls, p, c, t in mm_rows:
        cost = _cost(model, p, c)
        m = by_module.setdefault(
            module, {"module": module, "calls": 0, "prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0, "est_cost_usd": 0.0}
        )
        m["calls"] += calls
        m["prompt_tokens"] += p
        m["completion_tokens"] += c
        m["total_tokens"] += t
        m["est_cost_usd"] += cost
        key = model or "unknown"
        md = by_model.setdefault(key, {"model": key, "calls": 0, "total_tokens": 0, "est_cost_usd": 0.0})
        md["calls"] += calls
        md["total_tokens"] += t
        md["est_cost_usd"] += cost
        totals["calls"] += calls
        totals["prompt_tokens"] += p
        totals["completion_tokens"] += c
        totals["total_tokens"] += t
        totals["est_cost_usd"] += cost

    return {
        "totals": totals,
        "by_module": sorted(by_module.values(), key=lambda x: -x["total_tokens"]),
        "by_model": sorted(by_model.values(), key=lambda x: -x["total_tokens"]),
        "by_source": [
            {"source": s, "calls": calls, "total_tokens": t} for s, calls, t in source_rows
        ],
        "timeline": [
            {
                "day": d.isoformat(),
                "prompt_tokens": p,
                "completion_tokens": c,
                "total_tokens": t,
                "calls": calls,
            }
            for d, p, c, t, calls in day_rows
        ],
        "timeline_by_module": [
            {"day": d.isoformat(), "module": m, "total_tokens": t}
            for d, m, t in day_module_rows
        ],
        "sources": all_sources,
    }
