"""NLRS weights, NBA bands, and custom rules — Settings → Extraction & Analysis
(Admin-only). NLRS itself stays computed LIVE and is never persisted (see
app.services.nlrs) — this module only stores the WEIGHTS/THRESHOLDS/RULES
that formula reads, so a saved change applies to every candidate on their
very next page load, with no batch recompute needed. Settings' "Recalculate
across a batch" action is therefore a PREVIEW, not a write: it runs
compute_nlrs() with whatever's currently saved here against a batch of real
candidates so an Admin can sanity-check the effect before relying on it
broadly — there's nothing to separately "activate".

A custom rule nudges the final NLRS score by a flat point delta when one
numeric candidate field crosses a threshold — e.g. "total_companieswitched >=
4 -> -5". Kept deliberately simple (one field, one comparison, one flat
point adjustment) rather than an open-ended rule DSL.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from app.logging_config import get_logger

log = get_logger(__name__)

DEFAULT_WEIGHTS: dict[str, float] = {
    "analysis_report": 0.45,
    # CGPA is a strong second signal — weighted close to the Analysis Report
    # tier. When a candidate has NO CGPA on record it is EXCLUDED and the other
    # components renormalize (see nlrs.compute_nlrs), so a missing CGPA neither
    # helps nor hurts rather than scoring a punishing 0.
    "cgpa": 0.30,
    "certificates": 0.12,
    "experience": 0.08,
    "ats": 0.05,
}
DEFAULT_NBA_BANDS: dict[str, float] = {
    # Below "undecided" -> reject; below "call_now" -> undecided; below
    # "share_round1" -> call_now (Screening) — the long-standing baseline.
    # ABOVE that, three judiciously narrow, high bands fast-track a genuinely
    # exceptional candidate straight past the rounds a merely-good one would
    # still have to clear one at a time — reducing needless interview cycles
    # for the very promising minority without loosening the bar for everyone
    # else (nothing below 70 changes). Deliberately steep gaps (70 -> 78 -> 85
    # -> 92) so a candidate must be excellent across MULTIPLE weighted NLRS
    # components (not just one strong area) to earn a skip.
    "final_round": 92.0,   # exceptional across the board -> straight to Final
    "share_round2": 85.0,  # very strong -> straight to Round 2
    "share_round1": 78.0,  # strong -> straight to Round 1
    "call_now": 70.0,      # solid -> Screening (unchanged baseline)
    "undecided": 45.0,
}

# Numeric candidate_master columns safe to gate a rule on — deliberately a
# small allowlist, not "any column name", so a saved rule can never reference
# a field that doesn't exist or isn't numeric.
ALLOWED_RULE_FIELDS = (
    "yearofexp", "total_companieswitched", "cgpa", "atsscore",
    "passoutyr", "experience_months", "gap_months",
)
ALLOWED_RULE_OPS = (">", ">=", "<", "<=", "==", "!=")


def _path() -> Path:
    return Path(os.environ.get("NLRS_CONFIG_FILE", "secrets/nlrs.json"))


def _defaults() -> dict[str, Any]:
    return {"weights": dict(DEFAULT_WEIGHTS), "nba_bands": dict(DEFAULT_NBA_BANDS), "rules": []}


def _valid_rule(r: Any) -> bool:
    return (
        isinstance(r, dict)
        and isinstance(r.get("id"), str) and bool(r["id"])
        and isinstance(r.get("label"), str) and bool(r["label"])
        and r.get("field") in ALLOWED_RULE_FIELDS
        and r.get("op") in ALLOWED_RULE_OPS
        and isinstance(r.get("value"), (int, float)) and not isinstance(r.get("value"), bool)
        and isinstance(r.get("points"), (int, float)) and not isinstance(r.get("points"), bool)
    )


def get() -> dict[str, Any]:
    """Current NLRS config, merged onto the shipped defaults — never raises;
    a missing/corrupt file just reads as "no customization yet"."""
    out = _defaults()
    try:
        raw = json.loads(_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return out
    if isinstance(raw.get("weights"), dict):
        out["weights"].update({
            k: float(v) for k, v in raw["weights"].items()
            if k in DEFAULT_WEIGHTS and isinstance(v, (int, float)) and not isinstance(v, bool)
        })
    if isinstance(raw.get("nba_bands"), dict):
        out["nba_bands"].update({
            k: float(v) for k, v in raw["nba_bands"].items()
            if k in DEFAULT_NBA_BANDS and isinstance(v, (int, float)) and not isinstance(v, bool)
        })
    if isinstance(raw.get("rules"), list):
        out["rules"] = [r for r in raw["rules"] if _valid_rule(r)]
    return out


def save(payload: dict[str, Any]) -> dict[str, Any]:
    """Validates then persists. Raises ValueError on a structurally invalid
    payload — unlike the purely-cosmetic Settings sections, a bad weight/band/
    rule silently mis-ranks every candidate rather than just looking odd, so
    this is rejected outright rather than swallowed."""
    weights = payload.get("weights") or {}
    nba_bands = payload.get("nba_bands") or {}
    rules = payload.get("rules") or []

    unknown_weights = set(weights) - set(DEFAULT_WEIGHTS)
    if unknown_weights:
        raise ValueError(f"Unknown weight key(s): {', '.join(sorted(unknown_weights))}.")
    if not all(isinstance(v, (int, float)) and not isinstance(v, bool) and v >= 0 for v in weights.values()):
        raise ValueError("Weights must be non-negative numbers.")

    unknown_bands = set(nba_bands) - set(DEFAULT_NBA_BANDS)
    if unknown_bands:
        raise ValueError(f"Unknown NBA band key(s): {', '.join(sorted(unknown_bands))}.")
    if not all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in nba_bands.values()):
        raise ValueError("NBA band thresholds must be numbers.")

    for i, r in enumerate(rules):
        if not _valid_rule(r):
            raise ValueError(
                f"Rule #{i + 1} is invalid — need id/label, field in {ALLOWED_RULE_FIELDS}, "
                f"op in {ALLOWED_RULE_OPS}, and numeric value/points."
            )

    data = _defaults()
    data["weights"].update(weights)
    data["nba_bands"].update(nba_bands)
    data["rules"] = rules

    path = _path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        log.info("nlrs_config: saved %s", path)
    except OSError as exc:  # noqa: BLE001
        log.warning("nlrs_config: could not write %s: %s", path, exc)
    return get()


def revert_to_default() -> dict[str, Any]:
    path = _path()
    try:
        if path.exists():
            path.unlink()
            log.info("nlrs_config: reverted to default (%s removed)", path)
    except OSError as exc:  # noqa: BLE001
        log.warning("nlrs_config: could not remove %s: %s", path, exc)
    return get()
