"""Classic-legend codenames for saved question banks — movies & music only.

A question bank is auto-named after an iconic filmmaker or musician paired with
one of their works — e.g. ``Christopher Nolan - Inception``, ``Michael Jackson -
Dangerous``, ``Quentin Tarantino - Pulp Fiction``, ``The Beatles - Abbey Road``.

The pick is matched on the COMPLEXITY OF THE CREATIVITY: every legend carries a
tier (1 = accessible/feel-good … 3 = dense/cerebral), and the bank's difficulty
(nudged up by heavier question modes) picks the tier — so a Very-Hard, analytical
bank gravitates to a Nolan / Kubrick / Radiohead, while an Easy set leans to an
Elvis / Disney. There's enough spread within a tier that the exact name still
feels like a fresh discovery. Once every pairing is used it appends a Roman
numeral so it never runs dry.
"""
from __future__ import annotations

import random

# legend -> a few of their iconic works (films or music).
LEGENDS: dict[str, list[str]] = {
    # ── Filmmakers ──
    "Christopher Nolan": ["Inception", "Interstellar", "The Dark Knight", "Memento", "Tenet", "Oppenheimer", "Dunkirk"],
    "Quentin Tarantino": ["Pulp Fiction", "Kill Bill", "Django Unchained", "Reservoir Dogs", "Inglourious Basterds", "Jackie Brown"],
    "M. Night Shyamalan": ["The Sixth Sense", "Unbreakable", "Signs", "Split", "The Village", "Glass"],
    "Stanley Kubrick": ["2001 A Space Odyssey", "The Shining", "A Clockwork Orange", "Dr. Strangelove", "Full Metal Jacket"],
    "Alfred Hitchcock": ["Psycho", "Vertigo", "Rear Window", "The Birds", "North by Northwest"],
    "Martin Scorsese": ["Goodfellas", "Taxi Driver", "Raging Bull", "The Departed", "Casino", "The Irishman"],
    "Steven Spielberg": ["Jaws", "E.T.", "Jurassic Park", "Schindler's List", "Raiders of the Lost Ark", "Saving Private Ryan"],
    "Francis Ford Coppola": ["The Godfather", "Apocalypse Now", "The Conversation", "The Godfather Part II"],
    "Akira Kurosawa": ["Seven Samurai", "Rashomon", "Ran", "Yojimbo", "Ikiru"],
    "Ridley Scott": ["Blade Runner", "Alien", "Gladiator", "The Martian"],
    "David Fincher": ["Fight Club", "Se7en", "The Social Network", "Gone Girl", "Zodiac"],
    "Wes Anderson": ["The Grand Budapest Hotel", "Moonrise Kingdom", "The Royal Tenenbaums", "Fantastic Mr Fox"],
    "Charlie Chaplin": ["The Kid", "City Lights", "Modern Times", "The Great Dictator", "The Gold Rush"],
    "Satyajit Ray": ["Pather Panchali", "Charulata", "The Apu Trilogy", "Aparajito"],
    "Walt Disney": ["Snow White", "Fantasia", "Steamboat Willie", "Cinderella"],
    # ── Musicians & bands ──
    "Michael Jackson": ["Thriller", "Bad", "Dangerous", "Off the Wall", "Billie Jean", "Smooth Criminal"],
    "The Beatles": ["Abbey Road", "Let It Be", "Magical Mystery Tour", "Revolver", "Sgt. Pepper", "Hey Jude"],
    "Pink Floyd": ["The Dark Side of the Moon", "The Wall", "Wish You Were Here", "Comfortably Numb", "Animals"],
    "Queen": ["Bohemian Rhapsody", "A Night at the Opera", "We Will Rock You", "Somebody to Love"],
    "David Bowie": ["Ziggy Stardust", "Heroes", "Space Oddity", "Life on Mars", "Blackstar"],
    "Led Zeppelin": ["Stairway to Heaven", "Kashmir", "Whole Lotta Love", "Immigrant Song"],
    "Radiohead": ["OK Computer", "Kid A", "Paranoid Android", "In Rainbows", "Creep"],
    "Bob Dylan": ["Blowin' in the Wind", "Like a Rolling Stone", "Highway 61", "The Times They Are a-Changin'"],
    "Miles Davis": ["Kind of Blue", "Bitches Brew", "So What", "Birth of the Cool"],
    "Ludwig van Beethoven": ["Symphony No. 5", "Fur Elise", "Moonlight Sonata", "Ode to Joy"],
    "Wolfgang Mozart": ["The Magic Flute", "Requiem", "Eine kleine Nachtmusik", "Don Giovanni"],
    "Prince": ["Purple Rain", "When Doves Cry", "Kiss", "1999", "Sign o the Times"],
    "Stevie Wonder": ["Superstition", "Sir Duke", "Isn't She Lovely", "Songs in the Key of Life"],
    "The Rolling Stones": ["Paint It Black", "Satisfaction", "Gimme Shelter", "Angie"],
    "Nirvana": ["Smells Like Teen Spirit", "Nevermind", "Come as You Are", "Heart-Shaped Box"],
    "Elvis Presley": ["Jailhouse Rock", "Hound Dog", "Suspicious Minds", "Blue Suede Shoes", "Love Me Tender"],
    "Bob Marley": ["Redemption Song", "No Woman No Cry", "Exodus", "One Love", "Buffalo Soldier"],
    "Frank Sinatra": ["My Way", "Fly Me to the Moon", "New York New York", "Come Fly with Me"],
    "Louis Armstrong": ["What a Wonderful World", "Hello Dolly", "La Vie en Rose", "West End Blues"],
}

# legend -> creative-complexity tier (1 accessible/feel-good .. 3 dense/cerebral).
LEGEND_TIER: dict[str, int] = {
    # Filmmakers
    "Christopher Nolan": 3, "Quentin Tarantino": 3, "M. Night Shyamalan": 2,
    "Stanley Kubrick": 3, "Alfred Hitchcock": 3, "Martin Scorsese": 3,
    "Steven Spielberg": 2, "Francis Ford Coppola": 3, "Akira Kurosawa": 3,
    "Ridley Scott": 2, "David Fincher": 3, "Wes Anderson": 2,
    "Charlie Chaplin": 2, "Satyajit Ray": 3, "Walt Disney": 1,
    # Musicians & bands
    "Michael Jackson": 2, "The Beatles": 3, "Pink Floyd": 3, "Queen": 2,
    "David Bowie": 3, "Led Zeppelin": 2, "Radiohead": 3, "Bob Dylan": 3,
    "Miles Davis": 3, "Ludwig van Beethoven": 3, "Wolfgang Mozart": 3,
    "Prince": 2, "Stevie Wonder": 2, "The Rolling Stones": 2, "Nirvana": 2,
    "Elvis Presley": 1, "Bob Marley": 2, "Frank Sinatra": 2, "Louis Armstrong": 2,
}

_ROMAN = ["", " II", " III", " IV", " V", " VI", " VII", " VIII", " IX", " X"]

# Crowd favourites — weighted to come up more often (within whatever tier band a
# bank matches). Each of their pairings is this many times as likely as a normal
# legend's.
_FAVORED_WEIGHT: dict[str, int] = {
    "Michael Jackson": 3,
    "Quentin Tarantino": 3,
    "The Beatles": 3,
}

# Favourites span MORE than one complexity tier so they can surface across bands:
# Michael Jackson albums fit both medium and hard/very-hard; The Beatles fit both
# hard and medium. Overrides the single LEGEND_TIER for matching only.
_FAVORED_TIERS: dict[str, set[int]] = {
    "Michael Jackson": {2, 3},
    "The Beatles": {2, 3},
    "Quentin Tarantino": {3},
}

_TIER_BY_DIFFICULTY = {"easy": 1, "medium": 2, "hard": 3, "very hard": 3}
# Substrings in a mode key that signal more cerebral questions — nudge the tier
# up. Keyword-based so custom modes ("analytical_thinking", "critical_thinking",
# "logical_reasoning_level_2", …) count too, not just the built-ins.
_HEAVY_KEYWORDS = ("analyt", "logical", "reason", "operations_research", "dsa", "critical", "puzzle")


def _all_pairings() -> list[tuple[str, str]]:
    return [(f"{legend} - {work}", legend) for legend, works in LEGENDS.items() for work in works]


def _tier_distance(legend: str, target: int) -> int:
    """How far a legend's creative-complexity is from the target tier. Favourites
    span several tiers (distance 0 in any of them), so they surface across bands."""
    tiers = _FAVORED_TIERS.get(legend)
    if tiers:
        return 0 if target in tiers else min(abs(t - target) for t in tiers)
    return abs(LEGEND_TIER.get(legend, 2) - target)


def _target_tier(difficulty: str | None, modes: list[str] | None) -> int:
    tier = _TIER_BY_DIFFICULTY.get((difficulty or "").strip().lower(), 2)
    if any(k in (m or "").lower() for m in (modes or []) for k in _HEAVY_KEYWORDS):
        tier = min(3, tier + 1)
    return tier


def suggest(
    existing: set[str] | list[str] | None = None,
    *,
    difficulty: str | None = None,
    stream: str | None = None,  # kept for call-site compatibility; not used for matching
    modes: list[str] | None = None,
) -> str:
    """A "Legend - Work" name whose legend's creative-complexity tier matches the
    bank's difficulty (+ heavier modes), not already in ``existing``. Falls back
    to a plain random pairing when no difficulty/modes are supplied."""
    taken = {n.strip().lower() for n in (existing or []) if n}
    pairings = _all_pairings()
    available = [(n, legend) for (n, legend) in pairings if n.lower() not in taken]

    if not available:
        base = random.choice([n for n, _ in pairings])
        for suffix in _ROMAN[1:]:
            candidate = f"{base}{suffix}"
            if candidate.lower() not in taken:
                return candidate
        n = 2
        while f"{base} {n}".lower() in taken:
            n += 1
        return f"{base} {n}"

    def _weighted(pairs: list[tuple[str, str]]) -> str:
        """Pick a name, biasing toward the crowd-favourite legends."""
        names = [n for n, _ in pairs]
        weights = [_FAVORED_WEIGHT.get(legend, 1) for _, legend in pairs]
        return random.choices(names, weights=weights, k=1)[0]

    # No character supplied → still a surprise, but favourites weighted.
    if difficulty is None and not modes:
        return _weighted(available)

    target = _target_tier(difficulty, modes)
    # Prefer legends whose creative-complexity tier matches (favourites span
    # several tiers); the many works per legend keep it varied within that band.
    best = max(-_tier_distance(legend, target) for _, legend in available)
    top = [(n, legend) for (n, legend) in available if -_tier_distance(legend, target) == best]
    return _weighted(top)
