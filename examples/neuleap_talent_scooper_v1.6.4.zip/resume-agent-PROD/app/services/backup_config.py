"""Backup & Disaster-Recovery configuration — Settings → Backup & Disaster
Recovery (System Admin only). Controls the schedule (incremental cadence +
weekly full), retention, and the extra copy destinations (a mounted/NAS
secondary path and an S3-compatible cloud target).

Stored as JSON in the bind-mounted ``secrets/`` dir. The cloud secret key is
never returned by the API (only a ``has_secret`` flag), same as the LLM keys.
"""
from __future__ import annotations

import copy
import json
import os
from pathlib import Path
from typing import Any, Dict

from app.logging_config import get_logger

log = get_logger(__name__)

DEFAULT: Dict[str, Any] = {
    "enabled": False,                    # scheduled backups on/off
    "incremental_interval_hours": 6,     # how often an incremental (DB) runs
    "full_weekly_day": 6,                # 0=Mon … 6=Sun — day of the weekly full
    "full_weekly_hour": 2,               # hour (server TZ) of the weekly full
    "retention_full_sets": 2,            # keep at least this many full sets (min 2)
    "retention_incrementals": 14,        # keep this many recent incrementals
    "notify_on_failure": False,          # email when a backup fails
    "notify_emails": "",                 # comma-separated; blank = the Notifications recipient
    "secondary_dir": "",                 # container path of a mounted/NAS copy (optional)
    "cloud": {                           # S3-compatible off-site copy (optional)
        "enabled": False,
        "endpoint": "",                  # blank = AWS S3; else e.g. https://blob-endpoint
        "region": "",
        "bucket": "",
        "prefix": "neuleap-backups",
        "access_key": "",
        "secret_key": "",
    },
}


def _path() -> Path:
    return Path(os.environ.get("BACKUP_CONFIG_FILE", "secrets/backup_config.json"))


def _merge(base: dict, over: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _merge(out[k], v)
        else:
            out[k] = v
    return out


def get() -> Dict[str, Any]:
    try:
        saved = json.loads(_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        saved = {}
    cfg = _merge(DEFAULT, saved)
    # Clamp the load-bearing numbers.
    cfg["retention_full_sets"] = max(2, int(cfg.get("retention_full_sets") or 2))
    cfg["incremental_interval_hours"] = max(1, int(cfg.get("incremental_interval_hours") or 6))
    cfg["full_weekly_day"] = max(0, min(6, int(cfg.get("full_weekly_day") or 0)))
    cfg["full_weekly_hour"] = max(0, min(23, int(cfg.get("full_weekly_hour") or 0)))
    return cfg


def save(cfg: Dict[str, Any]) -> Dict[str, Any]:
    """Persist config. A blank cloud.secret_key in the incoming payload KEEPS the
    stored one (so the UI never has to re-enter it), mirroring the LLM-key flow."""
    current = get()
    incoming = _merge(current, cfg or {})
    new_secret = ((cfg or {}).get("cloud") or {}).get("secret_key")
    if not new_secret:
        incoming["cloud"]["secret_key"] = current["cloud"]["secret_key"]
    path = _path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(incoming, indent=2), encoding="utf-8")
    except OSError as exc:  # noqa: BLE001
        log.warning("backup_config: could not write %s: %s", path, exc)
    return incoming


def revert_to_default() -> Dict[str, Any]:
    try:
        p = _path()
        if p.exists():
            p.unlink()
    except OSError as exc:  # noqa: BLE001
        log.warning("backup_config: could not remove config: %s", exc)
    return get()


def public(cfg: Dict[str, Any] | None = None) -> Dict[str, Any]:
    """Config safe to return over the API — the cloud secret is masked to a flag."""
    cfg = cfg or get()
    out = copy.deepcopy(cfg)
    cloud = out.get("cloud", {})
    out["cloud"] = {**cloud, "secret_key": "", "has_secret": bool(cloud.get("secret_key"))}
    return out
