"""Object-store abstraction (MinIO by default, AWS S3 optional).

Two-bucket model (D2):
  * ``raw`` bucket    — written by L1 (key ``YYYY/MM/DD/{e_id}/file``, no prefix,
    because the bucket itself is named ``raw``). L2 reads/lists from here.
  * ``resume`` bucket — clean copies written by L2 (key ``resume/YYYY/MM/DD/{cid}/file``);
    L3 reads from here. ``s3_file_path`` stored on candidate_master is this key.

Raw-bucket access is explicit (``raw=True`` on list/get, and ``copy`` always
goes raw→resume); everything else defaults to the ``resume`` bucket.
"""
from __future__ import annotations

import logging
import tempfile
from abc import ABC, abstractmethod
from datetime import datetime
from pathlib import Path
from typing import BinaryIO, Optional
from urllib.parse import urlparse

from app.config import settings
from app.services import clock

logger = logging.getLogger(__name__)


def _to_key(path: str) -> str:
    """Normalize a stored path to a bare object key.

    Strips an ``s3://bucket/`` scheme or leading slashes. A bare key such as
    ``resume/2024/01/20/C1001/x.pdf`` is returned unchanged — the leading
    ``resume/`` is a key prefix, NOT the bucket (even though the bucket is also
    named ``resume``).
    """
    if path.startswith("s3://"):
        return urlparse(path).path.lstrip("/")
    return path.lstrip("/\\")


class S3Service(ABC):

    @abstractmethod
    def list_keys(self, prefix: str, *, raw: bool = False) -> list[str]: ...

    @abstractmethod
    def get_bytes(self, key: str, *, raw: bool = False) -> bytes: ...

    @abstractmethod
    def copy(self, src_key: str, dst_key: str) -> None: ...

    @abstractmethod
    def put_bytes(self, key: str, data: bytes, *, raw: bool = False) -> None: ...

    @abstractmethod
    def delete(self, key: str, *, raw: bool = False) -> None: ...

    @abstractmethod
    def ensure_buckets(self) -> None: ...

    def raw_prefix(self, e_id: str, run_date: str) -> str:
        # No `raw/` prefix — the bucket itself is `raw` (matches L1's dated_key).
        y, m, d = run_date.split("-")
        return f"{y}/{m}/{d}/{e_id}/"

    def clean_prefix(self, candidate_id: str, run_date: str) -> str:
        y, m, d = run_date.split("-")
        return f"{settings.s3_resume_prefix}/{y}/{m}/{d}/{candidate_id}/"


class BotoS3Service(S3Service):
    """boto3 implementation over two buckets (raw source + resume dest)."""

    def __init__(self, client, raw_bucket: str, resume_bucket: str) -> None:
        self._s3 = client
        self._raw = raw_bucket
        self._resume = resume_bucket

    def _bucket(self, raw: bool) -> str:
        return self._raw if raw else self._resume

    def list_keys(self, prefix: str, *, raw: bool = False) -> list[str]:
        keys: list[str] = []
        paginator = self._s3.get_paginator("list_objects_v2")
        for page in paginator.paginate(Bucket=self._bucket(raw), Prefix=prefix):
            for obj in page.get("Contents", []):
                keys.append(obj["Key"])
        return keys

    def get_bytes(self, key: str, *, raw: bool = False) -> bytes:
        obj = self._s3.get_object(Bucket=self._bucket(raw), Key=_to_key(key))
        return obj["Body"].read()

    def copy(self, src_key: str, dst_key: str) -> None:
        """Cross-bucket copy: raw source → resume destination."""
        self._s3.copy_object(
            Bucket=self._resume,
            CopySource={"Bucket": self._raw, "Key": _to_key(src_key)},
            Key=_to_key(dst_key),
        )

    def put_bytes(self, key: str, data: bytes, *, raw: bool = False) -> None:
        self._s3.put_object(Bucket=self._bucket(raw), Key=_to_key(key), Body=data)

    def delete(self, key: str, *, raw: bool = False) -> None:
        """Delete an object. Idempotent — S3 delete_object never errors on a miss."""
        self._s3.delete_object(Bucket=self._bucket(raw), Key=_to_key(key))

    def ensure_buckets(self) -> None:
        from botocore.exceptions import ClientError
        for bucket in (self._raw, self._resume):
            try:
                self._s3.head_bucket(Bucket=bucket)
            except ClientError:
                try:
                    self._s3.create_bucket(Bucket=bucket)
                    logger.info("Created bucket %s", bucket)
                except ClientError as exc:  # already exists / race
                    logger.warning("ensure_buckets(%s): %s", bucket, exc)


def _minio_service() -> BotoS3Service:
    import boto3
    from botocore.client import Config
    client = boto3.client(
        "s3",
        endpoint_url=settings.minio_endpoint,
        aws_access_key_id=settings.minio_access_key,
        aws_secret_access_key=settings.minio_secret_key,
        region_name=settings.minio_region,
        config=Config(signature_version="s3v4", s3={"addressing_style": "path"}),
    )
    return BotoS3Service(client, settings.minio_raw_bucket, settings.minio_resume_bucket)


def _aws_service() -> BotoS3Service:
    import boto3
    return BotoS3Service(boto3.client("s3"),
                         settings.minio_raw_bucket, settings.minio_resume_bucket)


# ── Singleton factory ─────────────────────────────────────────────────────────

_s3: S3Service | None = None


def s3() -> S3Service:
    global _s3
    if _s3 is None:
        _s3 = _aws_service() if settings.s3_backend == "aws" else _minio_service()
    return _s3


def ensure_buckets() -> None:
    s3().ensure_buckets()


# Back-compat alias (older callers used the single-bucket name).
def ensure_bucket() -> None:
    ensure_buckets()


# ── Helpers used by L3 extraction endpoints ────────────────────────────────────

def upload_resume(
    file_obj: BinaryIO,
    filename: str,
    content_type: str = "",
    candidate_id: str = "",
    dt: Optional[datetime] = None,
) -> str:
    """Upload a resume and return its bare key (the stored ``s3_file_path``).

    With a candidate_id the key is ``resume/YYYY/MM/DD/{cid}/{filename}`` to
    match L2's clean-resume convention; otherwise a flat key is used.
    """
    if dt is None:
        dt = clock.now()
    clean = filename.lstrip("/\\")
    if candidate_id:
        key = f"{settings.s3_resume_prefix}/{dt:%Y/%m/%d}/{candidate_id}/{clean}"
    else:
        key = clean
    s3().put_bytes(key, file_obj.read())
    return key


def download_resume_to_temp(s3_file_path: str) -> str:
    """Download an object to a temp file and return the local path."""
    data = s3().get_bytes(s3_file_path)
    suffix = Path(_to_key(s3_file_path)).suffix
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        tmp.write(data)
        return tmp.name
