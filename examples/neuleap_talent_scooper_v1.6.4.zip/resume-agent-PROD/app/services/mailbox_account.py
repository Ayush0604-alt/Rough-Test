"""Intake mailbox account & folder routing — Settings → Mailbox Account.

Stores WHICH mailbox the pipeline scans, the folder it scans, and the folders
processed mail is moved to per outcome — plus the mailbox credentials, with
the password encrypted at rest in PostgreSQL (Fernet/AES-128-CBC+HMAC via the
`cryptography` package, key derived from ``MAILBOX_ENC_KEY`` or, as a
fallback, the JWT secret).

Security posture:
  * The password NEVER leaves the server: the API returns only ``has_password``.
  * Saving requires the acting System Admin to re-enter their OWN password
    (same friction as the email-send switches) — see app.api.settings.
  * Every save is audit-logged (who + what changed, never the secret itself).
  * NOTE: today's Graph intake authenticates via the Azure app registration
    (client credentials), so the stored password is used only where a
    basic-auth/IMAP integration is enabled — but the mailbox address and the
    folder names configured here DO drive the live pipeline immediately.
"""
from __future__ import annotations

import base64
import hashlib
import os
from typing import Any, Dict, Optional

import psycopg2.extras
from cryptography.fernet import Fernet, InvalidToken

from app.config import settings
from app.db import get_conn
from app.logging_config import get_logger

log = get_logger(__name__)

# Folder keys, in pipeline order. "scan_folder" is where new mail is picked up
# (the Landing folder); the rest are the per-outcome destinations.
FOLDER_FIELDS = ["scan_folder", "folder_processing", "folder_processed", "folder_failed", "folder_non_resume"]

_ENV_DEFAULTS = {
    "scan_folder": os.environ.get("GRAPH_FOLDER_LANDING", "Landing"),
    "folder_processing": os.environ.get("GRAPH_FOLDER_PROCESSING", "Processing"),
    "folder_processed": os.environ.get("GRAPH_FOLDER_PROCESSED", "Processed"),
    "folder_failed": os.environ.get("GRAPH_FOLDER_FAILED", "Failed"),
    "folder_non_resume": os.environ.get("GRAPH_FOLDER_NON_RESUME", "Non-Resume"),
}


def _fernet() -> Fernet:
    # Prefer a dedicated key so rotating the JWT secret doesn't orphan the
    # stored credential; fall back to the JWT secret so encryption always
    # works out of the box.
    secret = os.environ.get("MAILBOX_ENC_KEY") or settings.jwt_secret
    key = base64.urlsafe_b64encode(hashlib.sha256(secret.encode("utf-8")).digest())
    return Fernet(key)


def _row() -> Optional[dict]:
    with get_conn() as conn:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute("SELECT * FROM mailbox_account_config WHERE id = 1")
            r = cur.fetchone()
            return dict(r) if r else None


def get_public() -> Dict[str, Any]:
    """The config as the API may expose it — the password never leaves the
    server, only whether one is stored."""
    r = _row()
    out: Dict[str, Any] = {
        "email": (r or {}).get("email") or os.environ.get("GRAPH_MAILBOX", ""),
        "has_password": bool((r or {}).get("password_enc")),
        "updated_at": r["updated_at"].isoformat() if r and r.get("updated_at") else None,
        "updated_by": (r or {}).get("updated_by"),
    }
    for f in FOLDER_FIELDS:
        out[f] = (r or {}).get(f) or _ENV_DEFAULTS[f]
    return out


def save(
    *, email: str, password: Optional[str], updated_by: str, **folders: str
) -> Dict[str, Any]:
    """Persist the account + folder routing. An empty/None password keeps the
    already-stored one (so folder edits never require re-typing the secret)."""
    email = (email or "").strip()
    if not email or "@" not in email:
        raise ValueError("A valid mailbox email address is required.")
    vals = {}
    for f in FOLDER_FIELDS:
        v = (folders.get(f) or "").strip()
        if not v:
            raise ValueError(f"{f.replace('_', ' ')} is required.")
        vals[f] = v
    if len(set(vals.values())) < len(vals):
        raise ValueError("Each folder must be distinct — two outcomes can't share one folder.")

    existing = _row()
    if password:
        password_enc = _fernet().encrypt(password.encode("utf-8")).decode("ascii")
    else:
        password_enc = (existing or {}).get("password_enc")

    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO mailbox_account_config
                    (id, email, password_enc, scan_folder, folder_processing,
                     folder_processed, folder_failed, folder_non_resume, updated_by, updated_at)
                VALUES (1, %s, %s, %s, %s, %s, %s, %s, %s, CURRENT_TIMESTAMP)
                ON CONFLICT (id) DO UPDATE SET
                    email = EXCLUDED.email,
                    password_enc = EXCLUDED.password_enc,
                    scan_folder = EXCLUDED.scan_folder,
                    folder_processing = EXCLUDED.folder_processing,
                    folder_processed = EXCLUDED.folder_processed,
                    folder_failed = EXCLUDED.folder_failed,
                    folder_non_resume = EXCLUDED.folder_non_resume,
                    updated_by = EXCLUDED.updated_by,
                    updated_at = CURRENT_TIMESTAMP
                """,
                (email, password_enc, vals["scan_folder"], vals["folder_processing"],
                 vals["folder_processed"], vals["folder_failed"], vals["folder_non_resume"],
                 updated_by),
            )
    # The Graph layer caches resolved folder ids by name — renamed folders must
    # re-resolve on the next call.
    try:
        from app.services import graph_client

        graph_client.reset_folder_cache()
    except Exception as exc:  # noqa: BLE001 — cache reset is best-effort
        log.warning("mailbox_account: could not reset graph folder cache: %s", exc)
    try:
        from app.services import audit

        audit.write_event(
            layer="SYSTEM", step="mailbox_account_changed", status="Info",
            fail_reason=(
                f"Intake mailbox config saved by {updated_by}: {email}, scan '{vals['scan_folder']}' "
                f"→ processed '{vals['folder_processed']}' / failed '{vals['folder_failed']}' / "
                f"non-resume '{vals['folder_non_resume']}'"
                + (" (password updated)" if password else "")
            ),
        )
    except Exception as exc:  # noqa: BLE001
        log.warning("mailbox_account: audit write failed: %s", exc)
    log.info("mailbox_account: saved by %s (password %s)", updated_by, "updated" if password else "kept")
    return get_public()


def get_password() -> Optional[str]:
    """Decrypted mailbox password for INTERNAL integrations only (e.g. an
    IMAP/basic-auth intake) — never exposed over the API."""
    r = _row()
    enc = (r or {}).get("password_enc")
    if not enc:
        return None
    try:
        return _fernet().decrypt(enc.encode("ascii")).decode("utf-8")
    except (InvalidToken, ValueError):
        log.warning("mailbox_account: stored password cannot be decrypted (key changed?)")
        return None


def configured_mailbox() -> Optional[str]:
    """The DB-configured mailbox address, if any — overrides GRAPH_MAILBOX."""
    r = _row()
    return (r or {}).get("email") or None


def configured_folder(key: str) -> Optional[str]:
    """DB-configured folder name for a logical key used by graph_client
    ("landing" | "processing" | "processed" | "failed" | "non_resume")."""
    col = "scan_folder" if key == "landing" else f"folder_{key}"
    r = _row()
    return (r or {}).get(col) or None
