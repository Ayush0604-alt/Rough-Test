"""Interview-question generation modes — Settings → Interview Question
Generation. The multi-select "Combine with question modes" dropdown is driven
by this list. The eight built-ins are the DEFAULT; an Admin can add, edit or
remove types here, and Reset to default restores the built-ins.

Each mode: ``{key, label, bucket_name, topic, guidance}``
  * key         — stable id sent by the client (slug).
  * label       — dropdown text.
  * bucket_name — the section name the generated bucket uses (also the key the
                  composition-weight rider addresses).
  * topic       — web-search query used when "Search the web" is on.
  * guidance    — optional extra instruction fed to the LLM for this mode.

Stored as a JSON file in the bind-mounted ``secrets/`` dir. Config, not
candidate data.
"""
from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Any, Dict, List

from app.logging_config import get_logger

log = get_logger(__name__)

DEFAULT_MODES: List[Dict[str, str]] = [
    {"key": "sql_aptitude", "label": "SQL Aptitude Questions",
     "bucket_name": "SQL Aptitude", "topic": "SQL aptitude interview questions", "guidance": ""},
    {"key": "logical_reasoning", "label": "Logical Thinking Ability Evaluation Questions",
     "bucket_name": "Logical Thinking Ability Evaluation",
     "topic": "logical reasoning aptitude questions with answers", "guidance": ""},
    {"key": "dsa_aptitude", "label": "DSA (Data Structures & Algorithms) Aptitude Questions",
     "bucket_name": "DSA (Data Structures & Algorithms) Aptitude",
     "topic": "data structures and algorithms interview questions", "guidance": ""},
    {"key": "python_libraries_aptitude",
     "label": "Aptitude Questions against Python Libraries across GenAI, Data Engineering & FastAPI",
     "bucket_name": "Python Libraries Aptitude (GenAI, Data Engineering & FastAPI)",
     "topic": "python pandas numpy fastapi interview questions", "guidance": ""},
    {"key": "data_eng_dwh_aptitude", "label": "Data Engineering & Data Warehousing Aptitude Questions",
     "bucket_name": "Data Engineering & Data Warehousing Aptitude",
     "topic": "data engineering data warehouse interview questions", "guidance": ""},
    {"key": "prompt_writing", "label": "Prompt Writing",
     "bucket_name": "Prompt Writing", "topic": "prompt engineering exercises and best practices",
     "guidance": "Tasks to author/critique/iterate LLM prompts: write a prompt for a concrete "
                 "task, spot what's wrong with a given prompt, add guardrails/format constraints."},
    {"key": "operations_research", "label": "Operations Research type Questions",
     "bucket_name": "Operations Research",
     "topic": "operations research linear programming interview problems",
     "guidance": "Optimization & decision problems: linear programming, scheduling, "
                 "transportation/assignment, queuing, inventory — set up the model and reason."},
    {"key": "analytical_reasoning",
     "label": "Analytical Thinking & Logical Reasoning (estimation & puzzles)",
     "bucket_name": "Analytical Thinking & Logical Reasoning",
     "topic": "Fermi estimation guesstimate puzzles interview brain teasers elevator algorithm",
     "guidance": "Sharp reasoning + estimation (guesstimate/Fermi) + algorithmic-logic puzzles of "
                 "the high-quality lateral-thinking kind (e.g. estimate paint for an aircraft, "
                 "design elevator control logic, weighing/river-crossing puzzles). Each question's "
                 "strong_answer must lay out the reasoning/estimation steps, not just a number."},
]

_KEY_RE = re.compile(r"[^a-z0-9_]+")


def _path() -> Path:
    return Path(os.environ.get("INTERVIEW_MODES_FILE", "secrets/interview_modes.json"))


def _slug(label: str) -> str:
    s = _KEY_RE.sub("_", (label or "").strip().lower()).strip("_")
    return s or "mode"


def _clean(raw: Any) -> List[Dict[str, str]]:
    out: List[Dict[str, str]] = []
    seen: set[str] = set()
    for item in raw or []:
        if not isinstance(item, dict):
            continue
        label = str(item.get("label") or "").strip()[:120]
        if not label:
            continue
        key = str(item.get("key") or "").strip().lower() or _slug(label)
        key = _KEY_RE.sub("_", key).strip("_") or _slug(label)
        if key in seen:
            continue
        seen.add(key)
        bucket = str(item.get("bucket_name") or label).strip()[:120]
        out.append({
            "key": key,
            "label": label,
            "bucket_name": bucket,
            "topic": str(item.get("topic") or "").strip()[:200],
            "guidance": str(item.get("guidance") or "").strip()[:1000],
        })
    return out


def get() -> List[Dict[str, str]]:
    try:
        raw = json.loads(_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return [dict(m) for m in DEFAULT_MODES]
    cleaned = _clean(raw if isinstance(raw, list) else raw.get("modes"))
    return cleaned or [dict(m) for m in DEFAULT_MODES]


def save(modes: List[Dict[str, Any]]) -> List[Dict[str, str]]:
    cleaned = _clean(modes)
    if not cleaned:
        raise ValueError("At least one question type is required.")
    path = _path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(cleaned, indent=2), encoding="utf-8")
        log.info("interview_modes_config: saved %s (%d modes)", path, len(cleaned))
    except OSError as exc:  # noqa: BLE001
        log.warning("interview_modes_config: could not write %s: %s", path, exc)
    return get()


def revert_to_default() -> List[Dict[str, str]]:
    try:
        p = _path()
        if p.exists():
            p.unlink()
    except OSError as exc:  # noqa: BLE001
        log.warning("interview_modes_config: could not remove file: %s", exc)
    return get()


# ── Lookups used by the generator ────────────────────────────────────────────
def bucket_names() -> Dict[str, str]:
    return {m["key"]: m["bucket_name"] for m in get()}


def search_topics() -> Dict[str, str]:
    return {m["key"]: m["topic"] for m in get() if m.get("topic")}


def guidance() -> Dict[str, str]:
    return {m["bucket_name"]: m["guidance"] for m in get() if m.get("guidance")}
