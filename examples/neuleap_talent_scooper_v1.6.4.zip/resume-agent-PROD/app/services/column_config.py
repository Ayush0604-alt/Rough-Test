"""Candidates-table column display config — which configurable columns are shown.

Backs the Candidates page's "Column Config" button: a flat ``{column_key: visible}`` map
the recruiter toggles + saves. Persisted as JSON in the bind-mounted ``secrets/`` dir
(default ``secrets/columns.json``, override with ``COLUMN_CONFIG_FILE``) so the choice is
shared by every user and survives container restarts — the same runtime-file philosophy as
:mod:`app.services.scoring_config` / :mod:`app.services.notify_config`.

This module owns the canonical column list (key + recruiter-facing label + default
visibility). The frontend renders the toggles and the table cells from the SAME keys, so
the two never drift. The operational columns (Stream, Received, Scheduled, Aging, ATS, Round
Status) and the Interview action are configurable too — only Candidate Name is pinned (kept
visible) on the frontend; everything else can be toggled on/off.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, List

from app.logging_config import get_logger

log = get_logger(__name__)

# (key, recruiter-facing label, default visible). Order is the panel order. Keys MUST match
# the frontend column registry (screeningColumns.tsx) + the candidate_name/experience gates.
_COLUMNS: List[tuple[str, str, bool]] = [
    ("candidate_name", "Candidate Name", True),
    # Operational columns — rendered with bespoke cells in the table (not via the frontend
    # registry), but toggleable here. They default ON so the table is unchanged out of the box.
    ("stream", "Stream", True),
    ("received", "Received", True),
    ("scheduled", "Scheduled", True),
    ("aging", "Aging", True),
    ("ats", "ATS", True),
    ("analysis_report", "Analysis Report", True),
    ("round_status", "Round Status", True),
    ("interview", "Interview", True),
    # Predicted NBA — the system-predicted (NLRS-banded) suggestion + its Apply
    # action, pinned at the end. Defaults ON: it was previously an unconditional
    # column, so hiding it now would be a visible regression out of the box.
    ("predicted_nba", "Predicted NBA", True),
    # JD Match — on-demand fit score against whatever JD the recruiter last
    # uploaded/pasted this session (app.services.jd_match). Defaults OFF: blank
    # until a JD has actually been matched, so it shouldn't clutter the table
    # for recruiters who never use the feature.
    ("jd_match", "JD Match Score", False),
    ("email", "Email", False),
    ("phone", "Phone", False),
    ("location", "Location", False),
    # Recruiter-typed intake source (e.g. "LinkedIn - Senior GenAI post") — see
    # app.services.source_tags. Defaults OFF: null on most historical rows.
    ("source", "Source", False),
    ("college", "College", True),
    ("highest_degree", "Highest Degree", False),
    ("domain", "Domain", False),
    ("passout_year", "Passout Year", True),
    ("cgpa", "CGPA", True),
    ("projects", "Projects", False),
    ("certificates", "Certificates", False),
    ("fresher_or_lateral", "Fresher / Lateral", False),
    ("current_company", "Current Company", False),
    ("job_role", "Job Role", True),
    ("experience", "Experience", True),
    ("career_gap", "Career Gap", True),
    ("primary_skills", "Primary Skills", True),
    ("next_best_action", "Next Best Action", False),
    ("one_line_summary", "One-Line Summary", False),
    ("thinking_summary", "Thinking Summary", False),
    # NLRS (Neuleap Resume Score) — placeholder column; renders blank until the resume
    # insights/analysis feature (app/matching/resumeanalysis_skill.md) is implemented.
    ("nlrs", "NLRS (Neuleap Resume Score)", False),
]

_VALID_KEYS = {key for key, _, _ in _COLUMNS}


_LABELS = {key: label for key, label, _ in _COLUMNS}
_DEFAULT_VISIBLE = {key: default for key, _, default in _COLUMNS}
_DEFAULT_ORDER = [key for key, _, _ in _COLUMNS]

# ── Dynamic columns carried from an Excel intake source ──────────────────────
# Keys like "College__from-source-sheet" / "CGPA__from-resume" aren't in the
# static list above — they're discovered from candidate_master.source_columns and
# offered as toggleable columns (default OFF, so they never flood the table). The
# frontend renders their cells from `candidate.source_columns[key]`.
_SHEET_SUFFIX = "__from-source-sheet"
_RESUME_SUFFIX = "__from-resume"


def _is_dynamic(key: Any) -> bool:
    return isinstance(key, str) and (key.endswith(_SHEET_SUFFIX) or key.endswith(_RESUME_SUFFIX))


def _valid(key: Any) -> bool:
    return key in _VALID_KEYS or _is_dynamic(key)


def _label_for(key: str) -> str:
    if key in _LABELS:
        return _LABELS[key]
    if key.endswith(_SHEET_SUFFIX):
        return f"{key[: -len(_SHEET_SUFFIX)]} (sheet)"
    if key.endswith(_RESUME_SUFFIX):
        return f"{key[: -len(_RESUME_SUFFIX)]} (resume)"
    return key


def _default_visible_for(key: str) -> bool:
    # Dynamic Excel columns default OFF; the recruiter opts them in via the modal.
    return _DEFAULT_VISIBLE.get(key, False)


def _dynamic_keys() -> List[str]:
    """Distinct Excel-sourced column keys present across candidates, sorted."""
    try:
        from app.db import get_conn

        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT DISTINCT jsonb_object_keys(source_columns) AS k "
                    "FROM candidate_master WHERE source_columns IS NOT NULL"
                )
                return sorted(r[0] for r in cur.fetchall() if _is_dynamic(r[0]))
    except Exception as exc:  # noqa: BLE001 — discovery is best-effort, never break config
        log.warning("column_config: dynamic key discovery failed: %s", exc)
        return []


def _path() -> Path:
    return Path(os.environ.get("COLUMN_CONFIG_FILE", "secrets/columns.json"))


def _saved() -> List[Dict[str, Any]]:
    """The persisted ordered ``[{key, visible}]`` ({} / [] when no file yet or unreadable).

    Accepts the legacy ``{key: bool}`` map too, so an older file keeps working.
    """
    try:
        raw = json.loads(_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    if isinstance(raw, dict):  # legacy visibility-only map → order falls back to default
        return [{"key": k, "visible": bool(v)} for k, v in raw.items() if _valid(k)]
    if isinstance(raw, list):
        return [
            {"key": e["key"], "visible": bool(e.get("visible"))}
            for e in raw
            if isinstance(e, dict) and _valid(e.get("key"))
        ]
    return []


def get() -> Dict[str, Any]:
    """Current config in the shape the Candidates page renders: an ordered list of
    ``{key, label, visible}`` — saved order + visibility, with any newly-added columns
    appended at their default position/visibility."""
    saved = _saved()
    saved_vis = {e["key"]: e["visible"] for e in saved}
    # Saved order first (de-duped), then any known columns not yet saved, then the
    # dynamic Excel-sourced columns discovered from the data — each appended once.
    ordered_keys: List[str] = []
    for entry in saved:
        if entry["key"] not in ordered_keys:
            ordered_keys.append(entry["key"])
    for key in _DEFAULT_ORDER:
        if key not in ordered_keys:
            ordered_keys.append(key)
    for key in _dynamic_keys():
        if key not in ordered_keys:
            ordered_keys.append(key)

    columns = [
        {"key": key, "label": _label_for(key), "visible": saved_vis.get(key, _default_visible_for(key))}
        for key in ordered_keys
    ]
    return {"columns": columns}


def save(columns: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Persist the given ordered ``[{key, visible}]`` (unknown keys ignored, missing known
    keys appended in default order), then return the refreshed :func:`get`. Writing never
    raises — a disk hiccup just keeps the old file."""
    seen: set[str] = set()
    ordered: List[Dict[str, Any]] = []
    for entry in columns or []:
        if not isinstance(entry, dict):
            continue
        key = entry.get("key")
        if _valid(key) and key not in seen:
            ordered.append({"key": key, "visible": bool(entry.get("visible"))})
            seen.add(key)
    # Any known/dynamic column the caller omitted keeps its current/default state, appended last.
    current_vis = {c["key"]: c["visible"] for c in get()["columns"]}
    for key in [*_DEFAULT_ORDER, *_dynamic_keys()]:
        if key not in seen:
            ordered.append({"key": key, "visible": current_vis.get(key, _default_visible_for(key))})
            seen.add(key)

    path = _path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(ordered, indent=2), encoding="utf-8")
        log.info("column_config: saved %s", path)
    except OSError as exc:  # noqa: BLE001 — a write failure must not break the request
        log.warning("column_config: could not write %s: %s", path, exc)
    return get()
