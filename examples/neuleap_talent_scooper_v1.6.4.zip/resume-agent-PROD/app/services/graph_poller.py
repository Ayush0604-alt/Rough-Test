"""Background Microsoft Graph (Outlook) poller — refresh the Intake queue.

Every N seconds it asks Graph for the Inbox mail in the rolling lookback window
(24h), queued by **date received** (not read-status), and caches a lightweight
preview for the Intake page. It **never processes or moves** anything — that
happens only on a pipeline run (the midnight cron or the Run Pipeline button),
which moves each mail Inbox → Processing → Processed and so drains the queue. Think
of it as the live "what's waiting in Outlook" view.

Config (env):
    GRAPH_POLL_ENABLED             1 to run the poller (default 1)
    GRAPH_POLL_INTERVAL_SECONDS    poll period (default 60)
    GRAPH_LOOKBACK_HOURS           window for "today's" mail (default 24)

Degrades cleanly: if Graph isn't configured the tick caches an empty queue with a
``not_configured`` marker instead of erroring.
"""

from __future__ import annotations

import os
import re
import threading
from datetime import datetime, timezone
from typing import Any, Optional

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.interval import IntervalTrigger

from app.logging_config import get_logger
from app.services import clock

log = get_logger(__name__)

_scheduler: Optional[BackgroundScheduler] = None
JOB_ID = "graph-inbox-poll"
_URL_RE = re.compile(r"https?://[^\s<>\"')]+", re.IGNORECASE)

# Latest poll snapshot (the Intake page reads this; the poller is the only writer).
_LOCK = threading.Lock()
_STATE: dict[str, Any] = {
    "items": [], "count": 0, "rejected": 0, "polled_at": None, "error": None,
}


def is_enabled() -> bool:
    return os.environ.get("GRAPH_POLL_ENABLED", "1") == "1"


def interval_seconds() -> int:
    try:
        return max(10, int(os.environ.get("GRAPH_POLL_INTERVAL_SECONDS", "60")))
    except ValueError:
        return 60


def promote_batch() -> int:
    """Max Landing messages a single poll tick promotes → Processing.

    Bounds the per-tick work so a large Landing backlog drains in chunks over several
    ticks instead of one slow burst (each message means a classify + a move). Set
    GRAPH_PROMOTE_BATCH (default 50). The pipeline run drains the Processing queue this
    feeds, so capping here also keeps a batch from stalling on a Landing backlog.
    """
    try:
        return max(1, int(os.environ.get("GRAPH_PROMOTE_BATCH", "50")))
    except ValueError:
        return 50


def auto_promote_enabled() -> bool:
    """True when each poll tick should move today's Inbox resumes → Processing.

    This is what makes the move happen "automatically after 60s": the resume gate runs
    here, and accepted mail is moved out of the Inbox into the Processing **queue** that
    the pipeline drains. Disable (``GRAPH_AUTO_PROMOTE=0``) to keep the poller read-only;
    the pipeline then self-drains the Inbox on each run instead.
    """
    return os.environ.get("GRAPH_AUTO_PROMOTE", "1") == "1"


def _now() -> str:
    return clock.now_iso()


def _simplify(msg: dict[str, Any]) -> dict[str, Any]:
    """One raw Graph message -> the compact shape the Intake queue renders.

    For a FORWARDED resume the envelope ``from`` is the forwarding mailbox, not the
    candidate's recruiter. Show the ORIGINAL sender's display name recovered from the
    quoted body ("Harsh Chhabda"), falling back to the envelope display name/address.
    """
    from app.services.mail_intake import original_sender_display_from_forward

    frm = (msg.get("from") or {}).get("emailAddress", {}) or {}
    envelope = frm.get("name") or frm.get("address") or "unknown"
    subject = msg.get("subject") or ""
    body = (msg.get("body") or {}).get("content") or msg.get("bodyPreview") or ""
    return {
        "id": msg.get("id"),
        "subject": subject or "(no subject)",
        "sender": original_sender_display_from_forward(subject, body, envelope),
        "received_date": msg.get("receivedDateTime"),
        "has_attachments": bool(msg.get("hasAttachments")),
    }


def _looks_like_resume(msg: dict[str, Any]) -> bool:
    """Cheap, no-LLM payload check for the live preview (full classify runs at intake).

    Hides blocklisted senders and LinkedIn-style alerts (website-only, no attachment);
    admits a mail with an attachment OR a resume/file-share link in the body.
    """
    from app.pipeline.mail.queue import resume_filter

    sender = (msg.get("from") or {}).get("emailAddress", {}).get("address", "")
    if resume_filter.blocklisted_sender(sender):
        return False
    if msg.get("hasAttachments"):
        return True
    # Scan the FULL HTML body, not just bodyPreview — SharePoint/OneDrive resume
    # links live as hyperlinks in the HTML and never appear in the preview text.
    body = (msg.get("body") or {}).get("content") or msg.get("bodyPreview") or ""
    links = _URL_RE.findall(body)
    return any(resume_filter.is_resume_link(u) for u in links)


def _promote_inbox_to_processing() -> int:
    """Move waiting resume mail in Landing → the Processing folder. Returns #skipped.

    Runs the authoritative resume gate (blocklist → classifier) per Landing message and
    moves the accepted ones to Processing so the pipeline finds them there — this is the
    "auto-move after 60s". Mail that fails the gate is moved to the **Non-Resume** folder
    so it leaves Landing (and isn't re-classified next tick) without polluting Failed.
    Best-effort: a mailbox/classifier hiccup on one message never aborts the tick.
    """
    from app.pipeline.mail.queue import agent_classifier, resume_filter
    from app.services import graph_client

    if not (graph_client.move_enabled() and auto_promote_enabled()):
        return 0

    filter_on = os.environ.get("MAIL_RESUME_FILTER", "1") != "0"
    skipped = 0
    # Everything in Landing is waiting — handled mail is MOVED out into a subfolder, so
    # we don't skip by read-status here (a human opening a mail must not exclude it).
    # Capped per tick so a backlog drains in chunks rather than one slow burst.
    for msg in graph_client.fetch_inbox(top=promote_batch()):
        try:
            sender = (msg.get("from") or {}).get("emailAddress", {}).get("address", "")
            subject = msg.get("subject") or ""
            body = (msg.get("body") or {}).get("content") or msg.get("bodyPreview") or ""
            links = _URL_RE.findall(body)
            if filter_on:
                if resume_filter.blocklisted_sender(sender):
                    graph_client.move_message(msg["id"], "non_resume")
                    skipped += 1
                    continue
                names = (graph_client.fetch_attachment_names(msg["id"])
                         if msg.get("hasAttachments") else [])
                accept, reason = agent_classifier.classify_is_resume(
                    subject, body, names, links, sender)
                if not accept:
                    log.info("graph promote: skip %r → Non-Resume — %s", subject[:60], reason)
                    graph_client.move_message(msg["id"], "non_resume")
                    skipped += 1
                    continue
            graph_client.move_message(msg["id"], "processing")
        except Exception as exc:  # noqa: BLE001 — one bad mail must not abort the tick
            log.warning("graph promote: skipping %s — %s", msg.get("id"), exc)
            skipped += 1
    return skipped


def tick() -> dict[str, Any]:
    """One poll cycle. Never raises.

    With auto-promote on (the default), it first moves today's Inbox resumes into the
    Processing folder, then caches the **Processing queue** (the resumes awaiting the
    pipeline) for the Intake page. With moves disabled it falls back to the old
    read-only Inbox preview.
    """
    from app.services import graph_client

    if not graph_client.is_configured():
        with _LOCK:
            _STATE.update(items=[], count=0, rejected=0, polled_at=_now(), error="not_configured")
        return dict(_STATE)
    try:
        if graph_client.move_enabled():
            # Auto-move Landing resumes → Processing, then the queue IS the Processing folder.
            skipped = _promote_inbox_to_processing()
            raw = graph_client.fetch_folder("processing")

            # Age-check every Processing message.
            # ≤ max_age_days (default 365 — incl. previous days) → show in queue.
            # older / undateable → move to Failed so the folder stays clean.
            from app.services.mail_intake import _age_days, _processing_max_age_days
            max_age = _processing_max_age_days()
            items = []
            expired = 0
            for m in raw:
                if _age_days(m.get("receivedDateTime")) <= max_age:
                    items.append(_simplify(m))
                else:
                    try:
                        graph_client.move_message(m["id"], "failed")
                        expired += 1
                        log.info("graph poll: expired message %s (>%dd) → Failed", m.get("id"), max_age)
                    except Exception as exc:  # noqa: BLE001
                        log.warning("graph poll: could not expire %s — %s", m.get("id"), exc)
                        items.append(_simplify(m))  # keep in queue if move failed

            with _LOCK:
                _STATE.update(items=items, count=len(items), rejected=skipped,
                              polled_at=_now(), error=None)
            log.info("graph poll: %d in Processing queue, %d Inbox skipped, %d expired→Failed",
                     len(items), skipped, expired)
        else:
            # Read-only mode: just preview resume-bearing Inbox mail (nothing moves).
            raw = graph_client.fetch_inbox()
            items = [_simplify(m) for m in raw if _looks_like_resume(m)]
            rejected = len(raw) - len(items)
            with _LOCK:
                _STATE.update(items=items, count=len(items), rejected=rejected,
                              polled_at=_now(), error=None)
            log.info("graph poll: %d resume-bearing, %d filtered out", len(items), rejected)
    except Exception as exc:  # noqa: BLE001 — a poll failure must not crash the thread
        with _LOCK:
            _STATE.update(polled_at=_now(), error=str(exc)[:200])
        log.warning("graph poll failed: %s", exc)
    return dict(_STATE)


def snapshot() -> dict[str, Any]:
    with _LOCK:
        return dict(_STATE)


def live_queue() -> dict[str, Any]:
    """Build the Intake queue DIRECTLY from the Processing folder — fast and read-only.

    Dead simple: list whatever is sitting in the Processing folder and return it. No
    promotion, no LLM, no moves, and NO age filter — every message in Processing shows
    in the queue. (Aging out stale mail is the pipeline drain's job, not the display's.)
    So this can never hang or loop, and "mail in Processing" always means "mail in queue".
    Moving Landing → Processing is a separate background concern (:func:`tick`).
    """
    from app.services import graph_client

    polled = _now()
    if not graph_client.is_configured():
        return {"items": [], "count": 0, "rejected": 0, "polled_at": polled, "error": "not_configured"}
    try:
        raw = graph_client.fetch_folder("processing")
        # Collapse exact duplicate copies (same sender + subject + received time): the
        # mailbox can hold the same email twice (forwarded / copied), and the pipeline
        # dedupes candidates anyway — so the queue shows one row per distinct mail.
        items: list[dict[str, Any]] = []
        seen: set[tuple[Any, Any, Any]] = set()
        for m in raw:
            item = _simplify(m)
            key = (item.get("sender"), item.get("subject"), item.get("received_date"))
            if key in seen:
                continue
            seen.add(key)
            items.append(item)
        log.info(
            "graph live_queue: %d message(s) in Processing (%d after de-dup)",
            len(raw), len(items),
        )
        return {"items": items, "count": len(items), "rejected": 0, "polled_at": polled, "error": None}
    except Exception as exc:  # noqa: BLE001 — a read failure must never hang the UI
        log.warning("graph live_queue failed: %s", exc)
        return {"items": [], "count": 0, "rejected": 0, "polled_at": polled, "error": str(exc)[:200]}


_tick_lock = threading.Lock()


def trigger_tick_async() -> None:
    """Kick off a promotion tick (Landing → Processing) in the BACKGROUND, if one isn't
    already running. Fire-and-forget — returns immediately, so a manual Refresh never
    waits on the slow LLM classification. At most one tick runs at a time."""
    def _run() -> None:
        if not _tick_lock.acquire(blocking=False):
            return  # a tick is already in flight
        try:
            tick()
        finally:
            _tick_lock.release()

    threading.Thread(target=_run, daemon=True).start()


def start() -> Optional[BackgroundScheduler]:
    """Start the 60s Outlook poller. Idempotent; runs once immediately on start."""
    global _scheduler
    if not is_enabled():
        log.info("graph poller disabled (GRAPH_POLL_ENABLED=0)")
        return None
    if _scheduler is not None:
        return _scheduler
    from app.services.clock import business_tz

    _scheduler = BackgroundScheduler(timezone=business_tz())
    _scheduler.add_job(
        tick,
        trigger=IntervalTrigger(seconds=interval_seconds()),
        id=JOB_ID,
        replace_existing=True,
        max_instances=1,
        coalesce=True,
        next_run_time=datetime.now(timezone.utc),  # populate the queue at once
    )
    _scheduler.start()
    log.info("graph poller started: every %ds", interval_seconds())
    return _scheduler


def shutdown() -> None:
    global _scheduler
    if _scheduler is not None:
        _scheduler.shutdown(wait=False)
        _scheduler = None
