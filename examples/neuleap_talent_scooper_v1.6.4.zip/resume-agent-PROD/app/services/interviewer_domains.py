"""Interviewer email-domain allow-list + remember-me duration — Settings →
"Interviewer Access".

An external interviewer can only request an access code (see
app.services.interviewer_auth) if their email's domain is in this list AND
marked allowed — everything else is a default-deny. JSON-file-backed, same
runtime-file philosophy as source_tags/candidate_sections_config.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, List

from app.logging_config import get_logger

log = get_logger(__name__)

DEFAULT_REMEMBER_DAYS = 11


def _path() -> Path:
    return Path(os.environ.get("INTERVIEWER_ACCESS_FILE", "secrets/interviewer_access.json"))


def _load() -> Dict[str, Any]:
    try:
        raw = json.loads(_path().read_text(encoding="utf-8"))
        if isinstance(raw, dict) and isinstance(raw.get("domains"), list):
            return {
                "domains": raw["domains"],
                "remember_days": int(raw.get("remember_days") or DEFAULT_REMEMBER_DAYS),
            }
    except (OSError, ValueError):
        pass
    return {"domains": [], "remember_days": DEFAULT_REMEMBER_DAYS}


def _save(data: Dict[str, Any]) -> None:
    path = _path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    except OSError as exc:  # noqa: BLE001 — a write failure must not break the request
        log.warning("interviewer_domains: could not write %s: %s", path, exc)


def get_config() -> Dict[str, Any]:
    """``{"domains": [{"domain": "neuleap.ai", "allowed": true}, ...], "remember_days": 11}``."""
    return _load()


def save_config(domains: List[Dict[str, Any]], remember_days: int) -> Dict[str, Any]:
    # De-dupe by domain (case-insensitive), last write wins; blank rows dropped.
    seen: Dict[str, bool] = {}
    for d in domains:
        name = str(d.get("domain", "")).strip().lower().lstrip("@")
        if name:
            seen[name] = bool(d.get("allowed", True))
    data = {
        "domains": [{"domain": k, "allowed": v} for k, v in seen.items()],
        "remember_days": max(1, int(remember_days)),
    }
    _save(data)
    log.info(
        "interviewer_domains: saved %d domain(s), remember_days=%d",
        len(data["domains"]), data["remember_days"],
    )
    return data


def remember_days() -> int:
    return _load()["remember_days"]


def is_email_allowed(email: str) -> bool:
    """True iff the email's domain (case-insensitive, after the last '@') is
    registered here with allowed=True."""
    email = (email or "").strip().lower()
    if "@" not in email:
        return False
    domain = email.rsplit("@", 1)[1]
    for d in _load()["domains"]:
        if d.get("domain") == domain:
            return bool(d.get("allowed"))
    return False
