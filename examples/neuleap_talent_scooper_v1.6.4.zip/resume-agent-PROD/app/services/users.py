"""User store for SPA login accounts (``app_users`` table).

Replaces the hardcoded config credentials with a real, Admin/System-Admin
-manageable account table while keeping the same role model:

* ``admin``     — full access, including manual Next Best Action overrides.
* ``recruiter`` — Recruitment Manager: everything else (including
  apply/bulk-apply of the system-predicted NBA), but the manual NBA override
  is Admin-only (enforced server-side via ``require_admin``), and no Settings
  access.
* ``sysadmin``  — System Admin: Settings access (pipeline/notifications/
  scoring/columns config + User Management), same as Admin there — but no
  NBA-override capability, which stays Admin-only regardless.

Passwords are stored as a self-describing PBKDF2-HMAC-SHA256 string
(``pbkdf2_sha256$<iterations>$<salt_hex>$<hash_hex>``) using only the stdlib —
no bcrypt/passlib dependency. Verification is constant-time.

The Admin + Recruiter + System Admin defaults are seeded from
:class:`app.config.Settings` (:func:`seed_default_users`, called by
``init_db``) so a fresh database always has working logins; an Admin or
System Admin can add more from Settings → User Management.
"""
from __future__ import annotations

import hashlib
import hmac
import logging
import os
import secrets
from typing import Any, Literal, Optional

import psycopg2
import psycopg2.errors
import psycopg2.extras

from app.config import settings
from app.db import get_conn

logger = logging.getLogger(__name__)

Role = Literal["admin", "recruiter", "sysadmin"]

_PBKDF2_ITERATIONS = 240_000
_PBKDF2_ALGO = "pbkdf2_sha256"


# ── Password hashing (stdlib PBKDF2, constant-time verify) ───────────────────
def hash_password(password: str) -> str:
    salt = os.urandom(16)
    digest = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), salt, _PBKDF2_ITERATIONS
    )
    return f"{_PBKDF2_ALGO}${_PBKDF2_ITERATIONS}${salt.hex()}${digest.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        algo, iters_s, salt_hex, hash_hex = stored.split("$")
        if algo != _PBKDF2_ALGO:
            return False
        digest = hashlib.pbkdf2_hmac(
            "sha256", password.encode("utf-8"), bytes.fromhex(salt_hex), int(iters_s)
        )
    except (ValueError, TypeError):
        return False
    return hmac.compare_digest(digest.hex(), hash_hex)


# ── Name derivation — same rule the token/UI uses everywhere ─────────────────
def derive_name(email: str) -> str:
    name = email.split("@")[0].replace(".", " ").replace("_", " ").replace("-", " ").title()
    return name or "Recruiter"


def _public(row: dict[str, Any]) -> dict[str, Any]:
    """A user row without the password hash — safe to return over the API."""
    return {
        "id": row["id"],
        "email": row["email"],
        "name": row["name"],
        "role": row["role"],
        "is_active": row["is_active"],
        "must_change_password": bool(row.get("must_change_password")),
        "created_at": row["created_at"].isoformat() if row.get("created_at") else None,
    }


# Unambiguous alphabet (no 0/O, 1/l/I) for generated passwords — read over a
# call or typed from a chat message without transcription errors.
_PW_ALPHABET = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789"


def generate_password() -> str:
    """A strong, human-relayable random password (e.g. "mK4t-Xw92-pQ7n") — the
    recommended value an Admin hands a user on reset; the user is then forced
    to change it on their next login."""
    group = lambda n: "".join(secrets.choice(_PW_ALPHABET) for _ in range(n))  # noqa: E731
    return f"{group(4)}-{group(4)}-{group(4)}"


# ── Authentication ───────────────────────────────────────────────────────────
def authenticate(email: str, password: str) -> Optional[dict[str, Any]]:
    """Return the matching active user (email/name/role) or ``None``.

    The password hash is compared for EVERY row we find so a missing account and
    a wrong password take the same code path (no user-enumeration timing leak).
    """
    with get_conn() as conn:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(
                "SELECT * FROM app_users "
                "WHERE lower(btrim(email)) = lower(btrim(%s)) AND is_active",
                (email,),
            )
            row = cur.fetchone()
    if row is None:
        # Run a dummy verify so timing doesn't reveal whether the email exists.
        verify_password(password, hash_password("_"))
        return None
    if not verify_password(password, row["password_hash"]):
        return None
    return {
        "email": row["email"],
        "name": row["name"],
        "role": row["role"],
        "must_change_password": bool(row.get("must_change_password")),
    }


def get_user_by_email(email: str) -> Optional[dict[str, Any]]:
    """Look up a registered app_user by email, no password involved — used to
    check whether an already-verified email (e.g. an external interviewer's
    session, app.services.interviewer_auth) also happens to belong to a real
    Admin/Recruiter/Sysadmin account, for role-gated extras on surfaces that
    otherwise have no login of their own."""
    with get_conn() as conn:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(
                "SELECT email, name, role, must_change_password FROM app_users "
                "WHERE lower(btrim(email)) = lower(btrim(%s)) AND is_active",
                (email,),
            )
            row = cur.fetchone()
    return dict(row) if row else None


def change_password(email: str, current_password: str, new_password: str) -> bool:
    """Self-service password change — verifies the CURRENT password first, then
    stores the new hash and clears the forced-change flag. Returns False when
    the current password doesn't match (or the account is missing/inactive)."""
    if authenticate(email, current_password) is None:
        return False
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE app_users SET password_hash = %s, must_change_password = FALSE, "
                "updated_at = CURRENT_TIMESTAMP "
                "WHERE lower(btrim(email)) = lower(btrim(%s)) AND is_active",
                (hash_password(new_password), email),
            )
            changed = cur.rowcount > 0
    if changed:
        logger.info("users: password changed by %s", email)
    return changed


def set_password(email: str, new_password: str) -> bool:
    """Set a user's password WITHOUT the current one — for the email-verified
    forgot-password / set-initial-password flows (the emailed token is the proof
    of identity, verified by the caller). Clears the forced-change flag. Returns
    False when no active account has that email."""
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE app_users SET password_hash = %s, must_change_password = FALSE, "
                "updated_at = CURRENT_TIMESTAMP "
                "WHERE lower(btrim(email)) = lower(btrim(%s)) AND is_active",
                (hash_password(new_password), email),
            )
            changed = cur.rowcount > 0
    if changed:
        logger.info("users: password set via token for %s", email)
    return changed


def admin_reset_password(user_id: int) -> Optional[dict[str, str]]:
    """Admin override: reset a user's password to a freshly generated value and
    force a change on their next login. Returns {email, password} — the ONLY
    time the plain value exists outside the hash — or None if no such user."""
    new_password = generate_password()
    with get_conn() as conn:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(
                "UPDATE app_users SET password_hash = %s, must_change_password = TRUE, "
                "updated_at = CURRENT_TIMESTAMP WHERE id = %s AND is_active "
                "RETURNING email",
                (hash_password(new_password), user_id),
            )
            row = cur.fetchone()
    if not row:
        return None
    logger.info("users: password reset by admin for %s", row["email"])
    return {"email": row["email"], "password": new_password}


# ── CRUD (Admin-managed) ─────────────────────────────────────────────────────
def list_users() -> list[dict[str, Any]]:
    with get_conn() as conn:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute("SELECT * FROM app_users ORDER BY created_at ASC, id ASC")
            return [_public(dict(r)) for r in cur.fetchall()]


class DuplicateEmailError(ValueError):
    """Raised when creating a user whose email already exists (case-insensitive)."""


def create_user(email: str, password: str, role: Role, name: Optional[str] = None) -> dict[str, Any]:
    email = email.strip()
    display = (name or "").strip() or derive_name(email)
    try:
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                # New accounts always start with a forced password change — the
                # admin-typed initial password is a handover credential, not the
                # user's own secret.
                cur.execute(
                    "INSERT INTO app_users (email, name, role, password_hash, must_change_password) "
                    "VALUES (%s, %s, %s, %s, TRUE) RETURNING *",
                    (email, display, role, hash_password(password)),
                )
                return _public(dict(cur.fetchone()))
    except psycopg2.errors.UniqueViolation as exc:
        raise DuplicateEmailError(email) from exc


def delete_user(user_id: int) -> bool:
    """Delete a user by id. Returns False if no such user existed."""
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("DELETE FROM app_users WHERE id = %s", (user_id,))
            return cur.rowcount > 0


def count_admins(exclude_id: Optional[int] = None) -> int:
    """Number of active admin accounts (optionally excluding one id) — used to
    stop the last admin from being removed and locking everyone out."""
    query = "SELECT COUNT(*) FROM app_users WHERE role = 'admin' AND is_active"
    params: tuple = ()
    if exclude_id is not None:
        query += " AND id <> %s"
        params = (exclude_id,)
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(query, params)
            return cur.fetchone()[0]


# ── Seeding ──────────────────────────────────────────────────────────────────
def seed_default_users() -> None:
    """Seed the Admin + Recruiter + System Admin defaults from config if they
    don't exist yet.

    Idempotent: ``ON CONFLICT DO NOTHING`` on the case-insensitive email index,
    so it never overwrites a password an Admin/System Admin later changed.
    Safe to run on every startup.
    """
    defaults = [
        (settings.auth_email, settings.auth_password, "admin"),
        (settings.recruiter_email, settings.recruiter_password, "recruiter"),
        (settings.sysadmin_email, settings.sysadmin_password, "sysadmin"),
    ]
    with get_conn() as conn:
        with conn.cursor() as cur:
            for email, password, role in defaults:
                # must_change_password TRUE: these passwords ship in source
                # control, so a fresh install forces each default account to
                # rotate its credential on first login. Existing rows are
                # never touched (ON CONFLICT DO NOTHING).
                cur.execute(
                    "INSERT INTO app_users (email, name, role, password_hash, must_change_password) "
                    "VALUES (%s, %s, %s, %s, TRUE) "
                    "ON CONFLICT (lower(btrim(email))) DO NOTHING",
                    (email, derive_name(email), role, hash_password(password)),
                )
