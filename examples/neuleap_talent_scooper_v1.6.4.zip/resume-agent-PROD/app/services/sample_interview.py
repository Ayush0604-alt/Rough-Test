"""A persistent, fully-mocked demo candidate + round + resume file — lets an
Admin/System Admin click ONE stable interview link (Settings → Interviewer
Access) to exercise the whole interviewer experience (resume viewer, Analysis
Report, ATS/NLRS breakdowns, question generation, feedback + verdict) at any
time, without touching a real candidate's data.

Self-healing: if the underlying candidate_master/rounds rows or the resume
file are ever gone (e.g. after a QA "wipe database"), the next fetch just
recreates them from scratch. The URL only changes in that rare case — day to
day it's the exact same stable link, safe to bookmark.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from app.config import settings
from app.db import get_conn
from app.logging_config import get_logger
from app.services import interviewer_link
from app.services.s3 import s3

log = get_logger(__name__)

SAMPLE_CANDIDATE_ID = "SAMPLE-DEMO"
SAMPLE_ROUND_NAME = "Round 1"  # back-compat default — see SAMPLE_ROUND_NAMES below
# One scenario per verdict-picker case (app.api.interviewer.get_verdict_options):
# Screening keeps the legacy Pass/Fail picker; Round 1/Round 2 exercise the
# round-aware "Move to X / Reject (+ Admin bypass)" options; Final exercises
# the Hire/Reject picker. Each gets its OWN persistent round row + stable
# link, so all four can be reset/re-tested independently.
SAMPLE_ROUND_NAMES = ["Screening", "Round 1", "Round 2", "Final"]
# The source tag stamped on the mock candidate — filtered out of source-tag
# pickers app-wide (Dashboard, Screening, Interviewer Timeslot Pools, …) per
# app.services.sample_data_visibility, since it isn't a real campaign.
SAMPLE_SOURCE_LABEL = "Sample Data"
_RESUME_KEY = f"{settings.s3_resume_prefix}/sample/{SAMPLE_CANDIDATE_ID}/sample-resume.pdf"

_ANALYSIS_REPORT = {
    "experience_level": "Experienced (Lateral) — over 4 years across two data engineering roles, most recently as Senior Data Engineer.",
    "graduation_and_window": "Bachelor's completed in 2020; roughly 5-6 years to consider since graduation.",
    "work_start_and_gap": "Started at CloudWorks Technologies immediately after graduation in 2020 — no gap.",
    "company_projects": "Led a Snowflake migration cutting warehouse costs 40%, and built a Kafka/Spark streaming pipeline handling 2M events/day.",
    "professional_certifications": "Databricks Certified Data Engineer Associate (2023).",
}


def _config_path() -> Path:
    return Path(os.environ.get("SAMPLE_INTERVIEW_FILE", "secrets/sample_interview.json"))


def _load_config() -> dict[str, Any] | None:
    try:
        return json.loads(_config_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def _save_config(cfg: dict[str, Any]) -> None:
    path = _config_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    except OSError as exc:  # noqa: BLE001
        log.warning("sample_interview: could not write %s: %s", path, exc)


def _build_mock_pdf() -> bytes:
    """A minimal, hand-built (but byte-correct) one-page PDF — no PDF-writing
    library dependency needed for a small placeholder document."""
    lines = [
        "Aditi Sharma",
        "Senior Data Engineer  |  Bengaluru, India",
        "",
        "EXPERIENCE",
        "Senior Data Engineer, NimbusData Analytics (2022 - Present)",
        "  - Led migration of the on-prem warehouse to Snowflake, cutting query costs 40%.",
        "  - Built a real-time streaming ETL pipeline processing 2M events/day (Kafka, Spark).",
        "Data Engineer, CloudWorks Technologies (2020 - 2022)",
        "  - Built and maintained Airflow-orchestrated batch pipelines across AWS Glue/S3.",
        "",
        "EDUCATION",
        "B.E. Computer Science, R.V. College of Engineering (2020), CGPA 8.4",
        "",
        "CERTIFICATIONS",
        "Databricks Certified Data Engineer Associate (2023)",
        "",
        "SKILLS",
        "Python, PySpark, Airflow, SQL, AWS Glue, Snowflake, Kafka",
        "",
        "--- MOCK resume generated for Settings > Interviewer Access sample testing. ---",
    ]

    def esc(t: str) -> str:
        return t.replace("\\", r"\\").replace("(", r"\(").replace(")", r"\)")

    body_lines = [f"BT /F1 16 Tf 56 770 Td ({esc(lines[0])}) Tj ET"]
    y = 748
    for line in lines[1:]:
        body_lines.append(f"BT /F1 10 Tf 56 {y} Td ({esc(line)}) Tj ET")
        y -= 16
    content = "\n".join(body_lines).encode("latin-1", errors="replace")

    objects: list[bytes] = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] "
        b"/Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
        f"<< /Length {len(content)} >>\nstream\n".encode() + content + b"\nendstream",
    ]

    out = bytearray(b"%PDF-1.4\n")
    offsets: list[int] = []
    for i, obj in enumerate(objects, start=1):
        offsets.append(len(out))
        out += f"{i} 0 obj\n".encode() + obj + b"\nendobj\n"
    xref_offset = len(out)
    out += f"xref\n0 {len(objects) + 1}\n".encode()
    out += b"0000000000 65535 f \n"
    for off in offsets:
        out += f"{off:010d} 00000 n \n".encode()
    out += (
        f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\n"
        f"startxref\n{xref_offset}\n%%EOF"
    ).encode()
    return bytes(out)


def _candidate_exists() -> bool:
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT 1 FROM candidate_master WHERE candidate_id = %s", (SAMPLE_CANDIDATE_ID,))
            return cur.fetchone() is not None


def _create_sample_data() -> dict[str, int]:
    """Inserts the mock candidate + one round row per SAMPLE_ROUND_NAMES
    scenario + the resume file. Returns {round_name: round_id}. The FIRST
    scenario (Screening) is left as the candidate's initially-active round."""
    s3().put_bytes(_RESUME_KEY, _build_mock_pdf())

    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO candidate_master (
                    candidate_id, s3_file_path, name, stream, status, source,
                    clg, highest_coursecompleted, education_status, passoutyr, cgpa,
                    domain, yearofexp, fresher_or_lateral, currentcompany, currentlocation,
                    job_roles, projects, primary_skills, certificates,
                    atsscore, role_context, analysis_report,
                    score_breakdown, score_penalties, certification_bonus, screened
                ) VALUES (
                    %s, %s, %s, %s, 'Active', %s,
                    %s, %s, %s, %s, %s,
                    %s, %s, %s, %s, %s,
                    %s, %s, %s, %s,
                    %s, %s, %s,
                    %s, %s, %s, TRUE
                )
                ON CONFLICT (candidate_id) DO UPDATE SET
                    s3_file_path = EXCLUDED.s3_file_path,
                    updated_at = CURRENT_TIMESTAMP
                """,
                (
                    SAMPLE_CANDIDATE_ID, _RESUME_KEY, "Aditi Sharma", "Data Eng", SAMPLE_SOURCE_LABEL,
                    "R.V. College of Engineering", "Bachelor", "completed", 2020, 8.4,
                    "Data Engineer", 4.5, "Lateral", "NimbusData Analytics", "Bengaluru, India",
                    json.dumps([
                        {"role": "Senior Data Engineer", "company": "NimbusData Analytics", "months": 30},
                        {"role": "Data Engineer", "company": "CloudWorks Technologies", "months": 24},
                    ]),
                    json.dumps([
                        "Led migration of a legacy on-prem warehouse to Snowflake, cutting query costs 40%.",
                        "Built a real-time streaming ETL pipeline processing 2M events/day with Kafka and Spark Structured Streaming.",
                    ]),
                    json.dumps(["Python", "PySpark", "Airflow", "SQL", "AWS Glue", "Snowflake", "Kafka"]),
                    json.dumps([{"name": "Databricks Certified Data Engineer Associate", "issuer": "Databricks", "year": 2023}]),
                    78.5,
                    "Data engineer with 4+ years building large-scale batch and streaming pipelines, most recently "
                    "leading a Snowflake migration that cut warehouse costs by 40%.",
                    json.dumps(_ANALYSIS_REPORT),
                    json.dumps([
                        {"component": "LLM track fit", "weight": 0.4, "subscore": 82.0, "weighted": 32.8},
                        {"component": "Skill / keyword match", "weight": 0.25, "subscore": 75.0, "weighted": 18.75},
                        {"component": "Experience match", "weight": 0.2, "subscore": 80.0, "weighted": 16.0},
                        {"component": "Education match", "weight": 0.1, "subscore": 85.0, "weighted": 8.5},
                        {"component": "Resume format / completeness", "weight": 0.05, "subscore": 90.0, "weighted": 4.5},
                    ]),
                    json.dumps([{"points": 3, "reason": "A 4-month career gap between roles isn't explained"}]),
                    json.dumps({"points": 8.0, "cap": 10.0, "certs": ["Databricks Certified Data Engineer Associate"]}),
                ),
            )
            round_ids: dict[str, int] = {}
            for idx, round_name in enumerate(SAMPLE_ROUND_NAMES):
                # Staggered mock dates (Screening today, each later round a few
                # days out) so the Round history reads like a real plan, not
                # four rounds all "scheduled" the same instant.
                cur.execute(
                    """
                    INSERT INTO rounds (candidate_id, round_name, domain, interviewer, scheduled_on)
                    VALUES (%s, %s, %s, %s, CURRENT_TIMESTAMP + (%s || ' days')::interval)
                    RETURNING round_id
                    """,
                    (SAMPLE_CANDIDATE_ID, round_name, "Data Engineer", "Sample Interviewer", idx * 3),
                )
                round_ids[round_name] = cur.fetchone()[0]
            active_name = SAMPLE_ROUND_NAMES[0]
            cur.execute(
                "UPDATE candidate_master SET roundid = %s, roundname = %s WHERE candidate_id = %s",
                (round_ids[active_name], active_name, SAMPLE_CANDIDATE_ID),
            )
    log.info("sample_interview: created sample candidate/rounds %s", round_ids)
    return round_ids


def get_sample_link() -> dict[str, Any]:
    """Back-compat single-link accessor — returns the Round 1 scenario (the
    original sample flow's stage). Prefer get_sample_links() for all four."""
    return get_sample_links()[SAMPLE_ROUND_NAME]


def get_sample_links() -> dict[str, dict[str, Any]]:
    """Ensures the mock candidate/rounds/resume exist (self-healing after e.g.
    a QA database wipe) and returns one STABLE {url_path, candidate_id,
    round_id} per scenario in SAMPLE_ROUND_NAMES — the same 4 URLs every time,
    safe to bookmark/click "anytime"."""
    cfg = _load_config()
    if cfg and cfg.get("scenarios") and set(cfg["scenarios"]) == set(SAMPLE_ROUND_NAMES) and _candidate_exists():
        return cfg["scenarios"]

    round_ids = _create_sample_data()
    scenarios = {
        round_name: {
            "url_path": f"/interview/{interviewer_link.generate_link_token(SAMPLE_CANDIDATE_ID, round_id)}",
            "candidate_id": SAMPLE_CANDIDATE_ID,
            "round_id": round_id,
        }
        for round_name, round_id in round_ids.items()
    }
    _save_config({"scenarios": scenarios})
    return scenarios


def reset_sample_round(round_name: str = SAMPLE_ROUND_NAME) -> dict[str, Any]:
    """Clears verdict/feedback on ONE scenario's round, deletes any extra
    round(s) a Pass verdict may have auto-created beyond the fixed scenario
    set, and makes this scenario the candidate's active round again (so
    submitting feedback on it drives the real status-sync/round-advance logic,
    not just a read-only view) — safe to call anytime to re-test from a clean
    slate.

    The OTHER scenario rounds are re-dressed around the chosen one so the
    Round history reads like a real candidate's progression, not four
    identical Pending rows: every EARLIER round shows as cleared (Pass, a
    plausible score, a past date), the chosen round is "today", and each
    later round sits a few days in the future."""
    scenarios = get_sample_links()  # self-heals first
    if round_name not in scenarios:
        raise ValueError(f"unknown sample scenario {round_name!r} — expected one of {SAMPLE_ROUND_NAMES}")
    target = scenarios[round_name]
    round_id = target["round_id"]
    keep_ids = tuple(s["round_id"] for s in scenarios.values())
    active_idx = SAMPLE_ROUND_NAMES.index(round_name)
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "DELETE FROM rounds WHERE candidate_id = %s AND round_id NOT IN %s",
                (SAMPLE_CANDIDATE_ID, keep_ids),
            )
            for idx, name in enumerate(SAMPLE_ROUND_NAMES):
                rid = scenarios[name]["round_id"]
                offset_days = (idx - active_idx) * 3
                if idx < active_idx:
                    cur.execute(
                        "UPDATE rounds SET outcome = 'Pass', feedback = %s, score = %s, "
                        "scheduled_on = CURRENT_TIMESTAMP + (%s || ' days')::interval, "
                        "candidate_accepted_slot = TRUE WHERE round_id = %s",
                        (
                            f"Sample data — {name} cleared earlier in this mock flow.",
                            round(7.5 + idx * 0.5, 1),
                            offset_days,
                            rid,
                        ),
                    )
                else:
                    cur.execute(
                        "UPDATE rounds SET outcome = NULL, feedback = NULL, score = NULL, "
                        "scheduled_on = CURRENT_TIMESTAMP + (%s || ' days')::interval, "
                        "candidate_accepted_slot = NULL WHERE round_id = %s",
                        (offset_days, rid),
                    )
            cur.execute(
                "UPDATE candidate_master SET status = 'Active', roundid = %s, roundname = %s, "
                "round_status = NULL, next_action_override = NULL WHERE candidate_id = %s",
                (round_id, round_name, SAMPLE_CANDIDATE_ID),
            )
            # Also clear any slot-invite lifecycle rows tied to a now-deleted or
            # reset round, so the native scheduling flow can be re-tested from
            # a clean slate too (mirrors the verdict/feedback reset above).
            cur.execute(
                "DELETE FROM round_slot_invites WHERE candidate_id = %s", (SAMPLE_CANDIDATE_ID,)
            )
    log.info("sample_interview: reset sample scenario %r (round_id=%s)", round_name, round_id)
    return target


def reset_all_sample_scenarios() -> dict[str, dict[str, Any]]:
    """Resets every scenario back to a clean slate, leaving the FIRST
    (Screening) as the active round afterward — a sane default."""
    scenarios = get_sample_links()
    for name in scenarios:
        reset_sample_round(name)
    reset_sample_round(SAMPLE_ROUND_NAMES[0])
    return get_sample_links()
