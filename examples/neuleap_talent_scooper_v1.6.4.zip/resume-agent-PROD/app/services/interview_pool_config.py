"""Default allocation rules for new interviewer timeslot pools — Settings →
Mailbox → Interviewer Timeslot Pools. Every pool (app.services.interview_pools)
copies these as its starting rules at creation time and can then override them
per-pool; this module only holds the DEFAULTS a new pool is pre-filled with.

``days_allowed`` values: "full" (10:00-18:00), "full_extended" (08:00-21:00),
"early_morning" (08:00-10:00), "first_half" (10:00-14:00), "second_half"
(14:00-18:00), "late_evening" (18:00-21:00), or "none". The 10–18 business
hours are shared with app.services.graph_calendar (BUSINESS_START_HOUR/
END_HOUR); the 08:00 / 21:00 extended bounds live in
app.services.interview_pools (_EARLY_START_HOUR / _LATE_END_HOUR).
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict

from app.logging_config import get_logger
from app.services.interview_plan import FLOW as _ROUND_FLOW

log = get_logger(__name__)

ALLOWED_DAY_VALUES = (
    "full", "full_extended", "early_morning",
    "first_half", "second_half", "late_evening", "none",
)

DEFAULT_DAYS_ALLOWED: Dict[str, str] = {
    "mon": "none",
    "tue": "second_half",
    "wed": "second_half",
    "thu": "second_half",
    "fri": "first_half",
    "sat": "none",
    "sun": "none",
}

# % of candidates who DON'T advance out of each round — e.g. Screening: 40 means
# 40% are filtered out at Screening, so only 60% of the Screening figure carries
# forward as Round 1's target. All 0 (the default) reproduces the old behaviour:
# every round in a pool is sized against the same top-of-funnel estimate.
_DEFAULT_CUT_PCT = {
    "Screening": 50.0,
    "Round 1": 30.0,
    "Round 2": 15.0,
    "Round 3": 0.0,
    "Final": 55.0,
}
DEFAULT_FUNNEL_FILTER_PCT: Dict[str, float] = {r: _DEFAULT_CUT_PCT.get(r, 0.0) for r in _ROUND_FLOW}

# Per-round OVERRIDES of the allocation rules. Empty by default (every round
# uses the global rules above); a round present here overrides only the fields
# it names — resolve_for_round() overlays it on the base. Keyed by round name
# (FLOW): Screening / Round 1 / Round 2 / Round 3 / Final.
_OVERRIDE_NUM_FIELDS = ("slot_minutes", "gap_minutes", "max_day_fraction")

# Default per-round overrides. The Final round is a scarce, senior-time round, so
# it defaults to fewer days and afternoons only — Tue/Wed/Thu PM — and locks at
# most 20% of the day (vs. 25% globally). Recruiters can still override per pool.
DEFAULT_ROUND_OVERRIDES: Dict[str, Any] = {
    "Final": {
        "max_day_fraction": 0.20,
        "days_allowed": {
            "mon": "none",
            "tue": "second_half",
            "wed": "second_half",
            "thu": "second_half",
            "fri": "none",
            "sat": "none",
            "sun": "none",
        },
    },
}

DEFAULTS: Dict[str, Any] = {
    "slot_minutes": 30,
    "gap_minutes": 15,
    "max_day_fraction": 0.25,
    "days_allowed": dict(DEFAULT_DAYS_ALLOWED),
    "funnel_filter_pct": dict(DEFAULT_FUNNEL_FILTER_PCT),
    "round_overrides": DEFAULT_ROUND_OVERRIDES,
}


def _path() -> Path:
    return Path(os.environ.get("INTERVIEW_POOL_CONFIG_FILE", "secrets/interview_pool_defaults.json"))


def get() -> Dict[str, Any]:
    out = {
        **DEFAULTS,
        "days_allowed": dict(DEFAULT_DAYS_ALLOWED),
        "funnel_filter_pct": dict(DEFAULT_FUNNEL_FILTER_PCT),
        # Fresh (deep-ish) copy of the shipped per-round overrides — a saved file
        # with its own round_overrides replaces this below.
        "round_overrides": _clean_round_overrides(DEFAULT_ROUND_OVERRIDES),
    }
    try:
        raw = json.loads(_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return out
    if isinstance(raw, dict):
        for k in ("slot_minutes", "gap_minutes", "max_day_fraction"):
            if k in raw:
                out[k] = raw[k]
        if isinstance(raw.get("days_allowed"), dict):
            out["days_allowed"].update({
                k: v for k, v in raw["days_allowed"].items()
                if k in DEFAULT_DAYS_ALLOWED and v in ALLOWED_DAY_VALUES
            })
        if isinstance(raw.get("funnel_filter_pct"), dict):
            out["funnel_filter_pct"].update({
                k: v for k, v in raw["funnel_filter_pct"].items()
                if k in DEFAULT_FUNNEL_FILTER_PCT and isinstance(v, (int, float)) and not isinstance(v, bool) and 0 <= v <= 100
            })
        if isinstance(raw.get("round_overrides"), dict):
            out["round_overrides"] = _clean_round_overrides(raw["round_overrides"])
    return out


def _clean_round_overrides(raw: Dict[str, Any]) -> Dict[str, Any]:
    """Keep only known rounds and known, valid override fields."""
    cleaned: Dict[str, Any] = {}
    for rnd, ov in (raw or {}).items():
        if rnd not in _ROUND_FLOW or not isinstance(ov, dict):
            continue
        entry: Dict[str, Any] = {}
        if "slot_minutes" in ov and isinstance(ov["slot_minutes"], (int, float)) and not isinstance(ov["slot_minutes"], bool) and 10 <= ov["slot_minutes"] <= 240:
            entry["slot_minutes"] = int(ov["slot_minutes"])
        if "gap_minutes" in ov and isinstance(ov["gap_minutes"], (int, float)) and not isinstance(ov["gap_minutes"], bool) and 0 <= ov["gap_minutes"] <= 240:
            entry["gap_minutes"] = int(ov["gap_minutes"])
        if "max_day_fraction" in ov and isinstance(ov["max_day_fraction"], (int, float)) and not isinstance(ov["max_day_fraction"], bool) and 0.05 <= ov["max_day_fraction"] <= 1.0:
            entry["max_day_fraction"] = float(ov["max_day_fraction"])
        da = ov.get("days_allowed")
        if isinstance(da, dict):
            clean_da = {k: v for k, v in da.items() if k in DEFAULT_DAYS_ALLOWED and v in ALLOWED_DAY_VALUES}
            if clean_da:
                entry["days_allowed"] = clean_da
        if entry:
            cleaned[rnd] = entry
    return cleaned


def resolve_for_round(round_name: str, base: Dict[str, Any] | None = None) -> Dict[str, Any]:
    """Effective allocation rules for a round — the ``base`` config (a pool's
    own rules, or the global defaults) with this round's override overlaid on
    top, field by field. ``days_allowed`` overrides merge per weekday."""
    cfg = dict(base) if base else get()
    ov = get().get("round_overrides", {}).get(round_name) or {}
    for k in _OVERRIDE_NUM_FIELDS:
        if k in ov:
            cfg[k] = ov[k]
    if isinstance(ov.get("days_allowed"), dict):
        cfg["days_allowed"] = {**(cfg.get("days_allowed") or {}), **ov["days_allowed"]}
    return cfg


def save(payload: Dict[str, Any]) -> Dict[str, Any]:
    days_allowed = payload.get("days_allowed") or {}
    if not all(k in DEFAULT_DAYS_ALLOWED for k in days_allowed):
        raise ValueError(f"Unknown weekday key(s) in days_allowed — expected {list(DEFAULT_DAYS_ALLOWED)}.")
    if not all(v in ALLOWED_DAY_VALUES for v in days_allowed.values()):
        raise ValueError(f"days_allowed values must be one of {ALLOWED_DAY_VALUES}.")

    funnel_filter_pct = payload.get("funnel_filter_pct") or {}
    if not all(k in DEFAULT_FUNNEL_FILTER_PCT for k in funnel_filter_pct):
        raise ValueError(f"Unknown round key(s) in funnel_filter_pct — expected {list(DEFAULT_FUNNEL_FILTER_PCT)}.")
    for v in funnel_filter_pct.values():
        if not isinstance(v, (int, float)) or isinstance(v, bool) or not (0 <= v <= 100):
            raise ValueError("funnel_filter_pct values must be numbers between 0 and 100.")

    def _num(key: str, lo: float, hi: float) -> float:
        v = payload.get(key)
        if not isinstance(v, (int, float)) or isinstance(v, bool) or not (lo <= v <= hi):
            raise ValueError(f"{key} must be a number between {lo} and {hi}.")
        return v

    data = {
        "slot_minutes": int(_num("slot_minutes", 10, 240)),
        "gap_minutes": int(_num("gap_minutes", 0, 240)),
        "max_day_fraction": _num("max_day_fraction", 0.05, 1.0),
        "days_allowed": {**DEFAULT_DAYS_ALLOWED, **days_allowed},
        "funnel_filter_pct": {**DEFAULT_FUNNEL_FILTER_PCT, **funnel_filter_pct},
        "round_overrides": _clean_round_overrides(payload.get("round_overrides") or {}),
    }
    path = _path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        log.info("interview_pool_config: saved %s", path)
    except OSError as exc:  # noqa: BLE001
        log.warning("interview_pool_config: could not write %s: %s", path, exc)
    return get()


def revert_to_default() -> Dict[str, Any]:
    path = _path()
    try:
        if path.exists():
            path.unlink()
    except OSError as exc:  # noqa: BLE001
        log.warning("interview_pool_config: could not remove %s: %s", path, exc)
    return get()
