"""Reconciliation for interviewer timeslot pools — scans every open or booked
placeholder that has a real Graph calendar event and checks whether the
interviewer deleted or moved it directly on their own calendar (rather than
through the self-service portal, see app.services.interview_pools.remove_slot
/propose_new_time), and folds that change back into our pool records.

Runs two ways:
  * **Scheduled** — every hour, system-wide (see app.services.scheduler).
  * **On-demand, scoped** — the interviewer portal's "my slots" view and the
    recruiter's per-pool slot view each call run_once() filtered to just that
    interviewer/pool before reading, so a refresh reflects a direct-calendar
    deletion immediately instead of waiting up to an hour for the next
    scheduled sweep.
"""
from __future__ import annotations

from typing import Any, Optional

from app.db import get_conn
from app.logging_config import get_logger
from app.services import audit, graph_calendar

log = get_logger(__name__)


def _open_slots_with_events(
    *, interviewer_email: Optional[str] = None, pool_id: Optional[int] = None
) -> list[dict[str, Any]]:
    query = (
        "SELECT id, pool_id, interviewer_email, slot_start, slot_end, "
        "graph_event_id, status, booked_candidate_id "
        "FROM interview_pool_slots "
        "WHERE status IN ('open', 'booked') AND graph_event_id IS NOT NULL"
    )
    params: list[Any] = []
    if interviewer_email:
        query += " AND interviewer_email = %s"
        params.append(interviewer_email)
    if pool_id is not None:
        query += " AND pool_id = %s"
        params.append(pool_id)
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(query, params)
            cols = [d[0] for d in cur.description]
            return [dict(zip(cols, row)) for row in cur.fetchall()]


def run_once(*, interviewer_email: Optional[str] = None, pool_id: Optional[int] = None) -> dict[str, int]:
    removed = 0
    rescheduled = 0
    checked = 0
    for slot in _open_slots_with_events(interviewer_email=interviewer_email, pool_id=pool_id):
        checked += 1
        try:
            event = graph_calendar.get_event(slot["interviewer_email"], slot["graph_event_id"])
        except Exception as exc:  # noqa: BLE001 — one bad lookup shouldn't abort the scan
            log.warning("pool_sync_job: could not check event for slot %s: %s", slot["id"], exc)
            continue

        with get_conn() as conn:
            with conn.cursor() as cur:
                if event is None:
                    cur.execute(
                        "UPDATE interview_pool_slots SET status = 'removed_by_interviewer', "
                        "updated_at = CURRENT_TIMESTAMP WHERE id = %s",
                        (slot["id"],),
                    )
                    removed += 1
                    if slot["booked_candidate_id"]:
                        audit.write_event(
                            candidate_id=slot["booked_candidate_id"], layer="L4",
                            step="pool_slot_removed_by_interviewer", status="Info",
                            fail_reason=(
                                f"Interviewer {slot['interviewer_email']} deleted the booked "
                                f"interview slot directly on their calendar — needs re-scheduling."
                            ),
                        )
                elif (event["start"], event["end"]) != (slot["slot_start"], slot["slot_end"]):
                    cur.execute(
                        "UPDATE interview_pool_slots SET slot_start = %s, slot_end = %s, "
                        "updated_at = CURRENT_TIMESTAMP WHERE id = %s",
                        (event["start"], event["end"], slot["id"]),
                    )
                    rescheduled += 1
                    if slot["booked_candidate_id"]:
                        audit.write_event(
                            candidate_id=slot["booked_candidate_id"], layer="L4",
                            step="pool_slot_moved_by_interviewer", status="Info",
                            fail_reason=(
                                f"Interviewer {slot['interviewer_email']} moved the booked "
                                f"interview slot to {event['start']} on their calendar."
                            ),
                        )
    return {"checked": checked, "removed": removed, "rescheduled": rescheduled}
