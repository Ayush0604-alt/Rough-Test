"""Legacy ``.doc`` (and other office) → ``.docx`` conversion via headless LibreOffice.

Old binary Word ``.doc`` files are OLE2 compound documents that python-docx
cannot read. LibreOffice (``soffice``) converts them losslessly to ``.docx``,
which the rest of the pipeline already handles.

The ``soffice`` binary must be present in the runtime image
(``apt-get install libreoffice-writer`` — see the Dockerfile). When it is
absent, every function degrades gracefully (returns ``None``) so a missing
converter never crashes the pipeline; the caller surfaces the file for manual
review instead of silently dropping it.
"""
from __future__ import annotations

import logging
import shutil
import subprocess
import tempfile
import uuid
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# Common Windows install locations (dev machines); Linux/containers use PATH.
_WINDOWS_CANDIDATES = (
    r"C:\Program Files\LibreOffice\program\soffice.exe",
    r"C:\Program Files (x86)\LibreOffice\program\soffice.exe",
)


def soffice_bin() -> Optional[str]:
    """Locate the LibreOffice ``soffice`` executable, or ``None`` if absent."""
    for name in ("soffice", "libreoffice"):
        found = shutil.which(name)
        if found:
            return found
    for candidate in _WINDOWS_CANDIDATES:
        if Path(candidate).exists():
            return candidate
    return None


def libreoffice_available() -> bool:
    return soffice_bin() is not None


def convert_to_docx(src: str | Path, timeout: int = 120) -> Optional[Path]:
    """Convert ``src`` (e.g. a ``.doc``) to ``.docx`` in a fresh temp dir.

    Returns the path to the produced ``.docx`` (caller owns cleanup of its parent
    temp dir) or ``None`` if LibreOffice is unavailable or the conversion failed.
    A unique ``UserInstallation`` profile is used per call so concurrent
    conversions (L3 runs several workers in parallel) never clash on the profile
    lock.
    """
    src = Path(src)
    binary = soffice_bin()
    if binary is None:
        logger.warning("LibreOffice not found — cannot convert %s", src.name)
        return None
    if not src.exists():
        return None

    outdir = Path(tempfile.mkdtemp(prefix="neuleap_doc_"))
    profile = (outdir / f"loprofile_{uuid.uuid4().hex}").as_uri()
    try:
        proc = subprocess.run(
            [
                binary,
                "--headless",
                f"-env:UserInstallation={profile}",
                "--convert-to", "docx",
                "--outdir", str(outdir),
                str(src),
            ],
            check=False,
            capture_output=True,
            timeout=timeout,
        )
    except Exception as exc:  # noqa: BLE001 — subprocess/timeout failures
        logger.warning("LibreOffice conversion of %s failed: %s", src.name, exc)
        return None

    produced = outdir / f"{src.stem}.docx"
    if produced.exists():
        return produced
    logger.warning(
        "LibreOffice produced no output for %s (rc=%s): %s",
        src.name, proc.returncode, proc.stderr.decode("utf-8", "ignore")[:300],
    )
    return None


def convert_to_pdf(src: str | Path, timeout: int = 120) -> Optional[Path]:
    """Convert ``src`` (a .doc/.docx office file) to PDF in a fresh temp dir.

    Used to get a TRUE page count for Word documents (python-docx can't paginate).
    Returns the produced ``.pdf`` path (caller owns its parent temp dir) or ``None`` if
    LibreOffice is unavailable or the conversion failed — callers then skip the
    page-count rule rather than dropping the file.
    """
    src = Path(src)
    binary = soffice_bin()
    if binary is None:
        logger.warning("LibreOffice not found — cannot convert %s to PDF", src.name)
        return None
    if not src.exists():
        return None

    outdir = Path(tempfile.mkdtemp(prefix="neuleap_pdf_"))
    profile = (outdir / f"loprofile_{uuid.uuid4().hex}").as_uri()
    try:
        proc = subprocess.run(
            [
                binary,
                "--headless",
                f"-env:UserInstallation={profile}",
                "--convert-to", "pdf",
                "--outdir", str(outdir),
                str(src),
            ],
            check=False,
            capture_output=True,
            timeout=timeout,
        )
    except Exception as exc:  # noqa: BLE001 — subprocess/timeout failures
        logger.warning("LibreOffice PDF conversion of %s failed: %s", src.name, exc)
        return None

    produced = outdir / f"{src.stem}.pdf"
    if produced.exists():
        return produced
    logger.warning(
        "LibreOffice produced no PDF for %s (rc=%s): %s",
        src.name, proc.returncode, proc.stderr.decode("utf-8", "ignore")[:300],
    )
    return None
