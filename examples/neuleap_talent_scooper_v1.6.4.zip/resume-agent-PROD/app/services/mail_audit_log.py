"""Audit_Log — cumulative failure ledger + retry/exhaustion gate (Step 2).

Layer 1 must not retry a poison email forever. The ledger persists across runs
so cumulative ``fail_count`` per ``E_id`` survives. In local test mode there is
no database — the ledger is a JSON file under ``local/`` (NOT a cloud/DB write).

Schema per row (matches the plan's Audit_Log):
  run_id · E_id · candidate_id(null) · layer · step · fail_reason · status ·
  fail_count · created_at
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from app.logging_config import get_logger
from app.mail_config import Settings
from app.services import clock

log = get_logger(__name__)

EXHAUSTION_THRESHOLD = 3


def _now() -> str:
    return clock.now_iso()


class AuditLog:
    """A persistent append-only audit ledger keyed by ``E_id``."""

    def __init__(self, settings: Settings) -> None:
        settings.ensure_folders()
        self.path: Path = settings.local_dir / "_audit_log.json"
        self.records: list[dict[str, Any]] = self._load()

    def _load(self) -> list[dict[str, Any]]:
        if not self.path.exists():
            return []
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return []

    def save(self) -> None:
        self.path.write_text(json.dumps(self.records, indent=2), encoding="utf-8")

    def fail_count(self, e_id: str) -> int:
        """Cumulative number of prior ``Failed`` events for this E_id."""
        return sum(1 for r in self.records
                   if r["E_id"] == e_id and r["status"] == "Failed")

    def log(
        self, run_id: str, e_id: str, step: int, status: str,
        fail_reason: str = "", fail_count: int | None = None,
    ) -> dict[str, Any]:
        record = {
            "run_id": run_id,
            "E_id": e_id,
            "candidate_id": None,
            "layer": "L1",
            "step": step,
            "fail_reason": fail_reason,
            "status": status,
            "fail_count": self.fail_count(e_id) if fail_count is None else fail_count,
            "created_at": _now(),
        }
        self.records.append(record)
        return record

    def is_exhausted(self, e_id: str) -> bool:
        return self.fail_count(e_id) >= EXHAUSTION_THRESHOLD
