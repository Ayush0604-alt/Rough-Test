"""Whether the "Sample Data" source tag (the SAMPLE-DEMO fixture candidate —
see app.services.sample_interview) shows up in source-tag filters/pickers
across the app (Dashboard, Screening, Interviewer Timeslot Pools, …).

Two gates, both must pass:
  1. Non-production environment (app.services.system_reset.is_wipe_allowed())
     — the sample candidate is QA/demo tooling and must NEVER be visible in a
     real production deploy, regardless of this toggle.
  2. This toggle (default ON) — lets an Admin/System Admin hide it even
     within a QA environment, e.g. while giving a clean demo. Settings only
     ever shows this control in a non-production environment in the first
     place (there's nothing to toggle in prod, since gate 1 already wins).

Persisted as JSON in the bind-mounted ``secrets/`` dir, same runtime-file
philosophy as chatbot_widget_config.py.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict

from app.logging_config import get_logger
from app.services import system_reset

log = get_logger(__name__)

_DEFAULT_VISIBLE = True


def _path() -> Path:
    return Path(os.environ.get("SAMPLE_DATA_VISIBILITY_FILE", "secrets/sample_data_visibility.json"))


def _toggle() -> bool:
    try:
        raw = json.loads(_path().read_text(encoding="utf-8"))
        if isinstance(raw, dict) and "visible" in raw:
            return bool(raw["visible"])
    except (OSError, ValueError):
        pass
    return _DEFAULT_VISIBLE


def get() -> Dict[str, Any]:
    """``{"visible": bool, "toggle_shown": bool}`` — `visible` is the final,
    already-env-gated answer; `toggle_shown` tells the Settings page whether
    to render the control at all (only in non-production)."""
    non_prod = system_reset.is_wipe_allowed()
    return {"visible": non_prod and _toggle(), "toggle_shown": non_prod}


def save(visible: bool) -> Dict[str, Any]:
    if not system_reset.is_wipe_allowed():
        # Nothing to save in production — the toggle isn't even shown there.
        return get()
    path = _path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps({"visible": bool(visible)}, indent=2), encoding="utf-8")
        log.info("sample_data_visibility: saved %s", path)
    except OSError as exc:  # noqa: BLE001
        log.warning("sample_data_visibility: could not write %s: %s", path, exc)
    return get()


def is_visible() -> bool:
    return get()["visible"]
