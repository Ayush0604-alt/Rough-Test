"""No-op-safe Langfuse wrapper for LLM token tracing.

Telemetry must NEVER break the pipeline. Every public helper here degrades to a
silent no-op when:
  * ``settings.langfuse_enabled`` is false, or
  * the keys are missing, or
  * the ``langfuse`` package isn't installed / fails to import, or
  * any Langfuse call raises at runtime.

Usage (see app/extraction/engine.py)::

    with langfuse_client.generation(
        name="l3-extraction",
        session_id=candidate_id,           # one trace per resume/candidate
        model=deployment,
        input=user_payload,
        metadata={"e_id": e_id},
    ) as gen:
        response = client.chat.completions.create(...)
        gen.record(
            output=content,
            prompt_tokens=usage.prompt_tokens,
            completion_tokens=usage.completion_tokens,
            total_tokens=usage.total_tokens,
        )
"""
from __future__ import annotations

import logging
from contextlib import contextmanager
from functools import lru_cache
from typing import Any, Dict, Iterator, Optional

from app.config import settings

logger = logging.getLogger(__name__)


def _resolve_config() -> Dict[str, Any]:
    """Resolve the four Langfuse settings, preferring the local ``.env`` file.

    ``app.config`` loads ``.env`` WITHOUT ``override``, so a stale OS-level
    ``LANGFUSE_*`` variable would otherwise shadow the project's ``.env`` (a
    common foot-gun: old keys / wrong data region left in the user environment).
    Here the ``.env`` file wins when present; otherwise we fall back to ``settings``
    (which already reflects real env vars). In Docker there is no ``.env`` file, so
    the ``environment:`` block keeps taking precedence — behaviour unchanged there.
    """
    file_vals: Dict[str, str] = {}
    try:
        from dotenv import dotenv_values, find_dotenv

        path = find_dotenv(usecwd=True)
        if path:
            file_vals = {k: v for k, v in dotenv_values(path).items() if v is not None}
    except Exception as exc:  # noqa: BLE001 — never let config loading break tracing
        logger.debug("Langfuse .env read failed (using settings): %s", exc)

    def pick(env_key: str, fallback: Any) -> Any:
        return file_vals.get(env_key, fallback)

    enabled_raw = pick("LANGFUSE_ENABLED", str(settings.langfuse_enabled))
    enabled = str(enabled_raw).strip().lower() in {"1", "true", "yes", "on"}
    return {
        "enabled": enabled,
        "public_key": pick("LANGFUSE_PUBLIC_KEY", settings.langfuse_public_key),
        "secret_key": pick("LANGFUSE_SECRET_KEY", settings.langfuse_secret_key),
        "host": pick("LANGFUSE_HOST", settings.langfuse_host),
    }


@lru_cache(maxsize=1)
def _get_client() -> Optional[Any]:
    """Build (once) the Langfuse client, or return None when unavailable.

    Cached for the process. A None result means "tracing disabled" — every caller
    must handle it gracefully.
    """
    cfg = _resolve_config()
    if not cfg["enabled"]:
        return None
    if not (cfg["public_key"] and cfg["secret_key"]):
        logger.info("Langfuse enabled but keys missing — tracing disabled.")
        return None
    try:
        from langfuse import Langfuse  # imported lazily so the dep stays optional
    except Exception as exc:  # noqa: BLE001 — missing/broken package ⇒ silently disable
        logger.warning("Langfuse import failed — tracing disabled: %s", exc)
        return None
    try:
        return Langfuse(
            public_key=cfg["public_key"],
            secret_key=cfg["secret_key"],
            host=cfg["host"],
        )
    except Exception as exc:  # noqa: BLE001 — bad config ⇒ silently disable
        logger.warning("Langfuse init failed — tracing disabled: %s", exc)
        return None


class _Recorder:
    """Handle returned by :func:`generation`; ``record()`` ends the generation.

    When Langfuse is disabled ``_generation`` is None and every method is a no-op.
    """

    def __init__(self, generation: Optional[Any]) -> None:
        self._generation = generation

    def record(
        self,
        *,
        output: Any = None,
        prompt_tokens: Optional[int] = None,
        completion_tokens: Optional[int] = None,
        total_tokens: Optional[int] = None,
    ) -> None:
        if self._generation is None:
            return
        try:
            self._generation.end(
                output=output,
                usage={
                    "input": prompt_tokens,
                    "output": completion_tokens,
                    "total": total_tokens,
                },
            )
        except Exception as exc:  # noqa: BLE001 — telemetry must never raise
            logger.debug("Langfuse record failed (ignored): %s", exc)


@contextmanager
def generation(
    *,
    name: str,
    session_id: Optional[str] = None,
    model: Optional[str] = None,
    input: Any = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> Iterator[_Recorder]:
    """Open a Langfuse trace + generation for one LLM call.

    Yields a :class:`_Recorder`; call ``.record(...)`` after the LLM responds to
    attach the output and token usage. Always yields a usable recorder — a no-op
    one when tracing is disabled — so callers need no conditional branches.
    """
    client = _get_client()
    if client is None:
        yield _Recorder(None)
        return

    gen = None
    try:
        trace = client.trace(name=name, session_id=session_id, metadata=metadata)
        gen = trace.generation(name=name, model=model, input=input, metadata=metadata)
    except Exception as exc:  # noqa: BLE001 — telemetry must never break extraction
        logger.debug("Langfuse generation start failed (ignored): %s", exc)
        gen = None

    try:
        yield _Recorder(gen)
    finally:
        # Best-effort flush so short-lived workers don't drop the event.
        try:
            client.flush()
        except Exception as exc:  # noqa: BLE001
            logger.debug("Langfuse flush failed (ignored): %s", exc)
