"""Review queue — first-class "needs a human" rows, backed by ``review_queue``.

Replaces the old ``audit_log``-as-view approach: ``kind`` / ``filename`` /
``raw_s3_key`` / ``details`` are stored columns (no free-text parsing), the open
queue is ``WHERE state='open'`` (indexed), and resolution captures who/when.
``audit_log`` stays append-only history (written separately by the pipeline);
this module no longer reads it for the live queue.

Write path (pipeline): :func:`enqueue`.
Read/resolve path (API): :func:`list_open`, :func:`count_open`, :func:`resolve`,
:func:`approve`, :func:`upload`, :func:`locate_file`.

See ``docs/MANUAL_REVIEW_IMPLEMENTATION_LOGIC.md``.
"""
from __future__ import annotations

import logging
import re
from typing import Any, Optional

import psycopg2.extras

from app.constants import APPROVABLE_KINDS, UPLOADABLE_KINDS, ReviewKind, ReviewState
from app.db import get_conn

logger = logging.getLogger(__name__)

_DUP_KINDS = {ReviewKind.DUPLICATE.value, ReviewKind.DUPLICATE_HIRED.value}

# SYNTHETIC kind — NOT a review_queue row (and deliberately absent from the table's
# chk_review_kind CHECK). Candidates stranded at status='Pending Extraction' are real
# candidate_master rows, not queue items; we surface them in the open queue on read so a
# recruiter can run extraction from here. Never enqueue()'d / persisted with this kind.
PENDING_EXTRACTION_KIND = "pending_extraction"


# ── Write path (pipeline) ────────────────────────────────────────────────────

def _dedup_predicate(
    kind_val: str, filename: Optional[str], details: Optional[dict]
) -> tuple[str, list[Any]]:
    """SQL fragment + params identifying an existing OPEN item for the SAME source.

    Re-running the pipeline over one email (retry / requeue / a fresh daily run) must
    not stack duplicate review rows — the same corrupt file validated by three runs is
    ONE problem, not three. ``reason`` is deliberately excluded from the identity so a
    differing detail (e.g. a per-run temp path in the message) can't defeat the dedup.
    The discriminator is per-kind: excel rows key on ``row_number``, links on ``url``,
    everything else on ``filename``.
    """
    if kind_val == ReviewKind.EXCEL_ROW.value:
        rn = None if not details or details.get("row_number") is None else str(details["row_number"])
        return "details->>'row_number' IS NOT DISTINCT FROM %s", [rn]
    if kind_val == ReviewKind.LINK_FETCH.value:
        url = (details or {}).get("url") or None
        return "details->>'url' IS NOT DISTINCT FROM %s", [url]
    return "filename IS NOT DISTINCT FROM %s", [filename]


def enqueue(
    *,
    e_id: Optional[str] = None,
    candidate_id: Optional[str] = None,
    batch_id: Optional[str] = None,
    layer: str,
    kind: ReviewKind | str,
    filename: Optional[str] = None,
    raw_s3_key: Optional[str] = None,
    reason: Optional[str] = None,
    details: Optional[dict] = None,
) -> Optional[int]:
    """Insert one OPEN review item; return its review_id (or None if suppressed/failed).

    Idempotent: if an OPEN item already exists for the same source (matched on
    e_id + candidate_id + kind + a per-kind discriminator, see :func:`_dedup_predicate`),
    no second row is created and ``None`` is returned — so reprocessing an email never
    stacks duplicate "needs review" entries for the same underlying problem.

    Best-effort: a failure here is logged and swallowed — capturing review state
    must never break the pipeline run (same contract as the audit ledger).
    """
    kind_val = kind.value if isinstance(kind, ReviewKind) else str(kind)
    disc_sql, disc_params = _dedup_predicate(kind_val, filename, details)
    details_json = psycopg2.extras.Json(details) if details is not None else None
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                # INSERT only when no equivalent OPEN row exists (single atomic statement).
                cur.execute(
                    f"""INSERT INTO review_queue
                          (e_id, candidate_id, batch_id, layer, kind, filename,
                           raw_s3_key, reason, details, state)
                        SELECT %s,%s,%s,%s,%s,%s,%s,%s,%s,'open'
                         WHERE NOT EXISTS (
                            SELECT 1 FROM review_queue
                             WHERE state='open'
                               AND kind=%s
                               AND e_id IS NOT DISTINCT FROM %s
                               AND candidate_id IS NOT DISTINCT FROM %s
                               AND {disc_sql}
                         )
                        RETURNING review_id""",
                    (e_id, candidate_id, batch_id, layer, kind_val, filename,
                     raw_s3_key, reason, details_json,
                     kind_val, e_id, candidate_id, *disc_params),
                )
                row = cur.fetchone()
                if row is None:
                    logger.info("[review_queue] enqueue(%s/%s) suppressed — open duplicate",
                                e_id, kind_val)
                    return None
                return int(row[0])
    except Exception as exc:  # noqa: BLE001 — review capture must never raise
        logger.warning("[review_queue] enqueue(%s/%s) failed: %s", e_id, kind_val, exc)
        return None


# ── Read path (API) ──────────────────────────────────────────────────────────

_SELECT_COLS = """
    r.review_id, r.e_id, r.candidate_id, r.batch_id, r.layer, r.kind,
    r.filename, r.raw_s3_key, r.reason, r.details, r.state, r.created_at,
    r.resolved_by, r.resolved_at, r.resolution_note,
    e.sender_mail_id, e.subject, e.received_date
"""
_LIST_SQL = f"""
    SELECT {_SELECT_COLS}
      FROM review_queue r
      LEFT JOIN email_master e ON e.e_id = r.e_id
     WHERE r.state = 'open'
     ORDER BY r.created_at DESC
     LIMIT %s
"""
_DISCARDED_SQL = f"""
    SELECT {_SELECT_COLS}
      FROM review_queue r
      LEFT JOIN email_master e ON e.e_id = r.e_id
     WHERE r.state = 'discarded'
     ORDER BY r.resolved_at DESC NULLS LAST
     LIMIT %s
"""


def list_open(limit: int = 200) -> list[dict[str, Any]]:
    """Open review items, each enriched with its email header (sender/subject/date).

    Includes SYNTHETIC ``pending_extraction`` items (candidates stranded at
    status='Pending Extraction') so they surface here for a one-click re-extract,
    even though they live in ``candidate_master`` rather than ``review_queue``.
    """
    items: list[dict[str, Any]] = []
    try:
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(_LIST_SQL, (limit,))
                items = [_to_item(dict(r)) for r in cur.fetchall()]
    except Exception as exc:  # noqa: BLE001
        logger.warning("[review_queue] list_open failed: %s", exc)
    return items + list_pending_extraction(limit)


def list_discarded(limit: int = 200) -> list[dict[str, Any]]:
    """Discarded items — kept (not deleted) so a recruiter can restore or purge them."""
    try:
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(_DISCARDED_SQL, (limit,))
                return [_to_item(dict(r)) for r in cur.fetchall()]
    except Exception as exc:  # noqa: BLE001
        logger.warning("[review_queue] list_discarded failed: %s", exc)
        return []


def count_open() -> int:
    table_count = 0
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT COUNT(*) FROM review_queue WHERE state = 'open'")
                table_count = int(cur.fetchone()[0])
    except Exception as exc:  # noqa: BLE001
        logger.warning("[review_queue] count_open failed: %s", exc)
    return table_count + _count_pending_extraction()


def open_counts_by_email() -> dict[str, int]:
    """How many OPEN review items each e_id still has (0 == nothing unresolved).

    The live "does this mail still need a human?" signal: a mail that processed but
    left some resumes in review reads > 0 here until a recruiter clears them, then
    drops to 0. Keeps the Intake table's mail flagged for review until cleared.
    """
    out: dict[str, int] = {}
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT e_id, COUNT(*) FROM review_queue "
                    "WHERE state = 'open' AND e_id IS NOT NULL GROUP BY e_id"
                )
                out = {eid: int(n) for eid, n in cur.fetchall()}
    except Exception as exc:  # noqa: BLE001
        logger.warning("[review_queue] open_counts_by_email failed: %s", exc)
    return out


# ── Synthetic "pending extraction" items (candidate_master, not review_queue) ──

_PENDING_EXTRACTION_SQL = """
    SELECT cm.candidate_id, cm.e_id, cm.s3_file_path, cm.failure_reason,
           cm.created_at, e.sender_mail_id, e.subject, e.received_date
      FROM candidate_master cm
      LEFT JOIN email_master e ON e.e_id = cm.e_id
     WHERE cm.status = 'Pending Extraction'
     ORDER BY cm.created_at DESC NULLS LAST
     LIMIT %s
"""


def _synthetic_review_id(candidate_id: str) -> int:
    """A stable, NEGATIVE id for a synthetic item (real review_ids are positive, so
    these never collide and the UI can tell them apart). Derived from the candidate's
    numeric suffix (C1111 → -1111); falls back to a hash for non-numeric ids."""
    digits = re.sub(r"\D", "", candidate_id or "")
    if digits:
        return -int(digits)
    return -(abs(hash(candidate_id)) % 1_000_000_000)


def _to_pending_item(row: dict[str, Any]) -> dict[str, Any]:
    """Shape a 'Pending Extraction' candidate_master row as an open review item."""
    created = row.get("created_at")
    e_id = row.get("e_id")
    email = None
    if e_id:
        email = {
            "sender_mail_id": row.get("sender_mail_id"),
            "subject": row.get("subject"),
            "received_date": row.get("received_date"),
        }
    s3_path = row.get("s3_file_path") or ""
    filename = s3_path.rsplit("/", 1)[-1] if s3_path else None
    return {
        "review_id": _synthetic_review_id(row["candidate_id"]),
        "e_id": e_id,
        "candidate_id": row["candidate_id"],
        "stage": "L3",
        "kind": PENDING_EXTRACTION_KIND,
        "filename": filename,
        "raw_s3_key": None,
        "reason": (
            row.get("failure_reason")
            or "Extraction hasn't completed — run it to fill skills, experience & ATS."
        ),
        "details": None,
        "state": "open",
        "duplicate_of": None,
        "email": email,
        "created_at": created.isoformat() if hasattr(created, "isoformat") else created,
        "resolved_by": None,
        "resolved_at": None,
    }


def list_pending_extraction(limit: int = 200) -> list[dict[str, Any]]:
    """Candidates stuck at status='Pending Extraction', as synthetic open items."""
    try:
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(_PENDING_EXTRACTION_SQL, (limit,))
                return [_to_pending_item(dict(r)) for r in cur.fetchall()]
    except Exception as exc:  # noqa: BLE001
        logger.warning("[review_queue] list_pending_extraction failed: %s", exc)
        return []


def _count_pending_extraction() -> int:
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT COUNT(*) FROM candidate_master WHERE status = 'Pending Extraction'"
                )
                return int(cur.fetchone()[0])
    except Exception as exc:  # noqa: BLE001
        logger.warning("[review_queue] _count_pending_extraction failed: %s", exc)
        return 0


def _to_item(row: dict[str, Any]) -> dict[str, Any]:
    """Map a review_queue (+ email_master) row to the UI item shape."""
    created = row.get("created_at")
    kind = row.get("kind")
    email = None
    if row.get("e_id"):
        email = {
            "sender_mail_id": row.get("sender_mail_id"),
            "subject": row.get("subject"),
            "received_date": row.get("received_date"),
        }
    return {
        "review_id": row["review_id"],
        "e_id": row.get("e_id"),
        "candidate_id": row.get("candidate_id"),
        "stage": row.get("layer"),
        "kind": kind,
        "filename": row.get("filename"),
        "raw_s3_key": row.get("raw_s3_key"),
        "reason": row.get("reason"),
        "details": row.get("details"),       # JSONB → dict (psycopg2 parses it)
        "state": row.get("state"),
        "duplicate_of": row.get("candidate_id") if kind in _DUP_KINDS else None,
        "email": email,
        "created_at": created.isoformat() if hasattr(created, "isoformat") else created,
        "resolved_by": row.get("resolved_by"),
        "resolved_at": (row["resolved_at"].isoformat()
                        if hasattr(row.get("resolved_at"), "isoformat") else row.get("resolved_at")),
    }


# ── Resolution ───────────────────────────────────────────────────────────────

def _close(
    review_id: int, *, state: str, by: str = "system",
    note: Optional[str] = None, candidate_id: Optional[str] = None,
) -> bool:
    """Close an OPEN item; returns False if it is missing or already closed."""
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                if candidate_id is not None:
                    cur.execute(
                        """UPDATE review_queue
                              SET state=%s, resolved_by=%s, resolved_at=CURRENT_TIMESTAMP,
                                  resolution_note=%s, candidate_id=COALESCE(candidate_id,%s)
                            WHERE review_id=%s AND state='open'""",
                        (state, by, note, candidate_id, review_id),
                    )
                else:
                    cur.execute(
                        """UPDATE review_queue
                              SET state=%s, resolved_by=%s, resolved_at=CURRENT_TIMESTAMP,
                                  resolution_note=%s
                            WHERE review_id=%s AND state='open'""",
                        (state, by, note, review_id),
                    )
                return cur.rowcount > 0
    except Exception as exc:  # noqa: BLE001
        logger.warning("[review_queue] close(%s) failed: %s", review_id, exc)
        return False


def resolve(review_id: int, action: str = "resolve",
            by: str = "system", note: Optional[str] = None) -> bool:
    """Mark handled (``resolve``) or junk (``discard``); records reviewer + time."""
    state = (ReviewState.DISCARDED.value if action == "discard"
             else ReviewState.RESOLVED.value)
    return _close(review_id, state=state, by=by, note=note)


def resolve_open_for_candidate(candidate_id: str, kind: ReviewKind | str,
                               by: str = "recruiter",
                               note: Optional[str] = None) -> int:
    """Close every OPEN item of ``kind`` for a candidate; return how many closed.

    Used when a recruiter resolves a re-application through the candidate flow
    (accept/ignore) so the mirror row in the Needs-Review queue doesn't linger.
    Best-effort — a failure here must never break the resolution it follows.
    """
    kind_val = kind.value if isinstance(kind, ReviewKind) else str(kind)
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """UPDATE review_queue
                          SET state=%s, resolved_by=%s, resolved_at=CURRENT_TIMESTAMP,
                              resolution_note=%s
                        WHERE candidate_id=%s AND kind=%s AND state='open'""",
                    (ReviewState.RESOLVED.value, by, note, candidate_id, kind_val),
                )
                return cur.rowcount
    except Exception as exc:  # noqa: BLE001
        logger.warning("[review_queue] resolve_open_for_candidate(%s/%s) failed: %s",
                       candidate_id, kind_val, exc)
        return 0


def restore(review_id: int) -> bool:
    """Re-open a DISCARDED item (undo a discard). Returns False if not discarded."""
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """UPDATE review_queue
                          SET state='open', resolved_by=NULL, resolved_at=NULL,
                              resolution_note=NULL
                        WHERE review_id=%s AND state='discarded'""",
                    (review_id,),
                )
                return cur.rowcount > 0
    except Exception as exc:  # noqa: BLE001
        logger.warning("[review_queue] restore(%s) failed: %s", review_id, exc)
        return False


def delete_permanently(review_id: int, by: str = "recruiter") -> Optional[dict[str, Any]]:
    """Hard-delete a DISCARDED item: remove its raw S3 file AND the review row.

    Two-step guard — only an item already in ``discarded`` state can be purged
    (Discard first, then Delete permanently). The original drop event stays in
    ``audit_log`` and a ``review_deleted`` marker is appended, so the action is
    traceable even though the row and file are gone.

    Returns ``{"deleted": True, "file_deleted": bool}`` or None if not eligible.
    """
    row = _row(review_id)
    if not row or row.get("state") != ReviewState.DISCARDED.value:
        return None

    file_deleted = False
    raw_key = row.get("raw_s3_key")
    if raw_key:
        try:
            from app.services.s3 import s3
            s3().delete(raw_key, raw=True)
            file_deleted = True
        except Exception as exc:  # noqa: BLE001 — log, still purge the row
            logger.warning("[review_queue] S3 delete failed (%s): %s", raw_key, exc)

    # Traceability marker (the ledger is append-only; the drop event remains).
    try:
        from app.services import audit
        audit.write_event(
            e_id=row.get("e_id"), candidate_id=row.get("candidate_id"),
            layer="REVIEW", step="review_deleted", status="Info",
            fail_reason=(f"purged review_id={review_id} kind={row.get('kind')} "
                         f"by={by} file_deleted={file_deleted}"),
        )
    except Exception:  # noqa: BLE001
        pass

    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "DELETE FROM review_queue WHERE review_id=%s AND state='discarded'",
                    (review_id,),
                )
                if cur.rowcount == 0:
                    return None
    except Exception as exc:  # noqa: BLE001
        logger.warning("[review_queue] delete_permanently(%s) failed: %s", review_id, exc)
        return None
    logger.info("[review_queue] permanently deleted %s (file_deleted=%s)",
                review_id, file_deleted)
    return {"deleted": True, "file_deleted": file_deleted}


def delete_all_discarded(by: str = "recruiter") -> dict[str, Any]:
    """Permanently delete EVERY discarded item — their raw S3 files AND rows.

    The bulk counterpart of :func:`delete_permanently`: only items already in
    ``discarded`` state are purged. Each file delete is best-effort (a missing /
    unreachable object is logged, the row is still removed), and one
    ``review_deleted`` audit marker is written per purged row so the action stays
    traceable. Returns ``{"deleted": int, "file_deleted": int}``.
    """
    try:
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    "SELECT review_id, e_id, candidate_id, kind, raw_s3_key "
                    "FROM review_queue WHERE state='discarded'"
                )
                rows = [dict(r) for r in cur.fetchall()]
    except Exception as exc:  # noqa: BLE001
        logger.warning("[review_queue] delete_all_discarded list failed: %s", exc)
        return {"deleted": 0, "file_deleted": 0}

    if not rows:
        return {"deleted": 0, "file_deleted": 0}

    file_deleted = 0
    for row in rows:
        raw_key = row.get("raw_s3_key")
        if raw_key:
            try:
                from app.services.s3 import s3
                s3().delete(raw_key, raw=True)
                file_deleted += 1
            except Exception as exc:  # noqa: BLE001 — log, still purge the row
                logger.warning("[review_queue] S3 delete failed (%s): %s", raw_key, exc)
        try:
            from app.services import audit
            audit.write_event(
                e_id=row.get("e_id"), candidate_id=row.get("candidate_id"),
                layer="REVIEW", step="review_deleted", status="Info",
                fail_reason=(f"purged review_id={row['review_id']} kind={row.get('kind')} "
                             f"by={by} bulk=true"),
            )
        except Exception:  # noqa: BLE001
            pass

    ids = [row["review_id"] for row in rows]
    deleted = 0
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "DELETE FROM review_queue WHERE state='discarded' AND review_id = ANY(%s)",
                    (ids,),
                )
                deleted = cur.rowcount
    except Exception as exc:  # noqa: BLE001
        logger.warning("[review_queue] delete_all_discarded failed: %s", exc)
        return {"deleted": 0, "file_deleted": file_deleted}

    logger.info("[review_queue] bulk-deleted %s discarded item(s) (files_deleted=%s)",
                deleted, file_deleted)
    return {"deleted": deleted, "file_deleted": file_deleted}


# ── Force a dropped/uploaded file through to a candidate ──────────────────────

def _row(review_id: int) -> Optional[dict[str, Any]]:
    try:
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute("SELECT * FROM review_queue WHERE review_id=%s", (review_id,))
                r = cur.fetchone()
                return dict(r) if r else None
    except Exception as exc:  # noqa: BLE001
        logger.warning("[review_queue] row(%s) lookup failed: %s", review_id, exc)
        return None


def _run_date_for(e_id: Optional[str]) -> Optional[str]:
    """The YYYY-MM-DD an e_id's mail was received (drives the dated S3 prefixes)."""
    if not e_id:
        return None
    from app.repositories import repo

    email = repo().get_email(e_id) or {}
    recv = str(email.get("received_date") or "")[:10]
    return recv if (len(recv) == 10 and recv[4] == "-") else None


def _locate_raw_key(e_id: Optional[str], filename: Optional[str]) -> Optional[str]:
    """Fallback raw-bucket key finder for legacy rows with no stored raw_s3_key."""
    if not e_id:
        return None
    from app.repositories import repo
    from app.services.s3 import s3

    email = repo().get_email(e_id)
    if not email:
        return None
    prefixes: list[str] = []
    fp = (email.get("file_path") or "").strip()
    if fp:
        if fp.startswith("raw/"):
            fp = fp[4:]
        prefixes.append(fp if fp.endswith("/") else fp + "/")
    recv = str(email.get("received_date") or "")[:10]
    if len(recv) == 10 and recv[4] == "-":
        y, m, d = recv.split("-")
        prefixes.append(f"{y}/{m}/{d}/{e_id}/")
    for prefix in prefixes:
        try:
            keys = s3().list_keys(prefix, raw=True)
        except Exception:  # noqa: BLE001
            continue
        if not keys:
            continue
        if filename:
            for k in keys:
                if k.rsplit("/", 1)[-1] == filename:
                    return k
        if len(keys) == 1:
            return keys[0]
    return None


def locate_file(review_id: int) -> Optional[str]:
    """The raw S3 key for a review item's dropped file (for inline viewing)."""
    row = _row(review_id)
    if not row:
        return None
    return row.get("raw_s3_key") or _locate_raw_key(row.get("e_id"), row.get("filename"))


def approve(review_id: int) -> Optional[dict[str, Any]]:
    """Override a not-a-resume / failed verdict: force the stored raw file through
    to a candidate (clean copy → stub → L3), then close the item as ``approved``.

    Only ``not_resume`` / ``failed`` kinds qualify (no candidate yet, file in S3).
    """
    from datetime import date

    from app.extraction.runner import safe_extract_candidate
    from app.repositories import repo
    from app.services.s3 import s3

    row = _row(review_id)
    if not row or row.get("state") != "open":
        return None
    if row.get("kind") not in {k.value for k in APPROVABLE_KINDS}:
        return None

    e_id = row.get("e_id")
    raw_key = row.get("raw_s3_key") or _locate_raw_key(e_id, row.get("filename"))
    if not raw_key:
        logger.warning("[review_queue] approve: raw file not found (id=%s)", review_id)
        return None

    run_date = _run_date_for(e_id) or date.today().isoformat()
    new_cid = repo().get_next_candidate_id()
    filename = raw_key.rsplit("/", 1)[-1]
    clean_key = s3().clean_prefix(new_cid, run_date) + filename

    s3().copy(raw_key, clean_key)  # raw → resume bucket
    email_row = repo().get_email(e_id) if e_id else None
    repo().insert_candidate_stub(
        candidate_id=new_cid, s3_file_path=clean_key,
        mail_send_date=date.fromisoformat(run_date), e_id=e_id or "",
        source=(email_row or {}).get("source"),
    )
    extraction = safe_extract_candidate(new_cid)
    _close(review_id, state=ReviewState.APPROVED.value, by="recruiter",
           note=f"approved → {new_cid}", candidate_id=new_cid)
    logger.info("[review_queue] approved %s → candidate %s", review_id, new_cid)
    return {"candidate_id": new_cid, "s3_file_path": clean_key, "extraction": extraction}


def upload(review_id: int, file_bytes: bytes, filename: str,
           by: str = "recruiter") -> Optional[dict[str, Any]]:
    """Resolve an excel_row / link_fetch item by uploading the missing resume.

    The candidate is seeded with the row's name/email (fallback identity; L3
    overwrites on success), the file is stored in the resume bucket, L3 runs, and
    the item closes as ``approved``.
    """
    from datetime import date

    from app.extraction.runner import safe_extract_candidate
    from app.repositories import repo
    from app.services.s3 import s3

    row = _row(review_id)
    if not row or row.get("state") != "open":
        return None
    if row.get("kind") not in {k.value for k in UPLOADABLE_KINDS}:
        return None

    e_id = row.get("e_id")
    details = row.get("details") or {}
    run_date = _run_date_for(e_id) or date.today().isoformat()
    new_cid = repo().get_next_candidate_id()
    safe_name = (filename or "").rsplit("/", 1)[-1] or "resume"
    clean_key = s3().clean_prefix(new_cid, run_date) + safe_name

    s3().put_bytes(clean_key, file_bytes)
    email_row = repo().get_email(e_id) if e_id else None
    repo().insert_candidate_stub(
        candidate_id=new_cid, s3_file_path=clean_key,
        mail_send_date=date.fromisoformat(run_date), e_id=e_id or "",
        name=str(details.get("name") or ""),
        email=str(details.get("email") or ""),
        phno=str(details.get("phone") or ""),
        source=(email_row or {}).get("source"),
    )
    extraction = safe_extract_candidate(new_cid)
    _close(review_id, state=ReviewState.APPROVED.value, by=by,
           note=f"uploaded → {new_cid}", candidate_id=new_cid)
    logger.info("[review_queue] uploaded resume for %s → candidate %s", review_id, new_cid)
    return {"candidate_id": new_cid, "s3_file_path": clean_key, "extraction": extraction}
