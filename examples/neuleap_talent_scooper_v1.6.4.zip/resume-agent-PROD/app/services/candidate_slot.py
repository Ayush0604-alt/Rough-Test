"""Candidate Interview Slot Selection — a candidate-facing, email-code-gated
public flow that mirrors app.services.interviewer_link/interviewer_auth, but
scoped to the CANDIDATE themselves (verified against their own on-file
email — see round_slot_invites.candidate_email) rather than an allow-listed
interviewer domain.

Lifecycle of one row in ``round_slot_invites``:
    1. create_invite()  — minted once, when a round becomes the candidate's
       new active round (see the auto-invite hook in app.api.rounds), IF
       Settings → Interview Scheduling → "Auto-send invites" is on.
    2. The candidate opens ``/schedule/{token}``, verifies their email via a
       mailed "NLi-XXXXX" code (request_code/verify_code below), and picks a
       slot from app.services.graph_calendar.available_slots() — book_slot()
       records it.
    3. If never booked, the reminder/auto-reject scheduled job
       (app.services.slot_reminder_job) reminds up to the configured count,
       then auto-rejects after the configured period — both read from
       app.services.interview_scheduling_config.
"""
from __future__ import annotations

import hashlib
import random
import secrets
import string
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Optional, TypedDict

import psycopg2

from app.config import settings
from app.db import get_conn
from app.logging_config import get_logger
from app.services import (
    email_send,
    email_templates,
    graph_calendar,
    graph_client,
    interview_pools,
    interview_scheduling_config,
    interviewer_link,
    system_reset,
)

log = get_logger(__name__)

_TOKEN_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
_TOKEN_LEN = 10
_MAX_ATTEMPTS = 5
_CODE_TTL_MINUTES = 10


class InviteContext(TypedDict):
    token: str
    candidate_id: str
    round_id: int
    candidate_email: Optional[str]
    reminder_count: int
    remind_me_again: bool
    slot_start: Optional[datetime]
    slot_end: Optional[datetime]
    booked_at: Optional[datetime]
    rejected_at: Optional[datetime]
    pool_id: Optional[int]


class EmailMismatch(Exception):
    """The email supplied doesn't match this invite's candidate."""


class InvalidCode(Exception):
    """The submitted code is wrong, expired, or already used."""


class AlreadyResolved(Exception):
    """This invite is already booked or rejected — no further action possible."""


def _gen_token() -> str:
    return "".join(secrets.choice(_TOKEN_ALPHABET) for _ in range(_TOKEN_LEN))


def _gen_code() -> str:
    return "NLi-" + "".join(random.choices(string.digits, k=5))


def create_invite(
    candidate_id: str, round_id: int, candidate_email: Optional[str], pool_id: Optional[int] = None
) -> str:
    """Mints a new slot-selection link for this round. When `pool_id` is set,
    the candidate picks from that pool's pre-reserved placeholder slots
    (app.services.interview_pools) instead of a live per-candidate Graph
    lookup. Returns the token."""
    for _ in range(_MAX_ATTEMPTS):
        token = _gen_token()
        try:
            with get_conn() as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        "INSERT INTO round_slot_invites "
                        "(token, candidate_id, round_id, candidate_email, pool_id) "
                        "VALUES (%s, %s, %s, %s, %s)",
                        (token, candidate_id, round_id, candidate_email, pool_id),
                    )
            return token
        except psycopg2.IntegrityError:
            continue
    raise RuntimeError("Could not generate a unique slot-invite token.")


def decode_invite(token: str) -> Optional[InviteContext]:
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT token, candidate_id, round_id, candidate_email, reminder_count, "
                "remind_me_again, slot_start, slot_end, booked_at, rejected_at, pool_id "
                "FROM round_slot_invites WHERE token = %s",
                (token,),
            )
            row = cur.fetchone()
    if not row:
        return None
    return {
        "token": row[0], "candidate_id": row[1], "round_id": row[2], "candidate_email": row[3],
        "reminder_count": row[4], "remind_me_again": row[5],
        "slot_start": row[6], "slot_end": row[7], "booked_at": row[8], "rejected_at": row[9],
        "pool_id": row[10],
    }


def public_schedule_url(token: str) -> Optional[str]:
    """Absolute /schedule/{token} link for backend-initiated emails (auto-
    invite, reminders) — there's no browser in the loop to prepend an origin
    itself, unlike the Draft Review flow. None if APP_PUBLIC_URL isn't
    configured, so callers can skip sending rather than emailing a candidate
    a broken relative link."""
    base = settings.app_public_url.rstrip("/")
    return f"{base}/schedule/{token}" if base else None


def invite_for_round(round_id: int) -> Optional[InviteContext]:
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT token FROM round_slot_invites WHERE round_id = %s", (round_id,))
            row = cur.fetchone()
    return decode_invite(row[0]) if row else None


def pool_slot_link_for_round(
    candidate_id: str,
    round_id: int,
    round_name: Optional[str],
    source_label: Optional[str],
    candidate_email: Optional[str],
) -> Optional[str]:
    """Absolute slot-picker URL for a round, sourced from the interviewer
    timeslot pool matching this candidate's source + round. Reuses the round's
    existing invite (re-pointing it at the current pool when it's not booked)
    or mints a fresh one. Returns None — meaning the caller must PAUSE the send
    rather than ship a broken link — when there's no matching pool or
    APP_PUBLIC_URL isn't configured. Mirrors app.api.rounds.get_pool_slot_link,
    minus the recruiter gate (auto-send already ran the NBA move)."""
    if not round_id:
        return None
    pool = interview_pools.find_pool_for(source_label, round_name or "")
    if not pool:
        return None
    existing = invite_for_round(round_id)
    booked = bool(existing and existing.get("booked_at"))
    # A pool with NO open slots would ship a link to an empty picker — return None
    # so the caller pauses the send (an already-booked invite still points at the
    # candidate's chosen slot, so it's fine to keep serving that).
    if not booked and not interview_pools.open_slots_for_pool(pool["id"], round_name or ""):
        return None
    if existing:
        if existing.get("pool_id") != pool["id"] and not existing.get("booked_at"):
            set_invite_pool(existing["token"], pool["id"])
        token = existing["token"]
    else:
        token = create_invite(candidate_id, round_id, candidate_email, pool_id=pool["id"])
    return public_schedule_url(token)


def set_invite_pool(token: str, pool_id: Optional[int]) -> None:
    """Re-point a NOT-yet-booked invite at a different timeslot pool — used when
    a link is re-minted for a round after the matching pool changed (or after a
    pool first appeared for a round whose invite predates it)."""
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE round_slot_invites SET pool_id = %s WHERE token = %s AND booked_at IS NULL",
                (pool_id, token),
            )


def request_code(token: str, email: str) -> None:
    ctx = decode_invite(token)
    if not ctx:
        raise EmailMismatch("This scheduling link is invalid.")
    email = email.strip().lower()
    on_file = (ctx["candidate_email"] or "").strip().lower()
    # In a non-production environment every invite email is actually
    # redirected to the configured QA test inbox (see
    # email_send.resolve_recipient) — so whoever is testing this flow only
    # ever has access to THAT inbox, never the candidate's real one. Accept
    # the QA email here too, or nobody could ever complete this flow in QA.
    qa_email = ""
    if system_reset.is_wipe_allowed():
        qa_email = (interview_scheduling_config.get().get("qa_calendar_email") or "").strip().lower()
    matches_candidate = bool(on_file) and email == on_file
    matches_qa = bool(qa_email) and email == qa_email
    if not (matches_candidate or matches_qa):
        raise EmailMismatch("That email doesn't match the address this invite was sent to.")

    code = _gen_code()
    expires_at = datetime.now(timezone.utc) + timedelta(minutes=_CODE_TTL_MINUTES)
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE candidate_slot_otp SET consumed_at = CURRENT_TIMESTAMP "
                "WHERE token = %s AND email = %s AND consumed_at IS NULL",
                (token, email),
            )
            cur.execute(
                "INSERT INTO candidate_slot_otp (token, email, code, expires_at) VALUES (%s, %s, %s, %s)",
                (token, email, _digest(_normalize_code(code)), expires_at),
            )

    result = graph_client.send_mail(
        email,
        "Your NeuLeap interview scheduling code",
        "<p>Your access code is:</p>"
        f"<p style=\"text-align:center;\"><strong style=\"font-size:24px; letter-spacing:3px;\">{code}</strong></p>"
        f"<p>It expires in {_CODE_TTL_MINUTES} minutes. Use it to pick your interview slot.</p>",
    )
    if not result["sent"]:
        log.warning("candidate_slot: code email to %s not sent: %s", email, result.get("error"))


def _digest(value: str) -> str:
    """Codes and session tokens at rest are SHA-256 digests, never plaintext —
    mirrors app.services.interviewer_auth (see its _digest docstring)."""
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _normalize_code(raw: str) -> str:
    """Tolerant of how a candidate might type it back — with/without the
    "NLi-" prefix or dash, any case. Rebuilt as "NLI-" + the digits typed."""
    digits = "".join(ch for ch in raw if ch.isdigit())
    return f"NLI-{digits}"


_UNREMEMBERED_SESSION_HOURS = 12


def verify_code(token: str, email: str, code: str, *, remember: bool) -> str:
    """Always returns a session token — status/slots/book all authenticate via
    this token, so one must exist regardless of "remember". ``remember`` only
    controls how long it stays valid (and whether the browser persists it for
    future visits, decided client-side) — an unremembered session still lives
    long enough to finish picking a slot in the current visit."""
    email = email.strip().lower()
    code = _normalize_code(code)
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT id FROM candidate_slot_otp WHERE token = %s AND email = %s "
                "AND code = %s AND consumed_at IS NULL AND expires_at > CURRENT_TIMESTAMP",
                (token, email, _digest(code)),
            )
            row = cur.fetchone()
            if not row:
                raise InvalidCode("That code is incorrect or has expired.")
            cur.execute(
                "UPDATE candidate_slot_otp SET consumed_at = CURRENT_TIMESTAMP WHERE id = %s", (row[0],)
            )
            session_token = uuid.uuid4().hex
            expires_at = datetime.now(timezone.utc) + (
                timedelta(days=30) if remember else timedelta(hours=_UNREMEMBERED_SESSION_HOURS)
            )
            cur.execute(
                "INSERT INTO candidate_slot_sessions (session_token, token, email, expires_at) "
                "VALUES (%s, %s, %s, %s)",
                (_digest(session_token), token, email, expires_at),
            )
    return session_token


def create_staff_session(token: str, email: str) -> str:
    """Session minted for an Admin/SysAdmin CHECKING a picker link with their
    own app credentials (already verified by the caller) — no emailed OTP.
    Same session mechanics/expiry as an unremembered candidate verification,
    so every downstream endpoint (status/slots/book/help) works identically."""
    session_token = uuid.uuid4().hex
    expires_at = datetime.now(timezone.utc) + timedelta(hours=_UNREMEMBERED_SESSION_HOURS)
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO candidate_slot_sessions (session_token, token, email, expires_at) "
                "VALUES (%s, %s, %s, %s)",
                (_digest(session_token), token, email.strip().lower(), expires_at),
            )
    return session_token


def validate_session(token: str, session_token: Optional[str]) -> Optional[str]:
    if not session_token:
        return None
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT email FROM candidate_slot_sessions "
                "WHERE session_token = %s AND token = %s AND expires_at > CURRENT_TIMESTAMP",
                (_digest(session_token), token),
            )
            row = cur.fetchone()
    return row[0] if row else None


def available_slots_for(ctx: InviteContext, round_name: str = "") -> list[dict[str, Any]]:
    """[{start, end}] the candidate can pick from — a pool's pre-reserved
    placeholders for THIS round when the invite is pool-scoped (a pool may
    cover several rounds, each with its own separate slots), else a live
    Graph lookup against the QA stand-in calendar."""
    if ctx["pool_id"] is not None:
        return [
            {
                "start": s["slot_start"].isoformat(),
                "end": s["slot_end"].isoformat(),
                "slot_id": s["id"],
                # How many parallel interviewer placeholders remain open at this
                # time — shown in the picker and decrements as candidates book.
                "remaining": int(s.get("remaining") or 1),
            }
            for s in interview_pools.open_slots_for_pool(ctx["pool_id"], round_name)
        ]
    return graph_calendar.available_slots(calendar_email(), slot_duration_minutes())


def book_slot(
    token: str, slot_start: datetime, slot_end: datetime, *, slot_id: Optional[int] = None
) -> InviteContext:
    ctx = decode_invite(token)
    if not ctx:
        raise EmailMismatch("This scheduling link is invalid.")
    if ctx["booked_at"] or ctx["rejected_at"]:
        raise AlreadyResolved("This invite has already been resolved.")

    booked = None
    if ctx["pool_id"] is not None:
        if slot_id is None:
            raise ValueError("A pool-scoped invite must book a specific slot_id.")
        booked = interview_pools.book_pool_slot(slot_id, ctx["candidate_id"], ctx["round_id"])
        if not booked:
            raise AlreadyResolved("That slot was just taken — pick another.")
        slot_start, slot_end = booked["slot_start"], booked["slot_end"]

    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE round_slot_invites SET slot_start = %s, slot_end = %s, "
                "booked_at = CURRENT_TIMESTAMP WHERE token = %s",
                (slot_start, slot_end, token),
            )
            cur.execute(
                "UPDATE rounds SET scheduled_on = %s, candidate_accepted_slot = TRUE "
                "WHERE round_id = %s",
                (slot_start, ctx["round_id"]),
            )
    updated = decode_invite(token)
    assert updated is not None

    # Interview Scheduled — traceable in the Actions Audit Log with the booked
    # time (and interviewer, for pool slots), alongside the reminder/auto-reject
    # events the same invite may accrue later.
    try:
        from app.repositories import repo
        from app.services import audit
        from app.stages import candidate_stage_bucket

        round_name = None
        for r in repo().list_rounds(ctx["candidate_id"]):
            if r.get("round_id") == ctx["round_id"]:
                round_name = r.get("round_name")
                break
        who = f" with {booked.get('interviewer_name') or booked.get('interviewer_email')}" if booked else ""
        audit.write_event(
            candidate_id=ctx["candidate_id"], layer="L4", step="interview_scheduled", status="Info",
            fail_reason=(
                f"Interview scheduled — candidate picked a {round_name or 'round'} slot"
                f"{who}: {slot_start:%a, %d %b %Y %I:%M %p}–{slot_end:%I:%M %p}."
            ),
            stage=candidate_stage_bucket({"roundname": round_name}),
        )
    except Exception as exc:  # noqa: BLE001 — the booking already succeeded; never undo it over an audit hiccup
        log.warning("candidate_slot: audit write for booking %s failed: %s", token, exc)

    if booked is not None:
        try:
            _finalize_pool_meeting(booked, ctx)
        except Exception as exc:  # noqa: BLE001 — the booking itself already succeeded; never undo it over a Graph/email hiccup
            log.warning("candidate_slot: could not finalize the Teams meeting for slot %s: %s", slot_id, exc)

    return updated


def _finalize_pool_meeting(slot: dict[str, Any], ctx: InviteContext) -> None:
    """Runs right after a pool-scoped slot is booked: converts the
    placeholder Graph event (still sitting on the interviewer's calendar as
    "[PLACEHOLDER for NLi ...]") into a real Teams meeting — the interviewer
    stays the organizer, the candidate is added as an attendee so Exchange
    sends THEM its own meeting-invite email with the same Teams join link —
    then emails both sides a confirmation. Best-effort throughout: every
    sub-step is independent, so a failure in one (e.g. Graph unreachable)
    doesn't block the others.

    In a non-production environment (email_send.resolve_recipient — the same
    QA restriction every other candidate-facing email in this module goes
    through), the CANDIDATE side of this — both the Teams meeting attendee
    and the confirmation email — is redirected to the configured QA test
    inbox instead of the candidate's real address, so a real candidate is
    never actually invited to/emailed about a meeting during QA testing. The
    interviewer's own notification is unaffected — they're real staff, not
    the candidate being tested around."""
    from app.repositories import repo

    candidate = repo().get_candidate(ctx["candidate_id"]) or {}
    candidate_name = candidate.get("name")
    candidate_email, qa_redirected = email_send.resolve_recipient(candidate.get("email"))

    round_name = "Interview"
    for r in repo().list_rounds(ctx["candidate_id"]):
        if r.get("round_id") == ctx["round_id"]:
            round_name = r.get("round_name") or round_name
            break

    interviewer_email = slot.get("interviewer_email")
    interviewer_name = slot.get("interviewer_name")
    event_id = slot.get("graph_event_id")

    join_url = None
    if event_id and interviewer_email and candidate_email:
        try:
            join_url = graph_calendar.convert_to_teams_meeting(
                interviewer_email,
                event_id,
                subject=f"{round_name} interview — {candidate_name or 'Candidate'}",
                attendees=[{"email": candidate_email, "name": candidate_name}],
                body_html=(
                    f"<p>{round_name} interview scheduled via NeuLeap.</p>"
                    f"<p>Candidate: {candidate_name or candidate_email}</p>"
                    + ("<p><em>QA environment — candidate redirected to the QA test inbox.</em></p>" if qa_redirected else "")
                ),
            )
        except Exception as exc:  # noqa: BLE001 — keep going; emails below still make sense without a Teams link
            log.warning(
                "candidate_slot: could not convert placeholder %s to a Teams meeting: %s", event_id, exc
            )

    if candidate_email:
        subject, body = email_templates.render_slot_confirmation(
            round_name, candidate_name, slot["slot_start"], slot["slot_end"], join_url
        )
        result = graph_client.send_mail(candidate_email, subject, graph_client.plain_text_to_html(body))
        if not result["sent"]:
            log.warning(
                "candidate_slot: confirmation email to %s not sent: %s", candidate_email, result.get("error")
            )

    if interviewer_email:
        link_url = None
        try:
            link_token = interviewer_link.generate_link_token(ctx["candidate_id"], ctx["round_id"])
            base = settings.app_public_url.rstrip("/")
            link_url = f"{base}/interview/{link_token}" if base else None
        except Exception as exc:  # noqa: BLE001 — the meeting/confirmation is more important than this link
            log.warning("candidate_slot: could not mint an interviewer link: %s", exc)

        subject, body = email_templates.render_interviewer_meeting_confirmation(
            round_name, candidate_name, interviewer_name, slot["slot_start"], slot["slot_end"], join_url, link_url
        )
        result = graph_client.send_mail(interviewer_email, subject, graph_client.plain_text_to_html(body))
        if not result["sent"]:
            log.warning(
                "candidate_slot: interviewer notification to %s not sent: %s", interviewer_email, result.get("error")
            )


def set_remind_me_again(token: str, value: bool) -> None:
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE round_slot_invites SET remind_me_again = %s WHERE token = %s", (value, token)
            )


def calendar_email() -> str:
    return interview_scheduling_config.get()["qa_calendar_email"]


def slot_duration_minutes() -> int:
    return interview_scheduling_config.get()["slot_duration_minutes"]


def maybe_create_and_send_invite(
    candidate_id: str,
    round_id: int,
    round_name: Optional[str],
    candidate_email: Optional[str],
    candidate_name: Optional[str],
    source_label: Optional[str] = None,
) -> Optional[str]:
    """Mints + emails a slot invite for this round IF Settings → Interview
    Scheduling → "Auto-send invites" is on — the safety gate that keeps this
    feature from silently emailing real in-flight candidates until an Admin
    opts in. Idempotent: a round that already has an invite is left alone.
    Called from app.api.rounds right after a round becomes a candidate's new
    active round (both the direct-create and Pass-auto-advance paths).
    Prefers a matching interviewer timeslot pool for this candidate's source +
    round when one exists (app.services.interview_pools.find_pool_for)."""
    if not interview_scheduling_config.get()["auto_invite_enabled"]:
        return None
    if invite_for_round(round_id) is not None:
        return None
    if not candidate_email:
        log.warning(
            "candidate_slot: round %s (candidate %s) has no email on file — invite not sent",
            round_id, candidate_id,
        )
        return None

    pool = interview_pools.find_pool_for(source_label, round_name or "")
    # The invite ROW keeps the candidate's real on-file email (request_code's
    # identity check needs it) — only the actual SEND is QA-redirected below.
    token = create_invite(candidate_id, round_id, candidate_email, pool_id=pool["id"] if pool else None)
    link_url = public_schedule_url(token)
    if not link_url:
        log.warning(
            "candidate_slot: APP_PUBLIC_URL isn't configured — invite created but email to %s not sent",
            candidate_email,
        )
        return token
    recipient, qa_redirected = email_send.resolve_recipient(candidate_email)
    if not recipient:
        log.warning(
            "candidate_slot: invite for %s not sent — non-production env and no QA test email configured",
            candidate_email,
        )
        return token
    subject, body = email_templates.render_slot_invite(round_name or "Interview", candidate_name, link_url)
    result = graph_client.send_mail(recipient, subject, graph_client.plain_text_to_html(body))
    if not result["sent"]:
        log.warning(
            "candidate_slot: invite email to %s%s not sent: %s",
            recipient, " (QA-redirected)" if qa_redirected else "", result.get("error"),
        )
    return token
