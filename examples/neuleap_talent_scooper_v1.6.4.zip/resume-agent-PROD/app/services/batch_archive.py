"""Batch archive/restore/prune — backs the Mailbox "Batch Archive" section.

A "batch" here is every candidate_master + email_master row sharing one
`source` value (the recruiter-typed intake tag from the upload modal / an
active registered source tag) — OR the "no source" bucket (`source IS NULL`)
for mail/uploads that never got tagged. There is no dedicated batch-id column
in the schema (see app/db/schema.sql), so `source` IS the batch key.

Archiving a batch moves its rows out of the live tables into the *_archive
tables — the exact same move-not-flag pattern as the existing per-candidate
``PATCH /candidates/{id}/archive`` (app.repositories.pg_repo._archive_ids),
just selected by `source` instead of by id, and extended to email_master so
the batch disappears from the Mailbox history too.

Unlike that per-candidate path (one-way today, no restore endpoint exists),
a batch here is restorable — `restore_batch` is the exact reverse of
`archive_batch` — and separately PRUNABLE — `prune_batch` permanently deletes
the archived rows AND their resume files from the object store, which the
per-candidate archive deliberately never does.
"""
from __future__ import annotations

from typing import Any

import psycopg2.extras

from app.db import get_conn
from app.logging_config import get_logger
from app.services.s3 import s3

log = get_logger(__name__)

# Display label the frontend uses for the `source IS NULL` bucket. Kept here
# (not just in the frontend) so any backend-generated text stays in sync.
NO_SOURCE_LABEL = "No source"


def _source_where(source: str | None) -> tuple[str, tuple]:
    """A SQL predicate + params matching rows with this `source` (None → NULL)."""
    if source is None:
        return "source IS NULL", ()
    return "source = %s", (source,)


def _columns(cur, table: str) -> list[str]:
    """This table's column names in physical order — used to build an explicit
    column-list INSERT when copying archive -> live (the archive table has one
    extra trailing `archived_at` column that must never be selected across)."""
    cur.execute(
        "SELECT column_name FROM information_schema.columns "
        "WHERE table_name = %s ORDER BY ordinal_position",
        (table,),
    )
    return [r[0] for r in cur.fetchall()]


def _sync_archive_columns(cur, live: str, archive: str) -> list[str]:
    """Bring `archive` up to date with `live`'s columns, returning live's
    column list. The live tables keep gaining feature columns (slot invites,
    reminders, onboarding, …) while the *_archive snapshots don't — so a
    positional `INSERT ... SELECT r.*` drifts and fails ("INSERT has more
    expressions than target columns"). Any column live has that the archive
    lacks is added here (same type, nullable) right before the copy."""
    cur.execute(
        "SELECT a.attname, pg_catalog.format_type(a.atttypid, a.atttypmod) "
        "FROM pg_attribute a JOIN pg_class c ON a.attrelid = c.oid "
        "JOIN pg_namespace n ON c.relnamespace = n.oid "
        "WHERE c.relname = %s AND n.nspname = 'public' AND a.attnum > 0 AND NOT a.attisdropped "
        "ORDER BY a.attnum",
        (live,),
    )
    live_cols = [(r[0], r[1]) for r in cur.fetchall()]
    have = set(_columns(cur, archive))
    for name, coltype in live_cols:
        if name not in have:
            cur.execute(f'ALTER TABLE {archive} ADD COLUMN IF NOT EXISTS "{name}" {coltype}')
            log.info("batch_archive: added missing column %s.%s (%s)", archive, name, coltype)
    return [name for name, _ in live_cols]


def candidate_ids_for_source(source: str | None) -> list[str]:
    """Every LIVE candidate_id sharing this `source` tag (None -> the "no
    source" bucket) — the same batch key used by archive/restore/prune,
    reused by Settings' "re-run across a batch" actions (extraction/analysis
    re-run, NLRS recalculation preview) so both features agree on exactly
    which candidates a source tag selects."""
    where, params = _source_where(source)
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(f"SELECT candidate_id FROM candidate_master WHERE {where}", params)
            return [r[0] for r in cur.fetchall()]


def list_batches() -> list[dict[str, Any]]:
    """Every distinct `source` currently live, with counts — the options for
    "archive a batch". NULL groups under the "no source" bucket."""
    with get_conn() as conn:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(
                """
                SELECT source,
                       COUNT(*)                    AS candidate_count,
                       MIN(mail_send_date)::text   AS oldest,
                       MAX(mail_send_date)::text   AS newest
                  FROM candidate_master
                 GROUP BY source
                 ORDER BY source NULLS FIRST
                """
            )
            return [dict(r) for r in cur.fetchall()]


def list_archived_batches() -> list[dict[str, Any]]:
    """Same grouping over candidate_master_archive — the options for restore/prune."""
    with get_conn() as conn:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(
                """
                SELECT source,
                       COUNT(*)             AS candidate_count,
                       MIN(archived_at)     AS archived_from,
                       MAX(archived_at)     AS archived_to
                  FROM candidate_master_archive
                 GROUP BY source
                 ORDER BY source NULLS FIRST
                """
            )
            return [dict(r) for r in cur.fetchall()]


def archive_batch(source: str | None) -> dict[str, Any]:
    """Move every candidate/round/email row sharing `source` into the archive
    tables, in one transaction. A no-op (zero counts) if the batch is empty."""
    where, params = _source_where(source)
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(f"SELECT candidate_id FROM candidate_master WHERE {where}", params)
            candidate_ids = [r[0] for r in cur.fetchall()]

            if candidate_ids:
                # Rounds first (archive then delete) so the candidate FK can be removed.
                # Explicit, name-matched column lists (after syncing any columns the
                # archive table is missing) — a positional `SELECT r.*` breaks as soon
                # as the live schema gains a column the archive snapshot doesn't have.
                r_cols = ", ".join(f'"{c}"' for c in _sync_archive_columns(cur, "rounds", "rounds_archive"))
                cur.execute(
                    f"INSERT INTO rounds_archive ({r_cols}, archived_at) "
                    f"SELECT {r_cols}, CURRENT_TIMESTAMP FROM rounds WHERE candidate_id = ANY(%s)",
                    (candidate_ids,),
                )
                cur.execute("DELETE FROM rounds WHERE candidate_id = ANY(%s)", (candidate_ids,))
                cm_cols = ", ".join(
                    f'"{c}"' for c in _sync_archive_columns(cur, "candidate_master", "candidate_master_archive")
                )
                cur.execute(
                    f"INSERT INTO candidate_master_archive ({cm_cols}, archived_at) "
                    f"SELECT {cm_cols}, CURRENT_TIMESTAMP FROM candidate_master WHERE candidate_id = ANY(%s)",
                    (candidate_ids,),
                )
                cur.execute(
                    "DELETE FROM candidate_master WHERE candidate_id = ANY(%s)", (candidate_ids,)
                )

            cur.execute(f"SELECT e_id FROM email_master WHERE {where}", params)
            e_ids = [r[0] for r in cur.fetchall()]
            if e_ids:
                em_cols = ", ".join(
                    f'"{c}"' for c in _sync_archive_columns(cur, "email_master", "email_master_archive")
                )
                cur.execute(
                    f"INSERT INTO email_master_archive ({em_cols}, archived_at) "
                    f"SELECT {em_cols}, CURRENT_TIMESTAMP FROM email_master WHERE e_id = ANY(%s)",
                    (e_ids,),
                )
                cur.execute("DELETE FROM email_master WHERE e_id = ANY(%s)", (e_ids,))

    log.info(
        "batch_archive: archived source=%r (%d candidates, %d emails)",
        source, len(candidate_ids), len(e_ids),
    )
    return {
        "source": source,
        "candidates_archived": len(candidate_ids),
        "emails_archived": len(e_ids),
    }


def restore_batch(source: str | None) -> dict[str, Any]:
    """Reverse of archive_batch: move matching archived rows back to the live
    tables. Candidates go first (rounds' FK needs the row to exist again)."""
    where, params = _source_where(source)
    with get_conn() as conn:
        with conn.cursor() as cur:
            cm_cols = _columns(cur, "candidate_master")
            cm_col_list = ", ".join(cm_cols)

            cur.execute(
                f"SELECT candidate_id FROM candidate_master_archive WHERE {where}", params
            )
            candidate_ids = [r[0] for r in cur.fetchall()]
            if candidate_ids:
                cur.execute(
                    f"INSERT INTO candidate_master ({cm_col_list}) "
                    f"SELECT {cm_col_list} FROM candidate_master_archive "
                    "WHERE candidate_id = ANY(%s)",
                    (candidate_ids,),
                )
                cur.execute(
                    "DELETE FROM candidate_master_archive WHERE candidate_id = ANY(%s)",
                    (candidate_ids,),
                )

                r_cols = _columns(cur, "rounds")
                r_col_list = ", ".join(r_cols)
                cur.execute(
                    f"INSERT INTO rounds ({r_col_list}) "
                    f"SELECT {r_col_list} FROM rounds_archive "
                    "WHERE candidate_id = ANY(%s)",
                    (candidate_ids,),
                )
                cur.execute(
                    "DELETE FROM rounds_archive WHERE candidate_id = ANY(%s)", (candidate_ids,)
                )

            em_cols = _columns(cur, "email_master")
            em_col_list = ", ".join(em_cols)
            cur.execute(
                f"SELECT e_id FROM email_master_archive WHERE {where}", params
            )
            e_ids = [r[0] for r in cur.fetchall()]
            if e_ids:
                cur.execute(
                    f"INSERT INTO email_master ({em_col_list}) "
                    f"SELECT {em_col_list} FROM email_master_archive WHERE e_id = ANY(%s)",
                    (e_ids,),
                )
                cur.execute(
                    "DELETE FROM email_master_archive WHERE e_id = ANY(%s)", (e_ids,)
                )

    log.info(
        "batch_archive: restored source=%r (%d candidates, %d emails)",
        source, len(candidate_ids), len(e_ids),
    )
    return {
        "source": source,
        "candidates_restored": len(candidate_ids),
        "emails_restored": len(e_ids),
    }


def prune_batch(source: str | None) -> dict[str, Any]:
    """Permanently delete an archived batch — rounds_archive + candidate_master_archive
    + email_master_archive rows AND each candidate's resume file in the object
    store (the per-candidate archive path deliberately keeps resumes forever;
    this is the one place that actually removes them, since "prune" means gone
    for good). Irreversible — the caller (API layer) is responsible for
    requiring an explicit confirmation before calling this.
    """
    where, params = _source_where(source)
    with get_conn() as conn:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(
                f"SELECT candidate_id, s3_file_path FROM candidate_master_archive WHERE {where}",
                params,
            )
            rows = cur.fetchall()
            candidate_ids = [r["candidate_id"] for r in rows]

            if candidate_ids:
                cur.execute(
                    "DELETE FROM rounds_archive WHERE candidate_id = ANY(%s)", (candidate_ids,)
                )
                cur.execute(
                    "DELETE FROM candidate_master_archive WHERE candidate_id = ANY(%s)",
                    (candidate_ids,),
                )

            cur.execute(f"SELECT e_id FROM email_master_archive WHERE {where}", params)
            e_ids = [r["e_id"] for r in cur.fetchall()]
            if e_ids:
                cur.execute(
                    "DELETE FROM email_master_archive WHERE e_id = ANY(%s)", (e_ids,)
                )

    # Resume files are deleted OUTSIDE the DB transaction (best-effort, after
    # commit) — a MinIO hiccup shouldn't roll back rows that are already gone
    # from Postgres, and a stray orphaned file is far safer than a stray row.
    deleted_files = 0
    for row in rows:
        path = row.get("s3_file_path")
        if not path:
            continue
        try:
            s3().delete(path)
            deleted_files += 1
        except Exception as exc:  # noqa: BLE001 — best-effort, log and continue
            log.warning("batch_archive: could not delete resume %s: %s", path, exc)

    log.info(
        "batch_archive: pruned source=%r (%d candidates, %d emails, %d resume files)",
        source, len(candidate_ids), len(e_ids), deleted_files,
    )
    return {
        "source": source,
        "candidates_pruned": len(candidate_ids),
        "emails_pruned": len(e_ids),
        "resume_files_deleted": deleted_files,
    }
