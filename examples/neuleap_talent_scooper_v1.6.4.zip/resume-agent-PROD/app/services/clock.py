"""Business-time clock — the single source of truth for batch/pipeline time.

Every batch and pipeline timestamp (run/batch IDs, started/finished stamps, the
cron's wall-clock) is anchored to the **business timezone**, which defaults to
**Asia/Kolkata (IST)**. Storing/serving in IST keeps run identifiers and operator-
facing timestamps consistent regardless of where the container runs (Docker hosts
are usually UTC).

Resolution order for the zone name:
    GRAPH_TZ  →  SCHEDULE_TZ  →  DEFAULT_TZ ("Asia/Kolkata")

so a Settings save (which writes SCHEDULE_TZ) re-points the whole system, and the
Graph intake window can still be overridden independently via GRAPH_TZ.
"""
from __future__ import annotations

import os
from datetime import datetime, timezone

# The system default when nothing is configured: Indian Standard Time.
DEFAULT_TZ = "Asia/Kolkata"


def tz_name() -> str:
    """The configured business timezone name (defaults to IST)."""
    return os.environ.get("SCHEDULE_TZ") or DEFAULT_TZ


def business_tz():
    """The business timezone as a tzinfo (falls back to UTC if tzdata missing)."""
    name = os.environ.get("GRAPH_TZ") or os.environ.get("SCHEDULE_TZ") or DEFAULT_TZ
    try:
        from zoneinfo import ZoneInfo

        return ZoneInfo(name)
    except Exception:  # noqa: BLE001 — missing tzdata ⇒ degrade to UTC, never crash
        return timezone.utc


def now() -> datetime:
    """Timezone-aware 'now' in the business timezone (IST by default)."""
    return datetime.now(business_tz())


def now_iso(timespec: str = "seconds") -> str:
    """ISO-8601 'now' in the business timezone (carries the +05:30 offset)."""
    return now().isoformat(timespec=timespec)


def stamp(fmt: str = "%Y%m%d-%H%M%S") -> str:
    """Compact business-time stamp for run/batch identifiers."""
    return now().strftime(fmt)
