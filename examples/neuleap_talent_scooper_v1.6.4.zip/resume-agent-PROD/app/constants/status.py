"""Canonical status / kind vocabularies for the review system.

One definition per concept, mirrored in ``frontend/src/constants/status.ts``.
Using these enums instead of bare string literals keeps Python ↔ SQL CHECK ↔ TS
in lock-step: a typo becomes a failed import, not a silently-misrouted row.

See ``docs/MANUAL_REVIEW_IMPLEMENTATION_LOGIC.md`` §3.2.
"""
from __future__ import annotations

from enum import Enum


class CandidateStatus(str, Enum):
    """``candidate_master.status`` lifecycle vocabulary."""
    PENDING_EXTRACTION = "Pending Extraction"
    PENDING_RESUME     = "Pending Resume"
    ACTIVE             = "Active"
    REAPPLICATION      = "Reapplication Review"  # known candidate, different resume
    CLOSED             = "Closed"
    REJECTED           = "Rejected"
    HIRED              = "Hired"


class AuditStatus(str, Enum):
    """``audit_log.status`` — append-only history vocabulary."""
    SUCCESS       = "Success"
    FAILED        = "Failed"
    RETRY         = "Retry"
    EXHAUSTED     = "Exhausted"
    DISCARDED     = "Discarded"
    # Retained for history & the retry-gate side effect; the live queue no longer
    # reads audit_log, so review state lives in review_queue (see fix plan §0/P5).
    MANUAL_REVIEW = "ManualReview"
    INFO          = "Info"


class ReviewKind(str, Enum):
    """What kind of problem a ``review_queue`` row represents (drives UI + actions)."""
    INVALID_FILE    = "invalid_file"      # L1 hard validation failure
    EXCEL_ROW       = "excel_row"         # L1 excel row: bad/missing/failed link
    LINK_FETCH      = "link_fetch"        # L1 standalone link could not be fetched
    CORRUPT         = "corrupt"           # L2 integrity failure
    NOT_RESUME      = "not_resume"        # L2 identity: not a resume
    DUPLICATE       = "duplicate"         # L2 dedup: same resume re-sent
    DUPLICATE_HIRED = "duplicate_hired"   # L2 dedup: matches an already-hired candidate
    REAPPLICATION   = "reapplication"     # L2 dedup: known candidate, different resume
    EXTRACTION_FAIL = "extraction_fail"   # L3 extraction failed (candidate exists)
    FAILED          = "failed"            # generic L3/orchestrator failure
    EXHAUSTED       = "exhausted"         # automatic retries ran out

    @classmethod
    def values(cls) -> tuple[str, ...]:
        return tuple(m.value for m in cls)


class ReviewState(str, Enum):
    """``review_queue.state`` — open until a recruiter closes it."""
    OPEN      = "open"
    RESOLVED  = "resolved"
    DISCARDED = "discarded"
    APPROVED  = "approved"

    @classmethod
    def values(cls) -> tuple[str, ...]:
        return tuple(m.value for m in cls)


# Kinds a recruiter can force through L3 to create a candidate (override the verdict).
APPROVABLE_KINDS: frozenset[str] = frozenset({ReviewKind.NOT_RESUME, ReviewKind.FAILED})
# Kinds with no file yet (the link failed) — resolved by uploading a resume instead.
UPLOADABLE_KINDS: frozenset[str] = frozenset({ReviewKind.EXCEL_ROW, ReviewKind.LINK_FETCH})
