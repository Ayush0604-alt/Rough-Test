"""L3 resume extraction engine (single-call Azure OpenAI).

Flow:
1. Extract normalized text from PDF, DOCX, or image input.
2. ONE master-prompt call that returns every candidate field plus the ATS analysis
   as a single JSON object. The prompt scores the ATS FIRST and then fills the
   candidate fields consistently with it (so e.g. the course the ATS cites also
   populates highest_coursecompleted / clg / passoutyr).

The model is the source of truth for every resume FIELD. Accuracy is enforced through
the master prompt itself (authoritative "today", per-field grounding rules, an explicit
anti-hallucination contract, and a cross-consistency guarantee between the ATS and
candidate objects) — not through Python re-computation. Python sanitizes the model's
JSON: trims junk, maps enums to their allowed values, clamps numeric ranges.

The ATS SCORE is the exception: it is computed deterministically in Python by
``app.services.ats_scoring`` from the validated signals (skills, experience, education,
format, certificates) using a transparent, configurable weighted formula, with the
model's own track-fit number folded in as ONE component. ``priority`` is then derived
from that deterministic score. This keeps the number stable, auditable, and tunable.

The master prompt is NOT defined in this module: it lives in ``SKILL.md`` (the
"Master Extraction Prompt" section) and is loaded at runtime by
``_load_master_prompt()`` so it can be edited without touching code.

Self-contained: reads Azure config from environment (populated by config.py's
load_dotenv() and/or the Docker environment).
"""
import io
import json
import os
import re
import zipfile
from datetime import date
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import parse_qs, urlparse

import pdfplumber
from docx import Document
from dotenv import load_dotenv
from openai import AzureOpenAI, NotFoundError
from PIL import Image

try:
    import pytesseract
except ImportError:  # pragma: no cover
    pytesseract = None

try:
    from pdf2image import convert_from_path
except ImportError:  # pragma: no cover
    convert_from_path = None

load_dotenv()

# Default Azure deployment for the single master call (overridable via env).
# Last-resort fallback only — the live deployment comes from AZURE_OPENAI_*
# env vars (EXTRACT_DEPLOYMENT=gpt-4.1) or the endpoint URL.
DEFAULT_MASTER_DEPLOYMENT = "gpt-4.1"


# ════════════════════════════════════════════════════════════════════════════
# MASTER PROMPT (single call — ATS scored first, candidate fields kept consistent)
#
# The prompt is NOT hardcoded here. It is the single editable source of truth in
# SKILL.md (the "Master Extraction Prompt" section, between the
# MASTER_PROMPT:START / :END markers) — or a Settings-uploaded override of that
# same file (app.services.skill_config), read live (no caching) so a saved
# override or revert applies on the very next extraction with no restart.
# ════════════════════════════════════════════════════════════════════════════

def _load_master_prompt() -> str:
    """The single system prompt: ATS + candidate fields in one JSON record."""
    from app.services import skill_config
    return skill_config.master_prompt()


def _load_timeline_prompt() -> str:
    """The optional Timeline & Experience Analyzer prompt (standalone call)."""
    from app.services import skill_config
    return skill_config.timeline_prompt()


SUPPORTED_IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".tiff", ".tif", ".gif"}
# The ONLY allowed streams/tracks — must stay in sync with the Settings page's
# "Stream Definitions" (frontend STREAM_KEYWORDS) and the CandidateStream type.
# Two real hiring tracks (GenAI, Data Eng) plus the catch-all. AI-ML was folded into
# GenAI, so ML/DL/CV/NLP/data-science resumes now classify as GenAI.
STREAM_VALUES = {"GenAI", "Data Eng", "Not Relevant"}
# Recommended hiring track uses the same categories.
RECOMMENDATION_VALUES = {"GenAI", "Data Eng", "Not Relevant"}
PRIORITY_VALUES = {"P1", "P2", "P3", "P4"}
MISSING_STRINGS = {"", "unknown", "n/a", "na", "not mentioned", "none", "null"}
# Map the model's likely verbose labels back onto the canonical categories. The former
# AI-ML aliases (ML/DL/data science/CV/NLP) now resolve to GenAI.
STREAM_ALIASES = {
    "generative ai": "GenAI",
    "gen ai": "GenAI",
    "genai": "GenAI",
    "ai engineering": "GenAI",
    "llm engineering": "GenAI",
    "ai-ml": "GenAI",
    "ai/ml": "GenAI",
    "ai ml": "GenAI",
    "machine learning": "GenAI",
    "deep learning": "GenAI",
    "data science": "GenAI",
    "ml engineering": "GenAI",
    "computer vision": "GenAI",
    "nlp": "GenAI",
    "data eng": "Data Eng",
    "data engineering": "Data Eng",
    "dataengineering": "Data Eng",
    "etl": "Data Eng",
    "mlops": "Data Eng",
    "not relevant": "Not Relevant",
}

# Canonical education levels — used only to defensively normalize the model's
# highest_coursecompleted to an allowed enum value (never to recompute it).
HIGHEST_COURSE_VALUES = {"PhD", "Master", "Bachelor", "Diploma"}
_DEGREE_RANK = {"Diploma": 0, "Bachelor": 1, "Master": 2, "PhD": 3}
_DEGREE_KEYWORDS = [
    ("PhD", ("phd", "ph.d", "doctorate", "doctoral", "d.phil")),
    ("Master", (
        "master", "m.tech", "mtech", "m.e.", "m.e ", "m.sc", "msc", "m.s.",
        "mba", "mca", "m.com", "m.a.", "postgraduate", "post graduate", "post-graduate",
    )),
    ("Bachelor", (
        "bachelor", "b.tech", "btech", "b.e.", "b.e ", "b.sc", "bsc", "bca",
        "b.com", "b.a.", "undergraduate", "graduate", "graduation",
    )),
    ("Diploma", ("diploma", "polytechnic")),
]


def _empty_success(candidate_id: str) -> Dict[str, Any]:
    return {
        "status": "success",
        "candidate_id": candidate_id,
        "candidate": {
            "name": None,
            "email": None,
            "phno": None,
            "stream": None,
            "clg": None,
            "highest_coursecompleted": None,
            "education_status": None,
            "passoutyr": None,
            "cgpa": None,
            "domain": None,
            "yearofexp": None,
            "priority": None,
            "fresher_or_lateral": None,
            "total_companieswitched": 0,
            "careergap": None,
            "currentcompany": None,
            "currentlocation": None,
            "job_roles": [],
            "projects": [],
            "primary_skills": [],
            "certificates": [],
            # Structured dated timeline (LLM-extracted, verbatim) + the deterministic
            # gap/experience signals Python computes from it (app.services.timeline).
            "timeline": [],
            "experience_months": None,
            "experience_method": None,
            "experience_confidence": None,
            "gap_months": None,
            "gap_count": None,
            "gap_ranges": [],
        },
        "ats": {
            "atsscore": 0.0,
            "recommendation": None,
            "role_context": None,
            "analysis": None,
            "evidence_snippets": [],
            # Recruiter-facing 5-point screening summary (fresher/experienced, graduation
            # window, work-start & gap, company projects, vendor certifications). Model-owned.
            "analysis_report": None,
            # LLM-supplied per-component subscores (0–100 each) that drive the score.
            "score_components": None,
            # Scoring transparency (ats_scoring): per-component breakdown,
            # certificate-bonus detail, and the penalties applied.
            "score_breakdown": [],
            "certification_bonus": None,
            "score_penalties": [],
        },
    }


def _failure(candidate_id: str, reason: str) -> Dict[str, Any]:
    result = _empty_success(candidate_id)
    result["status"] = "failed"
    result["failure_reason"] = reason
    return result


def _normalize_text(text: str) -> str:
    text = text.replace("\x00", " ")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


# ── OCR policy ──────────────────────────────────────────────────────────────────
# OCR runs on EVERY PDF page and EVERY DOCX image so text living inside images
# (scanned pages, a screenshotted resume, certificate/figure images embedded in a
# DOCX) is never missed. The native text layer is still authoritative; OCR output is
# MERGED on top and de-duplicated line-by-line, so re-OCR'ing a born-digital page
# adds nothing while image-only text is captured.
#   • EXTRACTION_OCR_ALWAYS=false → revert to "OCR only sparse/image pages & files".
#   • EXTRACTION_OCR_DPI overrides the page render DPI (default 300).
_OCR_THRESHOLD = 200          # doc-level chars; below this a file is OCR'd even in auto mode
_PAGE_OCR_THRESHOLD = 100     # per-page native chars below which a page is OCR'd in auto mode
_OCR_DPI = int(os.getenv("EXTRACTION_OCR_DPI", "300") or "300")
_ALWAYS_OCR = os.getenv("EXTRACTION_OCR_ALWAYS", "true").strip().lower() in {"1", "true", "yes", "on"}
_DOCX_IMAGE_EXTS = (".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".gif")


def _pdf_ocr_available() -> bool:
    return pytesseract is not None and convert_from_path is not None


def _norm_line(line: str) -> str:
    """De-dup key for a line: lowercase, alphanumerics only. Native and OCR text of the
    same content usually differ only in spacing/punctuation, so this collapses dupes."""
    return re.sub(r"[^a-z0-9]+", "", line.lower())


def _merge_layers(primary: str, secondary: str) -> str:
    """``primary`` with any genuinely new ``secondary`` (OCR) lines appended.

    Lines already in ``primary`` (by normalized key) are dropped, so OCR over a
    born-digital page contributes nothing, while text found only inside an image is kept.
    """
    primary = (primary or "").strip()
    secondary = (secondary or "").strip()
    if not secondary:
        return primary
    if not primary:
        return secondary
    seen = {k for k in (_norm_line(l) for l in primary.splitlines()) if k}
    extra: List[str] = []
    for line in secondary.splitlines():
        key = _norm_line(line)
        if key and key not in seen:
            seen.add(key)
            extra.append(line)
    if not extra:
        return primary
    return primary + "\n" + "\n".join(extra)


def _render_pdf_pages(path: Path) -> List["Image.Image"]:
    if convert_from_path is None:
        return []
    try:
        return convert_from_path(str(path), dpi=_OCR_DPI)
    except Exception:  # noqa: BLE001 — poppler missing/failed → skip OCR, keep native text
        return []


def _ocr_image_obj(image: "Image.Image") -> str:
    if pytesseract is None:
        return ""
    try:
        return pytesseract.image_to_string(image)
    except Exception:  # noqa: BLE001 — a tesseract hiccup must not fail the whole parse
        return ""


def _ocr_pdf(path: Path) -> str:
    """Doc-level OCR of every rendered page (kept for back-compat callers)."""
    return "\n".join(_ocr_image_obj(img) for img in _render_pdf_pages(path))


def _extract_pdf(path: Path) -> str:
    """Native text (pdfplumber) MERGED with per-page OCR.

    OCR runs on every page (``_ALWAYS_OCR``) — or, when that's disabled, only on pages
    that carry images or are text-sparse. The merge keeps the native layer and adds only
    OCR lines it didn't already contain, so image-only content is captured without
    duplicating born-digital text. Falls back to native text if OCR isn't available.
    """
    with pdfplumber.open(str(path)) as pdf:
        native_pages = [page.extract_text() or "" for page in pdf.pages]
        page_has_image = [bool(page.images) for page in pdf.pages]
    native_text = "\n".join(native_pages)

    if not _pdf_ocr_available():
        return native_text

    page_images = _render_pdf_pages(path)
    if not page_images:
        return native_text

    merged: List[str] = []
    for i, native in enumerate(native_pages):
        ocr = ""
        needs_ocr = (
            _ALWAYS_OCR or page_has_image[i] or len(native.strip()) < _PAGE_OCR_THRESHOLD
        )
        if needs_ocr and i < len(page_images):
            ocr = _ocr_image_obj(page_images[i])
        merged.append(_merge_layers(native, ocr))
    return "\n".join(merged)


def _ocr_docx_images(path: Path) -> str:
    """OCR every image embedded in a .docx (the zip's ``word/media/`` parts)."""
    if pytesseract is None:
        return ""
    out: List[str] = []
    try:
        with zipfile.ZipFile(str(path)) as zf:
            media = [
                n for n in zf.namelist()
                if n.startswith("word/media/") and n.lower().endswith(_DOCX_IMAGE_EXTS)
            ]
            for name in media:
                try:
                    with zf.open(name) as fh:
                        with Image.open(io.BytesIO(fh.read())) as img:
                            text = _ocr_image_obj(img)
                    if text.strip():
                        out.append(text)
                except Exception:  # noqa: BLE001 — skip an unreadable embedded image
                    continue
    except Exception:  # noqa: BLE001 — not a zip / unreadable → no OCR, keep native text
        return ""
    return "\n".join(out)


def _extract_docx(path: Path) -> str:
    document = Document(str(path))
    parts: List[str] = []
    parts.extend(paragraph.text for paragraph in document.paragraphs)
    for table in document.tables:
        for row in table.rows:
            parts.append(" | ".join(cell.text for cell in row.cells))
    native_text = "\n".join(parts)

    # OCR every embedded image so a resume pasted/scanned into the DOCX is still read.
    if _ALWAYS_OCR or len(native_text.strip()) < _OCR_THRESHOLD:
        return _merge_layers(native_text, _ocr_docx_images(path))
    return native_text


def _extract_doc(path: Path) -> str:
    """Legacy binary .doc → .docx via LibreOffice, then reuse the DOCX extractor."""
    from app.services import doc_convert

    converted = doc_convert.convert_to_docx(path)
    if converted is None:
        raise RuntimeError(
            "legacy .doc conversion failed (LibreOffice unavailable or file unreadable)"
        )
    return _extract_docx(converted)


def _extract_image(path: Path) -> str:
    # Local Tesseract OCR.
    if pytesseract is None:
        raise RuntimeError("No OCR available: install pytesseract")
    with Image.open(path) as image:
        return pytesseract.image_to_string(image)


def extract_resume_text(file_path: str) -> Tuple[Optional[str], Optional[str]]:
    path = Path(file_path)
    suffix = path.suffix.lower()

    try:
        if suffix == ".pdf":
            text = _extract_pdf(path)
        elif suffix == ".docx":
            text = _extract_docx(path)
        elif suffix == ".doc":
            text = _extract_doc(path)
        elif suffix in SUPPORTED_IMAGE_EXTENSIONS:
            text = _extract_image(path)
        else:
            return None, f"Unsupported file type '{suffix}'"
    except Exception as exc:  # noqa: BLE001 - any parser/OCR failure maps to a caller-safe error
        return None, f"Text extraction failed: {exc}"

    normalized = _normalize_text(text)
    if not normalized:
        return None, "Text extraction produced no content"
    return normalized, None


def _azure_config(module: Optional[str] = None) -> Tuple[AzureOpenAI, Optional[str]]:
    # Settings -> LLM Model Keys: DB-stored connection (global or per-module
    # override) wins over env; env stays the fallback so the pipeline never
    # depends on the DB row existing (app.services.llm_config.resolve).
    from app.services import llm_config

    _cfg = llm_config.resolve(module)
    raw_endpoint = _cfg.get("endpoint")
    api_key = _cfg.get("api_key")
    deployment = _cfg.get("deployment")
    api_version = _cfg.get("api_version") or "2025-01-01-preview"
    _db_deployment = _cfg.get("deployment") if _cfg.get("deployment_from_db") else None

    if not raw_endpoint or not api_key:
        raise RuntimeError("AZURE_OPENAI_ENDPOINT and AZURE_OPENAI_KEY are required")

    endpoint = raw_endpoint.rstrip("/")
    parsed = urlparse(endpoint)
    deployment_match = re.search(r"/deployments/([^/]+)/", parsed.path)
    if deployment_match:
        deployment = deployment or deployment_match.group(1)
        endpoint = f"{parsed.scheme}://{parsed.netloc}"
        query_version = parse_qs(parsed.query).get("api-version")
        if query_version:
            api_version = query_version[0]

    if not deployment:
        deployment = os.getenv("AZURE_OPENAI_MODEL")

    client = AzureOpenAI(
        api_key=api_key,
        azure_endpoint=endpoint,
        api_version=api_version,
    )
    # A deployment picked in Settings is explicit admin intent - hand it back
    # marked so _resolve_master_deployment lets it beat the env-var chain.
    return client, (_db_deployment or deployment)


def _resolve_master_deployment(default_deployment: Optional[str], module: Optional[str] = None) -> str:
    """Resolve the deployment for the single master call. A deployment stored
    in Settings -> LLM Model Keys (global or for this module) wins; otherwise
    the historical env-var chain applies."""
    try:
        from app.services import llm_config

        _cfg = llm_config.resolve(module)
        if _cfg.get("deployment_from_db") and _cfg.get("deployment"):
            return _cfg["deployment"]
    except Exception:  # noqa: BLE001 - env chain below keeps working regardless
        pass
    deployment = (
        os.getenv("AZURE_OPENAI_MASTER_DEPLOYMENT")
        or os.getenv("AZURE_OPENAI_EXTRACT_DEPLOYMENT")
        or os.getenv("AZURE_OPENAI_ATS_DEPLOYMENT")
        or os.getenv("AZURE_OPENAI_DEPLOYMENT")
        or default_deployment
        or DEFAULT_MASTER_DEPLOYMENT
    )
    if not deployment:
        raise RuntimeError(
            "A master deployment is required (set AZURE_OPENAI_DEPLOYMENT or embed "
            "/deployments/{name}/ in AZURE_OPENAI_ENDPOINT)."
        )
    return deployment


def _parse_json_object(content: str) -> Dict[str, Any]:
    content = content.strip()
    if content.startswith("```"):
        content = re.sub(r"^```(?:json)?", "", content, flags=re.IGNORECASE).strip()
        content = re.sub(r"```$", "", content).strip()

    try:
        return json.loads(content)
    except json.JSONDecodeError:
        start = content.find("{")
        end = content.rfind("}")
        if start == -1 or end == -1 or end <= start:
            raise
        return json.loads(content[start : end + 1])


def _is_reasoning_deployment(deployment: str) -> bool:
    # o-series (o1/o3/o4) and the GPT-5 family are reasoning deployments: they
    # reject a non-default `temperature`, so we must omit it for them.
    d = deployment.lower()
    return bool(re.match(r"^o\d", d)) or bool(re.match(r"^gpt-5", d))


def _usage_dict(response: Any, deployment: str) -> Dict[str, Any]:
    """Pull token usage off an Azure response, defensively (usage may be absent)."""
    usage = getattr(response, "usage", None)
    return {
        "prompt_tokens": getattr(usage, "prompt_tokens", None),
        "completion_tokens": getattr(usage, "completion_tokens", None),
        "total_tokens": getattr(usage, "total_tokens", None),
        "deployment": deployment,
    }


def _chat_json(
    *,
    client: AzureOpenAI,
    deployment: str,
    system_prompt: str,
    user_payload: Dict[str, Any],
    candidate_id: Optional[str] = None,
    temperature: float = 0,
    # Which app feature this call serves - one row per call lands in the
    # llm_token_usage ledger under this key (Admin -> Token Usage page).
    module: str = "extraction",
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """Run the master call and return ``(parsed_json, usage)``.

    ``usage`` carries prompt/completion/total token counts (or None when the
    provider omits them) plus the deployment that actually served the request.
    The call is also traced to Langfuse when configured (no-op otherwise).

    ``temperature`` defaults to 0 (deterministic extraction); callers that want
    varied output across identical inputs — e.g. regenerating an interview kit —
    pass a higher value. Reasoning deployments ignore it (they reject non-default
    temperatures), so they stay deterministic regardless.
    """
    request: Dict[str, Any] = {
        "model": deployment,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": json.dumps(user_payload, ensure_ascii=False)},
        ],
        "response_format": {"type": "json_object"},
    }
    if not _is_reasoning_deployment(deployment):
        request["temperature"] = temperature

    from app.services import langfuse_client

    with langfuse_client.generation(
        name="l3-extraction",
        session_id=candidate_id,
        model=deployment,
        input=user_payload,
        metadata={"candidate_id": candidate_id},
    ) as gen:
        try:
            response = client.chat.completions.create(**request)
        except NotFoundError:
            from app.services import llm_config as _llm_cfg

            fallback_deployment = _llm_cfg.resolve().get("fallback_deployment")
            if not fallback_deployment or fallback_deployment == deployment:
                raise
            request["model"] = fallback_deployment
            if _is_reasoning_deployment(fallback_deployment):
                request.pop("temperature", None)
            else:
                request["temperature"] = temperature
            response = client.chat.completions.create(**request)
            deployment = fallback_deployment

        content = response.choices[0].message.content or "{}"
        usage = _usage_dict(response, deployment)
        try:  # ledger write is best-effort telemetry - never blocks the call
            from app.services import token_usage

            token_usage.record(
                module=module,
                model=usage.get("deployment") or deployment,
                prompt_tokens=usage.get("prompt_tokens"),
                completion_tokens=usage.get("completion_tokens"),
                total_tokens=usage.get("total_tokens"),
                candidate_id=candidate_id,
            )
        except Exception:  # noqa: BLE001
            pass
        gen.record(
            output=content,
            prompt_tokens=usage["prompt_tokens"],
            completion_tokens=usage["completion_tokens"],
            total_tokens=usage["total_tokens"],
        )

    return _parse_json_object(content), usage


# ── Output sanitization (validation only — never recomputes a field value) ──────

def _clean_scalar(value: Any) -> Any:
    if isinstance(value, str):
        stripped = value.strip()
        if stripped.lower() in MISSING_STRINGS:
            return None
        return stripped
    return value


def _clean_list(value: Any, limit: int) -> List[Any]:
    if not isinstance(value, list):
        return []
    cleaned = []
    for item in value:
        if isinstance(item, str):
            scalar = _clean_scalar(item)
            if scalar is not None:
                cleaned.append(scalar)
        elif isinstance(item, dict):
            cleaned.append({str(k): _clean_scalar(v) for k, v in item.items()})
        elif item is not None:
            cleaned.append(item)
    return cleaned[:limit]


def _float_or_none(value: Any) -> Optional[float]:
    value = _clean_scalar(value)
    if value is None:
        return None
    try:
        return round(float(value), 1)
    except (TypeError, ValueError):
        return None


def _int_or_none(value: Any) -> Optional[int]:
    value = _clean_scalar(value)
    if value is None:
        return None
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return None


def _priority_from_score(score: float) -> str:
    """Map a 0–100 atsscore to its P-band. Thresholds are configurable on the
    Settings page (scoring_config); defaults are P1>=85, P2>=70, P3>=55, else P4."""
    try:
        from app.services import scoring_config
        return scoring_config.priority_for(score)
    except Exception:  # noqa: BLE001 — a config hiccup must never break extraction
        if score >= 85:
            return "P1"
        if score >= 70:
            return "P2"
        if score >= 55:
            return "P3"
        return "P4"


def _allowed_value(
    value: Any,
    allowed_values: set,
    aliases: Optional[Dict[str, str]] = None,
) -> Optional[str]:
    value = _clean_scalar(value)
    if not isinstance(value, str):
        return None

    lowered = value.lower()
    if aliases and lowered in aliases:
        return aliases[lowered]

    for allowed in allowed_values:
        if lowered == allowed.lower():
            return allowed
    return None


def _bucketed_category(value: Any) -> Optional[str]:
    """Snap a stream/recommendation to one of the canonical categories.

    A value that resolves (directly or via alias) to GenAI/Data Eng is kept; any other
    non-empty label (including the retired AI-ML, which now aliases to GenAI) becomes
    "Not Relevant" only when it matches nothing. Only a truly missing value stays None.
    """
    resolved = _allowed_value(value, STREAM_VALUES, STREAM_ALIASES)
    if resolved:
        return resolved
    return "Not Relevant" if _clean_scalar(value) is not None else None


def _normalize_job_roles(value: Any) -> List[Dict[str, Any]]:
    """Coerce job_roles into the canonical ``[{role, company, months}]`` shape.

    Validation only — never invents a role/company. Tolerates the legacy form (a list
    of plain title strings) by mapping each to ``{role, company: None, months: None}``.
    """
    if not isinstance(value, list):
        return []
    out: List[Dict[str, Any]] = []
    for item in value:
        if isinstance(item, dict):
            role = _clean_scalar(item.get("role") or item.get("title"))
            company = _clean_scalar(item.get("company") or item.get("employer"))
            months = _int_or_none(item.get("months"))
            if role or company:
                out.append({"role": role, "company": company, "months": months})
        elif isinstance(item, str):
            role = _clean_scalar(item)
            if role:
                out.append({"role": role, "company": None, "months": None})
    return out[:10]


def _dedupe_skills(skills: List[Any]) -> List[str]:
    """Case-insensitively de-duplicate the skill list, keeping first-seen casing/order.

    Matches on a normalized key (lowercased, punctuation/space stripped) so "Node.js" and
    "nodejs", or "Postgre SQL" and "PostgreSQL", collapse to a single pill. Non-string
    entries are dropped — primary_skills is a flat string list.
    """
    seen: set = set()
    out: List[str] = []
    for item in skills:
        if not isinstance(item, str):
            continue
        label = item.strip()
        if not label:
            continue
        key = re.sub(r"[^a-z0-9]", "", label.lower())
        if not key or key in seen:
            continue
        seen.add(key)
        out.append(label)
    return out


def _normalize_domain(value: Any, job_roles: List[Dict[str, Any]]) -> Optional[str]:
    """Keep ``domain`` a single ROLE label, never a comma-separated skill list.

    When the LLM returns a list (commas / slashes / 'and'-joined focus areas), prefer the
    candidate's most-recent extracted job title; if none exists, fall back to the first
    listed segment. Single-value domains pass through unchanged.
    """
    value = _clean_scalar(value)
    if not value:
        return None
    looks_like_list = bool(re.search(r",|/|\band\b|;", value))
    if not looks_like_list:
        return value
    for role in job_roles:
        title = _clean_scalar(role.get("role"))
        if title:
            return title
    first = re.split(r"\s*[,/;]\s*|\s+\band\b\s+", value)[0].strip()
    return first or value


def _count_job_changes(job_roles: List[Dict[str, Any]]) -> Optional[int]:
    """Number of job changes = (count of roles) − 1 (>=0).

    Deterministic replacement for the LLM's self-reported ``total_companieswitched``,
    derived from the same job_roles the candidate timeline shows so the two can never
    disagree (the LLM count is unreliable). Returns None when there are no roles, so
    the caller can keep the LLM value as a fallback.
    """
    if not job_roles:
        return None
    return max(0, len(job_roles) - 1)


def _normalize_certificates(value: Any) -> List[Dict[str, Any]]:
    """Coerce certificates into the canonical ``[{name, issuer, year}]`` shape.

    Validation only — never invents a certificate. Drops entries with no name,
    clamps an implausible year to None, and tolerates the legacy form (a list of
    plain title strings) by mapping each to ``{name, issuer: None, year: None}``.
    """
    if not isinstance(value, list):
        return []
    today_year = date.today().year
    out: List[Dict[str, Any]] = []
    for item in value:
        if isinstance(item, dict):
            name = _clean_scalar(
                item.get("name") or item.get("title") or item.get("certificate")
            )
            if not name:
                continue
            issuer = _clean_scalar(
                item.get("issuer") or item.get("organization") or item.get("provider")
            )
            year = _int_or_none(
                item.get("year") or item.get("date") or item.get("year_earned")
            )
            if year is not None and not (2000 <= year <= today_year + 1):
                year = None
            out.append({"name": name, "issuer": issuer, "year": year})
        elif isinstance(item, str):
            name = _clean_scalar(item)
            if name:
                out.append({"name": name, "issuer": None, "year": None})
    return out[:10]


# The five fixed keys of the recruiter-facing Analysis Report (ats.analysis_report).
# Order is the display order on the candidate profile.
_ANALYSIS_REPORT_KEYS = (
    "experience_level",
    "graduation_and_window",
    "work_start_and_gap",
    "company_projects",
    "professional_certifications",
)


def _normalize_analysis_report(value: Any) -> Optional[Dict[str, Any]]:
    """Coerce the LLM's analysis_report into a fixed-key string map.

    Validation only — never invents text. Keeps exactly the five known keys, trims each
    to a clean string (or None), and returns None when the model emitted nothing usable so
    the card is simply hidden rather than rendered empty.
    """
    if not isinstance(value, dict):
        return None
    out: Dict[str, Any] = {}
    for key in _ANALYSIS_REPORT_KEYS:
        out[key] = _clean_scalar(value.get(key))
    return out if any(out[k] for k in _ANALYSIS_REPORT_KEYS) else None


_TIMELINE_TYPES = {
    "education", "internship", "job", "freelance", "contract",
    "apprenticeship", "trainee", "traineeship", "articleship", "research", "training",
}
_TIMELINE_CONFIDENCE = {"high", "medium", "low"}


def _normalize_timeline(value: Any) -> List[Dict[str, Any]]:
    """Coerce the LLM's timeline into the canonical dated-activity shape.

    Validation only — never invents an entry or a date. Keeps dates as the raw strings
    the model copied (``"YYYY-MM"`` / ``"YYYY"`` / null); ALL date math happens later in
    :mod:`app.services.timeline`. Drops entries with neither a usable type nor any date.
    """
    if not isinstance(value, list):
        return []
    out: List[Dict[str, Any]] = []
    for item in value:
        if not isinstance(item, dict):
            continue
        atype = _clean_scalar(item.get("activity_type"))
        atype = atype.lower() if isinstance(atype, str) and atype.lower() in _TIMELINE_TYPES else atype
        start = _clean_scalar(item.get("start_date"))
        end = _clean_scalar(item.get("end_date"))
        is_current = bool(item.get("is_current"))
        if not atype and not start and not end:
            continue
        conf = _clean_scalar(item.get("confidence"))
        conf = conf.lower() if isinstance(conf, str) and conf.lower() in _TIMELINE_CONFIDENCE else None
        out.append({
            "activity_type": atype,
            "organization": _clean_scalar(item.get("organization") or item.get("company")),
            "title": _clean_scalar(item.get("title") or item.get("role") or item.get("degree")),
            "start_date": start,
            "end_date": end if not is_current else (end or "Present"),
            "is_current": is_current,
            "confidence": conf,
            "source_text": _clean_scalar(item.get("source_text")),
        })
    return out[:30]


def _normalize_highest_course(value: Any) -> Optional[str]:
    """Map the model's degree string to an allowed enum (PhD/Master/Bachelor/Diploma)."""
    value = _clean_scalar(value)
    if not isinstance(value, str):
        return None
    for canon in HIGHEST_COURSE_VALUES:
        if value.lower() == canon.lower():
            return canon
    lowered = f" {value.lower()} "
    best: Optional[str] = None
    for canon, keywords in _DEGREE_KEYWORDS:
        if any(k in lowered for k in keywords) and (
            best is None or _DEGREE_RANK[canon] > _DEGREE_RANK[best]
        ):
            best = canon
    return best


def _normalize_llm_result(payload: Dict[str, Any], candidate_id: str) -> Dict[str, Any]:
    """Sanitize the master call's JSON into the canonical record shape.

    This is validation, not computation: the model owns every field value. Here we
    only strip junk strings, coerce types, snap enums to their allowed values, and
    clamp numeric ranges so a stray/malformed value can't corrupt the row.
    """
    result = _empty_success(candidate_id)
    source_candidate = (
        payload.get("candidate") if isinstance(payload.get("candidate"), dict) else {}
    )
    source_ats = payload.get("ats") if isinstance(payload.get("ats"), dict) else {}
    candidate = result["candidate"]
    ats = result["ats"]

    _managed = {
        "job_roles", "projects", "primary_skills", "certificates",
        # gap/experience fields are owned by the deterministic timeline compute below.
        "timeline", "experience_months", "experience_method", "experience_confidence",
        "gap_months", "gap_count", "gap_ranges",
    }
    for key in candidate:
        if key in _managed:
            continue
        candidate[key] = _clean_scalar(source_candidate.get(key))

    # stream/recommendation are restricted to the four Settings categories; an
    # unrecognized-but-present label falls to "Not Relevant" (the catch-all bucket),
    # not null, so every classified candidate carries a valid category.
    candidate["stream"] = _bucketed_category(candidate["stream"])
    candidate["highest_coursecompleted"] = _normalize_highest_course(
        candidate["highest_coursecompleted"]
    )
    candidate["education_status"] = _allowed_value(
        candidate["education_status"], {"completed", "pursuing"}
    )
    candidate["fresher_or_lateral"] = _allowed_value(
        candidate["fresher_or_lateral"], {"Fresher", "Lateral"}
    )
    candidate["yearofexp"] = _float_or_none(candidate["yearofexp"])
    # careergap: "None" is a MEANINGFUL value (no gap) — _clean_scalar nulls it via
    # MISSING_STRINGS, so restore the explicit "None" default (never leave it empty).
    candidate["careergap"] = candidate.get("careergap") or "None"
    candidate["passoutyr"] = _int_or_none(candidate["passoutyr"])
    # cgpa: the highest degree's CGPA/GPA on its native scale. Keep only a plausible
    # 0 < x ≤ 10 value — anything larger is almost certainly a percentage the model
    # mistook for a grade-point, so null it rather than persist a bogus "85.0".
    candidate["cgpa"] = _float_or_none(candidate["cgpa"])
    if candidate["cgpa"] is not None and not (0 < candidate["cgpa"] <= 10):
        candidate["cgpa"] = None
    candidate["job_roles"] = _normalize_job_roles(source_candidate.get("job_roles"))
    # domain is a SINGLE role title (e.g. "Data Engineer"), never a skill list. The LLM
    # occasionally emits a comma-separated list of focus areas/tools instead — collapse it
    # to the candidate's actual role (most-recent job title when available, else the first
    # listed segment) so the profile's "Domain" stays a clean role label.
    candidate["domain"] = _normalize_domain(candidate.get("domain"), candidate["job_roles"])
    # Switches = number of job changes = (count of roles) − 1, computed
    # deterministically from job_roles. The LLM's own count is unreliable; only fall
    # back to it when no roles were extracted.
    _computed_switches = _count_job_changes(candidate["job_roles"])
    candidate["total_companieswitched"] = (
        _computed_switches
        if _computed_switches is not None
        else _int_or_none(candidate["total_companieswitched"]) or 0
    )
    candidate["projects"] = _clean_list(source_candidate.get("projects"), 5)
    # ALL skills the resume lists (not just the top few) — capped generously to guard
    # against runaway output, but high enough to keep a full skill set. De-duped
    # case-insensitively so casing variants ("PySpark"/"pyspark") collapse to one pill.
    candidate["primary_skills"] = _dedupe_skills(
        _clean_list(source_candidate.get("primary_skills"), 40)
    )
    candidate["certificates"] = _normalize_certificates(source_candidate.get("certificates"))

    # ── Career gap vs. Year of experience — computed DETERMINISTICALLY and
    # INDEPENDENTLY from the LLM's structured timeline (it extracts dates verbatim;
    # Python does the date math). The two signals never infer each other; each lands in
    # its own field. This OWNS yearofexp / careergap (the LLM's prose estimate is only a
    # fallback if the deterministic compute ever errors). ──
    candidate["timeline"] = _normalize_timeline(source_candidate.get("timeline"))
    computed_signals: Optional[Dict[str, Any]] = None
    try:
        from app.services import timeline as timeline_svc
        # ONE runtime date for this resume: every "Present"/"Current"/"Now" resolves to it
        # (clock-anchored), and the same date drives experience, gaps, and the narrative —
        # so no two modules can resolve an open-ended role differently.
        run_date = timeline_svc.current_date()
        candidate["timeline"] = timeline_svc.annotate_resolved(candidate["timeline"], run_date)
        signals = timeline_svc.compute(candidate["timeline"], today=run_date)
        computed_signals = signals
        candidate["experience_months"] = signals["experience_months"]
        candidate["yearofexp"] = signals["yearofexp"]
        candidate["experience_method"] = signals["experience_method"]
        candidate["experience_confidence"] = signals["experience_confidence"]
        candidate["gap_months"] = signals["gap_months"]
        candidate["gap_count"] = signals["gap_count"]
        candidate["gap_ranges"] = signals["gap_ranges"]
        candidate["careergap"] = signals["careergap"]
        # Only override fresher/lateral when experience is determinate (else keep LLM's).
        if signals["fresher_or_lateral"] is not None:
            candidate["fresher_or_lateral"] = signals["fresher_or_lateral"]
        # Company History / Career Timeline must reconcile with yearofexp, so derive
        # job_roles from the SAME qualifying work entries the experience total is built
        # from. The LLM's separate job_roles is only a fallback (kept when the timeline
        # has no usable work entries) — it's the field that drifted out of agreement.
        if signals.get("work_roles"):
            candidate["job_roles"] = _normalize_job_roles(signals["work_roles"])
    except Exception:  # noqa: BLE001 — deterministic compute must never break extraction
        # Fall back to the LLM's prose values already sitting in yearofexp / careergap.
        pass

    # Clamp an implausible graduation year rather than persist garbage.
    yr = candidate["passoutyr"]
    if yr is not None and not (1950 <= yr <= date.today().year + 6):
        candidate["passoutyr"] = None

    ats["recommendation"] = _bucketed_category(source_ats.get("recommendation"))
    ats["role_context"] = _clean_scalar(source_ats.get("role_context"))
    ats["analysis"] = _clean_scalar(source_ats.get("analysis"))
    ats["evidence_snippets"] = _clean_list(source_ats.get("evidence_snippets"), 10)
    ats["analysis_report"] = _normalize_analysis_report(source_ats.get("analysis_report"))

    # The LLM's holistic track-fit number, kept as the fallback's llm_fit component and
    # mirrored into score_components.llm_fit when the model omits it.
    llm_fit = max(0.0, min(100.0, _float_or_none(source_ats.get("atsscore")) or 0.0))

    # The LLM now rates ALL FIVE component subscores plus penalties + certificate bonus
    # (score_components / score_penalties / certification_bonus). Python keeps the
    # recruiter-configurable weights, the final arithmetic, and the safety clamps. When the
    # model omits score_components we fall back to the legacy deterministic compute_score, so
    # a config/data/schema hiccup can never break extraction.
    components = source_ats.get("score_components")
    if isinstance(components, dict):
        ats["score_components"] = components
    try:
        from app.services import ats_scoring
        if isinstance(components, dict) and components:
            # Default llm_fit to the holistic atsscore if the model only filled that.
            components.setdefault("llm_fit", llm_fit)
            scored = ats_scoring.score_from_llm(
                components,
                source_ats.get("score_penalties"),
                source_ats.get("certification_bonus"),
            )
        else:
            scored = ats_scoring.compute_score(candidate, ats, llm_fit=llm_fit)
        ats["atsscore"] = scored["score"]
        ats["score_breakdown"] = scored["breakdown"]
        ats["certification_bonus"] = scored["certification_bonus"]
        ats["score_penalties"] = scored["penalties"]
        ats["analysis"] = ats_scoring.merge_explanation(ats["analysis"], scored["explanation"])
    except Exception:  # noqa: BLE001 — scoring must never break extraction
        ats["atsscore"] = llm_fit

    # ── Narrative reconciliation — the analysis is DOWNSTREAM of the computed signals
    # and may never contradict them. Drop any sentence that claims "no gaps" when a gap
    # was computed (or invents one when there is none / disagrees on tenure) and append an
    # authoritative computed-signals statement. Runs LAST so it governs the full text. ──
    if computed_signals is not None:
        try:
            from app.services import timeline as timeline_svc
            ats["analysis"] = timeline_svc.reconcile_analysis(ats["analysis"], computed_signals)
        except Exception:  # noqa: BLE001 — reconciliation must never break extraction
            pass

    # Snap priority to its score band so the label can never drift from the score.
    candidate["priority"] = _priority_from_score(ats["atsscore"])

    return result


def _today_payload() -> Dict[str, Any]:
    """The authoritative current date, broken out so the model cannot misparse it.

    ALL date math (durations, gaps, completion) must use these values, never the
    model's stale notion of "now". Sourced from the SAME clock-anchored runtime date as
    the deterministic timeline engine (app.services.timeline.current_date) so the model's
    "Present" reading and Python's computation can never resolve to different days.
    """
    try:
        from app.services import timeline as timeline_svc
        today = timeline_svc.current_date()
    except Exception:  # noqa: BLE001 — never block extraction on a clock hiccup
        today = date.today()
    return {
        "today": today.isoformat(),                  # e.g. "2026-06-14"
        "current_year": today.year,                  # e.g. 2026
        "current_month": today.month,                # 1-12, e.g. 6
        "current_month_name": today.strftime("%B"),  # e.g. "June"
        "current_day": today.day,                    # 1-31, e.g. 14
    }


# ── Analysis Report instruction (plugged in from CODE, not SKILL.md) ────────────
# A recruiter-facing 5-point screening summary appended to the master system prompt
# at runtime (the same mechanism as scoring_config.prompt_hint), so the SINGLE master
# call also returns ats.analysis_report — without editing the SKILL.md master prompt.
_ANALYSIS_REPORT_INSTRUCTION = """

ADDITIONAL OUTPUT — ats.analysis_report (a recruiter-facing 5-point screening summary)
In ADDITION to every field above, add an "analysis_report" object inside the "ats" object
with EXACTLY these five string keys. Each value is a SHORT paragraph (1–3 sentences,
≤ 60 words), grounded ONLY in the resume and CONSISTENT with the candidate fields and the
ATS you already wrote. Never fabricate; when the resume is silent on a point, say so
plainly. Set a key to null ONLY when there is truly no signal.
  "analysis_report": {
    "experience_level": "Is the candidate FRESHER or EXPERIENCED, and why? Internships,
       traineeships, and apprenticeships are NOT professional experience — a candidate
       whose only roles are internships/trainee positions is a Fresher. Name the
       qualifying full-time role(s) and rough tenure when experienced. MUST agree with
       candidate.fresher_or_lateral.",
    "graduation_and_window": "The bachelor's (or highest undergraduate) completion year,
       and the years to consider since then (current_year − passoutyr). MUST agree with
       candidate.passoutyr / candidate.years_to_consider.",
    "work_start_and_gap": "When did the candidate first start at a real firm in a
       qualifying full-time role, and is there a gap between graduation and that first
       job? State 'No gap' or the gap length; 'Not applicable' for a fresher. MUST agree
       with candidate.post_degree_gap_months.",
    "company_projects": "Summarize the projects EXPLICITLY attributed to a company the
       candidate worked at — the tech stack evidenced and any quantified outcomes. If
       there are NO company projects, say so (personal/academic projects do NOT count).",
    "professional_certifications": "List the INDUSTRY-GRADE vendor certifications only
       (Databricks, Microsoft/Azure/Fabric, AWS, GCP, Snowflake, etc.). Course
       completions/bootcamps (Udemy, Coursera, Infosys, etc.) do NOT count. State 'None'
       when there is no qualifying vendor certification."
  }
Replace each placeholder above with the actual answer for THIS candidate. Keep the five
keys exactly as named.
"""


def _run_master(
    *,
    client: AzureOpenAI,
    deployment: str,
    candidate_id: str,
    resume_text: str,
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """Single-call extraction: ONE prompt that scores the ATS first, then fills the
    candidate fields consistently with it. Returns ``(payload, usage)`` where
    ``payload`` is the combined ``{"candidate": ..., "ats": ...}`` object that
    :func:`_normalize_llm_result` expects and ``usage`` is the token-usage dict.
    """
    # Append the recruiter-configured stream-classification hints (Settings page).
    system_prompt = _load_master_prompt()
    try:
        from app.services import scoring_config
        system_prompt += scoring_config.prompt_hint()
    except Exception:  # noqa: BLE001 — hints are optional; never block extraction
        pass
    # Plug in the Analysis Report prompt — its own SKILL.md section/marker pair,
    # independently overridable/revertible from Settings (app.services.skill_config).
    from app.services import skill_config
    system_prompt += "\n\n" + skill_config.active_analysis_prompt()

    return _chat_json(
        client=client,
        deployment=deployment,
        system_prompt=system_prompt,
        user_payload={
            "candidate_id": candidate_id,
            **_today_payload(),
            "resume_text": resume_text,
        },
        candidate_id=candidate_id,
    )


# ── Analysis-Report-ONLY regeneration ────────────────────────────────────────
# A lighter-weight sibling to the full master extraction: re-runs JUST the
# Analysis Report narrative (e.g. after editing its prompt in Settings), never
# touching any other candidate_master field. Grounded in the candidate's
# ALREADY-extracted fields so the regenerated text stays consistent with them
# (same agreement rules the master prompt enforces), without re-deriving those
# fields — no fresher/lateral, passoutyr, yearofexp, etc. change as a result.
_ANALYSIS_ONLY_WRAPPER = """
You are re-generating ONLY the "analysis_report" field for a candidate whose
other profile fields have ALREADY been extracted and are given below as
ground truth in "already_extracted_fields" — your analysis_report MUST agree
with them (e.g. do not call someone a Fresher if fresher_or_lateral says
Lateral). Return JSON with EXACTLY this shape and nothing else:
{"analysis_report": {"experience_level": "...", "graduation_and_window": "...",
"work_start_and_gap": "...", "company_projects": "...",
"professional_certifications": "..."}}

""".strip() + "\n\n"

_ANALYSIS_ONLY_CONTEXT_FIELDS = (
    "name", "stream", "fresher_or_lateral", "yearofexp", "passoutyr",
    "currentcompany", "job_roles", "domain", "atsscore",
)


def regenerate_analysis_report_only(candidate_id: str, candidate_row: Dict[str, Any], resume_text: str) -> Dict[str, Any]:
    """Returns ``{"analysis_report": <normalized dict or None>, "usage": {...}}``.

    Raises whatever ``_azure_config``/``_chat_json`` raise (e.g. missing Azure
    credentials) — unlike the full extraction path there is no deterministic
    fallback for narrative text, so callers must handle/report the failure."""
    from app.services import skill_config

    client, default_deployment = _azure_config()
    deployment = _resolve_master_deployment(default_deployment)
    system_prompt = _ANALYSIS_ONLY_WRAPPER + skill_config.active_analysis_prompt()
    already_extracted = {k: candidate_row.get(k) for k in _ANALYSIS_ONLY_CONTEXT_FIELDS}

    payload, usage = _chat_json(
        client=client,
        deployment=deployment,
        system_prompt=system_prompt,
        user_payload={
            "candidate_id": candidate_id,
            **_today_payload(),
            "already_extracted_fields": already_extracted,
            "resume_text": resume_text,
        },
        candidate_id=candidate_id,
        module="analysis_report",
    )
    analysis_report = _normalize_analysis_report((payload or {}).get("analysis_report"))
    return {"analysis_report": analysis_report, "usage": usage}


def run(file_path: str, candidate_id: str, pre_text: Optional[str] = None) -> Dict[str, Any]:
    # When L2 already captured the FULL text (pre_text), reuse it instead of re-extracting
    # — the file isn't OCR'd twice. Otherwise extract (with OCR) from the file as usual.
    if pre_text and pre_text.strip():
        resume_text, extraction_error = pre_text, None
    else:
        resume_text, extraction_error = extract_resume_text(file_path)
    if extraction_error:
        return _failure(candidate_id, extraction_error)

    try:
        client, default_deployment = _azure_config()
        deployment = _resolve_master_deployment(default_deployment)
        payload, usage = _run_master(
            client=client,
            deployment=deployment,
            candidate_id=candidate_id,
            resume_text=resume_text or "",
        )
    except Exception as exc:  # noqa: BLE001 - any LLM/Azure failure becomes a failed result row
        return _failure(candidate_id, f"Master LLM extraction failed: {exc}")

    result = _normalize_llm_result(payload, candidate_id)
    result["usage"] = usage
    return result


def _empty_timeline(candidate_id: str) -> Dict[str, Any]:
    """Fully-shaped empty timeline result (mirrors the TIMELINE_PROMPT schema)."""
    return {
        "status": "success",
        "candidate_id": candidate_id,
        "candidate_name": None,
        "timeline_entries": [],
        "gaps": {
            "total_gap_months": 0,
            "total_gap_years": 0.0,
            "gap_count": 0,
            "gap_ranges": [],
            "verified_or_unknown": "verified",
        },
        "total_years_of_experience": 0.0,
        "total_gap_duration": "None",
        "analysis_text": None,
        "confidence": None,
    }


def analyze_timeline(file_path: str, candidate_id: str = "TIMELINE") -> Dict[str, Any]:
    """Optional, standalone timeline & experience analysis (model-owned, no DB write).

    Extracts the resume text (same local PDF/DOCX/OCR path as :func:`run`) and makes a
    SINGLE Azure call with the Timeline & Experience Analyzer prompt. The LLM does all
    the date math; Python only shapes/guards the envelope — it never recomputes gaps or
    experience. Returns the parsed timeline JSON merged onto :func:`_empty_timeline`
    (so callers can read every key without null-checking), plus ``usage``. Any
    text/LLM failure comes back as ``{"status": "failed", "failure_reason": ...}``.
    """
    resume_text, extraction_error = extract_resume_text(file_path)
    if extraction_error:
        failed = _empty_timeline(candidate_id)
        failed["status"] = "failed"
        failed["failure_reason"] = extraction_error
        return failed

    try:
        client, default_deployment = _azure_config()
        deployment = _resolve_master_deployment(default_deployment)
        payload, usage = _chat_json(
            client=client,
            deployment=deployment,
            system_prompt=_load_timeline_prompt(),
            user_payload={
                "candidate_id": candidate_id,
                **_today_payload(),
                "resume_text": resume_text or "",
            },
            candidate_id=candidate_id,
            module="timeline",
        )
    except Exception as exc:  # noqa: BLE001 — any LLM/Azure failure becomes a failed result
        failed = _empty_timeline(candidate_id)
        failed["status"] = "failed"
        failed["failure_reason"] = f"Timeline LLM analysis failed: {exc}"
        return failed

    result = _empty_timeline(candidate_id)
    if isinstance(payload, dict):
        for key in (
            "candidate_name", "timeline_entries", "gaps",
            "total_years_of_experience", "total_gap_duration",
            "analysis_text", "confidence",
        ):
            if payload.get(key) is not None:
                result[key] = payload[key]
    result["usage"] = usage
    return result
