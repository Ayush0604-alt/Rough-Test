"""Bridge from a stored candidate row to the L3 extraction engine.

Used by the L2 auto-chain and by the manual extraction endpoints: download the
candidate's clean resume from MinIO, run the two-stage LLM, write the result
back onto candidate_master.
"""
from __future__ import annotations

import contextlib
import logging
import os
from typing import Any, Dict

from app.db import (
    get_candidate,
    pop_intake_excel_columns,
    update_candidate_analysis_report,
    update_candidate_from_result,
)
from app.extraction.engine import _failure, regenerate_analysis_report_only, run
from app.services.s3 import download_resume_to_temp

logger = logging.getLogger(__name__)


def _attach_excel_columns(row: Dict[str, Any], result: Dict[str, Any]) -> None:
    """When this candidate's resume came from an Excel intake row, attach that
    row's original columns to the extraction result as ``source_columns`` (keyed
    ``<header>__from-source-sheet``) and let an Excel CGPA OVERRIDE the resume-
    extracted one — the sheet is the source of truth, the resume value is kept as
    ``CGPA__from-resume``. Mutates ``result`` in place; a no-op for non-Excel rows."""
    e_id = row.get("e_id")
    stored_name = (row.get("s3_file_path") or "").rsplit("/", 1)[-1]
    try:
        row_cells = pop_intake_excel_columns(e_id, stored_name)
    except Exception as exc:  # noqa: BLE001 — never fail extraction over the side-channel
        logger.warning("[L3] excel-columns lookup failed for %s: %s", row.get("candidate_id"), exc)
        return
    if not row_cells:
        return

    source_cols: Dict[str, Any] = {}
    excel_cgpa = None
    for header, value in row_cells.items():
        key = (header or "").strip()
        if not key:
            continue
        source_cols[f"{key}__from-source-sheet"] = value
        # A CGPA/GPA column is the source of truth — parse + range-guard exactly
        # like the resume extractor (0 < x ≤ 10). A percentage that slipped in
        # stays a plain source column but is NOT used as the candidate's cgpa.
        norm = "".join(ch for ch in key.lower() if ch.isalnum())
        if excel_cgpa is None and ("cgpa" in norm or norm == "gpa"):
            try:
                v = float(str(value).strip())
                if 0 < v <= 10:
                    excel_cgpa = v
            except (TypeError, ValueError):
                pass

    candidate = result.get("candidate")
    if excel_cgpa is not None and isinstance(candidate, dict):
        if candidate.get("cgpa") is not None:
            source_cols["CGPA__from-resume"] = candidate.get("cgpa")
        candidate["cgpa"] = excel_cgpa

    result["source_columns"] = source_cols


def extract_candidate(candidate_id: str) -> Dict[str, Any]:
    """Run L3 extraction for an existing candidate_master row.

    Raises KeyError if the candidate or its s3_file_path is missing. LLM/parse
    failures do NOT raise — they come back as ``{"status": "failed", ...}`` and
    are persisted with status='failed'.
    """
    row = get_candidate(candidate_id)
    if not row:
        raise KeyError(f"candidate_id {candidate_id!r} not found")
    s3_path = row.get("s3_file_path")
    if not s3_path:
        raise KeyError(f"candidate_id {candidate_id!r} has no s3_file_path")

    # Reuse L2's text when it captured the full document (no double OCR, no S3 download).
    pre_text = row.get("l2_text") if row.get("l2_text_complete") else None
    if pre_text and pre_text.strip():
        result = run("", candidate_id, pre_text=pre_text)
        _attach_excel_columns(row, result)
        update_candidate_from_result(candidate_id, result)
        logger.info("[L3] Extraction %s for %s (reused L2 text)", result.get("status"), candidate_id)
        return result

    tmp_path = download_resume_to_temp(s3_path)
    try:
        result = run(tmp_path, candidate_id)
        _attach_excel_columns(row, result)
        update_candidate_from_result(candidate_id, result)
    finally:
        with contextlib.suppress(OSError):
            os.unlink(tmp_path)
    logger.info(
        "[L3] Extraction %s for %s", result.get("status"), candidate_id
    )
    return result


def _resume_text_for(row: Dict[str, Any]) -> tuple[str | None, str | None]:
    """(text, tmp_path) — tmp_path is set only when a fresh download happened
    (reused L2 text needs no file, so nothing to clean up in that case)."""
    pre_text = row.get("l2_text") if row.get("l2_text_complete") else None
    if pre_text and pre_text.strip():
        return pre_text, None
    s3_path = row.get("s3_file_path")
    if not s3_path:
        return None, None
    tmp_path = download_resume_to_temp(s3_path)
    from app.extraction.engine import extract_resume_text
    text, _error = extract_resume_text(tmp_path)
    return text, tmp_path


def regenerate_analysis_report(candidate_id: str) -> Dict[str, Any]:
    """Re-runs ONLY the Analysis Report prompt for an existing candidate —
    e.g. to test an edited prompt (Settings → Extraction & Analysis) — leaving
    every other extracted field untouched. Raises KeyError if the candidate is
    missing; propagates whatever the LLM call raises (no deterministic
    fallback exists for narrative text)."""
    row = get_candidate(candidate_id)
    if not row:
        raise KeyError(f"candidate_id {candidate_id!r} not found")

    resume_text, tmp_path = _resume_text_for(row)
    try:
        if not resume_text or not resume_text.strip():
            raise ValueError("No resume text available for this candidate (missing or unreadable file).")
        result = regenerate_analysis_report_only(candidate_id, row, resume_text)
    finally:
        if tmp_path:
            with contextlib.suppress(OSError):
                os.unlink(tmp_path)

    update_candidate_analysis_report(candidate_id, result["analysis_report"])
    logger.info("[L3] Analysis Report regenerated for %s", candidate_id)
    return result


def safe_extract_candidate(candidate_id: str) -> Dict[str, Any]:
    """Auto-chain wrapper: never raises, so a flaky L3 can't break L2 intake.

    A failure INSIDE ``run()`` (LLM/parse) already comes back as a result that
    ``extract_candidate`` persists (status='Active' + failure_reason, surfaced via a
    review_queue row). But a raise BEFORE the persist — e.g. the S3 fetch in
    ``download_resume_to_temp`` throwing, or a missing row/path — used to be swallowed
    here with nothing written back, stranding the row at 'Pending Extraction' forever
    (no failure_reason, no retry). So on any exception we now persist a failure result
    too, so it surfaces on the worklist instead of silently disappearing.
    """
    try:
        return extract_candidate(candidate_id)
    except Exception as exc:  # noqa: BLE001
        logger.warning("[L3] auto-extract failed for %s: %s", candidate_id, exc)
        failed = _failure(candidate_id, str(exc))
        # Best-effort persist — never let the failure-recording itself raise (e.g. the
        # row genuinely doesn't exist), so this wrapper keeps its never-raises contract.
        with contextlib.suppress(Exception):
            update_candidate_from_result(candidate_id, failed)
        return failed
