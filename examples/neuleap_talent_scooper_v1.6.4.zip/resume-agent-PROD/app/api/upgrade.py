"""In-app upgrade API — Settings → System Upgrade (System Admin).

Upload a version bundle, then start a one-click upgrade: the app takes a full
pre-upgrade backup and hands off to the updater sidecar, which swaps the images,
runs health + consistency checks, and auto-rolls-back on failure. The UI polls
``/upgrade/status``.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from pydantic import BaseModel

from app.api.auth import AuthUser, require_backoffice_access
from app.api.backup import require_sysadmin
from app.services import upgrade, upgrade_config

router = APIRouter(prefix="/api/v1", tags=["upgrade"])


@router.get("/upgrade/config", summary="Signing trust config (public key + require-signature)")
def get_config(_u: AuthUser = Depends(require_backoffice_access)) -> dict:
    return upgrade_config.get()


class UpgradeConfigIn(BaseModel):
    public_key: str = ""
    require_signature: bool = False


@router.put("/upgrade/config", summary="System Admin: set the bundle-signing public key")
def put_config(body: UpgradeConfigIn, _u: AuthUser = Depends(require_sysadmin)) -> dict:
    return upgrade_config.save(body.model_dump())


@router.post("/upgrade/bundle", summary="System Admin: upload + validate a version bundle")
async def upload_bundle(
    file: UploadFile = File(...), user: AuthUser = Depends(require_sysadmin)
) -> dict:
    try:
        manifest = upgrade.save_bundle(file.file, file.filename or "bundle.tar")
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"manifest": manifest}


@router.get("/upgrade/drop", summary="Bundle .tar files sitting in the server drop folder")
def drop_list(_u: AuthUser = Depends(require_backoffice_access)) -> dict:
    """For big bundles that exceed a browser-upload limit (Cloudflare/nginx):
    copy the .tar to backups/upgrade/drop/ on the host and load it from here."""
    return {"files": upgrade.list_drop_files()}


class DropLoadIn(BaseModel):
    filename: str


@router.post("/upgrade/drop/load", summary="System Admin: validate a bundle from the drop folder")
def drop_load(body: DropLoadIn, user: AuthUser = Depends(require_sysadmin)) -> dict:
    try:
        manifest = upgrade.load_drop_bundle(body.filename)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"manifest": manifest}


@router.get("/upgrade/bundles", summary="Uploaded bundles available to install")
def list_bundles(_u: AuthUser = Depends(require_backoffice_access)) -> dict:
    return {"bundles": upgrade.list_bundles()}


class StartUpgradeIn(BaseModel):
    bundle_id: str


@router.post("/upgrade/start", summary="System Admin: back up + start the upgrade")
def start(body: StartUpgradeIn, user: AuthUser = Depends(require_sysadmin)) -> dict:
    try:
        return upgrade.start_upgrade(body.bundle_id, requested_by=user.email)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("/upgrade/status", summary="Current upgrade status (poll during an upgrade)")
def status(_u: AuthUser = Depends(require_backoffice_access)) -> dict:
    return upgrade.get_status()
