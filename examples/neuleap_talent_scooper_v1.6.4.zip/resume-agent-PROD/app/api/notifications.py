"""Notifications API — the top-bar bell.

The feed is derived from existing tables (audit_log / review_queue / candidate_master)
and persisted into the single ``notifications`` table, which carries durable read/unread
state (``read_at``) and self-cleans 24h after a notification is read. See
``app.services.notifications`` and ``docs/notification.md``.
"""
from __future__ import annotations

from typing import Any

from fastapi import APIRouter

from app.services import notifications

router = APIRouter(prefix="/api/v1", tags=["notifications"])


@router.get("/notifications", summary="Notification feed (newest first)")
def list_notifications(limit: int = 50) -> list[dict[str, Any]]:
    return notifications.feed(limit)


@router.post("/notifications/mark-all-read", summary="Mark every notification as read")
def mark_all_read() -> dict[str, int]:
    return {"marked": notifications.mark_all_read()}


@router.post("/notifications/{notification_id}/read", summary="Mark one notification as read")
def mark_one_read(notification_id: str) -> dict[str, bool]:
    return {"updated": notifications.mark_read(notification_id)}
