"""JD (Job Description) matching — on-demand fit scoring for the Screening
page's "JD Match" column. See app.services.jd_match for the actual scoring;
this module is just the HTTP surface (JD text extraction from an upload, and
the batch scoring call).
"""
from __future__ import annotations

import logging
import os
import tempfile
from pathlib import Path
from typing import List

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from pydantic import BaseModel

from app.api.auth import require_admin
from app.extraction.engine import extract_resume_text
from app.repositories import repo
from app.services import jd_match

logger = logging.getLogger(__name__)

# Admin-only, router-wide: one batch call ships every filtered candidate to
# the LLM — a deliberate, metered spend an Admin owns (the frontend hides the
# button for other roles; this enforces it).
router = APIRouter(prefix="/api/v1", tags=["jd-match"], dependencies=[Depends(require_admin)])

_SUPPORTED_JD_EXTENSIONS = {".pdf", ".docx", ".doc", ".txt"}


@router.post("/jd-match/extract-text", summary="Extract plain text from an uploaded JD file")
async def extract_jd_text(file: UploadFile = File(...)) -> dict:
    suffix = Path(file.filename or "").suffix.lower()
    if suffix == ".txt":
        raw = await file.read()
        return {"text": raw.decode("utf-8", errors="ignore")}
    if suffix not in _SUPPORTED_JD_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file type '{suffix}'. Accepted: {sorted(_SUPPORTED_JD_EXTENSIONS)}",
        )
    data = await file.read()
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        tmp.write(data)
        tmp_path = tmp.name
    try:
        text, error = extract_resume_text(tmp_path)
    finally:
        os.unlink(tmp_path)
    if error or not text:
        raise HTTPException(status_code=422, detail=error or "Could not extract text from this file")
    return {"text": text}


class JdMatchRequest(BaseModel):
    jd_text: str
    candidate_ids: List[str]


class JdExplainRequest(BaseModel):
    jd_text: str
    candidate_id: str
    # The batch score/note already shown in the column — passed through so the
    # detailed explanation stays consistent with the number the user clicked.
    prior_score: int | None = None
    prior_note: str | None = None


@router.post("/jd-match/explain", summary="Explain one candidate's JD-match score in detail")
def jd_match_explain(body: JdExplainRequest) -> dict:
    jd_text = (body.jd_text or "").strip()
    if not jd_text:
        raise HTTPException(status_code=422, detail="jd_text is required")
    candidate = repo().get_candidate(body.candidate_id)
    if not candidate:
        raise HTTPException(status_code=404, detail=f"candidate {body.candidate_id} not found")
    try:
        return jd_match.explain_candidate(
            jd_text, candidate, prior_score=body.prior_score, prior_note=body.prior_note
        )
    except RuntimeError as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.post("/jd-match", summary="Score candidates against a job description")
def jd_match_score(body: JdMatchRequest) -> dict:
    jd_text = (body.jd_text or "").strip()
    if not jd_text:
        raise HTTPException(status_code=422, detail="jd_text is required")
    if not body.candidate_ids:
        return {"results": []}
    if len(body.candidate_ids) > jd_match.MAX_CANDIDATES:
        raise HTTPException(
            status_code=400,
            detail=(
                f"Too many candidates ({len(body.candidate_ids)}) — narrow your filters to "
                f"{jd_match.MAX_CANDIDATES} or fewer and try again."
            ),
        )
    candidates = [repo().get_candidate(cid) for cid in body.candidate_ids]
    candidates = [c for c in candidates if c]
    try:
        results = jd_match.score_candidates(jd_text, candidates)
    except RuntimeError as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"results": results}
