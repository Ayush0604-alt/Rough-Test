"""Backup & Disaster-Recovery API — Settings → Backup & Disaster Recovery.

Reads (health/status/list/config) are open to any back-office role; the
mutating actions (edit config, run a backup, restore) are System-Admin only,
since restore is destructive and the schedule governs real data protection.
"""
from __future__ import annotations

from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from app.api.auth import AuthUser, get_current_user, require_backoffice_access
from app.services import backup, backup_config

router = APIRouter(prefix="/api/v1", tags=["backup (DR)"])


def require_sysadmin(user: AuthUser = Depends(get_current_user)) -> AuthUser:
    if user.role != "sysadmin":
        raise HTTPException(status_code=403, detail="Backup controls are System Admin only.")
    return user


# ── status / health ──────────────────────────────────────────────────────────
@router.get("/backup/health", summary="System health + backup status")
def get_health(_u: AuthUser = Depends(require_backoffice_access)) -> dict:
    return backup.system_health()


@router.get("/backup/list", summary="List the available backup sets")
def get_list(_u: AuthUser = Depends(require_backoffice_access)) -> dict:
    return {"backups": backup.list_backups()}


@router.get("/backup/config", summary="Backup & DR configuration (secret masked)")
def get_config(_u: AuthUser = Depends(require_backoffice_access)) -> dict:
    return backup_config.public()


# ── config (System Admin) ─────────────────────────────────────────────────────
class CloudIn(BaseModel):
    enabled: bool = False
    endpoint: str = ""
    region: str = ""
    bucket: str = ""
    prefix: str = "neuleap-backups"
    access_key: str = ""
    secret_key: str = ""  # blank keeps the stored one


class BackupConfigIn(BaseModel):
    enabled: bool = False
    incremental_interval_hours: int = 6
    full_weekly_day: int = 6
    full_weekly_hour: int = 2
    retention_full_sets: int = 2
    retention_incrementals: int = 14
    notify_on_failure: bool = False
    notify_emails: str = ""
    secondary_dir: str = ""
    cloud: Optional[CloudIn] = None


@router.put("/backup/config", summary="System Admin: save the backup schedule + targets")
def put_config(body: BackupConfigIn, _u: AuthUser = Depends(require_sysadmin)) -> dict:
    saved = backup_config.save(body.model_dump())
    # Re-apply the schedule live so a cadence change takes effect without a restart.
    try:
        from app.services import scheduler
        scheduler.reschedule_backups()
    except Exception:  # noqa: BLE001
        pass
    return backup_config.public(saved)


@router.post("/backup/config/revert", summary="System Admin: reset backup config to defaults")
def revert_config(_u: AuthUser = Depends(require_sysadmin)) -> dict:
    cfg = backup_config.revert_to_default()
    try:
        from app.services import scheduler
        scheduler.reschedule_backups()
    except Exception:  # noqa: BLE001
        pass
    return backup_config.public(cfg)


# ── actions (System Admin) ────────────────────────────────────────────────────
@router.post("/backup/run", summary="System Admin: run a backup now")
def run_now(kind: str = "full", _u: AuthUser = Depends(require_sysadmin)) -> dict:
    if kind not in ("full", "incremental"):
        raise HTTPException(status_code=422, detail="kind must be 'full' or 'incremental'.")
    return backup.run_backup(kind=kind, reason="manual")


@router.post("/backup/restore/{backup_id}", summary="System Admin: restore from a backup (DESTRUCTIVE)")
def restore(backup_id: str, _u: AuthUser = Depends(require_sysadmin)) -> dict:
    result = backup.restore_backup(backup_id)
    if not result.get("restored"):
        raise HTTPException(status_code=400, detail=result.get("error") or "Restore failed.")
    return result
