"""L2 intake API: read email_master, validate/dedup/store, write candidate stub.

On any file that PASSes, L3 extraction is auto-chained (settings.auto_extract)
to complete the candidate_master row in the same request.
"""
from __future__ import annotations

import hashlib
import logging
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date
from typing import Optional

from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from pydantic import BaseModel

from app.config import settings
from app.extraction.runner import safe_extract_candidate
from app.models.schemas import (
    FileResult,
    ProcessEmailResponse,
    RunL2Request,
    RunL2Response,
)
from app.models.state import L2State
from app.pipeline.graph import get_graph
from app.repositories import repo
from app.services import clock
from app.services.s3 import s3

# pdfminer emits harmless warnings for malformed font descriptors in real-world PDFs.
logging.getLogger("pdfminer.pdffont").setLevel(logging.ERROR)

router = APIRouter(prefix="/api/v1", tags=["intake"])


# ── Upload trace models ───────────────────────────────────────────────────────

class StepResult(BaseModel):
    step: str
    name: str
    status: str
    detail: str


class UploadResumeResponse(BaseModel):
    e_id: str
    filename: str
    final_status: str    # PASS | DUP | DUP_HIRED | CORRUPT | NOT_RESUME
    candidate_id: Optional[str] = None
    s3_path: Optional[str] = None
    steps: list[StepResult]
    extraction: Optional[dict] = None


def _build_initial_state(e_id: str, mail_send_date: date) -> L2State:
    return {
        "e_id":              e_id,
        "run_date":          mail_send_date.strftime("%Y-%m-%d"),
        "mail_send_date":    mail_send_date,
        "files_to_process":  [],
        "current_file":      "",
        "file_bytes":        None,
        "file_extension":    "",
        "extracted_text":    "",
        "integrity_ok":      False,
        "is_resume":         False,
        "cand_name":         "",
        "cand_email":        "",
        "cand_phno":         "",
        "fuzzy_match_row":   None,
        "hash_match":        False,
        "is_post_screening": False,
        "candidate_id":      None,
        "s3_clean_path":     None,
        "drop_reason":       None,
        "file_outcomes":     [],
    }


def _auto_extract(outcomes: list[dict]) -> list[dict]:
    """Run L3 extraction for every PASS outcome in parallel batches."""
    if not settings.auto_extract:
        return []

    candidate_ids = [
        o["candidate_id"] for o in outcomes
        if o["status"] == "PASS" and o.get("candidate_id")
    ]
    if not candidate_ids:
        return []

    results: list[dict] = [{}] * len(candidate_ids)
    with ThreadPoolExecutor(max_workers=settings.extract_workers) as pool:
        futures = {pool.submit(safe_extract_candidate, cid): i
                   for i, cid in enumerate(candidate_ids)}
        for fut in as_completed(futures):
            results[futures[fut]] = fut.result()

    return results


@router.post("/process/{e_id}", response_model=ProcessEmailResponse)
def process_email(e_id: str) -> ProcessEmailResponse:
    """Process a single email's resume files through the L2 pipeline + auto-chain L3."""
    email_row = repo().get_email(e_id)
    if not email_row:
        raise HTTPException(status_code=404, detail=f"E_id {e_id!r} not found")

    try:
        # D4: email_master carries `received_date` (ISO string or "unknown").
        send_date = date.fromisoformat(str(email_row["received_date"])[:10])
    except (ValueError, TypeError):
        send_date = date.today()

    state = _build_initial_state(e_id, send_date)
    final_state = get_graph().invoke(state)

    outcomes = final_state["file_outcomes"]
    passed  = sum(1 for o in outcomes if o["status"] == "PASS")
    failed  = sum(1 for o in outcomes if o["status"] not in ("PASS", "REAPPLICATION"))
    reapps  = sum(1 for o in outcomes if o["status"] == "REAPPLICATION")

    extractions = _auto_extract(outcomes)

    return ProcessEmailResponse(
        e_id=e_id,
        total_files=len(outcomes),
        passed=passed,
        failed=failed,
        reapplications=reapps,
        file_results=[FileResult(**o) for o in outcomes],
        folder_status="Processed" if failed == 0 else "Processing",
        extractions=extractions,
    )


@router.post("/run", response_model=RunL2Response)
def run_layer2(body: RunL2Request) -> RunL2Response:
    """Run L2 over all Passed emails in email_master, auto-chaining L3."""
    started_at = clock.now()
    emails = repo().get_passed_emails()

    if body.dry_run:
        return RunL2Response(
            emails_processed=len(emails),
            total_files=0, total_passed=0, total_failed=0, extractions_run=0,
            started_at=started_at, completed_at=clock.now(),
        )

    total_files = total_passed = total_failed = extractions_run = 0

    for row in emails:
        try:
            send_date = date.fromisoformat(str(row["received_date"])[:10])  # D4
        except (ValueError, TypeError):
            send_date = date.today()

        state = _build_initial_state(row["e_id"], send_date)
        final_state = get_graph().invoke(state)
        outcomes = final_state["file_outcomes"]

        total_files  += len(outcomes)
        total_passed += sum(1 for o in outcomes if o["status"] == "PASS")
        total_failed += sum(1 for o in outcomes if o["status"] not in ("PASS", "REAPPLICATION"))
        extractions_run += len(_auto_extract(outcomes))

    return RunL2Response(
        emails_processed=len(emails),
        total_files=total_files,
        total_passed=total_passed,
        total_failed=total_failed,
        extractions_run=extractions_run,
        started_at=started_at,
        completed_at=clock.now(),
    )


@router.get("/candidates", summary="List all candidate_master rows")
def list_candidates() -> list[dict]:
    rows = repo().get_all_candidates()
    # Enrich each row with the computed "Proposed Next Best Action" — the SAME pure
    # function the detail endpoint uses (interview_plan.next_best_action), so the
    # Candidates list can show it as a configurable column. All inputs
    # (roundname/round_status/include_round3/priority) are already on the row, so this is
    # an in-memory enrichment with no extra query.
    from app.services import interview_plan
    for row in rows:
        row["next_action"] = interview_plan.next_best_action(
            current=row.get("roundname"),
            round_status=row.get("round_status"),
            include_round3=bool(row.get("include_round3")),
            priority=row.get("priority"),
        )
    # Pending (status='draft') email drafts — one batched query, keyed by
    # candidate_id, so the "draft ready for review" badge on list views is a
    # single extra query instead of one per row.
    pending = repo().latest_pending_drafts([r["candidate_id"] for r in rows])
    for row in rows:
        row["pending_email_draft"] = pending.get(row["candidate_id"])
    # NLRS + the predicted initial NBA (New-stage only) — pure in-memory
    # computation from fields already on the row, no extra query.
    from app.services.nlrs import enrich_with_nlrs
    for row in rows:
        enrich_with_nlrs(row)
    # Referral classification (Settings → Referrals) so the green referral badge
    # shows next to the name on list views too. Skipped entirely when nothing is
    # configured (no referrals possible), else ONE batched sender-email query +
    # in-memory classify against the pre-loaded config.
    from app.services import referral_config
    ref_cfg = referral_config.get()
    if ref_cfg["emails"] or ref_cfg["domains"]:
        srcs = repo().sender_emails_by_candidate([r["candidate_id"] for r in rows])
        for row in rows:
            src = srcs.get(row["candidate_id"]) or {}
            row["referral"] = referral_config.classify(src.get("sender"), src.get("subject"), ref_cfg)
    else:
        for row in rows:
            row["referral"] = None
    return rows


# NOTE: must stay ABOVE the dynamic /candidates/{candidate_id} route (rounds.py).
# intake.router is included before rounds.router, so this static path wins — keep it so.
@router.get("/candidates/facets", summary="Batch + email (E_ID) facets for candidate filtering")
def candidate_facets() -> dict:
    """Dropdown options for browsing candidates by batch_id or by source email (E_ID).
    Each facet carries the candidate_ids it covers, so the SPA filters client-side."""
    return repo().candidate_facets()


_IMAGE_EXTS = {"jpg", "jpeg", "png"}


def _resume_identity(ext: str, extracted_text: str) -> tuple[bool, str]:
    """Step 11B: decide if the upload looks like a resume + build the detail line."""
    from app.pipeline.nodes.validate import _looks_like_resume

    if ext in _IMAGE_EXTS:
        return True, "Scanned image — passed through without text check"
    is_resume = _looks_like_resume(extracted_text)
    lower = extracted_text.lower()
    found = {
        "contact":  any(k in lower for k in ["@", "phone", "mobile", "linkedin"]),
        "work/edu": any(
            k in lower
            for k in ["experience", "employment", "education", "university", "college"]
        ),
        "skills":   any(k in lower for k in ["skills", "technologies", "tools", "projects"]),
    }
    detail = "Sections found: " + ", ".join(k for k, v in found.items() if v)
    if not is_resume:
        detail += " | MISSING: " + ", ".join(k for k, v in found.items() if not v)
    return is_resume, detail


def _stored_hash_matches(s3_file_path: str, incoming_hash: str) -> bool:
    """True iff the stored object's SHA-256 equals ``incoming_hash``."""
    try:
        stored_bytes = s3().get_bytes(s3_file_path)
    except Exception:  # noqa: BLE001 - any storage read failure ⇒ treat as not-a-duplicate
        return False
    return incoming_hash == hashlib.sha256(stored_bytes).hexdigest()


def _append_fuzzy_step(
    steps: list[StepResult], fuzzy_match: Optional[dict], name: str, email: str, phone: str
) -> None:
    """Step 12A: record the fuzzy-dedup outcome."""
    if fuzzy_match:
        steps.append(StepResult(
            step="12A", name="Fuzzy Dedup (Stage 1)", status="MATCH",
            detail=(
                f"Matched candidate {fuzzy_match['candidate_id']}  "
                f"name='{fuzzy_match.get('name','')}' email='{fuzzy_match.get('email','')}' "
                f"status='{fuzzy_match.get('status','')}'"
            ),
        ))
    else:
        steps.append(StepResult(
            step="12A", name="Fuzzy Dedup (Stage 1)", status="NO_MATCH",
            detail=(
                f"No match  (extracted: name='{name}' email='{email}' "
                f"phone='{phone}'  threshold={settings.fuzzy_threshold})"
            ),
        ))


def _append_l3_step(steps: list[StepResult], cid: str) -> Optional[dict]:
    """Step 15: auto-chain L3 extraction (when enabled) and record the step."""
    if not settings.auto_extract:
        steps.append(StepResult(
            step="15", name="L3 Extraction (auto)", status="SKIP",
            detail="auto_extract disabled — call /api/v1/candidates/{id}/process to extract",
        ))
        return None
    extraction = safe_extract_candidate(cid)
    steps.append(StepResult(
        step="15",
        name="L3 Extraction (auto)",
        status=str(extraction.get("status", "")).upper(),
        detail=f"candidate_id={cid}  status={extraction.get('status')}",
    ))
    return extraction


@router.post(
    "/upload",
    response_model=UploadResumeResponse,
    summary="Upload a resume and trace all L2 steps + auto-chain L3",
)
async def upload_resume(
    file: UploadFile = File(..., description="PDF, DOCX, JPG, or PNG resume"),
    e_id: Optional[str] = Form(None, description="Optional email id; auto-generated if omitted"),
) -> UploadResumeResponse:
    from app.pipeline.nodes.dedup import _extract_contact, _find_fuzzy_match
    from app.pipeline.nodes.validate import _can_open, _extract_text

    steps: list[StepResult] = []
    run_date = date.today().isoformat()
    auto_e_id = e_id or f"E_UPLOAD_{uuid.uuid4().hex[:8].upper()}"
    filename = file.filename or "resume.pdf"
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    file_bytes = await file.read()

    # ── Step 10: Fetch & queue ────────────────────────────────────────────────
    steps.append(StepResult(
        step="10", name="Fetch & Queue File", status="PASS",
        detail=(
            f"Received '{filename}' ({len(file_bytes):,} bytes)  "
            f"e_id={auto_e_id}  run_date={run_date}"
        ),
    ))
    # D2: write raw to the `raw` bucket (no prefix — bucket itself is `raw`).
    raw_key = s3().raw_prefix(auto_e_id, run_date) + filename
    s3().put_bytes(raw_key, file_bytes, raw=True)

    # ── Step 11A: File integrity ──────────────────────────────────────────────
    if not _can_open(file_bytes, ext):
        steps.append(StepResult(
            step="11A", name="Integrity Check", status="FAIL",
            detail=f"Cannot open '{filename}' as {ext.upper()} — corrupt or unsupported",
        ))
        return UploadResumeResponse(
            e_id=auto_e_id, filename=filename, final_status="CORRUPT", steps=steps,
        )

    extracted_text = _extract_text(file_bytes, ext)
    steps.append(StepResult(
        step="11A", name="Integrity Check", status="PASS",
        detail=f"File opened — {len(extracted_text):,} chars extracted",
    ))

    # ── Step 11B: Resume identity ─────────────────────────────────────────────
    is_resume, identity_detail = _resume_identity(ext, extracted_text)
    if not is_resume:
        steps.append(StepResult(
            step="11B", name="Resume Identity Check", status="FAIL", detail=identity_detail,
        ))
        return UploadResumeResponse(
            e_id=auto_e_id, filename=filename, final_status="NOT_RESUME", steps=steps,
        )

    steps.append(StepResult(
        step="11B", name="Resume Identity Check", status="PASS", detail=identity_detail,
    ))

    # ── Step 12A: Fuzzy dedup (deterministic contact) ─────────────────────────
    name, email, phone = _extract_contact(extracted_text)
    fuzzy_match = _find_fuzzy_match(name, email, phone)
    _append_fuzzy_step(steps, fuzzy_match, name, email, phone)

    # ── Step 12B: Hash check ──────────────────────────────────────────────────
    cid: Optional[str] = None
    if fuzzy_match:
        if fuzzy_match.get("status") == "Hired":
            steps.append(StepResult(
                step="12B", name="Hash Check (Stage 2)", status="SKIP",
                detail="Candidate already Hired — dropped",
            ))
            return UploadResumeResponse(
                e_id=auto_e_id, filename=filename, final_status="DUP_HIRED",
                candidate_id=fuzzy_match["candidate_id"], steps=steps,
            )

        incoming_hash = hashlib.sha256(file_bytes).hexdigest()
        if _stored_hash_matches(fuzzy_match["s3_file_path"], incoming_hash):
            steps.append(StepResult(
                step="12B", name="Hash Check (Stage 2)", status="DUPLICATE",
                detail=(
                    f"SHA-256 matches stored file — exact duplicate  "
                    f"hash={incoming_hash[:16]}..."
                ),
            ))
            return UploadResumeResponse(
                e_id=auto_e_id, filename=filename, final_status="DUP",
                candidate_id=fuzzy_match["candidate_id"], steps=steps,
            )

        steps.append(StepResult(
            step="12B", name="Hash Check (Stage 2)", status="UPDATED",
            detail=f"Different hash — treating as resume update  hash={incoming_hash[:16]}...",
        ))
        cid = fuzzy_match["candidate_id"]
    else:
        steps.append(StepResult(
            step="12B", name="Hash Check (Stage 2)", status="SKIP",
            detail="No fuzzy match — new candidate path",
        ))

    # ── Step 13: Store clean resume ───────────────────────────────────────────
    if cid is None:
        cid = repo().get_next_candidate_id()
    clean_key = s3().clean_prefix(cid, run_date) + filename
    s3().copy(raw_key, clean_key)
    steps.append(StepResult(
        step="13", name="Store Clean Resume", status="PASS",
        detail=f"Copied to {clean_key}  candidate_id={cid}",
    ))

    # ── Step 14: candidate_master stub (deterministic contact persisted) ──────
    if fuzzy_match and fuzzy_match["candidate_id"] == cid:
        repo().update_candidate_resume(cid, clean_key)
        stub_action = f"Updated existing row for {cid}  (s3_file_path refreshed)"
    else:
        repo().insert_candidate_stub(
            candidate_id=cid, s3_file_path=clean_key, mail_send_date=date.today(),
            e_id=auto_e_id, name=name, email=email, phno=phone,
        )
        stub_action = (
            f"New row {cid}  name='{name}' email='{email}' phone='{phone}'  "
            "status='Pending Extraction'"
        )
    steps.append(StepResult(
        step="14", name="Candidate Master Stub", status="PASS", detail=stub_action,
    ))

    # ── Step 15: Auto-chain L3 extraction ─────────────────────────────────────
    extraction = _append_l3_step(steps, cid)

    return UploadResumeResponse(
        e_id=auto_e_id, filename=filename, final_status="PASS",
        candidate_id=cid, s3_path=clean_key, steps=steps, extraction=extraction,
    )
