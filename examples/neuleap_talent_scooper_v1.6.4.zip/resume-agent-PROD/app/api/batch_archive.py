"""Batch Archive — Mailbox section: archive/restore/prune resumes by source tag.

Admin or System Admin only (same gate as the rest of Mailbox/intake) — see
app.services.batch_archive for what "batch" means and exactly what each
action does to the database.
"""
from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends
from pydantic import BaseModel

from app.api.auth import require_backoffice_access
from app.services import batch_archive, recruiter_apply_config

router = APIRouter(
    prefix="/api/v1",
    tags=["batch archive"],
    dependencies=[Depends(require_backoffice_access)],
)


class BatchRef(BaseModel):
    # None = the "no source" bucket (source IS NULL) — a real, selectable batch,
    # not "no batch specified".
    source: Optional[str] = None


@router.get("/batches")
def get_batches() -> dict:
    """Distinct `source` values live in candidate_master, with counts — the
    options for "archive a batch"."""
    return {"batches": batch_archive.list_batches()}


@router.get("/batches/archived")
def get_archived_batches() -> dict:
    """Same grouping over the archive tables — the options for restore/prune."""
    return {"batches": batch_archive.list_archived_batches()}


@router.post("/batches/archive")
def post_archive_batch(body: BatchRef) -> dict:
    return batch_archive.archive_batch(body.source)


@router.post("/batches/restore")
def post_restore_batch(body: BatchRef) -> dict:
    return batch_archive.restore_batch(body.source)


@router.post("/batches/prune")
def post_prune_batch(body: BatchRef) -> dict:
    """Permanently deletes the archived batch — including its resume files.
    The frontend is responsible for a clear confirmation before calling this."""
    return batch_archive.prune_batch(body.source)


# ── Per-source "Recruiters can apply predicted NBA" ─────────────────────────
# Default OFF for every source until explicitly turned on here — see
# app.services.recruiter_apply_config for exactly what this gates (the Apply
# button/endpoint, and directly scheduling a round for a still-"New" candidate).

class RecruiterApplyRef(BatchRef):
    enabled: bool = False


@router.get("/batches/recruiter-apply-nba")
def get_recruiter_apply_nba() -> dict:
    return recruiter_apply_config.get()


@router.put("/batches/recruiter-apply-nba")
def put_recruiter_apply_nba(body: RecruiterApplyRef) -> dict:
    return recruiter_apply_config.set_for_source(body.source, body.enabled)
