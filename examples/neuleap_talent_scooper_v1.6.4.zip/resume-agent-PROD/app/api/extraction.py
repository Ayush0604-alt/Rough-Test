"""L3 extraction API: standalone parse + manual (re)processing endpoints.

These complement the L2 auto-chain — useful for re-running extraction on an
existing candidate, or for parsing a file directly without going through intake.
"""
from __future__ import annotations

import io
import os
import tempfile
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import List, Optional

from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from app.config import settings
from app.db import get_candidate, update_candidate_from_result, upsert_candidate_input
from app.extraction.engine import _failure, run
from app.extraction.runner import extract_candidate, safe_extract_candidate
from app.mail_config import max_upload_bytes, over_limit_message
from app.services.s3 import upload_resume


async def _read_capped(upload: UploadFile, limit: int) -> tuple[bytes, bool]:
    """Read an UploadFile in 1 MB chunks, stopping once ``limit`` is exceeded.

    Returns ``(data, oversize)``. When oversize, ``data`` is the partial buffer
    (unused by callers) — we stop early so a huge upload can't exhaust memory.
    """
    chunks: list[bytes] = []
    total = 0
    while True:
        chunk = await upload.read(1024 * 1024)
        if not chunk:
            break
        total += len(chunk)
        if total > limit:
            return b"".join(chunks), True
        chunks.append(chunk)
    return b"".join(chunks), False

router = APIRouter(prefix="/api/v1", tags=["extraction"])

SUPPORTED_EXTENSIONS = {
    ".pdf", ".docx", ".doc", ".jpg", ".jpeg", ".png", ".bmp", ".tiff", ".tif", ".gif",
}


class CandidateInput(BaseModel):
    candidate_id: str
    s3_file_path: str
    mail_send_date: Optional[str] = None
    e_id: Optional[str] = None


def _check_ext(filename: Optional[str]) -> str:
    suffix = Path(filename or "").suffix.lower()
    if suffix not in SUPPORTED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file type '{suffix}'. Accepted: {sorted(SUPPORTED_EXTENSIONS)}",
        )
    return suffix


@router.post("/parse", summary="Parse a resume file directly (no DB write)")
async def parse_resume(
    file: UploadFile = File(...),
    candidate_id: str = Form(default=None),
):
    suffix = _check_ext(file.filename)
    cid = candidate_id or f"CAND-{uuid.uuid4().hex[:8].upper()}"

    data, oversize = await _read_capped(file, max_upload_bytes(file.filename))
    if oversize:
        return JSONResponse(content=_failure(cid, over_limit_message(file.filename)), status_code=422)

    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        tmp.write(data)
        tmp_path = tmp.name
    try:
        result = run(tmp_path, cid)
    finally:
        os.unlink(tmp_path)

    return JSONResponse(content=result, status_code=200 if result["status"] == "success" else 422)


@router.post("/candidates", summary="Create/refresh a candidate input row")
def create_candidate(candidate: CandidateInput):
    upsert_candidate_input(
        candidate_id=candidate.candidate_id,
        s3_file_path=candidate.s3_file_path,
        mail_send_date=candidate.mail_send_date,
        e_id=candidate.e_id,
    )
    return {"status": "success", "candidate_id": candidate.candidate_id}


@router.post(
    "/candidates/{candidate_id}/process",
    summary="(Re)run L3 extraction on an existing candidate",
)
def process_candidate(candidate_id: str):
    if not get_candidate(candidate_id):
        raise HTTPException(status_code=404, detail="candidate_id not found")
    result = extract_candidate(candidate_id)
    return JSONResponse(content=result, status_code=200 if result["status"] == "success" else 422)


class BatchExtractRequest(BaseModel):
    candidate_ids: List[str]
    workers: Optional[int] = None  # override extract_workers from config


@router.post(
    "/candidates/batch-extract",
    summary="(Re)run L3 extraction on a list of candidates in parallel",
)
def batch_extract(body: BatchExtractRequest):
    """Extract a list of candidates concurrently.

    All L2 stubs must already exist in candidate_master.
    Results are written to PostgreSQL as they complete.
    Returns a summary once the full batch is done.
    """
    cids = body.candidate_ids
    if not cids:
        return {"total": 0, "parsed": 0, "failed": 0, "results": []}

    # Validate all exist before starting
    missing = [c for c in cids if not get_candidate(c)]
    if missing:
        raise HTTPException(status_code=404, detail=f"Not found: {missing}")

    workers = min(body.workers or settings.extract_workers, len(cids))
    results: list[dict] = [{}] * len(cids)

    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(safe_extract_candidate, cid): i for i, cid in enumerate(cids)}
        for fut in as_completed(futures):
            results[futures[fut]] = fut.result()

    parsed = sum(1 for r in results if r.get("status") == "success")
    failed = len(results) - parsed
    return {
        "total": len(cids),
        "parsed": parsed,
        "failed": failed,
        "results": results,
    }


@router.post("/parse-and-store", summary="Upload to MinIO, create the row, then extract")
async def parse_and_store_resume(
    file: UploadFile = File(...),
    candidate_id: str = Form(...),
    mail_send_date: Optional[str] = Form(default=None),
    e_id: Optional[str] = Form(default=None),
):
    suffix = _check_ext(file.filename)

    data, oversize = await _read_capped(file, max_upload_bytes(file.filename))
    if oversize:
        # Persist the row as FAILED (no upload) so the oversize candidate stays inspectable.
        reason = over_limit_message(file.filename)
        upsert_candidate_input(
            candidate_id=candidate_id, s3_file_path="",
            mail_send_date=mail_send_date, e_id=e_id,
        )
        failed = _failure(candidate_id, reason)
        update_candidate_from_result(candidate_id, failed)
        return JSONResponse(content=failed, status_code=422)

    object_name = f"{candidate_id}{suffix}"
    s3_file_path = upload_resume(
        io.BytesIO(data), object_name, content_type=file.content_type or "", candidate_id=candidate_id,
    )
    upsert_candidate_input(
        candidate_id=candidate_id, s3_file_path=s3_file_path,
        mail_send_date=mail_send_date, e_id=e_id,
    )
    result = extract_candidate(candidate_id)
    return JSONResponse(content=result, status_code=200 if result["status"] == "success" else 422)
