"""Outlook (Microsoft Graph) intake queue — read-only views for the Intake page.

The background :mod:`app.services.graph_poller` runs every ``GRAPH_POLL_INTERVAL_SECONDS``
(60s): it moves waiting Landing resumes into the **Processing** folder (the queue) and
caches that queue. These endpoints just expose the cached snapshot. The pipeline run
(midnight cron or Run Pipeline button) is what drains the queue and creates candidates.
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from app.api.auth import AuthUser, require_backoffice_access
from app.services import discarded_mail, graph_client, graph_poller, scheduler

# Mailbox/intake — Admin or System Admin only (Recruiter has no Mailbox access).
router = APIRouter(
    prefix="/graph", tags=["graph intake (outlook)"], dependencies=[Depends(require_backoffice_access)]
)


@router.get("/status")
def status() -> dict[str, Any]:
    snap = graph_poller.snapshot()
    return {
        "configured": graph_client.is_configured(),
        "poll_enabled": graph_poller.is_enabled(),
        "poll_interval_seconds": graph_poller.interval_seconds(),
        "count": snap.get("count", 0),
        "rejected": snap.get("rejected", 0),  # non-resume mail filtered out of preview
        "polled_at": snap.get("polled_at"),
        "error": snap.get("error"),
        # When the pipeline next drains the queue (ISO 8601 with tz, or null if the
        # scheduler isn't running). The Intake panel counts down to this.
        "next_run": scheduler.next_run_time(),
        "schedule": scheduler.schedule_description(),
    }


@router.get("/queue")
def queue() -> dict[str, Any]:
    """Resumes sitting in the Processing folder — the queue waiting for the next run.

    Read LIVE from the Processing folder (fast, no promotion/LLM), so it always reflects
    the mailbox and can never hang. Landing → Processing promotion runs in the
    background poller (:func:`graph_poller.tick`)."""
    snap = graph_poller.live_queue()
    return {
        "count": snap.get("count", 0),
        "rejected": snap.get("rejected", 0),
        "items": snap.get("items", []),
        "polled_at": snap.get("polled_at"),
        "error": snap.get("error"),
    }


@router.get("/folders")
def folders() -> dict[str, Any]:
    """Diagnostic: the exact Landing/subfolder resolution the backend sees (root folder
    list, resolved Landing id, its children + counts, and the logical-key → id map).
    Use this to confirm the Processing folder under Landing is being found."""
    return graph_client.resolve_debug()


@router.get("/folder-counts")
def folder_counts() -> dict[str, Any]:
    """Live Outlook folder item counts (Inbox / Processing / Processed / Failed /
    Non-Resume) read directly from Microsoft Graph — the same numbers shown next to
    each folder in the mail client. Powers the Mailbox "Email processing" overview."""
    return graph_client.folder_counts()


@router.post("/poll")
def poll_now() -> dict[str, Any]:
    """Refresh the queue. Nudges the Landing → Processing promotion in the BACKGROUND
    (non-blocking, so this never hangs on the classifier) and returns the LIVE Processing
    queue immediately. New Landing mail appears once the background tick promotes it."""
    graph_poller.trigger_tick_async()
    snap = graph_poller.live_queue()
    return {
        "count": snap.get("count", 0),
        "rejected": snap.get("rejected", 0),
        "items": snap.get("items", []),
        "polled_at": snap.get("polled_at"),
        "error": snap.get("error"),
    }


class DiscardRequest(BaseModel):
    ids: list[str] = []      # Graph message ids to discard (ignored when all=True)
    all: bool = False        # discard every item currently in the queue


@router.post("/discard", summary="Set aside selected/all queued mail — excludes it from the next run")
def discard(body: DiscardRequest, user: AuthUser = Depends(require_backoffice_access)) -> dict[str, Any]:
    """Move selected (or every) Incoming Email Queue item into the Discarded folder.

    Discarded mail leaves the Processing folder, so it is skipped by the next pipeline
    run — but it isn't deleted: it can be brought back with POST /graph/discarded/{id}/restore,
    which moves it back into Processing for a future or on-demand run. Every action is
    recorded (who discarded/restored, and when) for the Mailbox report.

    A ledger row is only written when the Outlook move actually succeeds — otherwise the
    message is still sitting in Processing and must stay visible in the live queue, not
    show up (also) as set aside."""
    if not graph_client.move_enabled():
        raise HTTPException(
            status_code=409,
            detail="Mail moving is disabled (GRAPH_MOVE_MAIL=0) — discard requires it to be on.",
        )

    snap = graph_poller.live_queue()
    items = snap.get("items", [])
    if body.all:
        targets = items
    else:
        wanted = set(body.ids)
        targets = [it for it in items if it.get("id") in wanted]

    discarded_ids: list[int] = []
    failed = 0
    for it in targets:
        new_id = graph_client.move_message(it["id"], "discarded")
        if not new_id:
            failed += 1
            continue
        row_id = discarded_mail.record_discard(
            message_id=new_id,
            sender_mail_id=it.get("sender"),
            subject=it.get("subject"),
            received_date=it.get("received_date"),
            discarded_by_email=user.email,
            discarded_by_name=user.name,
        )
        if row_id is not None:
            discarded_ids.append(row_id)

    snap2 = graph_poller.live_queue()
    return {
        "discarded": len(discarded_ids),
        "discarded_ids": discarded_ids,
        "failed": failed,
        "count": snap2.get("count", 0),
        "items": snap2.get("items", []),
    }


@router.get("/discarded", summary="List mail set aside (open, restorable) or the full discard/restore history")
def list_discarded(history: bool = False, limit: int = 200) -> list[dict[str, Any]]:
    return discarded_mail.list_history(limit) if history else discarded_mail.list_open(limit)


@router.post("/discarded/{item_id}/restore", summary="Bring a discarded mail back into the queue")
def restore_discarded(item_id: int, user: AuthUser = Depends(require_backoffice_access)) -> dict[str, Any]:
    """Move a set-aside message back into Processing so it's picked up by the next
    scheduled run or an on-demand "Run Pipeline"."""
    row = discarded_mail.get(item_id)
    if not row or row.get("state") != "discarded":
        raise HTTPException(status_code=404, detail="item not found or not currently discarded")
    if not row.get("message_id"):
        raise HTTPException(status_code=409, detail="no message id on record for this item")

    new_id = graph_client.move_message(row["message_id"], "processing")
    if not new_id:
        raise HTTPException(
            status_code=502,
            detail="could not move the message back into Processing (Outlook move failed or is disabled)",
        )
    ok = discarded_mail.record_restore(
        item_id, new_message_id=new_id, restored_by_email=user.email, restored_by_name=user.name
    )
    if not ok:
        raise HTTPException(status_code=409, detail="item already restored")
    return {"ok": True, "id": item_id}
