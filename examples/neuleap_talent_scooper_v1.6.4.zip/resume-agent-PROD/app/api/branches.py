"""Step 20 candidate-entry branches — recruiter-resolved exceptions.

Two flows the dashboard surfaces before a candidate can be screened:
  * Pending Resume    — recruiter uploads the missing resume → re-run L2/L3.
  * Previously Seen   — reapplication post-screening → accept (overwrite) or ignore.

Builds on the existing previously_seen / pending_review_file columns and the
extraction runner. Mounted under /api/v1.
"""
from __future__ import annotations

import logging
from datetime import date
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, File, HTTPException, UploadFile
from fastapi.responses import JSONResponse, Response
from pydantic import BaseModel

from app.constants import ReviewKind
from app.extraction.runner import safe_extract_candidate
from app.repositories import repo
from app.services import audit, review_queue
from app.services.s3 import s3, upload_resume
from app.stages import candidate_stage_bucket

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1", tags=["step20 (entry branches)"])

SUPPORTED_EXTENSIONS = {
    ".pdf", ".docx", ".doc", ".jpg", ".jpeg", ".png", ".bmp", ".tiff", ".tif", ".gif",
}

# Browser-renderable content types for the inline resume viewer.
_RESUME_CONTENT_TYPES = {
    ".pdf": "application/pdf",
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".doc": "application/msword",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".bmp": "image/bmp",
    ".tiff": "image/tiff",
    ".tif": "image/tiff",
    ".gif": "image/gif",
}


def _check_ext(filename: Optional[str]) -> str:
    suffix = Path(filename or "").suffix.lower()
    if suffix not in SUPPORTED_EXTENSIONS:
        raise HTTPException(status_code=400, detail=f"unsupported file type '{suffix}'")
    return suffix


# ── Queues ────────────────────────────────────────────────────────────────────

@router.get("/candidates/reapplications", summary="Candidates flagged Previously Seen")
def reapplication_queue() -> list[dict]:
    return repo().list_reapplications()


# ── View a candidate's stored resume (inline) ───────────────────────────────────

@router.get("/candidates/{candidate_id}/resume", summary="Stream a candidate's resume inline")
def get_resume(candidate_id: str, which: str = "current") -> Response:
    """Stream the candidate's resume inline.

    ``which=current`` (default) streams the live ``s3_file_path``; ``which=pending``
    streams the re-application's ``pending_review_file`` — so a reviewer can compare the
    old and new resume before accepting/ignoring a re-application.
    """
    cand = repo().get_candidate(candidate_id)
    if not cand:
        raise HTTPException(status_code=404, detail=f"candidate {candidate_id} not found")
    is_pending = which == "pending"
    key = cand.get("pending_review_file") if is_pending else cand.get("s3_file_path")
    if not key:
        detail = ("no pending re-application file" if is_pending
                  else "no resume on file for this candidate")
        raise HTTPException(status_code=404, detail=detail)
    try:
        # The pending re-application file is the L1 staging copy in the RAW bucket;
        # the live resume lives in the resume bucket.
        data = s3().get_bytes(key, raw=is_pending)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=404, detail=f"resume not found in storage: {exc}") from exc
    suffix = Path(key).suffix.lower()
    media_type = _RESUME_CONTENT_TYPES.get(suffix, "application/octet-stream")
    return Response(
        content=data,
        media_type=media_type,
        headers={"Content-Disposition": f'inline; filename="{Path(key).name}"'},
    )


# ── Pending Resume: supply a resume ─────────────────────────────────────────────

@router.post("/candidates/{candidate_id}/resume", summary="Attach a resume + re-run L2/L3")
async def attach_resume(candidate_id: str, file: UploadFile = File(...)) -> JSONResponse:
    if not repo().get_candidate(candidate_id):
        raise HTTPException(status_code=404, detail=f"candidate {candidate_id} not found")
    suffix = _check_ext(file.filename)
    object_name = f"{candidate_id}{suffix}"
    s3_file_path = upload_resume(
        file.file, object_name, content_type=file.content_type or "", candidate_id=candidate_id
    )
    # Resets ats/priority + status -> Pending Extraction, then L3 sets it Active.
    repo().update_candidate_resume(candidate_id, s3_file_path)
    result = safe_extract_candidate(candidate_id)
    # The file IS saved at this point — a failed L3 extraction is NOT an upload failure.
    # Return 200 with extraction_ok=False so the UI shows "saved, extraction pending"
    # rather than a hard error that nudges the recruiter to re-upload.
    extraction_ok = result.get("status") == "success"
    fresh = repo().get_candidate(candidate_id)  # post-extraction state, for stage
    audit.write_event(
        candidate_id=candidate_id, layer="L4", step="resume_attached", status="Info",
        fail_reason=f"Resume uploaded ({file.filename}); re-extraction "
        + ("completed." if extraction_ok else "did not complete — will retry."),
        stage=candidate_stage_bucket(fresh) if fresh else None,
    )
    return JSONResponse(
        content={
            "candidate_id": candidate_id,
            "s3_file_path": s3_file_path,
            "extraction": result,
            "extraction_ok": extraction_ok,
        },
        status_code=200,
    )


# ── Previously Seen: accept / ignore ────────────────────────────────────────────

class ReapplicationRequest(BaseModel):
    action: str  # "accept" | "ignore"


@router.post("/candidates/{candidate_id}/reapplication", summary="Accept/ignore a reapplication")
def resolve_reapplication(candidate_id: str, body: ReapplicationRequest) -> JSONResponse:
    existing = repo().get_candidate(candidate_id)
    if not existing:
        raise HTTPException(status_code=404, detail=f"candidate {candidate_id} not found")
    if body.action == "ignore":
        row = repo().ignore_reapplication(candidate_id)
        # Close the mirror row in the Needs-Review queue so it doesn't linger.
        review_queue.resolve_open_for_candidate(
            candidate_id, ReviewKind.REAPPLICATION, note="re-application ignored")
        audit.write_event(
            candidate_id=candidate_id, layer="L4", step="reapplication_ignored", status="Info",
            fail_reason="Re-application ignored — existing candidate record kept.",
            stage=candidate_stage_bucket(row or existing),
        )
        return JSONResponse(content={"candidate_id": candidate_id, "candidate": row})
    if body.action == "accept":
        # Relocate the pending raw file → resume bucket (so the live s3_file_path points
        # where L3 reads), promote it, then overwrite L3 fields by re-extracting.
        clean_key = _relocate_pending_to_resume(candidate_id)
        repo().accept_reapplication(candidate_id, clean_key)
        review_queue.resolve_open_for_candidate(
            candidate_id, ReviewKind.REAPPLICATION, note="re-application accepted")
        result = safe_extract_candidate(candidate_id)
        fresh = repo().get_candidate(candidate_id)  # post-extraction state, for stage
        # The new resume IS promoted — a failed re-extraction is not an accept failure.
        audit.write_event(
            candidate_id=candidate_id, layer="L4", step="reapplication_accepted", status="Info",
            fail_reason="Re-application accepted — resume and extracted fields overwritten.",
            stage=candidate_stage_bucket(fresh) if fresh else None,
        )
        return JSONResponse(
            content={"candidate_id": candidate_id, "s3_file_path": clean_key,
                     "extraction": result,
                     "extraction_ok": result.get("status") == "success"},
            status_code=200,
        )
    raise HTTPException(status_code=422, detail=f"unknown action '{body.action}'")


def _relocate_pending_to_resume(candidate_id: str) -> Optional[str]:
    """Copy a re-application's pending raw file into the resume bucket; return the new key.

    The pending file is the L1 staging copy (raw bucket, key ``YYYY/MM/DD/{e_id}/file``).
    On accept it must become the candidate's live resume in the resume bucket. Returns
    None when there's no pending file (the promote then falls back to existing behaviour).
    """
    cand = repo().get_candidate(candidate_id)
    raw_key = (cand or {}).get("pending_review_file")
    if not raw_key:
        return None
    parts = str(raw_key).split("/")
    run_date = (
        f"{parts[0]}-{parts[1]}-{parts[2]}"
        if len(parts) >= 3 and parts[0].isdigit()
        else date.today().isoformat()
    )
    clean_key = s3().clean_prefix(candidate_id, run_date) + raw_key.rsplit("/", 1)[-1]
    s3().copy(raw_key, clean_key)   # raw → resume
    logger.info("[reapplication] relocated %s → %s", raw_key, clean_key)
    return clean_key
