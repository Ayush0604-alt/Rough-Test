"""Settings API — notification preferences (env-file backed, no DB).

Backs the Settings page's Notifications section: the recipient address + the per-event
toggles. Persisted by :mod:`app.services.notify_config` to ``secrets/notifications.env``.

Every route is restricted to Admin/System Admin (require_backoffice_access) —
Recruiter has no Settings access at all, enforced here server-side, not just
by hiding the UI entry point.
"""

from __future__ import annotations

import logging
from typing import Any, Literal, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, EmailStr, Field

from app.api.auth import AuthUser, get_current_user, require_admin, require_backoffice_access
from app.services import (
    candidate_sections_config,
    chatbot_widget_config,
    column_config,
    email_send_config,
    email_template_overrides,
    graph_client,
    interview_scheduling_config,
    interview_slot_config,
    interviewer_auth,
    interviewer_domains,
    legacy_features_config,
    llm_config,
    mailbox_account,
    notify_config,
    pipeline_config,
    round_interviewers_config,
    sample_data_visibility,
    sample_interview,
    scoring_config,
    system_reset,
)
from app.services import users as user_store

log = logging.getLogger(__name__)

router = APIRouter(
    prefix="/settings", tags=["settings"], dependencies=[Depends(require_backoffice_access)]
)


class NotificationSettings(BaseModel):
    email: Optional[str] = Field(None, description="Recipient for pipeline alerts")
    run_summary: bool = True
    manual_review: bool = True
    exhausted: bool = True
    new_p1: bool = True


class PipelineSettings(BaseModel):
    run_time: str = Field("00:00", description="Daily run time HH:MM (→ SCHEDULE_CRON)")
    timezone: Optional[str] = None
    max_retries: int = Field(3, ge=1, le=10)
    archive_after_days: int = Field(30, ge=1, le=365)
    archive_ats_threshold: float = Field(30, ge=0, le=100)
    dedup_threshold: int = Field(85, ge=50, le=100)


@router.get("/notifications")
def get_notifications() -> dict[str, Any]:
    return {**notify_config.get(), "graph_configured": graph_client.is_configured()}


@router.put("/notifications")
def put_notifications(body: NotificationSettings) -> dict[str, Any]:
    saved = notify_config.save(body.model_dump())
    return {**saved, "graph_configured": graph_client.is_configured()}


@router.get("/pipeline")
def get_pipeline() -> dict[str, Any]:
    return pipeline_config.get()


@router.put("/pipeline")
def put_pipeline(body: PipelineSettings) -> dict[str, Any]:
    return pipeline_config.save(body.model_dump())


class ScoringSettings(BaseModel):
    # P1/P2/P3 minimum atsscore thresholds (0–100, descending); P4 is the rest.
    ats_bands: dict[str, float] = Field(default_factory=dict)
    # Per-stream classification keyword lists injected into the L3 prompt.
    stream_keywords: dict[str, list[str]] = Field(default_factory=dict)
    # Certificate filter tags shown as checkboxes in the Resume Library cert filter.
    cert_tags: list[str] = Field(default_factory=list)


@router.get("/scoring")
def get_scoring() -> dict[str, Any]:
    return scoring_config.get()


@router.put("/scoring")
def put_scoring(body: ScoringSettings) -> dict[str, Any]:
    return scoring_config.save(body.model_dump())


class ChatbotWidgetSettings(BaseModel):
    visible: bool = True


@router.get("/chatbot-widget")
def get_chatbot_widget() -> dict[str, Any]:
    return chatbot_widget_config.get()


@router.put("/chatbot-widget")
def put_chatbot_widget(body: ChatbotWidgetSettings) -> dict[str, Any]:
    return chatbot_widget_config.save(body.visible)


class InterviewSlotSettings(BaseModel):
    api_url: str = Field("", description="External API that returns an interview-slot-picker link")
    param_round: str = Field("round", description="Request key the API expects for the round name")
    param_name: str = Field("candidate_name", description="Request key the API expects for the candidate's name")
    param_email: str = Field("email", description="Request key the API expects for the candidate's email")
    override_email: str = Field(
        "", description="QA override — sent instead of the candidate's real email when set"
    )


@router.get("/interview-slot-picker")
def get_interview_slot_settings() -> dict[str, Any]:
    return interview_slot_config.get()


@router.put("/interview-slot-picker")
def put_interview_slot_settings(body: InterviewSlotSettings) -> dict[str, Any]:
    return interview_slot_config.save(body.model_dump())


class CandidateSectionsSettings(BaseModel):
    quick_signals: bool = False
    thinking_summary: bool = False
    ats_breakdown: bool = False
    nlrs_breakdown: bool = True
    skills: bool = False
    certificates: bool = True
    career_timeline: bool = False
    round_history: bool = True


@router.get("/candidate-sections")
def get_candidate_sections() -> dict[str, Any]:
    return candidate_sections_config.get()


@router.put("/candidate-sections")
def put_candidate_sections(body: CandidateSectionsSettings) -> dict[str, Any]:
    return candidate_sections_config.save(body.model_dump())


# ── Legacy Features — TEMP section, remove once each flag's legacy affordance
# is deleted from the codebase (see app.services.legacy_features_config). ──

class LegacyFeaturesSettings(BaseModel):
    interview_round_button: bool = False
    external_slot_link_button: bool = False
    qb_enrich_button: bool = False
    qb_duplicate_button: bool = False


@router.get("/legacy-features")
def get_legacy_features() -> dict[str, Any]:
    return legacy_features_config.get()


@router.put("/legacy-features", dependencies=[Depends(require_admin)], summary="Admin only")
def put_legacy_features(body: LegacyFeaturesSettings) -> dict[str, Any]:
    return legacy_features_config.save(body.model_dump())


class ColumnEntry(BaseModel):
    key: str
    visible: bool = True


class ColumnSettings(BaseModel):
    # Ordered columns ([{key, visible}]); list order = left-to-right display order.
    columns: list[ColumnEntry] = Field(default_factory=list)


@router.get("/columns")
def get_columns() -> dict[str, Any]:
    """Candidates-table column config: ordered [{key, label, visible}]."""
    return column_config.get()


@router.put("/columns")
def put_columns(body: ColumnSettings) -> dict[str, Any]:
    return column_config.save([e.model_dump() for e in body.columns])


@router.post("/reload")
def reload_from_env() -> dict[str, Any]:
    """Re-read ``.env`` + ``secrets/*.env`` into the running process and re-apply.

    Lets you edit env files and apply the changes live (no container restart). Order:
    ``.env`` first (so edited base config applies), then the UI-managed ``secrets/*.env``
    (which win for their keys), then reschedule the cron from the new SCHEDULE_CRON/TZ.
    Note: ``.env`` is only re-read if it is present in the container (bind-mounted).
    """
    from app.services import scheduler

    try:
        from dotenv import load_dotenv

        load_dotenv(override=True)  # /app/.env when mounted; no-op otherwise
    except Exception:  # noqa: BLE001 — dotenv optional / file absent
        pass
    pipeline_config.load()
    notify_config.load()
    scoring_config.load()
    rescheduled = scheduler.reschedule()
    return {
        "reloaded": True,
        "rescheduled": rescheduled,
        "pipeline": pipeline_config.get(),
        "notifications": notify_config.get(),
        "schedule": scheduler.schedule_description(),
        "next_run": scheduler.next_run_time(),
        "graph_configured": graph_client.is_configured(),
    }


@router.post("/notifications/test")
def test_notification() -> dict[str, Any]:
    """Send a one-off test email to the configured recipient (verifies Graph Mail.Send)."""
    to = notify_config.recipient()
    if not to:
        return {"sent": False, "error": "no_recipient"}
    return graph_client.send_mail(
        to,
        "NeuLeap — test notification",
        "<p>This is a test notification from NeuLeap. Pipeline alerts are configured "
        f"to send to <b>{to}</b>.</p>",
    )


# Recruiter apply-predicted-NBA permission moved to Mailbox → Batch Archive
# (per-source-tag, not a single global toggle) — see app.api.batch_archive.


# ── Interviewer Access — email-domain allow-list + remember-me duration ─────

class InterviewerDomainEntry(BaseModel):
    domain: str
    allowed: bool = True


class InterviewerAccessSettings(BaseModel):
    domains: list[InterviewerDomainEntry]
    remember_days: int = interviewer_domains.DEFAULT_REMEMBER_DAYS


class RevokeDomainRequest(BaseModel):
    domain: str


@router.get("/interviewer-access", response_model=InterviewerAccessSettings)
def get_interviewer_access() -> dict[str, Any]:
    return interviewer_domains.get_config()


@router.put("/interviewer-access", response_model=InterviewerAccessSettings)
def put_interviewer_access(body: InterviewerAccessSettings) -> dict[str, Any]:
    return interviewer_domains.save_config(
        [d.model_dump() for d in body.domains], body.remember_days
    )


@router.post("/interviewer-access/revoke")
def revoke_interviewer_domain(body: RevokeDomainRequest) -> dict[str, Any]:
    """Forces every remembered device under this domain to redo the email-code
    challenge — does not touch the domain's allow/deny setting itself."""
    revoked = interviewer_auth.invalidate_domain_sessions(body.domain)
    return {"domain": body.domain, "sessions_revoked": revoked}


@router.get("/interviewer-access/sample-link")
def get_sample_interview_link() -> dict[str, Any]:
    """Back-compat single link (the Round 1 scenario) — prefer
    /interviewer-access/sample-links for all four verdict-picker scenarios."""
    return sample_interview.get_sample_link()


@router.post("/interviewer-access/sample-link/reset")
def reset_sample_interview_link() -> dict[str, Any]:
    """Back-compat — resets just the Round 1 scenario."""
    return sample_interview.reset_sample_round()


@router.get("/interviewer-access/sample-links")
def get_sample_interview_links() -> dict[str, dict[str, Any]]:
    """One stable, always-clickable interview link per verdict-picker scenario
    (Screening / Round 1 / Round 2 / Final) against a fully-mocked demo
    candidate — so an Admin/System Admin can exercise every flavor of the
    interviewer experience without touching real candidate data. Self-heals
    (recreates the mock candidate/rounds/resume) if any are ever missing."""
    return sample_interview.get_sample_links()


@router.post("/interviewer-access/sample-links/{round_name}/reset")
def reset_sample_interview_scenario(round_name: str) -> dict[str, Any]:
    """Clears any verdict/feedback left over from a previous test on this ONE
    scenario, and makes it the demo candidate's active round again, so the
    feedback/verdict flow can be exercised from a clean slate."""
    try:
        return sample_interview.reset_sample_round(round_name)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


class SampleDataVisibilitySettings(BaseModel):
    visible: bool = True


@router.get("/sample-data-visibility")
def get_sample_data_visibility() -> dict[str, Any]:
    """Whether the "Sample Data" source tag appears in source-tag pickers app-
    wide. `toggle_shown` tells the Settings page whether to render this
    control at all — it's always False (and `visible` always False) outside a
    QA/non-production environment."""
    return sample_data_visibility.get()


@router.put("/sample-data-visibility")
def put_sample_data_visibility(body: SampleDataVisibilitySettings) -> dict[str, Any]:
    return sample_data_visibility.save(body.visible)


# ── Round Interviewers — per-round-type roster used to source calendar
# availability for the candidate slot-selection flow ────────────────────────

class RoundInterviewerEntry(BaseModel):
    name: str
    email: str


class RoundTypeEntry(BaseModel):
    key: str = ""
    label: str
    custom: bool = False
    interviewers: list[RoundInterviewerEntry] = Field(default_factory=list)


class RoundInterviewersSettings(BaseModel):
    round_types: list[RoundTypeEntry] = Field(default_factory=list)


@router.get("/round-interviewers")
def get_round_interviewers() -> dict[str, Any]:
    return round_interviewers_config.get()


@router.put("/round-interviewers")
def put_round_interviewers(body: RoundInterviewersSettings) -> dict[str, Any]:
    saved = round_interviewers_config.save([rt.model_dump() for rt in body.round_types])
    # A removed interviewer's OPEN pool placeholders must stop being offered —
    # reconcile the live pools against the new roster right away (booked slots
    # are left intact).
    try:
        from app.services import interview_pools

        pruned = interview_pools.prune_derostered_slots()
        saved["slots_pruned"] = pruned.get("cancelled", 0)
    except Exception as exc:  # noqa: BLE001 — the roster save already succeeded
        log.warning("settings: pruning de-rostered pool slots failed: %s", exc)
    return saved


# ── Interview Scheduling — native candidate slot-picker settings ───────────

class InterviewSchedulingSettings(BaseModel):
    qa_calendar_email: str = interview_scheduling_config.DEFAULTS["qa_calendar_email"]
    slot_duration_minutes: int = interview_scheduling_config.DEFAULTS["slot_duration_minutes"]
    reminder_max_count: int = interview_scheduling_config.DEFAULTS["reminder_max_count"]
    reminder_interval_hours: int = interview_scheduling_config.DEFAULTS["reminder_interval_hours"]
    auto_reject_after_days: int = interview_scheduling_config.DEFAULTS["auto_reject_after_days"]
    # "minutes" is accepted only in a QA environment (validated in save()).
    reminder_interval_unit: Literal["hours", "minutes"] = "hours"
    auto_reject_after_unit: Literal["days", "minutes"] = "days"
    auto_invite_enabled: bool = interview_scheduling_config.DEFAULTS["auto_invite_enabled"]


@router.get("/interview-scheduling")
def get_interview_scheduling() -> dict[str, Any]:
    out = interview_scheduling_config.get()
    # Tells the UI whether to offer the QA-only minute units at all — computed,
    # never persisted.
    out["minutes_allowed"] = system_reset.is_wipe_allowed()
    return out


@router.put("/interview-scheduling")
def put_interview_scheduling(body: InterviewSchedulingSettings) -> dict[str, Any]:
    try:
        return interview_scheduling_config.save(body.model_dump())
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@router.post("/interview-scheduling/revert")
def revert_interview_scheduling() -> dict[str, Any]:
    return interview_scheduling_config.revert_to_default()


# ── Email Base Templates — the per-NBA-key subject/body every generated
# draft starts from (Mailbox → Archives & Interview Slots). ─────────────────

class EmailTemplateUpdate(BaseModel):
    key: str
    subject: str = ""
    body: str = ""


@router.get("/email-templates")
def get_email_templates() -> dict[str, Any]:
    return {
        "templates": email_template_overrides.list_effective(),
        "placeholders": email_template_overrides.PLACEHOLDERS,
    }


@router.put("/email-templates", dependencies=[Depends(require_admin)], summary="Admin only")
def put_email_template(body: EmailTemplateUpdate) -> dict[str, Any]:
    """Save one template's override — or clear both fields to revert it to
    the shipped default."""
    try:
        return email_template_overrides.save(body.key, body.subject, body.body)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


# ── Email Send Controls — auto-send + draft-review-required ────────────────

class EmailSendSettings(BaseModel):
    auto_send_enabled: bool = False
    draft_review_required: bool = True


@router.get("/email-send-config")
def get_email_send_config() -> dict[str, Any]:
    return email_send_config.get()


@router.put("/email-send-config")
def put_email_send_config(body: EmailSendSettings) -> dict[str, Any]:
    current = email_send_config.get()
    if body.auto_send_enabled and not current["auto_send_enabled"]:
        raise HTTPException(
            403,
            "Turning on auto-send requires the separate confirmation step "
            "(POST /settings/email-send-config/enable-auto-send).",
        )
    if not body.draft_review_required and current["draft_review_required"]:
        raise HTTPException(
            403,
            "Turning off draft review requires the separate confirmation step "
            "(POST /settings/email-send-config/disable-draft-review).",
        )
    try:
        return email_send_config.save(body.model_dump())
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


class ReauthRequest(BaseModel):
    username: str
    password: str


def _require_own_sysadmin_password(body: ReauthRequest, user: AuthUser, *, action: str) -> None:
    if user.role != "sysadmin":
        raise HTTPException(403, f"Only a System Admin can {action}.")
    if body.username.strip().lower() != user.email.strip().lower():
        raise HTTPException(403, "Confirm with your own account's credentials.")
    if not user_store.authenticate(body.username, body.password):
        raise HTTPException(401, "Incorrect password.")


@router.post("/email-send-config/enable-auto-send")
def enable_auto_send(
    body: ReauthRequest, user: AuthUser = Depends(get_current_user)
) -> dict[str, Any]:
    """Turns ON auto-send — every draft's "Mark ready to send" starts
    prompting an immediate send-confirmation instead of just saving. Gated
    behind the acting System Admin re-entering their OWN password, same
    reasoning (and same friction, deliberately) as disable_draft_review below:
    this is the switch that makes real candidate emails actually start
    leaving the system."""
    _require_own_sysadmin_password(body, user, action="enable auto-send")
    cfg = email_send_config.get()
    return email_send_config.save({**cfg, "auto_send_enabled": True})


# ── Mailbox Account — intake mailbox credentials + folder routing ───────────

class MailboxAccountUpdate(ReauthRequest):
    """Config + the acting System Admin's OWN credentials (ReauthRequest
    fields) — changing where candidate mail is read from / moved to (and the
    stored mailbox secret) is deliberately high-friction."""
    email: EmailStr
    # Empty/omitted keeps the already-stored password (folder edits never
    # require re-typing the secret).
    mailbox_password: str = ""
    scan_folder: str
    folder_processing: str
    folder_processed: str
    folder_failed: str
    folder_non_resume: str


@router.get("/mailbox-account")
def get_mailbox_account() -> dict[str, Any]:
    """The intake mailbox config — the password itself never leaves the
    server, only whether one is stored."""
    return mailbox_account.get_public()


@router.put("/mailbox-account")
def put_mailbox_account(
    body: MailboxAccountUpdate, user: AuthUser = Depends(get_current_user)
) -> dict[str, Any]:
    _require_own_sysadmin_password(body, user, action="change the intake mailbox configuration")
    try:
        return mailbox_account.save(
            email=str(body.email),
            password=body.mailbox_password or None,
            updated_by=user.email,
            scan_folder=body.scan_folder,
            folder_processing=body.folder_processing,
            folder_processed=body.folder_processed,
            folder_failed=body.folder_failed,
            folder_non_resume=body.folder_non_resume,
        )
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


# ── Referrals — classify candidates by the sender of their resume email ──────

class ReferralEntry(BaseModel):
    value: str
    message: str = ""
    # Optional subject STYLE with a <Sender> placeholder — when set, the
    # referrer is extracted from the email subject instead of the sender.
    subject_pattern: str = ""


class ReferralConfigUpdate(BaseModel):
    # Each email/domain entry carries its own optional clip message.
    emails: list[ReferralEntry] = []
    domains: list[ReferralEntry] = []


@router.get("/referral-config")
def get_referral_config() -> dict[str, Any]:
    from app.services import referral_config

    return referral_config.get()


@router.put("/referral-config", dependencies=[Depends(require_admin)])
def put_referral_config(body: ReferralConfigUpdate) -> dict[str, Any]:
    from app.services import referral_config

    try:
        return referral_config.save({
            "emails": [e.model_dump() for e in body.emails],
            "domains": [d.model_dump() for d in body.domains],
        })
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


# ── LLM Model Keys — provider connection + per-module overrides ─────────────

class LlmModuleOverride(BaseModel):
    """One module's optional override — blank fields inherit the global row.
    api_key: empty keeps the stored key, "-" clears it."""
    endpoint: str = ""
    deployment: str = ""
    api_key: str = ""


class LlmConfigUpdate(ReauthRequest):
    """LLM connection + the acting System Admin's OWN credentials — these keys
    move every token the app spends, so the same high-friction gate as the
    mailbox credentials applies."""
    endpoint: str = ""
    # Empty keeps the stored key; the literal "-" clears it.
    api_key: str = ""
    api_version: str = ""
    deployment: str = ""
    fallback_deployment: str = ""
    modules: dict[str, LlmModuleOverride] = {}


@router.get("/llm-config")
def get_llm_config() -> dict[str, Any]:
    """The LLM connection config — keys never leave the server, only whether
    one is stored (globally and per module)."""
    out = llm_config.get_public()
    out["module_names"] = llm_config.MODULES
    return out


@router.put("/llm-config")
def put_llm_config(
    body: LlmConfigUpdate, user: AuthUser = Depends(get_current_user)
) -> dict[str, Any]:
    _require_own_sysadmin_password(body, user, action="change the LLM model keys")
    unknown = set(body.modules) - set(llm_config.MODULES)
    if unknown:
        raise HTTPException(422, f"Unknown module(s): {', '.join(sorted(unknown))}")
    try:
        return llm_config.save(
            endpoint=body.endpoint,
            api_key=body.api_key or None,
            api_version=body.api_version,
            deployment=body.deployment,
            fallback_deployment=body.fallback_deployment,
            modules={k: v.model_dump() for k, v in body.modules.items()},
            updated_by=user.email,
        )
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


# ── Graph API — Azure app-registration credentials for mail + calendar ───────

class GraphConfigUpdate(ReauthRequest):
    """Graph app credentials + the acting System Admin's OWN credentials — the
    client secret authenticates the whole mail/calendar integration, so the
    same high-friction gate as the mailbox account / LLM keys applies."""
    tenant_id: str = ""
    client_id: str = ""
    # Empty keeps the stored secret; the literal "-" clears it.
    client_secret: str = ""


@router.get("/graph-config")
def get_graph_config() -> dict[str, Any]:
    """The Graph API connection — the client secret never leaves the server,
    only whether one is stored."""
    from app.services import graph_config

    return graph_config.get_public()


@router.put("/graph-config")
def put_graph_config(
    body: GraphConfigUpdate, user: AuthUser = Depends(get_current_user)
) -> dict[str, Any]:
    from app.services import graph_config

    _require_own_sysadmin_password(body, user, action="change the Graph API credentials")
    return graph_config.save(
        tenant_id=body.tenant_id,
        client_id=body.client_id,
        client_secret=body.client_secret or None,
        updated_by=user.email,
    )


@router.post("/email-send-config/disable-draft-review")
def disable_draft_review(
    body: ReauthRequest, user: AuthUser = Depends(get_current_user)
) -> dict[str, Any]:
    """Turns OFF draft review — drafts send the instant they're created, with
    no recruiter look before they go out. Deliberately gated behind the
    acting System Admin re-entering their OWN password (not just their
    already-valid session token) — this flips a "no human ever checks this
    email before it leaves" switch, so a moment of friction here is
    intentional, not a bug."""
    _require_own_sysadmin_password(body, user, action="disable draft review")
    cfg = email_send_config.get()
    if not cfg["auto_send_enabled"]:
        raise HTTPException(400, "Auto-send must be enabled before draft review can be turned off.")
    return email_send_config.save({**cfg, "draft_review_required": False})
