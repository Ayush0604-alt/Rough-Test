"""Layer 1 (mail intake) routes — mounted as an APIRouter by the merged app.

Endpoints
---------
GET  /health                 liveness + which backends are wired
POST /intake/graph           pull unread Microsoft Graph mail -> stage as pending
POST /upload                 upload pdf/docx/zip/xlsx        -> stage as pending
GET  /intake/pending         list everything queued for the next run
POST /run-pipeline           run L1 LangGraph over all pending items (L1 only)
GET  /runs/{run_id}          poll a run's status + report
POST /handoff/done           mark an E_id range done -> webhook (optional/legacy)

The pipeline engine is the deterministic LangGraph workflow (no LLM required).
``/run-pipeline`` runs **L1 only**; the full L1→L2→L3 pipeline is the merged
orchestrator's ``/pipeline/run-all``. Startup (DB init, MinIO, scheduler) lives
in the merged app's lifespan — an APIRouter has no on_event.
"""

from __future__ import annotations

import os
import threading
from typing import Any, Optional

import requests
from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from pydantic import BaseModel, Field

from app.api.auth import require_backoffice_access
from app.db import email_master as db
from app.logging_config import get_logger
from app.mail_config import MAX_UPLOAD_ABSOLUTE_BYTES, Settings
from app.models.mail import Layer1State
from app.pipeline.mail.graph import build_graph, initial_state
from app.services import clock, graph_client, scheduler
from app.services import mail_intake as intake
from app.services import mail_storage as storage

log = get_logger(__name__)

# Optional Azure-OpenAI / env loading (also primes os.environ from the env file).
try:
    from app.services.agent_llm import load_env
    load_env()
except Exception:  # noqa: BLE001 — env file is optional in container deploys
    pass

# Mailbox/intake — Admin or System Admin only (Recruiter has no Mailbox access).
router = APIRouter(tags=["layer1 (mail intake)"], dependencies=[Depends(require_backoffice_access)])

ACCEPTED_UPLOAD_EXT = {".pdf", ".docx", ".doc", ".zip", ".xlsx"}

# In-process run registry: run_id -> {status, report, summary, started_at, ...}
_RUNS: dict[str, dict[str, Any]] = {}
_RUNS_LOCK = threading.Lock()


def settings() -> Settings:
    base = os.environ.get("NEULEAP_BASE_DIR")
    return Settings(base_dir=__import__("pathlib").Path(base)) if base else Settings()


# Back-compat private alias used internally.
_settings = settings


# --------------------------------------------------------------------------- #
# Health
# --------------------------------------------------------------------------- #

@router.get("/intake/health")
def health() -> dict[str, Any]:
    return {
        "status": "ok",
        "postgres": db.is_enabled(),
        "minio": storage.is_enabled(),
        "graph_configured": graph_client.is_configured(),
        "layer2_webhook": bool(os.environ.get("LAYER2_WEBHOOK_URL")),
        "schedule": {
            "enabled": scheduler.is_enabled(),
            "cron": scheduler.cron_expr(),
            "interval_seconds": scheduler.interval_seconds(),  # >0 = testing override
            "description": scheduler.schedule_description(),
            "next_run": scheduler.next_run_time(),
        },
    }


# --------------------------------------------------------------------------- #
# 1) Intake from Graph API
# --------------------------------------------------------------------------- #

class GraphIntakeRequest(BaseModel):
    top: Optional[int] = Field(
        None, ge=1,
        description="Optional cap on unread messages to pull. Omit to take ALL unread.",
    )


@router.post("/intake/graph")
def intake_graph(req: GraphIntakeRequest | None = None) -> dict[str, Any]:
    """Pull unread mail from Microsoft Graph and stage each as a pending item."""
    top = (req or GraphIntakeRequest()).top
    try:
        result = intake.stage_graph_messages(settings(), top=top)
    except RuntimeError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except requests.HTTPError as exc:  # noqa: PERF203
        raise HTTPException(status_code=502, detail=f"graph_error: {exc}") from exc
    return result


# --------------------------------------------------------------------------- #
# 2) Upload (pdf / docx / zip / xlsx)
# --------------------------------------------------------------------------- #

@router.post("/intake/upload")
async def upload(
    file: UploadFile = File(...),
    candidate_source: str = Form(..., description="Where this batch came from, e.g. 'LinkedIn', 'Naukri', 'Referral - Jane'"),
) -> dict[str, Any]:
    """Upload a single pdf/docx/zip/xlsx; stage it as a pending intake item.

    ``candidate_source`` is mandatory — it's attached to every candidate this
    batch produces and becomes filterable on the Dashboard.
    """
    import pathlib

    source_clean = candidate_source.strip()
    if not source_clean:
        raise HTTPException(status_code=422, detail="candidate_source is required")

    ext = pathlib.Path(file.filename or "").suffix.lower()
    if ext not in ACCEPTED_UPLOAD_EXT:
        raise HTTPException(
            status_code=415,
            detail=f"unsupported_type: {ext or 'none'} (allowed: pdf, docx, doc, zip, xlsx)",
        )
    # Bound the buffered bytes (anti-OOM). The per-type size cap is enforced by the
    # deterministic validators during the run, so a file that is over its type cap but
    # under this ceiling still stages and surfaces as FAILED with a file_too_large reason.
    chunks: list[bytes] = []
    total = 0
    while True:
        chunk = await file.read(1024 * 1024)
        if not chunk:
            break
        total += len(chunk)
        if total > MAX_UPLOAD_ABSOLUTE_BYTES:
            raise HTTPException(
                status_code=413,
                detail=f"file_too_large: exceeds {MAX_UPLOAD_ABSOLUTE_BYTES // (1024 * 1024)} MB",
            )
        chunks.append(chunk)
    data = b"".join(chunks)
    if not data:
        raise HTTPException(status_code=400, detail="empty_file")
    item = intake.stage_upload(settings(), file.filename, data, candidate_source=source_clean)
    return {"staged": True, **item}


@router.get("/intake/pending")
def intake_pending() -> dict[str, Any]:
    """List items queued for the next run (derived from email_master)."""
    pending = intake.list_pending(settings())
    return {"count": len(pending), "items": pending}


@router.delete("/intake/pending/{e_id}")
def intake_discard(e_id: str) -> dict[str, Any]:
    """Remove a staged item from the queue before it's processed (purges its files)."""
    return {"discarded": True, **intake.discard_pending(settings(), e_id)}


# --------------------------------------------------------------------------- #
# 3) Run L1 pipeline (L1 only — full pipeline is /pipeline/run-all)
# --------------------------------------------------------------------------- #

def _new_run_id() -> str:
    return "RUN-" + clock.stamp()


def run_l1_graph(run_id: str) -> Layer1State:
    """Run the L1 LangGraph once over all pending items (synchronous)."""
    app_graph = build_graph(settings())
    return app_graph.invoke(initial_state(run_id))  # type: ignore[return-value]


def _execute_run(run_id: str) -> None:
    """Background worker: run the L1 LangGraph pipeline once."""
    try:
        pending = intake.list_pending(settings())
        with _RUNS_LOCK:
            _RUNS[run_id]["pending_at_start"] = [p["e_id"] for p in pending]

        final = run_l1_graph(run_id)
        rows = [r.model_dump() for r in final.get("email_master_rows", [])]
        e_ids = [r["E_id"] for r in rows]
        summary = {
            "items": len(final.get("items", [])),
            "email_master_rows": len(rows),
            "passed": sum(1 for r in rows if r["process_status"] == "Passed"),
            "failed": sum(1 for r in rows if r["process_status"] == "Failed"),
            "discarded": len(final.get("discarded_items", [])),
            "e_id_min": min(e_ids, key=_eid_int) if e_ids else None,
            "e_id_max": max(e_ids, key=_eid_int) if e_ids else None,
        }
        with _RUNS_LOCK:
            _RUNS[run_id].update(
                status="completed", summary=summary, rows=rows,
                report=final.get("_table", ""), finished_at=clock.now_iso(),
            )
        log.info("L1 run %s completed: %s", run_id, summary)
    except Exception as exc:  # noqa: BLE001
        log.exception("L1 run %s failed", run_id)
        with _RUNS_LOCK:
            _RUNS[run_id].update(status="failed", error=str(exc),
                                 finished_at=clock.now_iso())


def _start_run() -> str:
    """Register an L1-only run and execute it on a daemon thread; returns run_id."""
    run_id = _new_run_id()
    with _RUNS_LOCK:
        _RUNS[run_id] = {"run_id": run_id, "status": "running",
                         "started_at": clock.now_iso()}
    threading.Thread(target=_execute_run, args=(run_id,), daemon=True).start()
    return run_id


@router.post("/run-pipeline")
def run_pipeline() -> dict[str, Any]:
    """Trigger an **L1-only** run over all pending intake. Returns a run_id."""
    run_id = _start_run()
    return {"run_id": run_id, "status": "running", "poll": f"/runs/{run_id}"}


@router.get("/runs/{run_id}")
def get_run(run_id: str) -> dict[str, Any]:
    with _RUNS_LOCK:
        run = _RUNS.get(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="unknown run_id")
    return run


# --------------------------------------------------------------------------- #
# 4) Done handoff (legacy/optional — full pipeline auto-chains in-process)
# --------------------------------------------------------------------------- #

class DoneRequest(BaseModel):
    run_id: str
    e_id_start: str = Field(..., description="First E_id in the completed range, e.g. E100")
    e_id_end: str = Field(..., description="Last E_id in the completed range, e.g. E120")


@router.post("/handoff/done")
def handoff_done(req: DoneRequest) -> dict[str, Any]:
    """Optional: fire the Layer-2 webhook for a completed E_id range. The merged
    app chains L1→L2 in-process, so this is only for external consumers."""
    if not db.is_enabled():
        raise HTTPException(status_code=400, detail="PostgreSQL not configured")

    passed_rows = db.passed_in_range(req.e_id_start, req.e_id_end)
    handed = [r["E_id"] for r in passed_rows]

    payload = {
        "run_id": req.run_id, "e_id_start": req.e_id_start, "e_id_end": req.e_id_end,
        "passed_e_ids": handed, "rows": passed_rows, "source_layer": "L1",
    }

    webhook = os.environ.get("LAYER2_WEBHOOK_URL")
    webhook_result: Optional[dict[str, Any]] = None
    if webhook:
        try:
            resp = requests.post(webhook, json=payload, timeout=30)
            webhook_result = {"url": webhook, "status_code": resp.status_code}
        except requests.RequestException as exc:  # noqa: BLE001
            webhook_result = {"url": webhook, "error": str(exc)}
            log.warning("Layer-2 webhook failed: %s", exc)

    return {
        "status": "handoff_ready",
        "handed_off_count": len(handed),
        "passed_e_ids": handed,
        "webhook": webhook_result,
    }


def _eid_int(e_id: str) -> int:
    digits = "".join(ch for ch in str(e_id) if ch.isdigit())
    return int(digits) if digits else 0
