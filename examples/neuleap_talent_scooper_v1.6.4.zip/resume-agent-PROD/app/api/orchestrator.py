"""Batch-phased orchestrator (D8–D12) — the single trigger for the whole app.

Phase 1  L1 runs its LangGraph over the WHOLE pending batch atomically and writes
         every email_master row (one graph.invoke — L1 has no per-mail entry).
Phase 2  Walk the Passed & ¬processed E_ids ONE AT A TIME; each runs L2 (which
         auto-chains L3 in-process, parallel within the mail) to completion, then
         is marked processed. Single-slot boundary = the mail.

Guarded by a process-wide run-lock so manual (/pipeline/run-all) and the cron
never overlap. Writes the batch count + per-stage events to the shared audit_log.
"""
from __future__ import annotations

import logging
import os
import threading
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import TimeoutError as FuturesTimeout
from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response

from app.api import intake as l2_intake
from app.api.auth import require_backoffice_access
from app.repositories import repo
from app.services import audit, clock
from app.services.xlsx_export import (
    XLSX_MEDIA_TYPE,
    Column,
    Sheet,
    build_xlsx_multi,
)

logger = logging.getLogger(__name__)

# Pipeline batch runs — Admin or System Admin only (Recruiter has no Mailbox access).
router = APIRouter(
    prefix="/api/v1/pipeline", tags=["orchestrator"], dependencies=[Depends(require_backoffice_access)]
)

_RUN_LOCK = threading.Lock()

# Live progress for the running batch — drives the Pipeline page progress bar.
# ``total`` is the number of mails phase 2 will process; ``done`` ticks up as each
# finishes. ``total == 0`` while running means "phase running, count not known yet"
# → the UI shows an indeterminate bar.
_PROGRESS_LOCK = threading.Lock()
_PROGRESS: dict[str, Any] = {
    "batch_id": None,
    "phase": "idle",
    "total": 0,
    "done": 0,
    "started_at": None,
    "finished_at": None,
    # The full result of the last run started via the (now async) HTTP
    # endpoint — the frontend's per-mail results table has no other way to
    # see this once /run-all just returns {"started": true} immediately.
    # In-memory only (lost on restart), same as the old React-state-only
    # behavior this replaces — nothing regresses.
    "result": None,
}


def _set_progress(**kw: Any) -> None:
    with _PROGRESS_LOCK:
        _PROGRESS.update(kw)


def get_progress() -> dict[str, Any]:
    with _PROGRESS_LOCK:
        return dict(_PROGRESS)


def _new_batch_id() -> str:
    return "BATCH-" + clock.stamp()


def is_running() -> bool:
    locked = _RUN_LOCK.acquire(blocking=False)
    if locked:
        _RUN_LOCK.release()
        return False
    return True


def _pipeline_has_work() -> tuple[bool, str]:
    """True (with a reason) when there is anything to process; else (False, "empty").

    Work comes from three places — the pipeline is skipped only when ALL are empty:
      1. leftover Passed-but-unprocessed e_ids (a prior partial run),
      2. staged items waiting in MinIO (Upload button / prior intake),
      3. new mail sitting in the Outlook Inbox window.
    """
    # 1. Downstream work still pending.
    try:
        if repo().passed_unprocessed_eids():
            return True, "pending_downstream"
    except Exception as exc:  # noqa: BLE001 — a probe failure must not block a run
        logger.warning("[orchestrator] work-check (downstream) failed: %s", exc)
        return True, "probe_failed"

    # 2. Staged items (uploads / not-yet-run intake).
    try:
        from app.api import mail as l1_api
        from app.services import mail_intake as l1_intake

        if l1_intake.list_staged(l1_api.settings()):
            return True, "staged_items"
    except Exception as exc:  # noqa: BLE001
        logger.warning("[orchestrator] work-check (staged) failed: %s", exc)
        return True, "probe_failed"

    # 3. Graph mail waiting in the Processing queue (the poller feeds it). Probe one —
    #    no staging/move side effects. With auto-promote off, also probe the Inbox,
    #    since the pipeline then self-drains it.
    from app.services import graph_client, graph_poller

    if graph_client.is_configured():
        try:
            if graph_client.fetch_folder("processing", top=1):
                return True, "graph_processing"
            if not graph_poller.auto_promote_enabled() and graph_client.fetch_inbox(top=1):
                return True, "graph_inbox"
        except Exception as exc:  # noqa: BLE001 — Graph hiccup ⇒ don't silently skip
            logger.warning("[orchestrator] work-check (graph) failed: %s", exc)
            return True, "probe_failed"

    return False, "empty"


def _phase1_l1(batch_id: str) -> tuple[int, dict[str, str]]:
    """Drain Graph mail (if configured), run L1 over the whole batch.

    Returns ``(email_master row count, {e_id: message_id})`` where the map holds the
    Graph mails that PASSED L1 and are STILL in the Processing folder — phase 2 moves
    each to Processed (Layer 2 success) or Failed (Layer 2 failure). L1-FAILED Graph
    mail is moved straight to Failed here.
    """
    from app.api import mail as l1_api
    from app.services import graph_client
    from app.services import mail_intake as l1_intake

    l1_settings = l1_api.settings()

    # Drain Microsoft Graph mail into the queue (best-effort). Each staged item carries
    # its (post-move-to-Processing) message id so we can route it once the pipeline
    # decides the outcome — Failed now (L1), Processed/Failed later (L2).
    #
    # TIME-BOXED: Graph intake runs in a worker thread with a hard timeout. The batch is
    # synchronous and MANUAL UPLOADS (already staged in MinIO) are processed by the L1
    # run BELOW — a slow/stuck Outlook drain must never block them. On timeout we proceed
    # without the Graph mail (whatever staged in time is kept; the rest waits for the
    # next run). Tune with GRAPH_INTAKE_TIMEOUT_S (default 45).
    staged_items: list[dict[str, Any]] = []
    if graph_client.is_configured():
        _set_progress(phase="Reading Outlook mail")
        try:
            timeout_s = max(5, int(os.environ.get("GRAPH_INTAKE_TIMEOUT_S", "45")))
        except ValueError:
            timeout_s = 45
        pool = ThreadPoolExecutor(max_workers=1)
        future = pool.submit(l1_intake.stage_graph_messages, l1_settings)
        try:
            staged = future.result(timeout=timeout_s)
            staged_items = staged.get("items", [])
            logger.info("[orchestrator] staged %d Graph message(s)", staged.get("staged_count", 0))
        except FuturesTimeout:
            logger.warning(
                "[orchestrator] Graph intake exceeded %ss — proceeding to L1 without it "
                "(staged uploads still process)", timeout_s,
            )
        except Exception as exc:  # noqa: BLE001 — never abort the batch on intake
            logger.warning("[orchestrator] Graph intake failed: %s", exc)
        finally:
            # Don't block on an orphaned (still-running) drain — it finishes in the
            # background; its staged mail is picked up next run.
            pool.shutdown(wait=False)

    # One atomic graph.invoke over all pending items (Graph-drained + manual uploads).
    _set_progress(phase="Reading mail (L1 intake)")
    final = l1_api.run_l1_graph(batch_id)
    rows = [r.model_dump() for r in final.get("email_master_rows", [])]
    logger.info("[orchestrator] L1 produced %d email_master row(s)", len(rows))

    passed_map = _route_l1_failures(staged_items, rows)
    return len(rows), passed_map


def _route_l1_failures(
    staged_items: list[dict[str, Any]], rows: list[dict[str, Any]]
) -> dict[str, str]:
    """Move L1-FAILED Graph mail Processing → Failed; keep L1-PASSED mail in Processing.

    Returns ``{e_id: message_id}`` for the PASSED mails so phase 2 can move each to
    Processed only after **Layer 2 succeeds** (or to Failed if it errors). Best-effort —
    a mailbox hiccup never affects the batch. Mail staged in an earlier run (absent from
    ``staged_items``) is left untouched.
    """
    from app.services import graph_client

    if not staged_items or not graph_client.is_configured() or not graph_client.move_enabled():
        return {}
    eid_to_msg = {
        it.get("e_id"): it.get("message_id")
        for it in staged_items if it.get("message_id")
    }
    status_by_eid = {r.get("E_id"): r.get("process_status") for r in rows}
    passed_map: dict[str, str] = {}
    for e_id, message_id in eid_to_msg.items():
        if status_by_eid.get(e_id) == "Passed":
            passed_map[e_id] = message_id            # stays in Processing until L2 decides
        else:
            _move_outlook(message_id, "failed", e_id=e_id)
    return passed_map


def _move_outlook(message_id: Optional[str], dest: str, *, e_id: str = "?") -> None:
    """Best-effort Outlook folder move (``processed`` | ``failed``) for a Graph mail.

    No-op when there is no message id (e.g. an upload, not a mailbox message) or when
    Graph moves are disabled. A mailbox hiccup is logged, never raised.
    """
    if not message_id:
        return
    from app.services import graph_client

    if not (graph_client.is_configured() and graph_client.move_enabled()):
        return
    try:
        graph_client.move_message(message_id, dest)
    except Exception as exc:  # noqa: BLE001 — best-effort mailbox routing
        logger.warning("[orchestrator] move %s -> %s failed: %s", e_id, dest, exc)


def _phase2_downstream(
    batch_id: str, eid_to_msg: dict[str, str]
) -> list[dict[str, Any]]:
    """Serial per-mail loop: L2 (+ fused L3) for each Passed & ¬processed E_id.

    The Outlook mail stays in **Processing** until here. Only once Layer 2 finishes
    cleanly is it moved Processing → **Processed**; an L2 error or a retry-exhausted
    e_id moves it to **Failed**. ``eid_to_msg`` maps the e_id to its Processing-folder
    message id; e_ids without one (e.g. uploads) simply skip the move.
    """
    results: list[dict[str, Any]] = []
    eids = list(repo().passed_unprocessed_eids())
    _set_progress(phase="Processing resumes", total=len(eids), done=0)
    for idx, e_id in enumerate(eids, start=1):
        message_id = eid_to_msg.get(e_id)
        if audit.is_exhausted(e_id):
            logger.warning("[orchestrator] %s exhausted (>=%d fails) — skipping",
                           e_id, audit._exhaustion_threshold())
            audit.write_event(batch_id=batch_id, e_id=e_id, layer="L2",
                              step="gate", status="Exhausted",
                              fail_reason="retry-exhaustion gate")
            _move_outlook(message_id, "failed", e_id=e_id)
            _set_progress(done=idx)
            continue
        try:
            resp = l2_intake.process_email(e_id)   # L2 + fused L3 (auto_extract)
            repo().mark_processed(e_id)
            audit.write_stage_events(batch_id, e_id, resp)
            results.append({
                "e_id": e_id,
                "total_files": resp.total_files,
                "passed": resp.passed,
                "failed": resp.failed,
                "extractions": len(resp.extractions or []),
            })
            # process_email ran L2 + auto-chained L3 to completion → only NOW, after
            # Layer 3 success, move the mail Processing → Processed.
            _move_outlook(message_id, "processed", e_id=e_id)
        except Exception as exc:  # noqa: BLE001
            logger.exception("[orchestrator] downstream failed for %s", e_id)
            audit.write_failure(batch_id, e_id, layer="L2/L3", reason=str(exc))
            results.append({"e_id": e_id, "error": str(exc)})
            _move_outlook(message_id, "failed", e_id=e_id)
        _set_progress(done=idx)
    return results


def _run_all_inner() -> dict[str, Any]:
    """The actual batch body: L1 (atomic) → per-mail L2+L3 (serial). Caller
    must already hold _RUN_LOCK (see run_all / start_run_all_async) — this
    function never touches the lock itself, so it's safe to run either
    directly (cron path) or inside a background thread (HTTP path)."""
    has_work, reason = _pipeline_has_work()
    if not has_work:
        logger.info("[orchestrator] skipped — mail queue empty (nothing to process)")
        return {
            "skipped": True,
            "reason": "empty_queue",
            "batch_id": None,
            "mail_count": 0,
            "processed": 0,
            "results": [],
        }
    batch_id = _new_batch_id()
    logger.info("[orchestrator] starting %s (work=%s)", batch_id, reason)
    _set_progress(
        batch_id=batch_id, phase="Reading mail (L1 intake)",
        total=0, done=0, started_at=clock.now_iso(), finished_at=None,
    )
    mail_count, eid_to_msg = _phase1_l1(batch_id)    # Outlook intake + uploads → L1
    audit.write_batch_row(batch_id, mail_count)      # D11
    # Passed E_ids → L2 + L3; each Outlook mail moves to Processed only after L2.
    results = _phase2_downstream(batch_id, eid_to_msg)
    _send_run_summary(batch_id, mail_count, results)  # email notification (best-effort)
    return {
        "batch_id": batch_id,
        "mail_count": mail_count,
        "processed": len(results),
        "results": results,
    }


def run_all() -> dict[str, Any]:
    """Run one full batch synchronously — blocks until it finishes. Used by
    the scheduled cron job (already running in its own APScheduler thread, so
    blocking there is harmless). The HTTP endpoint uses start_run_all_async
    instead — a batch can run many minutes, far longer than most reverse-proxy
    read timeouts sit in front of an HTTP request."""
    if not _RUN_LOCK.acquire(blocking=False):
        raise HTTPException(status_code=409, detail="a batch is already running")
    try:
        return _run_all_inner()
    finally:
        _set_progress(phase="done", finished_at=clock.now_iso())
        _RUN_LOCK.release()


def start_run_all_async() -> dict[str, Any]:
    """HTTP-facing kickoff — acquires the run-lock synchronously (so a rapid
    double-click/second tab still gets an immediate 409, same as before),
    then runs the actual batch in a background thread and returns right away.
    Poll GET /pipeline/status for progress and GET /pipeline/last-run once it
    finishes — the response body here carries no result, unlike run_all()."""
    if not _RUN_LOCK.acquire(blocking=False):
        raise HTTPException(status_code=409, detail="a batch is already running")

    def _worker() -> None:
        try:
            result = _run_all_inner()
            _set_progress(result=result)
        except Exception as exc:  # noqa: BLE001 — a background-thread crash must not vanish silently
            logger.exception("[orchestrator] background run_all failed")
            _set_progress(result={"error": str(exc)})
        finally:
            _set_progress(phase="done", finished_at=clock.now_iso())
            _RUN_LOCK.release()

    threading.Thread(target=_worker, daemon=True, name="pipeline-run-all").start()
    return {"started": True}


def _send_run_summary(
    batch_id: str, mail_count: int, results: list[dict[str, Any]]
) -> None:
    """Email a run digest to the configured recipient (best-effort; never raises).

    Sends only when a recipient is set AND the 'Run summary' toggle is on. The P1 /
    exhausted toggles gate the extra sections. Requires the app to hold Graph
    **Mail.Send**; a missing permission just logs a warning.
    """
    try:
        from app.services import graph_client, notify_config

        cfg = notify_config.get()
        to = cfg.get("email")
        if not to or not cfg.get("run_summary"):
            return

        candidates = repo().candidates_for_batch(batch_id)
        p1 = [c for c in candidates if str(c.get("priority") or "").upper() == "P1"]
        errors = [r for r in results if r.get("error")]

        rows = "".join(
            f"<tr><td style='padding:4px 12px 4px 0'>{label}</td>"
            f"<td style='padding:4px 0'><b>{value}</b></td></tr>"
            for label, value in [
                ("Mails in batch", mail_count),
                ("Processed", len(results)),
                ("Candidates created", len(candidates)),
                ("Errors", len(errors)),
            ]
        )
        extra = ""
        if cfg.get("new_p1") and p1:
            items = "".join(
                f"<li>{c.get('name') or c.get('candidate_id')} — "
                f"ATS {c.get('atsscore')}, {c.get('stream') or '—'}</li>"
                for c in p1[:20]
            )
            extra += f"<p><b>New P1 candidates ({len(p1)}):</b></p><ul>{items}</ul>"
        if cfg.get("exhausted") and errors:
            extra += f"<p><b>{len(errors)}</b> email(s) errored — see Audit Logs.</p>"

        html = (
            f"<h2>NeuLeap pipeline run</h2>"
            f"<p>Batch <code>{batch_id}</code> finished.</p>"
            f"<table style='border-collapse:collapse'>{rows}</table>{extra}"
        )
        graph_client.send_mail(to, f"NeuLeap run summary — {batch_id}", html)
    except Exception as exc:  # noqa: BLE001 — a notification must never break the run
        logger.warning("[orchestrator] run-summary email failed: %s", exc)


# ── Routes ────────────────────────────────────────────────────────────────────

@router.post(
    "/run-all",
    summary="Start the full L1→L2→L3 pipeline for one batch (returns immediately)",
)
def run_all_endpoint() -> dict[str, Any]:
    return start_run_all_async()


@router.get("/status", summary="Is a batch running? + live progress for the bar")
def status() -> dict[str, Any]:
    prog = get_progress()
    return {
        "running": is_running(),
        "phase": prog["phase"],
        "total": prog["total"],
        "done": prog["done"],
        "batch_id": prog["batch_id"],
        # The finished run's full per-mail result, once the background worker
        # completes — None while running or before the first run this process
        # lifetime. See start_run_all_async.
        "result": prog["result"],
    }


@router.get("/last-run", summary="Most recent batch run, read from the audit ledger")
def last_run() -> dict[str, Any]:
    return {"last_run": audit.last_run_summary()}


@router.get("/batches", summary="History of all batch runs (newest first)")
def list_batches() -> dict[str, Any]:
    return {"batches": audit.list_batches()}


@router.get(
    "/batches/{batch_id}/failures",
    summary="Per-file failures in a batch (which resume failed and why)",
)
def batch_failures(batch_id: str) -> dict[str, Any]:
    return {"batch_id": batch_id, "failures": audit.batch_failures(batch_id)}


# Export contract — a recruiter-readable report, not a raw DB dump. Title-case
# headers, the columns a recruiter scans FIRST up front, JSON-array fields rendered
# as readable text (kind="list"), and free-text columns wrapped. Internal blobs
# (raw_response, evidence_snippets, role_context, experience method/confidence,
# timeline/gap_ranges JSON, round_id) are intentionally omitted.
_EXPORT_COLUMNS = [
    # ── Identity ──
    Column("candidate_id", "Candidate ID", "text"),
    Column("name", "Name"),
    Column("email", "Email", "text"),
    Column("phno", "Phone", "text"),
    # ── Verdict (color-coded) ──
    Column("status", "Status"),
    Column("recommendation", "Recommendation"),
    Column("atsscore", "ATS Score", "float"),
    Column("roundname", "Current Round"),
    Column("screened", "Screened"),
    # ── Fit ──
    Column("domain", "Domain"),
    Column("yearofexp", "Years of Experience", "float"),
    Column("fresher_or_lateral", "Fresher / Lateral"),
    Column("priority", "Priority"),
    Column("primary_skills", "Primary Skills", "list"),
    Column("currentcompany", "Current Company"),
    Column("currentlocation", "Current Location"),
    Column("relocation", "Open to Relocation"),
    # ── Education ──
    Column("highest_coursecompleted", "Highest Qualification"),
    Column("stream", "Stream"),
    Column("clg", "College"),
    Column("education_status", "Education Status"),
    Column("passoutyr", "Passout Year", "int"),
    Column("cgpa", "CGPA", "float"),
    # ── Experience detail ──
    Column("total_companieswitched", "Companies Switched", "int"),
    Column("careergap", "Career Gap"),
    Column("gap_months", "Gap (Months)", "int"),
    Column("gap_count", "Gap Count", "int"),
    Column("job_roles", "Job Roles", "list"),
    Column("projects", "Projects", "list"),
    Column("certificates", "Certificates", "list"),
    # ── Assessment narrative ──
    Column("analysis", "Analysis", "auto", True),
    # ── Provenance ──
    Column("s3_file_path", "Resume Path"),
    Column("e_id", "Source Email ID", "text"),
    Column("mail_send_date", "Received Date", "date"),
    Column("previously_seen", "Previously Seen"),
    Column("failure_reason", "Failure Reason", "auto", True),
    Column("parsed_at", "Parsed At", "datetime"),
    Column("created_at", "Created At", "datetime"),
    Column("updated_at", "Updated At", "datetime"),
    Column("closed_at", "Closed At", "datetime"),
]


# "Discarded" sheet — every non-clean outcome in a batch (duplicate, re-application,
# not-a-resume, corrupt, invalid file, pending extraction, failed, exhausted, …).
# These don't land as a clean candidate, so the Candidates sheet alone under-reports
# the batch; this second sheet accounts for them so the export reconciles.
_DISCARDED_COLUMNS = [
    Column("E_id", "E_id", "text"),
    Column("filename", "Filename"),
    Column("outcome", "Outcome"),
    Column("reason", "Reason"),
    Column("duplicate_of", "Duplicate_of", "text"),
    Column("state", "State"),
    Column("created_at", "Time", "datetime"),
]

# review_queue.kind → recruiter-friendly outcome label for the Discarded sheet.
_OUTCOME_BY_KIND = {
    "duplicate": "Duplicate",
    "duplicate_hired": "Duplicate (already hired)",
    "reapplication": "Reapplication",
    "not_resume": "Not a resume",
    "corrupt": "Corrupt file",
    "invalid_file": "Invalid file",
    "excel_row": "Spreadsheet row — missing resume",
    "link_fetch": "Link could not be fetched",
    "extraction_fail": "Extraction failed",
    "pending_extraction": "Pending extraction",
    "exhausted": "Exhausted — retries ran out",
    "failed": "Failed",
}
# Kinds where candidate_id is the ORIGINAL candidate this row relates to.
_DUP_OF_KINDS = {"duplicate", "duplicate_hired", "reapplication"}


def _discarded_row(rec: dict[str, Any]) -> dict[str, Any]:
    """Shape a normalized review_queue / pending-extraction row for the Discarded sheet."""
    kind = (rec.get("kind") or "").lower()
    return {
        "E_id": rec.get("E_id"),
        "filename": rec.get("filename"),
        "outcome": _OUTCOME_BY_KIND.get(kind, kind or "Failed"),
        "reason": rec.get("reason") or None,
        "duplicate_of": rec.get("candidate_id") if kind in _DUP_OF_KINDS else None,
        "state": rec.get("state"),
        "created_at": rec.get("created_at"),
    }


@router.get(
    "/batches/{batch_id}/candidates.xlsx",
    summary="Export a batch's candidates as Excel (.xlsx)",
)
def export_batch_candidates(batch_id: str) -> Response:
    candidates = repo().candidates_for_batch(batch_id)
    discarded = [_discarded_row(r) for r in repo().discarded_for_batch(batch_id)]
    content = build_xlsx_multi([
        Sheet("Candidates", _EXPORT_COLUMNS, candidates,
              status_field="status", score_field="atsscore"),
        Sheet("Discarded", _DISCARDED_COLUMNS, discarded),
    ])
    return Response(
        content=content,
        media_type=XLSX_MEDIA_TYPE,
        headers={
            "Content-Disposition": f'attachment; filename="{batch_id}_candidates.xlsx"'
        },
    )
