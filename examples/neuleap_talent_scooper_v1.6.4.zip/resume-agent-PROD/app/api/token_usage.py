"""Admin "Token Usage" dashboard — read-only aggregates over the
llm_token_usage ledger (app.services.token_usage). Admin-gated: tokenomics is
an operations/cost view, not a recruiting one."""
from __future__ import annotations

from datetime import date
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException

from app.api.auth import require_admin
from app.services import token_usage

router = APIRouter(prefix="/api/v1", tags=["token usage"])


@router.get("/token-usage", dependencies=[Depends(require_admin)])
def get_token_usage(
    date_from: Optional[date] = None,
    date_to: Optional[date] = None,
    source: Optional[str] = None,
) -> dict:
    if date_from and date_to and date_from > date_to:
        raise HTTPException(status_code=422, detail="date_from must be on or before date_to")
    return token_usage.summary(date_from=date_from, date_to=date_to, source=source or None)
