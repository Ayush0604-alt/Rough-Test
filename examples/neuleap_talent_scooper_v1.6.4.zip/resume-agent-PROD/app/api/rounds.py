"""Layer 4 (recruiter) API — screening rounds + candidate lifecycle.

Owns the recruiter-driven side of candidate_master that the pipeline never
touches: interview rounds, status transitions, and priority overrides. All
routes are mounted under /api/v1 alongside intake/extraction.
"""
from __future__ import annotations

import logging
from typing import Optional

import requests
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from app.api.auth import AuthUser, get_current_user, require_admin
from app.repositories import repo
from app.services import (
    audit,
    candidate_slot,
    email_send,
    email_send_config,
    email_templates,
    interview_pools,
    interview_slot_config,
    recruiter_apply_config,
)
from app.services.nlrs import compute_nlrs, predicted_nba_key
from app.stages import (
    ONBOARDING_STAGE_LABELS,
    VALID_ONBOARDING_STAGES,
    VALID_STAGES,
    candidate_stage_bucket,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1", tags=["layer4 (screening)"])


# ── Status lifecycle (recruiter-owned, step 23) ───────────────────────────────
VALID_STATUSES = {
    "Pending Extraction", "Pending Resume",
    "Active", "Hired", "Rejected", "Closed", "Undecided",
}

# Legal recruiter transitions. Pipeline writes (→Active) bypass this.
ALLOWED_TRANSITIONS = {
    "Pending Resume": {"Active", "Closed"},
    "Pending Extraction": {"Active", "Closed"},
    "Active": {"Hired", "Rejected", "Closed", "Undecided"},
    # Hired/Rejected are a REVERSIBLE verdict, not a dead end: a recruiter can flip
    # one to the other (corrected a call) or re-open to Active. This mirrors the
    # Final-round outcome toggle (Pass↔Fail) in the repo, so both the round-outcome
    # and direct-status paths behave identically.
    "Hired": {"Rejected", "Active", "Closed"},
    "Rejected": {"Hired", "Active", "Closed"},
    "Closed": {"Active"},           # reversible
    # Undecided is a paused/parked state (set via the "Undecided for now" NBA) — a
    # recruiter can pull the candidate back into Active (and thus any round stage)
    # or resolve them straight to Hired/Rejected/Closed.
    "Undecided": {"Active", "Hired", "Rejected", "Closed"},
}

VALID_PRIORITIES = {"P1", "P2", "P3", "P4"}

# Next Best Action override keys + labels — must mirror the SPA's NBA_OPTIONS
# (frontend/src/components/candidate/NextActionOverride.tsx), so the activity-log
# summary reads the same sentence the recruiter picked from in the dropdown.
_NBA_OPTIONS = {
    "call_now": (
        "Share interview slots for Screening",
        "Agent action: send an ack-email — acknowledge & ask the candidate to pick an interview slot via the link in the email",
    ),
    "reject": (
        "Straight Reject",
        "Agent action: candidate is rejected & no email is sent — moves to the Reject bucket",
    ),
    "reject_email": (
        "Rejected — decline email drafted",
        "Agent action: candidate is rejected after the interview and a polite decline email is "
        "drafted for review — sent on your action (or auto if auto-send is configured) — moves "
        "to the Reject bucket",
    ),
    "undecided": (
        "Undecided for now",
        "Most freshers/interns fall here. Agent action: send an ack-email — let the candidate know we'll "
        "reach back when a matching opportunity arises. Moves to the Undecided bucket, so they can be pulled "
        "back into Round 1 or any other stage later (including a follow-up slot-picker email) once a matching "
        "opportunity arises",
    ),
    "office_interview": (
        "Share interview slots for Final round (in-office)",
        "Agent action: send an ack-email — ask the candidate to pick an in-office interview slot via the link "
        "and come to the office — moves to the Final round",
    ),
    "final_round": (
        "Share interview slots for Final round",
        "Agent action: send an ack-email — ask the candidate to pick an interview slot via the link in the "
        "email — moves to the Final round",
    ),
    "share_round2": (
        "Share interview slots for Round 2",
        "System-predicted for a very strong candidate (NLRS fast-track band). Agent action: send an ack-email "
        "— ask the candidate to pick a Round 2 interview slot via the link in the email, skipping Screening "
        "and Round 1 to cut needless cycles for a clearly promising profile — moves to Round 2",
    ),
    "share_round3": (
        "Share interview slots for Round 3",
        "Agent action: send an ack-email — ask the candidate to pick a Round 3 interview slot via the link "
        "in the email — moves to Round 3 (the optional round, offered when the candidate's plan includes it)",
    ),
    "share_round1": (
        "Share interview slots for Round 1",
        "System-predicted for a strong candidate (NLRS fast-track band). Agent action: send an ack-email — "
        "ask the candidate to pick a Round 1 interview slot via the link in the email, skipping Screening to "
        "cut needless cycles for a clearly promising profile — moves to Round 1",
    ),
    "hire": (
        "Mark for Immediate Hire / Send Offer letter",
        "Agent action: move to the Hiring System for offer preparation & invitation, then immediate onboarding "
        "(or wait out the notice period) — once joined, move to the Onboarding system for allocation & processing",
    ),
}
VALID_NBA_KEYS = {*_NBA_OPTIONS, "custom"}

# VALID_STAGES (the canonical stage vocabulary) lives in app.stages so the
# repository can share it for auto-advance without an import cycle.


def _validate_stage(round_name: Optional[str]) -> None:
    if round_name is not None and round_name not in VALID_STAGES:
        raise HTTPException(
            status_code=422,
            detail=f"unknown stage '{round_name}'; must be one of {sorted(VALID_STAGES)}",
        )


# ── Request models ────────────────────────────────────────────────────────────

class StatusUpdate(BaseModel):
    status: str


class PriorityUpdate(BaseModel):
    priority: str


class NextActionOverrideUpdate(BaseModel):
    # null/omitted key clears the override, reverting to the ATS-derived suggestion.
    key: Optional[str] = None
    text: Optional[str] = None
    # Free-text reason typed in the comment popup — appended to the Actions
    # Audit Log entry, never stored on the candidate row itself.
    comment: Optional[str] = None


class ScreeningUpdate(BaseModel):
    currentlocation: Optional[str] = None
    relocation: Optional[bool] = None


class RoundCreate(BaseModel):
    candidate_id: str
    round_name: Optional[str] = None        # New | Round 1 | Round 2
    domain: Optional[str] = None
    interviewer: Optional[str] = None
    current_ctc: Optional[float] = None
    expected_ctc: Optional[float] = None
    notice_period: Optional[int] = None     # days; captured on the Screening round
    relocation: Optional[bool] = None
    scheduled_on: Optional[str] = None
    feedback: Optional[str] = None
    score: Optional[float] = None
    outcome: Optional[str] = None
    # Live Workflow email/acceptance sub-steps for this round (every round type).
    invite_sent_at: Optional[str] = None
    candidate_accepted_slot: Optional[bool] = None


class RoundUpdate(BaseModel):
    round_name: Optional[str] = None
    domain: Optional[str] = None
    interviewer: Optional[str] = None
    current_ctc: Optional[float] = None
    expected_ctc: Optional[float] = None
    notice_period: Optional[int] = None     # days; captured on the Screening round
    relocation: Optional[bool] = None
    scheduled_on: Optional[str] = None
    feedback: Optional[str] = None
    score: Optional[float] = None
    outcome: Optional[str] = None
    # Fast-track target on a Pass: advance to this stage instead of the planned next
    # (e.g. Round 2 → skip the optional Round 3 → Final). Validated in the repo; an
    # invalid value falls back to the planned next stage.
    advance_to: Optional[str] = None
    # Interview-plan choices captured ONCE on the Screening round:
    #   next_interviewer — the Round 1 interviewer to assign on the round created by
    #     passing Screening (entered manually by the recruiter);
    #   include_round3   — whether the optional Round 3 runs.
    next_interviewer: Optional[str] = None
    include_round3: Optional[bool] = None
    # Live Workflow email/acceptance sub-steps for this round (every round type —
    # Screening/Round 1/Round 2/Final). reminder_count is normally advanced via
    # POST /rounds/{id}/send-reminder (capped at 2), not set directly here.
    invite_sent_at: Optional[str] = None
    reminder_count: Optional[int] = None
    candidate_accepted_slot: Optional[bool] = None


class OnboardingUpdate(BaseModel):
    # Advance/set the onboarding stage directly (see app.stages.ONBOARDING_STAGE_ORDER).
    stage: Optional[str] = None
    expected_join_date: Optional[str] = None   # ISO date, or "" to clear
    onboarding_date: Optional[str] = None      # ISO date, or "" to clear
    # Toggle ONE checklist item's done/pending flag (its `key`, e.g. "offer_letter_signed").
    checklist_item: Optional[str] = None


# ── Candidate (single read + recruiter mutations) ─────────────────────────────

@router.get("/candidates/{candidate_id}", summary="Fetch one candidate row")
def get_candidate(candidate_id: str) -> dict:
    row = repo().get_candidate(candidate_id)
    if not row:
        raise HTTPException(status_code=404, detail=f"candidate {candidate_id} not found")
    # Enrich with the sender address of the source email (email_master.sender_mail_id),
    # so the candidate page can show WHICH mailbox this resume arrived from, not just
    # the E_id. Best-effort: a missing/legacy e_id just leaves source_mail_id absent.
    eid = row.get("e_id")
    _subject = None
    if eid:
        email = repo().get_email(eid)
        if email:
            row["source_mail_id"] = email.get("sender_mail_id")
            _subject = email.get("subject")
    # Referral classification (Settings → Referrals) — a clip on the candidate
    # page when the resume's sender is on the referral allow-list. When the
    # matched entry has a subject pattern, "referred by" is extracted from the
    # email subject instead of the sender. None when it isn't a referral.
    from app.services import referral_config
    row["referral"] = referral_config.classify(row.get("source_mail_id"), _subject)
    # Computed "Proposed Next Best Action" for the profile — the next interview round
    # in this candidate's plan, derived deterministically from the current round +
    # its verdict (no LLM, no stored column). Single source of truth = interview_plan.
    from app.services import interview_plan
    row["next_action"] = interview_plan.next_best_action(
        current=row.get("roundname"),
        round_status=row.get("round_status"),
        include_round3=bool(row.get("include_round3")),
        priority=row.get("priority"),
    )
    # Pending (status='draft', not yet marked ready) email draft — drives the
    # "draft ready for review" badge next to the Proposed Next Best Action box.
    row["pending_email_draft"] = repo().latest_pending_drafts([candidate_id]).get(candidate_id)
    from app.services.nlrs import enrich_with_nlrs
    enrich_with_nlrs(row)
    return row


@router.patch("/candidates/{candidate_id}/status", summary="Recruiter status transition")
def patch_status(candidate_id: str, body: StatusUpdate) -> dict:
    if body.status not in VALID_STATUSES:
        raise HTTPException(status_code=422, detail=f"unknown status '{body.status}'")
    current = repo().get_candidate(candidate_id)
    if not current:
        raise HTTPException(status_code=404, detail=f"candidate {candidate_id} not found")
    cur_status = current.get("status")
    if body.status != cur_status and body.status not in ALLOWED_TRANSITIONS.get(cur_status, set()):
        raise HTTPException(
            status_code=409,
            detail=f"illegal transition {cur_status} → {body.status}",
        )
    row = repo().update_candidate_status(candidate_id, body.status)
    if body.status != cur_status:
        audit.write_event(
            candidate_id=candidate_id, layer="L4", step="status_change", status="Info",
            fail_reason=f"Status changed: {cur_status} → {body.status}",
            stage=candidate_stage_bucket(row),
        )
    return row


@router.patch("/candidates/{candidate_id}/priority", summary="Recruiter priority override")
def patch_priority(candidate_id: str, body: PriorityUpdate) -> dict:
    if body.priority not in VALID_PRIORITIES:
        raise HTTPException(status_code=422, detail=f"unknown priority '{body.priority}'")
    current = repo().get_candidate(candidate_id)
    if not current:
        raise HTTPException(status_code=404, detail=f"candidate {candidate_id} not found")
    old_priority = current.get("priority")
    row = repo().update_candidate_priority(candidate_id, body.priority)
    if body.priority != old_priority:
        audit.write_event(
            candidate_id=candidate_id, layer="L4", step="priority_override", status="Info",
            fail_reason=f"Priority overridden: {old_priority or '—'} → {body.priority}",
            stage=candidate_stage_bucket(row),
        )
    return row


# NBA keys whose "Agent action" moves the candidate's stage — applied automatically
# when that key is selected (see patch_next_action_override). Keys absent from both
# maps below (call_now, custom) never move the candidate.
_NBA_STATUS_EFFECTS = {
    "reject": "Rejected",
    "reject_email": "Rejected",
    "undecided": "Undecided",
    "hire": "Hired",
}
_NBA_ROUND_EFFECTS = {
    "office_interview": "Final",
    "final_round": "Final",
    "share_round3": "Round 3",
    "share_round2": "Round 2",
    "share_round1": "Round 1",
}


def _nba_set_status(candidate_id: str, new_status: str) -> Optional[dict]:
    """Best-effort status transition triggered by an NBA selection. Unlike the
    direct PATCH /status endpoint this never raises — an NBA-triggered move that
    turns out to be illegal (e.g. already Hired) is silently skipped so the
    override itself always still saves. Returns the updated row, or None if the
    candidate is missing/transition wasn't applicable."""
    current = repo().get_candidate(candidate_id)
    if not current:
        return None
    cur_status = current.get("status")
    if new_status == cur_status:
        return current
    if new_status not in ALLOWED_TRANSITIONS.get(cur_status, set()):
        return None
    row = repo().update_candidate_status(candidate_id, new_status)
    audit.write_event(
        candidate_id=candidate_id, layer="L4", step="status_change", status="Info",
        fail_reason=f"Status changed: {cur_status} → {new_status} (via Next Best Action)",
        stage=candidate_stage_bucket(row),
    )
    return row


def _nba_create_round(candidate_id: str, round_name: str) -> Optional[dict]:
    """Best-effort round creation triggered by an NBA selection — mirrors POST
    /rounds but skips (rather than erroring) when the candidate is already
    parked in a terminal/paused status or already sitting in this exact round,
    so re-selecting the same NBA twice doesn't create duplicate rounds."""
    current = repo().get_candidate(candidate_id)
    if not current:
        return None
    if current.get("status") in ("Hired", "Rejected", "Closed", "Undecided"):
        return None
    if (current.get("roundname") or "").strip() == round_name:
        return None
    row = repo().create_round({"candidate_id": candidate_id, "round_name": round_name})
    audit.write_event(
        candidate_id=candidate_id, layer="L4", step="round_created", status="Info",
        fail_reason=f"Round created: {round_name} (via Next Best Action selection)",
        stage=candidate_stage_bucket({"roundname": round_name}),
    )
    return row


def _apply_nba_key(
    candidate_id: str,
    key: Optional[str],
    text: Optional[str],
    *,
    source: str,
    comment: Optional[str] = None,
    bulk: bool = False,
) -> dict:
    """Shared core of every NBA-setting action: save the override, run the
    stage-move automation, and generate an email draft if the key's Agent
    action sends one. ``source`` is just an audit-log word ("manual override" /
    "predicted NBA") so the two entry points (admin-only manual pick vs.
    apply-the-system-prediction) read differently in the Actions Audit Log."""
    # `source` records HOW this NBA got set ("predicted" = Apply button, "manual"
    # = admin override picker) so the UI can later show "Applied"/"Overridden"
    # instead of a stale/misleading "Predicted" or blank state once predicted_nba
    # itself has gone null (see app.services.nlrs.enrich_with_nlrs).
    override = None if key is None else {"key": key, "text": text, "source": source}
    row = repo().update_candidate_next_action_override(candidate_id, override)
    if not row:
        raise HTTPException(status_code=404, detail=f"candidate {candidate_id} not found")
    # The recruiter/admin's typed reason travels ONLY into the audit trail;
    # bulk applies carry the same comment per candidate, marked (bulk-apply).
    reason = _nba_summary(override, source=source)
    if comment and comment.strip():
        reason += f' — Reason: "{comment.strip()[:500]}"'
    if bulk:
        reason += " (bulk-apply)"
    audit.write_event(
        candidate_id=candidate_id,
        layer="L4",
        step="next_action_override",
        status="Info",
        fail_reason=reason,
        stage=candidate_stage_bucket(row),
    )

    # ── Stage-move automation, triggered on selection (best-effort: a skipped
    # move never blocks the override save above) ───────────────────────────────
    if key:
        # Any key NOT in _NBA_STATUS_EFFECTS (call_now/office_interview/
        # final_round/custom) is a "keep this candidate moving through the
        # pipeline" action — if they're currently parked in a paused/terminal
        # status (Undecided/Hired/Rejected/Closed) from an EARLIER NBA pick,
        # picking one of these now must pull them back to Active, or the
        # stage badge stays stuck on the old status forever even though a
        # brand-new forward action was just taken. A no-op when already Active
        # (_nba_set_status skips same-status transitions).
        new_status = _NBA_STATUS_EFFECTS.get(key, "Active")
        if new_status:
            row = _nba_set_status(candidate_id, new_status) or row
        round_name = _NBA_ROUND_EFFECTS.get(key)
        if round_name:
            _nba_create_round(candidate_id, round_name)
            row = repo().get_candidate(candidate_id) or row  # roundname/roundid changed

        # ── Email draft — only for keys whose Agent action sends an ack-email ──
        draft = email_templates.render_draft(key, row.get("name"))
        if draft:
            subject, draft_body = draft
            draft_row = repo().create_email_draft(candidate_id, key, subject, draft_body)
            audit.write_event(
                candidate_id=candidate_id, layer="L4", step="email_draft_generated",
                status="Info",
                fail_reason=f'Email draft generated for review: "{subject}"',
                stage=candidate_stage_bucket(row),
                draft_id=draft_row["draft_id"],
            )
            # Settings → Email Send Controls → "Draft review required" OFF (only
            # possible when auto-send is also on) — skip the recruiter review
            # step entirely and send immediately. Full detail still lands in the
            # audit trail via email_send.send_draft, whether it sends or not.
            cfg = email_send_config.get()
            if cfg["auto_send_enabled"] and not cfg["draft_review_required"]:
                send_body = draft_body
                # A slot-invite email MUST carry a real slot-picker link. In
                # auto-send mode nobody inserts it by hand, so mint + insert it
                # here. If that fails, PAUSE the send (never ship a broken link)
                # and flag a blinking caution on the candidate (dashboard + stage)
                # so an operator can resolve it. The link is mandatory; the
                # question bank (bound below) is optional.
                if email_templates.SLOT_LINK_PLACEHOLDER in draft_body:
                    link = candidate_slot.pool_slot_link_for_round(
                        candidate_id, row.get("roundid"), row.get("roundname"),
                        row.get("source"), row.get("email"),
                    )
                    if not link:
                        reason = (
                            f"Auto-send paused for {row.get('roundname') or 'this round'} — the "
                            "interview slot-picker link couldn't be inserted: no matching interviewer "
                            "timeslot pool, NO OPEN SLOTS available in it, or the public URL isn't "
                            "configured. Gather/refresh the pool's slots, then open the draft and mark "
                            "it ready (or send manually)."
                        )
                        repo().set_invite_block(candidate_id, reason)
                        audit.write_event(
                            candidate_id=candidate_id, layer="L4",
                            step="email_draft_send_blocked", status="Failed",
                            fail_reason=reason, stage=candidate_stage_bucket(row),
                            draft_id=draft_row["draft_id"],
                        )
                        return row
                    send_body = draft_body.replace(email_templates.SLOT_LINK_PLACEHOLDER, link)
                    # Persist the resolved link so the draft a recruiter opens later shows it too.
                    repo().update_email_draft(draft_row["draft_id"], body=send_body)
                    draft_row = {**draft_row, "body": send_body}

                # Bind a pre-assigned question bank to this round if one is waiting
                # (optional — a missing bank never blocks the send).
                try:
                    alloc = repo().get_candidate_allocation(candidate_id, row.get("roundid"))
                    if alloc and alloc.get("round_id") is None and row.get("roundid"):
                        repo().update_allocation(
                            alloc["allocation_id"],
                            {"round_id": row.get("roundid"), "round_name": row.get("roundname")},
                        )
                except Exception:  # noqa: BLE001 — QB binding is best-effort
                    pass

                try:
                    result = email_send.send_draft(draft_row, row)
                    if result["sent"]:
                        repo().mark_email_draft_sent(draft_row["draft_id"])
                        repo().set_invite_block(candidate_id, None)  # clear any prior caution
                except Exception as exc:  # noqa: BLE001 — must not fail the NBA action
                    logger.warning("auto-send failed for draft %s: %s", draft_row["draft_id"], exc)
    return row


@router.patch(
    "/candidates/{candidate_id}/next-action",
    summary="Admin: manually override the Next Best Action to an arbitrary value",
)
def patch_next_action_override(
    candidate_id: str,
    body: NextActionOverrideUpdate,
    _admin: AuthUser = Depends(require_admin),
) -> dict:
    if body.key is not None:
        if body.key not in VALID_NBA_KEYS:
            raise HTTPException(status_code=422, detail=f"unknown next-action key '{body.key}'")
        if body.key == "custom" and not (body.text or "").strip():
            raise HTTPException(status_code=422, detail="text is required when key='custom'")
    return _apply_nba_key(candidate_id, body.key, body.text, source="manual", comment=body.comment)


def _new_stage_eligible(row: dict) -> bool:
    """A candidate is still "New" (never screened, nothing already applied) —
    the only stage the predicted-NBA Accept/Apply button is valid for."""
    return (
        row.get("status") == "Active"
        and not row.get("roundid")
        and not row.get("next_action_override")
    )


def _require_can_apply_predicted_nba(user: AuthUser, row: dict) -> None:
    """Mailbox → Batch Archive → Live batches → per-source "Recruiters can
    apply predicted NBA" (default off, configured per campaign source — see
    app.services.recruiter_apply_config). Admin/System Admin are never gated
    by this — it only ever restricts the Recruiter role, and only for THIS
    candidate's own source. Enforced here (not just a hidden button) so a
    direct API call can't bypass the toggle."""
    if user.role == "recruiter" and not recruiter_apply_config.is_enabled_for(row.get("source")):
        raise HTTPException(
            status_code=403,
            detail="Applying the predicted Next Best Action is disabled for Recruiters for this "
            "candidate's source — ask an Admin to turn it on (Mailbox → Batch Archive), or ask "
            "them to review this candidate.",
        )


@router.post(
    "/candidates/{candidate_id}/apply-predicted-nba",
    summary="Apply the system-predicted (NLRS-based) Next Best Action — New stage only",
)
def apply_predicted_nba(
    candidate_id: str,
    body: Optional["ApplyPredictedBody"] = None,
    user: AuthUser = Depends(get_current_user),
) -> dict:
    """Recruiter-safe counterpart to the admin-only manual override: the key is
    always computed SERVER-SIDE from the candidate's own NLRS, never taken from
    the request — so this can never be used to set an arbitrary NBA. The
    candidate must still be in the "New" bucket (unscreened, no prior
    override); applying is what actually moves them forward — nothing advances
    until this is called, even though the prediction is visible earlier."""
    row = repo().get_candidate(candidate_id)
    if not row:
        raise HTTPException(status_code=404, detail=f"candidate {candidate_id} not found")
    _require_can_apply_predicted_nba(user, row)
    if not _new_stage_eligible(row):
        raise HTTPException(
            status_code=409,
            detail="Predicted NBA can only be applied while the candidate is in the New stage.",
        )
    key = predicted_nba_key(compute_nlrs(row)["score"])
    return _apply_nba_key(
        candidate_id, key, None, source="predicted", comment=(body.comment if body else None)
    )


class ApplyPredictedBody(BaseModel):
    comment: str = ""


class BulkApplyRequest(BaseModel):
    candidate_ids: list[str]
    # One shared reason recorded on EVERY affected candidate's audit entry,
    # marked (bulk-apply).
    comment: str = ""


@router.post(
    "/candidates/apply-predicted-nba/bulk",
    summary="Bulk-apply the system-predicted Next Best Action to several New-stage candidates",
)
def apply_predicted_nba_bulk(
    body: BulkApplyRequest, user: AuthUser = Depends(get_current_user)
) -> dict:
    results: list[dict] = []
    for cid in body.candidate_ids:
        row = repo().get_candidate(cid)
        if not row:
            results.append({"candidate_id": cid, "applied": False, "reason": "not found"})
            continue
        if user.role == "recruiter" and not recruiter_apply_config.is_enabled_for(row.get("source")):
            results.append({
                "candidate_id": cid, "applied": False,
                "reason": "Recruiter apply disabled for this candidate's source",
            })
            continue
        if not _new_stage_eligible(row):
            results.append({"candidate_id": cid, "applied": False, "reason": "not in New stage"})
            continue
        key = predicted_nba_key(compute_nlrs(row)["score"])
        _apply_nba_key(cid, key, None, source="predicted", comment=body.comment, bulk=True)
        results.append({"candidate_id": cid, "applied": True, "key": key})
    return {"results": results}


def _nba_summary(override: Optional[dict], *, source: str = "manual") -> str:
    if override is None:
        return "Next Best Action override cleared — reverted to the suggested action."
    key, text = override.get("key"), (override.get("text") or "").strip()
    verb = "Predicted Next Best Action applied" if source == "predicted" else "Next Best Action set"
    if key == "custom":
        return f'{verb} to a custom instruction: "{text}"'
    label, full = _NBA_OPTIONS.get(key, (key, ""))
    return f"{verb} to ‘{label}’ — {full}"


@router.get(
    "/scheduling-cadence",
    summary="Reminder/auto-reject cadence — read-only, any role (Dashboard labels)",
)
def get_scheduling_cadence(user: AuthUser = Depends(get_current_user)) -> dict:
    from app.services import interview_scheduling_config

    cfg = interview_scheduling_config.get()
    return {
        "max_reminders": cfg.get("reminder_max_count", 2),
        "reminder_interval": cfg.get("reminder_interval_hours"),
        "reminder_interval_unit": cfg.get("reminder_interval_unit", "hours"),
        "auto_reject_after": cfg.get("auto_reject_after_days", 7),
        "auto_reject_after_unit": cfg.get("auto_reject_after_unit", "days"),
    }


class CandidateNoteBody(BaseModel):
    text: str


@router.post(
    "/candidates/{candidate_id}/note",
    summary="Stick a note on the candidate — any role, any time",
)
def add_candidate_note(
    candidate_id: str, body: CandidateNoteBody, user: AuthUser = Depends(get_current_user)
) -> dict:
    """Saves the note as the candidate's LATEST (the sticky note on their page
    + the yellow badge next to their name) and writes it to the Actions Audit
    Log, which is where the full history of earlier notes lives."""
    text = (body.text or "").strip()
    if not text:
        raise HTTPException(status_code=422, detail="The note text is required.")
    from datetime import datetime, timezone

    payload = {
        "text": text[:250],
        "author": user.email,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    row = repo().update_candidate_latest_note(candidate_id, payload)
    if not row:
        raise HTTPException(status_code=404, detail=f"candidate {candidate_id} not found")
    audit.write_event(
        candidate_id=candidate_id,
        layer="L4",
        step="candidate_note",
        status="Info",
        fail_reason=f'Note by {user.email}: "{text[:500]}"',
        stage=candidate_stage_bucket(row),
    )
    return {"note": payload}


class CandidateRemarkBody(BaseModel):
    text: str


def _note_payload(text: str, user_email: str) -> dict:
    from datetime import datetime, timezone

    return {
        "text": text[:250],
        "author": user_email,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }


@router.post(
    "/candidates/{candidate_id}/remark",
    summary="Set the candidate's remark — visible to the interviewer too",
)
def set_candidate_remark(
    candidate_id: str, body: CandidateRemarkBody, user: AuthUser = Depends(get_current_user)
) -> dict:
    """The remark — like a note but ALSO shown to the interviewer on their
    link view (blue icon next to the name). Only one stays; setting replaces
    it. Empty text clears it. Every change is written to the Actions Audit
    Log (step = candidate_remark)."""
    text = (body.text or "").strip()
    row = repo().get_candidate(candidate_id)
    if not row:
        raise HTTPException(status_code=404, detail=f"candidate {candidate_id} not found")
    if not text:
        # Empty = remove (idempotent: no-op when there's nothing to clear).
        old = (row.get("latest_remark") or {}).get("text")
        updated = repo().update_candidate_latest_remark(candidate_id, None)
        if old:
            audit.write_event(
                candidate_id=candidate_id, layer="L4", step="candidate_remark", status="Info",
                fail_reason=f'Remark cleared by {user.email} — was: "{old[:500]}"',
                stage=candidate_stage_bucket(updated or row),
            )
        return {"remark": None}
    payload = _note_payload(text, user.email)
    updated = repo().update_candidate_latest_remark(candidate_id, payload)
    existed = bool((row.get("latest_remark") or {}).get("text"))
    audit.write_event(
        candidate_id=candidate_id, layer="L4", step="candidate_remark", status="Info",
        fail_reason=f'Remark {"updated" if existed else "added"} by {user.email}: "{text[:500]}"',
        stage=candidate_stage_bucket(updated or row),
    )
    return {"remark": payload}


class BulkNoteBody(BaseModel):
    candidate_ids: list[str]
    text: str
    # "note" (yellow, internal) or "remark" (blue, interviewer-visible).
    kind: str = "note"


@router.post(
    "/candidates/notes/bulk",
    summary="Apply the same note OR remark to several candidates at once",
)
def bulk_candidate_note(
    body: BulkNoteBody, user: AuthUser = Depends(get_current_user)
) -> dict:
    """One note/remark text stamped on every listed candidate — each becomes
    that candidate's LATEST (replacing any previous), and each is written to
    the Actions Audit Log marked (bulk)."""
    text = (body.text or "").strip()
    if not text:
        raise HTTPException(status_code=422, detail="The note text is required.")
    kind = body.kind if body.kind in ("note", "remark") else "note"
    step = "candidate_remark" if kind == "remark" else "candidate_note"
    updater = (
        repo().update_candidate_latest_remark
        if kind == "remark"
        else repo().update_candidate_latest_note
    )
    results = []
    for cid in body.candidate_ids:
        row = repo().get_candidate(cid)
        if not row:
            results.append({"candidate_id": cid, "applied": False})
            continue
        payload = _note_payload(text, user.email)
        updated = updater(cid, payload)
        audit.write_event(
            candidate_id=cid, layer="L4", step=step, status="Info",
            fail_reason=f'{kind.capitalize()} by {user.email}: "{text[:500]}" (bulk)',
            stage=candidate_stage_bucket(updated or row),
        )
        results.append({"candidate_id": cid, "applied": True})
    return {"results": results, "kind": kind}


@router.delete(
    "/candidates/{candidate_id}/note",
    summary="Delete the candidate's latest note (the deletion itself is audit-logged)",
)
def delete_candidate_note(
    candidate_id: str, user: AuthUser = Depends(get_current_user)
) -> dict:
    """Clears the sticky note + the badge next to the name everywhere. The
    note's text and who deleted it are written to the Actions Audit Log, so
    the full history — including deletions — stays traceable there."""
    row = repo().get_candidate(candidate_id)
    if not row:
        raise HTTPException(status_code=404, detail=f"candidate {candidate_id} not found")
    old = (row.get("latest_note") or {}).get("text")
    if not old:
        raise HTTPException(status_code=404, detail="This candidate has no note to delete.")
    updated = repo().update_candidate_latest_note(candidate_id, None)
    audit.write_event(
        candidate_id=candidate_id,
        layer="L4",
        step="candidate_note",
        status="Info",
        fail_reason=f'Note deleted by {user.email} — was: "{old[:500]}"',
        stage=candidate_stage_bucket(updated or row),
    )
    return {"deleted": True}


@router.get(
    "/candidates/{candidate_id}/audit-log",
    summary="Full processing + recruiter-action audit trail for this candidate",
)
def get_candidate_audit_log(candidate_id: str) -> list[dict]:
    """Every audit_log row for this candidate — L1 (mail intake) through L4
    (recruiter actions) — the SPA groups these by stage on the profile page."""
    return repo().list_candidate_audit_log(candidate_id)


# ── Email drafts (generated by an email-sending NBA selection) ───────────────

class EmailDraftUpdate(BaseModel):
    subject: Optional[str] = None
    body: Optional[str] = None
    # 'ready' marks the draft reviewed and approved to send. No actual dispatch —
    # this is as far as the flow goes today (no Graph mail-send wiring for drafts).
    status: Optional[str] = None


_VALID_DRAFT_STATUSES = {"draft", "ready"}


@router.get(
    "/candidates/{candidate_id}/email-drafts",
    summary="This candidate's email drafts (newest first)",
)
def get_candidate_email_drafts(candidate_id: str) -> list[dict]:
    return repo().list_candidate_email_drafts(candidate_id)


@router.patch(
    "/email-drafts/{draft_id}",
    summary="Review/edit an email draft, or mark it ready to send",
)
def patch_email_draft(draft_id: int, body: EmailDraftUpdate) -> dict:
    if body.status is not None and body.status not in _VALID_DRAFT_STATUSES:
        raise HTTPException(status_code=422, detail=f"unknown draft status '{body.status}'")
    existing = repo().get_email_draft(draft_id)
    if not existing:
        raise HTTPException(status_code=404, detail=f"email draft {draft_id} not found")
    row = repo().update_email_draft(
        draft_id, subject=body.subject, body=body.body, status=body.status
    )
    if body.status == "ready" and existing.get("status") != "ready":
        audit.write_event(
            candidate_id=existing["candidate_id"], layer="L4", step="email_draft_ready",
            status="Info",
            fail_reason=f'Email draft marked ready to send: "{row["subject"]}"',
            draft_id=draft_id,
        )
    return row


@router.get(
    "/email-drafts/{draft_id}/send-preview",
    summary="Who this draft would actually be sent to (QA-restricted if applicable)",
)
def get_send_preview(draft_id: int) -> dict:
    draft = repo().get_email_draft(draft_id)
    if not draft:
        raise HTTPException(status_code=404, detail=f"email draft {draft_id} not found")
    candidate = repo().get_candidate(draft["candidate_id"]) or {}
    recipient, qa_redirected = email_send.resolve_recipient(candidate.get("email"))
    return {
        "recipient": recipient,
        "qa_redirected": qa_redirected,
        "candidate_email": candidate.get("email"),
    }


class SendDraftBody(BaseModel):
    confirm: bool = False


@router.post(
    "/email-drafts/{draft_id}/send",
    summary="Send an email draft now (requires explicit confirmation)",
)
def send_email_draft(draft_id: int, body: SendDraftBody) -> dict:
    if not body.confirm:
        raise HTTPException(status_code=422, detail="Sending requires confirm=true.")
    draft = repo().get_email_draft(draft_id)
    if not draft:
        raise HTTPException(status_code=404, detail=f"email draft {draft_id} not found")
    if draft["status"] == "sent":
        raise HTTPException(status_code=409, detail="This draft has already been sent.")
    candidate = repo().get_candidate(draft["candidate_id"]) or {}
    result = email_send.send_draft(draft, candidate)
    row = draft
    if result["sent"]:
        row = repo().mark_email_draft_sent(draft_id)
        # A manual send resolves any auto-send-paused caution on this candidate.
        repo().set_invite_block(draft["candidate_id"], None)
    return {**result, "draft": row}


class InterviewSlotLinkRequest(BaseModel):
    # The round this scheduling link is for — one of ROUND_PRESETS (frontend
    # constants/index.ts): Screening, Round 1, Round 2, Round 3, Final.
    round: str


@router.post(
    "/email-drafts/{draft_id}/interview-slot-link",
    summary="Call the configured external API for an interview-slot-picker link",
)
def get_interview_slot_link(draft_id: int, body: InterviewSlotLinkRequest) -> dict:
    draft = repo().get_email_draft(draft_id)
    if not draft:
        raise HTTPException(status_code=404, detail=f"email draft {draft_id} not found")
    candidate = repo().get_candidate(draft["candidate_id"])
    if not candidate:
        raise HTTPException(status_code=404, detail=f"candidate {draft['candidate_id']} not found")

    cfg = interview_slot_config.get()
    api_url = (cfg.get("api_url") or "").strip()
    if not api_url:
        raise HTTPException(
            status_code=400,
            detail="Interview slot picker API URL isn't configured (Settings → Interview Slot Picker).",
        )

    email = (cfg.get("override_email") or "").strip() or candidate.get("email") or ""
    payload = {
        cfg.get("param_round") or "round": body.round,
        cfg.get("param_name") or "candidate_name": candidate.get("name") or "",
        cfg.get("param_email") or "email": email,
    }
    try:
        resp = requests.post(api_url, json=payload, timeout=20)
        resp.raise_for_status()
    except requests.RequestException as exc:  # noqa: BLE001
        logger.warning("interview-slot-link call to %s failed: %s", api_url, exc)
        raise HTTPException(
            status_code=502, detail=f"Interview slot picker API call failed: {exc}"
        ) from exc

    link: Optional[str] = None
    try:
        data = resp.json()
        if isinstance(data, dict):
            link = data.get("link") or data.get("url") or data.get("slot_link") or data.get("interview_link")
        elif isinstance(data, str):
            link = data
    except ValueError:
        link = resp.text.strip() or None

    if not link:
        raise HTTPException(
            status_code=502, detail="Interview slot picker API did not return a recognizable link."
        )
    return {"link": link}


@router.post(
    "/email-drafts/{draft_id}/pool-slot-link",
    summary="Mint a native slot-picker link sourced from this candidate's interviewer timeslot pool",
)
def get_pool_slot_link(
    draft_id: int, body: InterviewSlotLinkRequest, user: AuthUser = Depends(get_current_user)
) -> dict:
    """The native counterpart to get_interview_slot_link above — instead of
    calling an external scheduling API, mints a /schedule/{token} link
    (app.api.candidate_slots) scoped to whichever interviewer timeslot pool
    matches this candidate's source + the given round
    (app.services.interview_pools.find_pool_for), if one exists.

    If the candidate doesn't have this round yet (the common case: drafting
    their very first Screening invite, before any round exists), this
    creates it on the spot — same as a recruiter creating the round by hand
    first, then generating the link — subject to the same recruiter-apply-
    NBA gate as manual round creation (create_round above), so this can't be
    used to route a still-New candidate around that gate."""
    draft = repo().get_email_draft(draft_id)
    if not draft:
        raise HTTPException(status_code=404, detail=f"email draft {draft_id} not found")
    candidate = repo().get_candidate(draft["candidate_id"])
    if not candidate:
        raise HTTPException(status_code=404, detail=f"candidate {draft['candidate_id']} not found")

    round_row = next(
        (r for r in repo().list_rounds(draft["candidate_id"]) if r.get("round_name") == body.round), None
    )
    if not round_row:
        if (
            user.role == "recruiter"
            and _new_stage_eligible(candidate)
            and not recruiter_apply_config.is_enabled_for(candidate.get("source"))
        ):
            raise HTTPException(
                status_code=403,
                detail="This candidate's predicted Next Best Action needs Admin review before a round "
                "can be created — ask an Admin to apply it or review this candidate.",
            )
        _validate_stage(body.round)
        round_row = repo().create_round({"candidate_id": draft["candidate_id"], "round_name": body.round})
        audit.write_event(
            candidate_id=draft["candidate_id"], layer="L4", step="round_created", status="Info",
            fail_reason=f"Round created: {body.round} · via pool slot link on email draft {draft_id}",
            stage=candidate_stage_bucket({"roundname": body.round}),
        )
        candidate = repo().get_candidate(draft["candidate_id"]) or candidate

    pool = interview_pools.find_pool_for(candidate.get("source"), body.round)
    if not pool:
        raise HTTPException(
            status_code=404,
            detail=f"No interviewer timeslot pool is configured for {body.round} / this candidate's source.",
        )

    existing = candidate_slot.invite_for_round(round_row["round_id"])
    # Refuse to insert a link when the pool has NO open slots — it would hand the
    # candidate an empty picker. The recruiter is alerted (the button surfaces this)
    # and no link is inserted. An already-booked invite is exempt (it points at the
    # candidate's chosen slot).
    if not (existing and existing.get("booked_at")) and not interview_pools.open_slots_for_pool(pool["id"], body.round):
        raise HTTPException(
            status_code=409,
            detail=f"No open interview slots are available for {body.round} in the "
                   f"\"{pool.get('label') or 'matching'}\" pool right now — gather/refresh its slots "
                   "(or add interviewers) before inserting the slot-picker link.",
        )
    if existing:
        # Reuse the round's token, but make sure it actually points at the pool
        # that matches NOW — an invite minted before this pool existed (or under
        # a different pool) would otherwise keep serving the wrong slot list.
        # Never re-point a booked invite: that slot is already converted.
        if existing.get("pool_id") != pool["id"] and not existing.get("booked_at"):
            candidate_slot.set_invite_pool(existing["token"], pool["id"])
        token = existing["token"]
    else:
        token = candidate_slot.create_invite(
            draft["candidate_id"], round_row["round_id"], candidate.get("email"), pool_id=pool["id"]
        )
    return {"url_path": f"/schedule/{token}"}


@router.post("/candidates/{candidate_id}/archive", summary="Manually archive a candidate")
def archive_candidate(candidate_id: str) -> dict:
    # Snapshot the stage BEFORE archiving — the row leaves candidate_master once
    # archived, so there's nothing left to compute a bucket from afterward.
    pre = repo().get_candidate(candidate_id)
    result = repo().archive_candidate(candidate_id)
    if result["archived"] == 0:
        raise HTTPException(status_code=404, detail=f"candidate {candidate_id} not found")
    audit.write_event(
        candidate_id=candidate_id, layer="L4", step="archive", status="Info",
        fail_reason="Candidate manually archived.",
        stage=candidate_stage_bucket(pre) if pre else None,
    )
    return result


@router.patch("/candidates/{candidate_id}", summary="Fill screening-call fields")
def patch_candidate(candidate_id: str, body: ScreeningUpdate) -> dict:
    row = repo().update_candidate_screening(
        candidate_id,
        currentlocation=body.currentlocation,
        relocation=body.relocation,
    )
    if not row:
        raise HTTPException(status_code=404, detail=f"candidate {candidate_id} not found")
    changes = []
    if body.currentlocation is not None:
        changes.append(f'current location set to "{body.currentlocation}"')
    if body.relocation is not None:
        changes.append(f"relocation willingness set to {'Yes' if body.relocation else 'No'}")
    if changes:
        audit.write_event(
            candidate_id=candidate_id, layer="L4", step="screening_update", status="Info",
            fail_reason="Screening details updated: " + "; ".join(changes),
            stage=candidate_stage_bucket(row),
        )
    return row


# ── Analytics (read-only aggregation) ─────────────────────────────────────────

@router.get("/analytics/rounds", summary="Per-round aging + tile rollups")
def analytics_rounds() -> dict:
    """Active-in-round candidates with aging (days in current round) and per-stage
    tile counts. Drives the Analytics dashboard and resolves the Screening
    ?aging=gt15 / gt30 filters. Read-only; no mutations."""
    return repo().analytics_rounds()


# ── Rounds (step 21) ──────────────────────────────────────────────────────────

@router.get("/candidates/{candidate_id}/rounds", summary="List a candidate's rounds")
def list_rounds(candidate_id: str) -> list[dict]:
    return repo().list_rounds(candidate_id)


@router.post("/rounds", summary="Create a round + point candidate at it")
def create_round(body: RoundCreate, user: AuthUser = Depends(get_current_user)) -> dict:
    candidate = repo().get_candidate(body.candidate_id)
    if not candidate:
        raise HTTPException(status_code=404, detail=f"candidate {body.candidate_id} not found")
    # A Recruiter can't route around the Apply-predicted-NBA gate by just
    # scheduling a round by hand while the candidate is still "New" and admin
    # review is pending for this source — same check as apply-predicted-nba,
    # applied here so there's no other door into moving the candidate forward.
    if (
        user.role == "recruiter"
        and _new_stage_eligible(candidate)
        and not recruiter_apply_config.is_enabled_for(candidate.get("source"))
    ):
        raise HTTPException(
            status_code=403,
            detail="This candidate's predicted Next Best Action needs Admin review before a round "
            "can be scheduled — ask an Admin to apply it or review this candidate.",
        )
    # A round name is mandatory — every round must carry a stage (the UI auto-assigns
    # it from the fixed sequence, this is the server-side safety net).
    if body.round_name is None or not body.round_name.strip():
        raise HTTPException(status_code=422, detail="round_name is required")
    _validate_stage(body.round_name)
    # Atomic in the repo: inserts the round AND repoints candidate_master
    # .roundid/.roundname at it, so the candidate has exactly one active stage.
    row = repo().create_round(body.model_dump())
    summary = f"Round created: {body.round_name}"
    if body.interviewer:
        summary += f" · interviewer {body.interviewer}"
    if body.scheduled_on:
        summary += f" · scheduled {body.scheduled_on}"
    audit.write_event(
        candidate_id=body.candidate_id, layer="L4", step="round_created", status="Info",
        fail_reason=summary,
        stage=candidate_stage_bucket({"roundname": body.round_name}),
    )
    try:
        candidate = repo().get_candidate(body.candidate_id) or {}
        candidate_slot.maybe_create_and_send_invite(
            body.candidate_id, row["round_id"], row.get("round_name"),
            candidate.get("email"), candidate.get("name"), candidate.get("source"),
        )
    except Exception as exc:  # noqa: BLE001 — a slot-invite hiccup must not fail round creation
        logger.warning("auto-invite hook failed for round %s: %s", row.get("round_id"), exc)
    return row


def _round_update_summary(row: dict, data: dict) -> str:
    parts = [f"Round {row.get('round_name') or '?'} updated"]
    if "outcome" in data:
        parts.append(f"outcome={data['outcome']}")
    if "score" in data:
        parts.append(f"score={data['score']}")
    if "scheduled_on" in data:
        parts.append(f"scheduled={data['scheduled_on']}")
    if data.get("feedback"):
        parts.append(f'feedback="{data["feedback"]}"')
    return " · ".join(parts)


@router.patch("/rounds/{round_id}", summary="Update a round (post-interview outcome)")
def update_round(round_id: int, body: RoundUpdate) -> dict:
    data = body.model_dump(exclude_unset=True)
    if "round_name" in data:
        # round_name is mandatory: it may be left untouched, but never cleared.
        if data["round_name"] is None or not str(data["round_name"]).strip():
            raise HTTPException(status_code=422, detail="round_name is required")
        _validate_stage(data["round_name"])
    if data.get("advance_to") is not None:
        _validate_stage(data["advance_to"])
    # A Pass/Fail outcome IS a stage transition — the comment explaining it is
    # mandatory, not optional, so the Actions Audit Log's transition entries are
    # never blank.
    if data.get("outcome") in ("Pass", "Fail") and not (data.get("feedback") or "").strip():
        raise HTTPException(
            status_code=422,
            detail="feedback is required when recording a Pass/Fail outcome",
        )
    # Repo keeps candidate_master in lock-step with the edited round (single
    # source of truth) and, when the recruiter marks the candidate's ACTIVE
    # round as Pass, atomically advances them to the next stage (Final → Offer
    # promotes to Hired). All in one transaction.
    row = repo().update_round(round_id, data)
    if not row:
        raise HTTPException(status_code=404, detail=f"round {round_id} not found")
    cid = row.get("candidate_id")
    if cid and data:
        audit.write_event(
            candidate_id=cid, layer="L4", step="round_updated", status="Info",
            fail_reason=_round_update_summary(row, data),
            stage=candidate_stage_bucket({"roundname": row.get("round_name")}),
        )
    # A Pass verdict may have auto-advanced the candidate to a brand-new round
    # (see pg_repo.update_round) — candidate_master.roundid now points at it.
    # Detect that here (rather than inside the repo, which holds a DB
    # connection open across this call) and fire the slot-invite hook for the
    # newly-active round, same as the direct-create path above.
    if cid:
        try:
            candidate = repo().get_candidate(cid) or {}
            new_round_id = candidate.get("roundid")
            if new_round_id and new_round_id != round_id:
                candidate_slot.maybe_create_and_send_invite(
                    cid, new_round_id, candidate.get("roundname"),
                    candidate.get("email"), candidate.get("name"), candidate.get("source"),
                )
        except Exception as exc:  # noqa: BLE001 — must not fail the round update
            logger.warning("auto-invite hook failed after round %s update: %s", round_id, exc)
    return row


@router.post(
    "/rounds/{round_id}/send-reminder",
    summary="Log a reminder email sent for this round (capped at 2)",
)
def send_round_reminder(round_id: int) -> dict:
    row = repo().send_round_reminder(round_id)
    if not row:
        raise HTTPException(status_code=404, detail=f"round {round_id} not found")
    audit.write_event(
        candidate_id=row["candidate_id"], layer="L4", step="reminder_sent", status="Info",
        fail_reason=f"Reminder email sent for {row.get('round_name') or '?'} "
                    f"({row['reminder_count']}/2)",
        stage=candidate_stage_bucket({"roundname": row.get("round_name")}),
    )
    return row


# ── Post-hire onboarding pipeline (Live Workflow) ─────────────────────────────

@router.patch(
    "/candidates/{candidate_id}/onboarding",
    summary="Advance the post-hire onboarding stage / set a date / toggle a checklist item",
)
def patch_onboarding(candidate_id: str, body: OnboardingUpdate) -> dict:
    current = repo().get_candidate(candidate_id)
    if not current:
        raise HTTPException(status_code=404, detail=f"candidate {candidate_id} not found")
    if current.get("status") != "Hired":
        raise HTTPException(
            status_code=409,
            detail="onboarding can only be tracked for a Hired candidate",
        )
    data = body.model_dump(exclude_unset=True)
    if data.get("stage") is not None and data["stage"] not in VALID_ONBOARDING_STAGES:
        raise HTTPException(status_code=422, detail=f"unknown onboarding stage '{data['stage']}'")
    row = repo().update_candidate_onboarding(
        candidate_id,
        stage=data.get("stage"),
        expected_join_date=data.get("expected_join_date"),
        onboarding_date=data.get("onboarding_date"),
        checklist_item=data.get("checklist_item"),
    )
    if not row:
        raise HTTPException(status_code=404, detail=f"candidate {candidate_id} not found")
    parts = []
    if "stage" in data:
        parts.append(f"stage → {ONBOARDING_STAGE_LABELS.get(data['stage'], data['stage'])}")
    if "expected_join_date" in data:
        parts.append(f"expected join date = {data['expected_join_date'] or '—'}")
    if "onboarding_date" in data:
        parts.append(f"onboarding date = {data['onboarding_date'] or '—'}")
    if "checklist_item" in data:
        parts.append(f"checklist item toggled: {data['checklist_item']}")
    if parts:
        audit.write_event(
            candidate_id=candidate_id, layer="L4", step="onboarding_update", status="Info",
            fail_reason="Onboarding updated: " + "; ".join(parts),
            stage="Hired",
        )
    return row
