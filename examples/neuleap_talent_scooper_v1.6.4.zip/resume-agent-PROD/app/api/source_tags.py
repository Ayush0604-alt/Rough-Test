"""Registered "social post" source tags — Mailbox page's "Register recent
social post as a source tag" button. See app.services.source_tags for the
auto-stamp-onto-Graph-mail behavior this backs.
"""
from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from app.api.auth import require_admin
from app.services import source_tags

router = APIRouter(prefix="/api/v1", tags=["source-tags"])


class RegisterSourceTagRequest(BaseModel):
    platform: str
    label: str
    post_url: Optional[str] = None
    note: Optional[str] = None


class UpdateSourceTagRequest(BaseModel):
    platform: str
    label: str
    post_url: Optional[str] = None
    note: Optional[str] = None


class SetActiveSourceTagRequest(BaseModel):
    tag_id: Optional[str] = None


class DupCheckScopeRequest(BaseModel):
    scoped: bool


@router.get("/source-tags", summary="List registered source tags + which is active")
def get_source_tags() -> dict:
    return source_tags.list_tags()


@router.post("/source-tags", summary="Register a social post as a new source tag (not automatically active)")
def post_source_tag(body: RegisterSourceTagRequest) -> dict:
    label = body.label.strip()
    if not label:
        raise HTTPException(status_code=422, detail="label is required")
    return source_tags.register(
        platform=body.platform.strip() or "Other",
        label=label,
        post_url=(body.post_url or "").strip() or None,
        note=(body.note or "").strip() or None,
    )


@router.put(
    "/source-tags/active",
    summary="Switch (or clear) which source tag is active — Admin only",
    dependencies=[Depends(require_admin)],
)
def put_active_source_tag(body: SetActiveSourceTagRequest) -> dict:
    try:
        return source_tags.set_active(body.tag_id)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.put("/source-tags/{tag_id}", summary="Edit a registered source tag's platform/label/URL/note")
def put_source_tag(tag_id: str, body: UpdateSourceTagRequest) -> dict:
    label = body.label.strip()
    if not label:
        raise HTTPException(status_code=422, detail="label is required")
    try:
        return source_tags.update(
            tag_id,
            platform=body.platform.strip() or "Other",
            label=label,
            post_url=(body.post_url or "").strip() or None,
            note=(body.note or "").strip() or None,
        )
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.delete("/source-tags/{tag_id}", summary="Remove a registered source tag — refused if it's already in use")
def delete_source_tag(tag_id: str) -> dict:
    try:
        return source_tags.delete(tag_id)
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@router.put(
    "/source-tags/{tag_id}/dup-check-scope",
    summary="Scope the duplicate-resume check to just this source (default off = system-wide)",
)
def put_dup_check_scope(tag_id: str, body: DupCheckScopeRequest) -> dict:
    try:
        return source_tags.set_dup_check_scope(tag_id, body.scoped)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
