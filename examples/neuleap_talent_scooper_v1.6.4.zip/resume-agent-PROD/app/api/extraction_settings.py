"""Settings → Extraction & Analysis — Admin-ONLY (not System Admin, unlike the
rest of Settings — this edits the live extraction prompt and scoring formula,
which is a higher blast radius than the rest of the back-office config).

Three independently testable pieces, each with its own "re-run across a
batch (by source tag)" action:
  * SKILL.md whole-file override — app.services.skill_config.
  * Analysis Report prompt-only override (the "simple view") — same module.
  * NLRS weights / NBA bands / custom rules — app.services.nlrs_config.

Batch selection reuses the exact same `source` tag grouping as Mailbox →
Batch Archive (app.services.batch_archive), so "this batch" always means the
same set of candidates in both places.
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from app.api.auth import require_admin
from app.api.batch_archive import BatchRef
from app.config import settings
from app.db import get_candidate
from app.extraction.runner import regenerate_analysis_report
from app.services import batch_archive, nlrs_config, skill_config
from app.services.nlrs import compute_nlrs

router = APIRouter(prefix="/api/v1/settings", tags=["settings"], dependencies=[Depends(require_admin)])


def _candidate_ids(source: Optional[str]) -> list[str]:
    ids = batch_archive.candidate_ids_for_source(source)
    if not ids:
        raise HTTPException(status_code=404, detail="No candidates match that source tag.")
    return ids


# ── SKILL.md (whole file) ────────────────────────────────────────────────────

class SkillOverrideBody(BaseModel):
    text: str


@router.get("/skill-override")
def get_skill_override() -> dict[str, Any]:
    status = skill_config.get_status()
    return {
        "overridden": status["skill_overridden"],
        "active_text": status["skill_active_text"],
        "default_text": status["skill_default_text"],
    }


@router.put("/skill-override")
def put_skill_override(body: SkillOverrideBody) -> dict[str, Any]:
    try:
        skill_config.save_skill_override(body.text)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return get_skill_override()


@router.post("/skill-override/revert")
def revert_skill_override() -> dict[str, Any]:
    skill_config.revert_skill_to_default()
    return get_skill_override()


@router.post("/skill-override/rerun")
def rerun_skill_override(body: BatchRef) -> dict[str, Any]:
    """Full re-extraction (every field, including the Analysis Report) for
    every candidate in this batch — the way to actually see a SKILL.md change
    reflected, since the master prompt drives every field at once."""
    from app.api.extraction import BatchExtractRequest, batch_extract

    ids = _candidate_ids(body.source)
    result = batch_extract(BatchExtractRequest(candidate_ids=ids))
    return {"total": result["total"], "succeeded": result["parsed"], "failed": result["failed"]}


# ── Analysis Report prompt (the "simple view") ───────────────────────────────

class AnalysisPromptBody(BaseModel):
    text: str


@router.get("/analysis-prompt")
def get_analysis_prompt() -> dict[str, Any]:
    status = skill_config.get_status()
    return {
        "overridden": status["analysis_overridden"],
        "active_prompt": status["analysis_active_prompt"],
        "default_prompt": status["analysis_default_prompt"],
    }


@router.put("/analysis-prompt")
def put_analysis_prompt(body: AnalysisPromptBody) -> dict[str, Any]:
    try:
        skill_config.save_analysis_prompt(body.text)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return get_analysis_prompt()


@router.post("/analysis-prompt/revert")
def revert_analysis_prompt() -> dict[str, Any]:
    skill_config.revert_analysis_prompt_to_default()
    return get_analysis_prompt()


@router.post("/analysis-prompt/rerun")
def rerun_analysis_prompt(body: BatchRef) -> dict[str, Any]:
    """Re-runs ONLY the Analysis Report prompt for every candidate in this
    batch — cheaper than a full re-extraction, and doesn't touch any other
    extracted field."""
    ids = _candidate_ids(body.source)
    workers = min(settings.extract_workers, len(ids))
    errors: list[dict[str, str]] = []
    succeeded = 0
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(regenerate_analysis_report, cid): cid for cid in ids}
        for fut in as_completed(futures):
            cid = futures[fut]
            try:
                fut.result()
                succeeded += 1
            except Exception as exc:  # noqa: BLE001 — collect and keep going
                errors.append({"candidate_id": cid, "error": str(exc)})
    return {"total": len(ids), "succeeded": succeeded, "failed": len(errors), "errors": errors[:20]}


# ── NLRS weights / NBA bands / custom rules ──────────────────────────────────

class NlrsRule(BaseModel):
    id: str
    label: str
    field: str
    op: str
    value: float
    points: float


class NlrsConfigBody(BaseModel):
    weights: dict[str, float] = Field(default_factory=dict)
    nba_bands: dict[str, float] = Field(default_factory=dict)
    rules: list[NlrsRule] = Field(default_factory=list)


@router.get("/nlrs-config")
def get_nlrs_config() -> dict[str, Any]:
    cfg = nlrs_config.get()
    return {
        **cfg,
        "allowed_rule_fields": list(nlrs_config.ALLOWED_RULE_FIELDS),
        "allowed_rule_ops": list(nlrs_config.ALLOWED_RULE_OPS),
    }


@router.put("/nlrs-config")
def put_nlrs_config(body: NlrsConfigBody) -> dict[str, Any]:
    try:
        nlrs_config.save({
            "weights": body.weights,
            "nba_bands": body.nba_bands,
            "rules": [r.model_dump() for r in body.rules],
        })
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return get_nlrs_config()


@router.post("/nlrs-config/revert")
def revert_nlrs_config() -> dict[str, Any]:
    nlrs_config.revert_to_default()
    return get_nlrs_config()


_PREVIEW_LIMIT = 500


@router.post("/nlrs-config/preview")
def preview_nlrs_config(body: BatchRef) -> dict[str, Any]:
    """NLRS is computed LIVE and never stored (app.services.nlrs) — a saved
    weights/rules change already applies everywhere the instant it's saved,
    so there's nothing to "recalculate and write". This is a READ-ONLY preview:
    it shows what the CURRENTLY SAVED config produces for a real batch, so an
    Admin can sanity-check the effect on real candidates before relying on it."""
    ids = _candidate_ids(body.source)
    truncated = len(ids) > _PREVIEW_LIMIT
    rows = []
    for cid in ids[:_PREVIEW_LIMIT]:
        row = get_candidate(cid)
        if not row:
            continue
        nlrs = compute_nlrs(row)
        rows.append({
            "candidate_id": cid,
            "name": row.get("name"),
            "score": nlrs["score"],
            "components": nlrs["components"],
            "adjustments": nlrs["adjustments"],
        })
    scores = [r["score"] for r in rows]
    summary = {
        "count": len(rows),
        "avg_score": round(sum(scores) / len(scores), 1) if scores else None,
        "min_score": min(scores) if scores else None,
        "max_score": max(scores) if scores else None,
    }
    return {"summary": summary, "candidates": rows, "truncated": truncated}
