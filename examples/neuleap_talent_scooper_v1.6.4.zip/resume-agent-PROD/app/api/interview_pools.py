"""Interviewer timeslot pools — Mailbox → "Interviewer Timeslot Pools" (backoffice
CRUD/gather, see ``router`` below) + the interviewer self-service portal (public,
email-code gated, see ``portal_router`` — mirrors app.api.interviewer's shape but
verified against the round-interviewer roster instead of a per-link token)."""
from __future__ import annotations

from datetime import date, datetime
from typing import Any, Optional

from fastapi import APIRouter, Depends, Header, HTTPException
from pydantic import BaseModel, EmailStr, Field

from app.api.auth import require_backoffice_access
from app.logging_config import get_logger
from app.services import interview_pool_config, interview_pools, pool_interviewer_auth

log = get_logger(__name__)

router = APIRouter(
    prefix="/api/v1/interview-pools", tags=["interview pools"],
    dependencies=[Depends(require_backoffice_access)],
)
portal_router = APIRouter(prefix="/api/v1/pool-interviewer", tags=["interview pools"])


# ── Backoffice: pool CRUD ────────────────────────────────────────────────────

class PoolCreate(BaseModel):
    source_label: Optional[str] = None
    round_names: list[str] = Field(default_factory=list)
    label: str
    range_start: date
    range_end: date
    slot_minutes: Optional[int] = None
    gap_minutes: Optional[int] = None
    max_day_fraction: Optional[float] = None
    days_allowed: Optional[dict[str, str]] = None


class PoolUpdate(BaseModel):
    source_label: Optional[str] = None
    round_names: Optional[list[str]] = None
    label: Optional[str] = None
    range_start: Optional[date] = None
    range_end: Optional[date] = None
    slot_minutes: Optional[int] = None
    gap_minutes: Optional[int] = None
    max_day_fraction: Optional[float] = None
    days_allowed: Optional[dict[str, str]] = None
    # Explicit null clears the override back to auto-computed velocity; the field
    # is only touched at all when the request body includes it (exclude_unset).
    manual_projected_candidates: Optional[float] = None


@router.get("")
def list_pools() -> list[dict[str, Any]]:
    return interview_pools.list_pools()


@router.get("/defaults")
def get_defaults() -> dict[str, Any]:
    return interview_pool_config.get()


@router.put("/defaults")
def put_defaults(body: dict[str, Any]) -> dict[str, Any]:
    try:
        return interview_pool_config.save(body)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@router.post("/defaults/revert")
def revert_defaults() -> dict[str, Any]:
    return interview_pool_config.revert_to_default()


@router.post("")
def create_pool(body: PoolCreate) -> dict[str, Any]:
    if body.range_start < date.today():
        raise HTTPException(422, "range_start cannot be in the past.")
    if body.range_end < body.range_start:
        raise HTTPException(422, "range_end must be on or after range_start.")
    try:
        return interview_pools.create_pool(body.model_dump(exclude_none=True))
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc


@router.get("/{pool_id}")
def get_pool(pool_id: int) -> dict[str, Any]:
    pool = interview_pools.get_pool(pool_id)
    if not pool:
        raise HTTPException(404, "Pool not found.")
    return pool


@router.patch("/{pool_id}")
def update_pool(pool_id: int, body: PoolUpdate) -> dict[str, Any]:
    try:
        updated = interview_pools.update_pool(pool_id, body.model_dump(exclude_unset=True))
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc
    if not updated:
        raise HTTPException(404, "Pool not found.")
    return updated


@router.post("/{pool_id}/archive")
def archive_pool(pool_id: int) -> dict[str, Any]:
    updated = interview_pools.archive_pool(pool_id)
    if not updated:
        raise HTTPException(404, "Pool not found.")
    return updated


@router.get("/{pool_id}/slots")
def list_slots(pool_id: int) -> list[dict[str, Any]]:
    if not interview_pools.get_pool(pool_id):
        raise HTTPException(404, "Pool not found.")
    from app.services import pool_sync_job

    try:
        pool_sync_job.run_once(pool_id=pool_id)
    except Exception as exc:  # noqa: BLE001 — a failed live sync must not break the read
        log.warning("interview_pools: live sync failed for pool %s: %s", pool_id, exc)
    return interview_pools.list_slots(pool_id)


@router.get("/{pool_id}/velocity")
def get_velocity(pool_id: int) -> dict[str, Any]:
    try:
        return interview_pools.compute_velocity(pool_id)
    except ValueError as exc:
        raise HTTPException(404, str(exc)) from exc


@router.get(
    "/{pool_id}/picker-links",
    summary="Per-round candidate slot-picker links for this pool (sample-candidate backed)",
)
def get_picker_links(pool_id: int) -> dict[str, Any]:
    """One openable /schedule/{token} link per round, scoped to THIS pool —
    each is a real slot-picker invite bound to the persistent SAMPLE-DEMO
    candidate (app.services.sample_interview), so a recruiter can see/verify
    exactly which slots that round would offer without touching any real
    candidate. Rounds with no sample scenario (Round 3) return null."""
    if not interview_pools.get_pool(pool_id):
        raise HTTPException(404, "Pool not found.")
    from app.services import candidate_slot, sample_interview

    scenarios = sample_interview.get_sample_links()
    links: dict[str, Optional[str]] = {}
    for r in interview_pools.compute_velocity(pool_id)["per_round"]:
        round_name = r["round_name"]
        sc = scenarios.get(round_name)
        if not sc:
            links[round_name] = None
            continue
        existing = candidate_slot.invite_for_round(sc["round_id"])
        if existing:
            # Re-point the sample invite at THIS pool so the page shows this
            # pool's slots (never re-pointing an already-booked test invite).
            if existing.get("pool_id") != pool_id and not existing.get("booked_at"):
                candidate_slot.set_invite_pool(existing["token"], pool_id)
            token = existing["token"]
        else:
            token = candidate_slot.create_invite(
                sample_interview.SAMPLE_CANDIDATE_ID, sc["round_id"], None, pool_id=pool_id
            )
        links[round_name] = f"/schedule/{token}"
    return {"links": links}


@router.post("/{pool_id}/sync", summary="Refresh — pull the latest status of this pool's existing placeholders from Graph")
def sync_pool(pool_id: int) -> dict[str, int]:
    """Does NOT create anything — it just checks each still-open/booked
    placeholder against the interviewer's actual calendar (deleted directly?
    moved to a new time?) and folds that back into our records. To allocate
    new placeholders, use POST /{pool_id}/gather instead. Also runs on its
    own every 2h system-wide (app.services.scheduler) — this is the same
    check, just scoped to one pool and run on demand."""
    if not interview_pools.get_pool(pool_id):
        raise HTTPException(404, "Pool not found.")
    from app.services import pool_sync_job

    return pool_sync_job.run_once(pool_id=pool_id)


@router.post("/{pool_id}/gather", summary="Make placeholders — allocate new slots per this pool's configured rules")
def gather(pool_id: int) -> dict[str, Any]:
    try:
        return interview_pools.gather_pool(pool_id)
    except ValueError as exc:
        raise HTTPException(404, str(exc)) from exc


# ── Interviewer self-service portal (public, email-code gated) ─────────────

class RequestCodeBody(BaseModel):
    email: EmailStr


class VerifyCodeBody(BaseModel):
    email: EmailStr
    code: str
    remember: bool = False


class VerifyCodeResponse(BaseModel):
    session_token: str
    name: str
    round_names: list[str]


def _require_session(x_pool_session: Optional[str]) -> str:
    email = pool_interviewer_auth.validate_session(x_pool_session)
    if not email:
        raise HTTPException(401, "Verification required.")
    return email


@portal_router.post("/request-code")
def request_code(body: RequestCodeBody) -> dict[str, bool]:
    try:
        pool_interviewer_auth.request_code(str(body.email))
    except pool_interviewer_auth.NotAnInterviewer as exc:
        raise HTTPException(403, str(exc)) from exc
    return {"sent": True}


@portal_router.post("/verify-code", response_model=VerifyCodeResponse)
def verify_code(body: VerifyCodeBody) -> VerifyCodeResponse:
    from app.services import round_interviewers_config

    try:
        session_token = pool_interviewer_auth.verify_code(
            str(body.email), body.code, remember=body.remember
        )
    except pool_interviewer_auth.InvalidCode as exc:
        raise HTTPException(400, str(exc)) from exc
    interviewer = round_interviewers_config.find_interviewer(str(body.email))
    return VerifyCodeResponse(
        session_token=session_token,
        name=(interviewer or {}).get("name", ""),
        round_names=(interviewer or {}).get("round_names", []),
    )


@portal_router.get("/me")
def get_me(x_pool_session: Optional[str] = Header(default=None)) -> dict[str, Any]:
    from app.services import round_interviewers_config

    email = _require_session(x_pool_session)
    interviewer = round_interviewers_config.find_interviewer(email) or {}
    return {"email": email, "name": interviewer.get("name"), "round_names": interviewer.get("round_names", [])}


@portal_router.get("/my-slots")
def my_slots(x_pool_session: Optional[str] = Header(default=None)) -> list[dict[str, Any]]:
    email = _require_session(x_pool_session)
    from app.services import pool_sync_job

    try:
        pool_sync_job.run_once(interviewer_email=email)
    except Exception as exc:  # noqa: BLE001 — a failed live sync must not break the read
        log.warning("interview_pools: live sync failed for %s: %s", email, exc)
    return interview_pools.slots_for_interviewer(email)


@portal_router.post("/slots/{slot_id}/remove")
def remove_slot(slot_id: int, x_pool_session: Optional[str] = Header(default=None)) -> dict[str, Any]:
    email = _require_session(x_pool_session)
    updated = interview_pools.remove_slot(slot_id, email)
    if not updated:
        raise HTTPException(404, "That slot isn't open or doesn't belong to you.")
    return updated


class ProposeTimeBody(BaseModel):
    start: str
    end: str


@portal_router.post("/slots/{slot_id}/propose")
def propose_time(
    slot_id: int, body: ProposeTimeBody, x_pool_session: Optional[str] = Header(default=None)
) -> dict[str, Any]:
    email = _require_session(x_pool_session)
    try:
        new_start = datetime.fromisoformat(body.start)
        new_end = datetime.fromisoformat(body.end)
    except ValueError as exc:
        raise HTTPException(422, "Invalid start/end.") from exc
    try:
        updated = interview_pools.propose_new_time(slot_id, email, new_start, new_end)
    except ValueError as exc:
        raise HTTPException(409, str(exc)) from exc
    if not updated:
        raise HTTPException(404, "That slot isn't open or doesn't belong to you.")
    return updated
