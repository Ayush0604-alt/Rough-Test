"""Layer 5 — NL-to-SQL chatbot (read-only).

Translates a recruiter's natural-language question into a single SELECT over
candidate_master / candidate_master_archive / rounds using the same Azure OpenAI
client L3 uses, then runs it on the existing Postgres pool.

Safety is enforced in two layers:
  1. App-side validation — SELECT-only, allow-listed tables, no DML/DDL, one
     statement, a hard LIMIT.
  2. DB-side — the query runs inside a READ ONLY transaction, so even a guard
     bypass cannot mutate data.
"""
from __future__ import annotations

import logging
import re
import time
from functools import lru_cache
from pathlib import Path

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.repositories import chatbot_repo

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1", tags=["layer5 (chatbot)"])

ALLOWED_TABLES = {
    "candidate_master",
    "candidate_master_archive",
    "rounds",
    "rounds_archive",
    "email_master",
    "audit_log",
}
MAX_ROWS = 200

FORBIDDEN = re.compile(
    r"\b(insert|update|delete|drop|alter|truncate|create|grant|revoke|"
    r"merge|replace|copy|call|do|execute|vacuum|analyze|comment|set|"
    r"begin|commit|rollback)\b",
    re.IGNORECASE,
)

# ── Intent routing messages (exact text returned to the user) ─────────────────
_REJECT_MSG = (
    "Sorry, I can only help with read-only candidate search and reporting. "
    "I cannot modify, delete, insert, or drop data."
)
_OFF_TOPIC_MSG = (
    "I can only answer HR resume and candidate database questions. "
    "Please ask about candidates, skills, ATS score, rounds, pipeline status, "
    "or resume analytics."
)

# ════════════════════════════════════════════════════════════════════════════
# The system + narrator prompts are NOT hardcoded here. They are the single
# editable source of truth in chatbot_SKILL.md, between the SYSTEM_PROMPT:START/END
# and NARRATOR_PROMPT:START/END markers. ``_load_prompt()`` reads and caches them at
# runtime, so editing chatbot behaviour requires no code change. (Mirrors Layer 3.)
# ════════════════════════════════════════════════════════════════════════════
_SKILL_PATH = Path(__file__).with_name("chatbot_SKILL.md")
_SYSTEM_MARKERS = ("<!-- SYSTEM_PROMPT:START -->", "<!-- SYSTEM_PROMPT:END -->")
_NARRATOR_MARKERS = ("<!-- NARRATOR_PROMPT:START -->", "<!-- NARRATOR_PROMPT:END -->")


@lru_cache(maxsize=2)
def _load_prompt(start_marker: str, end_marker: str) -> str:
    """Load the prompt between ``start_marker`` and ``end_marker`` from chatbot_SKILL.md.

    Cached per marker pair for the process. A missing file or markers raises a clear
    ``RuntimeError`` so a misconfigured deploy fails loudly instead of silently
    sending an empty prompt.
    """
    try:
        text = _SKILL_PATH.read_text(encoding="utf-8")
    except OSError as exc:
        raise RuntimeError(
            f"Cannot read the chatbot prompt from {_SKILL_PATH}: {exc}"
        ) from exc

    start = text.find(start_marker)
    end = text.find(end_marker)
    if start == -1 or end == -1 or end <= start:
        raise RuntimeError(
            f"Prompt markers not found in {_SKILL_PATH}; expected "
            f"{start_marker} … {end_marker}."
        )

    prompt = text[start + len(start_marker):end].strip()
    if not prompt:
        raise RuntimeError(f"Prompt {start_marker} in {_SKILL_PATH} is empty.")
    return prompt


def _load_system_prompt() -> str:
    """The intent-routing + guardrail + SQL-generation system prompt."""
    return _load_prompt(*_SYSTEM_MARKERS)


def _load_narrator_prompt() -> str:
    """The prompt that turns a SQL result set into the recruiter-facing chat reply."""
    return _load_prompt(*_NARRATOR_MARKERS)

# Categorical/text columns whose live DISTINCT values we inject into the prompt so
# the model filters on what's actually stored (e.g. "Data Eng", not "Data Engineer").
_CATEGORICAL: dict[str, tuple[str, ...]] = {
    "candidate_master": (
        "stream", "domain", "status", "priority", "fresher_or_lateral",
        "education_status", "recommendation", "round_status", "roundname",
    ),
    "rounds": ("round_name", "domain", "outcome"),
}

_VALUES_TTL = 300  # seconds
_values_cache: dict[str, object] = {"at": 0.0, "text": ""}


def _column_values() -> str:
    """A compact, cached snapshot of the real distinct values per categorical column.

    Best-effort: any DB hiccup just yields an empty hint (the model still works,
    just less precisely). Cached for a few minutes so chat stays snappy.
    """
    now = time.time()
    if _values_cache["text"] and now - float(_values_cache["at"]) < _VALUES_TTL:
        return str(_values_cache["text"])

    try:
        lines = chatbot_repo.fetch_distinct_values(_CATEGORICAL, limit=40)
    except Exception as exc:  # noqa: BLE001
        logger.warning("chatbot column-values probe failed: %s", exc)
        return str(_values_cache["text"])  # fall back to whatever we had

    text = (
        "Actual stored values (filter using THESE, matched with ILIKE for partials):\n"
        + "\n".join(lines)
    ) if lines else ""
    _values_cache["text"] = text
    _values_cache["at"] = now
    return text


class ChatTurn(BaseModel):
    role: str   # "user" | "assistant"
    content: str


class ChatRequest(BaseModel):
    question: str
    # Prior turns of this conversation (oldest → newest), so a short follow-up like
    # "skills" or "5+" is understood as a continuation rather than a new query.
    history: list[ChatTurn] = []
    # Short human-readable description of whichever page/candidate the recruiter
    # is currently looking at in the app (e.g. "Candidate profile page for
    # candidate C1066"), sent fresh by the frontend on every request — see
    # frontend/src/lib/pageContext.ts. Optional: the standalone /chatbot page has
    # no "current page" to describe, so this is often absent.
    page_context: str | None = None


# Cap how much history we replay to the model (keeps latency + tokens bounded).
_MAX_HISTORY_TURNS = 12


def _call_agent(
    question: str,
    history: list[ChatTurn] | None = None,
    *,
    retry_from: str = "",
    page_context: str | None = None,
) -> str:
    """Call the LLM agent. Returns either a SELECT query or a plain-text message.

    ``history`` (prior user/assistant turns) is replayed so the model keeps context
    across turns — a one-word reply to its own clarification becomes a real query.
    """
    from app.extraction.engine import _azure_config

    client, deployment = _azure_config(module="chatbot_sql")

    system = _load_system_prompt()
    values = _column_values()
    if values:
        system = f"{system}\n{values}\n"
    if page_context:
        system = (
            f"{system}\nCurrent app context: the recruiter is currently on: "
            f"{page_context}. If their question is ambiguous (e.g. \"this candidate\", "
            f"\"here\", \"on this page\"), prefer the candidate/page named above.\n"
        )

    messages: list[dict] = [{"role": "system", "content": system}]
    for turn in (history or [])[-_MAX_HISTORY_TURNS:]:
        role = turn.role if turn.role in ("user", "assistant") else "user"
        content = (turn.content or "").strip()
        if content:
            messages.append({"role": role, "content": content})

    user = question
    if retry_from:
        user = (
            f"{question}\n\n"
            f"Your previous query returned 0 rows:\n{retry_from}\n"
            "It was probably too strict or used the wrong column. Rewrite it: relax "
            "exact matches to ILIKE '%term%', and choose the column whose listed "
            "values actually contain the term. Return only the corrected SQL."
        )
    messages.append({"role": "user", "content": user})

    resp = client.chat.completions.create(
        model=deployment,
        messages=messages,
        temperature=0,
    )
    from app.services import token_usage

    usage = getattr(resp, "usage", None)
    token_usage.record(
        module="chatbot_sql",
        model=deployment,
        prompt_tokens=getattr(usage, "prompt_tokens", None),
        completion_tokens=getattr(usage, "completion_tokens", None),
        total_tokens=getattr(usage, "total_tokens", None),
    )
    return (resp.choices[0].message.content or "").strip()


# A single-quoted SQL string literal, including '' escaped quotes inside it.
_SQL_LITERAL = re.compile(r"'(?:[^']|'')*'")


def _strip_fences(text: str) -> str:
    """Remove an accidental ```sql … ``` markdown fence the model may have added."""
    text = text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```[a-zA-Z]*\n?|\n?```$", "", text).strip()
    return text


def _scrub_literals(sql: str) -> str:
    """Blank out string-literal contents so structural guards (forbidden keywords,
    statement separators, table refs) never trip on recruiter search terms like
    ``ILIKE '%Set Solutions%'`` or ``'%data replication%'``."""
    return _SQL_LITERAL.sub("''", sql)


def _is_sql(text: str) -> bool:
    """True when the agent returned a SQL query (starts with SELECT/WITH).

    Fence-tolerant: a model that wraps the query in a ```sql``` block must still be
    routed to execution, not shown to the user as a plain-text answer.
    """
    upper = _strip_fences(text).lstrip().upper()
    return upper.startswith("SELECT") or upper.startswith("WITH")


def _sanitize(sql: str) -> str:
    sql = _strip_fences(sql)
    sql = sql.rstrip(";").strip()
    if not sql.lower().startswith(("select", "with")):
        raise HTTPException(status_code=400, detail="only SELECT queries are allowed")
    # Validate STRUCTURE, not literal text: a search term that happens to contain a
    # SQL keyword or ';' must not be mistaken for an injected statement.
    scrubbed = _scrub_literals(sql)
    if ";" in scrubbed:
        raise HTTPException(status_code=400, detail="only a single statement is allowed")
    if FORBIDDEN.search(scrubbed):
        raise HTTPException(status_code=400, detail="query contains a disallowed keyword")
    # Every table referenced after FROM/JOIN must be allow-listed.
    refs = re.findall(r"\b(?:from|join)\s+([a-zA-Z_][a-zA-Z0-9_]*)", scrubbed, re.IGNORECASE)
    bad = [t for t in refs if t.lower() not in ALLOWED_TABLES]
    if bad:
        raise HTTPException(status_code=400, detail=f"table(s) not allowed: {bad}")
    # Enforce a row cap.
    if not re.search(r"\blimit\b", scrubbed, re.IGNORECASE):
        sql = f"{sql} LIMIT {MAX_ROWS}"
    return sql


def _run_select(sql: str) -> list[dict]:
    """Execute a sanitized SELECT inside a READ ONLY transaction."""
    return chatbot_repo.run_readonly_select(sql)


# Matches a trailing "LIMIT n [OFFSET m]" so we can tell the cap from the query.
_TRAILING_LIMIT = re.compile(r"\blimit\s+(\d+)\s*(?:offset\s+\d+\s*)?$", re.IGNORECASE)


def _applied_limit(sql: str) -> int | None:
    """The trailing LIMIT value, if the list query has one."""
    m = _TRAILING_LIMIT.search(sql.strip())
    return int(m.group(1)) if m else None


def _true_total(sql: str) -> int | None:
    """Real match count for a list query, ignoring its LIMIT.

    Wraps the query (minus its trailing LIMIT) in COUNT(*). Best-effort: returns
    None if anything goes wrong, so the caller just falls back to the shown count.
    Skips aggregate queries — counting an aggregate's rows isn't a "how many
    candidates" number.
    """
    lowered = sql.lower()
    if "count(" in lowered or "group by" in lowered:
        return None
    inner = _TRAILING_LIMIT.sub("", sql).strip()
    if not inner.lower().startswith(("select", "with")):
        return None
    try:
        return chatbot_repo.count_matches(inner)
    except Exception as exc:  # noqa: BLE001 — total is best-effort
        logger.info("chatbot total-count skipped: %s", exc)
        return None


def _answer(question: str, row_count: int) -> str:
    """Plain fallback answer, used only if the conversational narrator can't run."""
    if row_count == 0:
        return "No matching records found — try rephrasing or broadening your filters."
    return f"Found {row_count} matching record{'s' if row_count != 1 else ''}."


# How many rows / how much of each row we feed the narrator (keeps tokens bounded).
_NARRATE_SAMPLE_ROWS = 12
_NARRATE_MAX_CELL = 120


def _narrate(
    question: str,
    rows: list[dict],
    history: list[ChatTurn] | None,
    total: int | None = None,
    *,
    page_context: str | None = None,
) -> str:
    """Turn a SQL result set into a natural, ChatGPT-style chat reply.

    ``total`` is the real number of matches when the list was capped by a LIMIT, so
    the narrator can be honest about "top N of TOTAL" instead of treating the shown
    page as the whole set. Best-effort: any failure falls back to the plain
    ``_answer`` so the chat never breaks just because the narration call hiccuped.
    """
    from app.extraction.engine import _azure_config

    shown = len(rows)
    real_total = total if total is not None else shown
    try:
        client, deployment = _azure_config(module="chatbot_narration")

        sample = rows[:_NARRATE_SAMPLE_ROWS]
        # Trim long cells so a single bloated column can't blow the token budget.
        trimmed = [
            {k: (str(v)[:_NARRATE_MAX_CELL] if v is not None else None) for k, v in r.items()}
            for r in sample
        ]
        import json

        capped = (
            "\n(This is a capped preview — there are more matches than shown.)"
            if real_total > shown
            else ""
        )
        payload = (
            f"Recruiter asked: {question}\n"
            f"Total matches: {real_total}\n"
            f"Showing: {shown} row(s) in the table the recruiter sees.{capped}\n"
            f"Sample of those rows (up to {_NARRATE_SAMPLE_ROWS} shown to you):\n"
            f"{json.dumps(trimmed, default=str)}"
        )

        narrator_system = _load_narrator_prompt()
        if page_context:
            narrator_system = f"{narrator_system}\nCurrent app context: the recruiter is currently on: {page_context}\n"
        messages: list[dict] = [{"role": "system", "content": narrator_system}]
        # A little prior context lets the narrator phrase follow-ups naturally.
        for turn in (history or [])[-4:]:
            role = turn.role if turn.role in ("user", "assistant") else "user"
            content = (turn.content or "").strip()
            if content:
                messages.append({"role": role, "content": content})
        messages.append({"role": "user", "content": payload})

        resp = client.chat.completions.create(
            model=deployment,
            messages=messages,
            temperature=0.5,  # a touch of warmth; SQL stays at 0 elsewhere
        )
        from app.services import token_usage

        usage = getattr(resp, "usage", None)
        token_usage.record(
            module="chatbot_narration",
            model=deployment,
            prompt_tokens=getattr(usage, "prompt_tokens", None),
            completion_tokens=getattr(usage, "completion_tokens", None),
            total_tokens=getattr(usage, "total_tokens", None),
        )
        text = (resp.choices[0].message.content or "").strip()
        return text or _answer(question, len(rows))
    except Exception as exc:  # noqa: BLE001 — narration is best-effort
        logger.info("chatbot narration skipped: %s", exc)
        return _answer(question, len(rows))


@router.get(
    "/chatbot/widget-config",
    summary="Whether the floating chat launcher should be shown",
)
def chatbot_widget_config_get() -> dict:
    """Read by the floating launcher on every page load (every role, not just
    Admin/System Admin) — deliberately NOT behind require_backoffice_access
    like the rest of /settings/*, since a Recruiter's browser has to be able
    to check this too. The Settings page's own save action (PUT
    /settings/chatbot-widget) IS backoffice-gated; this is read-only."""
    from app.services import chatbot_widget_config

    return chatbot_widget_config.get()


@router.post("/chatbot/query", summary="Natural-language question → read-only SQL result")
def chatbot_query(body: ChatRequest) -> dict:
    if not body.question.strip():
        raise HTTPException(status_code=422, detail="question is required")

    try:
        response = _call_agent(body.question, body.history, page_context=body.page_context)
    except Exception as exc:  # noqa: BLE001
        logger.warning("chatbot LLM failed: %s", exc)
        raise HTTPException(status_code=502, detail=f"LLM error: {exc}") from exc

    # ── Non-SQL response: rejection / off-topic / clarification ───────────────
    if not _is_sql(response):
        return {
            "question": body.question,
            "type": "info",
            "sql": "",
            "row_count": 0,
            "rows": [],
            "answer": response,
            "retried": False,
        }

    # ── SQL response: validate and execute ────────────────────────────────────
    try:
        sql = _sanitize(response)
    except HTTPException:
        raise
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    try:
        rows = _run_select(sql)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=400, detail=f"query failed: {exc}") from exc

    # Smart retry: an empty result is usually an over-strict or wrong-column filter.
    retried = False
    if not rows:
        try:
            response2 = _call_agent(
                body.question, body.history, retry_from=sql, page_context=body.page_context
            )
            if _is_sql(response2):
                sql2 = _sanitize(response2)
                if sql2 != sql:
                    rows2 = _run_select(sql2)
                    retried = True
                    if rows2:
                        sql, rows = sql2, rows2
        except Exception as exc:  # noqa: BLE001 — retry is best-effort
            logger.info("chatbot retry skipped: %s", exc)

    # If the list was capped by its LIMIT, find the real total so the answer is
    # honest about how many candidates actually match (not just the shown page).
    total = len(rows)
    limit = _applied_limit(sql)
    if limit is not None and len(rows) >= limit:
        true_total = _true_total(sql)
        if true_total is not None:
            total = true_total

    return {
        "question": body.question,
        "type": "sql",
        "sql": sql,
        "row_count": len(rows),
        "total_count": total,
        "rows": rows,
        "answer": _narrate(body.question, rows, body.history, total, page_context=body.page_context),
        "retried": retried,
    }
