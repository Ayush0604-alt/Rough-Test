"""Read-only API for the Mailbox (intake table) and Activity Log (audit log) views.

email_master and audit_log are owned upstream; these endpoints only read them.
Routes are mounted under /api/v1 so the SPA talks to one base URL. Admin or
System Admin only — Recruiter has no Mailbox/Activity Log access (the candidate
pipeline's own audit trail is a separate, still-open endpoint: see
GET /candidates/{id}/audit-log in app/api/rounds.py).
"""
from __future__ import annotations

import logging
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response

from app.api.auth import require_backoffice_access
from app.repositories import repo
from app.services import clock
from app.services.xlsx_export import XLSX_MEDIA_TYPE, Column, build_xlsx

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/api/v1", tags=["reads (mailbox/activity-log)"], dependencies=[Depends(require_backoffice_access)]
)


def _status_from_candidate(cand: dict) -> Optional[tuple[str, str]]:
    """Outcome derived from a candidate_master row (it cleared L2/L3), or None.

    A candidate row existing AT ALL means the email was processed successfully — the
    resume was extracted and a candidate was created. So the mail's processing
    outcome is always "Processed", regardless of the candidate's HIRING status.

    The hiring lifecycle (Active / Hired / Rejected / Closed) is a recruiter decision,
    NOT an email-processing result, and must never flip the mail's Success badge to
    Failed. A rejected candidate's email was still ingested cleanly — the audit log
    says success, so the mail stays Success. The hiring verdict rides along in the
    detail line and is shown in full on the Candidate/Rounds views.
    """
    status = cand.get("status")
    cid = cand.get("candidate_id")
    if not status:
        return None
    return "Processed", f"Candidate {cid} · {status}"


def _status_from_audit(info: dict) -> Optional[tuple[str, str]]:
    """Outcome derived from the L2/L3/REVIEW audit trail for an e_id, or None."""
    if info.get("discarded"):
        detail = (info.get("discard_detail") or "").strip()
        if not detail or detail.isdigit():
            detail = "Manually discarded in review"
        return "Discarded", detail
    if info.get("exhausted"):
        return "Exhausted", "Retries exhausted (fail_count = 3)"
    reason = (info.get("failed_reason") or "").strip()
    if reason:
        # fail_reason is "<filename>: <reason>", so match the reason as a substring
        # (not just the prefix) to keep classifying duplicates/non-resumes correctly.
        low = reason.lower()
        if low.startswith("dup") or "dup:" in low or "dup_hired" in low:
            return "Duplicate", reason
        if "not_a_resume" in low or "not a resume" in low:
            return "Not a Resume", reason
        return "Failed", reason
    return None


def _final_status(email: dict, cand: Optional[dict], info: Optional[dict]) -> tuple[str, str]:
    """Derive the TRUE downstream outcome for an email (L2/L3), not just L1's verdict.

    Returns (status, detail). email_master.process_status only reflects L1 file
    validation; the real fate lives in candidate_master / audit_log.
    """
    if cand and (outcome := _status_from_candidate(cand)):
        return outcome
    if info and (outcome := _status_from_audit(info)):
        return outcome

    # L1 intake verdict. Prefer the queue lifecycle (extraction_status:
    # QUEUED|PROCESSING|SUCCESS|FAILED|EXHAUSTED) — it is the authoritative state the
    # Outlook intake panel shows. The legacy process_status is only a binary Passed|Failed
    # mirror where "Failed" ALSO marks rows that simply haven't passed yet (QUEUED /
    # PROCESSING), so it must never be read as a terminal failure on its own — doing so
    # made queued mail show as "Failed" here while the queue panel showed it as QUEUED.
    l1 = (email.get("extraction_status") or "").upper()
    if l1 == "EXHAUSTED":
        return "Exhausted", email.get("error_reason") or "Retries exhausted at L1 intake"
    if l1 == "FAILED":
        return "Failed", email.get("error_reason") or "Failed at L1 intake"
    if l1 in ("QUEUED", "PROCESSING", "DISCOVERED"):
        return "Queued", "Waiting for the next pipeline run"

    # Legacy LangGraph path (no queue lifecycle recorded) — fall back to the binary.
    if not l1 and email.get("process_status") == "Failed":
        return "Failed", "Failed at L1 intake"

    # Passed L1, but the pipeline hasn't processed it downstream yet.
    if not email.get("processed"):
        return "Queued", "Waiting for the next pipeline run"

    return "Processed", "Completed"


# Actionable — a recruiter still needs to do something.
NEEDS_REVIEW_STATUSES = {"Failed", "Exhausted"}
# Terminal — already handled/decided, no action needed (auto-clears from attention).
RESOLVED_STATUSES = {"Duplicate", "Not a Resume", "Discarded", "Closed", "Rejected"}

# "Pending" mail is the backlog the aging report watches: it has arrived but hasn't
# reached a terminal outcome, so its age is an SLA signal (vs. Processed/Resolved,
# whose age is just informational turnaround).
PENDING_STATUSES = NEEDS_REVIEW_STATUSES | {"Queued"}

# Mail-aging buckets (hours since received). Mirrored verbatim on the SPA so the
# Intake pill colors and the Dashboard report agree on every threshold.
AGING_FRESH_H    = 24        # < 1 day
AGING_AGING_H    = 24 * 3    # 1–3 days
AGING_STALE_H    = 24 * 7    # 3–7 days
#                              > 7 days ⇒ "critical"


def _compute_age(received_date) -> tuple[Optional[float], Optional[str]]:
    """Hours since a mail was received + its aging bucket, or (None, None).

    ``received_date`` arrives three ways (see schema): a plain calendar date
    ("2026-06-17"), a full ISO timestamp ("2026-06-17T10:48:46Z"), or "unknown".
    A date-only value is anchored to the START of that day in business time.
    Unparseable / "unknown" / future dates yield no age (None).
    """
    raw = (str(received_date) if received_date is not None else "").strip()
    if not raw or raw.lower() == "unknown":
        return None, None

    tz = clock.business_tz()
    try:
        if "T" in raw:
            parsed = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        else:
            parsed = datetime.fromisoformat(raw[:10])
    except (ValueError, TypeError):
        return None, None

    # Naive timestamps (date-only or no offset) are business-local by convention.
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=tz)

    hours = (clock.now() - parsed).total_seconds() / 3600.0
    if hours < 0:
        return None, None

    if hours < AGING_FRESH_H:
        bucket = "fresh"
    elif hours < AGING_AGING_H:
        bucket = "aging"
    elif hours < AGING_STALE_H:
        bucket = "stale"
    else:
        bucket = "critical"
    return hours, bucket


def _enriched_emails() -> list[dict]:
    """email_master rows annotated with their TRUE downstream outcome (final_status).

    Single source of truth shared by /emails and /emails/run-summary so the Intake
    table and the Dashboard cards never disagree.
    """
    emails = repo().get_all_emails()

    cand_by_eid: dict[str, dict] = {}
    # Per-mail token rollup: sum total_tokens across EVERY candidate sharing an e_id
    # (one mail can expand into many resumes) and count them, so the Intake table can
    # show the mail total, the average per candidate, and the candidate count.
    tokens_by_eid: dict[str, int] = {}
    count_by_eid: dict[str, int] = {}
    for c in repo().get_all_candidates():
        eid = c.get("e_id")
        if not eid:
            continue
        if eid not in cand_by_eid:
            cand_by_eid[eid] = c
        tokens_by_eid[eid] = tokens_by_eid.get(eid, 0) + (c.get("total_tokens") or 0)
        count_by_eid[eid] = count_by_eid.get(eid, 0) + 1

    audit_info: dict[str, dict] = {}
    for a in repo().list_audit_logs():  # newest first (log_id DESC)
        eid = a.get("e_id")
        if not eid:
            continue
        layer = a.get("layer")
        step = a.get("step") or ""
        st = a.get("status")
        info = audit_info.setdefault(eid, {})
        if layer == "REVIEW" and "discard" in step and not info.get("discarded"):
            info["discarded"] = True
            info["discard_detail"] = a.get("fail_reason")
        if layer in ("L2", "L3"):
            if st == "Exhausted":
                info["exhausted"] = True
            if st == "Failed" and not info.get("failed_reason"):
                info["failed_reason"] = a.get("fail_reason") or "L2/L3 step failed"
            # Per-file failure tally: one mail (e.g. a ZIP/Mixed) can expand into many
            # resumes, some of which fail downstream while the mail itself "Passed" L1.
            # Count those so the Intake page can show "Processed · N failed".
            if st in ("Failed", "Exhausted"):
                info["failed_files"] = info.get("failed_files", 0) + 1

    # Live "still needs a human" signal per mail — open review_queue rows, keyed by
    # e_id. Unlike failed_files (append-only audit history), this drops to 0 as a
    # recruiter clears the items, so a Partial mail can flip back to Processed.
    from app.services import review_queue
    open_reviews_by_eid = review_queue.open_counts_by_email()

    for e in emails:
        eid = e.get("e_id")
        info = audit_info.get(eid)
        status, detail = _final_status(e, cand_by_eid.get(eid), info)
        e["final_status"] = status
        e["final_detail"] = detail
        e["failed_files"] = (info or {}).get("failed_files", 0)
        # The actual per-file failure reason — kept SEPARATE from final_detail,
        # which for a multi-resume mail (a ZIP/Mixed/batch upload) reports the
        # arbitrary first candidate's hiring status once ANY resume in it
        # succeeds (_status_from_candidate wins over _status_from_audit), so
        # the real reason behind this mail's failed_files would otherwise be
        # silently dropped even though some files genuinely failed.
        e["failed_reason"] = ((info or {}).get("failed_reason") or "").strip() or None
        e["open_reviews"] = open_reviews_by_eid.get(eid, 0)
        # Mail aging (derived, never stored): hours/days since received + bucket.
        age_hours, bucket = _compute_age(e.get("received_date"))
        e["age_hours"] = round(age_hours, 1) if age_hours is not None else None
        e["age_days"] = round(age_hours / 24) if age_hours is not None else None
        e["aging_bucket"] = bucket
        e["is_pending"] = status in PENDING_STATUSES
        total_tokens = tokens_by_eid.get(eid, 0)
        candidate_count = count_by_eid.get(eid, 0)
        e["total_tokens"] = total_tokens
        e["candidate_count"] = candidate_count
        # Average tokens per candidate, computed server-side so every consumer agrees.
        e["avg_tokens"] = round(total_tokens / candidate_count) if candidate_count else 0
    return emails


@router.get("/emails", summary="List email_master rows")
def list_emails() -> list[dict]:
    return _enriched_emails()


@router.get("/emails/run-summary", summary="Counts + schedule for the dashboard cards")
def run_summary() -> dict:
    from app.services import graph_poller, scheduler

    emails = _enriched_emails()
    processed = sum(1 for e in emails if e["final_status"] == "Processed")
    queued = sum(1 for e in emails if e["final_status"] == "Queued")
    needs_review = sum(1 for e in emails if e["final_status"] in NEEDS_REVIEW_STATUSES)
    resolved = sum(1 for e in emails if e["final_status"] in RESOLVED_STATUSES)
    # File-level failures across all mail (a single mail can carry many resumes).
    failed_files = sum(e.get("failed_files", 0) for e in emails)

    # Mail still sitting in the Outlook Processing folder hasn't been staged into
    # email_master yet (it gets an E_id only at the next pipeline run), so it isn't in
    # the rows above. Fold those waiting mails into Queued/Total so the Pipeline card
    # agrees with the Incoming Email Queue panel instead of showing Queued 0.
    waiting = int(graph_poller.snapshot().get("count", 0))
    queued += waiting

    # Mail-aging report over PENDING mail only (arrived, not yet terminal). Mail still
    # waiting in the Outlook folder isn't staged into email_master yet (no received_date
    # / E_id), so it carries no age and is intentionally excluded here.
    pending_ages = [
        e["age_hours"] for e in emails
        if e.get("is_pending") and e.get("age_hours") is not None
    ]
    buckets = {"fresh": 0, "aging": 0, "stale": 0, "critical": 0}
    for e in emails:
        if e.get("is_pending") and e.get("aging_bucket"):
            buckets[e["aging_bucket"]] += 1
    aging = {
        "pending_total": len(pending_ages),
        "oldest_pending_days": round(max(pending_ages) / 24, 1) if pending_ages else 0,
        "avg_pending_days": round(sum(pending_ages) / len(pending_ages) / 24, 1) if pending_ages else 0,
        "buckets": buckets,
    }

    nxt = scheduler.next_run_time() if hasattr(scheduler, "next_run_time") else None
    return {
        "aging": aging,
        "total": len(emails) + waiting,
        "processed": processed,
        "queued": queued,
        "needs_review": needs_review,
        "resolved": resolved,
        "failed_files": failed_files,
        # Back-compat aliases (old keys map to the corrected outcome).
        "passed": processed,
        "partial": 0,
        "issues": needs_review,
        "failed": needs_review,
        "discarded": resolved,
        "last_run": "",
        "next_run": str(nxt) if nxt else "3:30 AM IST (daily)",
    }


@router.get("/emails/{e_id}", summary="Fetch one email_master row")
def get_email(e_id: str) -> dict:
    row = repo().get_email(e_id)
    if not row:
        raise HTTPException(status_code=404, detail=f"email {e_id} not found")
    return row


@router.get("/audit-logs", summary="List audit_log rows (filterable)")
def list_audit_logs(E_id: Optional[str] = None, batch_id: Optional[str] = None) -> list[dict]:
    return repo().list_audit_logs(e_id=E_id, batch_id=batch_id)


# Human-readable layer names — mirror the Audit Logs page so the export reads the same.
_AUDIT_LAYER_LABELS = {"L1": "Intake", "L2": "Validation", "L3": "Extraction"}

# Columns mirror the on-screen table (same headers/order); Time is a real Excel date,
# the IDs are text-guarded so Excel never reformats them.
_AUDIT_EXPORT_COLUMNS = [
    Column("log_id", "#", "int"),
    Column("E_id", "Email", "text"),
    Column("candidate_id", "Candidate", "text"),
    Column("batch_id", "Run", "text"),
    Column("stage", "Stage"),
    Column("step", "Step"),
    Column("fail_reason", "Failure reason"),
    Column("fail_count", "Attempts", "int"),
    Column("status", "Status"),
    Column("created_at", "Time", "datetime"),
]


@router.get("/audit-logs/export.xlsx", summary="Export audit logs as Excel (.xlsx)")
def export_audit_logs(
    E_id: Optional[str] = None,
    layer: Optional[str] = None,
    status: Optional[str] = None,
) -> Response:
    """Export the audit log as Excel, applying the same filters the page uses
    (layer, status, and a case-insensitive E_id search) so the file matches the view."""
    e_search = (E_id or "").strip().lower()
    out: list[dict] = []
    for r in repo().list_audit_logs():
        if layer and layer != "All" and r.get("layer") != layer:
            continue
        if status and status != "All" and r.get("status") != status:
            continue
        if e_search and e_search not in str(r.get("E_id") or "").lower():
            continue
        row = dict(r)
        row["stage"] = _AUDIT_LAYER_LABELS.get(r.get("layer"), r.get("layer"))
        out.append(row)

    content = build_xlsx(_AUDIT_EXPORT_COLUMNS, out, sheet_name="Audit Logs")
    return Response(
        content=content,
        media_type=XLSX_MEDIA_TYPE,
        headers={"Content-Disposition": 'attachment; filename="audit-logs.xlsx"'},
    )
