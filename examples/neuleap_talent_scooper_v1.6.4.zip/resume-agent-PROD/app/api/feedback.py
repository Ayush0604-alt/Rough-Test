"""Feedback API — in-app bug reports + feature requests.

Any signed-in user can file one (POST /feedback); the reporter is stamped from
their session, never the request body. Admins/System Admins list, triage, export
(Excel), and delete them from Settings → Feedback.
"""
from __future__ import annotations

from typing import Any, Literal, Optional

from fastapi import APIRouter, Depends, HTTPException, Response, status
from pydantic import BaseModel, Field

from app.api.auth import AuthUser, get_current_user, require_backoffice_access
from app.services import feedback

router = APIRouter(prefix="/api/v1/feedback", tags=["feedback"])

Kind = Literal["bug", "feature"]
Priority = Literal["P1", "P2", "P3", "P4", "P5"]
Moscow = Literal["must", "should", "could", "wont"]
Status = Literal["open", "in_progress", "resolved", "closed"]


class FeedbackIn(BaseModel):
    kind: Kind = "bug"
    title: str = Field(min_length=3, max_length=200)
    description: str = Field(default="", max_length=5000)
    priority: Priority = "P3"
    # MoSCoW requirement class (Must/Should/Could/Won't have) — optional.
    moscow: Optional[Moscow] = None


class FeedbackOut(BaseModel):
    id: int
    kind: str
    title: str
    description: str
    priority: str
    moscow: Optional[str] = None
    reporter_email: str
    reporter_name: str
    reporter_role: Optional[str] = None
    status: str
    created_at: str | None = None
    updated_at: str | None = None


class StatusUpdate(BaseModel):
    status: Status


def _out(row: dict[str, Any]) -> dict[str, Any]:
    r = dict(row)
    for k in ("created_at", "updated_at"):
        if r.get(k) is not None and not isinstance(r[k], str):
            r[k] = r[k].isoformat()
    return r


@router.post("", response_model=FeedbackOut, status_code=status.HTTP_201_CREATED)
def create_feedback(body: FeedbackIn, user: AuthUser = Depends(get_current_user)) -> dict[str, Any]:
    """File a bug report or feature request. Any signed-in user; the reporter is
    taken from the session (auto-added), never the request."""
    row = feedback.create(
        kind=body.kind,
        title=body.title,
        description=body.description,
        priority=body.priority,
        moscow=body.moscow,
        reporter_email=user.email,
        reporter_name=user.name,
        reporter_role=user.role,
    )
    return _out(row)


@router.get("", response_model=list[FeedbackOut])
def list_feedback(_admin: AuthUser = Depends(require_backoffice_access)) -> list[dict[str, Any]]:
    """All reports, most actionable first. Admin / System Admin only."""
    return [_out(r) for r in feedback.list_all()]


@router.patch("/{report_id}", response_model=FeedbackOut)
def update_feedback_status(
    report_id: int, body: StatusUpdate, _admin: AuthUser = Depends(require_backoffice_access)
) -> dict[str, Any]:
    row = feedback.update_status(report_id, body.status)
    if not row:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Report not found.")
    return _out(row)


@router.delete("/{report_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_feedback(report_id: int, _admin: AuthUser = Depends(require_backoffice_access)) -> None:
    if not feedback.delete(report_id):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Report not found.")


@router.get(".xlsx", summary="Export all feedback as an Excel sheet")
def export_feedback_xlsx(_admin: AuthUser = Depends(require_backoffice_access)) -> Response:
    from app.services.xlsx_export import XLSX_MEDIA_TYPE, Column, build_xlsx

    _KIND_LABEL = {"bug": "Bug", "feature": "Feature request"}
    _STATUS_LABEL = {"open": "Open", "in_progress": "In progress", "resolved": "Resolved", "closed": "Closed"}
    _MOSCOW_LABEL = {"must": "Must have", "should": "Should have", "could": "Could have", "wont": "Won't have"}
    rows = []
    for r in feedback.list_all():
        rows.append({
            "id": r["id"],
            "kind": _KIND_LABEL.get(r["kind"], r["kind"]),
            "priority": r["priority"],
            "moscow": _MOSCOW_LABEL.get(r.get("moscow"), ""),
            "title": r["title"],
            "description": r["description"],
            "status": _STATUS_LABEL.get(r["status"], r["status"]),
            "reporter_name": r["reporter_name"],
            "reporter_email": r["reporter_email"],
            "reporter_role": r.get("reporter_role") or "",
            "created_at": r["created_at"],
        })
    columns = [
        Column("id", "ID", "int"),
        Column("kind", "Type"),
        Column("priority", "Priority"),
        Column("moscow", "MoSCoW"),
        Column("title", "Title", "text", wrap=True),
        Column("description", "Description", "text", wrap=True),
        Column("status", "Status"),
        Column("reporter_name", "Reporter"),
        Column("reporter_email", "Reporter email"),
        Column("reporter_role", "Reporter role"),
        Column("created_at", "Reported at", "date"),
    ]
    data = build_xlsx(columns, rows, sheet_name="Feedback")
    return Response(
        content=data,
        media_type=XLSX_MEDIA_TYPE,
        headers={"Content-Disposition": 'attachment; filename="feedback_reports.xlsx"'},
    )
