"""Review-queue API — the surface for files/rows the pipeline could not
auto-process. Backs the "Needs Review" queue on the Mailbox page — Admin or
System Admin only (Recruiter has no Mailbox access).
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from fastapi.responses import Response
from pydantic import BaseModel

from app.api.auth import require_backoffice_access
from app.services import review_queue

router = APIRouter(
    prefix="/api/v1", tags=["review queue"], dependencies=[Depends(require_backoffice_access)]
)

# Browser-renderable content types for the inline "View file" link.
_FILE_CONTENT_TYPES = {
    ".pdf": "application/pdf",
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".doc": "application/msword",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".bmp": "image/bmp",
    ".tiff": "image/tiff",
    ".tif": "image/tiff",
    ".gif": "image/gif",
}


class ResolveRequest(BaseModel):
    action: str = "resolve"  # "resolve" (handled) | "discard" (junk)


@router.get("/review-queue", summary="List open review items (never-processed files/rows)")
def list_review_queue(limit: int = 200) -> list[dict[str, Any]]:
    return review_queue.list_open(limit)


@router.get("/review-queue/count", summary="Count of open review items")
def review_queue_count() -> dict[str, int]:
    return {"open": review_queue.count_open()}


@router.get("/review-queue/discarded", summary="List discarded items (restorable / purgeable)")
def list_discarded(limit: int = 200) -> list[dict[str, Any]]:
    return review_queue.list_discarded(limit)


@router.post("/review-queue/{review_id}/resolve", summary="Close a review item")
def resolve_review_item(review_id: int, body: ResolveRequest) -> dict[str, Any]:
    if body.action not in ("resolve", "discard"):
        raise HTTPException(status_code=400, detail="action must be 'resolve' or 'discard'")
    ok = review_queue.resolve(review_id, body.action)
    if not ok:
        raise HTTPException(status_code=404, detail="review item not found or already closed")
    return {"ok": True, "review_id": review_id, "status": body.action}


@router.post("/review-queue/{review_id}/restore", summary="Re-open a discarded item")
def restore_review_item(review_id: int) -> dict[str, Any]:
    ok = review_queue.restore(review_id)
    if not ok:
        raise HTTPException(status_code=404, detail="item not found or not discarded")
    return {"ok": True, "review_id": review_id, "status": "open"}


@router.delete(
    "/review-queue/discarded",
    summary="Permanently delete ALL discarded items — removes their S3 files AND rows",
)
def delete_all_discarded() -> dict[str, Any]:
    result = review_queue.delete_all_discarded()
    return {"ok": True, **result}


@router.delete(
    "/review-queue/{review_id}",
    summary="Permanently delete a discarded item — removes its S3 file AND the row",
)
def delete_review_item(review_id: int) -> dict[str, Any]:
    result = review_queue.delete_permanently(review_id)
    if not result:
        raise HTTPException(
            status_code=400,
            detail="item not found or not discarded — only a discarded item can be permanently deleted",
        )
    return {"ok": True, "review_id": review_id, **result}


@router.post(
    "/review-queue/{review_id}/approve",
    summary="Override a not-a-resume/failed verdict and process the file into a candidate",
)
def approve_review_item(review_id: int) -> dict[str, Any]:
    result = review_queue.approve(review_id)
    if not result:
        raise HTTPException(
            status_code=400,
            detail=(
                "item not found, already closed, or not approvable — only a "
                "not-a-resume / failed file (with its raw upload still in storage) "
                "can be force-processed into a candidate"
            ),
        )
    return {"ok": True, "review_id": review_id, **result}


@router.post(
    "/review-queue/{review_id}/upload",
    summary="Upload the missing resume for an excel-row / failed-link item → candidate",
)
async def upload_review_item(
    review_id: int, file: UploadFile = File(...)
) -> dict[str, Any]:
    data = await file.read()
    if not data:
        raise HTTPException(status_code=400, detail="empty file")
    result = review_queue.upload(review_id, data, file.filename or "resume")
    if not result:
        raise HTTPException(
            status_code=400,
            detail=(
                "item not found, already closed, or not an excel-row / failed-link "
                "item — only those (which have no file yet) accept an upload"
            ),
        )
    return {"ok": True, "review_id": review_id, **result}


@router.get("/review-queue/{review_id}/file", summary="Stream a review item's dropped file inline")
def review_item_file(review_id: int) -> Response:
    from app.services.s3 import s3

    key = review_queue.locate_file(review_id)
    if not key:
        raise HTTPException(status_code=404, detail="no file found for this review item")
    try:
        data = s3().get_bytes(key, raw=True)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=404, detail=f"file not in storage: {exc}") from exc
    suffix = Path(key).suffix.lower()
    media_type = _FILE_CONTENT_TYPES.get(suffix, "application/octet-stream")
    return Response(
        content=data,
        media_type=media_type,
        headers={"Content-Disposition": f'inline; filename="{Path(key).name}"'},
    )
