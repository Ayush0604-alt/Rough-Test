"""Auth API — JWT login backed by the ``app_users`` table.

Backs the SPA login page. Accounts live in ``app_users`` (see
:mod:`app.services.users`); the Admin + Recruiter defaults are seeded from
:class:`app.config.Settings` on startup, and an Admin can add more via the
``/auth/users`` endpoints (Settings → User Management). A successful login
returns a signed JWT carrying a ``role`` claim; the SPA stores it and sends it
as a Bearer token. The token is long-lived (``jwt_expire_minutes``) so the
session survives reloads and persists until the user explicitly logs out.

Role model:
  * Admin      — everything, including manually overriding a candidate's Next
                 Best Action to an arbitrary value.
  * Recruiter  — Recruitment Manager: everything else (including
                 apply/bulk-apply of the system-PREDICTED NBA), but blocked —
                 server-side, not just in the UI — from the manual override
                 and from Settings.
  * Sysadmin   — System Admin: Settings access (pipeline/notifications/
                 scoring/columns + User Management), same as Admin there, but
                 no NBA-override capability (Admin-only regardless).

Protect any route by adding ``user: AuthUser = Depends(get_current_user)``;
restrict one to Admin-only by adding ``Depends(require_admin)``; restrict one
to Settings-capable roles (Admin or Sysadmin) with ``Depends(require_backoffice_access)``.
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Literal, Optional

import jwt
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, EmailStr, Field

from app.config import settings
from app.services import email_templates, graph_client, password_reset
from app.services import users as user_store

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/auth", tags=["auth"])


def _password_link(token: str) -> Optional[str]:
    """The public set-password URL for an emailed token, or None when
    APP_PUBLIC_URL isn't configured (so callers can't ship a broken link)."""
    base = (settings.app_public_url or "").rstrip("/")
    return f"{base}/set-password/{token}" if base else None


def _send_account_email(email: str, name: str, purpose: str) -> dict:
    """Mint a token + email the set-password link. Returns {sent, link}. The link
    is surfaced back to callers ONLY for the admin invite-fallback path — never
    for public forgot-password (which must not reveal the link to the requester)."""
    token = password_reset.create_token(email, purpose=purpose)
    link = _password_link(token)
    if not link:
        logger.warning("auth: APP_PUBLIC_URL unset — cannot build %s link for %s", purpose, email)
        return {"sent": False, "link": None}
    if purpose == "invite":
        subject, body = email_templates.render_account_invite(name, link)
    else:
        subject, body = email_templates.render_password_reset(name, link)
    res = graph_client.send_mail(email, subject, graph_client.plain_text_to_html(body))
    if not res.get("sent"):
        logger.warning("auth: %s email to %s not sent: %s", purpose, email, res.get("error"))
    return {"sent": bool(res.get("sent")), "link": link}

_bearer = HTTPBearer(auto_error=False)

Role = Literal["admin", "recruiter", "sysadmin"]


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class AuthUser(BaseModel):
    email: str
    name: str
    role: Role
    # First-login / post-admin-reset gate: the SPA blocks the app behind a
    # forced change-password dialog while this is True. Derived from the DB
    # (login + /me), never from the JWT — so an admin reset takes effect on
    # the user's next /me validation even mid-session.
    must_change_password: bool = False


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: AuthUser


def _user_for(email: str, role: Role) -> AuthUser:
    name = email.split("@")[0].replace(".", " ").replace("_", " ").title()
    return AuthUser(email=email, name=name or "Recruiter", role=role)


def _create_token(email: str, role: Role) -> str:
    now = datetime.now(timezone.utc)
    payload = {
        "sub": email,
        "role": role,
        "iat": now,
        "exp": now + timedelta(minutes=settings.jwt_expire_minutes),
    }
    return jwt.encode(payload, settings.jwt_secret, algorithm=settings.jwt_algorithm)


@router.post("/login", response_model=TokenResponse)
def login(body: LoginRequest) -> TokenResponse:
    match = user_store.authenticate(body.email, body.password)
    if match is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password.",
        )
    user = AuthUser(
        email=match["email"], name=match["name"], role=match["role"],
        must_change_password=bool(match.get("must_change_password")),
    )
    return TokenResponse(access_token=_create_token(user.email, user.role), user=user)


def get_current_user(
    creds: HTTPAuthorizationCredentials | None = Depends(_bearer),
) -> AuthUser:
    """Dependency: validate the Bearer token, return the authenticated user."""
    if creds is None or creds.scheme.lower() != "bearer":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated.",
            headers={"WWW-Authenticate": "Bearer"},
        )
    try:
        payload: dict[str, Any] = jwt.decode(
            creds.credentials,
            settings.jwt_secret,
            algorithms=[settings.jwt_algorithm],
        )
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Session expired. Please sign in again.",
            headers={"WWW-Authenticate": "Bearer"},
        )
    except jwt.PyJWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token.",
            headers={"WWW-Authenticate": "Bearer"},
        )
    email = payload.get("sub")
    if not email:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token."
        )
    # role defaults to "admin" for tokens issued before the role claim existed
    # (dev-env long-lived sessions) so an existing login doesn't get locked out.
    role: Role = payload.get("role") or "admin"
    return _user_for(email, role)


def require_admin(user: AuthUser = Depends(get_current_user)) -> AuthUser:
    """Dependency: like get_current_user, but 403s unless the role is admin.
    Use on any route that must be Admin-only (e.g. manual NBA override)."""
    if user.role != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="This action is restricted to Admin.",
        )
    return user


def require_backoffice_access(user: AuthUser = Depends(get_current_user)) -> AuthUser:
    """Dependency: like get_current_user, but 403s unless the role is admin or
    sysadmin. Use on any back-office route (Settings incl. User Management,
    Mailbox/intake, Activity Log) — Recruiter has none of these, only the
    candidate pipeline (Dashboard, Candidates, Process Flow)."""
    if user.role not in ("admin", "sysadmin"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="This action is restricted to Admin or System Admin.",
        )
    return user


@router.get("/me", response_model=AuthUser)
def me(user: AuthUser = Depends(get_current_user)) -> AuthUser:
    """Return the current session's user — used by the SPA to validate a stored token."""
    row = user_store.get_user_by_email(user.email)
    if row:
        user.must_change_password = bool(row.get("must_change_password"))
    return user


class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str = Field(min_length=6, max_length=128)


@router.post("/change-password")
def change_password(
    body: ChangePasswordRequest, user: AuthUser = Depends(get_current_user)
) -> dict[str, bool]:
    """Self-service password change — available to every logged-in role
    (Admin / System Admin / Recruitment Manager) from the profile menu, and
    the required step behind the first-login forced change."""
    if body.new_password == body.current_password:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="The new password must be different from the current one.",
        )
    if not user_store.change_password(user.email, body.current_password, body.new_password):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Current password is incorrect.",
        )
    return {"ok": True}


# ── Public: forgot password + set/reset password via emailed token ──────────
class ForgotPasswordRequest(BaseModel):
    email: EmailStr


@router.post("/forgot-password", status_code=status.HTTP_200_OK)
def forgot_password(body: ForgotPasswordRequest) -> dict[str, Any]:
    """Public: email a reset link IF the account exists. ALWAYS returns the same
    200 message — it never reveals whether an email is registered (anti-
    enumeration), and never surfaces the link to the caller."""
    email = str(body.email).strip()
    user = user_store.get_user_by_email(email)
    if user:
        try:
            _send_account_email(email, user.get("name") or "", "reset")
        except Exception as exc:  # noqa: BLE001 — never leak failure to the caller
            logger.warning("auth: forgot-password send failed for %s: %s", email, exc)
    return {"ok": True, "message": "If that email is registered, a reset link is on its way."}


class ResetTokenInfo(BaseModel):
    valid: bool
    # 'reset' | 'invite' — lets the page greet a new member differently from a
    # returning user resetting a forgotten password.
    purpose: str | None = None


@router.get("/reset-token/{token}", response_model=ResetTokenInfo)
def check_reset_token(token: str) -> dict[str, Any]:
    """Public: is this set-password token still valid + unused? Drives the page."""
    info = password_reset.verify_token(token)
    return {"valid": bool(info), "purpose": info.get("purpose") if info else None}


class ResetPasswordSubmit(BaseModel):
    token: str
    new_password: str = Field(min_length=6, max_length=128)


@router.post("/reset-password", status_code=status.HTTP_200_OK)
def reset_password(body: ResetPasswordSubmit) -> dict[str, Any]:
    """Public: set a new password with a valid token (forgot-password OR invite).
    The token is single-use — consumed here whether or not the account still
    exists."""
    info = password_reset.consume_token(body.token)
    if not info:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="This link is invalid or has expired. Please request a new one.",
        )
    if not user_store.set_password(info["email"], body.new_password):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Account not found or inactive."
        )
    return {"ok": True, "message": "Your password is set — you can now sign in."}


# ── User management (Admin or System Admin) — Settings → User Management ─────
class UserOut(BaseModel):
    id: int
    email: str
    name: str
    role: Role
    is_active: bool
    must_change_password: bool = False
    created_at: str | None = None


class CreateUserRequest(BaseModel):
    email: EmailStr
    # When omitted (the default), the member is EMAILED a link to set their own
    # initial password — which guarantees the account has a valid, reachable
    # email. An explicit password is still accepted as an admin-handover fallback
    # (e.g. when outbound email isn't configured).
    password: str | None = Field(default=None, min_length=6, max_length=128)
    role: Role = "recruiter"


class CreateUserResponse(UserOut):
    # Present only for the emailed-invite path: whether the invite actually sent,
    # and — as a fallback when it didn't — the set-password link for the admin to
    # relay manually. Null link when the email sent (never surface it needlessly).
    invited: bool = False
    invite_sent: bool = False
    invite_link: str | None = None


@router.get("/users", response_model=list[UserOut])
def list_users(_admin: AuthUser = Depends(require_backoffice_access)) -> list[dict[str, Any]]:
    """List all login accounts. Admin or System Admin only."""
    return user_store.list_users()


@router.post("/users", response_model=CreateUserResponse, status_code=status.HTTP_201_CREATED)
def create_user(
    body: CreateUserRequest, _admin: AuthUser = Depends(require_backoffice_access)
) -> dict[str, Any]:
    """Create a new login account. Admin or System Admin only. By default the
    member receives an emailed link to set their initial password (no admin-typed
    password); passing an explicit `password` uses it as a handover credential."""
    invited = body.password is None
    # An invited account still needs a stored hash — a throwaway random one the
    # member replaces via the emailed link (never disclosed to anyone).
    initial = body.password or user_store.generate_password()
    try:
        created = user_store.create_user(str(body.email), initial, body.role)
    except user_store.DuplicateEmailError:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="A user with that email already exists.",
        )
    out: dict[str, Any] = dict(created)
    out["invited"] = invited
    if invited:
        res = _send_account_email(str(body.email), created.get("name") or "", "invite")
        out["invite_sent"] = res["sent"]
        # Only hand the raw link back when the email DIDN'T send (fallback).
        out["invite_link"] = None if res["sent"] else res["link"]
    return out


class ResetPasswordResponse(BaseModel):
    email: str
    # The freshly generated password, returned exactly once for the Admin to
    # hand to the user — never stored/retrievable in plain form again.
    password: str


@router.post("/users/{user_id}/reset-password", response_model=ResetPasswordResponse)
def reset_user_password(
    user_id: int, _admin: AuthUser = Depends(require_admin)
) -> dict[str, str]:
    """Admin-only override: reset a user's password to a recommended, freshly
    generated value. The user is forced to change it on their next login."""
    result = user_store.admin_reset_password(user_id)
    if not result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found.")
    return result


@router.delete("/users/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_user(
    user_id: int, admin: AuthUser = Depends(require_backoffice_access)
) -> None:
    """Delete a login account. Admin or System Admin only. Refuses to remove the last admin."""
    # Guard against locking everyone out: never delete the final admin account.
    if user_store.count_admins(exclude_id=user_id) == 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot delete the last remaining admin account.",
        )
    if not user_store.delete_user(user_id):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="User not found."
        )
