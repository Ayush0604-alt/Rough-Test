"""Generate Interview Questions — recruiter copilot endpoint.

Builds a context-aware interview kit from a candidate_master row: difficulty is
derived from ATS score + experience, fresher candidates get project/fundamentals
bias, laterals get impact/system-design bias. Uses the Azure LLM when available,
with a deterministic fallback so the endpoint always returns a usable kit.
"""
from __future__ import annotations

import logging
import os
import re
from pathlib import Path
from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from app.api.auth import AuthUser, get_current_user, require_admin
from app.repositories import repo

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1", tags=["interview (copilot)"])


# ── Extra question modes ─────────────────────────────────────────────────────
# Opt-in aptitude buckets a recruiter can layer on top of the standard,
# profile-grounded kit via the "Generate Interview Questions" dropdown on the
# candidate page. Selecting several combines all of them into one kit.
# Mode → bucket name / search topic are now CONFIG-DRIVEN (Settings → Interview
# Question Generation → app.services.interview_modes_config). These accessors
# read the active list so custom types added in Settings work end-to-end; the
# built-in defaults (interview_modes_config.DEFAULT_MODES) reproduce the
# original hardcoded set.
def _mode_names() -> dict[str, str]:
    from app.services import interview_modes_config
    return interview_modes_config.bucket_names()


def _mode_topics() -> dict[str, str]:
    from app.services import interview_modes_config
    return interview_modes_config.search_topics()


def _mode_guidance() -> dict[str, str]:
    from app.services import interview_modes_config
    return interview_modes_config.guidance()


# ── Request ─────────────────────────────────────────────────────────────────

class InterviewRequest(BaseModel):
    focus: Optional[str] = None          # projects | experience | system_design
    difficulty_bias: Optional[str] = None  # easier | harder
    # Bumped by the client on each "Regenerate" so an otherwise-identical request
    # yields a fresh kit: it drives a non-zero LLM temperature and reshuffles the
    # deterministic fallback. 0 (the default) keeps generation stable.
    variant: int = 0
    # Extra aptitude buckets to layer on top of the standard kit — any subset of
    # MODE_BUCKET_NAMES' keys; unknown keys are ignored. Multi-select: several
    # modes combine into the same kit alongside the base questions.
    modes: Optional[list[str]] = None
    # Independent of "difficulty" (conceptual depth): how much hands-on WORK a
    # question demands during the interview itself.
    #   lighter -> a quick verbal question, answerable from memory in under a minute.
    #   medium  -> a short exercise the candidate works through live (a few minutes)
    #              before explaining the result.
    #   harder  -> a real task the candidate must actually derive/build/compute over
    #              several minutes, then present the outcome back — not something
    #              answerable from memory alone.
    # None keeps today's default (unbiased) phrasing.
    effort: Optional[str] = None
    # Composition rider — relative weight per section (standard bucket name OR a
    # mode bucket name) controlling roughly what SHARE of the total questions
    # comes from each. e.g. {"Analytical Thinking & Logical Reasoning": 3,
    # "Fundamentals": 1}. Absent/empty = balanced default.
    mode_weights: Optional[dict[str, int]] = None
    # When true, the selected modes are grounded in a fresh web search of
    # popular resources for each topic; the sources are returned on the kit.
    search_web: bool = False
    # When true, generate GENERIC questions that apply uniformly to any candidate
    # for this stream/level (a placement-drive question set) instead of grounding
    # them in this candidate's own projects/evidence. Used to build a reusable
    # question bank — see the question-bank endpoints below.
    avoid_personalization: bool = False
    # Approximate TOTAL number of questions across all buckets (overrides the
    # default 12–16). Clamped server-side to a sane range.
    total_questions: Optional[int] = None
    # Section (bucket) names to OMIT entirely from the kit — the "avoid this
    # section" side of the composition control.
    exclude_sections: Optional[list[str]] = None
    # Per-section difficulty level — section (bucket) name → "B" (Beginner) |
    # "I" (Intermediate) | "E" (Expert) | "A" (Advanced). Pitches each section's
    # questions at that level (overrides the kit-wide difficulty for that section).
    section_levels: Optional[dict[str, str]] = None


# ── Helpers ─────────────────────────────────────────────────────────────────

def _as_list(v: Any) -> list[str]:
    if isinstance(v, list):
        return [str(x) for x in v if x]
    if isinstance(v, str) and v.strip():
        return [s.strip() for s in v.split(" · ") if s.strip()]
    return []


def _difficulty(ats: float, bias: Optional[str]) -> str:
    if ats >= 86:
        level = "Very Hard"
    elif ats >= 71:
        level = "Hard"
    elif ats >= 41:
        level = "Medium"
    else:
        level = "Easy"
    order = ["Easy", "Medium", "Hard", "Very Hard"]
    i = order.index(level)
    if bias == "easier":
        i = max(0, i - 1)
    elif bias == "harder":
        i = min(len(order) - 1, i + 1)
    return order[i]


def _experience_type(c: dict) -> str:
    fol = (c.get("fresher_or_lateral") or "").lower()
    yoe = c.get("yearofexp") or 0
    if fol == "fresher" or yoe == 0:
        return "Fresher"
    if yoe and yoe <= 2:
        return "Early-career (0–2y)"
    return "Lateral (3y+)"


def _build_context(c: dict) -> dict:
    return {
        "candidate_id": c.get("candidate_id"),
        "name": c.get("name") or c.get("candidate_id"),
        "stream": c.get("stream"),
        "domain": c.get("domain"),
        "atsscore": c.get("atsscore") or 0,
        "priority": c.get("priority"),
        "fresher_or_lateral": c.get("fresher_or_lateral"),
        "yearofexp": c.get("yearofexp"),
        "total_companieswitched": c.get("total_companieswitched"),
        "careergap": c.get("careergap"),
        "currentcompany": c.get("currentcompany"),
        "projects": _as_list(c.get("projects")),
        "primary_skills": _as_list(c.get("primary_skills")),
        "job_roles": _as_list(c.get("job_roles")),
        "evidence_snippets": _as_list(c.get("evidence_snippets")),
        "recommendation": c.get("recommendation"),
        "analysis": c.get("analysis"),
    }


PROMPT = """
You are NeuLeap's senior technical interviewer. From ONE candidate's structured
profile you design a focused, fair interview kit. Return JSON only — no prose.

PRINCIPLES
- Ground EVERY question in the candidate's actual projects, skills, roles, domain,
  and evidence. Never invent a technology or experience the profile does not show.
- Respect the difficulty level given in the input (Easy/Medium/Hard/Very Hard):
  Easy = verification & fundamentals; Medium = practical implementation; Hard =
  design/tradeoffs; Very Hard = deep scenario/impact.
- A Fresher → bias to projects, fundamentals, reasoning behind choices, code
  quality, learning agility, college/hackathon work. Avoid heavy enterprise system
  design unless experience justifies it.
- A Lateral / 3y+ → bias to work impact, ownership, system design, scale,
  production incidents, tradeoffs, migrations, debugging, collaboration.
- Low ATS → more gap-spotting / verification / clarification questions.
- Honor the optional "focus" (projects | experience | system_design) by weighting
  that bucket more heavily, but always keep the kit balanced.
- Honor the optional "effort" input — a SEPARATE axis from difficulty, about how
  much hands-on WORK answering takes, not how conceptually hard it is:
    "lighter" (or absent) -> phrase questions as quick, conversational, answerable
      from memory in under a minute — today's default style.
    "medium" -> phrase 1–2 questions per bucket as a short hands-on exercise the
      candidate actually works through during the call (a few minutes) — e.g.
      "trace through this snippet and tell me what it prints", "sketch the schema
      for X" — before explaining the result.
    "harder" -> phrase MOST questions as a real task requiring the candidate to
      actually DERIVE/COMPUTE/BUILD something over several minutes (give them
      concrete inputs — numbers, a snippet, a small dataset, a scenario — to work
      from) and then present the outcome back, not something answerable purely
      from memory. Still grounded in their profile/stack.
  Whatever the effort level, keep "difficulty" (Easy/Medium/Hard/Very Hard) about
  conceptual depth as already defined — the two axes are independent.
- If the input includes a non-empty "mode_buckets" list, ADD ONE EXTRA bucket per
  entry, using EXACTLY that bucket name, IN ADDITION TO the standard buckets
  above (do not replace or drop the standard ones — this is a combination).
  Each extra bucket gets aptitude-style questions for that specific topic, still
  grounded in the candidate's stack/domain where relevant, and tagged with the
  same difficulty rules. Topic guidance for the special modes:
    "Prompt Writing" -> tasks to author/critique/iterate LLM prompts: write a
      prompt for a concrete extraction/generation task, spot what's wrong with a
      given prompt, add guardrails/format constraints, or improve a weak prompt.
    "Operations Research" -> optimization & decision problems: linear
      programming / resource allocation, scheduling, transportation/assignment,
      queuing, inventory — set up the model (objective, constraints) and reason
      about the solution, favouring practical formulation over heavy math.
    "Analytical Thinking & Logical Reasoning" -> sharp reasoning + estimation
      (guesstimate/Fermi) + algorithmic-logic puzzles of the high-quality
      lateral-thinking kind. Examples of the STYLE (do NOT reuse verbatim):
      "estimate how many litres of paint are needed to paint a passenger
      aircraft", "design the control logic for an elevator serving a 20-floor
      building", "how many piano tuners are in a city", weighing/river-crossing
      puzzles, and quick mental-math. Each question must include a crisp
      strong_answer that lays out the reasoning/estimation steps, not just a
      number.
- If the input includes a non-empty "mode_weights" object (section name -> a
  small integer weight), COMPOSE the kit so the number of questions in each
  named section is roughly PROPORTIONAL to its weight relative to the others
  (e.g. weights {"Analytical Thinking & Logical Reasoning": 3, "Fundamentals":
  1} means ~3x as many analytical questions as fundamentals). Keep the total in
  the 12–16 range; sections not named keep a small baseline.
- If the input includes a non-empty "web_reference" list (title/url/snippet
  entries from a web search of popular resources for the selected topics), USE
  it as inspiration for the STYLE and coverage of the aptitude questions — adapt
  the ideas to fresh, candidate-appropriate questions; never copy text verbatim
  and never invent facts from a snippet. Web reference means these should be the
  LATEST and most challenging questions for the level, not stale textbook items.
- If the input includes a "mode_guidance" object (bucket name -> instruction),
  follow that instruction for the matching bucket in addition to the rules above.
- If the input includes "total_questions" (a positive integer), produce
  APPROXIMATELY that many questions IN TOTAL across all buckets (distributed by
  the mode_weights when present), instead of the default 12–16. Keep at least one
  question in every included bucket.
- If the input includes a non-empty "exclude_sections" list, DO NOT emit any
  bucket whose name appears in it — omit those sections from the kit entirely.
- If the input sets "avoid_personalization": true, OVERRIDE the grounding rule
  above: do NOT reference this candidate's name, specific project names,
  employer, or personal evidence. Instead generate GENERIC questions that apply
  UNIFORMLY to any candidate for this stream/domain and difficulty level, so the
  same set can fairly evaluate a whole cohort (e.g. a placement drive). Calibrate
  level from the "stream"/"domain"/"difficulty" inputs only. Keep the standard
  bucket structure and any requested modes, but replace the profile-specific
  buckets (Projects, project-anchored questions) with generic role/fundamentals
  questions. The "why" field should state the competency each question probes,
  not "why for THIS candidate".

OUTPUT SCHEMA (return exactly this shape):
{
  "summary": {
    "name": "", "stream": "", "atsscore": 0, "experience_type": "", "difficulty": ""
  },
  "buckets": [
    {
      "name": "Fundamentals" | "Projects" | "Role Fit" | "Debugging & Troubleshooting"
              | "Behavioral & Ownership" | "Advanced Follow-up"
              | one of the requested "mode_buckets" names verbatim,
      "questions": [
        {
          "question": "the question text, specific to this candidate",
          "why": "one sentence: why this question for THIS candidate",
          "difficulty": "Easy" | "Medium" | "Hard" | "Very Hard",
          "strong_answer": "what a strong answer should contain",
          "hints": ["a short cue the interviewer can use to probe/guide", "1-3 of them"],
          "answer_points": [
            {"point": "a specific credit-bearing thing a good answer covers", "marks": 4},
            {"point": "another distinct credit-bearing point", "marks": 3},
            {"point": "another", "marks": 3}
          ],
          "explanation": "a fuller, teach-back explanation of the correct answer (shown to the interviewer AFTER marking)",
          "follow_up": "one optional follow-up question, or null"
        }
      ]
    }
  ]
}
Produce 5–6 buckets, 2–3 questions each (12–16 total). Reference real project names
and skills from the profile in the question text.
"answer_points" is a SCORING RUBRIC: 2–4 distinct points whose "marks" are positive
integers that SUM TO 10 (each question is out of 10). "hints" are 1–3 short interviewer
cues. "explanation" is a fuller correct-answer writeup for post-marking review.

If "section_levels" is provided (a map of bucket name → level), pitch THAT section's
questions at the given level, overriding the kit-wide difficulty for it:
B = Beginner (basic recall / definitions), I = Intermediate (applied, typical on-the-job),
E = Expert (deep, edge-cases, trade-offs), A = Advanced (open-ended design / research-grade).
Set each question's "difficulty" consistently with its section's level.
""".strip()


def _normalize_question(q: dict) -> dict:
    """Ensure a question dict always carries the reveal-gated marking fields in a
    consistent shape — hints (list[str]), answer_points (rubric: list[{point,
    marks}]), explanation (str) — regardless of whether it came from the LLM, the
    offline fallback, or an older saved bank. Missing → sensible empty defaults."""
    q = dict(q or {})
    q.setdefault("question", "")
    q.setdefault("why", "")
    q.setdefault("difficulty", "Medium")
    q.setdefault("strong_answer", "")
    q.setdefault("follow_up", None)

    hints = q.get("hints")
    if isinstance(hints, str):
        hints = [hints]
    q["hints"] = [str(h).strip() for h in (hints or []) if str(h).strip()]

    points = []
    for p in q.get("answer_points") or []:
        if not isinstance(p, dict):
            continue
        point = str(p.get("point") or p.get("answer") or "").strip()
        if not point:
            continue
        try:
            marks = float(p.get("marks") or 0)
        except (TypeError, ValueError):
            marks = 0.0
        points.append({"point": point, "marks": marks})
    q["answer_points"] = points

    q["explanation"] = str(q.get("explanation") or "").strip()
    return q


def _normalize_buckets(buckets: Any) -> list:
    out = []
    for b in buckets or []:
        if not isinstance(b, dict):
            continue
        qs = [_normalize_question(q) for q in (b.get("questions") or []) if isinstance(q, dict)]
        out.append({**b, "questions": qs})
    return out


def _llm_generate(
    ctx: dict,
    difficulty: str,
    focus: Optional[str],
    variant: int = 0,
    mode_buckets: Optional[list[str]] = None,
    effort: Optional[str] = None,
    mode_weights: Optional[dict] = None,
    web_reference: Optional[list] = None,
    avoid_personalization: bool = False,
    total_questions: Optional[int] = None,
    exclude_sections: Optional[list[str]] = None,
    section_levels: Optional[dict] = None,
) -> Optional[dict]:
    try:
        from app.extraction.engine import (
            _azure_config,
            _chat_json,
            _resolve_master_deployment,
        )

        client, default_deployment = _azure_config(module="interview_questions")
        deployment = _resolve_master_deployment(default_deployment, module="interview_questions")
        payload = {
            "difficulty": difficulty,
            "focus": focus,
            "candidate": ctx,
            # Distinct nonce per regenerate so the prompt input differs run-to-run.
            "variant": variant,
            # Extra opt-in aptitude buckets to combine with the standard kit.
            "mode_buckets": mode_buckets or [],
            # How much hands-on work a question demands — see InterviewRequest.effort.
            "effort": effort,
            # Composition rider: section name -> relative weight.
            "mode_weights": mode_weights or {},
            # Web-search reference material for the selected topics (optional).
            "web_reference": web_reference or [],
            # Generate generic, cohort-uniform questions (not personalized).
            "avoid_personalization": avoid_personalization,
            # Approximate total question count (overrides the default range).
            "total_questions": total_questions,
            # Sections to omit entirely.
            "exclude_sections": exclude_sections or [],
            # Per-section difficulty level (bucket name -> B/I/E/A).
            "section_levels": section_levels or {},
            # Per-mode extra instructions (Settings → custom types can carry these).
            "mode_guidance": {
                name: g for name, g in _mode_guidance().items()
                if name in set(mode_buckets or [])
            },
        }
        # The generation prompt is editable (Settings → Interview Question
        # Generation); falls back to the built-in PROMPT when no override is set.
        from app.services import interview_prompt_config
        system_prompt = interview_prompt_config.active(PROMPT)
        # A fresh regenerate (variant > 0) samples at a non-zero temperature so the
        # kit actually changes; the first load (variant 0) stays deterministic.
        result, _usage = _chat_json(
            client=client,
            deployment=deployment,
            system_prompt=system_prompt,
            user_payload=payload,
            temperature=0.8 if variant > 0 else 0,
            candidate_id=ctx.get("candidate_id"),
            module="interview_questions",
        )
        if isinstance(result, dict) and result.get("buckets"):
            result["buckets"] = _normalize_buckets(result["buckets"])
            result.setdefault("summary", {})
            result["summary"].update(
                {
                    "name": ctx["name"],
                    "stream": ctx.get("stream"),
                    "atsscore": ctx.get("atsscore"),
                    "difficulty": difficulty,
                }
            )
            return result
    except Exception as exc:  # noqa: BLE001 — always fall back, never 500
        logger.warning("interview LLM generation failed: %s", exc)
    return None


def _mode_bucket(mode: str, difficulty: str) -> Optional[dict]:
    """Static aptitude bucket for one opt-in mode — used by the offline fallback
    (the LLM path gets the same 5 modes via the "mode_buckets" prompt input)."""
    name = _mode_names().get(mode)
    if not name:
        return None

    def q(text, why, sa, fu=None):
        return {"question": text, "why": why, "difficulty": difficulty,
                "strong_answer": sa, "follow_up": fu}

    questions_by_mode: dict[str, list[dict]] = {
        "sql_aptitude": [
            q("Write a query to find the second-highest salary in an Employees table "
              "without using LIMIT/OFFSET.",
              "Tests SQL fundamentals beyond simple SELECTs — subqueries/window functions.",
              "A correct subquery or DENSE_RANK()/ROW_NUMBER() approach that handles ties correctly."),
            q("Explain the difference between INNER JOIN, LEFT JOIN, and a correlated "
              "subquery — when would you pick each?",
              "Checks join semantics and query-plan intuition.",
              "Correct semantics for each, plus a concrete scenario where one is clearly the right tool."),
            q("Given a slow-running query on a large table, how would you diagnose and fix it?",
              "Probes practical query-optimization skill.",
              "EXPLAIN-plan reading, index usage, and a specific fix (index, rewrite, partitioning)."),
        ],
        "logical_reasoning": [
            q("You have 9 identical-looking balls and one is heavier — how do you find it "
              "in the fewest weighings on a balance scale?",
              "Classic logical-deduction puzzle — tests structured problem decomposition.",
              "Correct 2-weighing solution (splitting into groups of 3) with clear reasoning."),
            q("A sequence goes 2, 6, 12, 20, 30, … — what's the next number and the "
              "underlying rule?",
              "Tests pattern recognition under time pressure.",
              "Identifies the n(n+1) pattern, computes 42, and explains the rule."),
            q("Walk me through how you'd approach a problem where the requirements "
              "seem to contradict each other.",
              "Assesses reasoning under ambiguity, not just puzzle-solving.",
              "Clarifying questions, explicit assumptions, and a structured way to resolve the conflict."),
        ],
        "dsa_aptitude": [
            q("Given an array, find two numbers that add up to a target value — what's "
              "the most efficient approach and its complexity?",
              "Baseline DSA check: hashing vs brute force.",
              "O(n) hash-map approach, correctly reasoning about the time/space tradeoff vs O(n²)."),
            q("How would you detect a cycle in a linked list, and can you do it in O(1) space?",
              "Tests pointer manipulation and classic algorithm recall.",
              "Floyd's cycle detection (slow/fast pointers), explained correctly."),
            q("How would you choose between a hash map, a heap, and a balanced BST for "
              "a given problem?",
              "Checks data-structure selection judgment, not just memorized algorithms.",
              "Correct tradeoffs (lookup speed, ordering, min/max access) tied to a concrete example."),
        ],
        "python_libraries_aptitude": [
            q("In a FastAPI service, how do you handle a slow, blocking call inside an "
              "async endpoint without stalling the event loop?",
              "Tests real understanding of async/await vs blocking I/O in FastAPI.",
              "Identifies run_in_executor / background tasks / async-native clients as fixes — "
              "not just adding 'async' to the def."),
            q("When building a GenAI pipeline, how do you decide between an orchestration "
              "framework (e.g. LangChain-style) and calling the model SDK directly?",
              "Probes practical judgment on GenAI tooling tradeoffs, not library trivia.",
              "Weighs flexibility/debuggability of direct calls against orchestration convenience, "
              "with a concrete scenario."),
            q("In pandas/PySpark, what's the difference between an eager and a lazy "
              "transformation, and why does it matter for a data engineering pipeline?",
              "Checks core data-engineering library fundamentals.",
              "Correctly explains lazy evaluation (e.g. Spark transformations vs actions) and "
              "its performance/debugging implications."),
        ],
        "data_eng_dwh_aptitude": [
            q("Explain star schema vs snowflake schema — when would you pick one over "
              "the other for a data warehouse?",
              "Tests core data-warehousing modeling knowledge.",
              "Correct tradeoffs: query simplicity/performance (star) vs normalization/storage "
              "(snowflake), tied to a real use case."),
            q("How would you design an incremental (delta) load for a fact table that "
              "has late-arriving data?",
              "Probes real pipeline design experience, not just theory.",
              "A watermarking/CDC approach, handling late data without full reprocessing, and idempotency."),
            q("What's the difference between ETL and ELT, and how does that choice "
              "affect your warehouse architecture?",
              "Checks understanding of modern data-platform tradeoffs.",
              "Correctly explains where transformation happens and why (e.g. cloud warehouse "
              "compute), with a concrete example."),
        ],
        "prompt_writing": [
            q("Write a system prompt for an assistant that extracts a candidate's "
              "name, email, phone and total years of experience from a raw resume, "
              "returning STRICT JSON — and explain the guardrails you added.",
              "Tests the ability to author a precise, constraint-driven LLM prompt.",
              "Clear role, an exact output schema, explicit 'JSON only' / no-prose rule, "
              "handling of missing fields, and a note on why each guardrail matters."),
            q("Here's a weak prompt: 'Summarize this and make it good.' Rewrite it for a "
              "support-ticket summarizer and justify every change.",
              "Probes prompt-critique and iteration skill, not just writing from scratch.",
              "Adds role, audience, length/format constraints, tone, and what to include/exclude — "
              "each change tied to a concrete failure the original invites."),
            q("How would you prompt a model to REFUSE to answer off-topic questions while "
              "still being helpful on the intended task?",
              "Checks understanding of instruction-following, scoping and guardrails.",
              "A scoping instruction + refusal template + examples, and awareness that examples "
              "(few-shot) steer behavior more reliably than adjectives."),
        ],
        "operations_research": [
            q("A team can build two products; each needs limited machine-hours and labour. "
              "Set up the model to MAXIMIZE profit — what are the decision variables, "
              "objective and constraints?",
              "Tests the ability to formulate a linear program from a word problem.",
              "Names decision variables, a linear objective, the resource/non-negativity "
              "constraints, and identifies it as an LP solvable by simplex."),
            q("You must assign 5 engineers to 5 tasks to minimize total time. How do you "
              "model and solve it, and how does it differ from a transportation problem?",
              "Probes classic OR modeling (assignment vs transportation).",
              "Recognizes the assignment problem (Hungarian method / LP), the cost matrix, and "
              "the one-to-one vs supply/demand distinction."),
            q("Customers arrive at ~30/hour and a single server handles ~40/hour. Reason "
              "about the expected queue and when you'd add a second server.",
              "Checks intuition for queuing / capacity tradeoffs, not heavy formulae.",
              "Utilisation ρ = arrival/service, why waiting explodes as ρ→1, and a cost-vs-"
              "service-level argument for a second server."),
        ],
        "analytical_reasoning": [
            q("Estimate how many litres of paint are needed to give a single coat to a "
              "narrow-body passenger aircraft. Walk me through your reasoning.",
              "A Fermi/guesstimate — tests structured estimation under uncertainty.",
              "Decomposes surface area (fuselage cylinder + wings + tail), assumes a coverage "
              "rate (m² per litre), states assumptions, and reaches a defensible ballpark."),
            q("Design the control logic for an elevator serving a 20-floor building with "
              "heavy morning up-traffic. What rules decide where it goes next?",
              "Tests algorithmic thinking on a real scheduling problem.",
              "A sensible policy (e.g. SCAN/LOOK, honoring direction, avoiding starvation), "
              "morning-peak optimization, and the tradeoffs it makes."),
            q("A 3-litre and a 5-litre jug, unlimited water — measure exactly 4 litres. "
              "Then explain the general principle.",
              "A classic logic puzzle — tests methodical reasoning and generalization.",
              "A correct fill/pour sequence AND the insight that reachable amounts are "
              "combinations governed by gcd(3,5)=1."),
            q("You have 8 identical-looking balls; one is slightly heavier. Using a balance "
              "scale only TWICE, how do you find it?",
              "Tests information-theoretic reasoning (each weighing = a 3-way split).",
              "3-3-2 first weighing, then narrows to the heavy ball in the second — reasoning "
              "that two weighings distinguish up to 9 items."),
        ],
    }
    return {"name": name, "questions": questions_by_mode.get(mode, [])}


def _search_query(mode: str) -> str:
    """The web-search query for a mode: its configured topic, or — when that's
    missing/too thin (an empty or junk value like "Yes") — the section name, in
    both cases sharpened into an interview-question query so the results are the
    right kind of material."""
    topic = (_mode_topics().get(mode) or "").strip()
    bucket = (_mode_names().get(mode) or mode).strip()
    base = topic if len(topic) >= 4 else bucket
    low = base.lower()
    if "interview" not in low and "question" not in low and "puzzle" not in low:
        base = f"{base} interview questions and answers"
    return base


def _web_reference(modes: list[str], per_mode: int = 4) -> tuple[list[dict], list[dict]]:
    """Search the web for popular resources on each selected mode.
    Returns ``(reference, sources)`` — ``reference`` is the snippet material fed
    to the LLM; ``sources`` is the de-duped list of links shown in the UI.
    Best-effort: a failed search for a mode just contributes nothing, but every
    selected mode is always searched (falling back to its section name) so the
    feature never silently returns nothing just because a topic wasn't set."""
    from app.services import web_search

    reference: list[dict] = []
    sources: list[dict] = []
    seen: set[str] = set()
    for mode in modes:
        query = _search_query(mode)
        if not query:
            continue
        for hit in web_search.search(query, limit=per_mode):
            url = hit.get("url", "")
            if not url or url in seen:
                continue
            seen.add(url)
            entry = {"section": _mode_names().get(mode, mode), **hit}
            sources.append(entry)
            reference.append({k: hit.get(k, "") for k in ("title", "snippet")})
    return reference, sources


# Appended to each fallback question's text so the offline kit honors "effort"
# too, without hand-rewriting every canned question — the LLM path instead
# rephrases the question itself (see PROMPT's "effort" principle).
_EFFORT_SUFFIX = {
    "medium": " Take a couple of minutes to work through it, then walk me through your result.",
    "harder": " Actually work this through — derive/compute/sketch the real answer over the next "
              "several minutes — then present the outcome back to me, not just a recalled answer.",
}


def _generic_buckets(ctx: dict, difficulty: str, exp_type: str) -> list[dict]:
    """Cohort-uniform (non-personalized) fallback buckets — no project/skill
    anchors, calibrated only from stream/domain/difficulty. Used to seed a
    reusable question bank when the LLM is unavailable."""
    track = ctx.get("stream") or ctx.get("domain") or "software engineering"

    def q(text, why, sa, fu=None):
        return {"question": text, "why": why, "difficulty": difficulty,
                "strong_answer": sa, "follow_up": fu}

    return [
        {"name": "Fundamentals", "questions": [
            q(f"Explain a core concept every {track} engineer relies on daily, and a "
              "common way it's misused.",
              "Baseline conceptual depth for the track, comparable across candidates.",
              "Accurate mental model, a concrete tradeoff, and a real misuse example."),
            q(f"Walk through how you'd structure a small {track} feature end-to-end.",
              "Checks baseline design reasoning at this level, uniformly.",
              "Clear separation of concerns, data flow, and error handling."),
        ]},
        {"name": "Problem Solving", "questions": [
            q("Given an ambiguous requirement, how do you turn it into a concrete, "
              "testable plan?",
              "Assesses structured thinking independent of any specific project.",
              "Clarifying questions, explicit assumptions, milestones, and a validation step."),
        ]},
        {"name": "Role Fit", "questions": [
            q(f"What draws you to {track}, and how do you keep your skills current?",
              "Motivation and growth trajectory — same question for the whole cohort.",
              "Genuine interest and a concrete, recent learning habit."),
        ]},
        {"name": "Debugging & Troubleshooting", "questions": [
            q("A service intermittently returns wrong results in production — how do "
              "you isolate the cause?",
              "Probes systematic debugging without needing personal context.",
              "Reproduce -> narrow scope -> logs/metrics -> hypothesis -> verify, without guessing."),
        ]},
        {"name": "Behavioral & Ownership", "questions": [
            q("Tell me about a time you took ownership of something outside your "
              "assigned scope.",
              "Surfaces initiative and collaboration comparably across candidates.",
              "Clear situation, personal action, and a result with reflection."),
        ]},
    ]


def _fallback(
    ctx: dict,
    difficulty: str,
    exp_type: str,
    focus: Optional[str],
    variant: int = 0,
    modes: Optional[list[str]] = None,
    effort: Optional[str] = None,
    avoid_personalization: bool = False,
    total_questions: Optional[int] = None,
    exclude_sections: Optional[list[str]] = None,
) -> dict:
    """Profile-grounded kit when the LLM is unavailable.

    ``variant`` (bumped by each Regenerate) rotates which skill/project anchors the
    questions, so the offline kit still visibly changes between regenerations
    instead of returning a byte-identical kit every time. When
    ``avoid_personalization`` is set the base buckets are generic/cohort-uniform
    instead (the opt-in aptitude modes are still layered on top).
    """
    skills = ctx["primary_skills"] or ["your core stack"]
    projects = ctx["projects"]
    is_fresher = exp_type.startswith("Fresher")
    # Rotate the anchor skill/project by the variant so regenerate isn't a no-op.
    s0 = skills[variant % len(skills)]
    proj0 = projects[variant % len(projects)] if projects else "your most significant project"

    def q(text, why, sa, fu=None):
        return {"question": text, "why": why, "difficulty": difficulty,
                "strong_answer": sa, "follow_up": fu}

    buckets: list[dict] = [
        {"name": "Fundamentals", "questions": [
            q(f"Explain how {s0} works under the hood and when you'd avoid it.",
              f"Validates depth in the candidate's top skill ({s0}).",
              "Accurate mental model, concrete tradeoffs, and a real example of misuse."),
            q(f"Walk through how you'd structure a small "
              f"{ctx.get('domain') or ctx.get('stream') or 'software'} feature end-to-end.",
              "Checks baseline design reasoning at this level.",
              "Clear separation of concerns, data flow, and error handling."),
        ]},
        {"name": "Projects", "questions": [
            q(f"Give a deep dive on “{proj0}”: the problem, your role, "
              "and the key technical decision.",
              "Anchors the interview in the candidate's strongest evidence.",
              "Specific ownership, a non-trivial decision with alternatives weighed, "
              "and measurable outcome.",
              "What would you change if you rebuilt it today?"),
        ] + ([q(f"In “{projects[1]}”, what was the hardest bug or constraint "
                f"and how did you resolve it?",
              "Tests problem-solving on real work.",
              "A concrete reproduction, hypothesis-driven debugging, and the fix's tradeoffs.")]
             if len(projects) > 1 else [])},
        {"name": "Role Fit", "questions": [
            q(f"Why {ctx.get('stream') or 'this track'}, and where do you want to grow next?",
              "Assesses motivation and direction for the target stream.",
              "Genuine interest tied to past work and a realistic growth plan."),
        ]},
        {"name": "Debugging & Troubleshooting", "questions": [
            q(f"A {s0} service intermittently returns wrong results in production "
              "— how do you isolate the cause?",
              "Probes systematic debugging.",
              "Reproduce → narrow scope → logs/metrics → hypothesis → verify, without guessing."),
        ]},
        {"name": "Behavioral & Ownership", "questions": [
            q("Tell me about a time you took ownership of something outside your assigned scope.",
              "Surfaces initiative and collaboration.",
              "Clear situation, personal action, and a result with reflection."),
        ]},
    ]

    if is_fresher:
        buckets.append({"name": "Advanced Follow-up", "questions": [
            q("How do you decide a piece of code is 'good enough' to ship?",
              "Fresher-appropriate depth on code quality and judgment.",
              "Readability, tests, edge cases, and pragmatic scope control."),
        ]})
    else:
        buckets.append({"name": "Advanced Follow-up", "questions": [
            q(f"Design a system to scale {proj0} to 100x traffic "
              "— what breaks first and how do you fix it?",
              "Lateral-appropriate scale/system-design probe.",
              "Bottleneck analysis, caching/sharding/queueing tradeoffs, and a staged rollout."),
            q("Describe a production incident you owned: detection, mitigation, "
              "and the durable fix.",
              "Tests real operational ownership.",
              "Timeline, blast-radius control, root cause, and a prevention follow-through."),
        ]})

    # Cohort-uniform override: replace the profile-anchored base with generic
    # buckets (opt-in aptitude modes are still layered on below).
    if avoid_personalization:
        buckets = _generic_buckets(ctx, difficulty, exp_type)
        buckets.append({"name": "Advanced Follow-up", "questions": [
            q("Design a system to handle 100x its current load — what breaks first "
              "and how do you address it?",
              "Scale/system-design probe applied uniformly to the cohort.",
              "Bottleneck analysis, caching/sharding/queueing tradeoffs, and a staged rollout."),
        ]})

    if focus == "projects":
        buckets.sort(key=lambda b: 0 if b["name"] == "Projects" else 1)
    elif focus in ("experience", "system_design"):
        buckets.sort(key=lambda b: 0 if b["name"] == "Advanced Follow-up" else 1)

    # Extra opt-in aptitude buckets — appended on top of (never replacing) the
    # standard kit above, so multiple selected modes combine into one kit.
    for mode in modes or []:
        extra = _mode_bucket(mode, difficulty)
        if extra and extra["questions"]:
            buckets.append(extra)

    suffix = _EFFORT_SUFFIX.get(effort or "")
    if suffix:
        for bucket in buckets:
            for question in bucket["questions"]:
                question["question"] += suffix

    # Omit excluded sections (keep at least one bucket) and, if a smaller total
    # was requested, trim from the end so the offline kit honors both controls.
    if exclude_sections:
        drop = {s for s in exclude_sections}
        kept = [b for b in buckets if b["name"] not in drop]
        if kept:
            buckets = kept
    if total_questions and total_questions > 0:
        remaining = total_questions
        trimmed = []
        for bucket in buckets:
            if remaining <= 0:
                break
            qs = bucket["questions"][: max(1, remaining)]
            trimmed.append({**bucket, "questions": qs})
            remaining -= len(qs)
        if trimmed:
            buckets = trimmed

    return {
        "summary": {
            "name": ctx["name"], "stream": ctx.get("stream"),
            "atsscore": ctx.get("atsscore"), "experience_type": exp_type,
            "difficulty": difficulty,
        },
        "buckets": _normalize_buckets(buckets),
        "generated_by": "fallback",
    }


@router.post(
    "/candidates/{candidate_id}/interview-questions",
    summary="Generate a context-aware interview kit for a candidate",
)
def interview_questions(candidate_id: str, body: InterviewRequest | None = None) -> dict:
    body = body or InterviewRequest()
    c = repo().get_candidate(candidate_id)
    if not c:
        raise HTTPException(status_code=404, detail=f"candidate {candidate_id} not found")

    ctx = _build_context(c)
    exp_type = _experience_type(c)
    difficulty = _difficulty(float(ctx.get("atsscore") or 0), body.difficulty_bias)
    # Silently drop unknown mode keys rather than 422 — keeps the endpoint
    # forward-compatible if the client sends a stale/renamed key.
    _names = _mode_names()
    modes = [m for m in (body.modes or []) if m in _names]
    mode_bucket_names = [_names[m] for m in modes]

    # Composition rider — keep only weights naming a real bucket (standard or a
    # selected mode), coerced to small positive ints.
    # Composition can name ANY section — the standard buckets (both the
    # profile-anchored "Projects" and its generic "Problem Solving" counterpart)
    # plus any selected mode buckets.
    valid_sections = {
        "Fundamentals", "Projects", "Problem Solving", "Role Fit",
        "Debugging & Troubleshooting", "Behavioral & Ownership", "Advanced Follow-up",
        *mode_bucket_names,
    }
    mode_weights = {
        k: max(1, min(10, int(v)))
        for k, v in (body.mode_weights or {}).items()
        if k in valid_sections and isinstance(v, (int, float)) and v
    } or None

    # Sections to omit — keep only ones naming a real section.
    exclude_sections = [s for s in (body.exclude_sections or []) if s in valid_sections] or None
    # Total-question override — clamp to a sane range.
    total_questions = None
    if body.total_questions is not None:
        try:
            total_questions = max(3, min(40, int(body.total_questions)))
        except (TypeError, ValueError):
            total_questions = None

    # "Search web" — ground the selected modes in fresh popular resources.
    web_reference, sources = ([], [])
    if body.search_web and modes:
        web_reference, sources = _web_reference(modes)

    result = _llm_generate(
        ctx, difficulty, body.focus, body.variant, mode_bucket_names, body.effort,
        mode_weights=mode_weights, web_reference=web_reference or None,
        avoid_personalization=body.avoid_personalization,
        total_questions=total_questions, exclude_sections=exclude_sections,
        section_levels=body.section_levels,
    )
    if result is None:
        result = _fallback(
            ctx, difficulty, exp_type, body.focus, body.variant, modes, body.effort,
            avoid_personalization=body.avoid_personalization,
            total_questions=total_questions, exclude_sections=exclude_sections,
        )
    else:
        result["summary"]["experience_type"] = exp_type
        result["generated_by"] = "llm"
    # The web sources used (empty unless search_web produced hits) — the UI shows
    # them as "prepared using these sources".
    result["sources"] = sources
    return result


# ── Question modes list (drives the dropdown) — any authenticated role reads ──
@router.get("/interview-modes", summary="The active list of question-generation modes")
def get_interview_modes() -> list[dict]:
    from app.services import interview_modes_config
    return interview_modes_config.get()


class InterviewModeIn(BaseModel):
    key: str = ""
    label: str
    bucket_name: str = ""
    topic: str = ""
    guidance: str = ""


# ── Admin config: modes editor + prompt (SKILL) editor ───────────────────────
@router.put("/interview-modes", dependencies=[Depends(require_admin)], summary="Admin: replace the question-mode list")
def put_interview_modes(body: list[InterviewModeIn]) -> list[dict]:
    from app.services import interview_modes_config
    try:
        return interview_modes_config.save([m.model_dump() for m in body])
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/interview-modes/revert", dependencies=[Depends(require_admin)], summary="Admin: reset modes to the built-in default")
def revert_interview_modes() -> list[dict]:
    from app.services import interview_modes_config
    return interview_modes_config.revert_to_default()


@router.get("/interview-prompt", summary="The question-generation prompt (SKILL)")
def get_interview_prompt() -> dict:
    from app.services import interview_prompt_config
    return {
        "prompt": interview_prompt_config.active(PROMPT),
        "default": PROMPT,
        "is_custom": interview_prompt_config.is_custom(),
    }


class InterviewPromptIn(BaseModel):
    prompt: str = ""


@router.put("/interview-prompt", dependencies=[Depends(require_admin)], summary="Admin: edit the question-generation prompt")
def put_interview_prompt(body: InterviewPromptIn) -> dict:
    from app.services import interview_prompt_config
    interview_prompt_config.save(body.prompt)
    return get_interview_prompt()


@router.post("/interview-prompt/revert", dependencies=[Depends(require_admin)], summary="Admin: reset the prompt to default")
def revert_interview_prompt() -> dict:
    from app.services import interview_prompt_config
    interview_prompt_config.revert_to_default()
    return get_interview_prompt()


# ── Question banks — save a generated generic kit as a reusable bank ──────────
# A recruiter generates questions with "avoid personalization" on (a cohort/
# placement-drive set), then saves the kit here under an auto-suggested
# classic-legend name. Phase 2 allocates a bank to a candidate's interview round.

def _count_questions(buckets: list[dict]) -> int:
    return sum(len(b.get("questions") or []) for b in (buckets or []))


# ── Roman-numeral versioning for duplicated banks ────────────────────────────
_ROMAN_UNITS = [(1000, "M"), (900, "CM"), (500, "D"), (400, "CD"), (100, "C"),
                (90, "XC"), (50, "L"), (40, "XL"), (10, "X"), (9, "IX"),
                (5, "V"), (4, "IV"), (1, "I")]
_ROMAN_VALUE = {"I": 1, "V": 5, "X": 10, "L": 50, "C": 100, "D": 500, "M": 1000}
_VER_RE = re.compile(r"^(.*?)\s+([IVXLCDM]+)$")


def _to_roman(n: int) -> str:
    out = ""
    for value, sym in _ROMAN_UNITS:
        while n >= value:
            out += sym
            n -= value
    return out


def _roman_to_int(s: str) -> int:
    total, prev = 0, 0
    for ch in reversed(s.upper()):
        v = _ROMAN_VALUE.get(ch, 0)
        total += -v if v < prev else v
        prev = max(prev, v)
    return total


def _next_versioned_name(name: str, existing: set[str]) -> str:
    """Next Roman-numeral version of ``name`` — e.g. "Michael Jackson - Thriller"
    → " II", then "III". Duplicating an already-versioned name keeps the same
    root and bumps to the next free number."""
    m = _VER_RE.match(name.strip())
    root = m.group(1).strip() if m else name.strip()
    highest = 1  # the bare root counts as version 1
    for e in existing:
        e = e.strip()
        if e == root:
            highest = max(highest, 1)
            continue
        em = _VER_RE.match(e)
        if em and em.group(1).strip() == root:
            highest = max(highest, _roman_to_int(em.group(2)))
    return f"{root} {_to_roman(highest + 1)}"


# ── Sample question banks seeded on a fresh deployment (idempotent) ───────────
# Deletable like any other bank; a marker file stops them coming back after
# deletion. They double as templates — "Duplicate" makes a versioned copy.
_SEED_FLAG = Path(os.environ.get("QB_SEED_FLAG", "secrets/qb_seeded.flag"))
# The standard, profile-grounded sections. Seed banks are pure APTITUDE sets, so
# these are excluded by default on them (unchecked in Customize) — the operator
# can re-include any if they want, but the seeds ship aptitude-only.
_STANDARD_SECTIONS = [
    "Fundamentals", "Projects", "Problem Solving", "Role Fit",
    "Debugging & Troubleshooting", "Behavioral & Ownership", "Advanced Follow-up",
]
_SEED_SPECS = [
    {"name": "Michael Jackson - Thriller", "difficulty": "Hard", "stream": "GenAI",
     "modes": ["sql_aptitude", "analytical_reasoning", "logical_reasoning"]},
    {"name": "Quentin Tarantino - Pulp Fiction", "difficulty": "Hard", "stream": "Data Eng",
     "modes": ["dsa_aptitude", "prompt_writing", "data_eng_dwh_aptitude"]},
    {"name": "Charlie Chaplin - The Kid", "difficulty": "Medium", "stream": "GenAI",
     "modes": ["python_libraries_aptitude", "operations_research", "logical_reasoning"]},
]


def _create_seed_bank(spec: dict) -> bool:
    """Create one sample bank from the deterministic offline mode content if a
    bank with its name doesn't already exist. Returns True when created."""
    if repo().question_bank_name_exists(spec["name"]):
        return False
    buckets = []
    for mode in spec["modes"]:
        bucket = _mode_bucket(mode, spec["difficulty"])
        if bucket and bucket.get("questions"):
            buckets.append(bucket)
    if not buckets:
        return False
    buckets = _normalize_buckets(buckets)
    # Seed content is static (strong_answer only) — AI-add hints/rubric/explanation
    # so seeds ship with the SAME full structure as generated banks. Best-effort:
    # if the LLM is unavailable at seed time, the bank still saves and can be
    # enriched later (Settings → Legacy Features → Enrich).
    try:
        _enrich_buckets(buckets)
    except Exception as exc:  # noqa: BLE001 — never let enrichment block seeding
        logger.warning("seed bank enrich skipped for %s: %s", spec["name"], exc)
    repo().create_question_bank({
        "name": spec["name"],
        "stream": spec["stream"],
        "difficulty": spec["difficulty"],
        "modes": spec["modes"],
        "question_count": _count_questions(buckets),
        "buckets": buckets,
        "summary": {"name": spec["name"], "stream": spec["stream"],
                    "difficulty": spec["difficulty"], "experience_type": "Sample"},
        # Seed banks are aptitude-only — pre-exclude the standard sections so
        # Customize opens with them unchecked. Restored verbatim by Customize.
        "options": {
            "modes": spec["modes"],
            "difficulty": spec["difficulty"],
            "avoid_personalization": True,
            "exclude_sections": list(_STANDARD_SECTIONS),
        },
        "sources": [],
        "created_by": "sample",
        "status": "active",
    })
    return True


def seed_sample_question_banks() -> None:
    """Create the sample banks once per deployment (no LLM call). Skips silently
    if already seeded or on any error — never blocks startup."""
    if _SEED_FLAG.exists():
        return
    try:
        for spec in _SEED_SPECS:
            _create_seed_bank(spec)
        _SEED_FLAG.parent.mkdir(parents=True, exist_ok=True)
        _SEED_FLAG.write_text("1", encoding="utf-8")
    except Exception as exc:  # noqa: BLE001 — seeding is best-effort
        logger.warning("seed_sample_question_banks failed: %s", exc)


def ai_mark_responses(
    items: list[dict], max_mark: int = 10, candidate_id: Optional[str] = None
) -> list[dict]:
    """AI-suggest an integer 0..max_mark score per (question, ideal_answer,
    response). Returns ``[{index, mark, max, rationale}]``. Degrades to an empty
    list on any failure so the interviewer can always mark manually."""
    scored = [it for it in items if (it.get("response") or "").strip()]
    if not scored:
        return []
    try:
        from app.extraction.engine import (
            _azure_config,
            _chat_json,
            _resolve_master_deployment,
        )

        client, default_deployment = _azure_config(module="interview_questions")
        deployment = _resolve_master_deployment(default_deployment, module="interview_questions")
        payload = {
            "max_mark": max_mark,
            "items": [
                {
                    "index": it.get("index"),
                    "question": it.get("question"),
                    "ideal_answer": it.get("ideal_answer"),
                    "response": (it.get("response") or "").strip(),
                }
                for it in scored
            ],
        }
        system = (
            "You are a fair, consistent interview grader. For EACH item compare the "
            "candidate's response to the ideal answer and assign an INTEGER mark from 0 "
            "to max_mark (0 = blank/irrelevant/incorrect, max_mark = fully correct and "
            "complete). Judge substance, not length. Grade every candidate to the same "
            "bar. Return JSON ONLY in the form: "
            '{"marks":[{"index":<int>,"mark":<int>,"rationale":"<one short sentence>"}]}'
        )
        result, _usage = _chat_json(
            client=client,
            deployment=deployment,
            system_prompt=system,
            user_payload=payload,
            temperature=0,
            candidate_id=candidate_id,
            module="interview_questions",
        )
        raw = result.get("marks") if isinstance(result, dict) else None
        out: list[dict] = []
        for m in raw or []:
            try:
                idx = int(m.get("index"))
                mk = max(0, min(max_mark, int(round(float(m.get("mark"))))))
            except (TypeError, ValueError):
                continue
            out.append({"index": idx, "mark": mk, "max": max_mark,
                        "rationale": str(m.get("rationale") or "")})
        return out
    except Exception as exc:  # noqa: BLE001 — marking is best-effort
        logger.warning("ai_mark_responses failed: %s", exc)
        return []


def _llm_enrich(items: list[dict]) -> dict[int, dict]:
    """LLM-backfill hints + rubric (answer_points) + explanation for questions that
    lack them (older banks). Returns {index: {hints, answer_points, explanation}}."""
    if not items:
        return {}
    try:
        from app.extraction.engine import _azure_config, _chat_json, _resolve_master_deployment

        client, dd = _azure_config(module="interview_questions")
        deployment = _resolve_master_deployment(dd, module="interview_questions")
        payload = {"items": [
            {"index": it["index"], "question": it["question"], "strong_answer": it.get("strong_answer", "")}
            for it in items
        ]}
        system = (
            "For EACH interview question, produce interviewer marking aids. Return JSON ONLY: "
            '{"items":[{"index":<int>,"hints":["1-3 short interviewer cues"],'
            '"answer_points":[{"point":"a credit-bearing thing a good answer covers","marks":<int>}],'
            '"explanation":"a fuller correct-answer writeup"}]}. '
            "answer_points is a scoring rubric: 2-4 points whose marks are positive integers that SUM TO 10."
        )
        result, _usage = _chat_json(
            client=client, deployment=deployment, system_prompt=system,
            user_payload=payload, temperature=0, module="interview_questions",
        )
        out: dict[int, dict] = {}
        for m in (result.get("items") if isinstance(result, dict) else []) or []:
            try:
                idx = int(m.get("index"))
            except (TypeError, ValueError):
                continue
            out[idx] = {
                "hints": m.get("hints") or [],
                "answer_points": m.get("answer_points") or [],
                "explanation": m.get("explanation") or "",
            }
        return out
    except Exception as exc:  # noqa: BLE001 — enrich is best-effort
        logger.warning("enrich LLM failed: %s", exc)
        return {}


def _enrich_buckets(buckets: list) -> int:
    """Fill hints + rubric (answer_points) + explanation IN PLACE for every question
    in ``buckets`` that lacks a rubric. Returns how many were enriched. Best-effort:
    if the LLM is unavailable, nothing changes and it returns 0."""
    todo: list[tuple[int, int, int]] = []   # (global_index, bucket_i, q_i)
    items: list[dict] = []
    gidx = 0
    for bi, b in enumerate(buckets):
        for qi, q in enumerate(b.get("questions") or []):
            if not q.get("answer_points"):
                todo.append((gidx, bi, qi))
                items.append({"index": gidx, "question": q.get("question", ""),
                              "strong_answer": q.get("strong_answer", "")})
            gidx += 1
    if not items:
        return 0
    enriched = _llm_enrich(items)
    count = 0
    for gi, bi, qi in todo:
        e = enriched.get(gi)
        if not e:
            continue
        q = buckets[bi]["questions"][qi]
        q["hints"] = e["hints"]
        q["answer_points"] = e["answer_points"]
        q["explanation"] = e["explanation"]
        count += 1
    return count


@router.post("/question-banks/{qb_id}/enrich", summary="AI-backfill hints + rubric + explanation for a bank's questions")
def enrich_question_bank(qb_id: int, _user: AuthUser = Depends(get_current_user)) -> dict:
    """Fill in hints / rubric / explanation for any question in an existing bank
    that lacks them — so older (pre-rubric) banks become markable with the gated
    lock/reveal flow. Only touches questions missing a rubric; others are left as-is."""
    bank = repo().get_question_bank(qb_id)
    if not bank:
        raise HTTPException(status_code=404, detail="Question bank not found.")
    buckets = bank.get("buckets") or []
    count = _enrich_buckets(buckets)
    if count == 0:
        return {"enriched": 0, "bank": bank}
    buckets = _normalize_buckets(buckets)
    updated = repo().update_question_bank_buckets(qb_id, buckets, _count_questions(buckets))
    return {"enriched": count, "bank": updated or bank}


@router.get("/question-banks/suggest-name", summary="A classic-legend name fitted to the bank's character")
def suggest_question_bank_name(
    difficulty: Optional[str] = None,
    stream: Optional[str] = None,
    modes: Optional[str] = None,  # comma-separated mode keys
    _user: AuthUser = Depends(get_current_user),
) -> dict:
    from app.services import legend_names
    existing = {qb.get("name", "") for qb in repo().list_question_banks(include_archived=True)}
    mode_keys = [m for m in (modes or "").split(",") if m.strip()]
    return {
        "name": legend_names.suggest(
            existing, difficulty=difficulty, stream=stream, modes=mode_keys or None
        )
    }


class QuestionBankIn(BaseModel):
    name: str
    stream: Optional[str] = None
    difficulty: Optional[str] = None
    modes: list[str] = []
    buckets: list[dict] = []
    summary: Optional[dict] = None
    sources: list[dict] = []
    # Full generation options (composition mix, total, excludes, effort, focus)
    # so "Customize" can restore the exact settings this bank was built with.
    options: Optional[dict] = None


@router.get("/question-banks", summary="Saved question banks")
def list_question_banks(
    include_archived: bool = False,
    _user: AuthUser = Depends(get_current_user),
) -> list[dict]:
    return repo().list_question_banks(include_archived=include_archived)


@router.post("/question-banks", status_code=201, summary="Save a generated kit as a reusable question bank")
def create_question_bank(body: QuestionBankIn, user: AuthUser = Depends(get_current_user)) -> dict:
    name = (body.name or "").strip()
    if not name:
        raise HTTPException(status_code=400, detail="A question bank needs a name.")
    if not body.buckets or _count_questions(body.buckets) == 0:
        raise HTTPException(status_code=400, detail="A question bank needs at least one question.")
    if repo().question_bank_name_exists(name):
        raise HTTPException(status_code=409, detail=f"A question bank named “{name}” already exists.")
    return repo().create_question_bank({
        "name": name,
        "stream": body.stream,
        "difficulty": body.difficulty,
        "modes": body.modes or [],
        "question_count": _count_questions(body.buckets),
        "buckets": body.buckets,
        "summary": body.summary,
        "sources": body.sources or [],
        "options": body.options or {},
        "created_by": user.email,
        "status": "active",
    })


@router.post("/question-banks/{qb_id}/duplicate", status_code=201, summary="Duplicate a bank as the next Roman-numeral version")
def duplicate_question_bank(qb_id: int, user: AuthUser = Depends(get_current_user)) -> dict:
    bank = repo().get_question_bank(qb_id)
    if not bank:
        raise HTTPException(status_code=404, detail="Question bank not found.")
    existing = {qb.get("name", "") for qb in repo().list_question_banks(include_archived=True)}
    new_name = _next_versioned_name(bank["name"], existing)
    return repo().create_question_bank({
        "name": new_name,
        "stream": bank.get("stream"),
        "difficulty": bank.get("difficulty"),
        "modes": bank.get("modes") or [],
        "question_count": bank.get("question_count") or _count_questions(bank.get("buckets") or []),
        "buckets": bank.get("buckets") or [],
        "summary": bank.get("summary"),
        "sources": bank.get("sources") or [],
        "options": bank.get("options") or {},
        "created_by": user.email,
        "status": "active",
    })


class DiscardLeaderboardIn(BaseModel):
    password: str = ""


@router.post("/question-banks/{qb_id}/discard-leaderboard",
             summary="Clear a bank's leaderboard (assignments + responses) — irreversible")
def discard_leaderboard(qb_id: int, body: DiscardLeaderboardIn,
                        user: AuthUser = Depends(get_current_user)) -> dict:
    """Clear & discard a bank's leaderboard: delete every allocation + recorded
    response for this bank. NOT restorable — export the leaderboard first. Requires
    the caller's own password."""
    bank = repo().get_question_bank(qb_id)
    if not bank:
        raise HTTPException(status_code=404, detail="Question bank not found.")
    from app.services import users as user_store
    if not user_store.authenticate(user.email, body.password or ""):
        raise HTTPException(status_code=403, detail="Your password is incorrect.")
    discarded = repo().discard_allocations(qb_id)
    return {"discarded": discarded}


@router.delete(
    "/question-banks/{qb_id}/allocations/{allocation_id}",
    summary="Remove one candidate's assignment from this bank's leaderboard (soft — the record is kept, marked removed)",
)
def remove_bank_allocation(
    qb_id: int, allocation_id: int, user: AuthUser = Depends(get_current_user)
) -> dict:
    removed = repo().remove_allocation(qb_id, allocation_id, removed_by=user.email)
    if not removed:
        raise HTTPException(status_code=404, detail="Allocation not found on this bank (or already removed).")
    return {"removed": True}


class DeleteBankIn(BaseModel):
    sysadmin_email: Optional[str] = None
    sysadmin_password: Optional[str] = None
    user_password: Optional[str] = None


@router.delete("/question-banks/{qb_id}", summary="Delete a question bank")
def delete_question_bank(qb_id: int, body: Optional[DeleteBankIn] = None,
                         user: AuthUser = Depends(get_current_user)) -> dict:
    body = body or DeleteBankIn()
    bank = repo().get_question_bank(qb_id)
    if not bank:
        raise HTTPException(status_code=404, detail="Question bank not found.")
    # A live leaderboard blocks deletion outright — discard it first.
    active = repo().list_allocations_for_qb(qb_id)
    if active:
        raise HTTPException(
            status_code=409,
            detail=f"This bank is assigned to {len(active)} candidate(s) and its leaderboard is "
                   "active — discard the leaderboard first.",
        )
    # A bank that EVER had a leaderboard (even if now discarded) requires the
    # heightened, non-restorable confirmation: a sysadmin's credentials AND the
    # logged-in user's own password.
    if bank.get("had_allocations"):
        from app.services import users as user_store
        if not (body.sysadmin_email and body.sysadmin_password and body.user_password):
            raise HTTPException(
                status_code=403,
                detail="This bank had an active leaderboard — deleting it requires a sysadmin "
                       "password and your own password.",
            )
        sa = user_store.authenticate(body.sysadmin_email.strip(), body.sysadmin_password or "")
        if not sa or sa.get("role") != "sysadmin":
            raise HTTPException(status_code=403, detail="Sysadmin email/password is invalid.")
        if not user_store.authenticate(user.email, body.user_password or ""):
            raise HTTPException(status_code=403, detail="Your password is incorrect.")
    if not repo().delete_question_bank(qb_id):
        raise HTTPException(status_code=404, detail="Question bank not found.")
    return {"deleted": True}


@router.post("/question-banks/reseed", summary="Restore the default sample question banks")
def reseed_question_banks(_user: AuthUser = Depends(get_current_user)) -> dict:
    restored = sum(1 for spec in _SEED_SPECS if _create_seed_bank(spec))
    try:
        _SEED_FLAG.parent.mkdir(parents=True, exist_ok=True)
        _SEED_FLAG.write_text("1", encoding="utf-8")
    except OSError:
        pass
    return {"restored": restored, "samples": [s["name"] for s in _SEED_SPECS]}


@router.get("/question-banks/next-version", summary="The next Roman-numeral version name for a base bank name")
def question_bank_next_version(base: str, _user: AuthUser = Depends(get_current_user)) -> dict:
    existing = {qb.get("name", "") for qb in repo().list_question_banks(include_archived=True)}
    return {"name": _next_versioned_name(base, existing)}


class GeneralKitRequest(InterviewRequest):
    # A candidate-less "general" kit for building a question bank from the
    # Question Banks page. Always generic (avoid_personalization forced on).
    stream: Optional[str] = None
    difficulty: Optional[str] = None  # base difficulty; difficulty_bias still applies


@router.post("/question-banks/generate-general", summary="Generate a generic (candidate-less) kit for a new question bank")
def generate_general_kit(
    body: GeneralKitRequest | None = None, _user: AuthUser = Depends(get_current_user)
) -> dict:
    body = body or GeneralKitRequest()
    stream = (body.stream or "").strip() or "software engineering"
    order = ["Easy", "Medium", "Hard", "Very Hard"]
    idx = order.index(body.difficulty) if body.difficulty in order else 1  # default Medium
    if body.difficulty_bias == "easier":
        idx = max(0, idx - 1)
    elif body.difficulty_bias == "harder":
        idx = min(len(order) - 1, idx + 1)
    difficulty = order[idx]

    ctx = {
        "candidate_id": "general", "name": "General set", "stream": stream, "domain": stream,
        "atsscore": 0, "priority": None, "fresher_or_lateral": None, "yearofexp": None,
        "total_companieswitched": None, "careergap": None, "currentcompany": None,
        "projects": [], "primary_skills": [], "job_roles": [], "evidence_snippets": [],
        "recommendation": None, "analysis": None,
    }
    exp_type = "Cohort"

    _names = _mode_names()
    modes = [m for m in (body.modes or []) if m in _names]
    mode_bucket_names = [_names[m] for m in modes]
    valid_sections = {
        "Fundamentals", "Projects", "Problem Solving", "Role Fit",
        "Debugging & Troubleshooting", "Behavioral & Ownership", "Advanced Follow-up",
        *mode_bucket_names,
    }
    mode_weights = {
        k: max(1, min(10, int(v)))
        for k, v in (body.mode_weights or {}).items()
        if k in valid_sections and isinstance(v, (int, float)) and v
    } or None
    exclude_sections = [s for s in (body.exclude_sections or []) if s in valid_sections] or None
    total_questions = None
    if body.total_questions is not None:
        try:
            total_questions = max(3, min(40, int(body.total_questions)))
        except (TypeError, ValueError):
            total_questions = None

    web_reference, sources = ([], [])
    if body.search_web and modes:
        web_reference, sources = _web_reference(modes)

    result = _llm_generate(
        ctx, difficulty, body.focus, body.variant, mode_bucket_names, body.effort,
        mode_weights=mode_weights, web_reference=web_reference or None,
        avoid_personalization=True, total_questions=total_questions, exclude_sections=exclude_sections,
        section_levels=body.section_levels,
    )
    if result is None:
        result = _fallback(
            ctx, difficulty, exp_type, body.focus, body.variant, modes, body.effort,
            avoid_personalization=True, total_questions=total_questions, exclude_sections=exclude_sections,
        )
    else:
        result["summary"]["experience_type"] = exp_type
        result["generated_by"] = "llm"
    result["summary"]["name"] = "General set"
    result["summary"]["stream"] = stream
    result["sources"] = sources
    return result


# ── Question bank allocation (assign a bank to a candidate's interview) ───────
# Done while reviewing/sending the slot-invite email (or in bulk from the
# Question Banks page). The questions are never shown to the candidate — only to
# the interviewer for that round.

def _alloc_with_bank(alloc: Optional[dict]) -> Optional[dict]:
    if not alloc:
        return None
    bank = repo().get_question_bank(alloc["qb_id"])
    return {
        **alloc,
        "bank_name": bank["name"] if bank else None,
        "question_count": bank["question_count"] if bank else 0,
    }


class QuestionBankAllocationIn(BaseModel):
    qb_id: int
    round_id: Optional[int] = None
    round_name: Optional[str] = None
    interviewer: Optional[str] = None
    source_tag: Optional[str] = None


@router.get(
    "/candidates/{candidate_id}/question-bank-allocation",
    summary="The question bank (if any) allocated to this candidate's interview",
)
def get_candidate_question_bank(
    candidate_id: str,
    round_id: Optional[int] = None,
    _user: AuthUser = Depends(get_current_user),
) -> dict:
    alloc = repo().get_candidate_allocation(candidate_id, round_id)
    return {"allocation": _alloc_with_bank(alloc)}


@router.put(
    "/candidates/{candidate_id}/question-bank-allocation",
    summary="Assign a question bank to this candidate's interview round",
)
def allocate_candidate_question_bank(
    candidate_id: str,
    body: QuestionBankAllocationIn,
    user: AuthUser = Depends(get_current_user),
) -> dict:
    bank = repo().get_question_bank(body.qb_id)
    if not bank:
        raise HTTPException(status_code=404, detail="Question bank not found.")
    alloc = repo().allocate_question_bank({
        "qb_id": body.qb_id,
        "candidate_id": candidate_id,
        "round_id": body.round_id,
        "round_name": body.round_name,
        "interviewer": body.interviewer,
        "status": "assigned",
        "source_tag": body.source_tag,
        "assigned_by": user.email,
    })
    return {"allocation": _alloc_with_bank(alloc)}


@router.delete(
    "/candidates/{candidate_id}/question-bank-allocation",
    summary="Remove the question bank assigned to this candidate's interview",
)
def deallocate_candidate_question_bank(
    candidate_id: str,
    round_id: Optional[int] = None,
    _user: AuthUser = Depends(get_current_user),
) -> dict:
    repo().deallocate_question_bank(candidate_id, round_id)
    return {"allocation": None}


# ── Bulk allocation by source tag + leaderboard + export ─────────────────────

@router.get("/question-banks/{qb_id}/candidates", summary="Candidates under a source tag, for bulk-assigning this bank")
def question_bank_candidates(
    qb_id: int,
    source_tag: Optional[str] = None,
    round_names: Optional[str] = None,
    _user: AuthUser = Depends(get_current_user),
) -> dict:
    rounds = [r for r in (round_names or "").split(",") if r] or None
    cands = repo().candidates_by_source(source_tag, rounds)
    out = []
    for c in cands:
        alloc = repo().get_candidate_allocation(c["candidate_id"])
        out.append({
            "candidate_id": c["candidate_id"],
            "name": c.get("name"),
            "assigned_qb_id": alloc.get("qb_id") if alloc else None,
            "assigned_to_this": bool(alloc and alloc.get("qb_id") == qb_id),
        })
    return {"candidates": out}


@router.get(
    "/question-banks-allocation-summary",
    summary="Per-bank allocation counts by stage, cohort/round scope, and average score",
)
def question_banks_allocation_summary(_user: AuthUser = Depends(get_current_user)) -> dict:
    out: dict[str, dict] = {}

    def entry(qb_id) -> dict:
        return out.setdefault(str(qb_id), {
            "assigned": 0, "in_progress": 0, "scored": 0, "collected": 0, "total": 0,
            "scope": [], "avg_score_pct": None,
        })

    for row in repo().allocation_summary():
        e = entry(row["qb_id"])
        status = row.get("status") or "assigned"
        e[status] = e.get(status, 0) + int(row["n"])
        # "removed" candidates keep their soft-deleted row but don't count toward
        # the active cohort total (unblocks bank deletion once everyone's removed).
        if status != "removed":
            e["total"] += int(row["n"])
    for row in repo().allocation_scope_summary():
        entry(row["qb_id"])["scope"].append({
            "source_tag": row.get("source_tag"),
            "round_name": row.get("round_name"),
            "n": int(row["n"]),
        })
    for row in repo().allocation_score_summary():
        pct = row.get("avg_score_pct")
        entry(row["qb_id"])["avg_score_pct"] = round(float(pct), 1) if pct is not None else None
    return {"summary": out}


class BulkAllocateIn(BaseModel):
    source_tag: Optional[str] = None
    candidate_ids: Optional[list[str]] = None  # explicit subset; else every candidate under the tag
    # Optional round filter — when set, only candidates CURRENTLY in one of
    # these rounds get the bank; each allocation is stamped with that
    # candidate's own round (not a fixed value).
    round_names: Optional[list[str]] = None


@router.post("/question-banks/{qb_id}/bulk-allocate", summary="Assign this bank to a cohort (a source tag, or a chosen subset), optionally scoped to specific interview rounds")
def bulk_allocate_question_bank(
    qb_id: int, body: BulkAllocateIn, user: AuthUser = Depends(get_current_user)
) -> dict:
    bank = repo().get_question_bank(qb_id)
    if not bank:
        raise HTTPException(status_code=404, detail="Question bank not found.")
    if body.candidate_ids:
        round_by_id = repo().candidates_rounds(body.candidate_ids)
        ids = body.candidate_ids
    else:
        cands = repo().candidates_by_source(body.source_tag, body.round_names)
        round_by_id = {c["candidate_id"]: c.get("roundname") for c in cands}
        ids = [c["candidate_id"] for c in cands]
    if body.round_names:
        ids = [cid for cid in ids if round_by_id.get(cid) in body.round_names]
    allocated = 0
    for cid in ids:
        repo().allocate_question_bank({
            "qb_id": qb_id,
            "candidate_id": cid,
            "round_id": None,
            "round_name": round_by_id.get(cid),
            "status": "assigned",
            "source_tag": body.source_tag,
            "assigned_by": user.email,
        })
        allocated += 1
    return {"allocated": allocated}


def _response_mark(r: dict) -> float:
    m = r.get("final_mark")
    if m is None:
        m = r.get("ai_mark")
    try:
        return float(m) if m is not None else 0.0
    except (TypeError, ValueError):
        return 0.0


def _iso(v: Any) -> Optional[str]:
    return v.isoformat() if hasattr(v, "isoformat") else v


def _leaderboard_rows(qb_id: int) -> list[dict]:
    rows = []
    for a in repo().list_allocations_for_qb(qb_id):
        cand = repo().get_candidate(a["candidate_id"]) or {}
        responses = repo().list_responses(a["allocation_id"])
        rnd = None
        if a.get("round_id"):
            rnd = next(
                (r for r in repo().list_rounds(a["candidate_id"]) if r.get("round_id") == a["round_id"]),
                None,
            )
        booked = repo().booked_pool_slot_for_round(a.get("round_id"))
        total = sum(_response_mark(r) for r in responses)
        max_total = sum(float(r.get("max_mark") or 10) for r in responses)
        interviewer = (
            a.get("interviewer")
            or (rnd.get("interviewer") if rnd else None)
            or (booked.get("interviewer_name") or booked.get("interviewer_email") if booked else None)
        )
        rows.append({
            "allocation_id": a["allocation_id"],
            "candidate_id": a["candidate_id"],
            "candidate_name": cand.get("name") or a["candidate_id"],
            "status": a.get("status"),
            "round_name": a.get("round_name") or (rnd.get("round_name") if rnd else None),
            "interviewer": interviewer,
            "slot_start": _iso(
                a.get("slot_start")
                or (booked.get("slot_start") if booked else None)
                or (rnd.get("scheduled_on") if rnd else None)
            ),
            "slot_end": _iso(a.get("slot_end") or (booked.get("slot_end") if booked else None)),
            "questions_total": len(responses),
            "answered": sum(1 for r in responses if (r.get("response_text") or "").strip()),
            "total_mark": round(total, 2),
            "max_mark": round(max_total, 2),
            "scored": a.get("status") == "scored",
            "removed_at": _iso(a.get("removed_at")),
            "removed_by": a.get("removed_by"),
        })
    # Scored candidates ranked by total desc; unscored/collecting fall below;
    # removed candidates always sink to the bottom regardless of any marks.
    rows.sort(
        key=lambda r: (0 if r["status"] == "removed" else 2 if r["scored"] else 1, r["total_mark"]),
        reverse=True,
    )
    rank = 0
    for r in rows:
        if r["scored"] and r["status"] != "removed":
            rank += 1
            r["rank"] = rank
        else:
            r["rank"] = None
    return rows


@router.get("/question-banks/{qb_id}/leaderboard", summary="Ranking of candidates assigned this bank, by marks")
def question_bank_leaderboard(qb_id: int, _user: AuthUser = Depends(get_current_user)) -> dict:
    bank = repo().get_question_bank(qb_id)
    if not bank:
        raise HTTPException(status_code=404, detail="Question bank not found.")
    rows = _leaderboard_rows(qb_id)
    # "total" reflects the ACTIVE cohort only — removed candidates keep their row
    # (for the record) but don't count toward it.
    summary = {
        "total": sum(1 for r in rows if r["status"] != "removed"),
        "assigned": sum(1 for r in rows if r["status"] == "assigned"),
        "in_progress": sum(1 for r in rows if r["status"] == "in_progress"),
        "scored": sum(1 for r in rows if r["status"] == "scored"),
        "removed": sum(1 for r in rows if r["status"] == "removed"),
    }
    return {
        "bank": {"qb_id": bank["qb_id"], "name": bank["name"], "question_count": bank["question_count"]},
        "summary": summary,
        "rows": rows,
    }


@router.get(
    "/question-banks/{qb_id}/allocations/{allocation_id}/responses",
    summary="Full interview response sheet for one candidate's allocated bank",
)
def question_bank_allocation_responses(
    qb_id: int, allocation_id: int, _user: AuthUser = Depends(get_current_user)
) -> dict:
    """The recruiter-facing drill-down behind the leaderboard's (i): EVERY
    question in the bank paired with the candidate's response + marks, plus the
    model answer/rubric/explanation. Works for a partial interview (unanswered
    questions come back blank) as well as a completed one. Recruiter owns the
    bank, so nothing is gated here (unlike the interviewer's live view)."""
    alloc = repo().get_allocation(allocation_id)
    if not alloc or alloc.get("qb_id") != qb_id:
        raise HTTPException(status_code=404, detail="Allocation not found for this bank.")
    bank = repo().get_question_bank(qb_id)
    if not bank:
        raise HTTPException(status_code=404, detail="Question bank not found.")

    cand = repo().get_candidate(alloc["candidate_id"]) or {}
    responses = repo().list_responses(allocation_id)
    resp_by_index = {r["question_index"]: r for r in responses}

    items: list[dict] = []
    idx = 0
    for b in (bank.get("buckets") or []):
        for q in (b.get("questions") or []):
            r = resp_by_index.get(idx) or {}
            pts = q.get("answer_points") or []
            items.append({
                "index": idx,
                "bucket": b.get("name") or "",
                "question": q.get("question") or "",
                "why": q.get("why") or "",
                "difficulty": q.get("difficulty") or "Medium",
                "hints": q.get("hints") or [],
                "strong_answer": q.get("strong_answer") or "",
                "answer_points": pts,
                "explanation": q.get("explanation") or "",
                "response_text": r.get("response_text") or "",
                "observation": r.get("observation") or "",
                "ai_mark": r.get("ai_mark"),
                "ai_rationale": r.get("ai_rationale") or "",
                "final_mark": r.get("final_mark"),
                "awarded_points": r.get("awarded_points") or [],
                "max_mark": r.get("max_mark") or (sum(float(p.get("marks") or 0) for p in pts) or 10.0),
                "answered": bool((r.get("response_text") or "").strip()),
                "answer_locked": bool(r.get("answer_locked_at")),
                "mark_locked": bool(r.get("mark_locked_at")),
            })
            idx += 1

    rnd = None
    if alloc.get("round_id"):
        rnd = next(
            (r for r in repo().list_rounds(alloc["candidate_id"]) if r.get("round_id") == alloc["round_id"]),
            None,
        )
    booked = repo().booked_pool_slot_for_round(alloc.get("round_id"))
    total = sum(_response_mark(r) for r in responses)
    max_total = sum(float(r.get("max_mark") or 10) for r in responses)
    return {
        "allocation_id": allocation_id,
        "candidate_id": alloc["candidate_id"],
        "candidate_name": cand.get("name") or alloc["candidate_id"],
        "status": alloc.get("status"),
        "round_name": alloc.get("round_name") or (rnd.get("round_name") if rnd else None),
        "interviewer": (
            alloc.get("interviewer")
            or (rnd.get("interviewer") if rnd else None)
            or (booked.get("interviewer_name") or booked.get("interviewer_email") if booked else None)
        ),
        "slot_start": _iso(
            alloc.get("slot_start")
            or (booked.get("slot_start") if booked else None)
            or (rnd.get("scheduled_on") if rnd else None)
        ),
        "slot_end": _iso(alloc.get("slot_end") or (booked.get("slot_end") if booked else None)),
        "questions_total": len(items),
        "answered": sum(1 for it in items if it["answered"]),
        "total_mark": round(total, 2),
        "max_mark": round(max_total, 2),
        "items": items,
    }


@router.get("/question-banks/{qb_id}/leaderboard.xlsx", summary="Download the leaderboard as an Excel sheet")
def question_bank_leaderboard_xlsx(qb_id: int, _user: AuthUser = Depends(get_current_user)):
    from fastapi import Response
    from app.services.xlsx_export import XLSX_MEDIA_TYPE, Column, build_xlsx

    bank = repo().get_question_bank(qb_id)
    if not bank:
        raise HTTPException(status_code=404, detail="Question bank not found.")
    rows = _leaderboard_rows(qb_id)
    columns = [
        Column("rank", "Rank", "int"),
        Column("candidate_name", "Candidate", "text"),
        Column("candidate_id", "Candidate ID", "text"),
        Column("total_mark", "Total mark", "float"),
        Column("max_mark", "Out of", "float"),
        Column("answered", "Answered", "int"),
        Column("questions_total", "Questions", "int"),
        Column("status", "Status", "text"),
        Column("round_name", "Round", "text"),
        Column("interviewer", "Interviewer", "text"),
        Column("slot_start", "Interview slot", "datetime"),
    ]
    safe = "".join(ch if ch.isalnum() else "_" for ch in bank["name"])[:40] or "question_bank"
    content = build_xlsx(columns, rows, sheet_name="Leaderboard")
    return Response(
        content=content,
        media_type=XLSX_MEDIA_TYPE,
        headers={"Content-Disposition": f'attachment; filename="leaderboard_{safe}.xlsx"'},
    )
