"""Interviewer Access — a candidate-scoped, email-code-gated public surface.

No app_users account backs this: an external interviewer never logs into the
SPA at all. They open a signed link (``/interview/{token}``, minted from the
round a recruiter is managing — see ``POST /candidates/{id}/interview-link``
below, Admin/Recruiter only) that carries exactly one candidate id and,
usually, one round id (app.services.interviewer_link), prove they own an
allow-listed-domain email via a mailed one-time code
(app.services.interviewer_auth), and can then read that ONE candidate's
(deliberately narrow, read-only) profile — and, if the link names a round,
leave feedback + a Pass/Fail verdict for exactly that round. Every endpoint
here re-derives the candidate id (and round id) from the link token itself,
never from client input, so there is no way to widen access to a different
candidate/round by tampering with a request body.

Submitting a verdict does not duplicate the recruiter's rounds machinery — it
calls the exact same ``repo().update_round(...)`` the Screening page's round
drawer calls (see app.api.rounds.update_round), so stage auto-advance, the
candidate_master mirror, and the DB sync trigger all fire identically
regardless of who submitted it. The audit trail gets the same
``round_updated`` event the recruiter path writes, with the interviewer's
verified email folded into the summary text (there's no separate actor column
on audit_log — see app.services.audit).
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Literal, Optional

from fastapi import APIRouter, Depends, Header, HTTPException, Query, Response
from pydantic import BaseModel, EmailStr, Field

from app.api.auth import AuthUser, get_current_user
from app.api.interview import InterviewRequest, interview_questions
from app.logging_config import get_logger
from app.repositories import repo
from app.services import audit, interview_plan, interviewer_auth, interviewer_link, users
from app.services.s3 import s3
from app.stages import candidate_stage_bucket

log = get_logger(__name__)

router = APIRouter(prefix="/api/v1/interview", tags=["interviewer access"])
# Separate router (no "/interview" prefix) for the ONE endpoint in this file
# that isn't public — minting a link is a normal authenticated candidate
# action, so it belongs at /api/v1/candidates/{id}/... alongside the rest of
# the candidate-centric endpoints in app.api.rounds, not under /interview/.
admin_router = APIRouter(prefix="/api/v1", tags=["interviewer access"])

# Browser-renderable content types for the inline resume viewer (mirrors
# app.api.branches, kept local so this module has no reason to import a
# "private" symbol from another router).
_RESUME_CONTENT_TYPES = {
    ".pdf": "application/pdf",
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".doc": "application/msword",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".bmp": "image/bmp",
    ".tiff": "image/tiff",
}

# Fields an external interviewer is shown — deliberately a narrow, read-only
# subset: no contact info (email/phone), no internal workflow state (status,
# priority, NBA/next_action_override), no source/audit trail. Just what
# helps them run the interview.
_INTERVIEWER_FIELDS = [
    "candidate_id", "name", "stream", "fresher_or_lateral", "yearofexp",
    "currentcompany", "currentlocation", "clg", "highest_coursecompleted",
    "education_status", "passoutyr", "cgpa", "domain", "atsscore",
    "score_breakdown", "score_penalties", "certification_bonus",
    "analysis_report", "certificates", "primary_skills", "job_roles",
    "projects", "role_context", "s3_file_path",
    # The recruiter's remark is deliberately shared with the interviewer
    # (unlike the internal-only note); shown as a blue note by the name.
    "latest_remark",
]

# Round fields shown to an interviewer — excludes compensation (current/expected
# CTC, notice period, relocation) and the invite/reminder logistics columns,
# none of which are an interviewer's business; just enough to see what
# happened in past rounds and what's expected in the one they're running.
_INTERVIEWER_ROUND_FIELDS = [
    "round_id", "round_name", "domain", "interviewer", "scheduled_on",
    "feedback", "score", "outcome",
]


def _link_ctx_for(token: str) -> interviewer_link.LinkContext:
    ctx = interviewer_link.decode_link_token(token)
    if not ctx:
        raise HTTPException(status_code=404, detail="This interview link is invalid.")
    return ctx


def _candidate_payload(candidate_id: str) -> dict[str, Any]:
    row = repo().get_candidate(candidate_id)
    if not row:
        raise HTTPException(status_code=404, detail="Candidate not found.")
    from app.services.nlrs import enrich_with_nlrs
    enrich_with_nlrs(row)
    out = {k: row.get(k) for k in _INTERVIEWER_FIELDS}
    out["has_resume"] = bool(row.get("s3_file_path"))
    out.pop("s3_file_path", None)  # the raw storage key stays server-side; see /resume
    out["nlrs"] = row.get("nlrs")
    return out


def _rounds_payload(candidate_id: str) -> list[dict[str, Any]]:
    rounds = repo().list_rounds(candidate_id)
    return [{k: r.get(k) for k in _INTERVIEWER_ROUND_FIELDS} for r in rounds]


def _round_for(candidate_id: str, round_id: Optional[int]) -> Optional[dict[str, Any]]:
    """The specific round this link is scoped to, or None if the link is
    candidate-only (no round_id) or the round no longer exists / doesn't
    belong to this candidate (defense in depth — never trust the id alone)."""
    if round_id is None:
        return None
    for r in repo().list_rounds(candidate_id):
        if r.get("round_id") == round_id:
            return r
    return None


def _require_session(token: str, x_interviewer_session: str | None) -> str:
    email = interviewer_auth.validate_session(x_interviewer_session)
    if not email:
        raise HTTPException(status_code=401, detail="Verification required.")
    return email


class RequestCodeBody(BaseModel):
    email: EmailStr


class VerifyCodeBody(BaseModel):
    email: EmailStr
    code: str
    remember: bool = False


class VerifyCodeResponse(BaseModel):
    session_token: str | None
    candidate: dict[str, Any]
    round_id: Optional[int] = None
    rounds: list[dict[str, Any]] = Field(default_factory=list)


@router.post("/{token}/request-code")
def request_code(token: str, body: RequestCodeBody) -> dict[str, bool]:
    ctx = _link_ctx_for(token)
    try:
        interviewer_auth.request_code(str(body.email), ctx["candidate_id"])
    except interviewer_auth.DomainNotAllowed as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    return {"sent": True}


@router.post("/{token}/verify-code", response_model=VerifyCodeResponse)
def verify_code(token: str, body: VerifyCodeBody) -> VerifyCodeResponse:
    ctx = _link_ctx_for(token)
    try:
        session_token = interviewer_auth.verify_code(
            str(body.email), body.code, remember=body.remember
        )
    except interviewer_auth.InvalidCode as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return VerifyCodeResponse(
        session_token=session_token,
        candidate=_candidate_payload(ctx["candidate_id"]),
        round_id=ctx["round_id"],
        rounds=_rounds_payload(ctx["candidate_id"]),
    )


@router.get("/{token}/candidate")
def get_candidate(
    token: str, x_interviewer_session: str | None = Header(default=None)
) -> dict[str, Any]:
    """Re-entry with an already-remembered session — skips the code challenge."""
    ctx = _link_ctx_for(token)
    _require_session(token, x_interviewer_session)
    return {
        "candidate": _candidate_payload(ctx["candidate_id"]),
        "round_id": ctx["round_id"],
        "rounds": _rounds_payload(ctx["candidate_id"]),
    }


@router.get("/{token}/resume")
def get_resume(
    token: str, x_interviewer_session: str | None = Header(default=None)
) -> Response:
    ctx = _link_ctx_for(token)
    _require_session(token, x_interviewer_session)
    row = repo().get_candidate(ctx["candidate_id"])
    key = row.get("s3_file_path") if row else None
    if not key:
        raise HTTPException(status_code=404, detail="No resume on file for this candidate.")
    try:
        data = s3().get_bytes(key)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=404, detail=f"resume not found in storage: {exc}") from exc
    suffix = Path(key).suffix.lower()
    media_type = _RESUME_CONTENT_TYPES.get(suffix, "application/octet-stream")
    return Response(
        content=data,
        media_type=media_type,
        headers={"Content-Disposition": f'inline; filename="{Path(key).name}"'},
    )


# ── Interview questions — a small mandatory+optional checklist ──────────────
# Reuses the SAME kit-generation logic the recruiter's "Generate Interview
# Questions" panel uses (app.api.interview.interview_questions), just called
# as a plain function (not over HTTP) so there's no auth mismatch — then
# trims it down to a short, answerable-inline checklist: the first question
# of each of the first few buckets is marked mandatory, a couple more are
# offered as optional. Nothing here is persisted; it's regenerated per visit.
_MANDATORY_BUCKETS = 3
_OPTIONAL_BUCKETS = 2


class InterviewerQuestion(BaseModel):
    bucket: str
    question: str
    mandatory: bool


@router.get("/{token}/questions")
def get_questions(
    token: str, x_interviewer_session: str | None = Header(default=None)
) -> dict[str, Any]:
    ctx = _link_ctx_for(token)
    _require_session(token, x_interviewer_session)
    if ctx["round_id"] is None:
        raise HTTPException(status_code=404, detail="This link isn't linked to an interview round.")

    kit = interview_questions(ctx["candidate_id"], InterviewRequest())
    buckets = kit.get("buckets") or []
    out: list[InterviewerQuestion] = []
    for i, bucket in enumerate(buckets[: _MANDATORY_BUCKETS + _OPTIONAL_BUCKETS]):
        qs = bucket.get("questions") or []
        if not qs:
            continue
        out.append(InterviewerQuestion(
            bucket=bucket.get("name") or "General",
            question=qs[0]["question"],
            mandatory=i < _MANDATORY_BUCKETS,
        ))
    return {"questions": [q.model_dump() for q in out]}


# ── Full interview kit — the SAME rich generator the recruiter's "Generate
# Interview Questions" panel uses (regenerate, difficulty bias, focus, opt-in
# aptitude modes), just gated by the interviewer's session instead of a login.
# Candidate id is still always derived from the token, never the request body.
@router.post("/{token}/interview-questions")
def get_interview_kit(
    token: str,
    body: InterviewRequest | None = None,
    x_interviewer_session: str | None = Header(default=None),
) -> dict[str, Any]:
    ctx = _link_ctx_for(token)
    _require_session(token, x_interviewer_session)
    return interview_questions(ctx["candidate_id"], body or InterviewRequest())


# ── Allocated question bank — when a bank was assigned to this round, the
# interviewer uses ITS questions instead of generating a kit. Candidate id +
# round are always derived from the token, never the request.
def _flatten_bank(bank: dict) -> dict[int, dict]:
    """Flatten a bank's buckets into a stable global index → question map, with the
    rubric-derived max_mark (sum of answer_point marks, else 10)."""
    flat: dict[int, dict] = {}
    idx = 0
    for b in (bank.get("buckets") or []):
        for q in (b.get("questions") or []):
            pts = q.get("answer_points") or []
            flat[idx] = {
                "bucket": b.get("name") or "",
                "question": q.get("question") or "",
                "strong_answer": q.get("strong_answer") or "",
                "answer_points": pts,
                "explanation": q.get("explanation") or "",
                "max_mark": sum(float(p.get("marks") or 0) for p in pts) or 10.0,
            }
            idx += 1
    return flat


def _gated_qb_buckets(bank: dict, resp_by_index: dict[int, dict]) -> list[dict]:
    """Interviewer-facing buckets with PER-QUESTION reveal gating: each question's
    model answer + hints + rubric appear only after THAT question's answer is
    locked; its explanation only after THAT question's mark is locked. Question
    text/why/difficulty are always visible."""
    out: list[dict] = []
    idx = 0
    for b in (bank.get("buckets") or []):
        qs: list[dict] = []
        for q in (b.get("questions") or []):
            pts = q.get("answer_points") or []
            r = resp_by_index.get(idx) or {}
            answer_locked = bool(r.get("answer_locked_at"))
            mark_locked = bool(r.get("mark_locked_at"))
            item: dict[str, Any] = {
                "index": idx,
                "bucket": b.get("name") or "",
                "question": q.get("question") or "",
                "why": q.get("why") or "",
                "difficulty": q.get("difficulty") or "Medium",
                "follow_up": q.get("follow_up"),
                "max_mark": sum(float(p.get("marks") or 0) for p in pts) or 10.0,
                "answer_locked": answer_locked,
                "mark_locked": mark_locked,
                # Hints are an interviewer PROBING aid — available before locking
                # (behind a "Show hint" toggle). The model answer + rubric stay
                # gated until the response is locked (the anti-bias part).
                "hints": q.get("hints") or [],
            }
            if answer_locked:
                item["strong_answer"] = q.get("strong_answer") or ""
                item["answer_points"] = pts
            if mark_locked:
                item["explanation"] = q.get("explanation") or ""
            qs.append(item)
            idx += 1
        out.append({"name": b.get("name") or "", "questions": qs})
    return out


@router.get("/{token}/question-bank")
def get_allocated_question_bank(
    token: str, x_interviewer_session: str | None = Header(default=None)
) -> dict[str, Any]:
    ctx = _link_ctx_for(token)
    _require_session(token, x_interviewer_session)
    round_id = ctx["round_id"]
    alloc = repo().get_candidate_allocation(ctx["candidate_id"], round_id)
    if not alloc:
        return {"allocation": None, "buckets": []}
    bank = repo().get_question_bank(alloc["qb_id"])
    if not bank:
        return {"allocation": None, "buckets": []}
    # First open by the interviewer moves it from assigned -> in_progress, and
    # binds the (previously unbound, pre-assigned) allocation to this round.
    patch: dict[str, Any] = {}
    if alloc.get("status") == "assigned":
        patch["status"] = "in_progress"
    if alloc.get("round_id") is None and round_id is not None:
        row = _round_for(ctx["candidate_id"], round_id) or {}
        patch["round_id"] = round_id
        patch["round_name"] = row.get("round_name")
    if patch:
        try:
            alloc = repo().update_allocation(alloc["allocation_id"], patch) or alloc
        except Exception as exc:  # noqa: BLE001 — non-fatal
            log.warning("interviewer: binding QB alloc %s failed: %s", alloc.get("allocation_id"), exc)
    responses = repo().list_responses(alloc["allocation_id"])
    resp_by_index = {r["question_index"]: r for r in responses}
    return {
        "allocation": {
            "allocation_id": alloc["allocation_id"],
            "qb_id": alloc["qb_id"],
            "bank_name": bank["name"],
            "question_count": bank["question_count"],
            "status": alloc.get("status"),
        },
        "buckets": _gated_qb_buckets(bank, resp_by_index),
        "responses": responses,
    }


class QBMarkItem(BaseModel):
    index: int
    bucket: str = ""
    question: str
    ideal_answer: str = ""
    response: str = ""


class QBMarkBody(BaseModel):
    responses: list[QBMarkItem] = Field(default_factory=list)


@router.post("/{token}/question-bank/mark")
def mark_question_bank(
    token: str,
    body: QBMarkBody,
    x_interviewer_session: str | None = Header(default=None),
) -> dict[str, Any]:
    """AI-suggest a mark per recorded response (0..10). The interviewer can
    override any of these before submitting the verdict."""
    ctx = _link_ctx_for(token)
    _require_session(token, x_interviewer_session)
    from app.api.interview import ai_mark_responses

    items = [
        {"index": r.index, "question": r.question, "ideal_answer": r.ideal_answer, "response": r.response}
        for r in body.responses
    ]
    marks = ai_mark_responses(items, max_mark=10, candidate_id=ctx["candidate_id"])
    return {"marks": marks}


def _qb_alloc_for(token: str, allocation_id: int, session: str | None) -> dict:
    ctx = _link_ctx_for(token)
    _require_session(token, session)
    alloc = repo().get_allocation(allocation_id)
    if not alloc or str(alloc.get("candidate_id")) != str(ctx["candidate_id"]):
        raise HTTPException(status_code=404, detail="Allocation not found for this interview.")
    return alloc


def _qb_state(bank: dict, allocation_id: int) -> dict[str, Any]:
    """The re-gated buckets + saved responses after a per-question lock — the shape
    the UI merges back in so exactly the just-locked question updates."""
    responses = repo().list_responses(allocation_id)
    resp_by_index = {r["question_index"]: r for r in responses}
    return {"buckets": _gated_qb_buckets(bank, resp_by_index), "responses": responses}


class QBLockAnswerBody(BaseModel):
    allocation_id: int
    index: int
    bucket: str = ""
    question: str = ""
    response_text: str = ""
    observation: str = ""


@router.post("/{token}/question-bank/lock-answer")
def lock_qb_answer(
    token: str, body: QBLockAnswerBody, x_interviewer_session: str | None = Header(default=None)
) -> dict[str, Any]:
    """PER-QUESTION: freeze ONE question's response and reveal THAT question's model
    answer + hints + rubric. Idempotent-ish — re-locking updates the response."""
    from datetime import datetime, timezone

    alloc = _qb_alloc_for(token, body.allocation_id, x_interviewer_session)
    bank = repo().get_question_bank(alloc["qb_id"]) or {}
    f = _flatten_bank(bank).get(body.index, {})
    repo().lock_answer(
        body.allocation_id, body.index,
        body.bucket or f.get("bucket", ""), body.question or f.get("question", ""),
        body.response_text, body.observation, f.get("max_mark", 10),
        datetime.now(timezone.utc),
    )
    if alloc.get("status") == "assigned":
        repo().update_allocation(body.allocation_id, {"status": "in_progress"})
    return _qb_state(bank, body.allocation_id)


class QBLockMarkBody(BaseModel):
    allocation_id: int
    index: int
    final_mark: float | None = None
    awarded_points: list[int] = Field(default_factory=list)
    ai_mark: float | None = None
    ai_rationale: str = ""


@router.post("/{token}/question-bank/lock-mark")
def lock_qb_mark(
    token: str, body: QBLockMarkBody, x_interviewer_session: str | None = Header(default=None)
) -> dict[str, Any]:
    """PER-QUESTION: freeze ONE question's mark and reveal THAT question's
    explanation. Mark = explicit final_mark, else the sum of the ticked rubric
    points (clamped to the question's max). Requires the answer to be locked first.
    When every question is mark-locked, the allocation flips to 'scored'."""
    from datetime import datetime, timezone

    alloc = _qb_alloc_for(token, body.allocation_id, x_interviewer_session)
    bank = repo().get_question_bank(alloc["qb_id"]) or {}
    f = _flatten_bank(bank).get(body.index, {})
    pts = f.get("answer_points") or []
    maxm = float(f.get("max_mark", 10) or 10)
    awarded = [i for i in (body.awarded_points or []) if isinstance(i, int) and 0 <= i < len(pts)]
    fm = float(body.final_mark) if body.final_mark is not None else sum(float(pts[i].get("marks") or 0) for i in awarded)
    fm = max(0.0, min(maxm, fm))
    row = repo().lock_mark(
        body.allocation_id, body.index, fm, awarded, maxm,
        body.ai_mark, body.ai_rationale, datetime.now(timezone.utc),
    )
    if row is None:
        raise HTTPException(status_code=400, detail="Lock this question's answer first.")
    # All questions mark-locked → the allocation is fully scored.
    responses = repo().list_responses(body.allocation_id)
    if responses and len(responses) >= (bank.get("question_count") or 0) and all(r.get("mark_locked_at") for r in responses):
        repo().update_allocation(body.allocation_id, {"status": "scored"})
    return _qb_state(bank, body.allocation_id)


# ── Feedback + verdict submission — the one write this router allows ────────
# Converges on app.repositories.pg_repo.update_round(), the exact function
# app.api.rounds.update_round (the recruiter's PATCH /rounds/{id}) calls — so
# stage auto-advance and the candidate_master mirror behave identically no
# matter who submitted the verdict.

class QuestionAnswer(BaseModel):
    bucket: str
    question: str
    mandatory: bool
    answer: str = ""


class QBResponseIn(BaseModel):
    index: int
    bucket: str = ""
    question: str
    response_text: str = ""
    observation: str = ""
    ai_mark: Optional[float] = None
    ai_rationale: str = ""
    final_mark: Optional[float] = None
    max_mark: float = 10


class SubmitFeedbackBody(BaseModel):
    answers: list[QuestionAnswer] = Field(default_factory=list)
    overall_feedback: str = ""
    score: Optional[float] = Field(None, ge=0, le=10)
    outcome: Literal["Pass", "Fail"]
    # When this round used an allocated question bank: the allocation and the
    # per-question responses + marks to persist alongside the verdict.
    qb_allocation_id: Optional[int] = None
    qb_responses: Optional[list[QBResponseIn]] = None
    # Round 1 and later (never Screening, never sent with a plain reject) — which
    # stage a "Pass" advances to, when the round allows more than one target
    # (Round 2 -> Round 3 or Final). Validated server-side either way.
    advance_to: Optional[str] = None
    # Admin-only bypass, re-verified server-side against app_users (never
    # trusted from the client) — jump straight to Hired/Rejected from ANY
    # round, skipping whatever rounds remain.
    direct_status: Optional[Literal["Hired", "Rejected"]] = None


class VerdictOption(BaseModel):
    key: Literal["advance", "hire", "reject", "direct_hire", "direct_reject"]
    target: Optional[str] = None  # the round this advances to, when key == "advance"
    label: str


class VerdictOptionsResponse(BaseModel):
    round_name: str
    # True only for Screening — the frontend keeps the plain Pass/Fail picker
    # there; every later round uses `options` instead.
    legacy_pass_fail: bool
    is_admin: bool
    options: list[VerdictOption]


def _compose_feedback(email: str, body: SubmitFeedbackBody) -> str:
    lines = [f"Interviewer verdict via NeuLeap link — {email}", f"Verdict: {body.outcome}", ""]
    # Question-bank round: render each question with the recorded response and
    # the final mark, plus the total, so rounds.feedback stays human-readable.
    if body.qb_responses:
        total = 0.0
        out_of = 0.0
        lines.append("Question bank responses:")
        for r in body.qb_responses:
            mark = r.final_mark if r.final_mark is not None else r.ai_mark
            if mark is not None:
                total += float(mark)
                out_of += float(r.max_mark or 10)
            mark_str = f"{mark:g}/{r.max_mark:g}" if mark is not None else "unscored"
            lines.append(f"Q ({r.bucket}): {r.question}")
            lines.append(f"A: {(r.response_text or '').strip() or '(no response)'}")
            if (r.observation or "").strip():
                lines.append(f"Observation: {r.observation.strip()}")
            lines.append(f"Mark: {mark_str}")
            lines.append("")
        lines.append(f"Total: {total:g}/{out_of:g}")
        lines.append("")
    for a in body.answers:
        lines.append(f"Q ({a.bucket}{'' if a.mandatory else ', optional'}): {a.question}")
        lines.append(f"A: {a.answer.strip() or '(skipped)'}")
        lines.append("")
    if body.overall_feedback.strip():
        lines.append("Overall comments:")
        lines.append(body.overall_feedback.strip())
    return "\n".join(lines).strip()


@router.get("/{token}/verdict-options", response_model=VerdictOptionsResponse)
def get_verdict_options(
    token: str, x_interviewer_session: str | None = Header(default=None)
) -> VerdictOptionsResponse:
    """The verdict choices for THIS link's round — Screening keeps the plain
    Pass/Fail picker (`legacy_pass_fail=True`); Round 1 and later offer EVERY
    forward stage ("Move to Round 2", "Move to Final", ...) plus "Can be
    Hired" and "Reject", so a standout candidate can leapfrog rounds on the
    interviewer's verdict alone rather than only ever moving one step."""
    ctx = _link_ctx_for(token)
    email = _require_session(token, x_interviewer_session)
    round_id = ctx["round_id"]
    if round_id is None:
        raise HTTPException(status_code=404, detail="This link isn't linked to an interview round.")
    row = _round_for(ctx["candidate_id"], round_id)
    if not row:
        raise HTTPException(status_code=404, detail="Interview round not found.")

    round_name = row.get("round_name") or "Screening"
    if round_name == "Screening":
        return VerdictOptionsResponse(round_name=round_name, legacy_pass_fail=True, is_admin=False, options=[])

    candidate = repo().get_candidate(ctx["candidate_id"]) or {}
    include_r3 = bool(candidate.get("include_round3"))

    options: list[VerdictOption] = []
    if round_name == "Final":
        options.append(VerdictOption(key="advance", target=None, label="Hire"))
    else:
        for target in interview_plan.forward_stages(round_name, include_r3):
            options.append(VerdictOption(key="advance", target=target, label=f"Move to {target}"))
        # "Can be Hired" from ANY round — sets the "hire" NBA (ready-to-hire /
        # offer state), available to every interviewer. This made the old
        # Admin-only "Directly Hire/Reject" bypass options redundant ("Reject"
        # below ends the process for everyone the same way), so those two are
        # no longer emitted.
        options.append(VerdictOption(key="hire", target=None, label="Can be Hired"))
    options.append(VerdictOption(key="reject", target=None, label="Reject"))

    user = users.get_user_by_email(email)
    is_admin = bool(user and user["role"] in ("admin", "sysadmin"))
    return VerdictOptionsResponse(round_name=round_name, legacy_pass_fail=False, is_admin=is_admin, options=options)


@router.post("/{token}/feedback")
def submit_feedback(
    token: str,
    body: SubmitFeedbackBody,
    x_interviewer_session: str | None = Header(default=None),
) -> dict[str, Any]:
    ctx = _link_ctx_for(token)
    email = _require_session(token, x_interviewer_session)
    round_id = ctx["round_id"]
    if round_id is None:
        raise HTTPException(status_code=404, detail="This link isn't linked to an interview round.")

    row = _round_for(ctx["candidate_id"], round_id)
    if not row:
        raise HTTPException(status_code=404, detail="Interview round not found.")
    if row.get("outcome") not in (None, "", "Pending"):
        raise HTTPException(status_code=409, detail="This round's verdict has already been recorded.")

    missing = [a.question for a in body.answers if a.mandatory and not a.answer.strip()]
    if missing:
        raise HTTPException(
            status_code=422,
            detail=f"Please answer the mandatory question(s): {'; '.join(missing)}",
        )

    round_name = row.get("round_name") or "Screening"
    data: dict[str, Any] = {"feedback": _compose_feedback(email, body), "score": body.score}
    audit_detail = f"verdict {body.outcome}"
    # Set whenever the verdict should ALSO apply a Next Best Action — the same
    # mechanism the Candidate page's "Update Next Action" picker uses (creates
    # the next round, flips status, and sends the matching branded slot-invite/
    # ack email) — so "Move to Round 2" reads as "Share interview slots for
    # Round 2" everywhere else in the app, not just a bare round-advance.
    nba_key: Optional[str] = None

    # Which NBA key each forward stage routes through — the SAME keys the
    # Candidate page's NBA picker uses, so the verdict immediately leaves the
    # profile showing "Share interview slots for <next>" with a ready draft
    # (and auto-sends it when auto-send is configured), instead of a bare
    # round-advance with a stale action.
    _STAGE_SHARE_KEY = {
        "Round 1": "share_round1",
        "Round 2": "share_round2",
        "Round 3": "share_round3",
        "Final": "final_round",
    }
    candidate = repo().get_candidate(ctx["candidate_id"]) or {}
    include_r3 = bool(candidate.get("include_round3"))

    if body.direct_status:
        user = users.get_user_by_email(email)
        if not (user and user["role"] in ("admin", "sysadmin")):
            raise HTTPException(status_code=403, detail="Only an Admin can set a direct Hire/Reject verdict.")
        # Deliberately NOT setting data["outcome"] — a non-Final round's "Pass"
        # would otherwise auto-create the next planned round (see
        # repo().update_round), which a direct bypass must not do. The status
        # flip (and any audit trail) is handled entirely via the NBA key below.
        nba_key = "hire" if body.direct_status == "Hired" else "reject_email"
        audit_detail = f"direct verdict {body.direct_status}"
    elif body.outcome == "Fail":
        # A Fail on ANY round ends the process → record the Fail verdict (which
        # flips the candidate to Rejected via update_round) AND draft a polite
        # decline email through the reject NBA key. The draft waits for the
        # recruiter to send it, or auto-sends if auto-send is configured.
        data["outcome"] = "Fail"
        nba_key = "reject_email"
        audit_detail = "verdict Fail (Reject)"
    elif round_name == "Final":
        # Final Pass = hired; update_round's own Final branch sets Hired directly.
        data["outcome"] = "Pass"
        audit_detail = "verdict Pass"
    else:
        # Pass / leapfrog on Screening–Round 3: advance to the appropriate next
        # stage and draft its slot-share email. Screening uses the plain
        # Pass/Fail picker (no advance_to) so we derive the next planned stage;
        # later rounds pass an explicit forward target the interviewer chose.
        target = body.advance_to
        if target in ("Hire", "Hired"):
            # "Can be Hired" from any round — no data["outcome"] (a non-Final
            # "Pass" would auto-create the next round, which a jump straight to
            # ready-to-hire must not do); the status flip is via the NBA key.
            nba_key = "hire"
            audit_detail = "verdict Can be Hired"
        else:
            if not target or target not in interview_plan.forward_stages(round_name, include_r3):
                target = interview_plan.next_planned_stage(round_name, include_r3)
            nba_key = _STAGE_SHARE_KEY.get(target)
            if not nba_key:
                # No known next stage → plain single-step advance fallback.
                data["outcome"] = "Pass"
                if target:
                    data["advance_to"] = target
            audit_detail = f"verdict Pass — advance to {target or 'next round'}"

    updated = repo().update_round(round_id, data)
    if not updated:
        raise HTTPException(status_code=404, detail="Interview round not found.")

    # The round verdict FINALIZES this interview → mark the allocated question bank
    # SCORED so it stops showing "answering" on the leaderboard, regardless of how
    # many questions the interviewer actually asked/locked (per-question marking
    # already persisted each response via the lock endpoints). A legacy bulk
    # qb_responses payload, if any client still sends it, is persisted too.
    if body.qb_allocation_id:
        try:
            if body.qb_responses:
                rows = [
                    {
                        "bucket": r.bucket,
                        "question": r.question,
                        "question_index": r.index,
                        "response_text": r.response_text,
                        "observation": r.observation,
                        "ai_mark": r.ai_mark,
                        "ai_rationale": r.ai_rationale,
                        "final_mark": r.final_mark if r.final_mark is not None else r.ai_mark,
                        "max_mark": r.max_mark or 10,
                    }
                    for r in body.qb_responses
                ]
                repo().save_responses(body.qb_allocation_id, rows)
            repo().update_allocation(body.qb_allocation_id, {"status": "scored"})
        except Exception as exc:  # noqa: BLE001 — verdict already recorded
            log.warning("interviewer: finalizing QB alloc %s failed: %s",
                        body.qb_allocation_id, exc)

    if nba_key:
        from app.api.rounds import _apply_nba_key

        try:
            _apply_nba_key(ctx["candidate_id"], nba_key, None, source="interviewer")
        except HTTPException:
            raise
        except Exception as exc:  # noqa: BLE001 — the round verdict already recorded; don't fail the request over the NBA side-effect
            log.warning("interviewer: NBA key %r failed after round %s verdict: %s", nba_key, round_id, exc)
        else:
            if "outcome" not in data:
                # The verdict routed through an NBA key WITHOUT a plain outcome
                # (leapfrog advance / "Can be Hired" / direct verdict) — outcome
                # was deliberately left off the first update_round call so its
                # auto-advance wouldn't ALSO create the next planned round on a
                # "Pass". But that left this round reading "Pending" forever on
                # the Candidate page / interviewer view. Now that the NBA has
                # moved the candidate (leapfrogs repoint roundid to the new
                # round; hire/reject flip status off "Active"), stamping the
                # real verdict is side-effect-free: update_round's advance is
                # gated on is-active + status='Active', and the DB trigger only
                # syncs the candidate's ACTIVE round.
                stamp = "Fail" if body.direct_status == "Rejected" else "Pass"
                repo().update_round(round_id, {"outcome": stamp})

    audit.write_event(
        candidate_id=ctx["candidate_id"],
        layer="L4",
        step="round_updated",
        status="Info",
        fail_reason=(
            f"Round {row.get('round_name')} — {audit_detail} "
            f"submitted by interviewer ({email}) via interview link"
        ),
        stage=candidate_stage_bucket({"roundname": row.get("round_name")}),
    )

    # Mirrors app.api.rounds.update_round's auto-invite hook — a Pass verdict
    # here can advance the candidate to a brand-new "Pending" round exactly
    # like the recruiter's own round-drawer PATCH does (repo().update_round
    # already ran the same stage-advance logic above); without this, a
    # candidate advanced via an interviewer's verdict would never actually
    # get invited to pick a slot for that next round. Skipped when an NBA key
    # was applied above — that path already generates (and, per Settings,
    # possibly sends) its own branded ack-email; firing this too would notify
    # the candidate twice for the same advance.
    cid = ctx["candidate_id"]
    if not nba_key:
        try:
            candidate = repo().get_candidate(cid) or {}
            new_round_id = candidate.get("roundid")
            if new_round_id and new_round_id != round_id:
                from app.services import candidate_slot

                candidate_slot.maybe_create_and_send_invite(
                    cid, new_round_id, candidate.get("roundname"),
                    candidate.get("email"), candidate.get("name"), candidate.get("source"),
                )
        except Exception as exc:  # noqa: BLE001 — must not fail the verdict submission
            log.warning("interviewer: auto-invite hook failed after round %s update: %s", round_id, exc)

    return {
        "ok": True,
        "round": {k: updated.get(k) for k in _INTERVIEWER_ROUND_FIELDS},
    }


# ── Minting a link — Admin/Recruiter only, lives under the normal auth ──────
# (kept in this module since it's the other half of the same feature, not
# because it's public — get_current_user still gates it below).

class LinkResponse(BaseModel):
    url_path: str  # the SPA route, e.g. "/interview/<token>" — caller prefixes the origin


@admin_router.post("/candidates/{candidate_id}/interview-link", response_model=LinkResponse)
def create_interview_link(
    candidate_id: str,
    round_id: Optional[int] = Query(None, description="Scope the link to one interview round"),
    _user: AuthUser = Depends(get_current_user),
) -> LinkResponse:
    if not repo().get_candidate(candidate_id):
        raise HTTPException(status_code=404, detail=f"candidate {candidate_id} not found")
    if round_id is not None and not any(
        r.get("round_id") == round_id for r in repo().list_rounds(candidate_id)
    ):
        raise HTTPException(status_code=404, detail=f"round {round_id} not found for this candidate")
    token = interviewer_link.generate_link_token(candidate_id, round_id)
    return LinkResponse(url_path=f"/interview/{token}")
