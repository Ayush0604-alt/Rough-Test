"""Candidate Interview Slot Selection — a candidate-facing, email-code-gated
public surface, structurally mirroring app.api.interviewer (see that module's
docstring for the pattern this follows): a short opaque link token carries one
candidate+round, the candidate proves they own the on-file email via a mailed
"NLi-XXXXX" one-time code, and can then see available slots (sourced from
Microsoft Graph via app.services.graph_calendar, against the QA stand-in
calendar configured in Settings → Interview Scheduling) and book one.

Minting an invite (``POST /candidates/{id}/slot-invite``) is a normal
authenticated recruiter/admin action — kept in this module for the same
reason app.api.interviewer keeps its link-minting endpoint alongside the
public ones: it's the other half of the same feature. The AUTOMATIC mint
(when a round becomes a candidate's new active round) lives in
app.api.rounds, gated by Settings → Interview Scheduling → "Auto-send
invites" (default off).
"""
from __future__ import annotations

from datetime import datetime
from typing import Any, Optional

from fastapi import APIRouter, Depends, Header, HTTPException
from pydantic import BaseModel, EmailStr, Field

from app.api.auth import AuthUser, get_current_user
from app.logging_config import get_logger
from app.repositories import repo
from app.services import candidate_slot, email_send, email_templates, graph_client, interview_pools
from app.services.candidate_slot import AlreadyResolved, EmailMismatch, InvalidCode

log = get_logger(__name__)

router = APIRouter(prefix="/api/v1/schedule", tags=["candidate scheduling"])
admin_router = APIRouter(prefix="/api/v1", tags=["candidate scheduling"])


def _ctx_for(token: str) -> candidate_slot.InviteContext:
    ctx = candidate_slot.decode_invite(token)
    if not ctx:
        raise HTTPException(status_code=404, detail="This scheduling link is invalid.")
    return ctx


def _round_name(candidate_id: str, round_id: int) -> str:
    for r in repo().list_rounds(candidate_id):
        if r.get("round_id") == round_id:
            return r.get("round_name") or "Interview"
    return "Interview"


def _status_payload(ctx: candidate_slot.InviteContext) -> dict[str, Any]:
    from app.services.sample_interview import SAMPLE_CANDIDATE_ID

    candidate = repo().get_candidate(ctx["candidate_id"]) or {}
    return {
        "candidate_name": candidate.get("name"),
        # Pool-table check URLs are backed by the SAMPLE-DEMO fixture — the
        # page labels those as test invites instead of greeting a staff
        # checker with the fixture's (dummy) name as if it were a candidate.
        "is_sample": ctx["candidate_id"] == SAMPLE_CANDIDATE_ID,
        "round_name": _round_name(ctx["candidate_id"], ctx["round_id"]),
        "booked": ctx["booked_at"] is not None,
        "rejected": ctx["rejected_at"] is not None,
        "slot_start": ctx["slot_start"].isoformat() if ctx["slot_start"] else None,
        "slot_end": ctx["slot_end"].isoformat() if ctx["slot_end"] else None,
        "remind_me_again": ctx["remind_me_again"],
    }


class RequestCodeBody(BaseModel):
    email: EmailStr


class VerifyCodeBody(BaseModel):
    email: EmailStr
    code: str
    remember: bool = False


class VerifyCodeResponse(BaseModel):
    session_token: Optional[str]
    status: dict[str, Any]


@router.post("/{token}/request-code")
def request_code(token: str, body: RequestCodeBody) -> dict[str, bool]:
    _ctx_for(token)
    try:
        candidate_slot.request_code(token, str(body.email))
    except EmailMismatch as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    return {"sent": True}


@router.post("/{token}/verify-code", response_model=VerifyCodeResponse)
def verify_code(token: str, body: VerifyCodeBody) -> VerifyCodeResponse:
    ctx = _ctx_for(token)
    try:
        session_token = candidate_slot.verify_code(
            token, str(body.email), body.code, remember=body.remember
        )
    except InvalidCode as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return VerifyCodeResponse(session_token=session_token, status=_status_payload(ctx))


class StaffAccessBody(BaseModel):
    username: EmailStr
    password: str


@router.post("/{token}/staff-access", response_model=VerifyCodeResponse)
def staff_access(token: str, body: StaffAccessBody) -> VerifyCodeResponse:
    """Staff alternative to the emailed OTP: an Admin/SysAdmin checking a
    picker link (e.g. the pool table's "Time-slot picker URL" column) verifies
    with their own app credentials instead of needing access to the
    candidate's (or QA) inbox. Credentials are checked against app_users,
    role-gated to admin/sysadmin, and the visit is written to the Actions
    Audit Log so staff peeks at a candidate's page stay traceable."""
    ctx = _ctx_for(token)
    from app.services import audit, users

    user = users.authenticate(str(body.username), body.password)
    if not user or user.get("role") not in ("admin", "sysadmin"):
        raise HTTPException(
            status_code=403,
            detail="Admin or SysAdmin credentials are required to open this link without the emailed code.",
        )
    session_token = candidate_slot.create_staff_session(token, user["email"])
    audit.write_event(
        candidate_id=ctx["candidate_id"],
        layer="L4",
        step="slot_page_staff_access",
        status="Info",
        fail_reason=(
            f"Slot-picker page opened via staff credentials by {user['email']} ({user['role']})"
        ),
        stage=None,
    )
    return VerifyCodeResponse(session_token=session_token, status=_status_payload(ctx))


def _require_session(token: str, x_slot_session: Optional[str]) -> str:
    email = candidate_slot.validate_session(token, x_slot_session)
    if not email:
        raise HTTPException(status_code=401, detail="Verification required.")
    return email


@router.get("/{token}/status")
def get_status(token: str, x_slot_session: Optional[str] = Header(default=None)) -> dict[str, Any]:
    """Re-entry with an already-remembered session — skips the code challenge."""
    ctx = _ctx_for(token)
    _require_session(token, x_slot_session)
    return _status_payload(ctx)


@router.get("/{token}/slots")
def get_slots(
    token: str, x_slot_session: Optional[str] = Header(default=None)
) -> dict[str, Any]:
    ctx = _ctx_for(token)
    _require_session(token, x_slot_session)
    if ctx["booked_at"] or ctx["rejected_at"]:
        return {"slots": []}
    round_name = _round_name(ctx["candidate_id"], ctx["round_id"])
    return {"slots": candidate_slot.available_slots_for(ctx, round_name)}


class BookSlotBody(BaseModel):
    start: str
    end: str
    slot_id: Optional[int] = None  # set when the invite is pool-scoped


@router.post("/{token}/book")
def book_slot(
    token: str, body: BookSlotBody, x_slot_session: Optional[str] = Header(default=None)
) -> dict[str, Any]:
    ctx = _ctx_for(token)
    _require_session(token, x_slot_session)
    try:
        slot_start = datetime.fromisoformat(body.start)
        slot_end = datetime.fromisoformat(body.end)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail="Invalid slot start/end.") from exc
    try:
        updated = candidate_slot.book_slot(token, slot_start, slot_end, slot_id=body.slot_id)
    except AlreadyResolved as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except EmailMismatch as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return _status_payload(updated)


class HelpRequestBody(BaseModel):
    message: str = Field(min_length=3, max_length=2000)


@router.post("/{token}/help")
def send_help_request(
    token: str, body: HelpRequestBody, x_slot_session: Optional[str] = Header(default=None)
) -> dict[str, bool]:
    """The slot-picker page's "Need help?" message — lands on the candidate's
    row as a red "!" in status tracking (candidate_master.help_request) until
    a recruiter reads it and marks it handled, and is written to the Actions
    Audit Log so the whole exchange stays traceable."""
    ctx = _ctx_for(token)
    _require_session(token, x_slot_session)
    round_name = _round_name(ctx["candidate_id"], ctx["round_id"])
    from datetime import timezone

    from app.services import audit
    from app.stages import candidate_stage_bucket

    payload = {
        "message": body.message.strip(),
        "round_name": round_name,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "resolved": False,
    }
    repo().update_candidate_help_request(ctx["candidate_id"], payload)
    audit.write_event(
        candidate_id=ctx["candidate_id"], layer="L4", step="candidate_help_request", status="Info",
        fail_reason=f"Candidate asked for help from the {round_name or 'slot-picker'} page: {payload['message'][:180]}",
        stage=candidate_stage_bucket({"roundname": round_name}),
    )
    return {"ok": True}


class RemindAgainBody(BaseModel):
    value: bool


@router.post("/{token}/remind-me-again")
def remind_me_again(
    token: str, body: RemindAgainBody, x_slot_session: Optional[str] = Header(default=None)
) -> dict[str, bool]:
    _ctx_for(token)
    _require_session(token, x_slot_session)
    candidate_slot.set_remind_me_again(token, body.value)
    return {"remind_me_again": body.value}


# ── Minting an invite — Admin/Recruiter only ────────────────────────────────

class SlotInviteResponse(BaseModel):
    url_path: str


@admin_router.post("/candidates/{candidate_id}/help-request/resolve")
def resolve_help_request(
    candidate_id: str, user: AuthUser = Depends(get_current_user)
) -> dict[str, bool]:
    """Mark the candidate's "Need help" message as handled — clears the red
    "!" from status tracking (the message itself stays in the Audit Log)."""
    row = repo().get_candidate(candidate_id)
    if not row:
        raise HTTPException(status_code=404, detail=f"candidate {candidate_id} not found")
    hr = row.get("help_request")
    if not hr:
        return {"ok": True}
    from datetime import timezone

    from app.services import audit
    from app.stages import candidate_stage_bucket

    hr = dict(hr)
    hr["resolved"] = True
    hr["resolved_at"] = datetime.now(timezone.utc).isoformat()
    repo().update_candidate_help_request(candidate_id, hr)
    audit.write_event(
        candidate_id=candidate_id, layer="L4", step="candidate_help_resolved", status="Info",
        fail_reason=f"Help request marked handled by {user.email}.",
        stage=candidate_stage_bucket(row),
    )
    return {"ok": True}


# The stage-sharing NBA key for each round — resetting a round replays the
# same machinery the recruiter's own "Share slots for <round>" pick runs, so
# the fresh invite goes through the normal draft-review-then-send flow.
_ROUND_RESET_NBA_KEY = {
    "Screening": "call_now",
    "Round 1": "share_round1",
    "Round 2": "share_round2",
    "Round 3": "share_round3",
    "Final": "final_round",
}


@admin_router.post("/candidates/{candidate_id}/help-request/reset-round")
def reset_round_from_help(
    candidate_id: str, user: AuthUser = Depends(get_current_user)
) -> dict[str, Any]:
    """The "Reset this round" action on an ACTIVE help request: puts the
    candidate back at the INITIAL stage of their current round — the old
    picker link is disabled, invite/reminder/acceptance sub-steps are cleared,
    and a fresh slot-invite email draft is generated for the normal
    review-then-send flow. Marks the help request handled (this IS the
    response to it); every step lands in the Actions Audit Log."""
    row = repo().get_candidate(candidate_id)
    if not row:
        raise HTTPException(status_code=404, detail=f"candidate {candidate_id} not found")
    hr = row.get("help_request")
    if not hr or hr.get("resolved"):
        raise HTTPException(status_code=409, detail="This candidate has no active help request.")
    round_id = row.get("roundid")
    round_name = (row.get("roundname") or "").strip()
    if not round_id:
        raise HTTPException(status_code=409, detail="This candidate isn't currently in a round.")

    from datetime import timezone

    from app.db import get_conn
    from app.services import audit
    from app.stages import candidate_stage_bucket

    # 1) Disable this round's existing picker link(s) outright — sessions,
    #    pending codes and the invite rows themselves.
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT token FROM round_slot_invites WHERE round_id = %s", (round_id,))
            tokens = [r[0] for r in cur.fetchall()]
            if tokens:
                cur.execute("DELETE FROM candidate_slot_sessions WHERE token = ANY(%s)", (tokens,))
                cur.execute("DELETE FROM candidate_slot_otp WHERE token = ANY(%s)", (tokens,))
                cur.execute("DELETE FROM round_slot_invites WHERE round_id = %s", (round_id,))

    # 2) Reset the round to its initial stage (mirrors onto candidate_master
    #    because this is the active round — see repo().update_round).
    repo().update_round(
        round_id,
        {"invite_sent_at": None, "reminder_count": 0, "candidate_accepted_slot": None},
    )
    audit.write_event(
        candidate_id=candidate_id, layer="L4", step="round_reset", status="Info",
        fail_reason=(
            f"Round {round_name or '?'} reset to its initial stage by {user.email} in response to "
            f'the candidate\'s help request: "{(hr.get("message") or "")[:200]}". Old picker link '
            "disabled; fresh slots to be re-shared via draft review. Any already-booked meeting "
            "should be cancelled from the calendar."
        ),
        stage=candidate_stage_bucket(row),
    )

    # 3) Fresh slot-invite draft through the standard NBA machinery — the
    #    draft lands in review exactly like any share-slots action.
    key = _ROUND_RESET_NBA_KEY.get(round_name)
    if key:
        from app.api.rounds import _apply_nba_key

        try:
            _apply_nba_key(
                candidate_id, key, None, source="manual",
                comment=f"Round {round_name} reset after the candidate's help request",
            )
        except Exception as exc:  # noqa: BLE001 — the reset itself already happened
            log.warning("reset-round: draft regeneration failed for %s: %s", candidate_id, exc)

    # 4) The reset IS the response — mark the help request handled.
    hr = dict(hr)
    hr["resolved"] = True
    hr["resolved_at"] = datetime.now(timezone.utc).isoformat()
    repo().update_candidate_help_request(candidate_id, hr)
    audit.write_event(
        candidate_id=candidate_id, layer="L4", step="candidate_help_resolved", status="Info",
        fail_reason=f"Help request handled by {user.email} via round reset.",
        stage=candidate_stage_bucket(row),
    )
    return {"ok": True, "round_name": round_name, "draft_generated": bool(key)}


@admin_router.post("/candidates/{candidate_id}/slot-invite", response_model=SlotInviteResponse)
def create_slot_invite(
    candidate_id: str,
    round_id: int,
    _user: AuthUser = Depends(get_current_user),
) -> SlotInviteResponse:
    candidate = repo().get_candidate(candidate_id)
    if not candidate:
        raise HTTPException(status_code=404, detail=f"candidate {candidate_id} not found")
    round_row = next(
        (r for r in repo().list_rounds(candidate_id) if r.get("round_id") == round_id), None
    )
    if not round_row:
        raise HTTPException(status_code=404, detail=f"round {round_id} not found for this candidate")

    existing = candidate_slot.invite_for_round(round_id)
    if existing:
        token = existing["token"]
    else:
        # Prefer a matching interviewer timeslot pool (see app.services.interview_pools)
        # for this candidate's source + round when one exists — falls back to a
        # live per-candidate Graph lookup against the QA calendar otherwise.
        pool = interview_pools.find_pool_for(candidate.get("source"), round_row.get("round_name") or "")
        token = candidate_slot.create_invite(
            candidate_id, round_id, candidate.get("email"), pool_id=pool["id"] if pool else None
        )

    if candidate.get("email"):
        link_url = candidate_slot.public_schedule_url(token)
        if link_url:
            recipient, qa_redirected = email_send.resolve_recipient(candidate["email"])
            if not recipient:
                log.warning(
                    "candidate_slots: invite for %s not sent — non-production env and no QA test "
                    "email configured", candidate["email"],
                )
            else:
                subject, body = email_templates.render_slot_invite(
                    round_row.get("round_name") or "Interview", candidate.get("name"), link_url
                )
                result = graph_client.send_mail(recipient, subject, graph_client.plain_text_to_html(body))
                if not result["sent"]:
                    log.warning(
                        "candidate_slots: invite email to %s%s not sent: %s",
                        recipient, " (QA-redirected)" if qa_redirected else "", result.get("error"),
                    )
        else:
            log.warning(
                "candidate_slots: APP_PUBLIC_URL isn't configured — invite email to %s not sent",
                candidate["email"],
            )
    return SlotInviteResponse(url_path=f"/schedule/{token}")
