"""System Cleanup — Mailbox section: wipe the database for a fresh QA reload.

Admin-only (stricter than the rest of Mailbox, which is Admin-or-Sysadmin) —
see app.services.system_reset for the three-layer safety gate (QA-only env,
role, typed confirmation phrase) and exactly what gets wiped.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from app.api.auth import require_admin
from app.services import system_reset

router = APIRouter(
    prefix="/api/v1",
    tags=["system reset"],
    dependencies=[Depends(require_admin)],
)


class WipeRequest(BaseModel):
    confirm: str


@router.get("/system/wipe-info")
def get_wipe_info() -> dict:
    """Whether a wipe is even possible here, and the exact phrase the UI must
    ask the recruiter to type — see system_reset.required_confirmation()."""
    return {
        "allowed": system_reset.is_wipe_allowed(),
        "confirm_phrase": system_reset.required_confirmation(),
    }


@router.post("/system/wipe")
def post_wipe(body: WipeRequest) -> dict:
    try:
        return system_reset.wipe(body.confirm)
    except system_reset.WipeNotAllowed as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
