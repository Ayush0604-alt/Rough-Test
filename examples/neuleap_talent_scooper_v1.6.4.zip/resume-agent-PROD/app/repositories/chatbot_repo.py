"""Read-only data access for the NL-to-SQL chatbot (Layer 5).

This is the *only* place the chatbot touches the database. Every query runs inside
a ``READ ONLY`` transaction — a second line of defence behind the app-side SELECT
guardrails in ``app/api/chatbot.py`` (which stay there, next to the route, because
they are the security boundary).

The router owns intent routing, prompt loading and SQL sanitisation; this module
owns connection handling and execution. That keeps the HTTP layer free of raw
``psycopg2``/``get_conn`` usage without weakening the candidate repository's CRUD
contract.
"""
from __future__ import annotations

import psycopg2.extras

from app.db import get_conn


def fetch_distinct_values(
    spec: dict[str, tuple[str, ...]], *, limit: int = 40
) -> list[str]:
    """Snapshot the live distinct values for each ``(table, col)`` in ``spec``.

    Returns ``"- table.col: v1, v2, …"`` lines (one per column that has values).
    A missing column is skipped (the read-only transaction is restarted after the
    rollback) so a schema drift never aborts the whole probe. Raises only on a
    connection-level failure, which the caller treats as best-effort.
    """
    lines: list[str] = []
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("SET TRANSACTION READ ONLY")
            for table, cols in spec.items():
                for col in cols:
                    try:
                        cur.execute(
                            f"SELECT DISTINCT {col} FROM {table} "
                            f"WHERE {col} IS NOT NULL AND {col}::text <> '' "
                            f"ORDER BY 1 LIMIT {int(limit)}"
                        )
                        vals = [str(r[0]) for r in cur.fetchall()]
                    except Exception:  # noqa: BLE001 — skip a missing column
                        conn.rollback()
                        cur.execute("SET TRANSACTION READ ONLY")
                        continue
                    if vals:
                        lines.append(f"- {table}.{col}: {', '.join(vals)}")
    return lines


def run_readonly_select(sql: str) -> list[dict]:
    """Execute an already-sanitized SELECT inside a READ ONLY transaction."""
    with get_conn() as conn:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute("SET TRANSACTION READ ONLY")
            cur.execute(sql)
            return [dict(r) for r in cur.fetchall()]


def count_matches(inner_sql: str) -> int | None:
    """Real match count for ``inner_sql`` (its trailing LIMIT already stripped).

    Wraps the query in ``COUNT(*)`` inside a READ ONLY transaction. Returns ``None``
    if the count yields no row.
    """
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("SET TRANSACTION READ ONLY")
            cur.execute(f"SELECT count(*) FROM ({inner_sql}) _cnt")
            row = cur.fetchone()
            return int(row[0]) if row else None
