"""PostgreSQL repository.

Writes candidate_master (owned by this service); reads email_master (owned
upstream — never mutated here). Candidate ids come from the ``candidate_seq``
sequence (race-safe), formatted as ``C1001``, ``C1002`` ...
"""
from __future__ import annotations

import logging
from datetime import date
from decimal import Decimal
from typing import Optional

import psycopg2.errors
import psycopg2.extras

from app.config import settings, NO_SOURCE_TAG
from app.db import get_candidate as _db_get_candidate
from app.db import _AUTO_HOLD_SELECT, resolve_auto_hold
from app.db import get_conn
from app.repositories.base import BaseRepository
from app.services import interview_plan

logger = logging.getLogger(__name__)


class PostgresRepository(BaseRepository):

    # ── candidate_master ──────────────────────────────────────────────

    def get_next_candidate_id(self) -> str:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT nextval('candidate_seq')")
                n = cur.fetchone()[0]
        return f"{settings.candidate_id_prefix}{n}"

    def get_candidate(self, candidate_id: str) -> Optional[dict]:
        return _db_get_candidate(candidate_id)

    def insert_candidate_stub(
        self,
        candidate_id: str,
        s3_file_path: str,
        mail_send_date: date,
        e_id: str,
        name: str = "",
        email: str = "",
        phno: str = "",
        file_hash: Optional[str] = None,
        l2_text: Optional[str] = None,
        l2_text_complete: Optional[bool] = None,
        source: Optional[str] = None,
    ) -> None:
        # Never persist NULL/blank — an untagged candidate gets the canonical
        # "No Source Tag" bucket so the source filter and the dedup uniqueness
        # bucket (COALESCE(btrim(source), '')) stay consistent for every row.
        source = (source or "").strip() or NO_SOURCE_TAG
        query = """
            INSERT INTO candidate_master (
                candidate_id, e_id, s3_file_path, mail_send_date, status,
                name, email, phno, previously_seen,
                file_hash, l2_text, l2_text_complete, source
            ) VALUES (%s, %s, %s, %s, 'Pending Extraction', %s, %s, %s, FALSE, %s, %s, %s, %s)
            ON CONFLICT (candidate_id) DO NOTHING
        """
        with get_conn() as conn:
            with conn.cursor() as cur:
                try:
                    cur.execute(
                        query,
                        (
                            candidate_id, e_id, s3_file_path, mail_send_date,
                            name or None, email or None, phno or None,
                            file_hash, l2_text, l2_text_complete, source,
                        ),
                    )
                except psycopg2.errors.UniqueViolation as exc:
                    # The fuzzy name/email/phone dedup check (app.pipeline.nodes.dedup)
                    # missed this one — a corroborating signal fell short of its 2-of-3
                    # bar (or the name-strong shortcut) even though the email is an
                    # exact match within this source. uq_candidate_email_ci is the
                    # backstop; without translating it here, the raw multi-line SQL
                    # error ("duplicate key value violates ... DETAIL: Key (...)")
                    # propagates verbatim into the audit trail as this file's "reason",
                    # which is unreadable to a recruiter and untraceable to what
                    # actually happened.
                    raise ValueError(
                        f"Duplicate — a candidate with email {email!r} already exists "
                        f"for source {source!r}"
                    ) from exc

    def update_candidate_resume(self, candidate_id: str, s3_file_path: str) -> None:
        query = """
            UPDATE candidate_master
            SET s3_file_path = %s,
                atsscore = NULL,
                score_breakdown = NULL,
                score_penalties = NULL,
                certification_bonus = NULL,
                priority = NULL,
                status = 'Pending Extraction',
                updated_at = CURRENT_TIMESTAMP
            WHERE candidate_id = %s
        """
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(query, (s3_file_path, candidate_id))

    def flag_candidate_reapplication(
        self, candidate_id: str, incoming_s3_key: str
    ) -> None:
        # The candidate stays 'Active'; the reapplication is tracked purely by
        # previously_seen + pending_review_file (which drive the Entry Resolution
        # panel) and a review_queue row — not a separate lifecycle status.
        query = """
            UPDATE candidate_master
            SET previously_seen = TRUE,
                pending_review_file = %s,
                status = 'Active',
                updated_at = CURRENT_TIMESTAMP
            WHERE candidate_id = %s
        """
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(query, (incoming_s3_key, candidate_id))

    def candidates_for_batch(self, batch_id: str) -> list[dict]:
        """Candidates generated by a batch (linked via audit_log.candidate_id).

        Returns ALL candidate_master columns (the CSV export emits every field),
        candidate_id ordered.
        """
        query = """
            SELECT *
            FROM candidate_master
            WHERE candidate_id IN (
                SELECT DISTINCT candidate_id FROM audit_log
                WHERE batch_id = %s AND candidate_id IS NOT NULL
            )
            ORDER BY candidate_id
        """
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(query, (batch_id,))
                return [dict(r) for r in cur.fetchall()]

    def discarded_for_batch(self, batch_id: str) -> list[dict]:
        """Every non-clean outcome in a batch — for the export's "Discarded" sheet.

        These don't show up as a clean extracted candidate, so the Candidates
        sheet alone under-reports the batch. Two structured sources:

        * ``review_queue`` (ALL states) — the "needs a human / was dropped" ledger:
          duplicate, duplicate_hired, reapplication, not_resume, corrupt,
          invalid_file, excel_row, link_fetch, extraction_fail, failed, exhausted.
          ``kind`` is a stored column (no free-text parsing). For a dup/re-app row
          ``candidate_id`` is the ORIGINAL it matched (the "duplicate of").
        * Candidates stranded at ``status='Pending Extraction'`` — real
          candidate_master rows the parser never finished, scoped to this batch
          via audit_log.

        Returns normalized rows: ``E_id, candidate_id, kind, filename, reason,
        state, created_at`` — newest activity last (processing order).
        """
        review_q = """
            SELECT e_id AS "E_id", candidate_id, kind, filename, reason,
                   state, created_at
            FROM review_queue
            WHERE batch_id = %s
            ORDER BY created_at, review_id
        """
        # Pending-extraction candidates are not review_queue rows; pull them from
        # candidate_master and shape them to the same dict so they merge cleanly.
        pending_q = """
            SELECT DISTINCT cm.candidate_id, cm.e_id AS "E_id",
                   cm.s3_file_path, cm.failure_reason, cm.created_at
            FROM candidate_master cm
            JOIN audit_log a ON a.candidate_id = cm.candidate_id
            WHERE a.batch_id = %s AND cm.status = 'Pending Extraction'
            ORDER BY cm.candidate_id
        """
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(review_q, (batch_id,))
                rows = [dict(r) for r in cur.fetchall()]
                cur.execute(pending_q, (batch_id,))
                for r in cur.fetchall():
                    path = r["s3_file_path"] or ""
                    rows.append({
                        "E_id": r["E_id"],
                        "candidate_id": r["candidate_id"],
                        "kind": "pending_extraction",
                        "filename": path.rsplit("/", 1)[-1] if path else None,
                        "reason": r["failure_reason"]
                        or "Extraction never completed",
                        "state": "open",
                        "created_at": r["created_at"],
                    })
        return rows

    def candidate_facets(self) -> dict:
        """Dropdown facets for browsing candidates by batch or by sender email.

        - batches: one row per audit_log.batch_id that produced ≥1 candidate, with the
          set of candidate_ids it generated and its most recent run time.
        - emails: one row per source email (email_master.e_id), with its sender and
          subject and the candidates that arrived in it (candidate_master.e_id join).
          Keyed by E_ID — NOT grouped by sender — because a placeholder sender like
          "direct" is shared across many distinct emails that must stay separable.

        Each row carries its candidate_ids so the SPA can filter the already-loaded
        candidate list client-side with no extra round-trip per selection.
        """
        batches_q = """
            SELECT batch_id,
                   MAX(created_at) AS last_run,
                   ARRAY_AGG(DISTINCT candidate_id)
                     FILTER (WHERE candidate_id IS NOT NULL) AS candidate_ids
            FROM audit_log
            WHERE batch_id IS NOT NULL
            GROUP BY batch_id
            HAVING COUNT(candidate_id) FILTER (WHERE candidate_id IS NOT NULL) > 0
            ORDER BY MAX(created_at) DESC
        """
        emails_q = """
            SELECT em.e_id,
                   em.sender_mail_id,
                   em.subject,
                   ARRAY_AGG(DISTINCT cm.candidate_id) AS candidate_ids
            FROM candidate_master cm
            JOIN email_master em ON em.e_id = cm.e_id
            GROUP BY em.e_id, em.sender_mail_id, em.subject
            ORDER BY em.e_id
        """
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(batches_q)
                batches = [dict(r) for r in cur.fetchall()]
                cur.execute(emails_q)
                emails = [dict(r) for r in cur.fetchall()]
        return {"batches": batches, "emails": emails}

    def get_all_candidates(self) -> list[dict]:
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    f'SELECT cm.*, cm.e_id AS "E_id", {_AUTO_HOLD_SELECT} '
                    "FROM candidate_master cm "
                    "LEFT JOIN rounds r ON r.round_id = cm.roundid "
                    "ORDER BY cm.candidate_id"
                )
                return [resolve_auto_hold(dict(r)) for r in cur.fetchall()]

    # ── L4 archival (step 24) ─────────────────────────────────────────

    def _archive_ids(self, cur, candidate_ids: list[str]) -> None:
        """Move the given candidates (+ their rounds) into the archive tables.

        S3 files are never touched — only DB rows move, so reapplication matching
        still works. Caller owns the transaction/cursor.
        """
        if not candidate_ids:
            return
        # Rounds first (archive then delete) so the candidate FK can be removed.
        cur.execute(
            "INSERT INTO rounds_archive SELECT r.*, CURRENT_TIMESTAMP "
            "FROM rounds r WHERE r.candidate_id = ANY(%s)",
            (candidate_ids,),
        )
        cur.execute("DELETE FROM rounds WHERE candidate_id = ANY(%s)", (candidate_ids,))
        cur.execute(
            "INSERT INTO candidate_master_archive SELECT cm.*, CURRENT_TIMESTAMP "
            "FROM candidate_master cm WHERE cm.candidate_id = ANY(%s)",
            (candidate_ids,),
        )
        cur.execute(
            "DELETE FROM candidate_master WHERE candidate_id = ANY(%s)", (candidate_ids,)
        )

    def archive_eligible(self) -> dict:
        """Nightly rule: Closed >= N days, or low-score-never-screened >= N days.

        N (``ARCHIVE_AFTER_DAYS``) and the ATS cutoff (``ARCHIVE_ATS_THRESHOLD``) come
        from the Settings page (env). Hired rows are excluded here — those are archived
        manually after onboarding.
        """
        from app.services import pipeline_config

        days = pipeline_config.archive_after_days()       # int (env-driven, validated)
        ats = pipeline_config.archive_ats_threshold()     # float (env-driven, validated)
        # days/ats are coerced to int/float above, so this interpolation is injection-safe.
        select = f"""
            SELECT candidate_id FROM candidate_master
            WHERE (status = 'Closed' AND closed_at IS NOT NULL
                   AND closed_at <= NOW() - INTERVAL '{days} days')
               OR (atsscore IS NOT NULL AND atsscore < {ats} AND screened = FALSE
                   AND created_at <= NOW() - INTERVAL '{days} days')
        """
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(select)
                ids = [r[0] for r in cur.fetchall()]
                self._archive_ids(cur, ids)
        return {"archived": len(ids), "candidate_ids": ids}

    def archive_candidate(self, candidate_id: str) -> dict:
        """Manual archive (e.g. a Hired candidate after onboarding)."""
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT candidate_id FROM candidate_master WHERE candidate_id = %s",
                    (candidate_id,),
                )
                if not cur.fetchone():
                    return {"archived": 0, "candidate_ids": []}
                self._archive_ids(cur, [candidate_id])
        return {"archived": 1, "candidate_ids": [candidate_id]}

    # ── email_master (read-only) ──────────────────────────────────────

    def get_passed_emails(self) -> list[dict]:
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    "SELECT * FROM email_master WHERE process_status = 'Passed'"
                )
                return [dict(r) for r in cur.fetchall()]

    def get_email(self, e_id: str) -> Optional[dict]:
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    'SELECT *, e_id AS "E_id" FROM email_master WHERE e_id = %s',
                    (e_id,),
                )
                row = cur.fetchone()
                return dict(row) if row else None

    def get_all_emails(self) -> list[dict]:
        # Alias e_id -> E_id so the SPA's EmailMaster type lines up.
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    'SELECT *, e_id AS "E_id" FROM email_master ORDER BY e_id DESC'
                )
                return [dict(r) for r in cur.fetchall()]

    def email_run_summary(self) -> dict:
        """Counts for the dashboard cards, derived from email_master."""
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT
                      COUNT(*) FILTER (WHERE process_status = 'Passed')           AS passed,
                      COUNT(*) FILTER (WHERE extracted_status LIKE 'Partial%%')    AS partial,
                      COUNT(*) FILTER (WHERE process_status = 'Failed')            AS failed,
                      COUNT(*) FILTER (WHERE process_status = 'Discarded')         AS discarded
                    FROM email_master
                    """
                )
                passed, partial, failed, discarded = cur.fetchone()
        return {
            "passed": passed or 0,
            "partial": partial or 0,
            "failed": failed or 0,
            "discarded": discarded or 0,
        }

    # ── audit_log (read-only) ─────────────────────────────────────────

    def list_audit_logs(
        self, e_id: Optional[str] = None, batch_id: Optional[str] = None
    ) -> list[dict]:
        clauses, vals = [], []
        if e_id:
            clauses.append("e_id = %s")
            vals.append(e_id)
        if batch_id:
            clauses.append("batch_id = %s")
            vals.append(batch_id)
        where = (" WHERE " + " AND ".join(clauses)) if clauses else ""
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    'SELECT *, e_id AS "E_id" FROM audit_log'
                    + where
                    + " ORDER BY log_id DESC LIMIT 500",
                    vals,
                )
                return [dict(r) for r in cur.fetchall()]

    # ── D10: idempotency ──────────────────────────────────────────────

    def passed_unprocessed_eids(self) -> list[str]:
        """Passed emails not yet processed by L2/L3 — the orchestrator's queue."""
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT e_id FROM email_master "
                    "WHERE process_status = 'Passed' AND processed = FALSE "
                    "ORDER BY e_id"
                )
                return [r[0] for r in cur.fetchall()]

    def mark_processed(self, e_id: str) -> None:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "UPDATE email_master "
                    "SET processed = TRUE, processed_at = CURRENT_TIMESTAMP "
                    "WHERE e_id = %s",
                    (e_id,),
                )

    # ── L4: candidate lifecycle (recruiter-owned) ─────────────────────

    def update_candidate_status(self, candidate_id: str, status: str) -> Optional[dict]:
        """Set recruiter status; stamp closed_at when entering Closed, clear on exit.

        A direct Hired/Rejected (e.g. "Mark Hired" without walking the Final round)
        also syncs round_status — the at-a-glance verdict badge — so it can't show a
        stale "In Progress" against a Hired candidate.
        """
        query = """
            UPDATE candidate_master
            SET status = %s,
                round_status = CASE
                    WHEN %s = 'Hired'    THEN 'Hired'
                    WHEN %s = 'Rejected' THEN 'Rejected'
                    ELSE round_status
                END,
                closed_at = CASE WHEN %s = 'Closed' THEN CURRENT_TIMESTAMP ELSE NULL END,
                updated_at = CURRENT_TIMESTAMP
            WHERE candidate_id = %s
            RETURNING *
        """
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(query, (status, status, status, status, candidate_id))
                row = cur.fetchone()
                return dict(row) if row else None

    def update_candidate_priority(self, candidate_id: str, priority: str) -> Optional[dict]:
        """Recruiter override — overwrites the ATS-derived priority in place."""
        query = """
            UPDATE candidate_master
            SET priority = %s, updated_at = CURRENT_TIMESTAMP
            WHERE candidate_id = %s
            RETURNING *
        """
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(query, (priority, candidate_id))
                row = cur.fetchone()
                return dict(row) if row else None

    def update_candidate_next_action_override(
        self, candidate_id: str, override: Optional[dict]
    ) -> Optional[dict]:
        """Recruiter override of the "Next Best Action" suggestion. `override` is
        ``{"key": ..., "text": ...}`` or ``None`` to clear it back to the ATS-derived
        suggestion."""
        query = """
            UPDATE candidate_master
            SET next_action_override = %s, updated_at = CURRENT_TIMESTAMP
            WHERE candidate_id = %s
            RETURNING *
        """
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    query,
                    (psycopg2.extras.Json(override) if override else None, candidate_id),
                )
                row = cur.fetchone()
                return dict(row) if row else None

    def update_candidate_help_request(
        self, candidate_id: str, payload: Optional[dict]
    ) -> Optional[dict]:
        """The candidate's slot-picker "Need help" message — ``{"message",
        "round_name", "created_at", "resolved", ...}`` or ``None`` to clear."""
        query = """
            UPDATE candidate_master
            SET help_request = %s, updated_at = CURRENT_TIMESTAMP
            WHERE candidate_id = %s
            RETURNING *
        """
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    query,
                    (psycopg2.extras.Json(payload) if payload else None, candidate_id),
                )
                row = cur.fetchone()
                return dict(row) if row else None

    def update_candidate_latest_remark(
        self, candidate_id: str, payload: Optional[dict]
    ) -> Optional[dict]:
        """The LATEST recruiter remark ({text, author, created_at}) — like the
        note but also surfaced to the interviewer; ``None`` clears it. Full
        history (edits + deletions) is in audit_log (step = candidate_remark)."""
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    "UPDATE candidate_master SET latest_remark = %s, "
                    "updated_at = CURRENT_TIMESTAMP WHERE candidate_id = %s RETURNING *",
                    (psycopg2.extras.Json(payload) if payload else None, candidate_id),
                )
                row = cur.fetchone()
                return dict(row) if row else None

    def update_candidate_latest_note(
        self, candidate_id: str, payload: Optional[dict]
    ) -> Optional[dict]:
        """The LATEST recruiter note ({text, author, created_at}) — mirrors the
        Candidate page's sticky note; ``None`` clears it (deleting the sticky +
        badge). Full note history, deletions included, is in audit_log."""
        query = """
            UPDATE candidate_master
            SET latest_note = %s, updated_at = CURRENT_TIMESTAMP
            WHERE candidate_id = %s
            RETURNING *
        """
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    query,
                    (psycopg2.extras.Json(payload) if payload else None, candidate_id),
                )
                row = cur.fetchone()
                return dict(row) if row else None

    def list_candidate_audit_log(self, candidate_id: str) -> list[dict]:
        """Every audit_log row for this candidate — L1 (mail intake) through L4
        (recruiter actions), newest first (reverse chronological — log_id is a
        monotonic BIGSERIAL so this always agrees with created_at). The "Actions
        Audit Log" on the candidate profile shows these as one flat reverse-
        chronological list; ``draft_id`` (set only on email-lifecycle rows) backs
        its "view email" button."""
        query = """
            SELECT log_id, layer, step, status, fail_reason, stage, draft_id, created_at
            FROM audit_log
            WHERE candidate_id = %s
            ORDER BY log_id DESC
        """
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(query, (candidate_id,))
                return [dict(r) for r in cur.fetchall()]

    # ── Email drafts (generated on an email-sending NBA selection) ────────────

    def create_email_draft(
        self, candidate_id: str, nba_key: str, subject: str, body: str
    ) -> dict:
        query = """
            INSERT INTO email_drafts (candidate_id, nba_key, subject, body)
            VALUES (%s, %s, %s, %s)
            RETURNING *
        """
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(query, (candidate_id, nba_key, subject, body))
                return dict(cur.fetchone())

    def list_candidate_email_drafts(self, candidate_id: str) -> list[dict]:
        """This candidate's drafts, newest first."""
        query = """
            SELECT * FROM email_drafts
            WHERE candidate_id = %s
            ORDER BY draft_id DESC
        """
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(query, (candidate_id,))
                return [dict(r) for r in cur.fetchall()]

    def latest_pending_drafts(self, candidate_ids: list[str]) -> dict[str, dict]:
        """The latest email draft per candidate (any status), for the candidates
        in ``candidate_ids`` — powers the draft-status badge on list views
        (Draft/Ready/Sent) without an N+1 fetch. Keyed by candidate_id; a
        candidate with no draft at all is simply absent from the result."""
        if not candidate_ids:
            return {}
        query = """
            SELECT DISTINCT ON (candidate_id) *
            FROM email_drafts
            WHERE candidate_id = ANY(%s)
            ORDER BY candidate_id, draft_id DESC
        """
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(query, (candidate_ids,))
                return {r["candidate_id"]: dict(r) for r in cur.fetchall()}

    def sender_emails_by_candidate(self, candidate_ids: list[str]) -> dict[str, dict]:
        """candidate_id → ``{"sender", "subject"}`` of its source email
        (email_master via candidate_master.e_id), for referral classification on
        list views — one query, no N+1. Candidates with no e_id / sender are
        simply absent."""
        if not candidate_ids:
            return {}
        query = """
            SELECT cm.candidate_id, em.sender_mail_id, em.subject
            FROM candidate_master cm
            JOIN email_master em ON em.e_id = cm.e_id
            WHERE cm.candidate_id = ANY(%s) AND em.sender_mail_id IS NOT NULL
        """
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(query, (candidate_ids,))
                return {
                    cid: {"sender": sender, "subject": subject}
                    for cid, sender, subject in cur.fetchall()
                    if sender
                }

    def get_email_draft(self, draft_id: int) -> Optional[dict]:
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute("SELECT * FROM email_drafts WHERE draft_id = %s", (draft_id,))
                row = cur.fetchone()
                return dict(row) if row else None

    def update_email_draft(
        self,
        draft_id: int,
        *,
        subject: Optional[str] = None,
        body: Optional[str] = None,
        status: Optional[str] = None,
    ) -> Optional[dict]:
        sets, vals = [], []
        if subject is not None:
            sets.append("subject = %s")
            vals.append(subject)
        if body is not None:
            sets.append("body = %s")
            vals.append(body)
        if status is not None:
            sets.append("status = %s")
            vals.append(status)
        if not sets:
            return self.get_email_draft(draft_id)
        vals.append(draft_id)
        query = (
            "UPDATE email_drafts SET "
            + ", ".join(sets)
            + ", updated_at = CURRENT_TIMESTAMP WHERE draft_id = %s RETURNING *"
        )
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(query, vals)
                row = cur.fetchone()
                return dict(row) if row else None

    def mark_email_draft_sent(self, draft_id: int) -> Optional[dict]:
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    "UPDATE email_drafts SET status = 'sent', sent_at = CURRENT_TIMESTAMP, "
                    "updated_at = CURRENT_TIMESTAMP WHERE draft_id = %s RETURNING *",
                    (draft_id,),
                )
                row = cur.fetchone()
                return dict(row) if row else None

    def update_candidate_screening(
        self,
        candidate_id: str,
        *,
        currentlocation: Optional[str] = None,
        relocation: Optional[bool] = None,
    ) -> Optional[dict]:
        """Fields a recruiter fills during the screening call (currentlocation, relocation)."""
        sets, vals = [], []
        if currentlocation is not None:
            sets.append("currentlocation = %s")
            vals.append(currentlocation)
        if relocation is not None:
            sets.append("relocation = %s")
            vals.append(relocation)
        if not sets:
            return self.get_candidate(candidate_id)
        vals.append(candidate_id)
        query = (
            "UPDATE candidate_master SET "
            + ", ".join(sets)
            + ", updated_at = CURRENT_TIMESTAMP WHERE candidate_id = %s RETURNING *"
        )
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(query, vals)
                row = cur.fetchone()
                return dict(row) if row else None

    # ── Step 20: candidate-entry branches ─────────────────────────────

    def list_by_status(self, status: str) -> list[dict]:
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    f'SELECT cm.*, cm.e_id AS "E_id", {_AUTO_HOLD_SELECT} '
                    "FROM candidate_master cm "
                    "LEFT JOIN rounds r ON r.round_id = cm.roundid "
                    "WHERE cm.status = %s ORDER BY cm.candidate_id",
                    (status,),
                )
                return [resolve_auto_hold(dict(r)) for r in cur.fetchall()]

    def list_reapplications(self) -> list[dict]:
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    'SELECT *, e_id AS "E_id" FROM candidate_master '
                    "WHERE previously_seen = TRUE AND pending_review_file IS NOT NULL "
                    "ORDER BY candidate_id"
                )
                return [dict(r) for r in cur.fetchall()]

    def accept_reapplication(
        self, candidate_id: str, new_s3_key: Optional[str] = None
    ) -> Optional[dict]:
        """Promote the pending file to the live resume and queue re-extraction.

        ``new_s3_key`` is the **resume-bucket** key the pending raw file was relocated
        to (so the live ``s3_file_path`` points where L3 reads). When omitted, the raw
        pending key is promoted as-is (local/legacy path).
        """
        query = """
            UPDATE candidate_master
            SET s3_file_path = COALESCE(%s, pending_review_file, s3_file_path),
                pending_review_file = NULL,
                previously_seen = FALSE,
                atsscore = NULL,
                score_breakdown = NULL,
                score_penalties = NULL,
                certification_bonus = NULL,
                priority = NULL,
                status = 'Pending Extraction',
                updated_at = CURRENT_TIMESTAMP
            WHERE candidate_id = %s
            RETURNING *
        """
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(query, (new_s3_key, candidate_id))
                row = cur.fetchone()
                return dict(row) if row else None

    def ignore_reapplication(self, candidate_id: str) -> Optional[dict]:
        """Discard the incoming file; restore the existing record to Active."""
        query = """
            UPDATE candidate_master
            SET pending_review_file = NULL,
                previously_seen = FALSE,
                status = 'Active',
                updated_at = CURRENT_TIMESTAMP
            WHERE candidate_id = %s
            RETURNING *
        """
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(query, (candidate_id,))
                row = cur.fetchone()
                return dict(row) if row else None

    # ── L4: rounds ────────────────────────────────────────────────────

    def list_rounds(self, candidate_id: str) -> list[dict]:
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    "SELECT * FROM rounds WHERE candidate_id = %s ORDER BY round_id",
                    (candidate_id,),
                )
                return [dict(r) for r in cur.fetchall()]

    def analytics_rounds(self) -> dict:
        """Per-candidate aging in the active round + rolled-up per-stage tiles.

        Aging anchor = when the candidate ENTERED the active round (rounds.created_at).
        Aging therefore resets to 0 each time the candidate advances to a new round
        (a new row is inserted with a fresh created_at) and counts up from there —
        independent of when the interview is scheduled. Clamped at 0.

        Population: status='Active' AND roundid IS NOT NULL — every active-in-round
        candidate ages, regardless of the round's outcome. Tiers are strict:
        🟡 watch > 15 days, 🔴 stalled > 30 days.
        """
        query = """
            SELECT
                cm.candidate_id,
                cm.name,
                cm.roundname            AS stage,
                r.interviewer,
                r.outcome,
                r.scheduled_on,
                GREATEST(
                    0,
                    DATE_PART('day', now() - r.created_at)
                )::int                  AS aging_days
            FROM candidate_master cm
            JOIN rounds r ON r.round_id = cm.roundid
            WHERE cm.status = 'Active' AND cm.roundid IS NOT NULL
            ORDER BY aging_days DESC, cm.candidate_id
        """
        # Scheduled date of the candidate's current round, keyed by candidate_id.
        # Unlike aging (Active-only), this also covers terminal HIRED and REJECTED
        # candidates: their roundid still points at the last round they sat in, and
        # the Screening table's SCHEDULED column must show that round's date (for
        # Hired/Rejected we surface the date but not an aging counter).
        sched_query = """
            SELECT cm.candidate_id, r.scheduled_on
            FROM candidate_master cm
            JOIN rounds r ON r.round_id = cm.roundid
            WHERE cm.status IN ('Active', 'Hired', 'Rejected')
              AND cm.roundid IS NOT NULL
              AND r.scheduled_on IS NOT NULL
        """
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(query)
                candidates = [dict(r) for r in cur.fetchall()]
                cur.execute(sched_query)
                scheduled = {r["candidate_id"]: r["scheduled_on"] for r in cur.fetchall()}

        WATCH, ALERT = 15, 30
        tiles: dict[str, dict] = {}
        for c in candidates:
            stage = c.get("stage") or "—"
            aging = c.get("aging_days") or 0
            t = tiles.setdefault(
                stage,
                {"stage": stage, "count": 0, "aging_sum": 0,
                 "warn_count": 0, "alert_count": 0},
            )
            t["count"] += 1
            t["aging_sum"] += aging
            if aging > ALERT:
                t["alert_count"] += 1
            elif aging > WATCH:
                t["warn_count"] += 1

        for t in tiles.values():
            t["avg_aging"] = round(t.pop("aging_sum") / t["count"], 1) if t["count"] else 0

        watch_count = sum(1 for c in candidates if WATCH < (c.get("aging_days") or 0) <= ALERT)
        stalled_count = sum(1 for c in candidates if (c.get("aging_days") or 0) > ALERT)

        return {
            "tiles": list(tiles.values()),
            "candidates": candidates,
            "scheduled": scheduled,
            "watch_count": watch_count,
            "stalled_count": stalled_count,
        }

    def create_round(self, data: dict) -> dict:
        """Insert a round and point candidate_master.roundid/roundname at it.

        The repoint (+ screened/relocation mirror) is ALSO enforced at the DB by
        the rounds AFTER-INSERT trigger sync_candidate_current_round (schema.sql)
        — the authoritative single-source-of-truth guarantee. The explicit UPDATE
        below sets identical values and is kept as a self-contained, in-process
        fallback. Runs in one transaction so the pointer never dangles.
        """
        cols = [
            "candidate_id", "round_name", "domain", "interviewer",
            "current_ctc", "expected_ctc", "notice_period", "relocation",
            "scheduled_on", "feedback", "score", "outcome",
            "invite_sent_at", "candidate_accepted_slot",
        ]
        vals = [data.get(c) for c in cols]
        placeholders = ", ".join(["%s"] * len(cols))
        insert = (
            f"INSERT INTO rounds ({', '.join(cols)}) VALUES ({placeholders}) RETURNING *"
        )
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(insert, vals)
                row = dict(cur.fetchone())
                cur.execute(
                    """
                    UPDATE candidate_master
                    SET roundid = %s,
                        roundname = %s,
                        relocation = COALESCE(%s, relocation),
                        current_ctc = COALESCE(%s, current_ctc),
                        expected_ctc = COALESCE(%s, expected_ctc),
                        notice_period = COALESCE(%s, notice_period),
                        invite_sent_at = %s,
                        reminder_count = %s,
                        candidate_accepted_slot = %s,
                        screened = TRUE,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE candidate_id = %s
                    """,
                    (row["round_id"], row.get("round_name"),
                     data.get("relocation"), data.get("current_ctc"),
                     data.get("expected_ctc"), data.get("notice_period"),
                     row.get("invite_sent_at"), row.get("reminder_count") or 0,
                     row.get("candidate_accepted_slot"),
                     data["candidate_id"]),
                )
                return row

    def update_round(self, round_id: int, data: dict) -> Optional[dict]:
        # Any round may be edited at any time — there is no lock. The auto-advance
        # below is still gated on the round being the candidate's ACTIVE round, so
        # editing a historical round records its outcome without moving the pointer.
        allowed = [
            "round_name", "domain", "interviewer", "current_ctc", "expected_ctc",
            "notice_period", "relocation", "scheduled_on", "feedback", "score",
            "outcome", "invite_sent_at", "reminder_count", "candidate_accepted_slot",
        ]
        sets, vals = [], []
        for k in allowed:
            if k in data:
                sets.append(f"{k} = %s")
                vals.append(data[k])
        if not sets:
            with get_conn() as conn:
                with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                    cur.execute("SELECT * FROM rounds WHERE round_id = %s", (round_id,))
                    row = cur.fetchone()
                    return dict(row) if row else None
        vals.append(round_id)
        query = (
            "UPDATE rounds SET " + ", ".join(sets)
            + ", updated_at = CURRENT_TIMESTAMP WHERE round_id = %s RETURNING *"
        )
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(query, vals)
                row = cur.fetchone()
                if not row:
                    return None
                row = dict(row)
                cid = row["candidate_id"]

                # Is this the candidate's ACTIVE round? All candidate_master
                # sync below is gated on this so editing an old (historical)
                # round never moves the candidate, which also makes Pass
                # idempotent: advancing repoints roundid away from this round.
                cur.execute(
                    "SELECT roundid, status, stream, include_round3 "
                    "FROM candidate_master WHERE candidate_id = %s",
                    (cid,),
                )
                cand = cur.fetchone()
                is_active = bool(cand) and cand["roundid"] == round_id

                # Persist the interview-plan flag captured on the Screening round (whether
                # the optional Round 3 runs) — it drives auto-advance below and later rounds.
                if "include_round3" in data:
                    cur.execute(
                        "UPDATE candidate_master SET include_round3 = %s, "
                        "updated_at = CURRENT_TIMESTAMP WHERE candidate_id = %s",
                        (data["include_round3"], cid),
                    )
                    if cand:
                        cand["include_round3"] = data["include_round3"]

                # Mirror the screening-call figures (CTC / notice / relocation)
                # onto candidate_master so LATER rounds can display them read-only.
                # These are candidate-level attributes captured on the Screening
                # round, so they must propagate even when Screening is no longer
                # the active round (the DB trigger only syncs the active round, and
                # has no effect once the candidate advances). In-process fallback
                # mirroring create_round; COALESCE keeps it idempotent with the
                # trigger and avoids clobbering existing values with NULLs.
                mirror = {
                    k: data[k]
                    for k in ("current_ctc", "expected_ctc", "notice_period", "relocation")
                    if k in data
                }
                if mirror:
                    set_clause = ", ".join(f"{k} = COALESCE(%s, {k})" for k in mirror)
                    cur.execute(
                        f"UPDATE candidate_master SET {set_clause}, "
                        "updated_at = CURRENT_TIMESTAMP WHERE candidate_id = %s",
                        [*mirror.values(), cid],
                    )

                # Mirror this round's email/acceptance sub-steps onto candidate_master
                # — but ONLY when it's the active round (unlike CTC/relocation above,
                # these describe the CURRENT round's state, not a candidate-level fact
                # that should persist forward once the candidate advances). Direct
                # assign (not COALESCE): an explicit null here (e.g. un-sending an
                # invite) should take effect, not be swallowed.
                if is_active:
                    step_mirror = {
                        k: data[k]
                        for k in ("invite_sent_at", "reminder_count", "candidate_accepted_slot")
                        if k in data
                    }
                    if step_mirror:
                        set_clause = ", ".join(f"{k} = %s" for k in step_mirror)
                        cur.execute(
                            f"UPDATE candidate_master SET {set_clause}, "
                            "updated_at = CURRENT_TIMESTAMP WHERE candidate_id = %s",
                            [*step_mirror.values(), cid],
                        )

                # Keep candidate_master (the single source of truth for current
                # stage) in lock-step: if the active round's name changed,
                # repoint roundname in the same transaction.
                if is_active and "round_name" in data:
                    cur.execute(
                        "UPDATE candidate_master SET roundname = %s, "
                        "updated_at = CURRENT_TIMESTAMP WHERE candidate_id = %s",
                        (row.get("round_name"), cid),
                    )

                current_name = row.get("round_name") or "New"
                outcome = data.get("outcome")
                # Statuses the pipeline owns — never auto-moved by an interview outcome.
                # Everything else (Active and the terminal Hired/Rejected) is
                # recruiter-driven, so the verdict freely follows the round outcome.
                # A reapplication exception (new resume pending, tracked via
                # previously_seen) runs ORTHOGONALLY to the interview loop — the
                # candidate stays Active, so it never freezes them at their stage.
                pipeline_owned = cand["status"] in ("Pending Extraction", "Pending Resume", "Closed")

                if is_active and current_name == "Final" and not pipeline_owned:
                    # The Final round's verdict IS the candidate's terminal lifecycle
                    # status, and it is fully REVERSIBLE — flipping the outcome flips the
                    # status both ways (Pass↔Hired, Fail↔Rejected). The trigger keeps
                    # round_status in sync; we keep the lifecycle status in lock-step so
                    # the badge/Dashboard never show a stale verdict (status wins over
                    # round_status in the frontend). closed_at stays NULL (only 'Closed'
                    # stamps it). round_status is forced to 'Hired' on Pass because the
                    # trigger would otherwise map Pass → 'Cleared'.
                    if outcome == "Pass":
                        cur.execute(
                            "UPDATE candidate_master SET status = 'Hired', "
                            "round_status = 'Hired', closed_at = NULL, "
                            "updated_at = CURRENT_TIMESTAMP WHERE candidate_id = %s",
                            (cid,),
                        )
                    elif outcome == "Fail":
                        cur.execute(
                            "UPDATE candidate_master SET status = 'Rejected', "
                            "closed_at = NULL, updated_at = CURRENT_TIMESTAMP "
                            "WHERE candidate_id = %s",
                            (cid,),
                        )
                    elif outcome in ("Hold", "Pending") and cand["status"] in ("Hired", "Rejected"):
                        # Cleared the verdict (back to undecided) → re-open in-pipeline.
                        cur.execute(
                            "UPDATE candidate_master SET status = 'Active', "
                            "closed_at = NULL, updated_at = CURRENT_TIMESTAMP "
                            "WHERE candidate_id = %s",
                            (cid,),
                        )
                elif is_active and outcome == "Pass" and cand["status"] == "Active":
                    # Mid-round Pass advances along the interview plan: the requested
                    # target if it's allowed (e.g. Round 2 → skip optional Round 3 →
                    # Final), else the planned next. A fresh Pending round is created and
                    # the candidate repointed at it; interviewers are entered manually.
                    domain = cand.get("stream") or row.get("domain")
                    include_r3 = bool(cand.get("include_round3"))
                    requested = data.get("advance_to")
                    if requested and interview_plan.is_valid_advance(current_name, requested, include_r3):
                        target = requested
                    else:
                        target = interview_plan.next_planned_stage(current_name, include_r3)
                    if target:
                        interviewer = interview_plan.interviewer_for(
                            target, domain, data.get("next_interviewer")
                        )
                        cur.execute(
                            "INSERT INTO rounds (candidate_id, round_name, domain, interviewer, outcome) "
                            "VALUES (%s, %s, %s, %s, 'Pending') RETURNING round_id, round_name",
                            (cid, target, row.get("domain"), interviewer),
                        )
                        nxt_round = cur.fetchone()
                        cur.execute(
                            "UPDATE candidate_master SET roundid = %s, roundname = %s, "
                            "screened = TRUE, updated_at = CURRENT_TIMESTAMP "
                            "WHERE candidate_id = %s",
                            (nxt_round["round_id"], nxt_round["round_name"], cid),
                        )
                return row

    def send_round_reminder(self, round_id: int) -> Optional[dict]:
        """Increment a round's reminder_count, capped at 2 ("1/2" → "2/2").
        Atomic (LEAST() in the UPDATE itself, no read-then-write race). Mirrors
        onto candidate_master via the same is-active-gated direct assign as
        update_round's step_mirror (the DB trigger also does this on any UPDATE
        to rounds, this is the in-process fallback)."""
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    "UPDATE rounds SET reminder_count = LEAST(reminder_count + 1, 2), "
                    "updated_at = CURRENT_TIMESTAMP WHERE round_id = %s RETURNING *",
                    (round_id,),
                )
                row = cur.fetchone()
                if not row:
                    return None
                row = dict(row)
                cur.execute(
                    "UPDATE candidate_master SET reminder_count = %s, updated_at = CURRENT_TIMESTAMP "
                    "WHERE candidate_id = %s AND roundid = %s",
                    (row["reminder_count"], row["candidate_id"], round_id),
                )
                return row

    # ── Post-hire onboarding pipeline (Live Workflow) ─────────────────

    def update_candidate_onboarding(
        self,
        candidate_id: str,
        *,
        stage: Optional[str] = None,
        expected_join_date: Optional[str] = None,
        onboarding_date: Optional[str] = None,
        checklist_item: Optional[str] = None,
    ) -> Optional[dict]:
        """Advance the onboarding stage and/or set a date, and/or toggle ONE
        checklist item's done flag. Only fields actually passed are touched —
        callers pass exactly the ones the request set (mirrors update_round's
        `exclude_unset` pattern at the API layer)."""
        from app.stages import DEFAULT_ONBOARDING_CHECKLIST
        import json

        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                sets, vals = [], []
                if stage is not None:
                    sets.append("onboarding_stage = %s")
                    vals.append(stage)
                if expected_join_date is not None:
                    sets.append("expected_join_date = %s")
                    vals.append(expected_join_date or None)
                if onboarding_date is not None:
                    sets.append("onboarding_date = %s")
                    vals.append(onboarding_date or None)
                if checklist_item is not None:
                    cur.execute(
                        "SELECT onboarding_checklist FROM candidate_master WHERE candidate_id = %s",
                        (candidate_id,),
                    )
                    existing = cur.fetchone()
                    checklist = (existing and existing["onboarding_checklist"]) or DEFAULT_ONBOARDING_CHECKLIST
                    checklist = [
                        {**item, "done": not item["done"]} if item["key"] == checklist_item else item
                        for item in checklist
                    ]
                    sets.append("onboarding_checklist = %s")
                    vals.append(json.dumps(checklist))
                if not sets:
                    cur.execute("SELECT * FROM candidate_master WHERE candidate_id = %s", (candidate_id,))
                    row = cur.fetchone()
                    return dict(row) if row else None
                vals.append(candidate_id)
                cur.execute(
                    "UPDATE candidate_master SET " + ", ".join(sets)
                    + ", updated_at = CURRENT_TIMESTAMP WHERE candidate_id = %s RETURNING *",
                    vals,
                )
                row = cur.fetchone()
                return dict(row) if row else None

    # ── Question banks (saved generic question sets) ─────────────────────────

    def question_bank_name_exists(self, name: str) -> bool:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1 FROM question_banks WHERE lower(name) = lower(%s)", (name,))
                return cur.fetchone() is not None

    def create_question_bank(self, data: dict) -> dict:
        cols = [
            "name", "stream", "difficulty", "modes", "question_count",
            "buckets", "summary", "sources", "options", "created_by", "status",
        ]
        jsonb = {"modes", "buckets", "summary", "sources", "options"}
        vals = [
            # options is NOT NULL — coerce a missing/None value to {} so seed +
            # duplicate paths (which don't pass it) don't violate the constraint.
            psycopg2.extras.Json(data.get(c) if data.get(c) is not None else {}) if c == "options"
            else psycopg2.extras.Json(data.get(c)) if c in jsonb else data.get(c)
            for c in cols
        ]
        placeholders = ", ".join(["%s"] * len(cols))
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    f"INSERT INTO question_banks ({', '.join(cols)}) "
                    f"VALUES ({placeholders}) RETURNING *",
                    vals,
                )
                return dict(cur.fetchone())

    def list_question_banks(self, include_archived: bool = False) -> list[dict]:
        where = "" if include_archived else "WHERE status = 'active'"
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    f"SELECT * FROM question_banks {where} ORDER BY created_at DESC"
                )
                return [dict(r) for r in cur.fetchall()]

    def get_question_bank(self, qb_id: int) -> Optional[dict]:
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute("SELECT * FROM question_banks WHERE qb_id = %s", (qb_id,))
                row = cur.fetchone()
                return dict(row) if row else None

    def update_question_bank_buckets(self, qb_id: int, buckets: list, question_count: int) -> Optional[dict]:
        """Replace a bank's questions in place (used by the AI 'enrich' backfill)."""
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    "UPDATE question_banks SET buckets = %s, question_count = %s "
                    "WHERE qb_id = %s RETURNING *",
                    (psycopg2.extras.Json(buckets), question_count, qb_id),
                )
                row = cur.fetchone()
                return dict(row) if row else None

    def delete_question_bank(self, qb_id: int) -> bool:
        """Delete a bank; its allocations + responses cascade (FK ON DELETE CASCADE)."""
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute("DELETE FROM question_banks WHERE qb_id = %s", (qb_id,))
                return cur.rowcount > 0

    # ── Question bank allocations + responses ────────────────────────────────

    _ALLOC_COLS = [
        "qb_id", "candidate_id", "round_id", "round_name", "interviewer",
        "slot_start", "slot_end", "status", "source_tag", "assigned_by",
    ]

    def allocate_question_bank(self, data: dict) -> dict:
        """Assign a bank to a candidate's round, replacing any existing active
        allocation for the same candidate+round (one active bank per interview)."""
        cid = data["candidate_id"]
        rid = data.get("round_id")
        vals = [data.get(c) for c in self._ALLOC_COLS]
        placeholders = ", ".join(["%s"] * len(self._ALLOC_COLS))
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                if rid is None:
                    cur.execute(
                        "DELETE FROM question_bank_allocations WHERE candidate_id = %s "
                        "AND round_id IS NULL AND status IN ('assigned','in_progress')",
                        (cid,),
                    )
                else:
                    cur.execute(
                        "DELETE FROM question_bank_allocations WHERE candidate_id = %s "
                        "AND round_id = %s AND status IN ('assigned','in_progress')",
                        (cid, rid),
                    )
                cur.execute(
                    f"INSERT INTO question_bank_allocations ({', '.join(self._ALLOC_COLS)}) "
                    f"VALUES ({placeholders}) RETURNING *",
                    vals,
                )
                row = dict(cur.fetchone())
                # Mark the bank as having had an active leaderboard — persists even
                # after a discard, so deletion always requires the heightened flow.
                cur.execute(
                    "UPDATE question_banks SET had_allocations = TRUE WHERE qb_id = %s",
                    (data["qb_id"],),
                )
                return row

    def discard_allocations(self, qb_id: int) -> int:
        """Clear a bank's leaderboard — delete every allocation (responses cascade).
        The bank's had_allocations flag is intentionally LEFT set."""
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "DELETE FROM question_bank_allocations WHERE qb_id = %s", (qb_id,)
                )
                return cur.rowcount

    def remove_allocation(self, qb_id: int, allocation_id: int, removed_by: Optional[str] = None) -> bool:
        """Unassign a single candidate from this bank's leaderboard — a SOFT
        delete (status -> 'removed'). The row + any recorded responses/marks are
        KEPT (not cascaded away) so the leaderboard still shows the candidate,
        marked as removed, instead of the record vanishing. Scoped to qb_id so a
        leaderboard can only remove its own rows."""
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "UPDATE question_bank_allocations SET status = 'removed', "
                    "removed_at = CURRENT_TIMESTAMP, removed_by = %s, updated_at = CURRENT_TIMESTAMP "
                    "WHERE qb_id = %s AND allocation_id = %s AND status <> 'removed'",
                    (removed_by, qb_id, allocation_id),
                )
                return cur.rowcount > 0

    def get_candidate_allocation(
        self, candidate_id: str, round_id: Optional[int] = None
    ) -> Optional[dict]:
        """The active allocation for a candidate — preferring one bound to the
        given round, else a still-unbound (pre-assigned) one."""
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                if round_id is not None:
                    cur.execute(
                        "SELECT * FROM question_bank_allocations WHERE candidate_id = %s "
                        "AND (round_id = %s OR round_id IS NULL) "
                        "AND status IN ('assigned','in_progress','collected','scored') "
                        "ORDER BY (round_id = %s) DESC, created_at DESC LIMIT 1",
                        (candidate_id, round_id, round_id),
                    )
                else:
                    cur.execute(
                        "SELECT * FROM question_bank_allocations WHERE candidate_id = %s "
                        "AND status IN ('assigned','in_progress','collected','scored') "
                        "ORDER BY created_at DESC LIMIT 1",
                        (candidate_id,),
                    )
                row = cur.fetchone()
                return dict(row) if row else None

    def get_allocation(self, allocation_id: int) -> Optional[dict]:
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    "SELECT * FROM question_bank_allocations WHERE allocation_id = %s",
                    (allocation_id,),
                )
                row = cur.fetchone()
                return dict(row) if row else None

    def booked_pool_slot_for_round(self, round_id: Optional[int]) -> Optional[dict]:
        """The interviewer + time the candidate actually booked for this round,
        read from the pool placeholder they claimed. This is the reliable source
        of the interviewer NAME on the leaderboard — rounds.interviewer /
        allocation.interviewer are only populated for manual assignments, so a
        pool-booked interview would otherwise show no interviewer at all."""
        if not round_id:
            return None
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    "SELECT interviewer_name, interviewer_email, slot_start, slot_end "
                    "FROM interview_pool_slots WHERE booked_round_id = %s AND status = 'booked' "
                    "ORDER BY slot_start LIMIT 1",
                    (round_id,),
                )
                row = cur.fetchone()
                return dict(row) if row else None

    def deallocate_question_bank(self, candidate_id: str, round_id: Optional[int]) -> None:
        with get_conn() as conn:
            with conn.cursor() as cur:
                if round_id is None:
                    cur.execute(
                        "DELETE FROM question_bank_allocations WHERE candidate_id = %s "
                        "AND status IN ('assigned','in_progress')",
                        (candidate_id,),
                    )
                else:
                    cur.execute(
                        "DELETE FROM question_bank_allocations WHERE candidate_id = %s "
                        "AND round_id = %s AND status IN ('assigned','in_progress')",
                        (candidate_id, round_id),
                    )

    def allocation_summary(self) -> list[dict]:
        """Per-bank allocation counts by status — drives the stage badges on the
        Question Banks page (assigned / in_progress / scored)."""
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    "SELECT qb_id, status, COUNT(*) AS n FROM question_bank_allocations "
                    "GROUP BY qb_id, status"
                )
                return [dict(r) for r in cur.fetchall()]

    def allocation_scope_summary(self) -> list[dict]:
        """Per-bank distinct (source_tag, round_name) combos with counts — which
        cohorts/rounds each bank is currently assigned to, for the bank card."""
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    "SELECT qb_id, source_tag, round_name, COUNT(*) AS n "
                    "FROM question_bank_allocations "
                    "WHERE status IN ('assigned','in_progress','collected','scored') "
                    "GROUP BY qb_id, source_tag, round_name"
                )
                return [dict(r) for r in cur.fetchall()]

    def allocation_score_summary(self) -> list[dict]:
        """Per-bank average score (as a 0–100 percentage) across SCORED
        allocations — a quick-glance quality signal on the bank card."""
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    """
                    SELECT qb_id, AVG(pct) AS avg_score_pct FROM (
                        SELECT a.qb_id, a.allocation_id,
                               100.0 * SUM(COALESCE(r.final_mark, r.ai_mark, 0))
                                   / NULLIF(SUM(COALESCE(r.max_mark, 10)), 0) AS pct
                        FROM question_bank_allocations a
                        JOIN question_bank_responses r ON r.allocation_id = a.allocation_id
                        WHERE a.status = 'scored'
                        GROUP BY a.qb_id, a.allocation_id
                    ) per_alloc
                    GROUP BY qb_id
                    """
                )
                return [dict(r) for r in cur.fetchall()]

    def list_allocations_for_qb(self, qb_id: int) -> list[dict]:
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    "SELECT * FROM question_bank_allocations WHERE qb_id = %s "
                    "ORDER BY created_at DESC",
                    (qb_id,),
                )
                return [dict(r) for r in cur.fetchall()]

    def update_allocation(self, allocation_id: int, data: dict) -> Optional[dict]:
        allowed = ["round_id", "round_name", "interviewer", "slot_start", "slot_end", "status",
                   "answers_locked_at", "marks_locked_at"]
        sets, vals = [], []
        for k in allowed:
            if k in data:
                sets.append(f"{k} = %s")
                vals.append(data[k])
        if not sets:
            return self.get_allocation(allocation_id)
        vals.append(allocation_id)
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    "UPDATE question_bank_allocations SET " + ", ".join(sets)
                    + ", updated_at = CURRENT_TIMESTAMP WHERE allocation_id = %s RETURNING *",
                    vals,
                )
                row = cur.fetchone()
                return dict(row) if row else None

    def save_responses(self, allocation_id: int, rows: list[dict]) -> list[dict]:
        """Replace all per-question responses for an allocation."""
        cols = ["allocation_id", "bucket", "question", "question_index",
                "response_text", "observation", "ai_mark", "ai_rationale",
                "final_mark", "max_mark", "awarded_points"]
        jsonb = {"awarded_points"}
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    "DELETE FROM question_bank_responses WHERE allocation_id = %s",
                    (allocation_id,),
                )
                out = []
                placeholders = ", ".join(["%s"] * len(cols))
                for r in rows:
                    r = {**r, "allocation_id": allocation_id}
                    cur.execute(
                        f"INSERT INTO question_bank_responses ({', '.join(cols)}) "
                        f"VALUES ({placeholders}) RETURNING *",
                        [psycopg2.extras.Json(r.get(c) or []) if c in jsonb else r.get(c) for c in cols],
                    )
                    out.append(dict(cur.fetchone()))
                return out

    def lock_answer(self, allocation_id: int, index: int, bucket: str, question: str,
                    response_text: str, observation: str, max_mark, locked_at) -> dict:
        """PER-QUESTION answer lock — upsert the captured response for one question
        and stamp answer_locked_at (reveals that question's model answer + rubric).
        Leaves the mark fields untouched."""
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    "INSERT INTO question_bank_responses "
                    "(allocation_id, bucket, question, question_index, response_text, observation, max_mark, answer_locked_at) "
                    "VALUES (%s,%s,%s,%s,%s,%s,%s,%s) "
                    "ON CONFLICT (allocation_id, question_index) DO UPDATE SET "
                    "response_text=EXCLUDED.response_text, observation=EXCLUDED.observation, "
                    "bucket=EXCLUDED.bucket, question=EXCLUDED.question, max_mark=EXCLUDED.max_mark, "
                    "answer_locked_at=EXCLUDED.answer_locked_at, updated_at=CURRENT_TIMESTAMP RETURNING *",
                    (allocation_id, bucket, question, index, response_text, observation, max_mark, locked_at),
                )
                return dict(cur.fetchone())

    def lock_mark(self, allocation_id: int, index: int, final_mark, awarded_points,
                  max_mark, ai_mark, ai_rationale, locked_at) -> Optional[dict]:
        """PER-QUESTION mark lock — set the mark fields for one already-answer-locked
        question and stamp mark_locked_at (reveals that question's explanation)."""
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    "UPDATE question_bank_responses SET final_mark=%s, awarded_points=%s, max_mark=%s, "
                    "ai_mark=%s, ai_rationale=%s, mark_locked_at=%s, updated_at=CURRENT_TIMESTAMP "
                    "WHERE allocation_id=%s AND question_index=%s RETURNING *",
                    (final_mark, psycopg2.extras.Json(awarded_points or []), max_mark,
                     ai_mark, ai_rationale, locked_at, allocation_id, index),
                )
                row = cur.fetchone()
                return dict(row) if row else None

    def list_responses(self, allocation_id: int) -> list[dict]:
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    "SELECT * FROM question_bank_responses WHERE allocation_id = %s "
                    "ORDER BY question_index",
                    (allocation_id,),
                )
                out = []
                for r in cur.fetchall():
                    d = dict(r)
                    # NUMERIC columns come back as Decimal, which serializes to a
                    # JSON *string* — breaks arithmetic (`.toFixed`) on the client.
                    for k in ("final_mark", "ai_mark", "max_mark"):
                        if isinstance(d.get(k), Decimal):
                            d[k] = float(d[k])
                    out.append(d)
                return out

    def candidates_by_source(
        self, source_label: Optional[str], round_names: Optional[list[str]] = None
    ) -> list[dict]:
        """id + name for every candidate under a source tag — the bulk-assign
        target set on the Question Banks page. A null/empty label matches the
        untagged (source IS NULL) candidates. When round_names is given, only
        candidates currently in one of those rounds are returned — the
        optional round-specific assignment filter."""
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                clause = "source = %s" if source_label else "source IS NULL"
                params: list = [source_label] if source_label else []
                if round_names:
                    clause += " AND roundname = ANY(%s)"
                    params.append(round_names)
                cur.execute(
                    f"SELECT candidate_id, name, roundname FROM candidate_master WHERE {clause} "
                    "ORDER BY candidate_id",
                    params,
                )
                return [dict(r) for r in cur.fetchall()]

    def candidates_rounds(self, candidate_ids: list[str]) -> dict[str, Optional[str]]:
        """candidate_id -> current round name, for an explicit id list — used to
        apply the optional round filter when the caller picked specific candidates
        rather than a whole source tag."""
        if not candidate_ids:
            return {}
        with get_conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    "SELECT candidate_id, roundname FROM candidate_master WHERE candidate_id = ANY(%s)",
                    (candidate_ids,),
                )
                return {r["candidate_id"]: r["roundname"] for r in cur.fetchall()}

    def set_invite_block(self, candidate_id: str, reason: Optional[str]) -> None:
        """Set/clear the blinking-caution message shown next to a candidate when a
        slot-invite auto-send was paused because the slot link couldn't be inserted."""
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "UPDATE candidate_master SET invite_block_reason = %s, "
                    "updated_at = CURRENT_TIMESTAMP WHERE candidate_id = %s",
                    (reason, candidate_id),
                )
