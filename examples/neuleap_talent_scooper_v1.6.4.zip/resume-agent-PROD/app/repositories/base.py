"""Repository interface for the data this service owns/reads.

Writes: candidate_master (owned by this service).
Reads : email_master  (owned upstream — read-only here).
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import date
from typing import Optional


class BaseRepository(ABC):

    # ── candidate_master (read/write) ────────────────────────────────

    @abstractmethod
    def get_next_candidate_id(self) -> str: ...

    @abstractmethod
    def get_candidate(self, candidate_id: str) -> Optional[dict]: ...

    @abstractmethod
    def insert_candidate_stub(
        self,
        candidate_id: str,
        s3_file_path: str,
        mail_send_date: date,
        e_id: str,
        name: str = "",
        email: str = "",
        phno: str = "",
        file_hash: Optional[str] = None,
        l2_text: Optional[str] = None,
        l2_text_complete: Optional[bool] = None,
        source: Optional[str] = None,
    ) -> None: ...

    @abstractmethod
    def update_candidate_resume(self, candidate_id: str, s3_file_path: str) -> None: ...

    @abstractmethod
    def flag_candidate_reapplication(
        self, candidate_id: str, incoming_s3_key: str
    ) -> None: ...

    @abstractmethod
    def get_all_candidates(self) -> list[dict]: ...

    @abstractmethod
    def archive_eligible(self) -> dict: ...

    # ── email_master (read-only) ─────────────────────────────────────

    @abstractmethod
    def get_passed_emails(self) -> list[dict]: ...

    @abstractmethod
    def get_email(self, e_id: str) -> Optional[dict]: ...

    # ── D10: idempotency (processed flag, written by the orchestrator) ─────

    @abstractmethod
    def passed_unprocessed_eids(self) -> list[str]: ...

    @abstractmethod
    def mark_processed(self, e_id: str) -> None: ...
