from __future__ import annotations

from typing import Optional

from app.repositories.base import BaseRepository

_repo: Optional[BaseRepository] = None


def repo() -> BaseRepository:
    """Module-level singleton — PostgreSQL is the only backend."""
    global _repo
    if _repo is None:
        from app.repositories.pg_repo import PostgresRepository
        _repo = PostgresRepository()
    return _repo
