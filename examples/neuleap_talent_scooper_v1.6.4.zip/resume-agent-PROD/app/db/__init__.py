"""PostgreSQL access shared by both layers.

* ``connect`` / ``init_db``                — connection + schema bootstrap.
* ``get_candidate`` / ``upsert_candidate_input`` / ``update_candidate_from_result``
  — L3 extraction helpers (ported from resume_microservice/db.py).

L2's repository (``repositories/pg_repo.py``) also reuses ``connect()``.
"""
from __future__ import annotations

import json
import logging
import re
import threading
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Dict, Optional

import psycopg2
import psycopg2.extras
from psycopg2 import pool as pg_pool

from app.config import settings

logger = logging.getLogger(__name__)

SCHEMA_PATH = Path(__file__).resolve().parent / "schema.sql"


def _db_config(database: bool = True) -> Dict[str, Any]:
    from app.services.clock import tz_name

    config: Dict[str, Any] = {
        "host": settings.pg_host,
        "port": settings.pg_port,
        "user": settings.pg_user,
        "password": settings.pg_password,
        # Decode text as UTF-8 regardless of the container locale. Without this,
        # libpq falls back to the locale (often SQL_ASCII) and psycopg2 hands back
        # mojibake for any non-ASCII byte (e.g. "·" → "Â·", accented names).
        "client_encoding": "UTF8",
        # Pin every session to the business timezone (IST by default) so that
        # CURRENT_TIMESTAMP — which fills created_at/updated_at/parsed_at/archived_at
        # on TIMESTAMP columns across the batch/pipeline tables — is wall-clock IST.
        "options": f"-c timezone={tz_name()}",
    }
    config["dbname"] = settings.pg_database if database else "postgres"
    return config


def connect(database: bool = True):
    """Open a standalone connection (used by the seed script)."""
    return psycopg2.connect(**_db_config(database))


# ── Connection pool ──────────────────────────────────────────────────────────

_pool: Optional[pg_pool.ThreadedConnectionPool] = None
_pool_lock = threading.Lock()


def _get_pool() -> pg_pool.ThreadedConnectionPool:
    global _pool
    if _pool is None:
        with _pool_lock:
            if _pool is None:
                _pool = pg_pool.ThreadedConnectionPool(
                    minconn=1, maxconn=16, **_db_config()
                )
    return _pool


@contextmanager
def get_conn():
    """Borrow a pooled connection; commit on success, rollback on error, return it."""
    pool = _get_pool()
    conn = pool.getconn()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        pool.putconn(conn)


def _apply_additive_columns(schema: str) -> None:
    """Run every ``ALTER TABLE … ADD COLUMN IF NOT EXISTS …`` statement on its OWN
    autocommit transaction, BEFORE the full script.

    The whole schema.sql runs as a single transaction in :func:`init_db`, so if a
    later, data-dependent statement fails (notably the email-dedup / unique-index
    block, which can choke on a particular DB's data) the entire transaction rolls
    back — silently undoing the additive column migrations too. That stranded the
    DB without ``pipeline_processed_at``, so EVERY L3 write failed with
    ``UndefinedColumn``. Applying the idempotent column adds independently first means
    the columns the app requires always exist, regardless of the rest of the script.
    """
    statements = re.findall(
        r"ALTER\s+TABLE[^;]*?ADD\s+COLUMN\s+IF\s+NOT\s+EXISTS[^;]*;",
        schema,
        flags=re.IGNORECASE,
    )
    if not statements:
        return
    with get_conn() as conn:
        prev_autocommit = conn.autocommit
        conn.autocommit = True  # each ALTER commits on its own; one failure can't roll back the rest
        try:
            with conn.cursor() as cursor:
                for stmt in statements:
                    try:
                        cursor.execute(stmt)
                    except Exception as exc:  # noqa: BLE001 — one bad ALTER mustn't block the rest
                        logger.warning("additive column migration failed (%s): %s",
                                       " ".join(stmt.split())[:90], exc)
        finally:
            conn.autocommit = prev_autocommit


def init_db() -> None:
    """Create candidate_master + sequence. Idempotent — safe on every startup."""
    schema = SCHEMA_PATH.read_text(encoding="utf-8")
    # Land additive column migrations first, each independently committed, so a later
    # failure in the script can't roll them back (see _apply_additive_columns).
    _apply_additive_columns(schema)
    with get_conn() as conn:
        with conn.cursor() as cursor:
            cursor.execute(schema)
    # Seed the Admin + Recruiter login defaults into app_users (deferred import
    # to avoid a circular import: app.services.users imports get_conn from here).
    try:
        from app.services.users import seed_default_users

        seed_default_users()
    except Exception as exc:  # noqa: BLE001 — never let seeding abort startup
        logger.warning("seed_default_users failed at startup: %s", exc)


# ── L3 extraction helpers ───────────────────────────────────────────────────

# Read-time auto-Hold. An Active candidate whose active round is past its
# Scheduled Date with no outcome recorded yet reads as 'Hold' — exactly what a
# recruiter marking Hold produces (rounds.outcome='Hold' → round_status='Hold')
# — but computed on read, with no DB write, so it clears the moment the round is
# rescheduled or given a real outcome. Queries opt in by selecting the active
# round's overdue flag as the helper column ``_auto_hold``.
def resolve_auto_hold(row: Dict[str, Any]) -> Dict[str, Any]:
    """Override ``round_status`` to 'Hold' when the joined ``_auto_hold`` flag is
    set, then drop the helper column. Returns the same row for chaining."""
    if row.pop("_auto_hold", False):
        row["round_status"] = "Hold"
    return row


# Active round's overdue-with-no-outcome flag, exposed as ``_auto_hold`` for
# resolve_auto_hold(). scheduled_on is a date (captured via a date picker, stored
# at midnight), so "date passed" means its DAY is strictly before today — a round
# scheduled FOR today stays In Progress all day and only flips to Hold the next
# day if still unresolved. CURRENT_DATE uses the DB session timezone.
_AUTO_HOLD_SELECT = (
    "(cm.status = 'Active' AND r.scheduled_on IS NOT NULL "
    "AND r.scheduled_on::date < CURRENT_DATE "
    "AND COALESCE(r.outcome, 'Pending') = 'Pending') "
    'AS _auto_hold'
)


def get_candidate(candidate_id: str) -> Optional[Dict[str, Any]]:
    # e_id AS "E_id" keeps the API response aligned with the SPA's type while
    # the original lowercase e_id key stays available for internal callers.
    query = (
        f'SELECT cm.*, cm.e_id AS "E_id", {_AUTO_HOLD_SELECT} '
        "FROM candidate_master cm "
        "LEFT JOIN rounds r ON r.round_id = cm.roundid "
        "WHERE cm.candidate_id = %s"
    )
    with get_conn() as conn:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cursor:
            cursor.execute(query, (candidate_id,))
            row = cursor.fetchone()
            return resolve_auto_hold(dict(row)) if row else None


def upsert_candidate_input(
    *,
    candidate_id: str,
    s3_file_path: str,
    mail_send_date: Optional[str] = None,
    e_id: Optional[str] = None,
) -> None:
    query = """
        INSERT INTO candidate_master (
            candidate_id, s3_file_path, mail_send_date, e_id, status
        ) VALUES (%s, %s, %s, %s, 'Pending Extraction')
        ON CONFLICT (candidate_id) DO UPDATE SET
            s3_file_path = EXCLUDED.s3_file_path,
            mail_send_date = EXCLUDED.mail_send_date,
            e_id = EXCLUDED.e_id,
            status = 'Pending Extraction',
            failure_reason = NULL
    """
    with get_conn() as conn:
        with conn.cursor() as cursor:
            cursor.execute(query, (candidate_id, s3_file_path, mail_send_date, e_id))


def _json_or_none(value: Any) -> Optional[str]:
    if value is None:
        return None
    return json.dumps(value, ensure_ascii=False)


def save_intake_excel_columns(e_id: str, stored_name: str, row_cells: Dict[str, Any]) -> None:
    """L1: stash an Excel row's full column set, keyed by the email item + the
    resume file it produced, so L3 can attach it to the candidate once the resume
    is extracted. Upsert — a re-run of the same file just refreshes the cells."""
    if not e_id or not stored_name or not row_cells:
        return
    with get_conn() as conn:
        with conn.cursor() as cursor:
            cursor.execute(
                "INSERT INTO intake_excel_columns (e_id, stored_name, row_cells) "
                "VALUES (%s, %s, %s) "
                "ON CONFLICT (e_id, stored_name) DO UPDATE "
                "SET row_cells = EXCLUDED.row_cells, created_at = CURRENT_TIMESTAMP",
                (e_id, stored_name, json.dumps(row_cells, ensure_ascii=False)),
            )


def pop_intake_excel_columns(e_id: str, stored_name: str) -> Optional[Dict[str, Any]]:
    """L3: fetch AND delete the carried Excel columns for one resume file (a
    one-shot handoff — once attached to the candidate the carrier row is done).
    Returns the {header: value} dict, or None when this file wasn't Excel-sourced."""
    if not e_id or not stored_name:
        return None
    with get_conn() as conn:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cursor:
            cursor.execute(
                "DELETE FROM intake_excel_columns WHERE e_id = %s AND stored_name = %s "
                "RETURNING row_cells",
                (e_id, stored_name),
            )
            row = cursor.fetchone()
    return dict(row["row_cells"]) if row and isinstance(row["row_cells"], dict) else None


def update_candidate_from_result(candidate_id: str, result: Dict[str, Any]) -> None:
    """Write the L3 extraction + ATS result onto an existing candidate row.

    Overwrites name/email/phno (contact precedence: LLM wins). When the row
    was created by L2, its deterministic contact values remain if this row
    is never updated (e.g. extraction skipped) or are replaced on success.
    """
    candidate = result.get("candidate") or {}
    ats = result.get("ats") or {}
    usage = result.get("usage") or {}
    is_success = result.get("status") == "success"

    fields = {
        "name": candidate.get("name"),
        "email": candidate.get("email"),
        "phno": candidate.get("phno"),
        "stream": candidate.get("stream"),
        "clg": candidate.get("clg"),
        "highest_coursecompleted": candidate.get("highest_coursecompleted"),
        "education_status": candidate.get("education_status"),
        "passoutyr": candidate.get("passoutyr"),
        "cgpa": candidate.get("cgpa"),
        "domain": candidate.get("domain"),
        "yearofexp": candidate.get("yearofexp"),
        "priority": candidate.get("priority"),
        "fresher_or_lateral": candidate.get("fresher_or_lateral"),
        "total_companieswitched": candidate.get("total_companieswitched") or 0,
        # Career gap and Year of experience — STORED SEPARATELY. Each column is written
        # from its own deterministically-computed value (app.services.timeline); updating
        # one never mutates the other. careergap/yearofexp stay the human-facing summaries.
        "careergap": candidate.get("careergap"),
        "gap_months": candidate.get("gap_months"),
        "gap_count": candidate.get("gap_count"),
        "gap_ranges": _json_or_none(candidate.get("gap_ranges", [])),
        "experience_months": candidate.get("experience_months"),
        "experience_method": candidate.get("experience_method"),
        "experience_confidence": candidate.get("experience_confidence"),
        "timeline": _json_or_none(candidate.get("timeline", [])),
        "currentcompany": candidate.get("currentcompany"),
        "currentlocation": candidate.get("currentlocation"),
        "job_roles": _json_or_none(candidate.get("job_roles", [])),
        "projects": _json_or_none(candidate.get("projects", [])),
        "primary_skills": _json_or_none(candidate.get("primary_skills", [])),
        "certificates": _json_or_none(candidate.get("certificates", [])),
        "atsscore": ats.get("atsscore"),
        "recommendation": ats.get("recommendation"),
        "role_context": ats.get("role_context"),
        "analysis": ats.get("analysis"),
        "evidence_snippets": _json_or_none(ats.get("evidence_snippets", [])),
        # Recruiter-facing 5-point screening summary (model-owned) — rendered as the
        # "Analysis Report" card on the candidate profile.
        "analysis_report": _json_or_none(ats.get("analysis_report")),
        # Deterministic ATS transparency — structured so the UI renders risk signals
        # and the score breakdown without parsing the `analysis` text.
        "score_breakdown": _json_or_none(ats.get("score_breakdown", [])),
        "score_penalties": _json_or_none(ats.get("score_penalties", [])),
        "certification_bonus": _json_or_none(ats.get("certification_bonus", {})),
        # L3 token usage (per-resume); aggregated per mail by the Intake endpoint.
        "prompt_tokens": usage.get("prompt_tokens"),
        "completion_tokens": usage.get("completion_tokens"),
        "total_tokens": usage.get("total_tokens"),
        "raw_response": _json_or_none(result),
        # Extra columns carried from an Excel intake source (keyed
        # "<header>__from-source-sheet" + optional "CGPA__from-resume"), attached
        # by app.extraction.runner just before this write. None for non-Excel rows.
        "source_columns": _json_or_none(result.get("source_columns")),
        # Map the L3 pipeline outcome onto the recruiter lifecycle the dashboard
        # uses. Both a clean extraction AND a failed one land as "Active": a failed
        # extraction is surfaced for a human via its review_queue row (kind
        # extraction_fail) + failure_reason, not via a separate candidate status.
        "status": "Active",
        "screened": False,
        "failure_reason": result.get("failure_reason"),
    }

    assignments = ", ".join(f"{field} = %s" for field in fields)
    parsed_at_clause = "parsed_at = CURRENT_TIMESTAMP," if is_success else ""
    query = f"""
        UPDATE candidate_master
        SET {assignments},
            {parsed_at_clause}
            -- Stamped on every pipeline run (success or not) so the Screening
            -- list can age a New candidate from when the pipeline last touched it.
            pipeline_processed_at = CURRENT_TIMESTAMP,
            updated_at = CURRENT_TIMESTAMP
        WHERE candidate_id = %s
    """
    values = list(fields.values()) + [candidate_id]
    with get_conn() as conn:
        with conn.cursor() as cursor:
            cursor.execute(query, values)


def update_candidate_analysis_report(candidate_id: str, analysis_report: Optional[Dict[str, Any]]) -> None:
    """Writes ONLY analysis_report — the lighter sibling to
    update_candidate_from_result, for app.extraction.runner.regenerate_analysis_report
    (re-running just the Analysis Report prompt, e.g. after editing it in
    Settings, without touching any other extracted field)."""
    with get_conn() as conn:
        with conn.cursor() as cursor:
            cursor.execute(
                "UPDATE candidate_master SET analysis_report = %s, updated_at = CURRENT_TIMESTAMP "
                "WHERE candidate_id = %s",
                (_json_or_none(analysis_report), candidate_id),
            )
