"""PostgreSQL persistence for Layer 1 — ``email_master`` (the 7 spec columns).

Single DB library = **psycopg2**. This module reuses the shared connection pool
in :mod:`app.db` (the same pool L2/L3 use) and the unified ``schema.sql`` that
creates ``email_master`` + ``eid_seq``. SQLAlchemy has been removed.

A persistent sequence ``eid_seq`` mints ``E100, E101, …`` so an E_id is never
reused across runs.

Everything degrades to no-ops / an in-memory fallback when PostgreSQL is not
reachable (e.g. offline LangGraph unit tests), so the pipeline still runs.
"""

from __future__ import annotations

import os
import threading
from typing import Any, Optional

import psycopg2.extras

from app.config import NO_SOURCE_TAG
from app.logging_config import get_logger
from app.services import clock

log = get_logger(__name__)

_enabled: Optional[bool] = None
_enabled_lock = threading.Lock()
_fallback_counter = 100  # used only when no DB is present (keeps tests stable)


# --------------------------------------------------------------------------- #
# Connection gating (lazy, cached) — reuses app.db's psycopg2 pool
# --------------------------------------------------------------------------- #

def _get_conn():
    """Borrow a pooled connection from the shared app.db pool."""
    from app.db import get_conn
    return get_conn()


def is_enabled() -> bool:
    """True when PostgreSQL is reachable. Cached after the first probe.

    Set ``NEULEAP_DISABLE_DB=1`` to force the DB-less path (offline tests).
    """
    global _enabled
    if _enabled is None:
        with _enabled_lock:
            if _enabled is None:
                if os.environ.get("NEULEAP_DISABLE_DB") == "1":
                    _enabled = False
                else:
                    try:
                        with _get_conn() as conn:
                            with conn.cursor() as cur:
                                cur.execute("SELECT 1")
                        _enabled = True
                    except Exception as exc:  # noqa: BLE001
                        log.info("PostgreSQL unavailable — L1 running DB-less: %s", exc)
                        _enabled = False
    return _enabled


def init_db() -> bool:
    """Create all tables via the unified schema (idempotent). Returns enabled."""
    if not is_enabled():
        log.info("DATABASE unset/unreachable — running without PostgreSQL")
        return False
    from app.db import init_db as _init_all
    _init_all()  # email_master + eid_seq + audit_log + candidate_master
    return True


# --------------------------------------------------------------------------- #
# E_id minting
# --------------------------------------------------------------------------- #

def next_eid() -> str:
    """Mint the next ``E<n>`` id from the Postgres sequence (or a fallback)."""
    global _fallback_counter
    if is_enabled():
        try:
            with _get_conn() as conn:
                with conn.cursor() as cur:
                    cur.execute("SELECT nextval('eid_seq')")
                    n = cur.fetchone()[0]
            return f"E{n}"
        except Exception as exc:  # noqa: BLE001
            log.warning("eid_seq nextval failed, using fallback: %s", exc)
    n = _fallback_counter
    _fallback_counter += 1
    return f"E{n}"


# --------------------------------------------------------------------------- #
# email_master writers / readers
# --------------------------------------------------------------------------- #

# ``source`` is never persisted NULL: an untagged mail falls back to the canonical
# NO_SOURCE_TAG bucket. The raw value is still passed as NULL (not pre-defaulted) so
# the COALESCE precedence holds — a NEW real tag wins; else an EXISTING real tag is
# preserved on re-upsert; else "No Source Tag". Both the first INSERT and later
# UPDATEs get the fallback, so no row can slip through as NULL.
_UPSERT = f"""
    INSERT INTO email_master (
        e_id, sender_mail_id, subject, received_date,
        attachment_names, extracted_status, process_status, source
    ) VALUES (%s, %s, %s, %s, %s, %s, %s, COALESCE(%s, '{NO_SOURCE_TAG}'))
    ON CONFLICT (e_id) DO UPDATE SET
        sender_mail_id   = EXCLUDED.sender_mail_id,
        subject          = EXCLUDED.subject,
        received_date    = EXCLUDED.received_date,
        attachment_names = EXCLUDED.attachment_names,
        extracted_status = EXCLUDED.extracted_status,
        process_status   = EXCLUDED.process_status,
        source           = COALESCE(%s, email_master.source, '{NO_SOURCE_TAG}')
"""


def upsert_email_master(row: dict[str, Any]) -> None:
    """Persist one Email_Master row (idempotent upsert on E_id) — the 7 spec
    columns plus the recruiter-typed intake source (8th, defaulted to the
    NO_SOURCE_TAG bucket when absent)."""
    if not is_enabled():
        return
    candidate_source = row.get("candidate_source")
    with _get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(_UPSERT, (
                row["E_id"], row["sender_mail_id"], row["subject"],
                row["received_date"], row["attachment_names"],
                row["extracted_status"], row["process_status"],
                candidate_source,   # VALUES source (first insert)
                candidate_source,   # UPDATE source (re-upsert precedence)
            ))


def _row_dict(r: dict[str, Any]) -> dict[str, Any]:
    """Map a DB row (e_id) to the API shape (E_id) used by handoff/range readers."""
    return {
        "E_id": r["e_id"], "sender_mail_id": r["sender_mail_id"], "subject": r["subject"],
        "received_date": r["received_date"], "attachment_names": r["attachment_names"],
        "extracted_status": r["extracted_status"], "process_status": r["process_status"],
    }


def passed_eids() -> set[str]:
    """E_ids already finished successfully (process_status = Passed)."""
    if not is_enabled():
        return set()
    with _get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT e_id FROM email_master WHERE process_status = 'Passed'")
            return {r[0] for r in cur.fetchall()}


def status_by_eid() -> dict[str, str]:
    """Map every known E_id -> process_status (for pending derivation)."""
    if not is_enabled():
        return {}
    with _get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT e_id, process_status FROM email_master")
            return dict(cur.fetchall())


def is_passed(e_id: str) -> bool:
    return e_id in passed_eids()


def get_email_master_range(e_id_start: str, e_id_end: str) -> list[dict[str, Any]]:
    """All Email_Master rows whose numeric E_id falls in [start, end]."""
    if not is_enabled():
        return []
    lo, hi = sorted((_eid_int(e_id_start), _eid_int(e_id_end)))
    with _get_conn() as conn:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute("SELECT * FROM email_master")
            rows = [dict(r) for r in cur.fetchall()]
    out = [_row_dict(r) for r in rows if lo <= _eid_int(r["e_id"]) <= hi]
    return sorted(out, key=lambda d: _eid_int(d["E_id"]))


def passed_in_range(e_id_start: str, e_id_end: str) -> list[dict[str, Any]]:
    """Passed (Success/Partial) Email_Master rows in [start, end] — for handoff."""
    return [r for r in get_email_master_range(e_id_start, e_id_end)
            if r["process_status"] == "Passed"]


def _eid_int(e_id: str) -> int:
    """Extract the integer suffix of an E_id ('E123' -> 123)."""
    digits = "".join(ch for ch in str(e_id) if ch.isdigit())
    return int(digits) if digits else 0


def now_iso() -> str:
    return clock.now_iso()
