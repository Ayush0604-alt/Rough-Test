-- Unified schema for the merged app (L1 + L2 + L3), one PostgreSQL database.
--
-- Single DB library = psycopg2 (SQLAlchemy dropped). This file is the ONE place
-- every table/sequence is created, applied by app.db.init_db() on startup.
-- L1 (neuleap_layer1) writes email_master + audit_log via the same psycopg2 pool;
-- L2/L3 own candidate_master; L4 owns rounds.
--
-- Clean consolidated schema: every column lives in its CREATE TABLE. All objects
-- use IF NOT EXISTS / CREATE OR REPLACE so init_db() is safe to run on every
-- startup of a FRESH database. (Migrations/backfills for pre-existing databases
-- are intentionally omitted from this clean cut.)

-- ─────────────────────────────────────────────────────────────────────────────
-- L1: email_master (7 spec columns + queue-driven intake columns) + E_id generator
-- ─────────────────────────────────────────────────────────────────────────────
CREATE SEQUENCE IF NOT EXISTS eid_seq START 100;

CREATE TABLE IF NOT EXISTS email_master (
    e_id                TEXT NOT NULL PRIMARY KEY,   -- 1. E100 (PK)
    sender_mail_id      TEXT NULL,                   -- 2. from address
    subject             TEXT NULL,                   -- 3. raw subject
    received_date       TEXT NULL,                   -- 4. ISO-8601 / "unknown"
    attachment_names    TEXT NULL,                   -- 5. comma-separated final names
    extracted_status    TEXT NULL,                   -- 6. Success|Partial(N/M)|Fail
    process_status      TEXT NULL,                   -- 7. Passed|Failed
    -- D10: per-mail idempotency flag set by the orchestrator after L2+L3 finish.
    processed           BOOLEAN NOT NULL DEFAULT FALSE,
    processed_at        TIMESTAMP NULL,
    -- Queue-driven Layer 1 (intake → queue → process → store → audit). extraction_status
    -- uses the queue vocabulary: QUEUED | PROCESSING | SUCCESS | FAILED | EXHAUSTED.
    run_id              TEXT NULL,
    attachment_type     TEXT NULL,                   -- PDF|DOCX|ZIP|EXCEL|LINK|IMAGE|MIXED|NONE
    file_path           TEXT NULL,                   -- raw/YYYY/MM/DD/{e_id}/
    extraction_status   TEXT NULL,                   -- QUEUED|PROCESSING|SUCCESS|FAILED|EXHAUSTED
    retry_count         INT NOT NULL DEFAULT 0,
    error_reason        TEXT NULL,
    -- Mail intake dedup key: provider message id so the same mail never creates two rows.
    source_message_id   TEXT NULL,
    -- Recruiter-typed "where did this batch come from" (e.g. "LinkedIn", "Naukri",
    -- "Referral - Jane"), mandatory on the manual "Add to Intake queue" upload —
    -- copied onto every candidate_master row produced from this email/batch.
    source              TEXT NULL,
    created_at          TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_email_extraction_status ON email_master (extraction_status);
CREATE INDEX IF NOT EXISTS idx_email_run               ON email_master (run_id);
-- One row per source message (partial unique: rows without a source id are NULL).
CREATE UNIQUE INDEX IF NOT EXISTS uq_email_source_msg
    ON email_master (source_message_id) WHERE source_message_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_email_process_status ON email_master (process_status);
CREATE INDEX IF NOT EXISTS idx_email_unprocessed    ON email_master (process_status, processed);

-- ─────────────────────────────────────────────────────────────────────────────
-- D11: shared audit ledger — all three layers write here (L1 ledger promoted).
--   batch row : layer='BATCH', step='run', fail_count = mail_count
--   stage rows: layer in (L1, L2, L3), candidate_id set downstream
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS audit_log (
    log_id        BIGSERIAL PRIMARY KEY,
    batch_id      TEXT NULL,        -- the ONE correlation id
    e_id          TEXT NULL,
    candidate_id  TEXT NULL,
    layer         TEXT NULL,        -- L1 | L2 | L3 | L4 | BATCH
    step          TEXT NULL,
    fail_reason   TEXT NULL,
    status        TEXT NULL,        -- Success|Failed|Retry|Exhausted|Discarded|ManualReview|Info
    fail_count    INT NOT NULL DEFAULT 0,
    -- Candidate pipeline/round bucket the action belongs to (app.stages.BUCKET_ORDER:
    -- New/Screening/Round 1/Round 2/Final/Hired/Reject/Closed). NULL for pre-L4 pipeline
    -- rows written before this column existed, or rows a caller didn't attribute.
    -- Drives the candidate profile's "Actions Audit Log" stage grouping/coloring.
    stage         TEXT NULL,
    -- The email_drafts row this event refers to (draft generated / marked
    -- ready / sent) — lets the Actions Audit Log offer a "view email" button
    -- that opens the EXACT draft this entry is about, not just whichever
    -- draft happens to be latest. NULL for every non-email-lifecycle event.
    draft_id      BIGINT NULL,
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_audit_batch ON audit_log (batch_id);
CREATE INDEX IF NOT EXISTS idx_audit_eid   ON audit_log (e_id);
-- Widen for pre-existing databases (no-op once already applied).
ALTER TABLE audit_log ADD COLUMN IF NOT EXISTS draft_id BIGINT NULL;

-- ─────────────────────────────────────────────────────────────────────────────
-- Review queue — first-class "needs a human" rows. Populated by L1/L2/L3 via
-- review_queue.enqueue(); audit_log stays append-only history. NO foreign keys
-- (the pipeline may enqueue before the email_master row is finalized). The open
-- queue is WHERE state='open' (partial index).
-- See docs/MANUAL_REVIEW_IMPLEMENTATION_LOGIC.md §3.
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS review_queue (
    review_id       BIGSERIAL PRIMARY KEY,
    e_id            TEXT NULL,
    candidate_id    VARCHAR(64) NULL,
    batch_id        TEXT NULL,            -- correlate to the pipeline run
    layer           TEXT NULL,            -- 'L1' | 'L2' | 'L3'
    kind            TEXT NOT NULL,        -- ReviewKind (stored, never parsed from text)
    filename        TEXT NULL,
    raw_s3_key      TEXT NULL,            -- exact raw-bucket key (drives View / Approve)
    reason          TEXT NULL,            -- short human-readable detail
    details         JSONB NULL,           -- structured per-kind payload (excel row, etc.)
    state           TEXT NOT NULL DEFAULT 'open',   -- ReviewState
    resolved_by     TEXT NULL,
    resolved_at     TIMESTAMP NULL,
    resolution_note TEXT NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_review_kind  CHECK (kind IN (
        'invalid_file','excel_row','link_fetch','corrupt','not_resume',
        'duplicate','duplicate_hired','reapplication','extraction_fail','failed','exhausted')),
    CONSTRAINT chk_review_state CHECK (state IN ('open','resolved','discarded','approved'))
);
CREATE INDEX IF NOT EXISTS idx_review_open ON review_queue (state) WHERE state = 'open';
CREATE INDEX IF NOT EXISTS idx_review_eid  ON review_queue (e_id);
CREATE INDEX IF NOT EXISTS idx_review_cand ON review_queue (candidate_id);

-- ─────────────────────────────────────────────────────────────────────────────
-- L2/L3: candidate_master + race-safe candidate-id generator (C1001, C1002, …)
-- ─────────────────────────────────────────────────────────────────────────────
CREATE SEQUENCE IF NOT EXISTS candidate_seq START 1001;

CREATE TABLE IF NOT EXISTS candidate_master (
    candidate_id            VARCHAR(64) NOT NULL PRIMARY KEY,
    -- ── Written by L2 intake (deterministic, regex) ──
    name                    TEXT NULL,
    email                   TEXT NULL,
    phno                    TEXT NULL,
    e_id                    TEXT NULL,          -- string id, e.g. "E100"
    s3_file_path            TEXT NOT NULL,      -- resume/YYYY/MM/DD/{candidate_id}/file
    mail_send_date          DATE NULL,
    -- Copied from email_master.source at L2 stub-write time — the recruiter-typed
    -- "where did this batch come from" tag, carried onto every candidate it produced.
    source                  TEXT NULL,
    previously_seen         BOOLEAN NOT NULL DEFAULT FALSE,
    pending_review_file     TEXT NULL,
    file_hash               TEXT NULL,          -- SHA-256 of stored resume bytes (dedup hash_check)
    -- l2_text / l2_text_complete: text L2 extracted for identity+dedup. When complete
    -- (born-digital, full text) L3 reuses it instead of re-OCR'ing the file twice.
    l2_text                 TEXT NULL,
    l2_text_complete        BOOLEAN NULL,
    -- ── Completed by L3 extraction (LLM) ──
    stream                  TEXT NULL,
    clg                     TEXT NULL,
    highest_coursecompleted TEXT NULL,
    education_status        TEXT NULL,          -- 'completed' | 'pursuing' (highest degree)
    passoutyr               INT NULL,
    cgpa                    FLOAT NULL,         -- highest degree's CGPA/GPA, native scale (0 < x ≤ 10)
    -- Extra per-candidate columns carried over from an Excel/spreadsheet intake
    -- source, keyed "<sheet-header>__from-source-sheet" (plus "CGPA__from-resume"
    -- when an Excel CGPA overrode the resume-extracted one). Selectable on the
    -- Candidates page via the column customizer.
    source_columns          JSONB NULL,
    domain                  TEXT NULL,
    yearofexp               FLOAT NULL,         -- human-facing summary (= experience_months/12)
    priority                VARCHAR(8) NULL,
    -- Recruiter override of the "Next Best Action" suggestion (Dashboard "Update" /
    -- candidate-profile "Proposed Next Best Action" box). {"key": "reject"|"schedule"|
    -- "hold"|"custom", "text": <free-text, only when key="custom">}. NULL = no
    -- override, the ATS-derived suggestion stands.
    next_action_override    JSONB NULL,
    fresher_or_lateral      VARCHAR(32) NULL,
    total_companieswitched  INT NOT NULL DEFAULT 0,
    careergap               TEXT NULL,          -- human-facing summary string
    currentcompany          TEXT NULL,
    currentlocation         TEXT NULL,
    job_roles               JSONB NULL,
    projects                JSONB NULL,
    primary_skills          JSONB NULL,
    certificates            JSONB NULL,         -- [{name, issuer, year}] from L3 extraction
    -- Career gap vs. experience — STORED SEPARATELY and computed INDEPENDENTLY
    -- (app.services.timeline), never inferring one from the other. The structured
    -- columns below are the auditable, machine-readable truth.
    gap_months              INT   NULL,         -- total verified gap (months)
    gap_count               INT   NULL,         -- number of distinct gaps
    gap_ranges              JSONB NULL,         -- [{from,to,months}] explainable breaks
    experience_months       INT   NULL,         -- total verified work (months)
    experience_method       TEXT  NULL,         -- 'computed'|'partial'|'unknown'
    experience_confidence   TEXT  NULL,         -- 'high'|'medium'|'low'
    timeline                JSONB NULL,         -- structured dated activities (source of both)
    -- ── ATS scoring (L3) ──
    atsscore                FLOAT NULL,         -- 0–100 (deterministic, app.services.ats_scoring)
    recommendation          TEXT NULL,
    role_context            TEXT NULL,
    analysis                TEXT NULL,
    evidence_snippets       JSONB NULL,
    -- Deterministic ATS transparency (app.services.ats_scoring): per-component
    -- contribution, the penalties subtracted, and the certificate bonus. Persisted
    -- structured (not just merged into `analysis`) so the UI can render risk signals
    -- and the "why this score" breakdown without parsing free text.
    score_breakdown         JSONB NULL,         -- [{component, weight, subscore, weighted}]
    score_penalties         JSONB NULL,         -- [{points, reason}]
    certification_bonus     JSONB NULL,         -- {points, cap, certs[]}
    -- Recruiter-facing 5-point screening summary (model-owned): experience level,
    -- graduation window, work-start & gap, company projects, vendor certifications.
    analysis_report         JSONB NULL,         -- {experience_level, graduation_and_window, ...}
    -- LLM token usage from the L3 extraction call (one call per resume).
    prompt_tokens           INT NULL,
    completion_tokens       INT NULL,
    total_tokens            INT NULL,
    raw_response            JSONB NULL,
    -- ── L4 screening (recruiter); CTC/notice mirrored from the active round ──
    roundid                 INT NULL,
    roundname               TEXT NULL,
    round_status            TEXT NULL,          -- latest interview verdict, DERIVED from rounds
    -- Interview plan, captured once on the Screening round: whether the optional
    -- Round 3 is part of this candidate's pipeline. Drives auto-advance.
    include_round3          BOOLEAN NULL,
    relocation              BOOLEAN NULL,       -- mirrored from current/active round
    current_ctc             FLOAT NULL,         -- mirrored from the active round
    expected_ctc            FLOAT NULL,         -- mirrored from the active round
    notice_period           INT NULL,           -- days; captured on the Screening round
    -- ── Live Workflow: per-round email/acceptance sub-steps, mirrored from the
    -- ACTIVE round (rounds is the source of truth) — same mirroring pattern as
    -- current_ctc/expected_ctc/notice_period/relocation below. Reset to fresh
    -- (NULL/0/NULL) whenever the candidate advances into a NEW round, since these
    -- describe THIS round's invite/acceptance state, not an accumulated total.
    invite_sent_at          TIMESTAMP NULL,
    reminder_count          INT NOT NULL DEFAULT 0,
    candidate_accepted_slot BOOLEAN NULL,
    -- ── Post-hire onboarding pipeline (Live Workflow) — tracked in PARALLEL to
    -- `status` ('Hired' never changes/becomes non-terminal). NULL until a Hired
    -- candidate's onboarding actually starts. See app.stages.ONBOARDING_STAGE_ORDER.
    onboarding_stage        TEXT NULL,
    expected_join_date      DATE NULL,
    onboarding_date         DATE NULL,
    onboarding_checklist    JSONB NULL,         -- [{key, label, done}], fixed standard set
    -- ── Lifecycle ──
    status                  VARCHAR(32) NOT NULL DEFAULT 'Pending Extraction',
    failure_reason          TEXT NULL,
    screened                BOOLEAN NOT NULL DEFAULT FALSE,  -- set true once any round exists
    closed_at               TIMESTAMP NULL,     -- set when status -> Closed (archival clock)
    parsed_at               TIMESTAMP NULL,
    -- Refreshed every time the extraction pipeline (L3) processes this candidate.
    -- Anchors "Aging" for a New candidate (not yet in a round): days since the
    -- pipeline last touched the row. Once the candidate enters a round, round
    -- aging (analytics_rounds) takes over.
    pipeline_processed_at   TIMESTAMP NULL,
    created_at              TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at              TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_candidate_status ON candidate_master (status);
CREATE INDEX IF NOT EXISTS idx_candidate_email  ON candidate_master (email);

-- ─────────────────────────────────────────────────────────────────────────────
-- L4: rounds — interview rounds per candidate (full history). candidate_master
-- .roundid/.roundname point at the current/active round.
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS rounds (
    round_id        BIGSERIAL PRIMARY KEY,
    candidate_id    VARCHAR(64) NOT NULL REFERENCES candidate_master (candidate_id),
    round_name      TEXT NULL,          -- New | Round 1 | Round 2 | Screening | Final
    domain          TEXT NULL,          -- GenAI | Data Engineering
    interviewer     TEXT NULL,
    current_ctc     FLOAT NULL,         -- filled during screening call
    expected_ctc    FLOAT NULL,
    notice_period   INT NULL,           -- days; captured on the Screening round
    relocation      BOOLEAN NULL,
    scheduled_on    TIMESTAMP NULL,
    feedback        TEXT NULL,          -- post-interview notes
    score           FLOAT NULL,         -- interviewer score 0–10
    outcome         TEXT NULL,          -- Pass | Fail | Hold | Pending
    -- Live Workflow email/acceptance sub-steps for THIS round (every round type —
    -- Screening/Round 1/Round 2/Final — gets the same tracking).
    invite_sent_at          TIMESTAMP NULL,      -- interview invite emailed
    reminder_count          INT NOT NULL DEFAULT 0,  -- reminder emails sent, capped at 2
    candidate_accepted_slot BOOLEAN NULL,        -- did the candidate accept their picked slot?
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_rounds_candidate ON rounds (candidate_id);

-- ─────────────────────────────────────────────────────────────────────────────
-- SINGLE SOURCE OF TRUTH (schema-enforced): the rounds table drives a
-- candidate's current stage. This trigger keeps candidate_master.roundid /
-- roundname — the field BOTH the Rounds board and the Screening page read —
-- in lock-step with rounds, so the two views can never disagree no matter which
-- code path (API, seed script, manual SQL) writes a round.
--
--   • INSERT a round  → it becomes the candidate's current stage.
--   • Rename the ACTIVE round → candidate_master.roundname follows it.
--   • Change the ACTIVE round's outcome → candidate_master.round_status follows it.
--     (Editing a historical round never moves the candidate.)
--
-- round_status is mapped from the active round's outcome:
--   Fail → 'Rejected', Hold → 'Hold', Pass → 'Cleared', else (Pending/null) →
--   'In Progress'. The terminal 'Hired' verdict is written by the repository when
--   a candidate passes the Final round (Offer), so it is preserved there.
-- ─────────────────────────────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION sync_candidate_current_round() RETURNS TRIGGER AS $$
DECLARE
    v_round_status TEXT := CASE
        WHEN NEW.outcome = 'Fail' THEN 'Rejected'
        WHEN NEW.outcome = 'Hold' THEN 'Hold'
        WHEN NEW.outcome = 'Pass' THEN 'Cleared'
        ELSE 'In Progress'
    END;
BEGIN
    IF (TG_OP = 'INSERT') THEN
        UPDATE candidate_master
           SET roundid       = NEW.round_id,
               roundname     = NEW.round_name,
               round_status  = v_round_status,
               screened      = TRUE,
               relocation    = COALESCE(NEW.relocation, relocation),
               current_ctc   = COALESCE(NEW.current_ctc, current_ctc),
               expected_ctc  = COALESCE(NEW.expected_ctc, expected_ctc),
               notice_period = COALESCE(NEW.notice_period, notice_period),
               -- Per-round sub-steps reset to THIS (new) round's fresh state —
               -- direct assign, never coalesced forward from a prior round.
               invite_sent_at          = NEW.invite_sent_at,
               reminder_count          = NEW.reminder_count,
               candidate_accepted_slot = NEW.candidate_accepted_slot,
               updated_at    = CURRENT_TIMESTAMP
         WHERE candidate_id = NEW.candidate_id;
    ELSIF (TG_OP = 'UPDATE') THEN
        -- Keep candidate_master in lock-step with edits to its ACTIVE round:
        -- roundname follows a rename, round_status follows the outcome, CTC
        -- follows the screening-call figures, and the sub-steps mirror this
        -- round's current invite/reminder/acceptance state directly.
        UPDATE candidate_master
           SET roundname     = NEW.round_name,
               round_status  = v_round_status,
               current_ctc   = COALESCE(NEW.current_ctc, current_ctc),
               expected_ctc  = COALESCE(NEW.expected_ctc, expected_ctc),
               notice_period = COALESCE(NEW.notice_period, notice_period),
               invite_sent_at          = NEW.invite_sent_at,
               reminder_count          = NEW.reminder_count,
               candidate_accepted_slot = NEW.candidate_accepted_slot,
               updated_at    = CURRENT_TIMESTAMP
         WHERE candidate_id = NEW.candidate_id
           AND roundid      = NEW.round_id;   -- only when it's the active round
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_sync_candidate_current_round ON rounds;
CREATE TRIGGER trg_sync_candidate_current_round
    AFTER INSERT OR UPDATE ON rounds
    FOR EACH ROW EXECUTE FUNCTION sync_candidate_current_round();

-- ─────────────────────────────────────────────────────────────────────────────
-- L4 archival: nightly job moves eligible rows here. Same columns + archived_at.
-- S3 files are retained forever (never deleted), so reapplication match still works.
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS candidate_master_archive (
    LIKE candidate_master INCLUDING DEFAULTS,
    archived_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS rounds_archive (
    LIKE rounds INCLUDING DEFAULTS,
    archived_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Batch archival (app.services.batch_archive): a recruiter archives every
-- candidate/email sharing one `source` tag (or the whole "no source" bucket) in
-- one action from Mailbox → Batch Archive. Same move-not-flag pattern as the
-- per-candidate archive above, extended to email_master so the Mailbox history
-- for an archived batch clears too. Restorable (unlike the per-candidate path,
-- which has no restore endpoint) — see batch_archive.restore_batch().
CREATE TABLE IF NOT EXISTS email_master_archive (
    LIKE email_master INCLUDING DEFAULTS,
    archived_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ─────────────────────────────────────────────────────────────────────────────
-- Email drafts — generated when the recruiter picks an NBA option whose "Agent
-- action" sends an ack-email (call_now / undecided / office_interview /
-- final_round). One draft per NBA selection; the recruiter reviews it (may edit
-- subject/body) and flips status 'draft' → 'ready'. NOT wired to an actual send —
-- 'ready' is as far as this goes today. No FK to candidate_master (same reasoning
-- as audit_log/review_queue): archival deletes the candidate_master row, and a
-- draft should survive as history regardless.
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS email_drafts (
    draft_id     BIGSERIAL PRIMARY KEY,
    candidate_id TEXT NOT NULL,
    nba_key      TEXT NOT NULL,
    subject      TEXT NOT NULL,
    body         TEXT NOT NULL,
    status       TEXT NOT NULL DEFAULT 'draft',
    sent_at      TIMESTAMP NULL,
    created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_email_draft_status CHECK (status IN ('draft', 'ready', 'sent'))
);
CREATE INDEX IF NOT EXISTS idx_email_drafts_candidate ON email_drafts (candidate_id);
-- Widen for pre-existing databases + add sent_at (both no-ops once already applied).
ALTER TABLE email_drafts ADD COLUMN IF NOT EXISTS sent_at TIMESTAMP NULL;
ALTER TABLE email_drafts DROP CONSTRAINT IF EXISTS chk_email_draft_status;
ALTER TABLE email_drafts ADD CONSTRAINT chk_email_draft_status CHECK (status IN ('draft', 'ready', 'sent'));

-- ─────────────────────────────────────────────────────────────────────────────
-- Interviewer timeslot pools — proactive calendar placeholders. A pool is one
-- (campaign source tag, round) capacity plan over a date range: on "Gather /
-- Refresh" the system blocks [PLACEHOLDER for NLi <round> pool-<id>] events on
-- the rostered interviewers' calendars (app.services.round_interviewers_config),
-- respecting a minimum gap after existing meetings, a cap on how much of an
-- interviewer's day may be locked, and which part of each weekday is allowed
-- (see days_allowed). Candidates in that round then pick from these
-- pre-reserved slots instead of a live per-candidate Graph lookup — see
-- app.services.candidate_slot's pool_id-aware booking path.
--
--   interview_pools       — one row per (source, date range) capacity plan +
--                           its allocation rules. Covers MULTIPLE rounds at
--                           once (round_names, a JSONB array) — every round
--                           in the list shares this pool's rules/date range
--                           and the same source-tag candidate pipeline, but
--                           each gathers its OWN slots against its own
--                           roster (interview_pool_slots.round_name), so
--                           rounds never share or compete for each other's
--                           placeholders.
--   interview_pool_slots  — one row per placeholder slot actually created,
--                           tagged with which round it was gathered for,
--                           tracking Graph event id + booking/removal state —
--                           the hourly sync job (app.services.pool_sync_job)
--                           reconciles this against what the interviewer does
--                           directly on their own calendar.
--   pool_interviewer_otp/sessions — the interviewer self-service portal's
--                           email-code challenge + remembered session, same
--                           shape as interviewer_otp/interviewer_sessions but
--                           verified against the round-interviewer roster
--                           (app.services.round_interviewers_config) instead
--                           of an allow-listed domain.
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS interview_pools (
    id               BIGSERIAL PRIMARY KEY,
    source_label     TEXT NULL,      -- matches email_master.source / candidate_master.source; NULL = "no source"
    round_names      JSONB NOT NULL DEFAULT '[]'::jsonb,
    label            TEXT NOT NULL,
    range_start      DATE NOT NULL,
    range_end        DATE NOT NULL,
    slot_minutes     INT NOT NULL DEFAULT 30,
    gap_minutes      INT NOT NULL DEFAULT 15,
    max_day_fraction NUMERIC(4,3) NOT NULL DEFAULT 0.25,
    days_allowed     JSONB NOT NULL DEFAULT '{"mon":"second_half","tue":"full","wed":"first_half","thu":"second_half","fri":"first_half","sat":"first_half","sun":"none"}',
    archived         BOOLEAN NOT NULL DEFAULT FALSE,
    created_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_interview_pools_round_names ON interview_pools USING GIN (round_names);

CREATE TABLE IF NOT EXISTS interview_pool_slots (
    id                  BIGSERIAL PRIMARY KEY,
    pool_id             BIGINT NOT NULL REFERENCES interview_pools (id) ON DELETE CASCADE,
    round_name          TEXT NOT NULL,
    interviewer_email   TEXT NOT NULL,
    interviewer_name    TEXT NULL,
    slot_start          TIMESTAMP NOT NULL,
    slot_end            TIMESTAMP NOT NULL,
    graph_event_id      TEXT NULL,
    status              TEXT NOT NULL DEFAULT 'open',
    booked_candidate_id TEXT NULL,
    booked_round_id     INT NULL,
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_pool_slot_status
        CHECK (status IN ('open', 'booked', 'removed_by_interviewer', 'cancelled'))
);
CREATE INDEX IF NOT EXISTS idx_pool_slots_pool ON interview_pool_slots (pool_id);
CREATE INDEX IF NOT EXISTS idx_pool_slots_interviewer ON interview_pool_slots (interviewer_email);
CREATE INDEX IF NOT EXISTS idx_pool_slots_status ON interview_pool_slots (status);

CREATE TABLE IF NOT EXISTS pool_interviewer_otp (
    id          BIGSERIAL PRIMARY KEY,
    email       TEXT NOT NULL,
    code        TEXT NOT NULL,
    expires_at  TIMESTAMP NOT NULL,
    consumed_at TIMESTAMP NULL,
    created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_pool_interviewer_otp_email ON pool_interviewer_otp (email);

CREATE TABLE IF NOT EXISTS pool_interviewer_sessions (
    session_token TEXT NOT NULL PRIMARY KEY,
    email         TEXT NOT NULL,
    expires_at    TIMESTAMP NOT NULL,
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_pool_interviewer_sessions_email ON pool_interviewer_sessions (email);

-- ─────────────────────────────────────────────────────────────────────────────
-- Interviewer access (app.services.interviewer_auth) — an external interviewer
-- reaches a candidate's read-only view through a short link (see
-- app.services.interviewer_link). To actually open it they must prove they
-- own an allowed-domain email via a mailed one-time code, tracked here.
--
--   interviewer_links    — one row per minted link: token -> candidate_id
--                           (+ optional round_id). A short (~10-char) opaque
--                           token needs a lookup table rather than a
--                           self-contained encoded payload (which would run
--                           150+ characters) to keep the shared URL short.
--   interviewer_otp      — one row per code REQUEST; short-lived (see the code's
--                           TTL), consumed_at set the moment it's used so a code
--                           can't be replayed.
--   interviewer_sessions — one row per "remember this device" opt-in; the
--                           session_token is what the browser stores (localStorage,
--                           not a cookie — this app has no cookie/CORS-credentials
--                           setup, see app.main CORS config) and sends back on
--                           later visits to skip the code challenge. Deleting the
--                           row (Settings → Interviewer Access → Revoke) forces
--                           that email to re-verify immediately.
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS interviewer_links (
    token        VARCHAR(16) PRIMARY KEY,
    candidate_id VARCHAR(64) NOT NULL,
    round_id     INT NULL,
    created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS interviewer_otp (
    id           BIGSERIAL PRIMARY KEY,
    email        TEXT NOT NULL,
    code         TEXT NOT NULL,
    candidate_id TEXT NULL,      -- which link the code was requested from (context only)
    expires_at   TIMESTAMP NOT NULL,
    consumed_at  TIMESTAMP NULL,
    created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_interviewer_otp_email ON interviewer_otp (email);

CREATE TABLE IF NOT EXISTS interviewer_sessions (
    session_token TEXT NOT NULL PRIMARY KEY,
    email         TEXT NOT NULL,
    expires_at    TIMESTAMP NOT NULL,
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_interviewer_sessions_email ON interviewer_sessions (email);

-- ─────────────────────────────────────────────────────────────────────────────
-- Candidate interview slot-selection — mirrors the interviewer_* tables above,
-- but the public link/session belongs to the CANDIDATE (identified by their
-- own on-file email, not an allow-listed domain) rather than an interviewer.
--
--   round_slot_invites      — one row per round a slot invite was minted for
--                             (token -> candidate_id/round_id, same short-
--                             opaque-token approach as interviewer_links),
--                             plus the lifecycle state the reminder/auto-reject
--                             scheduled job (app.services.scheduler) scans.
--   candidate_slot_otp      — one row per code REQUEST; "NLi-XXXXX" (5-digit
--                             numeric) codes, same short-lived/single-use
--                             shape as interviewer_otp.
--   candidate_slot_sessions — one row per "remember this device" opt-in,
--                             same shape as interviewer_sessions.
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS round_slot_invites (
    id               BIGSERIAL PRIMARY KEY,
    token            VARCHAR(16) UNIQUE NOT NULL,
    candidate_id     VARCHAR(64) NOT NULL,
    round_id         INT NOT NULL,
    candidate_email  TEXT NULL,
    sent_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    reminder_count   INT NOT NULL DEFAULT 0,
    last_reminder_at TIMESTAMP NULL,
    remind_me_again  BOOLEAN NOT NULL DEFAULT FALSE,
    slot_start       TIMESTAMP NULL,
    slot_end         TIMESTAMP NULL,
    booked_at        TIMESTAMP NULL,
    rejected_at      TIMESTAMP NULL,
    created_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_round_slot_invites_round ON round_slot_invites (round_id);
CREATE INDEX IF NOT EXISTS idx_round_slot_invites_pending
    ON round_slot_invites (booked_at, rejected_at);

CREATE TABLE IF NOT EXISTS candidate_slot_otp (
    id           BIGSERIAL PRIMARY KEY,
    token        VARCHAR(16) NOT NULL,
    email        TEXT NOT NULL,
    code         TEXT NOT NULL,
    expires_at   TIMESTAMP NOT NULL,
    consumed_at  TIMESTAMP NULL,
    created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_candidate_slot_otp_email ON candidate_slot_otp (email);

CREATE TABLE IF NOT EXISTS candidate_slot_sessions (
    session_token TEXT NOT NULL PRIMARY KEY,
    token         VARCHAR(16) NOT NULL,
    email         TEXT NOT NULL,
    expires_at    TIMESTAMP NOT NULL,
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_candidate_slot_sessions_token ON candidate_slot_sessions (token);

-- ─────────────────────────────────────────────────────────────────────────────
-- Question Banks — a saved, reusable set of GENERIC (non-personalized) interview
-- questions, generated once and applied uniformly across a cohort of candidates
-- (e.g. a placement drive). A bank is created from a "Generate Interview
-- Questions" run with "avoid personalization" on, then saved with an
-- auto-suggested Greek-god name. Phase 2 allocates a bank to a candidate's round
-- (question_bank_allocations) and records per-question responses/marks
-- (question_bank_responses); those tables are added when that phase lands.
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS question_banks (
    qb_id           BIGSERIAL PRIMARY KEY,
    name            TEXT NOT NULL UNIQUE,          -- auto-suggested Greek-god name (editable)
    stream          TEXT,                          -- calibration context the kit was generated for
    difficulty      TEXT,
    modes           JSONB NOT NULL DEFAULT '[]'::jsonb,   -- mode keys layered in
    question_count  INT NOT NULL DEFAULT 0,
    buckets         JSONB NOT NULL DEFAULT '[]'::jsonb,   -- the full kit: [{name, questions:[...]}]
    summary         JSONB,                         -- kit summary meta (stream, difficulty, ...)
    sources         JSONB NOT NULL DEFAULT '[]'::jsonb,   -- web sources the kit was grounded in
    options         JSONB NOT NULL DEFAULT '{}'::jsonb,   -- FULL generation options (composition mix, total, excludes, effort, focus, difficulty) — restored verbatim by "Customize"
    had_allocations BOOLEAN NOT NULL DEFAULT FALSE, -- ever assigned to a candidate (leaderboard was active) → deleting needs the heightened 2-password flow even after a discard
    created_by      TEXT,                          -- recruiter email
    status          TEXT NOT NULL DEFAULT 'active',-- active | archived
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_question_banks_status ON question_banks (status, created_at DESC);

-- A question bank ALLOCATED to a candidate's interview round. The same bank can
-- be allocated to a whole cohort (one row per candidate). round_id is nullable
-- so a bank can be pre-assigned (e.g. bulk by source tag) before the round/slot
-- invite exists; it's bound to the round when the invite is sent. Questions are
-- never shown to the candidate — only to the interviewer for that round.
CREATE TABLE IF NOT EXISTS question_bank_allocations (
    allocation_id   BIGSERIAL PRIMARY KEY,
    qb_id           BIGINT NOT NULL REFERENCES question_banks(qb_id) ON DELETE CASCADE,
    candidate_id    VARCHAR(64) NOT NULL,
    round_id        BIGINT,
    round_name      TEXT,
    interviewer     TEXT,                              -- interviewer name/email for this round
    slot_start      TIMESTAMP,
    slot_end        TIMESTAMP,
    status          TEXT NOT NULL DEFAULT 'assigned',  -- assigned | in_progress | collected | scored | removed (soft-deleted)
    source_tag      TEXT,                              -- set when bulk-assigned by source tag
    assigned_by     TEXT,
    answers_locked_at TIMESTAMP,                        -- interviewer locked the pasted answers → reveals model answers + rubric
    marks_locked_at   TIMESTAMP,                        -- interviewer locked the marks → reveals explanations
    removed_at      TIMESTAMP,                          -- soft-delete: candidate unassigned from the leaderboard (status -> 'removed'); row + responses are KEPT
    removed_by      TEXT,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_qb_alloc_candidate ON question_bank_allocations (candidate_id);
CREATE INDEX IF NOT EXISTS idx_qb_alloc_qb ON question_bank_allocations (qb_id, status);

-- Per-question interviewer response + marks for one allocation. AI suggests a
-- mark from the response vs the question's ideal answer; the interviewer can
-- override it (final_mark). The leaderboard ranks candidates by summed final_mark.
CREATE TABLE IF NOT EXISTS question_bank_responses (
    response_id     BIGSERIAL PRIMARY KEY,
    allocation_id   BIGINT NOT NULL REFERENCES question_bank_allocations(allocation_id) ON DELETE CASCADE,
    bucket          TEXT,
    question        TEXT NOT NULL,
    question_index  INT NOT NULL,
    response_text   TEXT,
    observation     TEXT,
    ai_mark         NUMERIC,                           -- AI-suggested 0..max_mark
    ai_rationale    TEXT,
    final_mark      NUMERIC,                           -- interviewer's final (possibly overridden)
    max_mark        NUMERIC NOT NULL DEFAULT 10,
    awarded_points  JSONB NOT NULL DEFAULT '[]'::jsonb, -- rubric point indices the interviewer ticked
    answer_locked_at TIMESTAMP,                          -- PER-QUESTION: response locked → reveal this question's model answer + rubric
    mark_locked_at   TIMESTAMP,                          -- PER-QUESTION: mark locked → reveal this question's explanation
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (allocation_id, question_index)
);
CREATE INDEX IF NOT EXISTS idx_qb_responses_alloc ON question_bank_responses (allocation_id);

-- ─────────────────────────────────────────────────────────────────────────────
-- Migrations for PRE-EXISTING databases.
-- The CREATE TABLE above is a no-op once a table already exists, so columns added
-- after a database was first provisioned must also be ALTERed in here. Idempotent
-- (ADD COLUMN IF NOT EXISTS) and a no-op on a fresh DB where the column is already
-- present from CREATE TABLE.
-- ─────────────────────────────────────────────────────────────────────────────
-- Scopes a candidate slot invite to one interviewer-timeslot pool — when set,
-- app.services.candidate_slot sources available slots from that pool's open
-- interview_pool_slots instead of a live per-candidate Graph lookup.
ALTER TABLE round_slot_invites ADD COLUMN IF NOT EXISTS pool_id BIGINT NULL;
-- Question-bank gated marking (Phase 2): the interviewer captures the candidate's
-- answers WITHOUT seeing the model answers, LOCKS them (reveals model answers +
-- rubric), assigns marks by ticking rubric points, then LOCKS the marks (reveals
-- the explanation). Locks live on the allocation; the ticked points per response.
ALTER TABLE question_bank_allocations ADD COLUMN IF NOT EXISTS answers_locked_at TIMESTAMP NULL;
ALTER TABLE question_bank_allocations ADD COLUMN IF NOT EXISTS marks_locked_at   TIMESTAMP NULL;
ALTER TABLE question_bank_responses  ADD COLUMN IF NOT EXISTS awarded_points JSONB NOT NULL DEFAULT '[]'::jsonb;
-- Per-question lock/reveal: each response locks its OWN answer (reveals that
-- question's model answer + rubric) and its OWN mark (reveals its explanation).
ALTER TABLE question_bank_responses  ADD COLUMN IF NOT EXISTS answer_locked_at TIMESTAMP NULL;
ALTER TABLE question_bank_responses  ADD COLUMN IF NOT EXISTS mark_locked_at   TIMESTAMP NULL;
DO $$
BEGIN
    ALTER TABLE question_bank_responses ADD CONSTRAINT uq_qb_resp_alloc_qidx UNIQUE (allocation_id, question_index);
EXCEPTION
    WHEN duplicate_object THEN NULL;
    WHEN duplicate_table THEN NULL;
    WHEN OTHERS THEN RAISE WARNING 'qb_responses (allocation_id, question_index) unique constraint skipped: %', SQLERRM;
END $$;
-- Persist the FULL generation options on a bank so "Customize" restores the exact
-- composition mix + settings it was created with (not just modes/difficulty).
ALTER TABLE question_banks ADD COLUMN IF NOT EXISTS options JSONB NOT NULL DEFAULT '{}'::jsonb;
-- Mark a bank that has EVER been assigned to a candidate (its leaderboard was
-- active). Deleting such a bank requires discarding the leaderboard first, then a
-- heightened 2-password confirmation — even after the discard. Backfill existing.
ALTER TABLE question_banks ADD COLUMN IF NOT EXISTS had_allocations BOOLEAN NOT NULL DEFAULT FALSE;
UPDATE question_banks SET had_allocations = TRUE
 WHERE qb_id IN (SELECT DISTINCT qb_id FROM question_bank_allocations);
-- Removing a single candidate from a bank's leaderboard is a SOFT delete (status
-- -> 'removed') rather than dropping the row, so the leaderboard keeps a record
-- of who was unassigned and by whom, instead of silently disappearing.
ALTER TABLE question_bank_allocations ADD COLUMN IF NOT EXISTS removed_at TIMESTAMP NULL;
ALTER TABLE question_bank_allocations ADD COLUMN IF NOT EXISTS removed_by TEXT NULL;
-- Auto-send guard: when a slot-invite email could NOT get its interview slot-picker
-- link inserted, the send is paused and this holds the caution message shown as a
-- blinking alert next to the candidate (dashboard + stage). Cleared on a good send.
ALTER TABLE candidate_master ADD COLUMN IF NOT EXISTS invite_block_reason TEXT NULL;
-- interview_pools: round_name (single) -> round_names (JSONB multi-select) —
-- a pool now covers several rounds at once. No pools existed with real data
-- when this changed, so this simply folds any single value into the new
-- array column rather than attempting a lossless multi-value migration.
ALTER TABLE interview_pools ADD COLUMN IF NOT EXISTS round_names JSONB NOT NULL DEFAULT '[]'::jsonb;
DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'interview_pools' AND column_name = 'round_name'
    ) THEN
        UPDATE interview_pools SET round_names = jsonb_build_array(round_name)
            WHERE round_names = '[]'::jsonb AND round_name IS NOT NULL;
        ALTER TABLE interview_pools DROP COLUMN round_name;
    END IF;
EXCEPTION WHEN OTHERS THEN
    RAISE WARNING 'interview_pools.round_names migration skipped (non-fatal): %', SQLERRM;
END $$;
DROP INDEX IF EXISTS idx_interview_pools_round;
-- interview_pool_slots: each slot now records which round it was gathered
-- for (a pool spans multiple rounds; the roster differs per round).
ALTER TABLE interview_pool_slots ADD COLUMN IF NOT EXISTS round_name TEXT NOT NULL DEFAULT '';
-- Deterministic ATS transparency — structured columns so the candidate view can
-- render risk signals + the "why this score" breakdown without parsing `analysis`.
ALTER TABLE candidate_master ADD COLUMN IF NOT EXISTS score_breakdown     JSONB NULL;
ALTER TABLE candidate_master ADD COLUMN IF NOT EXISTS score_penalties     JSONB NULL;
ALTER TABLE candidate_master ADD COLUMN IF NOT EXISTS certification_bonus JSONB NULL;
-- Recruiter-facing 5-point screening summary (model-owned), rendered as the
-- "Analysis Report" card on the candidate profile.
ALTER TABLE candidate_master ADD COLUMN IF NOT EXISTS analysis_report JSONB NULL;
-- Interview plan flag (set once on Screening): include the optional Round 3?
ALTER TABLE candidate_master ADD COLUMN IF NOT EXISTS include_round3 BOOLEAN NULL;
-- Pipeline processing clock — refreshed whenever L3 processes the candidate.
-- Anchors the "Aging" column for New (not-yet-in-round) candidates.
ALTER TABLE candidate_master ADD COLUMN IF NOT EXISTS pipeline_processed_at TIMESTAMP NULL;
-- Highest degree's CGPA/GPA (native scale, 0 < x ≤ 10), captured by L3 extraction.
ALTER TABLE candidate_master ADD COLUMN IF NOT EXISTS cgpa FLOAT NULL;
-- Extra columns carried over from an Excel/spreadsheet intake source (see column
-- comment above); keyed "<header>__from-source-sheet" + optional "CGPA__from-resume".
ALTER TABLE candidate_master ADD COLUMN IF NOT EXISTS source_columns JSONB NULL;
-- L1→L3 carrier for the above: every Excel row's full column set, keyed by the
-- email item + the resume file it produced, so L3 can attach it to the candidate
-- once the resume is extracted. Rows are consumed (best-effort) at that point.
CREATE TABLE IF NOT EXISTS intake_excel_columns (
    e_id         TEXT NOT NULL,
    stored_name  TEXT NOT NULL,
    row_cells    JSONB NOT NULL,
    created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (e_id, stored_name)
);
-- Candidate pipeline/round bucket an audit_log row belongs to — drives the "Actions
-- Audit Log" stage grouping/coloring on the candidate profile (app.stages.BUCKET_ORDER).
ALTER TABLE audit_log ADD COLUMN IF NOT EXISTS stage TEXT NULL;
-- Recruiter override of the "Next Best Action" suggestion (Dashboard "Update" /
-- candidate-profile "Proposed Next Best Action" box). {"key": "reject"|"schedule"|
-- "hold"|"custom", "text": <free-text, only when key="custom">}. NULL = no override,
-- the ATS-derived suggestion stands.
ALTER TABLE candidate_master ADD COLUMN IF NOT EXISTS next_action_override JSONB NULL;
-- Live Workflow — per-round email/acceptance sub-steps, mirrored from the active round.
ALTER TABLE candidate_master ADD COLUMN IF NOT EXISTS invite_sent_at TIMESTAMP NULL;
ALTER TABLE candidate_master ADD COLUMN IF NOT EXISTS reminder_count INT NOT NULL DEFAULT 0;
ALTER TABLE candidate_master ADD COLUMN IF NOT EXISTS candidate_accepted_slot BOOLEAN NULL;
-- Live Workflow — post-hire onboarding pipeline, parallel to `status`.
ALTER TABLE candidate_master ADD COLUMN IF NOT EXISTS onboarding_stage TEXT NULL;
ALTER TABLE candidate_master ADD COLUMN IF NOT EXISTS expected_join_date DATE NULL;
ALTER TABLE candidate_master ADD COLUMN IF NOT EXISTS onboarding_date DATE NULL;
ALTER TABLE candidate_master ADD COLUMN IF NOT EXISTS onboarding_checklist JSONB NULL;
-- Live Workflow — same per-round email/acceptance sub-steps, on the round itself.
ALTER TABLE rounds ADD COLUMN IF NOT EXISTS invite_sent_at TIMESTAMP NULL;
ALTER TABLE rounds ADD COLUMN IF NOT EXISTS reminder_count INT NOT NULL DEFAULT 0;
ALTER TABLE rounds ADD COLUMN IF NOT EXISTS candidate_accepted_slot BOOLEAN NULL;
-- Recruiter-typed intake source (e.g. "LinkedIn", "Naukri", "Referral - Jane"),
-- mandatory on the manual "Add to Intake queue" upload; carried from email_master
-- onto every candidate_master row that batch produces.
ALTER TABLE email_master ADD COLUMN IF NOT EXISTS source TEXT NULL;
ALTER TABLE candidate_master ADD COLUMN IF NOT EXISTS source TEXT NULL;
-- candidate_master_archive was created (LIKE candidate_master) before `source`
-- existed on any pre-existing database, so it needs the same column added
-- explicitly — batch_archive.py groups archived rows by this column.
ALTER TABLE candidate_master_archive ADD COLUMN IF NOT EXISTS source TEXT NULL;

-- Untagged intake is persisted as the canonical "No Source Tag" bucket rather than
-- NULL, so there is exactly ONE representation of "no source" for the source filter
-- and the per-source dedup bucket below. The app defaults it on write (see
-- app.config.NO_SOURCE_TAG, app.repositories.pg_repo.insert_candidate_stub,
-- app.db.email_master.upsert_email_master); this column DEFAULT is the backstop for
-- any INSERT that omits the column (e.g. the mail-queue email_table writer), and the
-- one-time UPDATE folds every pre-existing NULL/blank row into the same bucket.
ALTER TABLE email_master             ALTER COLUMN source SET DEFAULT 'No Source Tag';
ALTER TABLE candidate_master         ALTER COLUMN source SET DEFAULT 'No Source Tag';
ALTER TABLE candidate_master_archive ALTER COLUMN source SET DEFAULT 'No Source Tag';
UPDATE email_master             SET source = 'No Source Tag' WHERE source IS NULL OR btrim(source) = '';
UPDATE candidate_master         SET source = 'No Source Tag' WHERE source IS NULL OR btrim(source) = '';
UPDATE candidate_master_archive SET source = 'No Source Tag' WHERE source IS NULL OR btrim(source) = '';

-- ─────────────────────────────────────────────────────────────────────────────
-- Unique email enforcement — case-insensitive, ignores blank/NULL, PER SOURCE
-- (not globally): the same email may exist as a separate candidate under a
-- different source (see app.services.source_tags' "dup check within this
-- source only" per-tag setting and app.pipeline.nodes.dedup's fuzzy-match
-- scoping) — the database index only needs to stop a literal second row for
-- the same email WITHIN one source; the soft fuzzy/name/phone match is what
-- decides same-source duplicates. Untagged intake all shares the one "No Source
-- Tag" bucket (blank/NULL is folded into it on write, above; COALESCE-to-'' still
-- guards any legacy blank), so untagged intake keeps the same protection among
-- itself that it always had.
--
-- Step 1 — resolve existing collisions so the index below can build (a duplicate
-- would otherwise abort init_db on startup). Per (source, case-insensitive
-- non-empty email) we KEEP the richest/oldest candidate and archive the rest:
--   keeper order: screened > has active round > extracted (atsscore) > Hired >
--                 oldest created_at > smallest candidate_id.
-- Losers are copied into dedicated, CURRENT-shape archive tables (so SELECT * never
-- mismatches a stale *_archive table) then removed; their rounds go first for the FK.
-- Idempotent: a no-op once no duplicates remain.
-- ─────────────────────────────────────────────────────────────────────────────
-- This whole block is DATA-DEPENDENT (it mutates existing rows), unlike the
-- idempotent DDL above. It runs inside an EXCEPTION-guarded DO so a data problem here
-- (residual duplicates, a stale archive shape, …) can NEVER abort the single
-- transaction init_db() runs — which previously rolled back the column migrations
-- above and stranded the DB without e.g. pipeline_processed_at, breaking every L3
-- write. A failure is now a non-fatal WARNING; the rest of the schema still commits.
DO $dedup$
BEGIN
    -- Rebuild the archive tables to the CURRENT candidate_master/rounds shape on every
    -- run, so the `SELECT *` archiving below can't mismatch a stale (pre-migration)
    -- layout. They're internal safety copies of removed duplicates, recreated fresh.
    DROP TABLE IF EXISTS candidate_email_dupes_archive;
    DROP TABLE IF EXISTS rounds_email_dupes_archive;
    CREATE TABLE candidate_email_dupes_archive
        (LIKE candidate_master INCLUDING DEFAULTS, archived_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE rounds_email_dupes_archive
        (LIKE rounds INCLUDING DEFAULTS, archived_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP);

    CREATE TEMP TABLE _dup_email_losers ON COMMIT DROP AS
    WITH ranked AS (
        SELECT candidate_id,
               ROW_NUMBER() OVER (
                   PARTITION BY COALESCE(btrim(source), ''), lower(btrim(email))
                   ORDER BY screened                DESC,   -- keep interview history
                            (roundid IS NOT NULL)   DESC,
                            (atsscore IS NOT NULL)  DESC,   -- keep the extracted one
                            (status = 'Hired')      DESC,
                            created_at              ASC,    -- else the oldest
                            candidate_id            ASC
               ) AS rn
          FROM candidate_master
         WHERE email IS NOT NULL AND btrim(email) <> ''
    )
    SELECT candidate_id FROM ranked WHERE rn > 1;

    INSERT INTO rounds_email_dupes_archive
    SELECT r.*, CURRENT_TIMESTAMP FROM rounds r
     WHERE r.candidate_id IN (SELECT candidate_id FROM _dup_email_losers);
    DELETE FROM rounds
     WHERE candidate_id IN (SELECT candidate_id FROM _dup_email_losers);

    INSERT INTO candidate_email_dupes_archive
    SELECT cm.*, CURRENT_TIMESTAMP FROM candidate_master cm
     WHERE cm.candidate_id IN (SELECT candidate_id FROM _dup_email_losers);
    DELETE FROM candidate_master
     WHERE candidate_id IN (SELECT candidate_id FROM _dup_email_losers);

    -- Step 2 — enforce uniqueness going forward, PER (source, email). Drop the
    -- old globally-unique-by-email-alone index first (a same-named
    -- CREATE...IF NOT EXISTS would otherwise silently keep the OLD definition
    -- on any pre-existing database).
    DROP INDEX IF EXISTS uq_candidate_email_ci;
    CREATE UNIQUE INDEX IF NOT EXISTS uq_candidate_email_ci
        ON candidate_master (COALESCE(btrim(source), ''), lower(btrim(email)))
        WHERE email IS NOT NULL AND btrim(email) <> '';
EXCEPTION WHEN OTHERS THEN
    RAISE WARNING 'email-dedup / unique-index migration skipped (non-fatal): %', SQLERRM;
END
$dedup$;

-- ─────────────────────────────────────────────────────────────────────────────
-- Interview workflow is hardcoded (app.services.interview_plan), not DB-configured —
-- drop any tables left by the earlier Settings-driven designs.
-- ─────────────────────────────────────────────────────────────────────────────
DROP TABLE IF EXISTS interview_stage_interviewer;
DROP TABLE IF EXISTS interview_stage_template;
DROP TABLE IF EXISTS interviewers;
DROP TABLE IF EXISTS interview_workflow;

-- ─────────────────────────────────────────────────────────────────────────────
-- Notifications — the ONE table backing the top-bar bell. The feed is still
-- DERIVED from audit_log / review_queue / candidate_master (app.services.notifications),
-- but each derived item is persisted here with a STABLE, content-derived id so that
-- read/unread state lives server-side (read_at) instead of in the browser.
--
--   • id          stable key (e.g. "candidate_hired:C1042", "run:BATCH-…", singleton
--                 "manual_review") so re-deriving the same event updates the same row.
--   • read_at     NULL = unread. "Mark all read" stamps now().
--
-- Retention: a notification is deleted 24h AFTER it is read (app.services.notifications
-- .cleanup, run on every sync). Unread notifications are never auto-deleted.
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS notifications (
    id          TEXT PRIMARY KEY,
    type        TEXT NOT NULL,
    severity    TEXT NOT NULL,                 -- action | health | info
    title       TEXT NOT NULL,
    body        TEXT NULL,
    link        TEXT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    read_at     TIMESTAMPTZ NULL
);
CREATE INDEX IF NOT EXISTS idx_notifications_created ON notifications (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_read    ON notifications (read_at);

-- ─────────────────────────────────────────────────────────────────────────────
-- app_users — SPA login accounts. Replaces the two hardcoded config credentials:
-- the Admin/Recruiter defaults are still seeded from config (app.services.users
-- .seed_default_users, called by init_db) so a fresh DB has working logins, but an
-- Admin can now add more accounts from Settings → User Management.
--
-- role = 'admin'    → full access, including manual Next Best Action overrides.
--        'recruiter'→ Recruitment Manager: everything else, but the manual NBA
--                     override is blocked (require_admin, server-side + UI-hidden).
-- password_hash is a self-describing PBKDF2 string (pbkdf2_sha256$iters$salt$hash);
-- see app.services.users. Emails are unique case-insensitively.
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS app_users (
    id            BIGSERIAL PRIMARY KEY,
    email         TEXT NOT NULL,
    name          TEXT NOT NULL,
    role          TEXT NOT NULL DEFAULT 'recruiter',
    password_hash TEXT NOT NULL,
    is_active     BOOLEAN NOT NULL DEFAULT TRUE,
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_app_user_role CHECK (role IN ('admin', 'recruiter', 'sysadmin'))
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_app_users_email_ci ON app_users (lower(btrim(email)));
-- Widen the role CHECK for pre-existing databases (the CREATE TABLE above is a
-- no-op once the table exists) — drop + re-add is idempotent and safe on every
-- startup since it only ever widens the allowed set, never narrows live data out.
ALTER TABLE app_users DROP CONSTRAINT IF EXISTS chk_app_user_role;
ALTER TABLE app_users ADD CONSTRAINT chk_app_user_role CHECK (role IN ('admin', 'recruiter', 'sysadmin'));
-- First-login (and admin-reset) forced password change: TRUE means the next
-- successful login must set a new password before using the app. Set on
-- accounts created via User Management and on every admin password reset;
-- cleared by the user's own change-password action.
ALTER TABLE app_users ADD COLUMN IF NOT EXISTS must_change_password BOOLEAN NOT NULL DEFAULT FALSE;

-- Password reset + account-invite tokens. A single opaque URL token is emailed
-- to the user (forgot-password) or to a newly-created member (set initial
-- password); only its SHA-256 digest is stored, single-use (consumed_at) and
-- time-limited (expires_at). Same table serves both flows via `purpose`.
CREATE TABLE IF NOT EXISTS password_reset_tokens (
    id          BIGSERIAL PRIMARY KEY,
    email       TEXT NOT NULL,
    token_hash  TEXT NOT NULL,
    purpose     TEXT NOT NULL DEFAULT 'reset',   -- 'reset' | 'invite'
    expires_at  TIMESTAMP NOT NULL,
    consumed_at TIMESTAMP NULL,
    created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_password_reset_tokens_hash ON password_reset_tokens (token_hash);
CREATE INDEX IF NOT EXISTS ix_password_reset_tokens_email ON password_reset_tokens (lower(btrim(email)));

-- In-app bug reports + feature requests. Any signed-in user submits one; the
-- reporter (email/name/role) is stamped server-side from their session (never
-- client-supplied). Admins review + export these from Settings → Feedback.
CREATE TABLE IF NOT EXISTS feedback_reports (
    id             BIGSERIAL PRIMARY KEY,
    kind           TEXT NOT NULL DEFAULT 'bug',      -- 'bug' | 'feature'
    title          TEXT NOT NULL,
    description    TEXT NOT NULL DEFAULT '',
    priority       TEXT NOT NULL DEFAULT 'P3',       -- P1 (highest) .. P5 (lowest)
    moscow         TEXT NULL,                        -- MoSCoW: must | should | could | wont
    reporter_email TEXT NOT NULL,
    reporter_name  TEXT NOT NULL DEFAULT '',
    reporter_role  TEXT NULL,
    status         TEXT NOT NULL DEFAULT 'open',     -- open | in_progress | resolved | closed
    created_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_feedback_reports_created ON feedback_reports (created_at DESC);
-- MoSCoW classification (Must/Should/Could/Won't have), added alongside P1–P5.
ALTER TABLE feedback_reports ADD COLUMN IF NOT EXISTS moscow TEXT NULL;

-- ─────────────────────────────────────────────────────────────────────────────
-- Data migration — retire the 'Manual Review' candidate status.
-- The status was collapsed into 'Active': a failed extraction / reapplication is
-- now surfaced via review_queue (+ previously_seen) rather than a distinct status.
-- Idempotent: after the first run no rows match, so it's safe on every startup.
-- ─────────────────────────────────────────────────────────────────────────────
UPDATE candidate_master SET status = 'Active', updated_at = CURRENT_TIMESTAMP
 WHERE status = 'Manual Review';

-- Recruiter-editable override for the pool-size (velocity) estimate. NULL means
-- "use the trailing-14-day candidate velocity" (the original behaviour); once set,
-- it also becomes the target compute_velocity()/gather_pool() size against, so a
-- recruiter can correct a thin/noisy history without the estimate ever being
-- pinned back down to zero (it just reverts to auto once cleared).
ALTER TABLE interview_pools ADD COLUMN IF NOT EXISTS manual_projected_candidates NUMERIC NULL;

-- A short, memorable codename assigned per slot at gather time (see
-- interview_pools._SLOT_CODENAMES) — the same string appended to the
-- placeholder's calendar event subject, so a recruiter/interviewer can say
-- "the Batman slot" instead of reading out a timestamp.
ALTER TABLE interview_pool_slots ADD COLUMN IF NOT EXISTS slot_name TEXT NULL;

-- Candidate "Need help" message from the slot-picker page — a red "!" on the
-- candidate's status tracking until a recruiter reads it and marks it handled.
-- {message, round_name, created_at, resolved, resolved_at?} or NULL.
ALTER TABLE candidate_master ADD COLUMN IF NOT EXISTS help_request JSONB NULL;

-- ─────────────────────────────────────────────────────────────────────────────
-- Intake mailbox account & folder routing (Settings → Mailbox Account).
-- Single-row config; password_enc is Fernet-encrypted at rest (see
-- app.services.mailbox_account — key from MAILBOX_ENC_KEY / JWT secret).
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS mailbox_account_config (
    id                 INT PRIMARY KEY DEFAULT 1 CHECK (id = 1),
    email              TEXT NOT NULL,
    password_enc       TEXT NULL,
    scan_folder        TEXT NOT NULL DEFAULT 'Landing',
    folder_processing  TEXT NOT NULL DEFAULT 'Processing',
    folder_processed   TEXT NOT NULL DEFAULT 'Processed',
    folder_failed      TEXT NOT NULL DEFAULT 'Failed',
    folder_non_resume  TEXT NOT NULL DEFAULT 'Non-Resume',
    updated_by         TEXT NULL,
    updated_at         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ─────────────────────────────────────────────────────────────────────────────
-- LLM token-usage ledger — one row per LLM call (extraction, analysis report,
-- timeline, interview questions, JD match, chatbot). Powers the Admin "Token
-- Usage" dashboard; source attribution is a query-time join on candidate_id.
-- Also created lazily by app.services.token_usage._ensure_table().
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS llm_token_usage (
    id BIGSERIAL PRIMARY KEY,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    module TEXT NOT NULL,
    model TEXT,
    candidate_id TEXT,
    prompt_tokens INTEGER NOT NULL DEFAULT 0,
    completion_tokens INTEGER NOT NULL DEFAULT 0,
    total_tokens INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_llm_token_usage_created ON llm_token_usage (created_at);
CREATE INDEX IF NOT EXISTS idx_llm_token_usage_module ON llm_token_usage (module);

-- ─────────────────────────────────────────────────────────────────────────────
-- LLM provider keys — Settings → LLM Model Keys. API key Fernet-encrypted at
-- rest; module_overrides carries optional per-module {endpoint, deployment,
-- api_key_enc}. Also created lazily by app.services.llm_config._ensure_table().
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS llm_api_config (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    endpoint TEXT,
    api_key_enc TEXT,
    api_version TEXT,
    deployment TEXT,
    fallback_deployment TEXT,
    module_overrides JSONB NOT NULL DEFAULT '{}'::jsonb,
    updated_by TEXT,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Latest recruiter note on the candidate ({text, author, created_at}) — shown
-- as the sticky note on the Candidate page and the yellow badge next to the
-- name. FULL history lives in audit_log (step = 'candidate_note').
ALTER TABLE candidate_master ADD COLUMN IF NOT EXISTS latest_note JSONB NULL;

-- Latest recruiter REMARK on the candidate ({text, author, created_at}) —
-- like latest_note but ALSO surfaced to the interviewer on their link view;
-- shown as a BLUE note icon next to the name. Full history in audit_log
-- (step = 'candidate_remark').
ALTER TABLE candidate_master ADD COLUMN IF NOT EXISTS latest_remark JSONB NULL;

-- Microsoft Graph app-registration credentials — Settings → Graph API. Client
-- secret Fernet-encrypted at rest. Also created lazily by
-- app.services.graph_config._ensure_table().
CREATE TABLE IF NOT EXISTS graph_api_config (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    tenant_id TEXT,
    client_id TEXT,
    client_secret_enc TEXT,
    updated_by TEXT,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ─────────────────────────────────────────────────────────────────────────────
-- Incoming Email Queue discards — mail dismissed from the Outlook Processing
-- folder BEFORE it is staged into email_master (no e_id exists yet, so this
-- can't live in audit_log). One row per discarded message, capturing who
-- discarded it (Admin/System Admin) and when, for the Mailbox report.
-- ─────────────────────────────────────────────────────────────────────────────
-- ``state``: 'discarded' while the message sits in the Outlook Discarded folder
-- (excluded from the queue / pipeline runs); 'restored' once an Admin/System
-- Admin has brought it back into Processing for a future or on-demand run. Rows
-- are NEVER deleted — restoring just appends the restored_by/at columns — so
-- the report keeps full history of both actions.
CREATE TABLE IF NOT EXISTS discarded_incoming_mail (
    id                  BIGSERIAL PRIMARY KEY,
    message_id          TEXT NULL,      -- Graph message id at its CURRENT folder
    sender_mail_id      TEXT NULL,
    subject             TEXT NULL,
    received_date       TEXT NULL,      -- ISO-8601 as reported by Graph, or NULL
    state               TEXT NOT NULL DEFAULT 'discarded',  -- discarded | restored
    discarded_by_email  TEXT NULL,
    discarded_by_name   TEXT NULL,
    discarded_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    restored_by_email   TEXT NULL,
    restored_by_name    TEXT NULL,
    restored_at         TIMESTAMP NULL
);
CREATE INDEX IF NOT EXISTS idx_discarded_incoming_mail_at
    ON discarded_incoming_mail (discarded_at DESC);
CREATE INDEX IF NOT EXISTS idx_discarded_incoming_mail_state
    ON discarded_incoming_mail (state);
