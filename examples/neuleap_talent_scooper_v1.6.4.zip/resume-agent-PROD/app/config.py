"""Unified settings for the merged resume service (L2 intake + L3 extraction).

One ``.env`` drives both layers:
  * L2 (this ``Settings``)                  — Postgres + MinIO + pipeline tuning.
  * L3 (raw ``os.getenv`` in extraction/engine.py) — Azure OpenAI keys.

``load_dotenv()`` runs at import so L3's ``os.getenv`` calls also see the file.
In Docker the values arrive as real env vars and take precedence.
"""
from __future__ import annotations

from dotenv import load_dotenv
from pydantic_settings import BaseSettings, SettingsConfigDict

load_dotenv()

# Canonical label for the "no source tag" bucket. Persisted (not just displayed)
# so email_master.source / candidate_master.source are never NULL — there is ONE
# representation of "untagged", keeping the source filter and the dedup bucket
# (COALESCE(btrim(source), '')) consistent for tagged and untagged rows alike.
# Defined here (a dependency-free leaf module) so the DB layer can default to it
# without importing app.services. See app.services.source_tags.active_label().
NO_SOURCE_TAG = "No Source Tag"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env", env_file_encoding="utf-8", extra="ignore"
    )

    # Object store: "minio" (default) | "aws"
    s3_backend: str = "minio"

    # Deploy stage label, shown in the top bar (GET /api/v1/meta) and gating the
    # destructive full-database wipe (app.services.system_reset): the wipe is
    # allowed for any non-empty value EXCEPT "production"/"prod"/"prd" — so
    # "qa", "dev", "staging", "uat", etc. all enable it, regardless of role or
    # the typed confirmation phrase, while an unset/production value never does.
    # Defaults to "production" (safe) — set APP_ENV explicitly per environment.
    app_env: str = "production"

    # Public origin the frontend is served at (e.g. "https://talents.neuleap.io",
    # no trailing slash) — needed ONLY by backend-initiated emails that embed a
    # /schedule/{token} link without a browser in the loop to prepend one
    # itself (auto-invite on a new round, and the slot-selection reminder job;
    # see app.services.candidate_slot / slot_reminder_job). The Draft Review
    # flow doesn't need this — the frontend already prepends its own origin
    # before the recruiter ever sees the link. Blank = these two paths log a
    # warning and skip sending rather than emailing a candidate a broken link.
    app_public_url: str = ""

    # Auto-chain: on a passing L2 intake, immediately run L3 extraction.
    auto_extract: bool = True

    # Number of parallel L3 extraction workers (ThreadPoolExecutor).
    # Keep <= pg pool maxconn (16) and below Azure rate-limit ceiling.
    extract_workers: int = 5

    # ── PostgreSQL ───────────────────────────────────────────────────
    pg_host: str = "postgres"
    pg_port: int = 5432
    pg_database: str = "resume_db"
    pg_user: str = "resume_user"
    pg_password: str = "resume_password"

    # ── MinIO / S3 (two buckets, D2) ─────────────────────────────────
    minio_endpoint: str = "http://minio:9000"
    minio_access_key: str = "minioadmin"
    minio_secret_key: str = "minioadmin"
    minio_region: str = "us-east-1"

    # L1 writes validated resumes to the `raw` bucket (key Y/M/D/{e_id}/file);
    # L2 reads them cross-bucket and writes clean copies to the `resume` bucket.
    minio_raw_bucket: str = "raw"        # L1 output / L2 source
    minio_resume_bucket: str = "resume"  # L2 clean / L3 source

    # Back-compat alias (older code referenced a single bucket = the clean one).
    minio_bucket: str = "resume"

    # Object key prefixes. raw keys carry NO prefix (the bucket itself is `raw`);
    # clean keys keep the `resume/` prefix inside the `resume` bucket.
    s3_raw_prefix: str = "raw"
    s3_resume_prefix: str = "resume"

    # ── Pipeline tuning (L2) ─────────────────────────────────────────
    fuzzy_threshold: int = 85
    candidate_id_prefix: str = "C"
    candidate_id_start: int = 1001

    # ── Logging ──────────────────────────────────────────────────────
    log_level: str = "INFO"

    # ── Auth (JWT) ───────────────────────────────────────────────────
    # Login accounts live in the app_users table (app.services.users); these
    # values seed the three DEFAULT accounts on startup.
    #   admin      — full access, including manual Next Best Action overrides.
    #   recruiter  — Recruitment Manager: everything else (including
    #                apply/bulk-apply of the system-predicted NBA), but the
    #                manual "change NBA" action is Admin-only (enforced
    #                server-side via require_admin, not just hidden in the UI).
    #                Does NOT have Settings access.
    #   sysadmin   — System Admin: Settings access (pipeline/notifications/
    #                scoring/columns config + User Management), same as Admin
    #                there, but no NBA-override capability — that stays
    #                Admin-only regardless of Settings access.
    # Admins/System Admins can add further accounts from Settings → User
    # Management. Seed credentials and signing secret are overridable via env
    # (AUTH_EMAIL / AUTH_PASSWORD / RECRUITER_EMAIL / RECRUITER_PASSWORD /
    # SYSADMIN_EMAIL / SYSADMIN_PASSWORD / JWT_SECRET).
    auth_email: str = "re-admin@neuleap.ai"
    auth_password: str = "test@123"
    recruiter_email: str = "re-recruiter@neuleap.ai"
    recruiter_password: str = "recruit@123"
    sysadmin_email: str = "re-sysadmin@neuleap.ai"
    sysadmin_password: str = "sysadmin@123"
    jwt_secret: str = "neuleap-dev-secret-change-in-production"
    jwt_algorithm: str = "HS256"
    # Token lifetime — long-lived so the session persists until explicit logout.
    jwt_expire_minutes: int = 60 * 24 * 30  # 30 days

    # ── Observability: Langfuse (LLM token tracing) ──────────────────
    # All optional. Langfuse stays DISABLED unless langfuse_enabled is true and
    # both keys are present, so local/CI runs never depend on it.
    langfuse_enabled: bool = False
    langfuse_public_key: str = ""
    langfuse_secret_key: str = ""
    langfuse_host: str = "https://cloud.langfuse.com"


settings = Settings()

# ── JWT-secret hardening ─────────────────────────────────────────────────────
# The class default above is a PUBLIC string (it's in source control) — signing
# auth tokens with it, or deriving the Fernet key that encrypts stored secrets
# (mailbox password, LLM API keys) from it, would be a real vulnerability the
# moment nobody sets JWT_SECRET. When no explicit secret is configured,
# generate a strong random one ONCE and persist it to the bind-mounted
# secrets/ directory so it survives restarts/rebuilds. Rotating it logs every
# user out (tokens re-verify) — a one-time cost, not data loss.
_JWT_PUBLIC_DEFAULT = "neuleap-dev-secret-change-in-production"


def _harden_jwt_secret() -> None:
    import os as _os
    import secrets as _secrets
    from pathlib import Path as _Path

    if _os.environ.get("JWT_SECRET") or settings.jwt_secret != _JWT_PUBLIC_DEFAULT:
        return  # explicitly configured — respect it
    key_file = _Path(_os.environ.get("SECRETS_DIR", "secrets")) / "jwt_secret.key"
    try:
        if key_file.exists():
            stored = key_file.read_text(encoding="utf-8").strip()
            if stored:
                settings.jwt_secret = stored
                return
        key_file.parent.mkdir(parents=True, exist_ok=True)
        generated = _secrets.token_urlsafe(64)
        key_file.write_text(generated, encoding="utf-8")
        try:
            _os.chmod(key_file, 0o600)
        except OSError:
            pass  # best-effort on non-POSIX filesystems
        settings.jwt_secret = generated
    except OSError:
        # Can't persist (read-only fs?) — keep the default rather than minting
        # a per-process secret that would break multi-worker token validation.
        import logging as _logging

        _logging.getLogger(__name__).warning(
            "JWT secret is the PUBLIC default and secrets/jwt_secret.key could not "
            "be written — set JWT_SECRET explicitly."
        )


_harden_jwt_secret()
