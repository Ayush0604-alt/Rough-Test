"""LangGraph workflow definition for Layer 1.

Topology (one node = one responsibility; per-item loop via ``dispatch``)::

    START
      -> read_inbox
      -> move_to_processing
      -> dispatch ---------------------------------.
           | (has item)                            | (done)
           v                                       v
      inspect_message                         print_report -> END
           v
      classify_content
        |        \\ (None)
        |         `-> discard_item ----------------> dispatch
        | (Attachment/Links/Mixed)
        v
      validate_files
        |        \\ (nothing to store)
        |         `-------------------------------> build_email_master_row
        | (has clean files)
        v
      store_clean_files -> build_email_master_row -> dispatch

Conditional edges:
* ``dispatch``          -> loop vs. finish (cursor < len(items))
* ``classify_content``  -> discard (None) vs. proceed
* ``validate_files``    -> store (clean files present) vs. skip straight to row
"""

from __future__ import annotations

from langgraph.graph import END, START, StateGraph

from app.mail_config import SETTINGS, Settings
from app.models.mail import Classification, Layer1State
from app.pipeline.mail.nodes import Layer1Nodes


def _route_dispatch(state: Layer1State) -> str:
    return "process" if state["cursor"] < len(state["items"]) else "finish"


def _route_classification(state: Layer1State) -> str:
    return "discard" if state.get("classification") is Classification.NONE else "proceed"


def _route_validation(state: Layer1State) -> str:
    return "store" if state.get("pending_store") else "skip"


def build_graph(settings: Settings | None = None):
    """Compile and return the Layer 1 LangGraph application."""
    nodes = Layer1Nodes(settings or SETTINGS)
    g: StateGraph = StateGraph(Layer1State)

    g.add_node("read_inbox", nodes.read_inbox)
    g.add_node("move_to_processing", nodes.move_to_processing)
    g.add_node("dispatch", nodes.dispatch)
    g.add_node("inspect_message", nodes.inspect_message)
    g.add_node("classify_content", nodes.classify_content)
    g.add_node("discard_item", nodes.discard_item)
    g.add_node("validate_files", nodes.validate_files)
    g.add_node("store_clean_files", nodes.store_clean_files)
    g.add_node("build_email_master_row", nodes.build_email_master_row)
    g.add_node("print_report", nodes.print_report)

    g.add_edge(START, "read_inbox")
    g.add_edge("read_inbox", "move_to_processing")
    g.add_edge("move_to_processing", "dispatch")

    g.add_conditional_edges(
        "dispatch", _route_dispatch,
        {"process": "inspect_message", "finish": "print_report"},
    )
    g.add_edge("inspect_message", "classify_content")
    g.add_conditional_edges(
        "classify_content", _route_classification,
        {"discard": "discard_item", "proceed": "validate_files"},
    )
    g.add_edge("discard_item", "dispatch")
    g.add_conditional_edges(
        "validate_files", _route_validation,
        {"store": "store_clean_files", "skip": "build_email_master_row"},
    )
    g.add_edge("store_clean_files", "build_email_master_row")
    g.add_edge("build_email_master_row", "dispatch")
    g.add_edge("print_report", END)

    return g.compile()


def initial_state(run_id: str) -> Layer1State:
    """Return a fresh, fully-initialized Layer 1 state."""
    return Layer1State(
        run_id=run_id,
        items=[],
        cursor=0,
        current_item=None,
        classification=None,
        validation_results=[],
        stored_files=[],
        discarded_items=[],
        email_master_rows=[],
        audit_events=[],
        workflow_results=[],
        pending_store=[],
        pending_status="",
        pending_manual_review=[],
        pending_stored_names=[],
        pending_workflows=[],
    )
