"""Workflows A (links), B (ZIP), C (Excel) — the File Processing skill.

Each workflow performs Download → Extract → Validate and returns a uniform
*intermediate* result the graph can aggregate::

    {
      "workflow": "links" | "zip" | "excel" | "attachment",
      "total": int,                 # units attempted (files / inner files / rows)
      "passed": int,                # units that validated cleanly
      "ready_files": [ {source_path, desired_name} ],  # validated, awaiting store
      "manual_review": [ {row|item, reason} ],
      "errors": [ str ],
    }

Actual storage into ``local/raw/`` is done by the ``store_clean_files`` node, so
the graph keeps Download/Extract/Validate (here) separate from Store (node) and
Report (reporting). A workflow NEVER stops because one unit fails.

Critical boundaries (per the skill): no resume parsing, no ATS scoring, no
candidate profiles, no dedup of candidates. Only Download → Extract → Validate
→ (hand off for) Store → Report.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from app.logging_config import get_logger
from app.mail_config import FINAL_TYPES, Settings
from app.models.mail import WorkflowResult
from app.pipeline.mail.download import download_link
from app.pipeline.mail.tools.validation import (
    extract_zip,
    read_excel_rows,
    validate_by_extension,
)

log = get_logger(__name__)


def _empty(workflow: str) -> dict[str, Any]:
    return {
        "workflow": workflow,
        "total": 0,
        "passed": 0,
        "ready_files": [],
        "manual_review": [],   # [{row|item, reason}] — needs human follow-up
        "failures": [],        # [{filename, reason}] — hard validation failures
        "errors": [],          # free-text log lines (incl. informational skips)
    }


def _validate_final_file(path: str) -> tuple[bool, str]:
    res = validate_by_extension(path)
    return bool(res["ok"]), str(res.get("reason", ""))


# --- Workflow A: links ------------------------------------------------------

def workflow_links(
    settings: Settings, e_id: str, links: list[str], dest_dir: str
) -> dict[str, Any]:
    """Resolve + (locally) download each link, then validate the file."""
    result = _empty("links")
    for url in links:
        dl = download_link(settings, url, dest_dir, item_eid=e_id)
        if not dl["success"]:
            # The link itself is the failed unit.
            result["total"] += 1
            result["manual_review"].append({"item": url, "reason": dl["reason"]})
            result["errors"].append(f"link_download_failed:{url}:{dl['reason']}")
            continue
        path = dl["file_path"]
        ext = Path(path).suffix.lower()
        # Containers expand into sub-workflows that contribute their own units;
        # the wrapping link is NOT counted separately.
        if ext == ".zip":
            _merge(result, workflow_zip(settings, e_id, path, dest_dir))
            if len(links) == 1:
                result["workflow"] = "zip"
            continue
        if ext == ".xlsx":
            _merge(result, workflow_excel(settings, e_id, path, dest_dir))
            if len(links) == 1:
                result["workflow"] = "excel"
            continue
        # A link that yields a single resume file: the link is the unit.
        result["total"] += 1
        if ext in FINAL_TYPES:
            ok, reason = _validate_final_file(path)
            if ok:
                result["passed"] += 1
                result["ready_files"].append(
                    {"source_path": path, "desired_name": Path(path).name}
                )
            else:
                result["failures"].append({"filename": Path(path).name, "reason": reason})
                result["errors"].append(f"link_validate_failed:{url}:{reason}")
        else:
            result["failures"].append(
                {"filename": Path(path).name, "reason": f"unsupported_type:{ext}"}
            )
            result["errors"].append(f"link_unsupported_type:{url}:{ext}")
    return result


def _merge(into: dict[str, Any], sub: dict[str, Any]) -> None:
    """Fold a sub-workflow's counts into a parent (links wrapping zip/excel)."""
    into["total"] += sub["total"]
    into["passed"] += sub["passed"]
    into["ready_files"].extend(sub["ready_files"])
    into["manual_review"].extend(sub["manual_review"])
    into["failures"].extend(sub["failures"])
    into["errors"].extend(sub["errors"])


# --- Workflow B: ZIP --------------------------------------------------------

def workflow_zip(
    settings: Settings, e_id: str, zip_path: str, dest_dir: str
) -> dict[str, Any]:
    """Extract a ZIP (skip nested zips/junk) and validate each inner file."""
    result = _empty("zip")
    extract_dir = str(Path(dest_dir) / f"_zip_{Path(zip_path).stem}")
    res = extract_zip(zip_path, extract_dir)
    if not res["ok"]:
        result["errors"].append(f"zip_failed:{Path(zip_path).name}:{res['reason']}")
        return result
    for inner in res["extracted"]:
        result["total"] += 1
        ok, reason = _validate_final_file(inner)
        if ok:
            result["passed"] += 1
            result["ready_files"].append(
                {"source_path": inner, "desired_name": Path(inner).name}
            )
        else:
            result["failures"].append({"filename": Path(inner).name, "reason": reason})
            result["errors"].append(f"zip_inner_invalid:{Path(inner).name}:{reason}")
    for skipped in res["skipped"]:
        # Skipped nested zips / junk are informational, not validation failures.
        result["errors"].append(f"zip_skipped:{skipped}")
    return result


# --- Workflow C: Excel ------------------------------------------------------

def workflow_excel(
    settings: Settings, e_id: str, excel_path: str, dest_dir: str
) -> dict[str, Any]:
    """Treat each row as a candidate; download + validate each resume link."""
    result = _empty("excel")
    sheet = read_excel_rows(excel_path)
    if not sheet["ok"]:
        result["errors"].append(f"excel_failed:{Path(excel_path).name}:{sheet['reason']}")
        return result

    for row in sheet["rows"]:
        result["total"] += 1
        row_no = row["row_number"]
        link = row.get("resume_link", "")
        # Manual-review rows carry the WHOLE row (name/email/phone/link/row_cells)
        # so the review queue can show the candidate and every original column.
        if not link:
            result["manual_review"].append({**row, "reason": "missing_resume_link"})
            continue
        dl = download_link(settings, link, dest_dir, item_eid=e_id)
        if not dl["success"]:
            # Carry the SPECIFIC reason to manual review so a recruiter knows
            # WHY: "google_infected_file" means the candidate must re-share a
            # clean file (a retry can't fix it — Google hard-blocks it); a
            # transient failure just needs the row re-run.
            dl_reason = dl.get("reason", "")
            row_reason = "download_infected" if dl_reason == "google_infected_file" else "download_failed"
            result["manual_review"].append({**row, "reason": row_reason, "detail": dl_reason})
            result["errors"].append(f"excel_row_{row_no}_download_failed:{dl_reason}")
            continue
        ok, reason = _validate_final_file(dl["file_path"])
        if ok:
            result["passed"] += 1
            result["ready_files"].append(
                {"source_path": dl["file_path"],
                 "desired_name": Path(dl["file_path"]).name,
                 # Every original spreadsheet column for THIS row — carried through
                 # storage so L3 can attach it to the candidate as source columns
                 # (and let an Excel CGPA override the resume-extracted one).
                 "row_cells": row.get("row_cells") or {}}
            )
        else:
            result["manual_review"].append({**row, "reason": "invalid_file"})
            result["errors"].append(f"excel_row_{row_no}_invalid:{reason}")
    return result


# --- Final Output Schema builder -------------------------------------------

def _status_from_counts(total: int, passed: int) -> str:
    if total == 0 or passed == 0:
        return "Fail"
    if passed == total:
        return "Success"
    return "Partial"


def to_schema(
    e_id: str, intermediate: dict[str, Any], stored_files: list[str]
) -> WorkflowResult:
    """Convert an intermediate workflow result + final stored names to schema."""
    total = intermediate["total"]
    passed = intermediate["passed"]
    manual = len(intermediate["manual_review"])
    return WorkflowResult(
        e_id=e_id,
        workflow=intermediate["workflow"],
        status=_status_from_counts(total, passed),
        processed_count=total,
        success_count=passed,
        failure_count=max(total - passed - manual, 0),
        manual_review_count=manual,
        stored_files=stored_files,
        errors=list(intermediate["errors"]),
    )
