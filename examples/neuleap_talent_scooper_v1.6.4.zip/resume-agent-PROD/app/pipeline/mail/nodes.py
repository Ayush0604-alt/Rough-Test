"""Thin LangGraph node implementations.

Each node has exactly one responsibility and calls the deterministic Layer-1
service functions directly (``file_ops``, ``metadata``, ``reporting``,
``validation`` — plain Python, no tool registry, no MCP). Business logic
(counting, status math) lives in small helpers here and in
:mod:`app.pipeline.mail.tools.reporting`. Nodes are bound to a :class:`Settings`
via :class:`Layer1Nodes` so the graph can be pointed at a temp dir in tests.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from app.db import email_master as db
from app.db import save_intake_excel_columns
from app.logging_config import get_logger
from app.mail_config import FINAL_TYPES, Settings
from app.models.mail import (
    AuditEvent,
    DiscardedItem,
    EmailItem,
    EmailMasterRow,
    Layer1State,
    StoredFile,
    ValidationMode,
    ValidationResult,
)
from app.pipeline.mail import classifier, workflows
from app.pipeline.mail.tools import file_ops, reporting
from app.pipeline.mail.tools import metadata as metadata_tools
from app.pipeline.mail.tools.validation import validate_by_extension
from app.constants import ReviewKind
from app.services import clock
from app.services import mail_audit as audit
from app.services import mail_storage as storage
from app.services import review_queue

log = get_logger(__name__)


def _now() -> str:
    return clock.now_iso()


class Layer1Nodes:
    """Container of node callables bound to one :class:`Settings`."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        # Ephemeral per-run scratch. Staged items are downloaded from MinIO into
        # here for processing; the whole tree is deleted in print_report. MinIO
        # is the only durable store — nothing persists locally between runs.
        import tempfile
        self._work_root = Path(tempfile.mkdtemp(prefix="neuleap_l1_"))

    # -- helpers ------------------------------------------------------------

    def _item_dir(self, e_id: str) -> Path:
        """Per-item ephemeral working folder under the run's temp root."""
        return self._work_root / e_id

    def _audit(
        self, state: Layer1State, e_id: str | None, node: str, status: str, reason: str = ""
    ) -> AuditEvent:
        event = AuditEvent(
            run_id=state["run_id"],
            e_id=e_id,
            node=node,
            status=status,
            reason=reason,
            created_at=_now(),
        )
        state["audit_events"].append(event)
        # Mirror consequential events to the flat audit.log ledger (not a DB table).
        if status in ("Failed", "Discarded", "ManualReview", "Retry", "Exhausted"):
            try:
                audit.log_event(self.settings, state["run_id"], e_id,
                                node=node, status=status, reason=reason)
            except Exception as exc:  # noqa: BLE001
                log.warning("audit write failed (%s/%s): %s", e_id, status, exc)
        return event

    def _current(self, state: Layer1State) -> EmailItem:
        return state["items"][state["cursor"]]

    # -- nodes --------------------------------------------------------------

    def read_inbox(self, state: Layer1State) -> dict[str, Any]:
        """Discover pending items from the MinIO staging queue (raw/temp/{E_id}/).

        Items are staged into MinIO by the intake layer (/intake/graph, /upload).
        Already-Passed E_ids are skipped; Failed ones are retried.
        """
        from app.services import source_tags

        items: list[EmailItem] = []
        already_passed = db.passed_eids()   # skip done items; Failed ones retry
        for e_id in storage.list_staged_eids():
            if e_id in already_passed:
                continue
            meta = storage.get_staging_manifest(e_id)
            if not meta:
                continue
            # candidate_source is normally stamped once, at staging time (see
            # mail_intake._stage_one_graph_message). A Graph mail that staged
            # with no tag active yet still gets one last chance here, at the
            # latest possible moment before a candidate row is created —
            # otherwise a tag activated in the (often short) window between a
            # message landing and the next pipeline run would permanently miss
            # it. Never overrides an ALREADY-stamped value (a mail tagged under
            # one active post keeps that attribution even if a different tag
            # is active by the time it's actually processed), and never
            # applies to manual uploads (those always carry their own
            # explicit, recruiter-typed source).
            # Both graph staging paths qualify: "graph" (Inbox drain) and
            # "graph-processing" (the poller's Processing-queue drain). Uploads
            # carry their own explicit source and are excluded.
            candidate_source = meta.get("candidate_source") or None
            if not candidate_source and (meta.get("source") or "").startswith("graph"):
                candidate_source = source_tags.active_label()
            items.append(
                EmailItem(
                    e_id=e_id,
                    manifest_name=f"{e_id}.json",
                    sender_mail_id=str(meta.get("sender_mail_id") or "unknown"),
                    subject=str(meta.get("subject") or "unknown"),
                    received_date=meta.get("received_date") or None,
                    body=str(meta.get("body") or ""),
                    attachment_files=[Path(a).name for a in (meta.get("attachments") or [])],
                    declared_links=[str(link) for link in (meta.get("links") or [])],
                    processing_subdir=e_id,
                    candidate_source=candidate_source,
                )
            )

        log.info("read_inbox: %d staged item(s) from MinIO", len(items))
        for item in items:
            self._audit(state, item.e_id, "read_inbox", "Info",
                        f"discovered: {item.subject!r}")
        return {"items": items, "cursor": 0}

    def move_to_processing(self, state: Layer1State) -> dict[str, Any]:
        """Download each item's staged files from MinIO into its temp work dir."""
        for item in state["items"]:
            dest = self._item_dir(item.e_id)
            downloaded = storage.download_staging(item.e_id, str(dest))
            # The downloaded set is authoritative (MinIO is the source of truth).
            item.attachment_files = downloaded
            item.processing_subdir = item.e_id
        return {"items": state["items"]}

    def dispatch(self, state: Layer1State) -> dict[str, Any]:
        """No-op routing checkpoint; sets current_item for the active cursor."""
        if state["cursor"] < len(state["items"]):
            return {"current_item": self._current(state)}
        return {"current_item": None}

    def inspect_message(self, state: Layer1State) -> dict[str, Any]:
        """Reconcile attachments with files on disk and detect usable links."""
        item = self._current(state)
        item_dir = self._item_dir(item.e_id)
        present = (
            {p.name for p in item_dir.iterdir() if p.is_file()} if item_dir.exists() else set()
        )
        item.attachment_files = [
            name for name in item.attachment_files if Path(name).name in present
        ]
        item.detected_links = metadata_tools.detect_links(
            self.settings, item.body, item.declared_links
        )
        self._audit(
            state, item.e_id, "inspect_message", "Info",
            f"attachments={item.attachment_files} links={len(item.detected_links)}",
        )
        return {"items": state["items"], "current_item": item}

    def classify_content(self, state: Layer1State) -> dict[str, Any]:
        """Classify the email as Attachment / Links / Mixed / None."""
        item = self._current(state)
        has_attachments = len(item.attachment_files) > 0
        has_links = len(item.detected_links) > 0
        classification = classifier.refine_classification(
            self.settings,
            subject=item.subject,
            body=item.body,
            has_attachments=has_attachments,
            has_links=has_links,
        )
        self._audit(state, item.e_id, "classify_content", "Info", classification.value)
        return {"classification": classification}

    def discard_item(self, state: Layer1State) -> dict[str, Any]:
        """Record a None-classified email as discarded; create no master row."""
        item = self._current(state)
        state["discarded_items"].append(
            DiscardedItem(
                e_id=item.e_id,
                sender_mail_id=item.sender_mail_id,
                subject=item.subject,
                reason="no_attachment_no_link",
            )
        )
        self._audit(state, item.e_id, "discard_item", "Discarded", "no_attachment_no_link")
        log.info("discarded %s (no usable attachment or link)", item.e_id)
        return {"cursor": state["cursor"] + 1, "classification": None}

    def _run_workflows(self, item: EmailItem) -> tuple[ValidationMode, list[dict]]:
        """Route the item's files/links to Workflows A/B/C; return mode + results.

        Each entry in the returned list is an intermediate workflow dict (see
        :mod:`neuleap_layer1.workflows`). Plain final-type attachments are folded
        into a single ``attachment`` intermediate.
        """
        subdir = self._item_dir(item.e_id)
        dest = str(subdir / "_dl")
        files = [
            name for name in item.attachment_files
            if (subdir / Path(name).name).exists()
        ]
        links = item.detected_links

        intermediates = self._classify_attachments(item.e_id, subdir, dest, files)
        if links:
            intermediates.append(workflows.workflow_links(self.settings, item.e_id, links, dest))

        return self._pick_mode(intermediates, files, links), intermediates

    def _classify_attachments(
        self, e_id: str, subdir: Path, dest: str, files: list[str]
    ) -> list[dict[str, Any]]:
        """Route each on-disk attachment to its workflow; fold plain final-type
        files into a single ``attachment`` intermediate."""
        intermediates: list[dict[str, Any]] = []
        attachment = workflows._empty("attachment")
        for name in files:
            ext = Path(name).suffix.lower()
            src = subdir / Path(name).name
            if ext == ".zip":
                intermediates.append(
                    workflows.workflow_zip(self.settings, e_id, str(src), dest)
                )
            elif ext == ".xlsx":
                intermediates.append(
                    workflows.workflow_excel(self.settings, e_id, str(src), dest)
                )
            elif ext in FINAL_TYPES:
                attachment["total"] += 1
                vr = validate_by_extension(str(src))
                if vr["ok"]:
                    attachment["passed"] += 1
                    attachment["ready_files"].append(
                        {"source_path": str(src), "desired_name": src.name}
                    )
                else:
                    attachment["failures"].append(
                        {"filename": name, "reason": vr["reason"]})
            else:
                attachment["total"] += 1
                attachment["failures"].append(
                    {"filename": name, "reason": f"unsupported_type:{ext}"})
        if attachment["total"] > 0:
            intermediates.append(attachment)
        return intermediates

    @staticmethod
    def _pick_mode(
        intermediates: list[dict[str, Any]], files: list[str], links: list[str]
    ) -> ValidationMode:
        """Choose status-wording mode. A lone ZIP/Excel workflow (even via a link)
        uses files/rows wording; link-only uses LINK; otherwise PLAIN."""
        single_wf = intermediates[0]["workflow"] if len(intermediates) == 1 else None
        if single_wf == "zip":
            return ValidationMode.ZIP
        if single_wf == "excel":
            return ValidationMode.EXCEL
        if not files and links:
            return ValidationMode.LINK
        return ValidationMode.PLAIN

    def validate_files(self, state: Layer1State) -> dict[str, Any]:
        """Run Workflows A/B/C for the current item; compute extracted_status."""
        item = self._current(state)
        mode, intermediates = self._run_workflows(item)

        total = sum(i["total"] for i in intermediates)
        passed = sum(i["passed"] for i in intermediates)
        pending_store: list[dict] = []
        pending_workflows: list[dict] = []
        for inter in intermediates:
            ready = inter["ready_files"]
            pending_store.extend(ready)
            pending_workflows.append({
                "workflow": inter["workflow"],
                "total": inter["total"],
                "passed": inter["passed"],
                "manual_review": inter["manual_review"],
                "errors": inter["errors"],
                "ready_count": len(ready),
            })
            # Hard validation failures -> validation_results + Failed audit.
            for fail in inter["failures"]:
                state["validation_results"].append(ValidationResult(
                    e_id=item.e_id, filename=fail["filename"],
                    file_type=inter["workflow"], ok=False, reason=fail["reason"],
                ))
                # _audit mirrors to the shared Postgres ledger (mail_audit.log_event
                # → shared_audit.write_event), so this is the single ledger write —
                # writing again here produced duplicate audit_log rows per failure.
                self._audit(state, item.e_id, "validate_files", "Failed",
                            f"invalid_file: {fail['filename']}: {fail['reason']}")
                # Review queue — structured invalid-file row. A rejected file is
                # corrupt / oversized / unsupported / locked, so it is NOT persisted
                # for viewing (no raw_s3_key) and the UI shows Discard only — the
                # reason tells the recruiter what to ask the sender to fix.
                review_queue.enqueue(
                    e_id=item.e_id, batch_id=state["run_id"], layer="L1",
                    kind=ReviewKind.INVALID_FILE, filename=fail["filename"],
                    reason=fail["reason"], details={"reason_code": fail["reason"]},
                )
            # Manual-review units (excel rows w/o link, link not fetchable, ...).
            for mr in inter["manual_review"]:
                key = mr.get("row_number", mr.get("item", "?"))
                # Single ledger write — _audit already mirrors to Postgres (see above).
                self._audit(state, item.e_id, "validate_files", "ManualReview",
                            f"{inter['workflow']}:{key}:{mr['reason']}")
                # Review queue — Excel row (full row + all columns) or failed link.
                if "row_number" in mr:
                    review_queue.enqueue(
                        e_id=item.e_id, batch_id=state["run_id"], layer="L1",
                        kind=ReviewKind.EXCEL_ROW, reason=mr.get("reason"),
                        details={
                            "row_number": mr.get("row_number"),
                            "name": mr.get("name", ""), "email": mr.get("email", ""),
                            "phone": mr.get("phone", ""),
                            "resume_link": mr.get("resume_link", ""),
                            "reason_code": mr.get("reason"),
                            "row_cells": mr.get("row_cells", {}),
                        },
                    )
                else:
                    review_queue.enqueue(
                        e_id=item.e_id, batch_id=state["run_id"], layer="L1",
                        kind=ReviewKind.LINK_FETCH, reason=mr.get("reason"),
                        details={"url": mr.get("item", ""), "reason_code": mr.get("reason")},
                    )
            # Informational skips (nested zips, junk) -> Info audit only.
            for err in inter["errors"]:
                if err.startswith("zip_skipped"):
                    self._audit(state, item.e_id, "validate_files", "Info", err)

        status = reporting.compute_extracted_status(mode, total, passed)
        log.info("validate %s: mode=%s %d/%d -> %s",
                 item.e_id, mode.value, passed, total, status)
        return {
            "pending_store": pending_store,
            "pending_status": status,
            "pending_workflows": pending_workflows,
        }

    def store_clean_files(self, state: Layer1State) -> dict[str, Any]:
        """Upload validated files to MinIO raw/{YYYY}/{MM}/{DD}/{E_id}/, deduping safely.

        Files are deduped into an ephemeral temp out-dir purely to compute a
        collision-safe name, then uploaded to MinIO (the only durable store) and
        the staging entry (raw/temp/{E_id}/) is purged. Nothing persists locally.
        """
        item = self._current(state)
        out_dir = self._item_dir(item.e_id) / "_out"
        stored_names: list[str] = []
        for entry in state.get("pending_store", []):
            final_name = file_ops.save_clean_file(
                self.settings,
                entry["source_path"], entry["desired_name"], str(out_dir),
            )
            local_final = out_dir / final_name
            # Durable copy → MinIO raw/{YYYY}/{MM}/{DD}/{E_id}/ (the L2 handoff).
            uri = storage.put_final(str(local_final), item.e_id, item.received_date, final_name)
            state["stored_files"].append(
                StoredFile(
                    e_id=item.e_id,
                    original_name=entry["desired_name"],
                    stored_name=final_name,
                    stored_path=uri or str(local_final),
                )
            )
            stored_names.append(final_name)
            # Excel-sourced file → stash its row's columns keyed by the FINAL
            # stored name, so L3 can attach them to the candidate this file
            # becomes (best-effort — a carrier hiccup never blocks the store).
            row_cells = entry.get("row_cells")
            if row_cells:
                try:
                    save_intake_excel_columns(item.e_id, final_name, row_cells)
                except Exception as exc:  # noqa: BLE001
                    log.warning("[L1] could not stash excel columns for %s: %s", final_name, exc)
            if final_name != entry["desired_name"]:
                self._audit(state, item.e_id, "store_clean_files", "Info",
                            f"renamed_duplicate:{entry['desired_name']}->{final_name}")
        # Staging quarantine (raw/temp/{E_id}/) has served its purpose for this email.
        if stored_names:
            storage.purge_temp(item.e_id)
        return {"pending_stored_names": stored_names}

    def build_email_master_row(self, state: Layer1State) -> dict[str, Any]:
        """Build exactly one Email_Master row for the current item."""
        item = self._current(state)
        stored_names = state.get("pending_stored_names", [])
        status = state.get("pending_status", "Fail")
        row_dict = reporting.build_email_master_row(
            item.e_id, item.sender_mail_id, item.subject,
            item.received_date, stored_names, status,
            candidate_source=item.candidate_source,
        )
        row = EmailMasterRow(**row_dict)
        state["email_master_rows"].append(row)

        # Persist the one-and-only Email_Master row to PostgreSQL (no-op when
        # DATABASE_URL is unset, e.g. offline unit tests). Pending state is
        # derived from this row — no separate intake table to update.
        try:
            db.upsert_email_master(row.model_dump())
        except Exception as exc:  # noqa: BLE001 — never fail a run on a DB hiccup
            log.warning("email_master persist failed for %s: %s", item.e_id, exc)

        # Build one Final Output Schema per workflow invoked, slicing the final
        # (deduped) stored names back to the workflow that produced them.
        offset = 0
        for wf in state.get("pending_workflows", []):
            count = wf["ready_count"]
            wf_stored = stored_names[offset:offset + count]
            offset += count
            state["workflow_results"].append(
                workflows.to_schema(item.e_id, wf, wf_stored)
            )

        self._audit(state, item.e_id, "build_email_master_row",
                    "Success" if row.process_status == "Passed" else "Failed",
                    f"{status} -> {row.process_status}")
        # Advance and clear transient scratch for the next item.
        return {
            "cursor": state["cursor"] + 1,
            "pending_store": [],
            "pending_status": "",
            "pending_manual_review": [],
            "pending_stored_names": [],
            "pending_workflows": [],
            "classification": None,
        }

    def print_report(self, state: Layer1State) -> dict[str, Any]:
        """Render the final Email_Master table (returned, not just printed)."""
        rows = [r.model_dump() for r in state["email_master_rows"]]
        table = reporting.print_markdown_table(rows)
        log.info("print_report: %d row(s)", len(rows))
        # Stash the rendered table so the runner can present it.
        state["_table"] = table  # type: ignore[typeddict-unknown-key]
        # Ephemeral scratch is no longer needed — MinIO holds everything durable.
        import shutil
        shutil.rmtree(self._work_root, ignore_errors=True)
        return {}
