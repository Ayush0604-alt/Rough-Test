"""Reporting tools: extracted_status math, row building, markdown rendering."""

from __future__ import annotations

from typing import Any

from app.models.mail import EmailMasterRow, ProcessStatus, ValidationMode


def _zip_status(total: int, passed: int) -> str:
    if total == 0:
        return "Fail(0/0 files)"
    if passed == total:
        return f"Success({passed} files)"
    if passed == 0:
        return f"Fail(0/{total} files)"
    return f"Partial({passed}/{total} files)"


def _excel_status(total: int, passed: int) -> str:
    if total == 0:
        return "Fail(0/0 rows)"
    if passed == total:
        return f"Success({passed}/{total} rows)"
    if passed == 0:
        return f"Fail(0/{total} rows)"
    return f"Partial({passed}/{total} rows)"


def _plain_status(total: int, passed: int) -> str:
    if total == 0 or passed == 0:
        return "Fail"
    if passed == total:
        return "Success"
    return f"Partial({passed}/{total})"


def compute_extracted_status(mode: ValidationMode, total: int, passed: int) -> str:
    """Derive the ``extracted_status`` string from counts + mode.

    * total == 0            -> ``Fail`` (nothing storable; e.g. link-only local)
    * passed == total > 0   -> ``Success`` (worded per mode)
    * 0 < passed < total    -> ``Partial(N/M ...)``
    * passed == 0 < total   -> ``Fail`` (worded per mode)
    """
    if mode is ValidationMode.ZIP:
        return _zip_status(total, passed)
    if mode is ValidationMode.EXCEL:
        return _excel_status(total, passed)
    return _plain_status(total, passed)  # PLAIN / LINK / MIXED


def derive_process_status(extracted_status: str) -> ProcessStatus:
    """Passed if Success/Partial, Failed if Fail."""
    if extracted_status.startswith("Fail"):
        return ProcessStatus.FAILED
    return ProcessStatus.PASSED


def build_email_master_row(
    e_id: str,
    sender_mail_id: str,
    subject: str,
    received_date: str | None,
    attachment_names: list[str],
    extracted_status: str,
    candidate_source: str | None = None,
) -> dict[str, Any]:
    """Build one Email_Master row (as a dict) with the required 7 columns
    plus the recruiter-typed intake source (8th, source-tagging feature)."""
    process_status = derive_process_status(extracted_status)
    row = EmailMasterRow(
        E_id=e_id,
        sender_mail_id=sender_mail_id,
        subject=subject,
        received_date=received_date or "unknown",
        attachment_names=", ".join(attachment_names) if attachment_names else "-",
        extracted_status=extracted_status,
        process_status=process_status.value,
        candidate_source=candidate_source,
    )
    return row.model_dump()


_COLUMNS = [
    "E_id",
    "sender_mail_id",
    "subject",
    "received_date",
    "attachment_names",
    "extracted_status",
    "process_status",
]


def print_markdown_table(rows: list[dict[str, Any]]) -> str:
    """Render Email_Master rows as a GitHub-flavored markdown table string."""
    header = "| " + " | ".join(_COLUMNS) + " |"
    divider = "| " + " | ".join("---" for _ in _COLUMNS) + " |"
    lines = [header, divider]
    for row in rows:
        cells = [str(row.get(col, "")) for col in _COLUMNS]
        lines.append("| " + " | ".join(cells) + " |")
    return "\n".join(lines)
