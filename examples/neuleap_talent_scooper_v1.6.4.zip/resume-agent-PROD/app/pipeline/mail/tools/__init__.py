"""Layer 1 deterministic services — the file-processing layer behind the nodes.

Plain Python functions grouped by responsibility. The LangGraph nodes
(:mod:`app.pipeline.mail.nodes`) and workflows (:mod:`app.pipeline.mail.workflows`)
import and call these directly — there is no tool registry, no dispatcher, and
no MCP layer.

* ``file_ops``   — inbox/processing/raw file movement + dedup-safe save
* ``metadata``   — manifest parsing, link detection
* ``validation`` — PDF/DOCX/image/Excel/ZIP validation + extraction
* ``reporting``  — Email_Master row + markdown table builders
"""

from __future__ import annotations

from . import file_ops, metadata, reporting, validation  # noqa: F401

__all__ = ["file_ops", "metadata", "reporting", "validation"]
