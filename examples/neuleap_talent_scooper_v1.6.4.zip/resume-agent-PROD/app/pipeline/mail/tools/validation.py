"""Local file-validation tools (deterministic, NO AI).

Each validator opens a file with the appropriate library and reports whether it
is usable. Validators never raise on bad input — they return a structured result
so the pipeline can record failures and keep going.

Acceptable final types : .pdf .docx .jpg .jpeg .png
Special inputs          : .zip (expanded) .xlsx (rows = resume sources)
"""

from __future__ import annotations

import zipfile
from pathlib import Path
from typing import Any

# Import heavy parsers at MODULE LOAD (main thread / server startup). Importing
# them lazily inside a function that may run on a worker thread can deadlock on
# Python's import lock (observed with openpyxl's first import), so load eagerly.
import openpyxl  # noqa: E402

from app.logging_config import get_logger
from app.mail_config import (
    FINAL_TYPES,
    ZIP_MAX_ENTRIES,
    ZIP_MAX_ENTRY_BYTES,
    ZIP_MAX_RATIO,
    ZIP_MAX_TOTAL_BYTES,
    oversize_reason,
)

log = get_logger(__name__)

_IMAGE_EXTS = {".jpg", ".jpeg", ".png"}


def _result(ok: bool, reason: str = "", **extra: Any) -> dict[str, Any]:
    return {"ok": ok, "reason": reason, **extra}


def _size_reason(p: Path) -> str | None:
    """Return a ``file_too_large: …`` reason if the file exceeds its per-type cap.

    Deterministic, runs before any parsing. An oversized file is rejected here so
    it flows to FAILED through the normal Step 10 path instead of being stored.
    """
    try:
        return oversize_reason(p.name, p.stat().st_size)
    except OSError:
        return None


def validate_pdf(path: str) -> dict[str, Any]:
    """Validate a PDF: opens, not corrupt, not password-locked, has pages."""
    import fitz  # PyMuPDF

    p = Path(path)
    if not p.exists():
        return _result(False, "missing_file")
    if (reason := _size_reason(p)):
        return _result(False, reason)
    try:
        doc = fitz.open(str(p))
    except Exception as exc:  # noqa: BLE001 - any open failure means corrupt
        return _result(False, f"pdf_corrupt: {exc}")
    try:
        if doc.needs_pass or doc.is_encrypted:
            return _result(False, "pdf_password_locked")
        if doc.page_count < 1:
            return _result(False, "pdf_no_pages")
        # Touch the first page to confirm the body is readable, not just a header.
        _ = doc.load_page(0).get_text("text")
    except Exception as exc:  # noqa: BLE001
        return _result(False, f"pdf_unreadable: {exc}")
    finally:
        doc.close()
    return _result(True)


def validate_docx(path: str) -> dict[str, Any]:
    """Validate a DOCX: opens with python-docx and is not corrupt/encrypted."""
    import docx  # python-docx

    p = Path(path)
    if not p.exists():
        return _result(False, "missing_file")
    if (reason := _size_reason(p)):
        return _result(False, reason)
    # Password-protected Office files are OLE/CFB containers, not real zips.
    if not zipfile.is_zipfile(str(p)):
        return _result(False, "docx_corrupt_or_encrypted")
    try:
        document = docx.Document(str(p))
        _ = len(document.paragraphs)  # force parse of the document part
    except Exception as exc:  # noqa: BLE001
        return _result(False, f"docx_corrupt: {exc}")
    return _result(True)


# OLE2 compound-document magic — the signature of a real legacy .doc file.
_OLE2_MAGIC = b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"


def validate_doc(path: str) -> dict[str, Any]:
    """Validate a legacy .doc: exists and is a real OLE2 compound document.

    Full text conversion (LibreOffice → .docx) happens downstream at extraction
    time; here we only confirm the bytes are a genuine .doc so junk is rejected
    while real .doc resumes survive into raw/.
    """
    p = Path(path)
    if not p.exists():
        return _result(False, "missing_file")
    if (reason := _size_reason(p)):
        return _result(False, reason)
    try:
        with open(str(p), "rb") as fh:
            head = fh.read(8)
    except Exception as exc:  # noqa: BLE001
        return _result(False, f"doc_unreadable: {exc}")
    if head != _OLE2_MAGIC:
        return _result(False, "doc_not_ole2_or_corrupt")
    return _result(True)


def validate_image(path: str) -> dict[str, Any]:
    """Validate a JPG/PNG: opens, verifies, and has positive dimensions."""
    from PIL import Image

    p = Path(path)
    if not p.exists():
        return _result(False, "missing_file")
    if (reason := _size_reason(p)):
        return _result(False, reason)
    try:
        with Image.open(str(p)) as img:
            img.verify()  # detects truncation / corruption without decoding
        # verify() leaves the image unusable; reopen to read size.
        with Image.open(str(p)) as img2:
            width, height = img2.size
            mode = img2.mode
    except Exception as exc:  # noqa: BLE001
        return _result(False, f"image_corrupt: {exc}")
    if width <= 0 or height <= 0:
        return _result(False, "image_bad_dimensions", width=width, height=height)
    return _result(True, "", width=width, height=height, mode=mode)


def _find_link_column(header: list[Any]) -> int | None:
    for idx, cell in enumerate(header):
        if cell is None:
            continue
        label = str(cell).strip().lower()
        if any(k in label for k in ("link", "url", "resume")):
            return idx
    return None


def _looks_like_url(value: str) -> bool:
    return value.startswith("http://") or value.startswith("https://")


def validate_excel(path: str) -> dict[str, Any]:
    """Validate an XLSX and treat sheet-1 rows as resume sources.

    Rows whose link cell is empty or malformed are flagged for manual review;
    other rows continue to count as valid sources. Returns total/valid counts
    and the 1-based row numbers that need manual review.
    """
    p = Path(path)
    if not p.exists():
        return _result(False, "missing_file")
    if (reason := _size_reason(p)):
        return _result(False, reason)
    try:
        # Eager load (read_only=False): the lazy read_only iterator can deadlock
        # on a worker thread; eager load is fast for resume-sized sheets.
        wb = openpyxl.load_workbook(str(p), read_only=False, data_only=True)
    except Exception as exc:  # noqa: BLE001 - includes encrypted workbooks
        return _result(False, f"excel_corrupt_or_locked: {exc}")
    try:
        ws = wb[wb.sheetnames[0]]
        rows = list(ws.iter_rows(values_only=True))
    finally:
        wb.close()

    if not rows:
        return _result(False, "excel_empty", total_rows=0, valid_rows=0,
                       manual_review_rows=[])

    header = list(rows[0])
    link_col = _find_link_column(header)
    data_rows = rows[1:]
    total = len(data_rows)
    valid = 0
    manual_review: list[int] = []

    for offset, row in enumerate(data_rows):
        excel_row_no = offset + 2  # account for header + 1-based indexing
        cell = None
        if link_col is not None and link_col < len(row):
            cell = row[link_col]
        value = "" if cell is None else str(cell).strip()
        if value and _looks_like_url(value):
            valid += 1
        else:
            manual_review.append(excel_row_no)

    ok = total > 0
    return _result(
        ok,
        "" if valid == total else "excel_rows_need_manual_review",
        total_rows=total,
        valid_rows=valid,
        manual_review_rows=manual_review,
    )


def _norm_header(cell: Any) -> str:
    return str(cell or "").strip().lower().replace(" ", "_")


_RESUME_LINK_ALIASES = (
    "resume_link", "resume_url", "cv_link", "candidate_resume", "resume", "url", "link"
)


def _load_excel_grid(p: Path) -> tuple[list, dict, str]:
    """Eager-load sheet 1. Returns (rows, hyperlinks, error).

    ``hyperlinks`` maps ``(row_idx, col_idx)`` (0-based, header included) to
    the cell's hyperlink target. Google Forms response sheets store the
    uploaded file's DRIVE URL as the cell hyperlink while displaying only the
    file NAME as the value — reading values alone loses the actual link.
    """
    import openpyxl

    try:
        # NOTE: read_only=True uses a lazy SAX iterator that can deadlock when
        # the call runs on a worker thread. Eager load is fast for resume sheets
        # and avoids that hang (and read_only also drops hyperlink objects).
        wb = openpyxl.load_workbook(str(p), read_only=False, data_only=True)
    except Exception as exc:  # noqa: BLE001 - any open failure ⇒ corrupt/locked workbook
        return [], {}, f"excel_corrupt_or_locked: {exc}"
    try:
        ws = wb[wb.sheetnames[0]]
        values: list = []
        links: dict = {}
        for r_i, row in enumerate(ws.iter_rows()):
            values.append(tuple(cell.value for cell in row))
            for c_i, cell in enumerate(row):
                try:
                    target = cell.hyperlink.target if cell.hyperlink else None
                except AttributeError:
                    target = None
                if target:
                    links[(r_i, c_i)] = str(target)
        return values, links, ""
    finally:
        wb.close()


def _resolve_columns(headers: list[str]) -> dict[str, int | None]:
    """Map normalized headers to the name/email/phone/resume-link column indices."""
    def _find(predicate) -> int | None:
        for idx, h in enumerate(headers):
            if predicate(h):
                return idx
        return None

    link_col: int | None = None
    for alias in _RESUME_LINK_ALIASES:
        link_col = _find(lambda h, a=alias: a in h)
        if link_col is not None:
            break
    return {
        "name": _find(lambda h: "name" in h),
        "email": _find(lambda h: "email" in h or "mail" in h),
        "phone": _find(lambda h: "phone" in h or "mobile" in h or "contact" in h),
        "resume_link": link_col,
    }


def read_excel_rows(path: str) -> dict[str, Any]:
    """Read sheet 1 and map columns to candidate fields (Workflow C, Step 1-3).

    Recognizes resume-link columns named like ``resume_link`` / ``resume url`` /
    ``cv link`` / ``resume`` / ``candidate resume``. Returns ``ok`` plus a list
    of row dicts ``{row_number, name, email, phone, resume_link}``.
    """
    p = Path(path)
    if not p.exists():
        return {"ok": False, "reason": "missing_file", "rows": []}
    if (reason := _size_reason(p)):
        return {"ok": False, "reason": reason, "rows": []}
    raw, hyperlinks, error = _load_excel_grid(p)
    if error:
        return {"ok": False, "reason": error, "rows": []}
    if not raw:
        return {"ok": False, "reason": "excel_empty", "rows": []}

    headers = [str(c or "").strip() for c in raw[0]]
    cols = _resolve_columns([_norm_header(c) for c in raw[0]])

    def _cell(row, idx) -> str:
        if idx is None or idx >= len(row) or row[idx] is None:
            return ""
        return str(row[idx]).strip()

    def _resume_link(offset: int, row) -> str:
        """The row's resume link — the cell VALUE when it already is a URL,
        otherwise the cell's HYPERLINK target (Google Forms sheets show the
        uploaded file's name and hide the Drive URL in the hyperlink)."""
        idx = cols["resume_link"]
        value = _cell(row, idx)
        if value.lower().startswith(("http://", "https://", "file://", "local://")):
            return value
        target = hyperlinks.get((offset + 1, idx)) if idx is not None else None
        return target or value

    rows: list[dict[str, Any]] = []
    for offset, row in enumerate(raw[1:]):
        # Skip fully-empty rows (Excel's used range often pads with blanks).
        if all(c is None or str(c).strip() == "" for c in row):
            continue
        rows.append({
            "row_number": offset + 2,   # 1-based Excel row (header is row 1)
            "name": _cell(row, cols["name"]),
            "email": _cell(row, cols["email"]),
            "phone": _cell(row, cols["phone"]),
            "resume_link": _resume_link(offset, row),
            # Every ORIGINAL column (header→value) so the review UI can show the
            # whole row regardless of how the sheet's columns are named.
            "row_cells": {
                (headers[i] or f"Column {i + 1}"):
                    ("" if i >= len(row) or row[i] is None else str(row[i]).strip())
                for i in range(len(headers))
            },
        })
    return {"ok": True, "reason": "", "rows": rows}


# Recurse into nested zips, but bound the depth so a zip-bomb (a zip nested
# inside itself thousands of levels deep) cannot exhaust the disk or stack.
_MAX_ZIP_DEPTH = 8


def _collision_safe_path(dest: Path, name: str) -> Path:
    """Return a non-colliding path inside ``dest`` (resume.pdf -> resume_2.pdf).

    Two inner files named ``resume.pdf`` (e.g. ``john/resume.pdf`` and
    ``jane/resume.pdf``) must BOTH survive — never let the second overwrite the
    first, or a candidate is silently lost.
    """
    candidate = dest / name
    if not candidate.exists():
        return candidate
    stem, suffix = Path(name).stem, Path(name).suffix
    i = 2
    while True:
        candidate = dest / f"{stem}_{i}{suffix}"
        if not candidate.exists():
            return candidate
        i += 1


class _ZipBombError(Exception):
    """Raised when a zip's declared decompression exceeds the configured budget."""


def _extract_zip_into(
    zip_path: Path,
    dest: Path,
    extracted: list[str],
    skipped: list[str],
    depth: int,
    errors: list[str],
    budget: dict[str, int],
) -> None:
    """Recursively extract a zip's final-type members into ``dest`` (flattened).

    Nested zips are recursed into (down to ``_MAX_ZIP_DEPTH``) rather than
    skipped, so resumes bundled as zip-of-zips are never dropped.

    ``budget`` (``{"total", "count"}``) is shared across the whole recursion so a
    zip bomb — many members, one giant member, or an absurd compression ratio —
    is stopped before it can exhaust disk/memory. Limits come from
    ``mail_config`` (``ZIP_MAX_*``).
    """
    if depth > _MAX_ZIP_DEPTH:
        skipped.append(f"nested_zip_too_deep:{zip_path.name}")
        return
    if not zipfile.is_zipfile(str(zip_path)):
        errors.append(f"zip_corrupt:{zip_path.name}")
        return
    with zipfile.ZipFile(str(zip_path)) as zf:
        bad = zf.testzip()
        if bad is not None:
            errors.append(f"zip_member_crc_fail:{zip_path.name}:{bad}")
            return
        for info in zf.infolist():
            if info.is_dir():
                continue

            # ── Zip-bomb guards (use the header's declared sizes, before reading) ──
            budget["count"] += 1
            if budget["count"] > ZIP_MAX_ENTRIES:
                raise _ZipBombError(f"zip_too_many_entries: >{ZIP_MAX_ENTRIES}")
            if info.file_size > ZIP_MAX_ENTRY_BYTES:
                # One oversized inner file: skip it, but keep the rest of the zip.
                skipped.append(f"oversize_entry:{Path(info.filename).name}")
                continue
            if (
                info.compress_size > 0
                and info.file_size > 1024 * 1024  # ignore tiny files (ratio is noisy)
                and info.file_size / info.compress_size > ZIP_MAX_RATIO
            ):
                raise _ZipBombError(f"zip_ratio_exceeded: {Path(info.filename).name}")
            budget["total"] += info.file_size
            if budget["total"] > ZIP_MAX_TOTAL_BYTES:
                raise _ZipBombError("zip_uncompressed_too_large")

            inner_name = Path(info.filename).name
            ext = Path(inner_name).suffix.lower()
            if ext == ".zip":
                # Materialize the nested zip to a temp file, then recurse.
                tmp = _collision_safe_path(dest, inner_name)
                with zf.open(info) as member, open(tmp, "wb") as fh:
                    fh.write(member.read())
                try:
                    _extract_zip_into(tmp, dest, extracted, skipped,
                                      depth + 1, errors, budget)
                finally:
                    tmp.unlink(missing_ok=True)  # the container itself isn't a resume
                continue
            if ext not in FINAL_TYPES:
                skipped.append(f"junk:{inner_name}")
                continue
            # Flatten into dest with a collision-safe name; never overwrite.
            out_path = _collision_safe_path(dest, inner_name)
            with zf.open(info) as member, open(out_path, "wb") as fh:
                fh.write(member.read())
            extracted.append(str(out_path.resolve()))


def extract_zip(path: str, dest_dir: str) -> dict[str, Any]:
    """Extract a ZIP (recursing into nested zips), and list inner target files.

    Returns the absolute paths of inner files whose extension is a final type
    (.pdf/.docx/.jpg/.jpeg/.png). Inner files still require their own content
    validation by the caller. ``inner_total`` counts target-type members only.
    Colliding inner filenames are disambiguated (resume.pdf -> resume_2.pdf) so
    no inner resume is ever overwritten. Nested zips are recursed into rather
    than skipped.
    """
    p = Path(path)
    if not p.exists():
        return _result(False, "missing_file", inner_total=0, extracted=[], skipped=[])
    if (reason := _size_reason(p)):
        return _result(False, reason, inner_total=0, extracted=[], skipped=[])
    if not zipfile.is_zipfile(str(p)):
        return _result(False, "zip_corrupt", inner_total=0, extracted=[], skipped=[])

    dest = Path(dest_dir)
    dest.mkdir(parents=True, exist_ok=True)
    extracted: list[str] = []
    skipped: list[str] = []
    errors: list[str] = []
    # Decompression budget shared across nested zips (zip-bomb guard).
    budget = {"total": 0, "count": 0}

    try:
        _extract_zip_into(p, dest, extracted, skipped, depth=0, errors=errors, budget=budget)
    except _ZipBombError as exc:
        return _result(False, f"zip_bomb: {exc}",
                       inner_total=len(extracted), extracted=extracted, skipped=skipped)
    except Exception as exc:  # noqa: BLE001
        return _result(False, f"zip_extract_failed: {exc}",
                       inner_total=len(extracted), extracted=extracted, skipped=skipped)

    # A top-level read failure (corrupt outer zip / all members bad) with nothing
    # recovered is a hard failure; partial recovery still returns ok=True so the
    # caller stores what survived and logs the rest.
    if not extracted and errors:
        return _result(False, errors[0], inner_total=0, extracted=[], skipped=skipped)

    return _result(True, "", inner_total=len(extracted),
                   extracted=extracted, skipped=skipped)


def validate_by_extension(path: str) -> dict[str, Any]:
    """Dispatch a final-type file to the right validator (internal helper)."""
    ext = Path(path).suffix.lower()
    if ext == ".pdf":
        return validate_pdf(path)
    if ext == ".docx":
        return validate_docx(path)
    if ext == ".doc":
        return validate_doc(path)
    if ext in _IMAGE_EXTS:
        return validate_image(path)
    return _result(False, f"unsupported_type: {ext}")
