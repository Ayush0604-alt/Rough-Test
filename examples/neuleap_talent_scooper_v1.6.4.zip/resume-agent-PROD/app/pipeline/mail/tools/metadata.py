"""Metadata + link-detection tools (deterministic, no AI).

Inbox items are described by a JSON manifest::

    {
      "sender_mail_id": "recruiter@example.com",
      "subject": "Resume for John",
      "received_date": "2026-06-13",
      "attachments": ["john_resume.pdf"],
      "links": ["https://drive.google.com/file/d/abc/view"],
      "body": "Please find the resume attached."
    }

Loose files (no manifest) are each treated as a single-attachment email with
``unknown`` metadata — we never invent sender/subject/date.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from app.logging_config import get_logger
from app.mail_config import LINK_HOST_HINTS, Settings

log = get_logger(__name__)

_URL_RE = re.compile(r"https?://[^\s<>\"')]+", re.IGNORECASE)
_DIRECT_FILE_RE = re.compile(r"\.(pdf|docx)(\?|#|$)", re.IGNORECASE)


def extract_metadata(settings: Settings, manifest_name: str) -> dict[str, Any]:
    """Read a JSON manifest from the inbox and return normalized metadata.

    Missing fields are filled with ``unknown``/``None`` — never guessed.
    """
    path = settings.inbox_dir / manifest_name
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        log.error("manifest unreadable: %s (%s)", manifest_name, exc)
        return {
            "sender_mail_id": "unknown",
            "subject": "unknown",
            "received_date": None,
            "attachments": [],
            "links": [],
            "body": "",
            "_error": f"manifest_unreadable: {exc}",
        }
    return {
        # Staged items (intake/upload) carry an explicit sequence E_id; plain
        # local-test manifests omit it and the pipeline assigns one.
        "e_id": (str(raw["e_id"]) if raw.get("e_id") else None),
        "sender_mail_id": str(raw.get("sender_mail_id") or "unknown"),
        "subject": str(raw.get("subject") or "unknown"),
        "received_date": raw.get("received_date") or None,
        "attachments": [str(a) for a in (raw.get("attachments") or [])],
        "links": [str(link) for link in (raw.get("links") or [])],
        "body": str(raw.get("body") or ""),
    }


def _is_usable_file_link(url: str) -> bool:
    lowered = url.lower()
    if any(host in lowered for host in LINK_HOST_HINTS):
        return True
    return bool(_DIRECT_FILE_RE.search(lowered))


def detect_links(settings: Settings, body: str, declared_links: list[str]) -> list[str]:
    """Return de-duplicated usable file URLs from body text + declared links."""
    found: list[str] = []
    seen: set[str] = set()
    for url in [*declared_links, *_URL_RE.findall(body or "")]:
        url = url.rstrip(".,);")
        if url in seen:
            continue
        if _is_usable_file_link(url):
            seen.add(url)
            found.append(url)
    if found:
        log.info("detected %d usable link(s)", len(found))
    return found


def discover_loose_email(settings: Settings, filename: str) -> dict[str, Any]:
    """Build metadata for a loose (manifest-less) attachment file.

    A small internal helper used while assembling the item list. Metadata is
    honestly ``unknown``.
    """
    return {
        "sender_mail_id": "unknown",
        "subject": Path(filename).stem,
        "received_date": None,
        "attachments": [filename],
        "links": [],
        "body": "",
    }
