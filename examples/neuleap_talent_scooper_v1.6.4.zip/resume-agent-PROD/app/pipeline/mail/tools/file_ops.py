"""File-system tools: inbox listing, move-to-processing, save + dedup.

All paths are confined to the three local folders. Every function takes an
explicit :class:`Settings` so the same code works against a temp dir in tests.
"""

from __future__ import annotations

import shutil
from pathlib import Path

from app.logging_config import get_logger
from app.mail_config import Settings

log = get_logger(__name__)


def _safe_child(parent: Path, name: str) -> Path:
    """Resolve ``parent/name`` and refuse paths that escape ``parent``."""
    candidate = (parent / name).resolve()
    parent_resolved = parent.resolve()
    if parent_resolved != candidate and parent_resolved not in candidate.parents:
        raise ValueError(f"Path escapes allowed folder: {name}")
    return candidate


def list_inbox_items(settings: Settings) -> dict[str, list[str]]:
    """List inbox contents split into JSON manifests and loose files."""
    settings.ensure_folders()
    manifests: list[str] = []
    loose: list[str] = []
    for entry in sorted(settings.inbox_dir.iterdir()):
        if entry.is_dir():
            continue
        # Files prefixed with "_" are config (e.g. _link_map.json), not emails.
        if entry.name.startswith("_"):
            continue
        if entry.suffix.lower() == ".json":
            manifests.append(entry.name)
        else:
            loose.append(entry.name)
    log.info("inbox: %d manifest(s), %d loose file(s)", len(manifests), len(loose))
    return {"manifests": manifests, "loose": loose}


def move_item_to_processing(
    settings: Settings, e_id: str, filenames: list[str]
) -> str:
    """Move an item's files from inbox into a per-item processing subfolder.

    Returns the name of the processing subdirectory (relative to processing/).
    Missing source files are skipped with a warning rather than crashing.
    """
    settings.ensure_folders()
    subdir = settings.processing_dir / e_id
    subdir.mkdir(parents=True, exist_ok=True)
    for name in filenames:
        src = _safe_child(settings.inbox_dir, name)
        if not src.exists():
            log.warning("move: source missing, skipped: %s", name)
            continue
        dest = subdir / Path(name).name
        shutil.move(str(src), str(dest))
        log.info("move: %s -> processing/%s/%s", name, e_id, dest.name)
    return e_id


def read_local_item(settings: Settings, e_id: str) -> list[str]:
    """List the files currently in an item's processing subfolder."""
    subdir = settings.processing_dir / e_id
    if not subdir.exists():
        return []
    return sorted(p.name for p in subdir.iterdir() if p.is_file())


def _dedup_name(raw_dir: Path, filename: str) -> str:
    """Return a non-colliding filename inside ``raw_dir`` (resume.pdf -> resume_2.pdf)."""
    candidate = Path(filename).name
    if not (raw_dir / candidate).exists():
        return candidate
    stem = Path(candidate).stem
    suffix = Path(candidate).suffix
    n = 2
    while (raw_dir / f"{stem}_{n}{suffix}").exists():
        n += 1
    return f"{stem}_{n}{suffix}"


def rename_duplicate_file(settings: Settings, filename: str, dest_dir: str | None = None) -> str:
    """Return a safe, non-colliding name for ``filename`` within the target dir."""
    target = Path(dest_dir) if dest_dir else settings.raw_dir
    target.mkdir(parents=True, exist_ok=True)
    return _dedup_name(target, filename)


def save_clean_file(
    settings: Settings, source_path: str, desired_name: str, dest_dir: str | None = None
) -> str:
    """Copy a validated file into a destination folder, deduping if needed.

    ``dest_dir`` defaults to local/raw/ but the pipeline passes the dated
    ``local/resume/{MM}/{E_id}/`` folder. Returns the final stored filename.
    The source is left in place. ``dest_dir`` is an ephemeral temp folder in the
    MinIO-only runtime; the deduped file is uploaded to MinIO by the caller.
    """
    src = Path(source_path)
    if not src.exists():
        raise FileNotFoundError(source_path)
    target = Path(dest_dir) if dest_dir else settings.raw_dir
    target.mkdir(parents=True, exist_ok=True)
    final_name = _dedup_name(target, desired_name)
    shutil.copy2(str(src), str(target / final_name))
    log.info("store: %s -> %s/%s", src.name, target.name, final_name)
    return final_name


def list_raw_files(settings: Settings) -> list[str]:
    """List files currently stored in local/raw/."""
    settings.ensure_folders()
    return sorted(p.name for p in settings.raw_dir.iterdir() if p.is_file())
