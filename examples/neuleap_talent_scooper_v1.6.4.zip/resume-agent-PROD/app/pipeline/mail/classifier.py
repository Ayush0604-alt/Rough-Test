"""Optional GPT-4o-mini classification assist.

Classification is deterministic by default (presence of attachments / usable
links decides Attachment / Links / Mixed / None). The LLM is only consulted to
*confirm* an ambiguous case and is NEVER used for file validation.

If ``settings.use_llm`` is false or no API key / SDK is available, the
deterministic result is returned unchanged — the pipeline stays fully offline.
"""

from __future__ import annotations

import os

from app.logging_config import get_logger
from app.mail_config import Settings
from app.models.mail import Classification

log = get_logger(__name__)


def deterministic_classification(
    has_attachments: bool, has_links: bool
) -> Classification:
    """The authoritative, rule-based classification."""
    if has_attachments and has_links:
        return Classification.MIXED
    if has_attachments:
        return Classification.ATTACHMENT
    if has_links:
        return Classification.LINKS
    return Classification.NONE


def llm_available(settings: Settings) -> bool:
    """True only if LLM assist is enabled AND usable (key + SDK present)."""
    if not settings.use_llm:
        return False
    if not os.environ.get("OPENAI_API_KEY"):
        log.info("LLM assist requested but OPENAI_API_KEY is unset; staying offline")
        return False
    try:
        import langchain_openai  # noqa: F401
    except ImportError:
        log.info("langchain-openai not installed; staying offline")
        return False
    return True


def refine_classification(
    settings: Settings,
    *,
    subject: str,
    body: str,
    has_attachments: bool,
    has_links: bool,
) -> Classification:
    """Return a classification, optionally refined by GPT-4o-mini.

    The LLM is only asked when the deterministic signals are weak — specifically
    when there are no attachments and no regex-detected links but the body text
    might still reference a file share. Validation logic never calls this.
    """
    base = deterministic_classification(has_attachments, has_links)

    # Only bother the model in the genuinely ambiguous "looks like None" case
    # where the body is non-trivial — it may mention a share link in prose.
    ambiguous = base is Classification.NONE and len(body.strip()) > 0
    if not ambiguous or not llm_available(settings):
        return base

    try:
        from langchain_openai import ChatOpenAI

        llm = ChatOpenAI(model=settings.llm_model, temperature=0)
        prompt = (
            "You classify recruiter emails for a resume-intake pipeline. "
            "Given the subject and body, answer with exactly one word: "
            "'Links' if the body references a downloadable resume file or file-share "
            "link, otherwise 'None'. Do not explain.\n\n"
            f"Subject: {subject}\nBody: {body}\n"
        )
        answer = llm.invoke(prompt).content.strip().lower()
        if "link" in answer:
            log.info("LLM refined None -> Links for subject=%r", subject)
            return Classification.LINKS
    except Exception as exc:  # noqa: BLE001 - never let assist break the run
        log.warning("LLM assist failed, using deterministic result: %s", exc)
    return base
