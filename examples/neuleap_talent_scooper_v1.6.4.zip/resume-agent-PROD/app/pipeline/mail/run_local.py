"""Local test runner for Layer 1.

Runs the LangGraph workflow against the three local folders and prints:

  1. a short run summary
  2. the final Email_Master table (markdown)
  3. discarded items
  4. validation failures
  5. files stored in local/raw/

Usage::

    python -m neuleap_layer1.run_local                 # run against ./local
    python -m neuleap_layer1.run_local --seed-samples  # seed fixtures, then run
    python -m neuleap_layer1.run_local --base-dir /tmp/x
"""

from __future__ import annotations

import argparse
from pathlib import Path

from app.logging_config import get_logger
from app.mail_config import Settings
from app.services import clock
from app.models.mail import Layer1State
from app.pipeline.mail.graph import build_graph, initial_state
from app.pipeline.mail.tools.reporting import print_markdown_table

log = get_logger(__name__)


def new_run_id() -> str:
    return "RUN-" + clock.stamp()


def run(settings: Settings) -> Layer1State:
    """Execute the Layer 1 graph once and return the final state."""
    settings.ensure_folders()
    app = build_graph(settings)
    state = initial_state(new_run_id())
    # LangGraph returns the final merged state dict.
    final: Layer1State = app.invoke(state)  # type: ignore[assignment]
    return final


def _section_summary(
    state: Layer1State, rows, discarded, failures, raw_files, manual_reviews
) -> list[str]:
    passed = sum(1 for r in rows if r.process_status == "Passed")
    failed = sum(1 for r in rows if r.process_status == "Failed")
    return [
        "## 1) Run summary",
        f"- run_id: `{state['run_id']}`",
        f"- items discovered: {len(state.get('items', []))}",
        f"- Email_Master rows: {len(rows)} (Passed={passed}, Failed={failed})",
        f"- discarded: {len(discarded)}",
        f"- validation failures: {len(failures)}",
        f"- files stored in local/resume/: {len(raw_files)}",
        f"- manual-review flags: {len(manual_reviews)}",
        "",
    ]


def _section_email_master(rows) -> list[str]:
    body = print_markdown_table([r.model_dump() for r in rows]) if rows else "(no rows)"
    return ["## 2) Email_Master", body, ""]


def _section_discarded(discarded) -> list[str]:
    out = ["## 3) Discarded items"]
    if discarded:
        out += [f"- {d.e_id} · {d.sender_mail_id} · {d.subject!r} — {d.reason}" for d in discarded]
    else:
        out.append("- none")
    out.append("")
    return out


def _section_failures(failures, manual_reviews) -> list[str]:
    out = ["## 4) Validation failures"]
    if failures:
        out += [f"- {f.e_id} · {f.filename} ({f.file_type}) — {f.reason}" for f in failures]
    else:
        out.append("- none")
    if manual_reviews:
        out.append("")
        out.append("**Needs review (Excel rows):**")
        out += [f"- {e.e_id} — {e.reason}" for e in manual_reviews]
    out.append("")
    return out


def _section_stored(raw_files) -> list[str]:
    out = ["## 5) Files stored in local/resume/{MM}/{E_id}/"]
    out += [f"- {name}" for name in raw_files] if raw_files else ["- none"]
    out.append("")
    return out


def _section_workflows(wf_results) -> list[str]:
    out = ["## 6) Workflow results (Final Output Schema)"]
    if wf_results:
        out += [
            f"- `{wf.e_id}` **{wf.workflow}** → {wf.status} "
            f"(processed={wf.processed_count}, success={wf.success_count}, "
            f"failure={wf.failure_count}, manual_review={wf.manual_review_count}, "
            f"stored={wf.stored_files})"
            for wf in wf_results
        ]
    else:
        out.append("- none")
    out.append("")
    return out


def render_report(settings: Settings, state: Layer1State) -> str:
    """Build the full human-readable report from a finished run."""
    rows = state.get("email_master_rows", [])
    discarded = state.get("discarded_items", [])
    failures = [v for v in state.get("validation_results", []) if not v.ok]
    stored = state.get("stored_files", [])
    # Relative paths under local/ for the dated resume storage tree.
    raw_files = sorted(
        str(Path(sf.stored_path).relative_to(settings.local_dir)).replace("\\", "/")
        for sf in stored
    )
    manual_reviews = [
        e for e in state.get("audit_events", []) if e.status == "ManualReview"
    ]

    out: list[str] = ["# Layer 1 — Local Run Report", ""]
    out += _section_summary(state, rows, discarded, failures, raw_files, manual_reviews)
    out += _section_email_master(rows)
    out += _section_discarded(discarded)
    out += _section_failures(failures, manual_reviews)
    out += _section_stored(raw_files)
    out += _section_workflows(state.get("workflow_results", []))
    return "\n".join(out)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run Layer 1 in local test mode.")
    parser.add_argument("--base-dir", default=None, help="Project dir containing local/")
    parser.add_argument("--seed-samples", action="store_true",
                        help="Seed local/inbox/ with sample fixtures before running.")
    args = parser.parse_args(argv)

    settings = Settings(base_dir=Path(args.base_dir)) if args.base_dir else Settings()

    if args.seed_samples:
        from app.pipeline.mail.samples import seed_samples
        seed_samples(settings)

    state = run(settings)
    print(render_report(settings, state))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
