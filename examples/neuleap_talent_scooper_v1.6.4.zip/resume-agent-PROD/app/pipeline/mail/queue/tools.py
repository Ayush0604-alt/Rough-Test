"""The deterministic Layer-1 tool surface (Graph / Storage / Validation / Logging).

These are the "MCP tools" the orchestration contract (``SKILL.md``) refers to.
They are implemented as **plain in-process functions**, not a network MCP server:
the repository deliberately ships no ``mcp`` runtime dependency (and guards
against re-introducing one), so the same contract is satisfied by a thin,
testable facade over the existing deterministic services.

Groups
------
* **Graph**      — ``graph_fetch_inbox``, ``graph_move_message``
* **Storage**    — :class:`FileStorage` (``save_file`` / ``file_exists`` / ``raw_prefix``)
* **Validation** — ``validate_file`` / ``extract_zip`` / ``read_excel_rows`` (re-exported,
  deterministic, NO AI)
* **Logging**    — ``write_audit_event`` / ``write_run_summary``

The Queue tools (``enqueue`` / ``dequeue`` / ``ack`` / ``requeue`` / ``dead_letter``)
live in :mod:`app.pipeline.mail.queue.message_queue` (the durable SQLite queue),
and the Email Table writer lives in :mod:`app.pipeline.mail.queue.email_table`.
"""

from __future__ import annotations

import shutil
from pathlib import Path
from typing import Any, Optional

from app.logging_config import get_logger
from app.mail_config import _day_from, _month_from, _parse_date
from app.pipeline.mail.tools.validation import (  # re-export deterministic validators
    extract_zip,
    read_excel_rows,
    validate_by_extension,
)
from app.services import audit as audit_db
from app.services import mail_storage as minio

log = get_logger(__name__)

__all__ = [
    "graph_fetch_inbox",
    "graph_move_message",
    "FileStorage",
    "default_storage",
    "validate_file",
    "extract_zip",
    "read_excel_rows",
    "write_audit_event",
    "write_run_summary",
]


# --------------------------------------------------------------------------- #
# Graph tools (best-effort; degrade cleanly when Graph is not configured)
# --------------------------------------------------------------------------- #

def graph_fetch_inbox(top: Optional[int] = None) -> list[dict[str, Any]]:
    """Fetch Inbox Graph messages (by date received). Returns [] if unconfigured."""
    from app.services import graph_client

    if not graph_client.is_configured():
        log.info("graph_fetch_inbox: Graph not configured — returning 0 messages")
        return []
    return graph_client.fetch_inbox(top=top)


# Logical folder label (as the runner names it) -> graph_client folder key.
_MOVE_FOLDER_KEYS = {
    "Processing": "processing",
    "Processed": "processed",
    "Failed review": "failed",
}


def graph_move_message(message_id: Optional[str], folder: str) -> Optional[str]:
    """Move a mail between mailbox folders (Inbox → Processing → Processed/Failed).

    Performs a **real** Graph folder move so the Inbox only ever holds mail still
    waiting to be processed. Graph reassigns the message id on every move, so this
    returns the message's **new id** in the destination folder — callers must keep it
    to address the mail in a later move. Best-effort: returns ``message_id`` unchanged
    if moving is disabled or the move fails (auditing records the state either way).
    Never raises.
    """
    if not message_id:
        return None
    from app.services import graph_client

    key = _MOVE_FOLDER_KEYS.get(folder)
    if key is None:
        log.warning("graph_move_message: unknown folder %r (move skipped)", folder)
        return message_id
    try:
        if key == "processed":
            graph_client.mark_read(message_id)
        new_id = graph_client.move_message(message_id, key)
        return new_id or message_id
    except Exception as exc:  # noqa: BLE001 — folder move must never break a run
        log.warning("graph_move_message(%s -> %s) failed: %s", message_id, folder, exc)
        return message_id


# --------------------------------------------------------------------------- #
# Storage tool — durable MinIO when enabled, local raw/ mirror otherwise.
# Both honour the spec path form raw/YYYY/MM/DD/{e_id}/<filename>.
# --------------------------------------------------------------------------- #

class FileStorage:
    """Save validated files under ``raw/YYYY/MM/DD/{e_id}/`` (MinIO or local).

    ``settings`` selects the local mirror root (``settings.local_dir/raw``) used
    when MinIO is disabled — tests point it at a temp dir for isolation.
    """

    def __init__(self, settings: Optional[Any] = None) -> None:
        from app.mail_config import SETTINGS

        self.settings = settings or SETTINGS

    def raw_prefix(self, e_id: str, received_date: Optional[str]) -> str:
        dt = _parse_date(received_date)
        return (f"raw/{dt.year:04d}/{_month_from(received_date)}/"
                f"{_day_from(received_date)}/{e_id}/")

    def _local_dir(self, e_id: str, received_date: Optional[str]) -> Path:
        dt = _parse_date(received_date)
        d = (self.settings.local_dir / "raw" / f"{dt.year:04d}"
             / _month_from(received_date) / _day_from(received_date) / e_id)
        d.mkdir(parents=True, exist_ok=True)
        return d

    def save_file(
        self, local_path: str, e_id: str, received_date: Optional[str], name: str
    ) -> str:
        """Persist one validated file; return its durable path (s3 uri or local path)."""
        if minio.is_enabled():
            uri = minio.put_final(local_path, e_id, received_date, name)
            if uri:
                return uri
        # Local durable mirror (also the offline-test store).
        dest = self._local_dir(e_id, received_date) / Path(name).name
        shutil.copy2(local_path, dest)
        log.info("storage: saved %s -> %s", name, dest)
        return str(dest)

    def file_exists(self, path: str) -> bool:
        if path.startswith("s3://"):
            return True  # written via put_final; existence implied by a returned uri
        return Path(path).exists()


_DEFAULT_STORAGE = FileStorage()


def default_storage() -> FileStorage:
    return _DEFAULT_STORAGE


# --------------------------------------------------------------------------- #
# Validation tool (deterministic dispatch)
# --------------------------------------------------------------------------- #

def validate_file(path: str) -> dict[str, Any]:
    """Validate a final-type file by extension (existence + integrity + type)."""
    return validate_by_extension(path)


# --------------------------------------------------------------------------- #
# Logging / audit tools
# --------------------------------------------------------------------------- #

def _audit_enabled() -> bool:
    """Skip the shared Postgres audit ledger when no DB is reachable (offline)."""
    from app.db import email_master as db

    return db.is_enabled()


def write_audit_event(
    *,
    run_id: str,
    e_id: Optional[str],
    step: str,
    status: str,
    reason: str = "",
) -> None:
    """Append one Audit_log row (shared D11 ledger). Best-effort, never raises."""
    if not _audit_enabled():
        return
    audit_db.write_event(
        run_id=run_id, batch_id=run_id, e_id=e_id,
        layer="L1", step=step, status=status, fail_reason=reason,
    )


def write_run_summary(run_id: str, counts_mails: int) -> None:
    """Write the per-run BATCH summary row to the Audit_log ledger."""
    if not _audit_enabled():
        return
    audit_db.write_batch_row(run_id, counts_mails)
