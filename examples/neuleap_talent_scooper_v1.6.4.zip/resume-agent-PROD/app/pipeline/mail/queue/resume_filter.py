"""Deterministic resume-relevance filter for Outlook (Graph) mail intake.

Only mail that actually carries a resume is admitted to the queue; everything else
(LinkedIn job alerts, newsletters, auto-replies, receipts, …) is rejected at the
gate and never creates an Email-Table row.

**Hard rule — a resume mail must carry a resume PAYLOAD:**
  * a resume-type **attachment** (``.pdf`` / ``.docx`` / ``.doc``), OR
  * a **container** attachment that may hold one (``.zip`` / ``.xlsx``), OR
  * a **link to a resume file** (a URL ending in ``.pdf`` / ``.docx`` / ``.doc``) or to
    a known **file-share** host (Google Drive/Docs, OneDrive, SharePoint, Dropbox,
    WeTransfer, Box).

Text alone is never enough: a mail whose only "resume signal" is the word *resume*
in the subject, or whose only link points at a website (e.g. ``linkedin.com`` job
pages), has **no resume to process** and is rejected. This is the deterministic
fallback for :mod:`app.pipeline.mail.queue.agent_classifier`; it is predictable,
free, and explainable — every decision returns a human-readable reason.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse

from app.mail_config import BLOCKLIST_DOMAINS, BLOCKLIST_PREFIXES

# Direct resume/CV vocabulary — used only to enrich the accept reason, never to
# admit a mail on its own (payload is mandatory).
RESUME_TERMS: tuple[str, ...] = (
    "resume", "resume", "resume", "curriculum vitae", "curriculum-vitae",
)
CV_TERMS: tuple[str, ...] = ("cv",)
JOB_TERMS: tuple[str, ...] = (
    "job application", "applying for", "application for", "apply for",
    "for the position", "for the role", "cover letter", "notice period",
    "expected ctc", "current ctc", "years of experience", "i am writing to apply",
)

# Attachment-name hints (the file itself is named like a resume).
RESUME_FILE_HINTS: tuple[str, ...] = ("resume", "resume", "resume", "cv", "curriculum")

# Resume-bearing file types and containers that may hold them.
RESUME_EXTS = {".pdf", ".docx", ".doc"}
CONTAINER_EXTS = {".zip", ".xlsx"}
# Extensions that count as a downloadable resume when they appear in a link.
RESUME_LINK_EXTS = {".pdf", ".docx", ".doc"}

# File-share hosts whose links can deliver a resume. A link to one of these counts
# as a payload; a link to any other site (linkedin.com, a job board, a blog) does NOT.
FILE_SHARE_HOSTS: tuple[str, ...] = (
    "drive.google.com", "docs.google.com",
    "onedrive.live.com", "1drv.ms", "sharepoint.com",
    "dropbox.com", "wetransfer.com", "box.com",
)


def _has_word(text: str, word: str) -> bool:
    """Whole-word match for short tokens like 'cv' (so 'service' doesn't match)."""
    return re.search(rf"(?<![a-z]){re.escape(word)}(?![a-z])", text) is not None


_EMAIL_RE = re.compile(r"[\w.+-]+@[\w.-]+")


def _sender_email(sender: str) -> str:
    """Pull the bare address out of 'Name <addr@dom>' / 'addr@dom'."""
    m = _EMAIL_RE.search(sender or "")
    return (m.group(0) if m else (sender or "")).strip().lower()


def blocklisted_sender(sender: Optional[str]) -> Optional[str]:
    """Return a reason string if the sender is on the blocklist, else None.

    Cheap first pass — matches a blocklisted domain (or any subdomain) or an
    automated local-part / leading subdomain label (noreply@, digest@, …).
    """
    email = _sender_email(sender or "")
    if "@" not in email:
        return None
    local, _, domain = email.partition("@")
    for d in BLOCKLIST_DOMAINS:
        if domain == d or domain.endswith("." + d):
            return f"blocklisted_domain:{d}"
    first_label = domain.split(".")[0]
    for p in BLOCKLIST_PREFIXES:
        # local-part: exactly the prefix, or prefix followed by a separator/digit.
        if re.match(rf"{re.escape(p)}([._+\-]|\d|$)", local):
            return f"blocklisted_sender:{p}"
        if first_label == p:                       # e.g. noreply.acme.com
            return f"blocklisted_subdomain:{p}"
    return None


def is_resume_link(url: str) -> bool:
    """True when a URL delivers a resume: a direct .pdf/.doc/.docx, or a file-share."""
    if not url:
        return False
    u = str(url).strip().lower()
    parsed = urlparse(u if "://" in u else f"http://{u}")
    host = parsed.netloc
    path = parsed.path
    if any(path.endswith(ext) for ext in RESUME_LINK_EXTS):
        return True
    return any(h in host for h in FILE_SHARE_HOSTS)


def is_resume_email(
    subject: str,
    body: str,
    attachment_names: list[str],
    links: list[str] | None = None,
    sender: Optional[str] = None,
) -> tuple[bool, str]:
    """Return (accept, reason). Deterministic — no LLM, no network.

    Rejects blocklisted senders first (noreply/digest/LinkedIn/naukri …), then admits
    a mail ONLY when it carries a resume payload (attachment, container, or a resume
    file / file-share link). Text-only or website-only mail is rejected.
    """
    blocked = blocklisted_sender(sender)
    if blocked:
        return False, blocked

    text = f"{subject or ''}\n{body or ''}".lower()
    names = [str(n).lower() for n in (attachment_names or [])]
    exts = {Path(n).suffix for n in names}
    url_list = [str(u) for u in (links or [])]

    has_resume_attachment = bool(exts & RESUME_EXTS)
    has_container = bool(exts & CONTAINER_EXTS)
    resume_links = [u for u in url_list if is_resume_link(u)]

    # HARD GATE: no resume payload ⇒ nothing to process ⇒ reject (this is what stops
    # LinkedIn-style alerts whose only links are websites, and text-only mail).
    if not (has_resume_attachment or has_container or resume_links):
        if url_list:
            return False, "no_resume_payload: links are websites, not resume files"
        return False, "no_resume_payload: no resume attachment or file link"

    # Payload present — describe why we accepted (most specific signal first).
    if has_resume_attachment and any(h in n for n in names for h in RESUME_FILE_HINTS):
        return True, "resume-named attachment"
    if has_resume_attachment:
        return True, "resume-type attachment (pdf/doc/docx)"
    if resume_links:
        return True, "link to a resume file / file-share"
    # Only a container (.zip/.xlsx) — accept when there's any resume/job context, else
    # still accept (a recruiting inbox container is almost always resumes) but say so.
    if any(t in text for t in RESUME_TERMS) or any(_has_word(text, t) for t in CV_TERMS) \
            or any(t in text for t in JOB_TERMS):
        return True, "container attachment with resume/application context"
    return True, "container attachment (zip/xlsx) — may hold resumes"
