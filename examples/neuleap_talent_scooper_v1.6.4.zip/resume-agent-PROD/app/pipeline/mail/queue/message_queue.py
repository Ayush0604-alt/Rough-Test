"""Durable, crash-safe message queue for Layer 1 — keyed by ``e_id``.

Backed by **SQLite** (ACID, single-file, no server) so the queue survives process
crashes and needs zero external infrastructure in tests/CI. PostgreSQL or a
broker (SQS/RabbitMQ) could be substituted behind the same interface; SQLite is
the durable default because the rest of Layer 1 must run offline.

Guarantees
----------
* **Idempotency** — ``e_id`` is the PRIMARY KEY. ``enqueue`` is INSERT-OR-IGNORE,
  so the same ``e_id`` can never produce two live messages, and a ``done``/``dead``
  message is never resurrected.
* **No concurrent double-processing** — ``dequeue`` atomically flips the lowest
  ``seq`` ready row to ``inflight`` under ``BEGIN IMMEDIATE``; that ``e_id`` is not
  handed out again until its lease expires (crash recovery) or it is requeued.
* **Per-e_id ordering** — exactly one row per ``e_id`` ordered by insertion ``seq``;
  there is no interleaving for a given key.
* **Bounded retries** — ``requeue`` increments ``retry_count``; once it reaches
  ``max_attempts`` (default 3) the message is routed to the Dead-Letter Queue
  (``state='dead'``) instead of going ``ready`` again.

States: ``ready`` -> ``inflight`` -> (``done`` | ``ready`` (retry) | ``dead`` (DLQ)).
"""

from __future__ import annotations

import json
import os
import sqlite3
import time
from typing import Any, Optional

from app.logging_config import get_logger

log = get_logger(__name__)

MAX_ATTEMPTS = 3            # total processing attempts per e_id before DLQ
DEFAULT_LEASE_SECONDS = 300  # inflight visibility timeout (crash reclaim window)

READY = "ready"
INFLIGHT = "inflight"
DONE = "done"
DEAD = "dead"


def default_db_path() -> str:
    """Resolve the queue file path (env override -> repo-local default)."""
    override = os.environ.get("NEULEAP_QUEUE_DB")
    if override:
        return override
    from app.mail_config import SETTINGS

    qdir = SETTINGS.local_dir / "queue"
    qdir.mkdir(parents=True, exist_ok=True)
    return str(qdir / "layer1_queue.db")


class MessageQueue:
    """A single durable queue table. Open one per worker/run; cheap to construct."""

    def __init__(
        self,
        db_path: Optional[str] = None,
        *,
        lease_seconds: int = DEFAULT_LEASE_SECONDS,
        max_attempts: int = MAX_ATTEMPTS,
    ) -> None:
        self.db_path = db_path or default_db_path()
        self.lease_seconds = lease_seconds
        self.max_attempts = max_attempts
        self._init_schema()

    # -- connection ---------------------------------------------------------

    def _connect(self) -> sqlite3.Connection:
        # A fresh short-lived connection per op keeps this thread-safe and crash
        # safe (SQLite handles file locking). WAL improves concurrent readers.
        conn = sqlite3.connect(self.db_path, timeout=30)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=FULL")
        return conn

    def _init_schema(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS queue_messages (
                    e_id         TEXT PRIMARY KEY,
                    seq          INTEGER,
                    run_id       TEXT,
                    payload      TEXT NOT NULL,
                    retry_count  INTEGER NOT NULL DEFAULT 0,
                    state        TEXT NOT NULL DEFAULT 'ready',
                    lease_until  REAL,
                    error_reason TEXT,
                    enqueued_at  REAL NOT NULL,
                    updated_at   REAL NOT NULL
                )
                """
            )
            conn.execute(
                "CREATE TABLE IF NOT EXISTS queue_seq (n INTEGER NOT NULL)"
            )
            if conn.execute("SELECT COUNT(*) FROM queue_seq").fetchone()[0] == 0:
                conn.execute("INSERT INTO queue_seq (n) VALUES (0)")
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_queue_state ON queue_messages (state, seq)"
            )

    def _next_seq(self, conn: sqlite3.Connection) -> int:
        conn.execute("UPDATE queue_seq SET n = n + 1")
        return int(conn.execute("SELECT n FROM queue_seq").fetchone()[0])

    # -- producer -----------------------------------------------------------

    def enqueue(
        self,
        e_id: str,
        run_id: str,
        payload: dict[str, Any],
        *,
        retry_count: int = 0,
    ) -> bool:
        """Push one message keyed by ``e_id``. Idempotent.

        Returns True if a NEW message was created, False if ``e_id`` was already
        present (duplicate suppressed — preserves exactly-once enqueue semantics).
        """
        now = time.time()
        body = json.dumps(payload, ensure_ascii=False)
        with self._connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            existing = conn.execute(
                "SELECT state FROM queue_messages WHERE e_id = ?", (e_id,)
            ).fetchone()
            if existing is not None:
                log.info("enqueue: duplicate e_id=%s (state=%s) — ignored",
                         e_id, existing["state"])
                return False
            seq = self._next_seq(conn)
            conn.execute(
                """INSERT INTO queue_messages
                   (e_id, seq, run_id, payload, retry_count, state,
                    lease_until, error_reason, enqueued_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, 'ready', NULL, NULL, ?, ?)""",
                (e_id, seq, run_id, body, retry_count, now, now),
            )
        log.info("enqueue: e_id=%s seq=%d run=%s", e_id, seq, run_id)
        return True

    # -- consumer -----------------------------------------------------------

    def dequeue(self) -> Optional[dict[str, Any]]:
        """Lease the next available message (FIFO by ``seq``), or None.

        Picks a ``ready`` message, or an ``inflight`` one whose lease expired
        (i.e. a worker crashed mid-flight) — that reclaim is what makes the queue
        resilient to crashes without losing work.
        """
        now = time.time()
        with self._connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute(
                """SELECT * FROM queue_messages
                   WHERE state = 'ready'
                      OR (state = 'inflight' AND lease_until IS NOT NULL AND lease_until < ?)
                   ORDER BY seq ASC LIMIT 1""",
                (now,),
            ).fetchone()
            if row is None:
                return None
            conn.execute(
                "UPDATE queue_messages SET state='inflight', lease_until=?, updated_at=? "
                "WHERE e_id=?",
                (now + self.lease_seconds, now, row["e_id"]),
            )
        return self._to_msg(row)

    def ack(self, e_id: str) -> None:
        """Mark a message permanently done (success). Never re-delivered."""
        self._set_state(e_id, DONE)
        log.info("ack: e_id=%s -> done", e_id)

    def requeue(self, e_id: str, error_reason: str = "") -> str:
        """Record a failure: increment retry_count, then requeue or dead-letter.

        Returns the resulting state: ``'ready'`` (will retry) or ``'dead'`` (DLQ,
        retries exhausted). The retry_count is the number of attempts MADE.
        """
        now = time.time()
        with self._connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute(
                "SELECT retry_count FROM queue_messages WHERE e_id=?", (e_id,)
            ).fetchone()
            if row is None:
                log.warning("requeue: unknown e_id=%s", e_id)
                return DEAD
            attempts = int(row["retry_count"]) + 1
            if attempts >= self.max_attempts:
                conn.execute(
                    "UPDATE queue_messages SET state='dead', retry_count=?, "
                    "lease_until=NULL, error_reason=?, updated_at=? WHERE e_id=?",
                    (attempts, error_reason, now, e_id),
                )
                log.warning("requeue: e_id=%s EXHAUSTED after %d attempts -> DLQ",
                            e_id, attempts)
                return DEAD
            conn.execute(
                "UPDATE queue_messages SET state='ready', retry_count=?, "
                "lease_until=NULL, error_reason=?, updated_at=? WHERE e_id=?",
                (attempts, error_reason, now, e_id),
            )
        log.info("requeue: e_id=%s attempt=%d -> ready (retry)", e_id, attempts)
        return READY

    def dead_letter(self, e_id: str, error_reason: str = "") -> None:
        """Force a message straight to the Dead-Letter Queue."""
        now = time.time()
        with self._connect() as conn:
            conn.execute(
                "UPDATE queue_messages SET state='dead', lease_until=NULL, "
                "error_reason=?, updated_at=? WHERE e_id=?",
                (error_reason, now, e_id),
            )
        log.warning("dead_letter: e_id=%s -> DLQ (%s)", e_id, error_reason)

    # -- introspection ------------------------------------------------------

    def get(self, e_id: str) -> Optional[dict[str, Any]]:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM queue_messages WHERE e_id=?", (e_id,)
            ).fetchone()
        return self._to_msg(row) if row else None

    def list_dead(self) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM queue_messages WHERE state='dead' ORDER BY seq"
            ).fetchall()
        return [self._to_msg(r) for r in rows]

    def counts(self) -> dict[str, int]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT state, COUNT(*) AS n FROM queue_messages GROUP BY state"
            ).fetchall()
        out = {READY: 0, INFLIGHT: 0, DONE: 0, DEAD: 0}
        for r in rows:
            out[r["state"]] = int(r["n"])
        return out

    # -- helpers ------------------------------------------------------------

    def _set_state(self, e_id: str, state: str) -> None:
        with self._connect() as conn:
            conn.execute(
                "UPDATE queue_messages SET state=?, lease_until=NULL, updated_at=? "
                "WHERE e_id=?",
                (state, time.time(), e_id),
            )

    @staticmethod
    def _to_msg(row: sqlite3.Row) -> dict[str, Any]:
        return {
            "e_id": row["e_id"],
            "seq": row["seq"],
            "run_id": row["run_id"],
            "payload": json.loads(row["payload"]),
            "retry_count": int(row["retry_count"]),
            "state": row["state"],
            "error_reason": row["error_reason"],
        }
