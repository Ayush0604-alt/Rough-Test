"""Per-message processing for the queue-driven Layer 1.

Given one dequeued message and its materialized inputs (attachments on disk +
declared links), this:

1. determines the file type — PDF / DOCX / ZIP / EXCEL / LINK / IMAGE / MIXED / NONE,
2. routes to the deterministic Workflows A/B/C (links / zip / excel) and the plain
   final-file validators (reusing :mod:`app.pipeline.mail.workflows`),
3. validates every candidate file (existence + extension + integrity — NO AI),
4. stores clean files to ``raw/YYYY/MM/DD/{e_id}/`` via the Storage tool,
5. returns a :class:`ProcessOutcome` describing success/failure.

Queue transitions (ack / requeue / DLQ) and Email-Table/Audit writes are the
runner's job — this module is a pure function of (inputs) -> (outcome), which is
what makes retries deterministic and the batch resilient (one bad item raises
nothing; it just yields ``ok=False``).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from app.logging_config import get_logger
from app.mail_config import FINAL_TYPES, SETTINGS, Settings
from app.pipeline.mail import workflows
from app.pipeline.mail.queue.tools import FileStorage, default_storage
from app.pipeline.mail.tools.validation import validate_by_extension

log = get_logger(__name__)

# Email Table attachment_type labels (spec).
PDF = "PDF"
DOCX = "DOCX"
ZIP = "ZIP"
EXCEL = "EXCEL"
LINK = "LINK"
IMAGE = "IMAGE"
MIXED = "MIXED"
NONE = "NONE"

_IMAGE_EXTS = {".jpg", ".jpeg", ".png"}


def _ext_category(ext: str) -> Optional[str]:
    ext = ext.lower()
    if ext == ".pdf":
        return PDF
    if ext in (".docx", ".doc"):
        return DOCX
    if ext == ".zip":
        return ZIP
    if ext == ".xlsx":
        return EXCEL
    if ext in _IMAGE_EXTS:
        return IMAGE
    return None


def detect_type(attachment_files: list[str], links: list[str]) -> str:
    """Classify the email's payload into one Email-Table ``attachment_type``."""
    categories: set[str] = set()
    for name in attachment_files:
        cat = _ext_category(Path(name).suffix)
        categories.add(cat if cat else "OTHER")
    if links:
        categories.add(LINK)
    # OTHER (unsupported) on its own is still a real, processable category that
    # will fail validation — only a truly empty payload is NONE.
    if not categories:
        return NONE
    if categories == {"OTHER"}:
        return NONE
    categories.discard("OTHER")
    if len(categories) == 1:
        return next(iter(categories))
    return MIXED


@dataclass
class ProcessOutcome:
    """Result of processing one message (consumed by the runner)."""

    ok: bool
    attachment_type: str
    stored_files: list[str] = field(default_factory=list)
    file_path: Optional[str] = None       # raw/YYYY/MM/DD/{e_id}/  (dir prefix)
    error_reason: str = ""
    total: int = 0
    passed: int = 0


def _route_inputs(
    settings: Settings, e_id: str, workdir: Path, links: list[str], dest: str
) -> list[dict[str, Any]]:
    """Route on-disk attachments + links to Workflows A/B/C. Mirrors the node path.

    Returns the list of intermediate workflow dicts (uniform shape from
    :mod:`app.pipeline.mail.workflows`).
    """
    intermediates: list[dict[str, Any]] = []
    attachment = workflows._empty("attachment")
    for entry in sorted(workdir.iterdir()) if workdir.exists() else []:
        if not entry.is_file():
            continue
        ext = entry.suffix.lower()
        if ext == ".zip":
            intermediates.append(workflows.workflow_zip(settings, e_id, str(entry), dest))
        elif ext == ".xlsx":
            intermediates.append(workflows.workflow_excel(settings, e_id, str(entry), dest))
        elif ext in FINAL_TYPES:
            attachment["total"] += 1
            vr = validate_by_extension(str(entry))
            if vr["ok"]:
                attachment["passed"] += 1
                attachment["ready_files"].append(
                    {"source_path": str(entry), "desired_name": entry.name})
            else:
                attachment["failures"].append(
                    {"filename": entry.name, "reason": vr["reason"]})
        else:
            attachment["total"] += 1
            attachment["failures"].append(
                {"filename": entry.name, "reason": f"unsupported_type:{ext}"})
    if attachment["total"] > 0:
        intermediates.append(attachment)
    if links:
        intermediates.append(workflows.workflow_links(settings, e_id, links, dest))
    return intermediates


def process_item(
    *,
    e_id: str,
    received_date: Optional[str],
    workdir: str,
    attachment_files: list[str],
    links: list[str],
    storage: Optional[FileStorage] = None,
    settings: Optional[Settings] = None,
) -> ProcessOutcome:
    """Process one email's files/links; validate and store clean outputs.

    Never raises for *data* problems — a bad item yields ``ok=False`` with a
    reason. Infrastructure failures (e.g. the Storage tool raising) propagate so
    the runner can record them as a retryable failure.
    """
    settings = settings or SETTINGS
    storage = storage or default_storage()
    wd = Path(workdir)
    attachment_type = detect_type(attachment_files, links)

    if attachment_type == NONE:
        return ProcessOutcome(
            ok=False, attachment_type=NONE,
            error_reason="no_attachment_no_link",
        )

    dest = str(wd / "_dl")
    intermediates = _route_inputs(settings, e_id, wd, links, dest)
    total = sum(i["total"] for i in intermediates)
    passed = sum(i["passed"] for i in intermediates)

    ready: list[dict[str, Any]] = []
    failure_reasons: list[str] = []
    for inter in intermediates:
        ready.extend(inter["ready_files"])
        for f in inter["failures"]:
            failure_reasons.append(f"{f['filename']}:{f['reason']}")
        for mr in inter["manual_review"]:
            key = mr.get("row", mr.get("item", "?"))
            failure_reasons.append(f"{inter['workflow']}:{key}:{mr['reason']}")

    if not ready:
        reason = "; ".join(failure_reasons) or "no_valid_files"
        return ProcessOutcome(
            ok=False, attachment_type=attachment_type,
            error_reason=f"validation_failed: {reason}",
            total=total, passed=passed,
        )

    # Store clean files durably (collision-safe names per dir).
    out_dir = wd / "_out"
    out_dir.mkdir(parents=True, exist_ok=True)
    stored_names: list[str] = []
    for entry in ready:
        from app.pipeline.mail.tools import file_ops

        final_name = file_ops.save_clean_file(
            settings, entry["source_path"], entry["desired_name"], str(out_dir))
        storage.save_file(str(out_dir / final_name), e_id, received_date, final_name)
        stored_names.append(final_name)

    return ProcessOutcome(
        ok=True,
        attachment_type=attachment_type,
        stored_files=stored_names,
        file_path=storage.raw_prefix(e_id, received_date),
        total=total,
        passed=passed,
    )
