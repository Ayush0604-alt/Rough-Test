"""Queue-driven Layer 1 orchestrator (the run lifecycle).

Implements the workflow from ``SKILL.md``:

    1. START RUN      — mint run_id, write Audit_log start row, count unread mail
    2. FETCH MAIL     — pull unread mail (Graph) or accept explicit items; stage to a
                        per-item work dir ("move to Processing")
    3. EXTRACT META   — write the Email-Table row (extraction_status = QUEUED)
    4. ENQUEUE        — one message per e_id (idempotent; skips already-SUCCESS e_ids)
    5. PROCESS        — drain the queue: PROCESSING -> validate/store -> SUCCESS, or
                        FAILED -> requeue (< 3) / EXHAUSTED -> DLQ
    10. END RUN       — write the Audit_log summary and return a RunReport

Resilience: every per-message step is wrapped — one bad item is recorded and the
batch continues. Idempotency: an e_id already SUCCESS in the Email Table is never
re-enqueued, so a crashed run resumes without duplicating completed work.
"""

from __future__ import annotations

import shutil
import tempfile
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from app.logging_config import get_logger
from app.services import clock
from app.mail_config import ACCEPTED_INPUT_TYPES, SETTINGS, Settings
from app.pipeline.mail.queue import email_table, processor, tools
from app.pipeline.mail.queue.email_table import (
    EXHAUSTED,
    FAILED,
    PROCESSING,
    QUEUED,
    SUCCESS,
)
from app.pipeline.mail.queue.message_queue import DEAD, MessageQueue

log = get_logger(__name__)


def _new_run_id() -> str:
    ts = clock.stamp("%Y%m%d%H%M%S")
    return f"L1RUN-{ts}-{uuid.uuid4().hex[:6]}"


@dataclass
class IntakeItem:
    """One email staged for processing (its files live in ``workdir``)."""

    e_id: str
    sender_mail: str
    subject: str
    date_received: Optional[str]
    attachment_files: list[str]
    links: list[str]
    workdir: str
    message_id: Optional[str] = None


@dataclass
class RunReport:
    """The concise per-batch run report (workflow step 10)."""

    run_id: str
    started_at: str
    finished_at: Optional[str] = None
    unread: int = 0
    queued: int = 0
    successful: int = 0
    failed_attempts: int = 0
    exhausted: int = 0
    skipped_done: int = 0
    errors: list[str] = field(default_factory=list)
    dead_letter: list[str] = field(default_factory=list)
    final_states: dict[str, str] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "run_id": self.run_id,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "unread": self.unread,
            "queued": self.queued,
            "successful": self.successful,
            "failed_attempts": self.failed_attempts,
            "exhausted": self.exhausted,
            "skipped_done": self.skipped_done,
            "dead_letter": list(self.dead_letter),
            "errors": list(self.errors),
            "final_states": dict(self.final_states),
        }

    def markdown(self) -> str:
        lines = [
            f"### Layer 1 run `{self.run_id}`",
            "",
            f"- unread / fetched : **{self.unread}**",
            f"- queued           : **{self.queued}**",
            f"- successful       : **{self.successful}**",
            f"- failed attempts  : **{self.failed_attempts}**",
            f"- exhausted (DLQ)  : **{self.exhausted}**",
            f"- skipped (done)   : **{self.skipped_done}**",
        ]
        if self.dead_letter:
            lines.append(f"- dead-letter e_ids: {', '.join(self.dead_letter)}")
        if self.errors:
            lines.append(f"- errors: {len(self.errors)}")
        return "\n".join(lines)


class Layer1QueueRunner:
    """Drives one Layer-1 batch through the durable queue."""

    def __init__(
        self,
        queue: Optional[MessageQueue] = None,
        *,
        storage: Optional[tools.FileStorage] = None,
        settings: Optional[Settings] = None,
    ) -> None:
        self.queue = queue or MessageQueue()
        self.settings = settings or SETTINGS
        self.storage = storage or tools.FileStorage(settings=self.settings)
        self._items: dict[str, IntakeItem] = {}
        self._work_root = Path(tempfile.mkdtemp(prefix="neuleap_l1q_"))

    # -- public entrypoint --------------------------------------------------

    def run_batch(
        self,
        emails: Optional[list[dict[str, Any]]] = None,
        *,
        fetch_graph: bool = False,
        top: Optional[int] = None,
    ) -> RunReport:
        """Run one full intake batch and return its report."""
        run_id = _new_run_id()
        report = RunReport(run_id=run_id, started_at=_now())
        log.info("=== Layer1 queue run %s START ===", run_id)

        # 1 + 2. START RUN / FETCH MAIL (move each to its Processing work dir).
        items = self._gather(emails, fetch_graph, top, report)
        report.unread = len(items)

        # Audit start row + run summary placeholder.
        tools.write_run_summary(run_id, len(items))
        tools.write_audit_event(run_id=run_id, e_id=None, step="start",
                                status="Started", reason=f"unread={len(items)}")

        # 3 + 4. EXTRACT METADATA + ENQUEUE (idempotent, skip already-done).
        for item in items:
            self._items[item.e_id] = item
            if email_table.is_success(item.e_id):
                report.skipped_done += 1
                log.info("enqueue skip: %s already SUCCESS", item.e_id)
                continue
            attachment_type = processor.detect_type(item.attachment_files, item.links)
            email_table.upsert_metadata(
                e_id=item.e_id, run_id=run_id, sender_mail=item.sender_mail,
                subject=item.subject, date_received=item.date_received,
                attachment_names=item.attachment_files, attachment_type=attachment_type,
                extraction_status=QUEUED,
            )
            created = self.queue.enqueue(
                item.e_id, run_id,
                {
                    "e_id": item.e_id,
                    "run_id": run_id,
                    "retry_count": 0,
                    "sender_mail": item.sender_mail,
                    "subject": item.subject,
                    "date_received": item.date_received,
                    "attachment_type": attachment_type,
                },
            )
            if created:
                report.queued += 1
                tools.write_audit_event(run_id=run_id, e_id=item.e_id, step="enqueue",
                                        status="Info", reason=attachment_type)

        # 5. PROCESS — drain the queue until empty (retries handled inline).
        self._drain(run_id, report)

        # 10. END RUN.
        self._finish(run_id, report)
        report.finished_at = _now()
        log.info("=== Layer1 queue run %s END: %s ===", run_id, report.as_dict())
        return report

    # -- step 2: fetch / stage ---------------------------------------------

    def _gather(
        self,
        emails: Optional[list[dict[str, Any]]],
        fetch_graph: bool,
        top: Optional[int],
        report: RunReport,
    ) -> list[IntakeItem]:
        items: list[IntakeItem] = []
        if emails:
            for raw in emails:
                items.append(self._stage_explicit(raw))
        if fetch_graph:
            try:
                items.extend(self._stage_graph(top))
            except Exception as exc:  # noqa: BLE001 — a Graph read failure must not crash the run
                msg = f"graph_fetch_failed: {exc}"
                log.warning(msg)
                report.errors.append(msg)
        return items

    def _stage_explicit(self, raw: dict[str, Any]) -> IntakeItem:
        """Stage an explicitly-provided email (attachments = [(name, local_path)])."""
        e_id = str(raw["e_id"])
        wd = self._work_root / e_id
        wd.mkdir(parents=True, exist_ok=True)
        names: list[str] = []
        for name, src in raw.get("attachments", []):
            safe = Path(name).name
            if Path(safe).suffix.lower() not in ACCEPTED_INPUT_TYPES:
                log.warning("stage %s: skipping unsupported %s", e_id, safe)
                continue
            shutil.copy2(src, wd / safe)
            names.append(safe)
        return IntakeItem(
            e_id=e_id,
            sender_mail=str(raw.get("sender_mail", "unknown")),
            subject=str(raw.get("subject", "unknown")),
            date_received=raw.get("date_received"),
            attachment_files=names,
            links=[str(link) for link in raw.get("links", [])],
            workdir=str(wd),
            message_id=raw.get("message_id"),
        )

    def _stage_graph(self, top: Optional[int]) -> list[IntakeItem]:
        """Fetch unread Graph mail + attachments into per-item work dirs."""
        import base64

        from app.db import email_master as db
        from app.services import graph_client

        out: list[IntakeItem] = []
        for msg in tools.graph_fetch_inbox(top=top):
            e_id = db.next_eid()
            wd = self._work_root / e_id
            wd.mkdir(parents=True, exist_ok=True)
            names: list[str] = []
            if msg.get("hasAttachments"):
                for att in graph_client.fetch_attachments(msg["id"]):
                    content_b64 = att.get("contentBytes")
                    if not content_b64:
                        continue
                    safe = Path(att["name"]).name
                    if Path(safe).suffix.lower() not in ACCEPTED_INPUT_TYPES:
                        continue
                    (wd / safe).write_bytes(base64.b64decode(content_b64))
                    names.append(safe)
            sender = (msg.get("from") or {}).get("emailAddress", {}).get("address", "unknown")
            item = IntakeItem(
                e_id=e_id, sender_mail=sender or "unknown",
                subject=msg.get("subject") or "unknown",
                date_received=msg.get("receivedDateTime"),
                attachment_files=names, links=[], workdir=str(wd),
                message_id=msg.get("id"),
            )
            # Move Inbox → Processing right after ingestion. Graph reassigns the id on
            # move, so keep the new id to address the mail in the later Processed move.
            item.message_id = tools.graph_move_message(item.message_id, "Processing")
            out.append(item)
        return out

    # -- step 5: drain ------------------------------------------------------

    def _drain(self, run_id: str, report: RunReport) -> None:
        """Dequeue + process until the queue is empty. Retries happen inline."""
        guard = 0
        max_iterations = 10_000  # belt-and-braces against a pathological loop
        while guard < max_iterations:
            guard += 1
            msg = self.queue.dequeue()
            if msg is None:
                break
            try:
                self._handle(run_id, msg, report)
            except Exception as exc:  # noqa: BLE001 — one bad item never stops the batch
                e_id = msg.get("e_id", "?")
                log.exception("unexpected error handling %s", e_id)
                report.errors.append(f"{e_id}: unexpected {exc}")
                self._fail(run_id, msg, f"unexpected_error: {exc}", report)

    def _handle(self, run_id: str, msg: dict[str, Any], report: RunReport) -> None:
        e_id = msg["e_id"]
        item = self._items.get(e_id)
        email_table.set_status(e_id, PROCESSING, retry_count=msg["retry_count"])
        tools.write_audit_event(run_id=run_id, e_id=e_id, step="process",
                                status="Info", reason="processing")
        if item is None:
            self._fail(run_id, msg, "intake_item_missing", report)
            return

        outcome = processor.process_item(
            e_id=e_id, received_date=item.date_received, workdir=item.workdir,
            attachment_files=item.attachment_files, links=item.links,
            storage=self.storage, settings=self.settings,
        )
        if outcome.ok:
            self._succeed(run_id, item, outcome, report)
        else:
            self._fail(run_id, msg, outcome.error_reason, report,
                       attachment_type=outcome.attachment_type)

    def _succeed(
        self, run_id: str, item: IntakeItem,
        outcome: processor.ProcessOutcome, report: RunReport,
    ) -> None:
        email_table.set_status(
            item.e_id, SUCCESS,
            file_path=outcome.file_path,
            attachment_names=", ".join(outcome.stored_files) if outcome.stored_files else "-",
        )
        self.queue.ack(item.e_id)
        # Move Processing → Processed now that every layer has passed.
        item.message_id = tools.graph_move_message(item.message_id, "Processed")
        tools.write_audit_event(run_id=run_id, e_id=item.e_id, step="store",
                                status="Success",
                                reason=f"{outcome.passed}/{outcome.total} stored")
        report.successful += 1
        report.final_states[item.e_id] = SUCCESS

    def _fail(
        self, run_id: str, msg: dict[str, Any], reason: str, report: RunReport,
        *, attachment_type: Optional[str] = None,
    ) -> None:
        e_id = msg["e_id"]
        report.failed_attempts += 1
        tools.write_audit_event(run_id=run_id, e_id=e_id, step="process",
                                status="Failed", reason=reason)
        new_state = self.queue.requeue(e_id, reason)
        if new_state == DEAD:
            email_table.set_status(e_id, EXHAUSTED,
                                   retry_count=self.queue.max_attempts,
                                   error_reason=reason)
            item = self._items.get(e_id)
            if item is not None:
                item.message_id = tools.graph_move_message(item.message_id, "Failed review")
            tools.write_audit_event(run_id=run_id, e_id=e_id, step="dead_letter",
                                    status="Exhausted", reason=reason)
            report.exhausted += 1
            report.dead_letter.append(e_id)
            report.final_states[e_id] = EXHAUSTED
        else:
            cur = self.queue.get(e_id)
            email_table.set_status(e_id, FAILED,
                                   retry_count=cur["retry_count"] if cur else 1,
                                   error_reason=reason)
            tools.write_audit_event(run_id=run_id, e_id=e_id, step="retry",
                                    status="Retry", reason=reason)
            report.final_states[e_id] = FAILED  # transient; updated on next attempt

    # -- step 10: finish ----------------------------------------------------

    def _finish(self, run_id: str, report: RunReport) -> None:
        counts = self.queue.counts()
        tools.write_audit_event(
            run_id=run_id, e_id=None, step="summary", status="Info",
            reason=(f"successful={report.successful} "
                    f"exhausted={report.exhausted} "
                    f"failed_attempts={report.failed_attempts} "
                    f"dlq={counts.get(DEAD, 0)}"),
        )
        shutil.rmtree(self._work_root, ignore_errors=True)


def _now() -> str:
    return clock.now_iso()
