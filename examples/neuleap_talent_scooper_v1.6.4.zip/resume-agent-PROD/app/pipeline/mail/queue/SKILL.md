---
name: layer1-mail-intake
description: >-
  Layer 1 orchestration contract for queue-driven Outlook (Graph) mail intake:
  the LLM resume-payload classifier gate, idempotent enqueue (e_id), deterministic
  file validation + MinIO storage, retry/DLQ policy, and audit logging.
  Use when working on mail intake, the resume classifier, the ingest queue, sender
  blocklists, attachment validation, or MinIO storage paths — and as the source of
  truth before changing any Layer 1 (queue) behaviour.
---

# Layer 1 — Queue-Driven Mail Intake

**Version 2.3**

> This contract follows the standard Skill.md section order (Name → Description →
> Purpose → Trigger → Inputs → Procedure → Script/Logic → Output Format → References →
> Rules → Examples → Success Criteria). It is the **orchestration contract**: it defines
> *what* each stage must do and *which tools* it may call. The implementation lives
> beside it in `app/pipeline/mail/queue/`; this contract is the source of truth and is
> kept reconciled to shipped code — behaviour is tagged **shipped** vs **Planned**.

## Name

`layer1-mail-intake` — Queue-Driven Mail Intake.

## Description

Fetches Outlook (Graph) inbox mail, runs an LLM resume-payload classifier gate,
validates attachments deterministically, stores clean files in MinIO, and enqueues
resume-bearing mail for Layer 2/3 — with idempotent processing (`e_id`), a 3-attempt
retry/DLQ policy, and full audit logging.

## Purpose

Filter the raw inbox down to genuine resume submissions and stage them safely and
exactly once, so the downstream extraction pipeline only ever sees clean, validated,
de-duplicated files — while every rejection and failure stays inspectable.

## Trigger / When to use

Use this skill when working on:
- mail intake or the Outlook (Graph) ingest path (`stage_graph_messages`);
- the resume classifier, its deterministic fallback, or the sender blocklist;
- the ingest queue (enqueue / retry / DLQ) or `e_id` idempotency;
- attachment validation or MinIO storage paths;
- and as the source of truth before changing any Layer 1 behaviour.

**When NOT to use it:** Layer 1 does intake, classification, validation, storage, and
audit **only**. It does not parse resumes, score ATS, build candidate profiles, or dedup
candidates — that is Layer 2/3 (see [app/extraction/SKILL.md](../../../extraction/SKILL.md)).

## Inputs

Per fetched Outlook (Graph) message, the intake pulls metadata only (never files at the
classifier): `sender`, `subject`, `body` (truncated to the first 4000 chars),
`attachment_names`, `attachment_type`, and the `links` found in the body.

Batch entry point:

```python
from app.pipeline.mail.queue import Layer1QueueRunner
report = Layer1QueueRunner().run_batch(fetch_graph=True)   # or emails=[...]

# Live Outlook (Graph) path on a pipeline run:
from app.services import mail_intake
mail_intake.stage_graph_messages(settings)   # classify + stage Inbox mail as QUEUED
```

### Idempotency key

`e_id` is the unique idempotency key for every queue message and Email-Table row.

- One live queue message per `e_id` (the queue table's PRIMARY KEY).
- An `e_id` already `SUCCESS` in the Email Table is **never re-enqueued**.
- A rejected (non-resume) message is cached by `source_message_id` and **never
  re-fetched or re-classified** on the next ingest tick.
- The same `e_id` is **never processed twice concurrently** (single run lock).

## Procedure

| Step | Action |
|------|--------|
| **1 — START RUN** | Mint `run_id`; write a run-start audit row; count the runnable set. |
| **2 — FETCH / INGEST MAIL** | `graph_client.fetch_inbox()` → per message pull metadata (`sender, subject, date, body, attachment_names, attachment_type, links`). Mail leaves the queue by being moved out of the Inbox (idempotent ingest). |
| **3 — CLASSIFY** *(LLM exception)* | For each fetched email, **before any row/queue write**, run `agent_classifier.classify(...)`. If `not is_resume` → cache `source_message_id`, `result.rejected += 1`, discard (no row, no enqueue), continue. Else proceed to Step 4. Classifier errors trigger the deterministic fallback — never halt the batch. |
| **4 — EXTRACT METADATA** | Only resume-classified mail reaches here. `write_email_row` with `e_id, sender_mail, subject, date_received, attachment_names, attachment_type, run_id, retry_count=0, extraction_status=QUEUED`. Classifier source/category recorded on the ingest audit event (`DISCOVERED->QUEUED · <source>:<category>`). |
| **5 — ENQUEUE** | Row staged `QUEUED`; the manual/auto run processes the queued set. Resume-safe: an `e_id` already `SUCCESS` is never re-processed. |
| **6 — PROCESS MESSAGE** | `dequeue` → set `PROCESSING` → determine type (`PDF \| DOCX \| ZIP \| EXCEL \| LINK \| IMAGE \| MIXED \| NONE`) → route (see §Script / Logic). |
| **7 — VALIDATION** | **Deterministic — never LLM.** Existence + extension/MIME match + integrity (not corrupt, not zero-byte). Allowed final types: `{pdf, docx, doc, jpg, jpeg, png}`. Reject and never store corrupt / unsupported / empty files. |
| **8 — STORAGE (MinIO)** | `save_file` → `raw/YYYY/MM/DD/{e_id}/<filename>`; update `file_path`. On MinIO write failure → processing failure (Retry/DLQ path). *Planned:* mint + store a pre-signed URL for Layer 2. |
| **9 — SUCCESS** | `extraction_status=SUCCESS`; audit success; `ack`; move mail to **Processed**. |
| **10 — FAILURE** | Audit the reason; if `retry_count < 3` requeue (`FAILED`), else `EXHAUSTED` + `dead_letter` and keep in Failed-review state. |
| **11 — END RUN** | Write the run summary (total / successful / failed / exhausted; rejected count available) and the run-end audit row; return the run report. |

## Script / Logic

### Attachment routing (Step 6)

| Type | Route |
|------|-------|
| `PDF` | `validate_pdf` → save to MinIO |
| `DOCX` | `validate_docx` → save to MinIO |
| `IMAGE` (JPG/PNG) | `validate_image` → save to MinIO |
| `ZIP` | `extract_zip` → validate inner files → keep allowed |
| `EXCEL` | `read_excel_rows` → download resume links → validate |
| `LINK` | download → validate type → save to MinIO |
| `MIXED` | process each component independently |
| `NONE` | fail (retry only if attempts remain) |

### Resume-payload rule (the classifier's hard rule)

Text is never enough. A mail is admitted **only** when it carries a resume payload:

| Payload | Counts? |
|---------|---------|
| Attachment `.pdf` / `.doc` / `.docx` | Yes |
| Container attachment `.zip` / `.xlsx` (may hold one) | Yes |
| Link to a resume file (URL ends in `.pdf`/`.doc`/`.docx`) | Yes |
| Link to a file-share (Google Drive/Docs, OneDrive, SharePoint, Dropbox, WeTransfer, Box) | Yes |
| Only the word "resume"/"cv" in subject/body, no attachment/link | reject |
| Only website links (e.g. `linkedin.com` job pages, job boards, blogs) | reject |
| No subject **and** no body **and** no attachment | reject |

A LinkedIn "you appeared in N searches" alert (website link, no file) is rejected even
though it mentions jobs; a mail with `Jane_Resume.pdf` attached is admitted. Reason on
rejection: `no_resume_payload: …`. The file-share host list and `is_resume_link(url)`
live in `resume_filter.py`.

### Classifier scoping + fallback

- Runs **once per email**, before the Email-Table row is created / enqueued; sees only
  metadata (`subject`, `body`, `attachment_names`, `links`) — **never files**.
- Model: Azure OpenAI **`gpt-4o-mini`** via `services/agent_llm.build_azure_llm`,
  temperature `0`, strict-JSON reply (fences tolerated).
- **Not retried on LLM error** — the fallback heuristic activates immediately.
- Output is advisory; the verdict trusts the `is_resume` boolean directly.

| Fallback condition | Action |
|--------------------|--------|
| Agent disabled (`MAIL_CLASSIFIER_AGENT=0`) or Azure unconfigured | Deterministic heuristic (`source="deterministic"`). |
| LLM call fails (timeout, API error) | Deterministic heuristic; warning logged. |
| LLM reply is malformed JSON | Deterministic heuristic; warning logged. |
| LLM call succeeds | Use the agent verdict (`source="agent"`). |

The deterministic fallback is `resume_filter.is_resume_email` — **payload-gated** and it
**never raises**, so a bad LLM call can never halt ingest:

```
ACCEPT if ANY of:
  - a resume-type attachment (.pdf / .doc / .docx), OR
  - a container attachment (.zip / .xlsx) that may hold one, OR
  - a link to a resume file (URL ends .pdf/.doc/.docx), OR
  - a link to a file-share host (Drive/Docs/OneDrive/SharePoint/Dropbox/WeTransfer/Box).
REJECT otherwise (reason "no_resume_payload: …").
```

### Sender blocklist — cheap FIRST pass

Before any payload inspection or LLM call, the sender is checked against a blocklist
(`resume_filter.blocklisted_sender(sender)`); a match rejects immediately:

- **`BLOCKLIST_DOMAINS`** — matches the sender domain or any subdomain (default
  `linkedin.com`, `naukri.com`; blocks `notifications.linkedin.com`).
- **`BLOCKLIST_PREFIXES`** — matches an automated local-part or leading subdomain label
  (default `noreply`, `no-reply`, `donotreply`, `bounce`, `mailer-daemon`, `newsletter`,
  `digest`, `notifications`, `notify`, `updates`, `alerts`, …).

Both env-overridable, defined in `app/mail_config.py`, applied to Gmail + Outlook
(Graph rejects before downloading attachments) + the 60s preview.

> Keep `BLOCKLIST_DOMAINS` conservative — a job board that *forwards* a real resume from
> its own domain would be dropped. The `*PREFIXES` are safe (automated senders never
> carry a candidate's own resume).

### Retry / DLQ policy

- **3 total attempts** per `e_id`. On failure: write the reason to Audit_log, increment
  `retry_count`.
  - `retry_count < 3` → requeue (eligible next run), preserving order.
  - `retry_count == 3` → `EXHAUSTED`, route to the **Dead-Letter Queue** (Failed-review),
    keep inspectable. **Never lose the reason.**
- A failure of one item must never stop the batch.
- **Classifier failures do NOT count as retry attempts** — the fallback runs immediately.

## Output Format

### Status vocabulary (Email Table `extraction_status`)

```
QUEUED → PROCESSING → SUCCESS
                    → FAILED → (retry) → EXHAUSTED
```

| Status | Meaning | Shipped |
|--------|---------|---------|
| `QUEUED` | Resume-bearing; metadata written; waiting for the next pipeline run. | Yes |
| `PROCESSING` | Locked under a `run_id`, currently being processed. | Yes |
| `SUCCESS` | File validated, stored in MinIO, mail moved to Processed. | Yes |
| `FAILED` | Processing failed; retry pending if attempts remain. | Yes |
| `EXHAUSTED` | All 3 attempts failed; routed to DLQ; awaiting manual review. | Yes |
| `SKIPPED` | **Planned.** A persisted row for non-resume mail. Today non-resume mail is rejected at ingest *without* a row (cached by `source_message_id`). | Planned |

### Classifier output — `MailClassification`

```python
MailClassification(
    is_resume:  bool,    # true → admit to queue; false → reject
    category:   str,     # one of the stable label set below
    confidence: float,   # 0.0–1.0, clamped (advisory; not thresholded today)
    reason:     str,     # short human-readable explanation, always populated
    source:     str,     # "agent" | "deterministic"
)
```

`as_gate()` collapses this to `(is_resume, "[source:category] reason")`, consumed by the
ingest gate and recorded in the audit trail.

**Stable label set** (free-text drifts; these don't):

| Group | Categories |
|-------|------------|
| Resume (admit) | `resume_submission`, `job_application`, `referral` |
| Reject | `recruiter_outreach`, `newsletter`, `job_alert`, `receipt`, `security_alert`, `spam`, `other` |

### RunReport

Renders total fetched, successful, failed (retrying), and exhausted (DLQ). The
rejected/non-resume count is tracked at ingest (`IngestResult.rejected`). *Planned:* a
dedicated `skipped` column lands with the SKIPPED-status work.

## References

### Storage paths (MinIO)

```
s3://{MINIO_BUCKET}/raw/YYYY/MM/DD/{e_id}/<filename>     # validated (put_final / dated_key)
s3://{MINIO_BUCKET}/temp/{e_id}/<filename>               # pre-validation mirror (put_temp / temp_key)
```

- `FileStorage` (`queue/tools.py`) delegates to `services/mail_storage.py` (MinIO-backed,
  **not** `minio_storage.py`): `save_file` → `put_final` → `put_bytes`; `file_exists` →
  existence probe; `raw_prefix(e_id, received_date)` → the object-key prefix.
- **Only clean, validated files are written**; rejections are logged to Audit_log.
- *Planned:* `minio_presign_url(object_key, expiry)` for Layer 2 (no `presigned_url`
  column today).

### Tool surface

Deterministic in-process functions (this repo ships **no** `mcp` runtime dependency by
design). **File validation is deterministic — never LLM.**

| Group | Tools | Module |
|-------|-------|--------|
| **Graph** | `graph_fetch_inbox`, `graph_fetch_attachments`, `graph_move_message` | `tools.py`, `services/graph_client.py` |
| **Classifier** | `classify`, `classify_is_resume` | `queue/agent_classifier.py` (→ `services/agent_llm.py`) |
| **Queue** | `enqueue`, `dequeue`, `ack`, `requeue`, `dead_letter` | `message_queue.py` |
| **Storage** | `save_file`, `file_exists`, `raw_prefix` (MinIO-backed) | `queue/tools.py` (`FileStorage`) → `services/mail_storage.py` |
| **Validation** | `validate_pdf`, `validate_docx`, `validate_image`, `validate_excel`, `extract_zip`, `read_excel_rows`, `validate_by_extension` | `tools/validation.py` |
| **Logging** | `write_email_row` (`email_table.upsert_metadata`/`set_status`), `write_audit_event`, `write_run_summary` | `email_table.py`, `tools.py` |

> **Planned tool:** `minio_presign_url`. Modules: `agent_classifier.py`,
> `resume_filter.py`, `message_queue.py`, `email_table.py`, `tools.py`, `runner.py`,
> `processor.py`.

### Email-Table columns

**Implemented (`db/schema.sql`):** `e_id`, `sender_mail_id`, `subject`, `received_date`,
`attachment_names`, `extracted_status`, `process_status`, `processed`, `processed_at`,
plus queue fields `run_id`, `attachment_type`, `file_path`, `extraction_status`,
`retry_count`, `error_reason`, `source_message_id`, `created_at`, `updated_at`.

**Planned (v2.0 target, not yet in schema):**

| Column | Type | Notes |
|--------|------|-------|
| `resume_source` | enum | `attachment \| link \| both \| none` |
| `skip_reason` | str | populated when `extraction_status=SKIPPED` |
| `presigned_url` | str | MinIO pre-signed URL; Layer 2 reads this |
| `classifier_confidence` | float | LLM confidence; useful for tuning blocklists |

### Configuration surface (env vars)

| Key | Status | Description |
|-----|--------|-------------|
| `MINIO_ENDPOINT` | Yes | MinIO host (`host:port`). |
| `MINIO_BUCKET` | Yes | Target bucket. |
| `MINIO_ACCESS_KEY` / `MINIO_SECRET_KEY` | Yes | Credentials. |
| `MAIL_RESUME_FILTER` | Yes | Master resume-gate toggle (default `1`; `0` admits everything). |
| `MAIL_CLASSIFIER_AGENT` | Yes | LLM classifier toggle (default `1`; `0` ⇒ deterministic). |
| `AZURE_OPENAI_ENDPOINT` / `AZURE_OPENAI_KEY` | Yes | Classifier model credentials (absent ⇒ deterministic fallback). |
| `BLOCKLIST_DOMAINS` | Yes | Sender domains to always skip (default `linkedin.com,naukri.com`). |
| `BLOCKLIST_PREFIXES` | Yes | Automated local-part / subdomain labels to skip (noreply, digest, …). |
| `MINIO_PRESIGN_EXPIRY_DAYS` | Planned | Pre-signed URL expiry (default 7). |
| `CLASSIFIER_CONFIDENCE_THRESHOLD` | Planned | Low-confidence fallback threshold (default 0.60). |
| `NON_RESUME_FOLDER` / `PROCESSED_FOLDER` | Planned | Graph mailbox folders for SKIPPED / SUCCESS. |

### Entry point (unchanged interface)

```python
from app.pipeline.mail.queue import Layer1QueueRunner
report = Layer1QueueRunner().run_batch(fetch_graph=True)   # or emails=[...]
print(report.markdown())

# The live Outlook (Graph) path runs on a pipeline run:
from app.services import mail_intake
mail_intake.stage_graph_messages(settings)   # classify + stage Inbox mail as QUEUED
# orchestrator.run_all() then drains the queue through L1 → L2 → L3
```

## Rules / Constraints

1. **Deterministic everywhere except the classifier.** The LLM classifier is the one
   scoped exception: it runs **once, before a mail is admitted**, sees only metadata
   (never files), and **always has a rule-based fallback**. All file validation stays
   fully deterministic.
2. The classifier uses the repo's existing Azure OpenAI stack (`gpt-4o-mini`), not Claude.
3. **Payload required.** Admit only mail carrying a resume attachment/container or a link
   to a resume file / file-share; text-only and website-only mail is rejected.
4. **Idempotent.** One live queue message per `e_id`; a `SUCCESS` `e_id` is never
   re-enqueued; the same `e_id` is never processed twice concurrently.
5. **Never store junk.** Only clean, validated files reach MinIO; corrupt/unsupported/
   empty files are rejected and logged, never stored.
6. **Never lose a reason.** Every rejection/failure is written to Audit_log; exhausted
   items go to the DLQ, inspectable.
7. **A single item's failure never stops the batch.** Classifier failures do not consume
   retry attempts.
8. **Never expose secrets.** No credentials/tokens in logs or storage paths.

## Examples

- **Resume attachment** — mail with `Jane_Resume.pdf` → classifier `is_resume=true` →
  `QUEUED` → validate PDF → store at `raw/YYYY/MM/DD/{e_id}/Jane_Resume.pdf` → `SUCCESS`.
- **LinkedIn job alert** — "you appeared in N searches", website link, no file →
  `no_resume_payload` → rejected at ingest, `source_message_id` cached, no row written.
- **Automated sender** — `noreply@acme.com` → blocklist prefix match → rejected before
  payload/LLM inspection.
- **Drive link** — body links to a Google Drive file, no attachment → file-share host →
  admitted → `LINK` route → download + validate.
- **Corrupt PDF** — attachment fails `validate_pdf` → not stored → `FAILED`; retried if
  attempts remain, else `EXHAUSTED` → DLQ.
- **Classifier outage** — Azure error → deterministic `is_resume_email` fallback runs
  immediately (no retry consumed); ingest continues.

## Success Criteria

The skill succeeds when it: admits only genuine resume-payload mail; rejects
website-only/automated-sender/text-only mail with a recorded reason; processes each
`e_id` exactly once (no duplicates, no concurrent double-processing); stores only clean,
validated files in the dated MinIO path; retries failures up to 3 times and routes the
exhausted ones to an inspectable DLQ; never loses a rejection/failure reason; and never
lets one bad item or a classifier outage halt the batch.

---

## Change log

| Version | Change |
|---------|--------|
| 2.3 | **Restructured to the standard Skill.md section order** (Name → Description → Purpose → Trigger → Inputs → Procedure → Script/Logic → Output Format → References → Rules → Examples → Success Criteria). No behavioural change — all prior technical content (status vocabulary, classifier contract, payload rule, fallback/blocklist logic, retry/DLQ policy, storage paths, tool/config surfaces, Email-Table columns) is preserved and reorganised under the canonical headings. |
| 2.2 | Added a **sender blocklist** as a cheap first pass (before payload/LLM): `blocklisted_sender()` rejects `BLOCKLIST_DOMAINS` (+ subdomains) and `BLOCKLIST_PREFIXES` (noreply/digest/notifications/…). Config in `mail_config.py`, env-overridable, applied to Gmail + Outlook (Graph rejects before downloading attachments) + the 60s preview. `sender` threaded through `classify(...)` / `is_resume_email(...)`. |
| 2.1 | Made the gate **payload-required**: a mail is admitted only with a resume attachment/container or a link to a resume file / file-share; text-only and website-only mail (LinkedIn alerts) are rejected with `no_resume_payload`. Added `links` to the classifier input + `is_resume_link()` / `FILE_SHARE_HOSTS` to `resume_filter.py`, and tightened the agent prompt. Extended the gate to the **Outlook (Graph)** path (`stage_graph_messages` runs the same classifier; the 60s `graph_poller` preview hides non-resume mail). |
| 2.0 | Documented the LLM resume classifier (`agent_classifier.py`, Azure `gpt-4o-mini`) as a scoped exception at the ingest gate, with deterministic fallback. Documented the MinIO storage backend (`mail_storage.py`) and `validate_image`. Reconciled the contract to the shipped code and tagged not-yet-built items as **Planned**. |
| 1.0 | Initial queue-driven intake contract. |
