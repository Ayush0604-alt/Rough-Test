"""Queue-driven Layer 1 (Mail Intake Layer).

This package adds a durable message-queue stage to Layer 1 *without* touching the
existing LangGraph path. The flow is:

    START RUN -> FETCH MAIL -> EXTRACT METADATA -> ENQUEUE (keyed by e_id)
              -> PROCESS (validate / store) -> SUCCESS|FAILED|EXHAUSTED -> END RUN

Design contract lives in ``SKILL.md`` (the orchestration contract). The
deterministic "MCP tool surface" (Graph / Queue / Storage / Validation /
Logging) is exposed by :mod:`app.pipeline.mail.queue.tools` as plain in-process
functions — the repository deliberately ships no ``mcp`` runtime dependency.
"""

from __future__ import annotations

from app.pipeline.mail.queue.email_table import (
    EXHAUSTED,
    FAILED,
    PROCESSING,
    QUEUED,
    SUCCESS,
)
from app.pipeline.mail.queue.message_queue import MessageQueue
from app.pipeline.mail.queue.runner import IntakeItem, Layer1QueueRunner, RunReport

__all__ = [
    "MessageQueue",
    "Layer1QueueRunner",
    "IntakeItem",
    "RunReport",
    "QUEUED",
    "PROCESSING",
    "SUCCESS",
    "FAILED",
    "EXHAUSTED",
]
