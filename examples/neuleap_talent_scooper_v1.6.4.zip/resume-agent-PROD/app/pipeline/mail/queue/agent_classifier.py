"""Agentic mail classification for the queue-driven Layer 1 resume gate.

The SKILL contract keeps **file validation and type detection deterministic — never
LLM**. What *is* a judgement call is the very first decision at ingest: *"is this
mail a resume / job application at all, or a newsletter / alert / receipt?"*. This
module promotes that **mail classification** to an LLM agent (Azure ``gpt-4o-mini``
via :mod:`app.services.agent_llm`), while everything downstream (extension routing,
PDF/DOCX/ZIP/Excel validation, storage) stays deterministic.

Design guarantees:

* **Same gate interface** — :func:`classify_is_resume` returns ``(accept, reason)``,
  a drop-in for :func:`app.pipeline.mail.queue.resume_filter.is_resume_email`.
* **Graceful degradation** — when the agent is disabled (``MAIL_CLASSIFIER_AGENT=0``),
  not configured (no Azure key/SDK), or errors at runtime, it falls back to the
  deterministic keyword filter. The pipeline therefore runs fully offline and every
  existing test stays green.
* **Explainable** — every decision carries a human-readable ``reason`` and a
  ``source`` (``agent`` | ``deterministic``) so the audit trail says how it was made.
"""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from app.logging_config import get_logger
from app.pipeline.mail.queue import resume_filter

log = get_logger(__name__)

# Stable label set the agent must choose from (free-text categories drift; these
# don't). Only the resume-bearing categories admit a mail to the queue.
RESUME_CATEGORIES = frozenset(
    {"resume_submission", "job_application", "referral"}
)
ALL_CATEGORIES = RESUME_CATEGORIES | frozenset(
    {"recruiter_outreach", "newsletter", "job_alert", "receipt",
     "security_alert", "spam", "other"}
)

_SYSTEM_PROMPT = (
    "You are the intake classification agent for a resume-processing pipeline. "
    "Your ONLY job is to decide whether an incoming email is a candidate's resume / "
    "job application that a recruiter should process, versus noise (newsletters, job "
    "alerts, receipts, security alerts, spam, generic recruiter outreach with no "
    "candidate resume). You never read or validate file contents — you judge intent "
    "from the subject, body, attachment file names, and links only.\n\n"
    "HARD RULE — a resume email MUST carry a resume PAYLOAD. Set is_resume=true ONLY "
    "when the mail has at least one of:\n"
    "  • a resume-type attachment (.pdf, .doc, .docx), or a container that may hold "
    "one (.zip, .xlsx); OR\n"
    "  • a LINK to a resume file (URL ending in .pdf/.doc/.docx) or to a file-share "
    "(Google Drive/Docs, OneDrive, SharePoint, Dropbox, WeTransfer, Box).\n"
    "If the mail has NO attachment and NO resume/file-share link — even if the subject "
    "or body says 'resume' — set is_resume=false. In particular, REJECT LinkedIn "
    "notifications, job alerts, and any mail whose only links point to websites "
    "(linkedin.com, job boards, blogs) rather than a downloadable resume file.\n\n"
    "Respond with STRICT JSON only, no prose, no markdown fences:\n"
    '{"is_resume": <bool>, "category": <one of '
    + ", ".join(sorted(ALL_CATEGORIES))
    + '>, "confidence": <0.0-1.0>, "reason": <short phrase>}'
)

# Keep token cost bounded — the first few KB carry all the signal we need.
_MAX_BODY_CHARS = 4000


@dataclass(frozen=True)
class MailClassification:
    """Structured verdict for one email's intake classification."""

    is_resume: bool
    category: str
    confidence: float
    reason: str
    source: str  # "agent" | "deterministic"

    def as_gate(self) -> tuple[bool, str]:
        """Collapse to the ``(accept, reason)`` shape the ingest gate consumes."""
        return self.is_resume, f"[{self.source}:{self.category}] {self.reason}"


def _agent_enabled() -> bool:
    """True when the LLM classifier is both requested and actually usable."""
    if os.environ.get("MAIL_CLASSIFIER_AGENT", "1") == "0":
        return False
    # Pull Azure creds from the services env file without clobbering real env.
    try:
        from app.services.agent_llm import load_env

        load_env()
    except Exception as exc:  # noqa: BLE001 — missing env file is fine
        log.debug("classifier: load_env skipped (%s)", exc)
    if not (os.environ.get("AZURE_OPENAI_KEY") and os.environ.get("AZURE_OPENAI_ENDPOINT")):
        return False
    try:
        import langchain_openai  # noqa: F401
    except ImportError:
        log.info("classifier agent requested but langchain-openai not installed")
        return False
    return True


def _parse_json(text: str) -> dict[str, Any]:
    """Extract the JSON object from a model reply (tolerates ```json fences)."""
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = re.sub(r"^```[a-zA-Z]*\n?|\n?```$", "", cleaned).strip()
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", cleaned, re.DOTALL)
        if match:
            return json.loads(match.group(0))
        raise


def _classify_with_agent(
    subject: str, body: str, attachment_names: list[str], links: list[str]
) -> MailClassification:
    """Ask the LLM agent to classify the mail. Raises on any failure (caller falls back)."""
    from app.services.agent_llm import build_azure_llm

    names = ", ".join(str(n) for n in (attachment_names or [])) or "(none)"
    link_str = ", ".join(str(u) for u in (links or [])) or "(none)"
    user = (
        f"Subject: {subject or '(empty)'}\n"
        f"Attachments: {names}\n"
        f"Links: {link_str}\n"
        f"Body:\n{(body or '').strip()[:_MAX_BODY_CHARS] or '(empty)'}"
    )
    llm = build_azure_llm(temperature=0.0)
    reply = llm.invoke([("system", _SYSTEM_PROMPT), ("human", user)])
    data = _parse_json(getattr(reply, "content", "") or "")

    category = str(data.get("category", "other")).strip().lower()
    if category not in ALL_CATEGORIES:
        category = "other"
    # Trust the explicit boolean, but keep it coherent with the category label.
    is_resume = bool(data.get("is_resume"))
    try:
        confidence = float(data.get("confidence", 0.0))
    except (TypeError, ValueError):
        confidence = 0.0
    reason = str(data.get("reason", "")).strip()[:200] or "agent classification"
    return MailClassification(
        is_resume=is_resume,
        category=category,
        confidence=max(0.0, min(1.0, confidence)),
        reason=reason,
        source="agent",
    )


def _deterministic(
    subject: str, body: str, attachment_names: list[str],
    links: list[str], sender: str,
) -> MailClassification:
    """The payload/keyword heuristic, wrapped in the structured verdict shape."""
    accept, reason = resume_filter.is_resume_email(
        subject, body, attachment_names, links, sender,
    )
    return MailClassification(
        is_resume=accept,
        category="resume_submission" if accept else "other",
        confidence=1.0 if accept else 0.0,
        reason=reason,
        source="deterministic",
    )


def classify(
    subject: str,
    body: str,
    attachment_names: list[str],
    links: list[str] | None = None,
    sender: str | None = None,
) -> MailClassification:
    """Classify an email at intake — blocklist → agent → deterministic fallback.

    ``sender`` is checked against the blocklist FIRST (a cheap reject before any LLM
    call). ``links`` are part of the payload test (website-only mail is rejected).
    """
    links = list(links or [])

    # First pass: blocklisted senders (noreply/digest/LinkedIn/naukri …) never carry
    # a candidate resume — reject without spending an LLM call.
    blocked = resume_filter.blocklisted_sender(sender)
    if blocked:
        log.info("classifier(blocklist): rejected sender=%r — %s", sender, blocked)
        return MailClassification(
            is_resume=False, category="job_alert", confidence=1.0,
            reason=blocked, source="blocklist",
        )

    # Deterministic payload short-circuit: a resume-type attachment (.pdf/.doc/.docx)
    # or a container that may hold one (.zip/.xlsx) IS a resume payload — accept it
    # without an LLM call. This stops the agent from vetoing real payloads (e.g. an
    # Excel candidate list, or a resume .zip it judged "not a resume"). The agent is
    # only consulted for the genuinely ambiguous no-attachment case (link/text only).
    exts = {Path(str(n)).suffix.lower() for n in (attachment_names or [])}
    payload_exts = resume_filter.RESUME_EXTS | resume_filter.CONTAINER_EXTS
    matched = sorted(exts & payload_exts)
    if matched:
        log.info("classifier(payload): accepted on attachment type(s) %s", matched)
        return MailClassification(
            is_resume=True, category="resume_submission", confidence=1.0,
            reason=f"resume-bearing attachment ({', '.join(matched)})",
            source="deterministic",
        )

    if _agent_enabled():
        try:
            result = _classify_with_agent(subject, body, attachment_names, links)
            log.info(
                "classifier(agent): is_resume=%s category=%s conf=%.2f subject=%r",
                result.is_resume, result.category, result.confidence,
                (subject or "")[:60],
            )
            return result
        except Exception as exc:  # noqa: BLE001 — never let the agent break ingest
            log.warning("classifier agent failed, falling back to deterministic: %s", exc)
    return _deterministic(subject, body, attachment_names, links, sender or "")


def classify_is_resume(
    subject: str,
    body: str,
    attachment_names: list[str],
    links: list[str] | None = None,
    sender: str | None = None,
) -> tuple[bool, str]:
    """Drop-in replacement for ``resume_filter.is_resume_email`` -> ``(accept, reason)``."""
    return classify(subject, body, attachment_names, links, sender).as_gate()
