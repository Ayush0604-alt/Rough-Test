"""Extended Email Table writer for the queue-driven Layer 1.

The spec's Email Table is the existing ``email_master`` row PLUS the queue
lifecycle fields (``run_id``, ``attachment_type``, ``file_path``,
``extraction_status``, ``retry_count``, ``processed_at``, ``error_reason``). Those
columns are added additively by ``schema.sql``; this module owns writing them.

``extraction_status`` uses the queue vocabulary required by the spec::

    QUEUED -> PROCESSING -> SUCCESS | FAILED | EXHAUSTED

To keep ``email_master`` coherent for existing readers (frontend, handoff), each
write also mirrors the legacy 7-column fields: ``process_status`` = Passed on
SUCCESS else Failed, and ``extracted_status`` echoes the queue status.

Everything degrades to an in-memory store when PostgreSQL is unavailable (offline
tests), so the queue path is fully exercisable without a database. The in-memory
table is also the inspection surface the tests read.
"""

from __future__ import annotations

import threading
from typing import Any, Optional

from app.db import email_master as db
from app.logging_config import get_logger
from app.services import clock

log = get_logger(__name__)

# extraction_status vocabulary (spec).
DISCOVERED = "DISCOVERED"
QUEUED = "QUEUED"
PROCESSING = "PROCESSING"
SUCCESS = "SUCCESS"
FAILED = "FAILED"
EXHAUSTED = "EXHAUSTED"

# In-memory mirror: e_id -> row dict. Always written (cheap) so tests and the
# DB-less path share one source of truth.
_MEM: dict[str, dict[str, Any]] = {}
_LOCK = threading.Lock()


def _now() -> str:
    return clock.now_iso()


def reset() -> None:
    """Clear the in-memory mirror (test helper)."""
    with _LOCK:
        _MEM.clear()


def get(e_id: str) -> Optional[dict[str, Any]]:
    """Return the current Email Table row for ``e_id`` (in-memory mirror)."""
    with _LOCK:
        row = _MEM.get(e_id)
        return dict(row) if row else None


def all_rows() -> list[dict[str, Any]]:
    with _LOCK:
        return [dict(r) for r in _MEM.values()]


def is_success(e_id: str) -> bool:
    row = get(e_id)
    return bool(row and row.get("extraction_status") == SUCCESS)


def list_by_status(*statuses: str) -> list[dict[str, Any]]:
    """All rows whose extraction_status is in ``statuses`` (insertion order)."""
    want = set(statuses)
    with _LOCK:
        return [dict(r) for r in _MEM.values() if r.get("extraction_status") in want]


def counts() -> dict[str, int]:
    """Aggregate row counts per extraction_status (UI queue counts)."""
    out: dict[str, int] = dict.fromkeys(
        (DISCOVERED, QUEUED, PROCESSING, SUCCESS, FAILED, EXHAUSTED), 0
    )
    with _LOCK:
        for row in _MEM.values():
            status = row.get("extraction_status")
            out[status] = out.get(status, 0) + 1
    return out


def upsert_metadata(  # noqa: PLR0913 — row-writer: one keyword-only arg per Email-Table column
    *,
    e_id: str,
    run_id: Optional[str],
    sender_mail: str,
    subject: str,
    date_received: Optional[str],
    attachment_names: list[str] | str,
    attachment_type: str,
    retry_count: int = 0,
    extraction_status: str = QUEUED,
    source_message_id: Optional[str] = None,
) -> dict[str, Any]:
    """Create/refresh the metadata row at intake time (status defaults QUEUED)."""
    names = (
        attachment_names
        if isinstance(attachment_names, str)
        else (", ".join(attachment_names) if attachment_names else "-")
    )
    now = _now()
    with _LOCK:
        created = _MEM.get(e_id, {}).get("created_at") or now
        row = {
            "e_id": e_id,
            "source_message_id": source_message_id,
            "run_id": run_id,
            "sender_mail": sender_mail,
            "subject": subject,
            "date_received": date_received or "unknown",
            "attachment_names": names,
            "attachment_type": attachment_type,
            "file_path": None,
            "extraction_status": extraction_status,
            "retry_count": retry_count,
            "processed_at": None,
            "error_reason": None,
            "created_at": created,
            "updated_at": now,
        }
        _MEM[e_id] = row
        snapshot = dict(row)
    _persist(snapshot)
    log.info("email_table %s: metadata -> %s (%s)", e_id, extraction_status, attachment_type)
    return snapshot


def set_status(
    e_id: str,
    extraction_status: str,
    *,
    run_id: Optional[str] = None,
    retry_count: Optional[int] = None,
    file_path: Optional[str] = None,
    attachment_names: Optional[str] = None,
    error_reason: Optional[str] = None,
    processed_at: Optional[str] = None,
) -> None:
    """Transition the Email Table row; only provided fields are overwritten."""
    with _LOCK:
        row = _MEM.get(e_id)
        if row is None:
            # Defensive: never lose a transition even if metadata wasn't seen.
            row = {"e_id": e_id, "source_message_id": None, "run_id": None,
                   "sender_mail": "unknown", "subject": "unknown",
                   "date_received": "unknown", "attachment_names": "-",
                   "attachment_type": "NONE", "file_path": None,
                   "extraction_status": extraction_status, "retry_count": 0,
                   "processed_at": None, "error_reason": None,
                   "created_at": _now(), "updated_at": _now()}
            _MEM[e_id] = row
        row["extraction_status"] = extraction_status
        row["updated_at"] = _now()
        if run_id is not None:
            row["run_id"] = run_id
        if retry_count is not None:
            row["retry_count"] = retry_count
        if file_path is not None:
            row["file_path"] = file_path
        if attachment_names is not None:
            row["attachment_names"] = attachment_names
        if error_reason is not None:
            row["error_reason"] = error_reason
        if extraction_status in (SUCCESS, FAILED, EXHAUSTED) and processed_at is None:
            processed_at = _now()
        if processed_at is not None:
            row["processed_at"] = processed_at
        snapshot = dict(row)
    _persist(snapshot)
    log.info("email_table %s: -> %s (retry=%s)", e_id,
             extraction_status, snapshot.get("retry_count"))


# --------------------------------------------------------------------------- #
# PostgreSQL persistence (best-effort; no-op when DB-less)
# --------------------------------------------------------------------------- #

_UPSERT = """
    INSERT INTO email_master (
        e_id, sender_mail_id, subject, received_date, attachment_names,
        extracted_status, process_status,
        run_id, attachment_type, file_path, extraction_status,
        retry_count, error_reason, processed, processed_at,
        source_message_id, created_at, updated_at
    ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
    ON CONFLICT (e_id) DO UPDATE SET
        sender_mail_id    = EXCLUDED.sender_mail_id,
        subject           = EXCLUDED.subject,
        received_date     = EXCLUDED.received_date,
        attachment_names  = EXCLUDED.attachment_names,
        extracted_status  = EXCLUDED.extracted_status,
        process_status    = EXCLUDED.process_status,
        run_id            = EXCLUDED.run_id,
        attachment_type   = EXCLUDED.attachment_type,
        file_path         = EXCLUDED.file_path,
        extraction_status = EXCLUDED.extraction_status,
        retry_count       = EXCLUDED.retry_count,
        error_reason      = EXCLUDED.error_reason,
        processed_at      = EXCLUDED.processed_at,
        source_message_id = EXCLUDED.source_message_id,
        updated_at        = EXCLUDED.updated_at
"""
# NOTE: ``processed`` (the D10 downstream-complete flag) is deliberately NOT in the
# UPDATE set. It is owned by the orchestrator (set TRUE after L2+L3 finish); L1 only
# ever inserts it FALSE so a freshly-stored resume is picked up by phase 2.


def _persist(row: dict[str, Any]) -> None:
    if not db.is_enabled():
        return
    status = row["extraction_status"]
    process_status = "Passed" if status == SUCCESS else "Failed"
    # L1 never owns the downstream-complete flag — leave it FALSE so the orchestrator
    # (phase 2) picks up a Passed resume for L2+L3, then sets it TRUE itself.
    processed = False
    processed_at = row.get("processed_at")  # ISO str or None; psycopg2 casts it
    try:
        from app.db import get_conn

        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(_UPSERT, (
                    row["e_id"], row["sender_mail"], row["subject"],
                    row["date_received"], row["attachment_names"],
                    status, process_status,
                    row["run_id"], row["attachment_type"], row["file_path"],
                    status, row["retry_count"], row["error_reason"],
                    processed, processed_at,
                    row.get("source_message_id"), row.get("created_at"),
                    row.get("updated_at"),
                ))
    except Exception as exc:  # noqa: BLE001 — persistence must never break a run
        log.warning("email_table persist failed for %s: %s", row["e_id"], exc)
