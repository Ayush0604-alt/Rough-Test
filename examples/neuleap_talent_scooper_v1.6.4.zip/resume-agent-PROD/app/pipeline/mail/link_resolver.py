"""Workflow A — share-link → downloadable-URL resolution (pure, no network).

This module performs only the *string* transformation from a human share link
into a direct-download URL, plus provider detection. It never makes network
calls, so it is fully deterministic and unit-testable. The actual fetch (gated
to local-only behavior in test mode) lives in :mod:`neuleap_layer1.download`.
"""

from __future__ import annotations

import re
from typing import Any

from app.logging_config import get_logger

log = get_logger(__name__)

_GDRIVE_ID_PATTERNS = (
    re.compile(r"/file/d/([A-Za-z0-9_-]+)"),
    re.compile(r"[?&]id=([A-Za-z0-9_-]+)"),
)


def detect_provider(url: str) -> str:
    """Classify a URL's hosting provider."""
    u = url.lower()
    if "drive.google.com" in u or "docs.google.com" in u:
        return "google_drive"
    if "1drv.ms" in u or "onedrive.live.com" in u:
        return "onedrive"
    if "sharepoint.com" in u:
        return "sharepoint"
    if "dropbox.com" in u:
        return "dropbox"
    if re.search(r"\.(pdf|docx|jpg|jpeg|png|zip|xlsx)(\?|#|$)", u):
        return "direct_file"
    return "unknown"


def _gdrive_id(url: str) -> str | None:
    for pat in _GDRIVE_ID_PATTERNS:
        m = pat.search(url)
        if m:
            return m.group(1)
    return None


def resolve_download_url(url: str) -> dict[str, Any]:
    """Return ``{provider, download_url}`` for a share link.

    * Google Drive : ``/file/d/{id}/view`` -> ``uc?export=download&id={id}``
    * Dropbox      : ``?dl=0`` -> ``?dl=1`` (or append ``?dl=1``)
    * OneDrive / SharePoint : returned unchanged (redirect resolved at fetch)
    * Direct file / unknown : returned unchanged
    """
    provider = detect_provider(url)
    download_url = url

    if provider == "google_drive":
        file_id = _gdrive_id(url)
        if file_id:
            download_url = f"https://drive.google.com/uc?export=download&id={file_id}"
    elif provider == "dropbox":
        if "dl=0" in url:
            download_url = url.replace("dl=0", "dl=1")
        elif "dl=1" not in url:
            sep = "&" if "?" in url else "?"
            download_url = f"{url}{sep}dl=1"
    elif provider in ("sharepoint", "onedrive"):
        # Appending download=1 forces a direct file response on share links.
        if "download=1" not in url:
            sep = "&" if "?" in url else "?"
            download_url = f"{url}{sep}download=1"
    # direct_file / unknown: unchanged

    return {"provider": provider, "download_url": download_url}
