"""NeuLeap HR Platform — Layer 1 Mail Intake (MinIO-backed).

Layer 1 reads recruiter emails (Microsoft Graph) and uploads, classifies what
each contains, validates resume files, stores the clean ones, and builds the
``email_master`` table.

Storage is **MinIO only** (see :mod:`app.services.mail_storage`):

* ``raw/temp/{E_id}/``                  staged intake items + ``{E_id}.json`` manifest
* ``raw/{YYYY}/{MM}/{DD}/{E_id}/``      final clean files (the Layer-2 handoff)

Each item is processed in an ephemeral OS temp dir (deleted per run); no durable
local filesystem is used.

Orchestration is done with LangGraph (see :mod:`app.pipeline.mail.graph`); the
side effects live in small deterministic services (see
:mod:`app.pipeline.mail.tools`) that the nodes call directly. There is no tool
registry and no MCP layer.
"""

from __future__ import annotations

__version__ = "1.0.0"
__all__ = ["__version__"]
