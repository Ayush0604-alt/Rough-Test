"""Local-mode link fetcher (Workflow A, Step 3-6).

In local test mode there is **no network**. This fetcher only resolves links
that point at files already available locally, which keeps the whole pipeline
offline while still exercising the link → download → validate → store path.

Supported local link forms (so fixtures/tests can drive Workflow A & C):

* ``file:///abs/path/resume.pdf``        — absolute local path
* ``local://resume.pdf``                 — basename looked up in inbox/processing
* ``https://.../<name>.pdf``             — basename looked up locally; only the
                                           filename is used, never the network

Any link whose target cannot be found locally returns ``success=False`` with
``reason="network_disabled_local_mode"`` — the caller marks the row/link for
manual review and continues.
"""

from __future__ import annotations

import os
import re
import shutil
from pathlib import Path
from typing import Any
from urllib.parse import unquote, urlparse

from app.logging_config import get_logger
from app.mail_config import ACCEPTED_INPUT_TYPES, Settings
from app.pipeline.mail.link_resolver import resolve_download_url

log = get_logger(__name__)

# Real network fetches are enabled by default for the agent flow; set
# NEULEAP_ALLOW_NETWORK=0 to force pure-local resolution (offline test mode).
def _network_allowed() -> bool:
    return os.environ.get("NEULEAP_ALLOW_NETWORK", "1") != "0"


_CONTENT_TYPE_EXT = {
    "application/pdf": ".pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": ".xlsx",
    "application/zip": ".zip",
    "application/x-zip-compressed": ".zip",
    "image/png": ".png",
    "image/jpeg": ".jpg",
}


def _filename_from_headers(resp, url: str, content_ext: str) -> str:
    """Pick a safe filename from Content-Disposition, URL, or content-type."""
    cd = resp.headers.get("content-disposition", "")
    m = re.search(r'filename\*?=(?:UTF-8\'\')?"?([^"\;]+)"?', cd, re.IGNORECASE)
    if m:
        return Path(unquote(m.group(1))).name
    url_name = Path(unquote(urlparse(url).path)).name
    if url_name and Path(url_name).suffix.lower() in ACCEPTED_INPUT_TYPES:
        return url_name
    stem = url_name or "download"
    return f"{Path(stem).stem or 'download'}{content_ext or ''}"


def _gdrive_confirm_retry(session, resp) -> "Any | None":
    """Google Drive serves an HTML interstitial for non-trivial files instead of
    the bytes. Resolve it to the real download and return the follow-up response.

    Two interstitial forms are handled:
    * Legacy: a ``download_warning`` cookie + an ``&confirm=<token>`` link.
    * Current: a ``<form id="download-form" action="https://drive.usercontent…">``
      with hidden ``id``/``export``/``confirm``/``uuid`` inputs.
    Returns ``None`` if no confirmable interstitial was found.
    """
    from urllib.parse import urlencode

    html = resp.text

    # Current form-based interstitial: rebuild the action URL from hidden inputs.
    form = re.search(r'<form[^>]+id="download-form"[^>]+action="([^"]+)"', html)
    if form:
        action = form.group(1).replace("&amp;", "&")
        fields = dict(re.findall(r'name="([^"]+)"\s+value="([^"]*)"', html))
        if fields:
            target = f"{action}?{urlencode(fields)}"
            return session.get(target, allow_redirects=True, timeout=120, stream=False)

    # Legacy cookie-based confirm token.
    token = next((v for k, v in session.cookies.items()
                  if k.startswith("download_warning")), None)
    if not token:
        m = re.search(r'confirm=([0-9A-Za-z_-]+)', html)
        token = m.group(1) if m else None
    if token:
        sep = "&" if "?" in resp.url else "?"
        return session.get(f"{resp.url}{sep}confirm={token}",
                           allow_redirects=True, timeout=120)
    return None


def _http_download(url: str, dest_dir: str) -> dict[str, Any]:
    """Resolve + fetch an http(s) link over the network. Returns a result dict."""
    import requests

    resolved = resolve_download_url(url)
    target_url = resolved["download_url"]
    provider = resolved["provider"]
    # A session carries the cookies Google Drive sets on its interstitial page.
    session = requests.Session()
    session.headers.update({"User-Agent": "Mozilla/5.0 (NeuLeap resume intake)"})
    try:
        resp = session.get(target_url, allow_redirects=True, timeout=60)
    except Exception as exc:  # noqa: BLE001
        # Network/timeout errors are transient — tagged so download_link retries.
        return {"success": False, "provider": provider, "reason": f"http_error:{exc}"}
    if resp.status_code != 200 or not resp.content:
        return {"success": False, "provider": provider,
                "reason": f"http_status:{resp.status_code}"}
    ctype = resp.headers.get("content-type", "").split(";")[0].strip().lower()

    # An HTML body on a file link means an interstitial/landing page, not the
    # file. For Google Drive this is the "confirm download" gate — resolve it.
    if ctype.startswith("text/html"):
        # Google flags some uploads as malware and HARD-blocks the download
        # (no download-anyway form) — a permanent failure a retry can't fix,
        # surfaced with a clear reason so manual review shows WHY.
        if provider == "google_drive" and "Infected file" in resp.text[:2000]:
            return {"success": False, "provider": provider,
                    "reason": "google_infected_file"}
        if provider == "google_drive":
            followup = _gdrive_confirm_retry(session, resp)
            if followup is not None and followup.status_code == 200 and followup.content:
                resp = followup
                ctype = resp.headers.get("content-type", "").split(";")[0].strip().lower()
        if ctype.startswith("text/html"):
            return {"success": False, "provider": provider,
                    "reason": "auth_or_html_response"}

    content_ext = _CONTENT_TYPE_EXT.get(ctype, "")
    name = _filename_from_headers(resp, url, content_ext)
    ext = Path(name).suffix.lower()
    if ext not in ACCEPTED_INPUT_TYPES:
        return {"success": False, "provider": provider,
                "reason": f"unsupported_type:{ext or ctype}"}

    dest = Path(dest_dir)
    dest.mkdir(parents=True, exist_ok=True)
    out = dest / name
    out.write_bytes(resp.content)
    log.info("download(http): %s -> %s (%d bytes)", target_url[:70], out.name, len(resp.content))
    return {"success": True, "file_path": str(out.resolve()),
            "file_type": ext.lstrip("."), "provider": provider, "reason": ""}


def _graph_shares_download(url: str, dest_dir: str) -> "dict[str, Any] | None":
    """Download a SharePoint/OneDrive share link via the Microsoft Graph Shares API.

    Org share links (``…sharepoint.com/:w:/g/personal/…``, ``1drv.ms``) are not
    anonymously downloadable, but Graph can resolve them with the app token:
    encode the URL as a sharing id and GET ``/shares/{id}/driveItem/content``.

    Returns a result dict, or ``None`` when Graph isn't configured (so the caller
    falls back to a plain HTTP fetch). Requires the app to hold ``Files.Read.All``
    (or ``Sites.Read.All``); without it Graph returns 403 → a clean failure here.
    """
    import base64

    import requests

    from app.services import graph_client

    if not graph_client.is_configured():
        return None
    try:
        token = graph_client._token()
    except Exception as exc:  # noqa: BLE001 — auth failure ⇒ let caller fall back
        log.warning("graph shares: token failed (%s)", exc)
        return None

    enc = "u!" + base64.urlsafe_b64encode(url.encode("utf-8")).decode("ascii").rstrip("=")
    item = f"https://graph.microsoft.com/v1.0/shares/{enc}/driveItem"
    headers = {"Authorization": f"Bearer {token}"}
    try:
        meta = requests.get(f"{item}?$select=name,size,file", headers=headers, timeout=60)
        if meta.status_code != 200:
            return {"success": False, "provider": "graph_shares",
                    "reason": f"graph_shares_meta:{meta.status_code}"}
        name = Path(meta.json().get("name") or "download").name
        ext = Path(name).suffix.lower()
        if ext not in ACCEPTED_INPUT_TYPES:
            return {"success": False, "provider": "graph_shares",
                    "reason": f"unsupported_type:{ext}"}
        content = requests.get(f"{item}/content", headers=headers, timeout=120,
                               allow_redirects=True)
        if content.status_code != 200 or not content.content:
            return {"success": False, "provider": "graph_shares",
                    "reason": f"graph_shares_content:{content.status_code}"}
        dest = Path(dest_dir)
        dest.mkdir(parents=True, exist_ok=True)
        out = dest / name
        out.write_bytes(content.content)
        log.info("download(graph_shares): %s -> %s (%d bytes)",
                 url[:70], name, len(content.content))
        return {"success": True, "file_path": str(out.resolve()),
                "file_type": ext.lstrip("."), "provider": "graph_shares", "reason": ""}
    except Exception as exc:  # noqa: BLE001 — never let a fetch error crash the run
        return {"success": False, "provider": "graph_shares",
                "reason": f"graph_shares_error:{exc}"}


def _load_link_map(settings: Settings) -> dict[str, str]:
    """Load the optional local link map (URL -> local filename in inbox/links/).

    This lets opaque share links (SharePoint/OneDrive) resolve to a local
    stand-in file in test mode, where no network fetch is possible.
    """
    import json

    map_path = settings.inbox_dir / "_link_map.json"
    if not map_path.exists():
        return {}
    try:
        data = json.loads(map_path.read_text(encoding="utf-8"))
        return {str(k): str(v) for k, v in data.items()}
    except (OSError, json.JSONDecodeError, AttributeError):
        return {}


def _candidate_local_paths(settings: Settings, url: str, item_eid: str | None) -> list[Path]:
    """Enumerate local paths a link might resolve to (longest-shot last)."""
    paths: list[Path] = []

    # 1) Explicit link map wins (handles opaque SharePoint/OneDrive URLs).
    mapped = _load_link_map(settings).get(url)
    if mapped:
        paths.append(settings.inbox_dir / "links" / mapped)
        paths.append(settings.inbox_dir / mapped)

    parsed = urlparse(url)

    if parsed.scheme == "file":
        # file:///C:/x -> strip leading slash on Windows drive paths
        raw = unquote(parsed.path)
        if raw.startswith("/") and len(raw) > 3 and raw[2] == ":":
            raw = raw[1:]
        paths.append(Path(raw))
    elif parsed.scheme == "local":
        name = (parsed.netloc + parsed.path).lstrip("/")
        paths.append(settings.inbox_dir / "links" / name)
        paths.append(settings.inbox_dir / name)
        if item_eid:
            paths.append(settings.processing_dir / item_eid / name)
    else:
        # Use only the basename of any other URL; look it up locally.
        name = Path(unquote(parsed.path)).name
        if name:
            paths.append(settings.inbox_dir / "links" / name)
            paths.append(settings.inbox_dir / name)
            if item_eid:
                paths.append(settings.processing_dir / item_eid / name)
    return paths


# Failure reasons a retry can't fix — permanent, so we stop immediately.
_PERMANENT_REASONS = ("google_infected_file", "unsupported_type", "auth_or_html_response")
_MAX_HTTP_ATTEMPTS = 3


def _is_retryable(reason: str) -> bool:
    if any(reason.startswith(p) for p in _PERMANENT_REASONS):
        return False
    if reason.startswith("http_status:"):
        # 4xx (except 429) are client errors a retry won't fix; 5xx + 429 are transient.
        code = reason.split(":", 1)[1].strip()
        return code in ("429", "500", "502", "503", "504")
    # http_error:* (network/timeout) and anything else → worth another try.
    return True


def _http_download_with_retry(url: str, dest_dir: str) -> dict[str, Any]:
    """`_http_download` with up to ``_MAX_HTTP_ATTEMPTS`` tries on TRANSIENT
    failures, backing off between attempts so a rate-limited host (Google
    Drive throttling a large batch) gets a moment to recover."""
    import time

    last = {"success": False, "reason": "no_attempt"}
    for attempt in range(1, _MAX_HTTP_ATTEMPTS + 1):
        last = _http_download(url, dest_dir)
        if last["success"] or not _is_retryable(last.get("reason", "")):
            return last
        if attempt < _MAX_HTTP_ATTEMPTS:
            backoff = 1.5 * attempt  # 1.5s, 3.0s
            log.info(
                "download(http) attempt %d/%d failed (%s) — retrying in %.1fs: %s",
                attempt, _MAX_HTTP_ATTEMPTS, last.get("reason"), backoff, url[:70],
            )
            try:
                time.sleep(backoff)
            except Exception:  # noqa: BLE001
                pass
    return last


def download_link(
    settings: Settings, url: str, dest_dir: str, item_eid: str | None = None
) -> dict[str, Any]:
    """Resolve + 'download' a link in local-only mode.

    Returns ``{success, file_path, file_type, provider, reason}``.
    """
    resolved = resolve_download_url(url)
    provider = resolved["provider"]
    parsed = urlparse(url)

    # 1) Real network fetch for http(s) links (unless disabled).
    if parsed.scheme in ("http", "https") and _network_allowed():
        # SharePoint/OneDrive org links aren't anonymously downloadable — resolve them
        # with the Graph app token first, then fall back to a plain HTTP fetch.
        if provider in ("sharepoint", "onedrive"):
            shares = _graph_shares_download(url, dest_dir)
            if shares is not None:
                if shares["success"]:
                    return {**shares}
                log.warning("graph shares download failed (%s); trying http", shares["reason"])
        # Retry TRANSIENT failures (network blips, timeouts, 5xx, and Drive
        # rate-limiting — a 65-row sheet hammers Drive fast enough to get
        # throttled). Permanent failures (infected file, unsupported type,
        # auth wall) are NOT retried — a retry can't fix them, and hammering
        # only makes throttling worse.
        http = _http_download_with_retry(url, dest_dir)
        if http["success"]:
            return {**http}
        log.warning("http download failed (%s); trying local fallback", http["reason"])

    # 2) Local resolution (file://, local://, link map, basename lookup).
    source: Path | None = None
    for candidate in _candidate_local_paths(settings, url, item_eid):
        if candidate.exists() and candidate.is_file():
            source = candidate
            break

    if source is None:
        reason = "download_failed" if _network_allowed() else "network_disabled_local_mode"
        return {
            "success": False,
            "file_path": None,
            "file_type": None,
            "provider": provider,
            "reason": reason,
        }

    ext = source.suffix.lower()
    if ext not in ACCEPTED_INPUT_TYPES:
        return {
            "success": False,
            "file_path": None,
            "file_type": ext.lstrip("."),
            "provider": provider,
            "reason": f"unsupported_type:{ext}",
        }

    dest = Path(dest_dir)
    dest.mkdir(parents=True, exist_ok=True)
    out = dest / source.name
    shutil.copy2(str(source), str(out))
    log.info("download(local): %s -> %s", url, out.name)
    return {
        "success": True,
        "file_path": str(out.resolve()),
        "file_type": ext.lstrip("."),
        "provider": provider,
        "reason": "",
    }
