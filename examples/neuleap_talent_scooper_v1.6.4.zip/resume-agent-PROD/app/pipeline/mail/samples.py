"""Generate real sample fixtures for local testing.

Builds genuinely valid (and intentionally corrupt) files using the same
libraries the validators use, plus JSON manifests, covering every path:
attachment / links / mixed / none, zip, excel, dedup, corrupt, manual-review.

Used by both the ``--seed-samples`` runner flag and the unit tests.
"""

from __future__ import annotations

import json
import zipfile
from pathlib import Path

from app.mail_config import Settings

# --- low-level file builders (reusable by tests) ---------------------------


def make_pdf(path: Path, text: str = "Resume content for testing.") -> Path:
    import fitz

    doc = fitz.open()
    page = doc.new_page()
    page.insert_text((72, 72), text)
    doc.save(str(path))
    doc.close()
    return path


def make_docx(path: Path, text: str = "Resume content for testing.") -> Path:
    import docx

    document = docx.Document()
    document.add_paragraph(text)
    document.save(str(path))
    return path


def make_png(path: Path, size: tuple[int, int] = (120, 90)) -> Path:
    from PIL import Image

    Image.new("RGB", size, color=(20, 90, 160)).save(str(path), "PNG")
    return path


def make_jpg(path: Path, size: tuple[int, int] = (100, 100)) -> Path:
    from PIL import Image

    Image.new("RGB", size, color=(200, 120, 40)).save(str(path), "JPEG")
    return path


def make_corrupt_pdf(path: Path) -> Path:
    path.write_bytes(b"%PDF-1.4 this is not really a pdf body \x00\x01garbage")
    return path


def make_zip(path: Path, valid: int = 2, include_junk: bool = True) -> Path:
    """Create a ZIP with `valid` good PDFs, optional junk + a nested zip."""
    tmp = path.parent / "_ziptmp"
    tmp.mkdir(parents=True, exist_ok=True)
    members: list[Path] = []
    for i in range(valid):
        p = tmp / f"resume_{i + 1}.pdf"
        make_pdf(p, f"Resume {i + 1}")
        members.append(p)
    if include_junk:
        junk = tmp / "notes.txt"
        junk.write_text("not a resume", encoding="utf-8")
        members.append(junk)
        nested = tmp / "inner.zip"
        with zipfile.ZipFile(nested, "w") as zf:
            zf.writestr("x.pdf", "nope")
        members.append(nested)
    with zipfile.ZipFile(path, "w") as zf:
        for m in members:
            zf.write(m, arcname=m.name)
    for m in members:
        m.unlink()
    tmp.rmdir()
    return path


def make_excel(path: Path, links: list[str | None]) -> Path:
    """Create an XLSX with name/email/phone/resume_link columns."""
    import openpyxl

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.append(["name", "email", "phone", "resume_link"])
    for i, link in enumerate(links):
        ws.append([f"Cand {i + 1}", f"c{i+1}@ex.com", f"555000{i}", link or ""])
    wb.save(str(path))
    return path


def _manifest(inbox: Path, name: str, payload: dict) -> None:
    (inbox / name).write_text(json.dumps(payload, indent=2), encoding="utf-8")


# --- the full sample set ---------------------------------------------------


def seed_samples(settings: Settings) -> None:
    """Populate local/inbox/ with a representative spread of test items."""
    settings.ensure_folders()
    inbox = settings.inbox_dir
    # Link targets live here so they are NOT treated as loose inbox emails;
    # the local-mode downloader resolves links against this folder.
    links_dir = inbox / "links"
    links_dir.mkdir(parents=True, exist_ok=True)

    # E1: valid PDF attachment -> Success
    make_pdf(inbox / "john_resume.pdf", "John Doe — Senior Engineer")
    _manifest(inbox, "email_pdf.json", {
        "sender_mail_id": "recruiter@example.com",
        "subject": "Resume for John",
        "received_date": "2026-06-13",
        "attachments": ["john_resume.pdf"],
        "links": [],
        "body": "Please find the resume attached.",
    })

    # E2: valid DOCX + valid PNG (two attachments) -> Success
    make_docx(inbox / "jane_cv.docx", "Jane Roe — Designer")
    make_png(inbox / "portfolio.png")
    _manifest(inbox, "email_multi.json", {
        "sender_mail_id": "hr@studio.io",
        "subject": "Jane application",
        "received_date": "2026-06-12",
        "attachments": ["jane_cv.docx", "portfolio.png"],
        "links": [],
        "body": "CV and a portfolio image attached.",
    })

    # E3: one valid PDF + one corrupt PDF -> Partial(1/2)
    make_pdf(inbox / "ok_resume.pdf", "Valid")
    make_corrupt_pdf(inbox / "broken_resume.pdf")
    _manifest(inbox, "email_partial.json", {
        "sender_mail_id": "agency@talent.co",
        "subject": "Two resumes",
        "received_date": "2026-06-11",
        "attachments": ["ok_resume.pdf", "broken_resume.pdf"],
        "links": [],
        "body": "Two candidates attached.",
    })

    # E4: ZIP with 2 valid PDFs + junk + nested zip -> Success(2 files)
    make_zip(inbox / "batch.zip", valid=2, include_junk=True)
    _manifest(inbox, "email_zip.json", {
        "sender_mail_id": "bulk@agency.com",
        "subject": "Batch resumes",
        "received_date": "2026-06-10",
        "attachments": ["batch.zip"],
        "links": [],
        "body": "Batch of resumes zipped.",
    })

    # E5: Excel with 3 rows; one row has no link -> Partial(2/3 rows).
    # Two rows resolve to the SAME local file to exercise safe dedup-rename in
    # raw/ (cand_a.pdf -> cand_a_2.pdf). Links use local:// for offline resolve.
    make_pdf(links_dir / "cand_a.pdf", "Candidate A")
    make_excel(inbox / "candidates.xlsx",
               links=["local://cand_a.pdf", "local://cand_a.pdf", None])
    _manifest(inbox, "email_excel.json", {
        "sender_mail_id": "sheet@vendor.com",
        "subject": "Candidate sheet",
        "received_date": "2026-06-09",
        "attachments": ["candidates.xlsx"],
        "links": [],
        "body": "Spreadsheet of candidate resume links.",
    })

    # E6: link-only email; link resolves to a local file -> Success
    make_docx(links_dir / "linked_resume.docx", "Linked candidate")
    _manifest(inbox, "email_link.json", {
        "sender_mail_id": "ref@portal.com",
        "subject": "Resume link",
        "received_date": "2026-06-08",
        "attachments": [],
        "links": ["local://linked_resume.docx"],
        "body": "Resume available via link.",
    })

    # E7: no attachment, no usable link -> None -> Discarded
    _manifest(inbox, "email_none.json", {
        "sender_mail_id": "spam@nowhere.com",
        "subject": "Just saying hello",
        "received_date": "2026-06-07",
        "attachments": [],
        "links": [],
        "body": "Hi, no resume here. Visit our homepage https://example.com",
    })
