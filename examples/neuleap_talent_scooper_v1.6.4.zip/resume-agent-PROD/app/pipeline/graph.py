"""LangGraph state machine for L2.

  fetch_email_files → pick_next_file → validate_integrity →
  validate_resume_identity → fuzzy_dedup → (hash_check) →
  store_clean_resume → write_candidate_master → (loop) → finalize_email
"""
from __future__ import annotations

from typing import Literal

from langgraph.graph import END, StateGraph

from app.models.state import L2State
from app.pipeline.nodes.dedup import fuzzy_dedup, hash_check
from app.pipeline.nodes.drop import drop_file
from app.pipeline.nodes.fetch import fetch_email_files
from app.pipeline.nodes.finalize import finalize_email
from app.pipeline.nodes.flag import flag_recruiter
from app.pipeline.nodes.pick import pick_next_file
from app.pipeline.nodes.store import store_clean_resume, write_candidate_master
from app.pipeline.nodes.validate import validate_integrity, validate_resume_identity

# ── Conditional edge routers ──────────────────────────────────────────────────

def _after_pick(state: L2State) -> Literal["validate_integrity", "finalize_email"]:
    return "validate_integrity" if state["current_file"] else "finalize_email"


def _after_integrity(state: L2State) -> Literal["validate_resume_identity", "drop_file"]:
    return "validate_resume_identity" if state["integrity_ok"] else "drop_file"


def _after_identity(state: L2State) -> Literal["fuzzy_dedup", "drop_file"]:
    return "fuzzy_dedup" if state["is_resume"] else "drop_file"


def _after_fuzzy(state: L2State) -> Literal["store_clean_resume", "hash_check", "drop_file"]:
    match = state["fuzzy_match_row"]
    if not match:
        return "store_clean_resume"
    if match.get("status") == "Hired":
        return "drop_file"
    return "hash_check"


def _after_hash(state: L2State) -> Literal["drop_file", "flag_recruiter"]:
    # Exact same file re-sent → duplicate, drop. ANY different resume from a known
    # candidate (whether or not they've been screened) is a re-application: flag it for
    # recruiter review instead of silently overwriting the record.
    if state["hash_match"]:
        return "drop_file"
    return "flag_recruiter"


def _loop_or_end(state: L2State) -> Literal["pick_next_file", "finalize_email"]:
    return "pick_next_file" if state["files_to_process"] else "finalize_email"


# ── Graph builder ─────────────────────────────────────────────────────────────

def build_l2_graph():
    g = StateGraph(L2State)

    g.add_node("fetch_email_files",        fetch_email_files)
    g.add_node("pick_next_file",           pick_next_file)
    g.add_node("validate_integrity",       validate_integrity)
    g.add_node("validate_resume_identity", validate_resume_identity)
    g.add_node("fuzzy_dedup",              fuzzy_dedup)
    g.add_node("hash_check",               hash_check)
    g.add_node("store_clean_resume",       store_clean_resume)
    g.add_node("write_candidate_master",   write_candidate_master)
    g.add_node("flag_recruiter",           flag_recruiter)
    g.add_node("drop_file",                drop_file)
    g.add_node("finalize_email",           finalize_email)

    g.set_entry_point("fetch_email_files")

    g.add_edge("fetch_email_files", "pick_next_file")
    g.add_edge("store_clean_resume", "write_candidate_master")
    g.add_edge("finalize_email", END)

    g.add_conditional_edges("pick_next_file",           _after_pick,      {
        "validate_integrity": "validate_integrity",
        "finalize_email":     "finalize_email",
    })
    g.add_conditional_edges("validate_integrity",       _after_integrity, {
        "validate_resume_identity": "validate_resume_identity",
        "drop_file":                "drop_file",
    })
    g.add_conditional_edges("validate_resume_identity", _after_identity,  {
        "fuzzy_dedup": "fuzzy_dedup",
        "drop_file":   "drop_file",
    })
    g.add_conditional_edges("fuzzy_dedup",              _after_fuzzy,     {
        "store_clean_resume": "store_clean_resume",
        "hash_check":         "hash_check",
        "drop_file":          "drop_file",
    })
    g.add_conditional_edges("hash_check",               _after_hash,      {
        "drop_file":          "drop_file",
        "flag_recruiter":     "flag_recruiter",
    })
    for node in ("write_candidate_master", "drop_file", "flag_recruiter"):
        g.add_conditional_edges(node, _loop_or_end, {
            "pick_next_file": "pick_next_file",
            "finalize_email": "finalize_email",
        })

    return g.compile()


# Lazy singleton — compiled once, reused across requests
_graph = None


def get_graph():
    global _graph
    if _graph is None:
        _graph = build_l2_graph()
    return _graph
