"""Step 15 — Terminal node. Logs a per-email summary.

This service does not write back to email_master (read-only, owned upstream)
and does not keep an audit log, so finalize is purely a summary/logging step.
"""
from __future__ import annotations

import logging

from app.models.state import L2State

logger = logging.getLogger(__name__)


def finalize_email(state: L2State) -> L2State:
    outcomes = state["file_outcomes"]
    failed = [o for o in outcomes if o["status"] not in ("PASS", "REAPPLICATION")]
    passed = len(outcomes) - len(failed)
    folder_status = "Processed" if not failed else "Processing"

    logger.info(
        "[L2] e_id=%s finalized — PASS=%d FAIL=%d folder=%s",
        state["e_id"], passed, len(failed), folder_status,
    )
    # No state changes — terminal node.
    return {}
