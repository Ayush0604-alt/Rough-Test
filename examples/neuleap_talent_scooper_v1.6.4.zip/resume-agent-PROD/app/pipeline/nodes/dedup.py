"""Step 12 — Two-stage dedup: deterministic contact extraction + fuzzy identity
match, then SHA-256 hash check.

The contact tuple (name/email/phone) is extracted deterministically (regex, no
LLM) and stashed into state so write_candidate_master can persist it onto the
stub. L3's LLM later overwrites these on a successful parse.
"""
from __future__ import annotations

import hashlib
import logging
import re
from typing import Optional

from rapidfuzz import fuzz

from app.config import settings
from app.models.state import L2State
from app.repositories import repo
from app.services.s3 import s3

logger = logging.getLogger(__name__)

_EMAIL_RE = re.compile(r"[\w.+-]+@[\w-]+\.[a-zA-Z]{2,}")
# Tolerant phone candidate: an optional +91/0 prefix then a 10+ digit run that may
# carry spaces/hyphens/dots between digits (e.g. "98765 43210", "+91-98765-43210").
# Each candidate is normalized to its last 10 digits and validated below.
_PHONE_RE = re.compile(r"(?:\+?91[\s.-]?|0)?[6-9][\d\s.-]{8,}\d")

# A near-identical name (token_sort_ratio ≥ this) counts as a STRONG signal: it can
# merge on a single corroborating contact match (email OR phone), below the usual
# 2-of-3 bar. Still never merges on name alone — guards against two distinct people
# who happen to share a common name.
_STRONG_NAME = 95


def _norm_email(value: str | None) -> str:
    """Trim + lowercase so formatting/case differences don't defeat an exact compare."""
    return (value or "").strip().lower()


def _norm_phone(value: str | None) -> str:
    """Digits-only, last 10 — drops +91/0 prefixes and separators. '' if < 10 digits.

    Makes the phone compare robust to formatting ("+91 98765 43210", "098765-43210",
    "98765 43210" all → "9876543210"), the dominant reason duplicate resumes used to
    slip through as new candidates.
    """
    digits = re.sub(r"\D", "", value or "")
    return digits[-10:] if len(digits) >= 10 else ""

_HEADER_WORDS = {
    "resume", "curriculum vitae", "cv", "bio data", "biodata", "profile",
    "personal profile", "personal details",
}


# ── Deterministic contact extraction ──────────────────────────────────────────

def _guess_name(lines: list[str]) -> str:
    """First plausible name line: 1-4 alphabetic tokens, no digits/@, not a header."""
    for line in lines[:8]:
        low = line.lower()
        if not line or "@" in line or any(ch.isdigit() for ch in line):
            continue
        if low in _HEADER_WORDS:
            continue
        tokens = line.split()
        if 1 <= len(tokens) <= 4 and all(
            t.replace(".", "").replace("-", "").replace("'", "").isalpha() for t in tokens
        ):
            return line
    return lines[0] if lines else ""


def _extract_phone(text: str) -> str:
    """First text run that normalizes to a valid 10-digit Indian mobile (starts 6–9)."""
    for m in _PHONE_RE.finditer(text or ""):
        norm = _norm_phone(m.group())
        if norm and norm[0] in "6789":
            return norm
    return ""


def _extract_contact(text: str) -> tuple[str, str, str]:
    """Return (name_guess, email, phone) from extracted text — regex only.

    email/phone are returned NORMALIZED (lowercased email, digits-only 10-char phone)
    so the stub persists a canonical contact and the dedup compare is format-agnostic.
    """
    email_m = _EMAIL_RE.search(text)
    email = _norm_email(email_m.group()) if email_m else ""
    phone = _extract_phone(text)
    lines = [line.strip() for line in text.split("\n") if line.strip()]
    return _guess_name(lines), email, phone


# ── Stage 1: fuzzy identity ───────────────────────────────────────────────────

def _find_fuzzy_match(name: str, email: str, phone: str, *, source: Optional[str] = None) -> Optional[dict]:
    # Runtime FUZZY_THRESHOLD (Settings page) wins; else the startup default.
    from app.services import pipeline_config

    threshold = pipeline_config.dedup_threshold() or settings.fuzzy_threshold
    # Incoming contact is already normalized by _extract_contact; normalize the STORED
    # side too (it may hold an L3-LLM value in a different format) so the compare is
    # format-agnostic on both sides.
    n_email = _norm_email(email)
    n_phone = _norm_phone(phone)
    # `source` is only passed when the caller already confirmed (via
    # app.services.source_tags.dup_check_scoped_for) that this source has
    # opted into narrower checking — default behavior (source=None) is the
    # existing system-wide compare across every candidate.
    scoped_source = (source or "").strip() if source else None
    for row in repo().get_all_candidates():
        if scoped_source and (row.get("source") or "").strip() != scoped_source:
            continue
        name_score  = fuzz.token_sort_ratio(name, row.get("name") or "")
        name_match  = name_score >= threshold
        email_match = bool(n_email) and n_email == _norm_email(row.get("email"))
        phone_match = bool(n_phone) and n_phone == _norm_phone(row.get("phno"))
        # Standard rule: any 2 of the 3 identity signals agree.
        if sum([name_match, email_match, phone_match]) >= 2:
            return row
        # Name-strong: a near-identical name + ONE corroborating contact match merges
        # even if the basic name threshold is configured above _STRONG_NAME. Never
        # merges on a name match alone.
        if name_score >= _STRONG_NAME and (email_match or phone_match):
            return row
    return None


def fuzzy_dedup(state: L2State) -> L2State:
    from app.services import source_tags

    name, email, phone = _extract_contact(state["extracted_text"])
    # The intake source isn't in L2State — it's on this file's email row (same
    # place write_candidate_master later reads it from). A registered source
    # tag can opt into scoping the duplicate check to just its own candidates
    # instead of the system-wide default (app.services.source_tags).
    email_row = repo().get_email(state["e_id"]) if state.get("e_id") else None
    incoming_source = (email_row or {}).get("source")
    scope_source = incoming_source if source_tags.dup_check_scoped_for(incoming_source) else None
    match = _find_fuzzy_match(name, email, phone, source=scope_source)
    logger.info(
        "[L2] Fuzzy dedup — match: %s%s",
        f"YES ({match['candidate_id']})" if match else "NO",
        f" (scoped to source={scope_source!r})" if scope_source else "",
    )
    return {
        "fuzzy_match_row": match,
        "cand_name": name,
        "cand_email": email,
        "cand_phno": phone,
    }


# ── Stage 2: SHA-256 hash ─────────────────────────────────────────────────────

def hash_check(state: L2State) -> L2State:
    incoming_hash = hashlib.sha256(state["file_bytes"]).hexdigest()
    match = state["fuzzy_match_row"]

    # Prefer the stored file_hash column (written by L2 at intake) — no S3 round-trip.
    # Older rows have no hash yet ("going forward only"): fall back to reading the file.
    stored_hash = match.get("file_hash")
    if stored_hash:
        same = incoming_hash == stored_hash
    else:
        try:
            stored_bytes = s3().get_bytes(match["s3_file_path"])
            same = incoming_hash == hashlib.sha256(stored_bytes).hexdigest()
        except Exception:  # noqa: BLE001 - cannot read stored file ⇒ treat as different (accept update)
            same = False

    has_rounds = bool(
        state["fuzzy_match_row"].get("roundid") and
        str(state["fuzzy_match_row"]["roundid"]) not in ("", "None")
    )
    logger.info("[L2] Hash check — same=%s  post_screening=%s", same, has_rounds)
    return {"hash_match": same, "is_post_screening": has_rounds}
