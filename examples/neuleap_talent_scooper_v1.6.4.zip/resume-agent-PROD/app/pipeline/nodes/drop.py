"""Drop a file — determine reason from state, record outcome. Raw file kept in S3."""
from __future__ import annotations

import logging

from app.models.state import L2State

logger = logging.getLogger(__name__)

_REASON_MAP = {
    "corrupt":     ("CORRUPT",   "resume_corrupt: cannot open"),
    "not_resume":  ("NOT_RESUME","not_a_resume: no contact or work section"),
    "dup_hired":   ("DUP_HIRED", "DUP_HIRED: candidate already hired"),
    "dup":         ("DUP",       "DUP: hash match — same resume re-sent"),
}


def drop_file(state: L2State) -> L2State:
    match = state["fuzzy_match_row"]

    if not state["integrity_ok"]:
        key = "corrupt"
    elif not state["is_resume"]:
        key = "not_resume"
    elif match and match.get("status") == "Hired":
        key = "dup_hired"
    else:
        key = "dup"

    status, fail_reason = _REASON_MAP[key]
    # Prefer a specific not-a-resume reason from validate (e.g. ">3 pages") over the
    # generic default, so the review queue shows WHY it was rejected.
    if key == "not_resume" and state.get("not_resume_reason"):
        fail_reason = state["not_resume_reason"]
    logger.info("[L2] DROP %s: %s", status, state["current_file"])

    # Note: these drops are already recorded in audit_log by the orchestrator's
    # write_stage_events (status='Failed'), which is what the review queue reads.
    return {
        "drop_reason": status,
        "file_outcomes": [{
            "filename": state["current_file"].rsplit("/", 1)[-1],
            "status": status,
            "candidate_id": match["candidate_id"] if match else None,
            "fail_reason": fail_reason,
            # The raw-bucket key of the dropped file is retained so the review
            # queue can store an exact raw_s3_key (for View / Approve).
            "s3_key": state["current_file"],
        }],
    }
