"""Step 10 — List files from S3:raw for this email."""
from __future__ import annotations

import logging

from app.models.state import L2State
from app.services.s3 import s3

logger = logging.getLogger(__name__)


def fetch_email_files(state: L2State) -> L2State:
    prefix = s3().raw_prefix(state["e_id"], state["run_date"])
    keys = s3().list_keys(prefix, raw=True)   # source = `raw` bucket (L1 output)
    logger.info("[L2] e_id=%s  found %d file(s) in %s", state["e_id"], len(keys), prefix)
    # Return only changed keys — file_outcomes uses an append-reducer, so
    # re-emitting it (or spreading {**state}) would duplicate accumulated items.
    return {"files_to_process": keys}
