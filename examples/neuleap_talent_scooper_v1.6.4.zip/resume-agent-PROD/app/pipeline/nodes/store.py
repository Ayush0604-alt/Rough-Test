"""Steps 13 + 14 — Copy resume to S3:resume and write the candidate_master stub.

The stub persists the deterministic contact fields (name/email/phno) extracted
in fuzzy_dedup; L3 later completes the row.
"""
from __future__ import annotations

import hashlib
import logging

from app.models.state import L2State
from app.repositories import repo
from app.services.s3 import s3

logger = logging.getLogger(__name__)


def store_clean_resume(state: L2State) -> L2State:
    """Step 13 — Copy file from S3:raw -> S3:resume. Generate candidate_id if new."""
    match = state["fuzzy_match_row"]
    cid = match["candidate_id"] if match else repo().get_next_candidate_id()

    filename = state["current_file"].rsplit("/", 1)[-1]
    clean_key = s3().clean_prefix(cid, state["run_date"]) + filename

    s3().copy(state["current_file"], clean_key)
    logger.info("[L2] Stored clean resume: %s  (candidate_id=%s)", clean_key, cid)

    return {"candidate_id": cid, "s3_clean_path": clean_key}


def write_candidate_master(state: L2State) -> L2State:
    """Step 14 — Insert stub (with deterministic contact) or update existing row."""
    cid = state["candidate_id"]
    match = state["fuzzy_match_row"]

    # SHA-256 of the resume bytes → persisted so the dedup hash_check can compare
    # against this column instead of re-downloading the stored file from S3.
    file_bytes = state.get("file_bytes") or b""
    file_hash = hashlib.sha256(file_bytes).hexdigest() if file_bytes else None
    # L2 text carried forward; L3 reuses it only when complete (see _extract).
    l2_text = state.get("extracted_text") or None
    l2_text_complete = bool(state.get("text_complete"))

    if match and match["candidate_id"] == cid:
        repo().update_candidate_resume(cid, state["s3_clean_path"])
        logger.info("[L2] Updated candidate_master stub: %s", cid)
    else:
        # Carry the recruiter-typed intake source from this candidate's email
        # onto the stub — best-effort, a missing/legacy e_id just leaves it None.
        email_row = repo().get_email(state["e_id"]) if state.get("e_id") else None
        source = (email_row or {}).get("source")
        repo().insert_candidate_stub(
            candidate_id=cid,
            s3_file_path=state["s3_clean_path"],
            mail_send_date=state["mail_send_date"],
            e_id=state["e_id"],
            name=state.get("cand_name", ""),
            email=state.get("cand_email", ""),
            phno=state.get("cand_phno", ""),
            file_hash=file_hash,
            l2_text=l2_text,
            l2_text_complete=l2_text_complete,
            source=source,
        )
        logger.info("[L2] Inserted candidate_master stub: %s", cid)

    # Append exactly one outcome for this file (reducer concatenates).
    return {
        "file_outcomes": [{
            "filename": state["current_file"].rsplit("/", 1)[-1],
            "status": "PASS",
            "candidate_id": cid,
            "fail_reason": None,
        }],
    }
