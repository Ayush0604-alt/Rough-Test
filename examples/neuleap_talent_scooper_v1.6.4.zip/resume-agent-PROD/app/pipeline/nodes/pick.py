"""Pop the next file from the queue and download it. Resets per-file state."""
from __future__ import annotations

import logging

from app.models.state import L2State
from app.services.s3 import s3

logger = logging.getLogger(__name__)

_RESET: dict = {
    "integrity_ok": False,
    "is_resume": False,
    "extracted_text": "",
    "cand_name": "",
    "cand_email": "",
    "cand_phno": "",
    "fuzzy_match_row": None,
    "hash_match": False,
    "is_post_screening": False,
    "candidate_id": None,
    "s3_clean_path": None,
    "drop_reason": None,
}


def pick_next_file(state: L2State) -> L2State:
    remaining = list(state["files_to_process"])
    if not remaining:
        return {"current_file": "", "file_bytes": None, "file_extension": "", **_RESET}

    current = remaining.pop(0)
    file_bytes = s3().get_bytes(current, raw=True)   # raw key from fetch → `raw` bucket
    ext = current.rsplit(".", 1)[-1].lower() if "." in current else ""

    logger.info("[L2] Picked file: %s  (%d bytes)", current, len(file_bytes))

    # Only changed keys (no {**state}) — see fetch.py for why.
    return {
        "files_to_process": remaining,
        "current_file": current,
        "file_bytes": file_bytes,
        "file_extension": ext,
        **_RESET,
    }
