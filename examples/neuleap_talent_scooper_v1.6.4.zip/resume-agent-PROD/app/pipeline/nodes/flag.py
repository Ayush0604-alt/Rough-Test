"""Flag a re-application (known candidate, different resume) for recruiter review."""
from __future__ import annotations

import logging

from app.models.state import L2State
from app.repositories import repo

logger = logging.getLogger(__name__)


def flag_recruiter(state: L2State) -> L2State:
    cid = state["fuzzy_match_row"]["candidate_id"]
    repo().flag_candidate_reapplication(cid, state["current_file"])
    logger.info("[L2] REAPPLICATION flagged: %s", cid)

    return {
        "candidate_id": cid,
        "drop_reason": "REAPPLICATION",
        "file_outcomes": [{
            "filename": state["current_file"].rsplit("/", 1)[-1],
            "status": "REAPPLICATION",
            "candidate_id": cid,
            "fail_reason": "Re-application (same candidate, new resume) — needs review",
            # Raw-bucket key of the NEW resume, so the review queue can store an
            # exact raw_s3_key (drives the "View file" link on the queue item).
            "s3_key": state["current_file"],
        }],
    }
