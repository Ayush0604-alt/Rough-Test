"""Steps 11A + 11B — File integrity and resume identity.

Text is extracted once here and stored in state["extracted_text"] so the dedup
node can reuse it without a second parse.
"""
from __future__ import annotations

import io
import logging
import os
import tempfile
from pathlib import Path

from app.models.state import L2State
from app.services import doc_convert, ocr

logger = logging.getLogger(__name__)

_IMAGE_EXTS = {"jpg", "jpeg", "png"}


# ── Text extraction ───────────────────────────────────────────────────────────

def _docx_text(data: bytes) -> str:
    from docx import Document
    return " ".join(p.text for p in Document(io.BytesIO(data)).paragraphs)


def _extract_doc_text(data: bytes) -> str:
    """Legacy .doc → .docx via LibreOffice, then extract text. '' if unavailable."""
    tmp_dir = Path(tempfile.mkdtemp(prefix="neuleap_l2doc_"))
    src = tmp_dir / "input.doc"
    src.write_bytes(data)
    try:
        converted = doc_convert.convert_to_docx(src)
        if converted is None:
            return ""
        return _docx_text(converted.read_bytes())
    except Exception as exc:  # noqa: BLE001
        logger.warning("[L2] .doc extraction failed: %s", exc)
        return ""


# A resume is at most this many pages; a longer document (brochure, applicant list,
# contract, bundled resumes) is treated as not-a-resume. Configurable; default 3.
_MAX_RESUME_PAGES = int(os.environ.get("MAX_RESUME_PAGES", "3") or "3")


def _office_to_pdf(data: bytes, ext: str):
    """Convert .doc/.docx bytes to a PDF (LibreOffice) for page counting + first-page OCR.

    python-docx cannot paginate, so a true page count needs a render. Returns the PDF
    Path (in a temp dir) or None when LibreOffice is unavailable / conversion failed.
    """
    tmp_dir = Path(tempfile.mkdtemp(prefix="neuleap_l2office_"))
    src = tmp_dir / f"input.{ext}"
    src.write_bytes(data)
    try:
        return doc_convert.convert_to_pdf(src)
    except Exception as exc:  # noqa: BLE001 — conversion is best-effort
        logger.warning("[L2] office→pdf failed: %s", exc)
        return None


def _pdf_page_count_path(path) -> "int | None":
    try:
        import fitz
        with fitz.open(str(path)) as doc:
            return doc.page_count
    except Exception:  # noqa: BLE001
        return None


def _extract(data: bytes, ext: str) -> "tuple[str, bool, int | None]":
    """Return ``(text, text_complete, page_count)``.

    Native text covers ALL pages (cheap). OCR runs on the FIRST PAGE ONLY when the native
    layer is thin (scanned) — enough for the identity + dedup contact block. ``text_complete``
    is True only when the full text was captured WITHOUT partial OCR, so L3 may reuse it;
    otherwise L3 re-extracts with full OCR (it owns field accuracy). ``page_count`` feeds
    the ">N pages ⇒ not a resume" rule (PDF via PyMuPDF; .doc/.docx via LibreOffice→PDF).
    """
    if ext == "pdf":
        import fitz
        with fitz.open(stream=data, filetype="pdf") as doc:
            page_count = doc.page_count
            native = " ".join(page.get_text() for page in doc)
        if len(native.strip()) >= ocr.OCR_TEXT_THRESHOLD:
            return native, True, page_count
        tmp = Path(tempfile.mkdtemp(prefix="neuleap_l2pdf_")) / "scan.pdf"
        tmp.write_bytes(data)
        ocr_text = ocr.ocr_pdf(tmp, max_pages=1)
        best = ocr_text if len(ocr_text.strip()) > len(native.strip()) else native
        return best, False, page_count

    if ext in ("docx", "doc"):
        native = _docx_text(data) if ext == "docx" else _extract_doc_text(data)
        pdf_path = _office_to_pdf(data, ext)
        page_count = _pdf_page_count_path(pdf_path) if pdf_path else None
        if len(native.strip()) >= ocr.OCR_TEXT_THRESHOLD:
            return native, True, page_count
        ocr_text = ocr.ocr_pdf(pdf_path, max_pages=1) if pdf_path else ""
        best = ocr_text if len(ocr_text.strip()) > len(native.strip()) else native
        return best, False, page_count

    if ext in _IMAGE_EXTS:
        return "", False, 1   # a single image is one page; L3 OCRs it
    return "", False, None


# ── Step 11A: File integrity ──────────────────────────────────────────────────

# OLE2 compound-document magic — the signature of a real legacy .doc file.
_OLE2_MAGIC = b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"


def _can_open(data: bytes, ext: str) -> bool:
    if ext == "pdf":
        try:
            import fitz
            # Opening succeeds for scanned PDFs too (no text needed here — OCR
            # happens in _extract_text); only a truly corrupt file fails.
            fitz.open(stream=data, filetype="pdf")
            return True
        except Exception:  # noqa: BLE001 - any parse failure ⇒ file is not a valid PDF
            return False
    if ext == "docx":
        try:
            from docx import Document
            Document(io.BytesIO(data))
            return True
        except Exception:  # noqa: BLE001 - any parse failure ⇒ file is not a valid DOCX
            return False
    if ext == "doc":
        # A valid legacy .doc is an OLE2 compound file. Real conversion happens
        # at text-extraction time; here we just reject obvious garbage.
        return data[:8] == _OLE2_MAGIC
    if ext in _IMAGE_EXTS:
        return len(data) > 0
    return False   # unsupported type


def validate_integrity(state: L2State) -> L2State:
    ok = _can_open(state["file_bytes"], state["file_extension"])
    if not ok:
        logger.warning("[L2] CORRUPT: %s", state["current_file"])
        return {"integrity_ok": False, "extracted_text": "", "text_complete": False, "page_count": None}

    text, complete, page_count = _extract(state["file_bytes"], state["file_extension"])
    return {
        "integrity_ok": True,
        "extracted_text": text,
        "text_complete": complete,
        "page_count": page_count,
    }


# ── Step 11B: Resume identity ─────────────────────────────────────────────────

def _looks_like_resume(text: str) -> bool:
    lower = text.lower()
    has_contact = any(k in lower for k in ["@", "phone", "mobile", "linkedin"])
    has_work    = any(k in lower for k in [
        "experience", "employment", "work history", "company", "organisation", "organization"
    ])
    has_edu     = any(k in lower for k in [
        "education", "university", "college", "bachelor", "master",
        "b.tech", "m.tech", "degree",
    ])
    has_skills = any(
        k in lower for k in ["skills", "technologies", "tools", "projects", "achievements"]
    )
    return has_contact and (has_work or has_edu) and has_skills


def validate_resume_identity(state: L2State) -> L2State:
    ext = state["file_extension"]

    # Page-count gate — applies to ALL document types (digital or scanned): a resume is
    # at most _MAX_RESUME_PAGES pages; anything longer is not a resume and is dropped.
    page_count = state.get("page_count")
    if page_count is not None and page_count > _MAX_RESUME_PAGES:
        logger.info("[L2] NOT_RESUME (%d pages > %d): %s",
                    page_count, _MAX_RESUME_PAGES, state["current_file"])
        return {
            "is_resume": False,
            "not_resume_reason": f"not_a_resume: {page_count} pages (limit {_MAX_RESUME_PAGES})",
        }

    if ext in _IMAGE_EXTS:
        # Scanned resume — pass through; L3 handles OCR parsing
        return {"is_resume": True}

    text = state["extracted_text"]

    # The file opened cleanly (integrity_ok) but we could not read any text —
    # e.g. a scan OCR couldn't crack, or LibreOffice was unavailable for a .doc.
    # Never drop it on a read failure: hand it to L3, whose OCR is stronger, and
    # let a human see it if L3 also fails. Losing a real resume is worse than an
    # occasional non-resume reaching L3 (which will just mark it failed).
    if not text.strip():
        logger.info("[L2] no readable text for %s — passing through to L3",
                    state["current_file"])
        return {"is_resume": True}

    is_resume = _looks_like_resume(text)
    if not is_resume:
        logger.info("[L2] NOT_RESUME: %s", state["current_file"])
    return {
        "is_resume": is_resume,
        "not_resume_reason": None if is_resume else "not_a_resume: no contact or work section",
    }
