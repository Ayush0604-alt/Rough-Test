"""Configuration for Layer 1.

The runtime is **MinIO-only**: incoming items are staged to ``raw/temp/{E_id}/``
and clean files land in ``raw/{YYYY}/{MM}/{DD}/{E_id}/`` (see
:mod:`app.services.mail_storage`). The graph nodes process each item in an
ephemeral OS temp dir created per run.

The ``base_dir`` / ``local/*`` directory properties below are NOT the runtime
store — they are retained only for the optional offline dev harness
(:mod:`app.pipeline.mail.run_local`, :mod:`app.pipeline.mail.samples`) and for
``download.py``'s local link-map resolution. Nothing in the deployed pipeline
reads or writes them.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

# Final file types that are allowed to survive into local/raw/.
# ``.doc`` (legacy Word) is accepted here and converted to .docx downstream;
# without it, .doc resumes — including those bundled inside zips — were dropped.
FINAL_TYPES: frozenset[str] = frozenset({".pdf", ".docx", ".doc", ".jpg", ".jpeg", ".png"})

# Temporary / special inputs accepted into processing but never stored as-is.
SPECIAL_TYPES: frozenset[str] = frozenset({".zip", ".xlsx"})

# Everything we are willing to pull into processing for inspection.
ACCEPTED_INPUT_TYPES: frozenset[str] = FINAL_TYPES | SPECIAL_TYPES

# ─────────────────────────────────────────────────────────────────────────────
# Upload size limits (per file type).
#
# Oversized files are never silently stored: the deterministic validators
# (Layer 1) and the L3 upload boundary reject them so the item surfaces as
# FAILED with a ``file_too_large: …`` reason. Every value below is in MB and is
# env-overridable. ``MAX_UPLOAD_ABSOLUTE_MB`` is a hard anti-OOM ceiling on the
# raw bytes any single upload may buffer (files above it are refused outright).
# ─────────────────────────────────────────────────────────────────────────────
_MB = 1024 * 1024


def _int_env(key: str, default: int) -> int:
    """Read a positive-integer env override (interpreted as MB/count), else default."""
    raw = os.environ.get(key)
    if not raw:
        return default
    try:
        val = int(raw)
    except ValueError:
        return default
    return val if val > 0 else default


# Per-extension caps in bytes (env vars are expressed in MB).
MAX_UPLOAD_BYTES: dict[str, int] = {
    ".pdf": _int_env("MAX_UPLOAD_MB_PDF", 10) * _MB,
    ".docx": _int_env("MAX_UPLOAD_MB_DOCX", 25) * _MB,
    ".doc": _int_env("MAX_UPLOAD_MB_DOC", 25) * _MB,
    ".jpg": _int_env("MAX_UPLOAD_MB_IMAGE", 10) * _MB,
    ".jpeg": _int_env("MAX_UPLOAD_MB_IMAGE", 10) * _MB,
    ".png": _int_env("MAX_UPLOAD_MB_IMAGE", 10) * _MB,
    ".zip": _int_env("MAX_UPLOAD_MB_ZIP", 100) * _MB,
    ".xlsx": _int_env("MAX_UPLOAD_MB_XLSX", 25) * _MB,
}

# Fallback cap for any accepted type without an explicit entry.
DEFAULT_MAX_UPLOAD_BYTES: int = _int_env("MAX_UPLOAD_MB_DEFAULT", 25) * _MB

# Hard ceiling on bytes buffered for one upload (anti-OOM). Files modestly over
# their per-type cap still buffer and stage → FAILED (accurate reason); files
# above this ceiling are refused at the boundary.
MAX_UPLOAD_ABSOLUTE_BYTES: int = _int_env("MAX_UPLOAD_ABSOLUTE_MB", 150) * _MB

# Zip-bomb guards (decompression limits), independent of the raw .zip cap above.
ZIP_MAX_TOTAL_BYTES: int = _int_env("ZIP_MAX_TOTAL_MB", 200) * _MB  # total uncompressed
ZIP_MAX_ENTRY_BYTES: int = _int_env("ZIP_MAX_ENTRY_MB", 50) * _MB   # per inner file
ZIP_MAX_ENTRIES: int = _int_env("ZIP_MAX_ENTRIES", 200)            # member count
ZIP_MAX_RATIO: int = _int_env("ZIP_MAX_RATIO", 100)               # uncompressed/compressed


def max_upload_bytes(name_or_ext: str) -> int:
    """Return the byte cap for a filename or extension (falls back to default)."""
    ext = name_or_ext if name_or_ext.startswith(".") else Path(name_or_ext).suffix
    return MAX_UPLOAD_BYTES.get(ext.lower(), DEFAULT_MAX_UPLOAD_BYTES)


def oversize_reason(filename: str, nbytes: int) -> str | None:
    """Return a ``file_too_large: …`` reason if ``nbytes`` exceeds the cap, else None."""
    limit = max_upload_bytes(filename)
    if nbytes > limit:
        return (
            f"file_too_large: '{Path(filename).name}' is "
            f"{nbytes / _MB:.1f} MB (limit {limit // _MB} MB)"
        )
    return None


def over_limit_message(filename: str) -> str:
    """Reason string when the exact size is unknown (boundary cap hit while streaming)."""
    limit = max_upload_bytes(filename)
    return f"file_too_large: '{Path(filename).name}' exceeds limit {limit // _MB} MB"

# URL hosts / patterns that count as "usable file links" during classification.
LINK_HOST_HINTS: tuple[str, ...] = (
    "drive.google.com",
    "docs.google.com",
    "1drv.ms",
    "onedrive.live.com",
    "sharepoint.com",
    "dropbox.com",
)


def _csv_env(key: str, default: tuple[str, ...]) -> tuple[str, ...]:
    """Read a comma-separated env override, else fall back to ``default`` (lower-cased)."""
    raw = os.environ.get(key)
    if not raw:
        return default
    items = tuple(x.strip().lower() for x in raw.split(",") if x.strip())
    return items or default


# ─────────────────────────────────────────────────────────────────────────────
# Sender blocklist — a cheap FIRST-PASS reject at the resume gate, applied before
# any payload inspection or LLM call (Outlook/Graph intake). These senders
# never carry a candidate's own resume, so we skip them outright.
#
#   • BLOCKLIST_DOMAINS  — match the sender's domain OR any subdomain of it
#                          (e.g. "linkedin.com" blocks notifications.linkedin.com).
#   • BLOCKLIST_PREFIXES — match an automated local-part or leading subdomain label
#                          (e.g. "noreply@…", "digest@…", "noreply.acme.com").
#
# Both are overridable via comma-separated env vars. Keep DOMAINS conservative — a
# job board that *forwards* a real resume would be dropped if you block its domain.
# ─────────────────────────────────────────────────────────────────────────────
BLOCKLIST_DOMAINS: tuple[str, ...] = _csv_env(
    "BLOCKLIST_DOMAINS",
    ("linkedin.com", "naukri.com"),
)
BLOCKLIST_PREFIXES: tuple[str, ...] = _csv_env(
    "BLOCKLIST_PREFIXES",
    (
        "noreply", "no-reply", "donotreply", "do-not-reply", "bounce",
        "mailer-daemon", "mailer", "postmaster", "newsletter", "digest",
        "notifications", "notification", "notify", "updates", "alerts", "alert",
        "jobalerts", "jobs-noreply",
    ),
)


def _parse_date(received_date: str | None):
    """Parse an ISO-8601-ish date string to a datetime, else now() in IST."""
    from datetime import datetime

    from app.services import clock

    if received_date:
        text = str(received_date).strip().replace("Z", "+00:00")
        for parser in (
            lambda s: datetime.fromisoformat(s),
            lambda s: datetime.strptime(s[:10], "%Y-%m-%d"),
        ):
            try:
                return parser(text)
            except (ValueError, TypeError):
                continue
    return clock.now()


def _month_from(received_date: str | None) -> str:
    """Return a 2-digit month from an ISO-8601 date, else the current month."""
    return f"{_parse_date(received_date).month:02d}"


def _day_from(received_date: str | None) -> str:
    """Return a 2-digit day from an ISO-8601 date, else the current day."""
    return f"{_parse_date(received_date).day:02d}"


def _default_base_dir() -> Path:
    """Resolve the project base dir (the folder that contains ``local/``)."""
    override = os.environ.get("NEULEAP_BASE_DIR")
    if override:
        return Path(override).expanduser().resolve()
    # app/mail_config.py -> repo root (the folder holding local/) is two up.
    return Path(__file__).resolve().parent.parent


@dataclass(frozen=True)
class Settings:
    """Immutable runtime settings for a Layer 1 run."""

    base_dir: Path = field(default_factory=_default_base_dir)
    # Enable GPT-4o-mini classification assist. Off unless explicitly requested
    # AND an API key is present (see classifier.llm_available()).
    use_llm: bool = field(
        default_factory=lambda: os.environ.get("NEULEAP_USE_LLM", "0") == "1"
    )
    llm_model: str = field(
        default_factory=lambda: os.environ.get("NEULEAP_LLM_MODEL", "gpt-4o-mini")
    )

    @property
    def local_dir(self) -> Path:
        return self.base_dir / "local"

    @property
    def inbox_dir(self) -> Path:
        return self.local_dir / "inbox"

    @property
    def processing_dir(self) -> Path:
        return self.local_dir / "processing"

    @property
    def raw_dir(self) -> Path:
        return self.local_dir / "raw"

    @property
    def resume_dir(self) -> Path:
        """Final clean storage root: local/resume/{MM}/{E_id}/."""
        return self.local_dir / "resume"

    def resume_path(self, e_id: str, received_date: str | None) -> Path:
        """Per-email clean folder: local/resume/{MM}/{E_id}/ (dated pipeline).

        ``MM`` is the 2-digit month parsed from ``received_date`` (ISO-8601);
        falls back to the current month when the date is missing/unparseable.
        """
        month = _month_from(received_date)
        return self.resume_dir / month / e_id

    def raw_item_dir(self, e_id: str) -> Path:
        """Per-email downloaded-attachment folder: local/raw/{E_id}/."""
        return self.raw_dir / e_id

    def resume_dated_dir(self, e_id: str, received_date: str | None) -> Path:
        """Per-email parsed-resume folder: local/resume/{MM}/{DD}/{E_id}/.

        MM/DD come from the email's received_date (falls back to today).
        """
        return (self.resume_dir / _month_from(received_date)
                / _day_from(received_date) / e_id)

    def ensure_folders(self) -> None:
        """Create the core local folders if they do not exist."""
        for path in (self.inbox_dir, self.processing_dir, self.raw_dir,
                     self.resume_dir):
            path.mkdir(parents=True, exist_ok=True)


# A module-level default; callers may construct their own Settings for tests.
SETTINGS = Settings()
