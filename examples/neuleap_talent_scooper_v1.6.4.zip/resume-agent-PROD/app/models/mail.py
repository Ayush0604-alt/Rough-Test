"""Typed models for Layer 1 state.

Pydantic models are used for the domain objects (validated, serializable) and a
``TypedDict`` is used for the LangGraph state container, because LangGraph
operates on dict-like state.
"""

from __future__ import annotations

from enum import Enum
from typing import Optional, TypedDict

from pydantic import BaseModel, Field


class Classification(str, Enum):
    """What an email contains, per Step 4 of the plan."""

    ATTACHMENT = "Attachment"
    LINKS = "Links"
    MIXED = "Mixed"
    NONE = "None"


class ProcessStatus(str, Enum):
    PASSED = "Passed"
    FAILED = "Failed"


class ValidationMode(str, Enum):
    """How extracted_status should be worded for an email."""

    PLAIN = "plain"   # Success | Partial(N/M) | Fail
    ZIP = "zip"       # Success(N files) | Partial(N/M files) | Fail(0/M files)
    EXCEL = "excel"   # Success(N/N rows) | Partial(N/M rows) | Fail(0/M rows)
    LINK = "link"     # link-only, nothing fetchable in local mode


class EmailItem(BaseModel):
    """One email-like item discovered in the inbox."""

    e_id: str
    manifest_name: Optional[str] = None          # JSON manifest filename, if any
    sender_mail_id: str = "unknown"
    subject: str = "unknown"
    received_date: Optional[str] = None          # ISO-8601 or None
    body: str = ""
    # Attachment filenames relative to the item's processing folder.
    attachment_files: list[str] = Field(default_factory=list)
    # Raw link strings declared in the manifest (in addition to body links).
    declared_links: list[str] = Field(default_factory=list)
    # Usable file links detected at inspect time (body + declared).
    detected_links: list[str] = Field(default_factory=list)
    # Folder (under local/processing) holding this item's files after the move.
    processing_subdir: Optional[str] = None
    # Recruiter-typed intake source (mandatory on the manual upload modal), read
    # from the staging manifest — carried onto the email_master row, then onto
    # every candidate_master row this batch produces.
    candidate_source: Optional[str] = None


class ValidationResult(BaseModel):
    """Outcome of validating a single file (or inner zip file / excel sheet)."""

    e_id: str
    filename: str
    file_type: str
    ok: bool
    reason: str = ""
    # For container types (zip/excel) we carry inner counts.
    inner_total: int = 0
    inner_passed: int = 0
    manual_review_rows: list[int] = Field(default_factory=list)


class StoredFile(BaseModel):
    """A file that survived validation and now lives in local/raw/."""

    e_id: str
    original_name: str
    stored_name: str
    stored_path: str


class AuditEvent(BaseModel):
    """An audit-style event (kept in memory only — no DB writes in test mode)."""

    run_id: str
    e_id: Optional[str]
    node: str
    status: str          # Success | Failed | Retry | Discarded | ManualReview | Info
    reason: str = ""
    created_at: str


class DiscardedItem(BaseModel):
    e_id: str
    sender_mail_id: str
    subject: str
    reason: str


class WorkflowResult(BaseModel):
    """The shared Final Output Schema returned by every workflow (A/B/C)."""

    e_id: str
    workflow: str                 # "links" | "zip" | "excel" | "attachment"
    status: str                   # Success | Partial | Fail
    processed_count: int = 0
    success_count: int = 0
    failure_count: int = 0
    manual_review_count: int = 0
    stored_files: list[str] = Field(default_factory=list)
    errors: list[str] = Field(default_factory=list)


class EmailMasterRow(BaseModel):
    """The 7 spec columns, plus the recruiter-typed intake source (8th, added
    for the "Add to Intake queue" source-tagging feature — not part of the
    original spec, but needed on the same row it's staged from)."""

    E_id: str
    sender_mail_id: str
    subject: str
    received_date: str
    attachment_names: str       # comma-separated final stored filenames
    extracted_status: str       # Success | Partial(N/M...) | Fail
    process_status: str         # Passed | Failed
    candidate_source: Optional[str] = None


class Layer1State(TypedDict, total=False):
    """LangGraph state container threaded through every node."""

    run_id: str
    items: list[EmailItem]
    cursor: int                 # index of the item currently being processed
    current_item: Optional[EmailItem]
    classification: Optional[Classification]
    validation_results: list[ValidationResult]
    stored_files: list[StoredFile]
    discarded_items: list[DiscardedItem]
    email_master_rows: list[EmailMasterRow]
    audit_events: list[AuditEvent]
    workflow_results: list[WorkflowResult]
    # Transient per-item scratch (set by validate_files, consumed downstream).
    pending_store: list[dict]
    pending_status: str
    pending_manual_review: list[int]
    pending_stored_names: list[str]
    pending_workflows: list[dict]
