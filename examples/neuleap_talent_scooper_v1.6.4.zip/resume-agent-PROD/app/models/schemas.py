from __future__ import annotations

from datetime import datetime
from typing import Literal, Optional

from pydantic import BaseModel


class ProcessEmailRequest(BaseModel):
    e_id: str
    mail_send_date: str   # YYYY-MM-DD


class RunL2Request(BaseModel):
    """Trigger a full L2 run over all Passed emails."""
    dry_run: bool = False


class FileResult(BaseModel):
    filename: str
    status: str
    candidate_id: Optional[str] = None
    fail_reason: Optional[str] = None
    # Raw-bucket key of the dropped file, when one was kept (L2 drops). Lets the
    # review queue store an exact raw_s3_key instead of guessing it later.
    s3_key: Optional[str] = None


class ProcessEmailResponse(BaseModel):
    e_id: str
    total_files: int
    passed: int
    failed: int
    reapplications: int
    file_results: list[FileResult]
    folder_status: Literal["Processed", "Processing"]
    # L3 extraction results for the files that passed L2 (auto-chain).
    extractions: list[dict] = []


class RunL2Response(BaseModel):
    emails_processed: int
    total_files: int
    total_passed: int
    total_failed: int
    extractions_run: int
    started_at: datetime
    completed_at: datetime


class HealthResponse(BaseModel):
    status: Literal["ok", "degraded"]
    storage_backend: str
    s3_backend: str
    auto_extract: bool
    version: str = "2.0.0"
