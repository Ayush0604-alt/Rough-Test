from __future__ import annotations

import operator
from datetime import date
from typing import Annotated, Literal, Optional

from typing_extensions import TypedDict


class FileOutcome(TypedDict):
    filename: str
    status: Literal["PASS", "DUP", "DUP_HIRED", "CORRUPT", "NOT_RESUME", "REAPPLICATION"]
    candidate_id: Optional[str]
    fail_reason: Optional[str]


class L2State(TypedDict):
    # ── Email-level ──────────────────────────────────────────
    e_id: str
    run_date: str           # YYYY-MM-DD
    mail_send_date: date

    # ── File loop ────────────────────────────────────────────
    files_to_process: list[str]   # S3 keys remaining
    current_file: str             # S3 key being processed
    file_bytes: Optional[bytes]
    file_extension: str           # pdf | docx | jpg | png

    # ── Extracted text (computed once, reused for identity + dedup) ──
    extracted_text: str
    # True only when L2 captured the FULL text (born-digital / no partial first-page
    # OCR), so L3 may reuse extracted_text instead of re-extracting. False ⇒ L3 re-OCRs.
    text_complete: bool
    # Page count (PDF via PyMuPDF; DOCX/DOC via LibreOffice→PDF). None = undeterminable.
    page_count: Optional[int]

    # ── Validation results ───────────────────────────────────
    integrity_ok: bool
    is_resume: bool
    # Specific reason when is_resume is False (e.g. ">3 pages"); drop_file surfaces it.
    not_resume_reason: Optional[str]

    # ── Deterministic contact (regex; persisted into the stub) ──
    cand_name: str
    cand_email: str
    cand_phno: str

    # ── Dedup results ────────────────────────────────────────
    fuzzy_match_row: Optional[dict]
    hash_match: bool
    is_post_screening: bool

    # ── Per-file output ──────────────────────────────────────
    candidate_id: Optional[str]
    s3_clean_path: Optional[str]
    drop_reason: Optional[str]

    # ── Audit accumulator (appended across all files) ────────
    file_outcomes: Annotated[list[FileOutcome], operator.add]
