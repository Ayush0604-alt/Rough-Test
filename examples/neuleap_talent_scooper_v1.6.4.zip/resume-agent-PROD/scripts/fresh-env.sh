#!/usr/bin/env bash
# Reset this checkout to a CLEAN environment before a first deploy on a new host.
#
# Two things carry a previous deployment's state and must be cleared for a truly
# fresh environment (see the "Your interview is booked" / leaked source-tags issue):
#   1. secrets/  — file-based config (source tags, templates, keys) that is
#                  bind-mounted into the app container. Copying the project folder
#                  brings the old host's config along.
#   2. The Docker data volumes (pg_data, minio_data) — the database + object store.
#
# This script empties secrets/ (keeping .gitkeep) and drops the Docker volumes.
# It NEVER touches your source code. Run it from anywhere.
#
#   bash scripts/fresh-env.sh
#   bash scripts/fresh-env.sh --keep-secrets   # only drop DB/volumes
#   bash scripts/fresh-env.sh --yes            # no prompt
set -euo pipefail

KEEP_SECRETS=0
ASSUME_YES=0
for arg in "$@"; do
  case "$arg" in
    --keep-secrets) KEEP_SECRETS=1 ;;
    --yes|-y)       ASSUME_YES=1 ;;
    *) echo "Unknown option: $arg" >&2; exit 2 ;;
  esac
done

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

echo "Fresh-environment reset for: $ROOT"
echo "This will:"
[ "$KEEP_SECRETS" -eq 0 ] && echo "  * empty secrets/ (source tags, templates, keys) — keeping only .gitkeep"
echo "  * run 'docker compose down -v' (DROPS the database + object-store volumes)"
echo

if [ "$ASSUME_YES" -eq 0 ]; then
  read -r -p "Type 'fresh' to proceed: " ans
  [ "$ans" = "fresh" ] || { echo "Aborted — nothing changed."; exit 1; }
fi

# 1) Clear file-based config (keep the .gitkeep placeholder so the dir survives).
if [ "$KEEP_SECRETS" -eq 0 ]; then
  mkdir -p secrets
  find secrets -mindepth 1 ! -name '.gitkeep' -exec rm -rf {} + 2>/dev/null || true
  touch secrets/.gitkeep
  echo "secrets/ cleared."
fi

# 2) Drop the Docker volumes (database + object store).
docker compose down -v
echo "Docker volumes dropped."

echo
echo "Clean slate ready. Bring it up with:"
echo "  docker compose up -d --build"
echo
echo "The app recreates default config on start (empty source tags, a fresh"
echo "secrets/jwt_secret.key, seeded default users that must change their password)."
