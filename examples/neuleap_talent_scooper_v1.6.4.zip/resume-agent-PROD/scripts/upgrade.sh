#!/usr/bin/env bash
# Seamless, data-preserving upgrade with an automatic pre-upgrade backup and
# auto-rollback on failure. Run from the project root (or anywhere — it cd's up).
#
#   bash scripts/upgrade.sh
#
# What it does:
#   1. Takes a full pre-upgrade DB dump (host file) — nothing is ever dropped.
#   2. Tags the CURRENT app/frontend images as :rollback so we can revert.
#   3. Rebuilds the images and recreates services WITHOUT touching data volumes
#      (no `-v`). schema.sql runs additively on boot, so new columns/tables are
#      created in place — existing data + config are preserved.
#   4. Waits for health, then runs a data-consistency check.
#   5. On ANY failure, calls rollback.sh to restore the previous images + DB.
#
# NOTE: this preserves the named volumes pg_data / minio_data and the bind-mounted
# secrets/ + .env. It NEVER runs `docker compose down -v`.
set -euo pipefail
cd "$(dirname "$0")/.."

PROJECT="$(basename "$(pwd)" | tr '[:upper:] ' '[:lower:]-')"
STAMP="$(date +%Y%m%dT%H%M%SZ)"
BK="backups/preupgrade/preupgrade_${STAMP}"
mkdir -p "$BK"

echo "== NeuLeap upgrade ${STAMP} =="

echo "[1/6] Pre-upgrade full DB dump -> $BK/db.dump"
docker compose exec -T postgres pg_dump -U resume_user -d resume_db -Fc --no-owner --no-privileges > "$BK/db.dump"

echo "[2/6] Tagging current images for rollback"
app_img="$(docker inspect --format='{{.Image}}' "$(docker compose ps -q app)")"
fe_img="$(docker inspect --format='{{.Image}}' "$(docker compose ps -q frontend)")"
docker tag "$app_img" "${PROJECT}-app:rollback"
docker tag "$fe_img"  "${PROJECT}-frontend:rollback"
printf '%s\n' "$app_img" > "$BK/app_image"
printf '%s\n' "$fe_img"  > "$BK/frontend_image"

echo "[3/6] Building new images"
docker compose build app frontend

echo "[4/6] Recreating services (data volumes preserved)"
docker compose up -d

echo "[5/6] Waiting for app health"
ok=0
for _ in $(seq 1 40); do
  if docker compose ps app --format '{{.Status}}' | grep -q healthy; then ok=1; break; fi
  sleep 3
done
if [ "$ok" != "1" ]; then
  echo "[!] App did not become healthy — ROLLING BACK"
  bash scripts/rollback.sh "$BK"
  exit 1
fi

echo "[6/6] Data consistency check"
if ! docker compose exec -T postgres psql -U resume_user -d resume_db \
      -c "SELECT count(*) FROM candidate_master;" >/dev/null 2>&1; then
  echo "[!] Consistency check failed — ROLLING BACK"
  bash scripts/rollback.sh "$BK"
  exit 1
fi

echo "== Upgrade successful. Pre-upgrade backup: $BK =="
