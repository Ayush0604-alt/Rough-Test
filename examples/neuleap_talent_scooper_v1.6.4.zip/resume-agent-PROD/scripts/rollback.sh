#!/usr/bin/env bash
# Revert to the previous version: restore the :rollback images and (if a
# pre-upgrade dump is given) the database. Called automatically by upgrade.sh on
# failure, or run by hand:
#
#   bash scripts/rollback.sh                       # images only
#   bash scripts/rollback.sh backups/preupgrade/preupgrade_<STAMP>   # images + DB
set -euo pipefail
cd "$(dirname "$0")/.."

PROJECT="$(basename "$(pwd)" | tr '[:upper:] ' '[:lower:]-')"
BK="${1:-}"

echo "== NeuLeap rollback =="

if docker image inspect "${PROJECT}-app:rollback" >/dev/null 2>&1; then
  echo "[1/3] Restoring previous images"
  docker tag "${PROJECT}-app:rollback"      "${PROJECT}-app:latest"
  docker tag "${PROJECT}-frontend:rollback" "${PROJECT}-frontend:latest"
else
  echo "[1/3] No :rollback images found — recreating with current images"
fi

echo "[2/3] Recreating services (data volumes preserved)"
docker compose up -d

if [ -n "$BK" ] && [ -f "$BK/db.dump" ]; then
  echo "[3/3] Restoring database from $BK/db.dump"
  # Wait for postgres to accept connections first.
  for _ in $(seq 1 20); do
    docker compose exec -T postgres pg_isready -U resume_user -d resume_db >/dev/null 2>&1 && break
    sleep 2
  done
  docker compose exec -T postgres pg_restore -U resume_user -d resume_db \
     --clean --if-exists --no-owner --no-privileges < "$BK/db.dump" || true
else
  echo "[3/3] No DB dump supplied — images reverted only (data left as-is)"
fi

echo "== Rollback complete =="
