#!/usr/bin/env python3
"""Sign a bundle manifest with an Ed25519 private key.

    python scripts/sign_bundle.py <private_key.pem> <manifest.json> <out.sig>

Writes a base64 Ed25519 signature over the raw manifest.json bytes. The server
verifies it with the matching public key (Settings → System Upgrade). The
private key never leaves the build machine.
"""
import base64
import sys

from cryptography.hazmat.primitives.serialization import load_pem_private_key


def main() -> int:
    if len(sys.argv) != 4:
        print(__doc__)
        return 2
    priv_path, manifest_path, out_path = sys.argv[1], sys.argv[2], sys.argv[3]
    key = load_pem_private_key(open(priv_path, "rb").read(), password=None)
    payload = open(manifest_path, "rb").read()
    sig = key.sign(payload)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(base64.b64encode(sig).decode("ascii"))
    print(f"signed -> {out_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
