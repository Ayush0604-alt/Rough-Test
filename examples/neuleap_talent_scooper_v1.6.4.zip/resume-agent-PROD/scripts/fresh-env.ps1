# Reset this checkout to a CLEAN environment before a first deploy on a new host.
#
# Two things carry a previous deployment's state and must be cleared for a truly
# fresh environment (see the "Your interview is booked" / leaked source-tags issue):
#   1. secrets/  - file-based config (source tags, templates, keys) that is
#                  bind-mounted into the app container. Copying the project folder
#                  brings the old host's config along.
#   2. The Docker data volumes (pg_data, minio_data) - the database + object store.
#
# This script empties secrets/ (keeping .gitkeep) and drops the Docker volumes.
# It NEVER touches your source code. Run it from the project root.
#
#   powershell -ExecutionPolicy Bypass -File scripts\fresh-env.ps1
#   powershell -ExecutionPolicy Bypass -File scripts\fresh-env.ps1 -KeepSecrets   # only drop DB/volumes
#   powershell -ExecutionPolicy Bypass -File scripts\fresh-env.ps1 -Yes            # no prompt

param(
    [switch]$KeepSecrets,   # keep secrets/ files (only reset the DB/volumes)
    [switch]$Yes            # skip the confirmation prompt
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

Write-Host "Fresh-environment reset for: $root" -ForegroundColor Cyan
Write-Host "This will:" -ForegroundColor Yellow
if (-not $KeepSecrets) {
    Write-Host "  * empty secrets\ (source tags, templates, keys) - keeping only .gitkeep"
}
Write-Host "  * run 'docker compose down -v' (DROPS the database + object-store volumes)"
Write-Host ""

if (-not $Yes) {
    $ans = Read-Host "Type 'fresh' to proceed"
    if ($ans -ne "fresh") { Write-Host "Aborted - nothing changed." -ForegroundColor Red; exit 1 }
}

# 1) Clear file-based config (keep the .gitkeep placeholder so the dir survives).
if (-not $KeepSecrets) {
    if (Test-Path "secrets") {
        Get-ChildItem -Path "secrets" -Force | Where-Object { $_.Name -ne ".gitkeep" } | Remove-Item -Recurse -Force
    } else {
        New-Item -ItemType Directory -Path "secrets" | Out-Null
    }
    if (-not (Test-Path "secrets\.gitkeep")) { New-Item -ItemType File -Path "secrets\.gitkeep" | Out-Null }
    Write-Host "secrets\ cleared." -ForegroundColor Green
}

# 2) Drop the Docker volumes (database + object store).
docker compose down -v
Write-Host "Docker volumes dropped." -ForegroundColor Green

Write-Host ""
Write-Host "Clean slate ready. Bring it up with:" -ForegroundColor Cyan
Write-Host "  docker compose up -d --build"
Write-Host ""
Write-Host "The app recreates default config on start (empty source tags, a fresh" -ForegroundColor DarkGray
Write-Host "secrets\jwt_secret.key, seeded default users that must change their password)." -ForegroundColor DarkGray
