#!/usr/bin/env bash
# Generate an Ed25519 signing keypair for upgrade bundles. Keep signing_private.pem
# SECRET on the build machine; paste signing_public.pem into Settings → System
# Upgrade on the server.
#
#   bash scripts/keygen.sh            # -> signing_private.pem + signing_public.pem
set -euo pipefail
cd "$(dirname "$0")/.."

PY=python; command -v python >/dev/null 2>&1 || PY=python3
"$PY" - <<'PYEOF'
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization as s
k = Ed25519PrivateKey.generate()
open("signing_private.pem", "wb").write(
    k.private_bytes(s.Encoding.PEM, s.PrivateFormat.PKCS8, s.NoEncryption()))
open("signing_public.pem", "wb").write(
    k.public_key().public_bytes(s.Encoding.PEM, s.PublicFormat.SubjectPublicKeyInfo))
print("wrote signing_private.pem (keep secret) + signing_public.pem (paste in Settings)")
PYEOF
