#!/usr/bin/env bash
# Build an upgrade BUNDLE from the currently-built app/frontend images. Run this
# on a machine where you've already `docker compose build`-ed the new version.
# The produced dist-bundle/bundle_<version>.tar is what an Admin uploads in
# Settings → System Upgrade.
#
#   bash scripts/make-bundle.sh v1.3.1 [features.txt]
#
# features.txt (optional): one feature line per row, shown after the upgrade.
#
# Optional env vars:
#   SIGN_KEY=signing_private.pem    sign the manifest (recommended)
#   ENV_ADDITIONS=path/to/env.add   new .env KEY=default lines this release needs
#   COMPOSE_OVERLAY=path/to/ov.yml  compose overlay (new port/service/volume)
set -euo pipefail
cd "$(dirname "$0")/.."

PROJECT="${COMPOSE_PROJECT_NAME:-neuleap_app_v2}"
VER="${1:?usage: make-bundle.sh <version> [features.txt]}"
FEAT="${2:-}"
# Bundles are large build artifacts kept OUTSIDE the repo — default to the repo's
# parent (../dist-bundle); override with DIST_OUT=/some/path.
OUT="${DIST_OUT:-../dist-bundle}"
STAGE="$OUT/stage"
rm -rf "$STAGE"; mkdir -p "$STAGE"

echo "Saving ${PROJECT}-app:latest + ${PROJECT}-frontend:latest ..."
docker save "${PROJECT}-app:latest"      -o "$STAGE/app.tar"
docker save "${PROJECT}-frontend:latest" -o "$STAGE/frontend.tar"

app_sha=$(sha256sum "$STAGE/app.tar" | cut -d' ' -f1)
fe_sha=$(sha256sum "$STAGE/frontend.tar" | cut -d' ' -f1)

feats='[]'
if [ -n "$FEAT" ] && [ -f "$FEAT" ]; then
  feats=$(python -c "import json,sys;print(json.dumps([l.strip() for l in open(sys.argv[1],encoding='utf-8') if l.strip()]))" "$FEAT" 2>/dev/null \
       || python3 -c "import json,sys;print(json.dumps([l.strip() for l in open(sys.argv[1],encoding='utf-8') if l.strip()]))" "$FEAT" 2>/dev/null \
       || echo '[]')
fi

# Optional .env additions + compose overlay — staged + checksummed so the signed
# manifest covers them (tamper-proof).
env_sha=""; overlay_sha=""
if [ -n "${ENV_ADDITIONS:-}" ] && [ -f "$ENV_ADDITIONS" ]; then
  cp "$ENV_ADDITIONS" "$STAGE/env.additions"; env_sha=$(sha256sum "$STAGE/env.additions" | cut -d' ' -f1); echo "including .env additions"
fi
if [ -n "${COMPOSE_OVERLAY:-}" ] && [ -f "$COMPOSE_OVERLAY" ]; then
  cp "$COMPOSE_OVERLAY" "$STAGE/overlay.compose.yml"; overlay_sha=$(sha256sum "$STAGE/overlay.compose.yml" | cut -d' ' -f1); echo "including compose overlay"
fi

cat > "$STAGE/manifest.json" <<JSON
{
  "version": "${VER}",
  "created_at": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "project": "${PROJECT}",
  "images": [
    {"service":"app","tarfile":"app.tar","image":"${PROJECT}-app:latest","sha256":"${app_sha}"},
    {"service":"frontend","tarfile":"frontend.tar","image":"${PROJECT}-frontend:latest","sha256":"${fe_sha}"}
  ],
  "env_sha256": "${env_sha}",
  "overlay_sha256": "${overlay_sha}",
  "features": ${feats}
}
JSON

# Optional signing: set SIGN_KEY=path/to/signing_private.pem to sign the manifest.
BUNDLE_FILES="app.tar frontend.tar manifest.json"
[ -f "$STAGE/env.additions" ] && BUNDLE_FILES="$BUNDLE_FILES env.additions"
[ -f "$STAGE/overlay.compose.yml" ] && BUNDLE_FILES="$BUNDLE_FILES overlay.compose.yml"
if [ -n "${SIGN_KEY:-}" ]; then
  PY=python; command -v python >/dev/null 2>&1 || PY=python3
  "$PY" scripts/sign_bundle.py "$SIGN_KEY" "$STAGE/manifest.json" "$STAGE/manifest.sig"
  BUNDLE_FILES="$BUNDLE_FILES manifest.sig"
  echo "Bundle signed."
fi

tar -C "$STAGE" -cf "$OUT/bundle_${VER}.tar" $BUNDLE_FILES
rm -rf "$STAGE"
echo "Bundle ready: $OUT/bundle_${VER}.tar"
